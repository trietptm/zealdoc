#include "priv.h"

/* smartcard reader handle */
usb_dev_handle *g_dev = NULL; 

#define EP_IN 	0x84
#define EP_OUT 	0x05


char output[MAX_BUFFER_LEN];
char input[MAX_BUFFER_LEN];

#define ASSERT_TRUE(fun)	\
	do {			\
		int rv;		\
		rv = fun();	\
		if (!rv) {	\
			printf("%s err\r\n", __FUNCTION__);	\
			exit(0);				\
		}						\
	} while (0)


int find_interclass(struct usb_config_descriptor *config, int cla)
{
	int j, i;
	struct usb_interface *intfc;

	for (i = 0; i < config->bNumInterfaces; i++)
		intfc = &config->interface[i];
		for (j = 0; j < intfc->num_altsetting; j++) {
			if (intfc->altsetting[j].bInterfaceClass == cla)
				return 1;
	}
	return 0;
}

int is_needed(struct usb_device *dev)
{
	int i;
	for (i = 0; i < dev->descriptor.bNumConfigurations; i++) 
		if (find_interclass(&dev->config[i], 0x0b))
			return 1;
	return 0;
}

/* init usb bus and get set g_dev handle */
int get_usb_dev(void) 
{
	struct usb_bus *bus; 
	struct usb_device *dev; 
	usb_dev_handle *udev; 

	usb_init(); 
	usb_find_busses(); 
	usb_find_devices(); 
	usb_set_debug(255);

	printf("bus/device\tidVendor/idProduct\n"); 

	for (bus = usb_busses; bus; bus = bus->next) { 
		for (dev = bus->devices; dev; dev = dev->next) { 
			udev = usb_open(dev);
			if (udev) {
				if (is_needed(dev)) {
					printf("%s/%s\t\t%04X/%04X\n", bus->dirname, dev->filename, 
					dev->descriptor.idVendor, dev->descriptor.idProduct); 

#if 0
					if (usb_set_configuration(udev, 1) < 0) {
						printf("set_config err\r\n");
						usb_close(udev);
						break;
					}

					if (usb_set_altinterface(udev, 0) < 0) {
						printf("altset err\r\n");
						usb_close(udev);
						break;
					}

#endif
					if (usb_claim_interface(udev, 0) < 0) {
						printf("claim err\r\n");
						usb_close(udev);
						break;
					}
					g_dev = udev;
					break;
				}
				usb_close(udev);
			}
		}
	}
	/* found */
	if (g_dev)
		return 1;
	return 0;
}

/* t = 1 is receive */
void print_bin2hex(u8 *tmp_bin, int len, int t)
{
	int i;
	char buff[128];

	if (len > MAX_BUFFER_LEN) {
		printf("default output len is too samll, len=%d\r\n", len);
		return;
	}
	memset(buff, 0x00, sizeof (buff));

	for (i = 0; i < len; i++)
		sprintf(buff + 3 * i, "%02x ", tmp_bin[i]);
	if (t == 1)
		printf("<<< ");
	else
		printf(">>> ");
	printf("%s\n", buff);
}

int test_snd_recv(u8 *snd, int sl, u8 *rcv, int rl)
{
	int ret, ag = 0;

	ret = usb_bulk_write(g_dev, EP_OUT, snd, sl, 50);

	if (ret < 0) {
		printf("usb_bulk_write fail, err=%s\r\n", strerror(errno));
		goto err;
	}
	print_bin2hex(snd, ret, 0);

again:
	ret = usb_bulk_read(g_dev, EP_IN, rcv, rl, 50);
	if (ret < 0) {
		if (ag == 0) {
			printf("usb_bulk_read fail, err=%s\r\n", strerror(errno));
			goto err;
		}
	} else {
		print_bin2hex(rcv, ret, 1);
		ag = 1;
		goto again;
	}
	return 1;
err:
	return 0;
}

int do_PowerOff(int bSlot, int bSeq)
{
	ccid_build_PowerOff(bSlot, bSeq);
	printf("PowerOff:\r\n");
	return test_snd_recv(output, 10, input, sizeof (input));
}

int do_PowerOn(int bSlot, int bSeq)
{
	ccid_build_PowerOn(bSlot, bSeq);
	printf("PowerOn:\r\n");

	return test_snd_recv(output, 10, input, sizeof (input));
}

int do_GetSlotStatus(int bSlot, int bSeq)
{
	ccid_build_GetSlotStatus(bSlot, bSeq);
	printf("GetSlotStatus:\r\n");

	return test_snd_recv(output, 10, input, sizeof (input));
}

int do_GetParameters(int bSlot, int bSeq)
{
	ccid_build_GetParameters(bSlot, bSeq);
	printf("GetParameters:\r\n");

	return test_snd_recv(output, 10, input, sizeof (input));
}
int do_ResetParameters(int bSlot, int bSeq)
{
	ccid_build_GetParameters(bSlot, bSeq);
	printf("ResetParameters:\r\n");
	return test_snd_recv(output, 10, input, sizeof (input));
}
int warm_up(void)
{
	int seq = 0, ret;
	int i = 3;

	while (i--) {

		ccid_build_GetSlotStatus(0, seq++);

		if (test_snd_recv(output, 10, input, sizeof (input))) {
			printf("warm up success\r\n");
			return 1;
		}
#if 0
		ret = usb_bulk_write(g_dev, EP_OUT, cmd, 2, 50);
		if (ret < 0) {
			continue;
		}
		print_bin2hex(cmd, ret, 0);
		/* read all */
		ret = usb_bulk_read(g_dev, EP_IN, cmd, sizeof (cmd), 50);
		if (ret > 0) {
			print_bin2hex(cmd, ret, 1);
			printf("Warm up success\r\n");
again:
			if (usb_bulk_read(g_dev, EP_IN, cmd, sizeof (cmd), 50) > 0) {
				print_bin2hex(cmd, ret, 1);
				goto again;
			}

			return 1;
		}
#endif
	}

	printf("Warm up failure\r\n");
	return 0;
}

int test_init(void)
{
	ASSERT_TRUE(get_usb_dev);
	ASSERT_TRUE(warm_up);

	return 0;
}

int test_cmd(void)
{
	do_PowerOn(0, 2);
	do_PowerOn(0, 3);
	do_GetSlotStatus(0, 1);
	return 0;
	if (!do_GetSlotStatus(0, 0) ||
	    !do_PowerOn(0, 0) ||
	    !do_PowerOff(0, 0) ||
	    !do_GetParameters(0, 1) ||
	    !do_ResetParameters(0, 1)) {
		return 1;
	}
	return 0;
}

int main(void)
{
	test_init();


	if (g_dev) {
		test_cmd();
		usb_release_interface(g_dev, 0);
		usb_close(g_dev);
		g_dev = NULL;
	}
	return 0;
}
