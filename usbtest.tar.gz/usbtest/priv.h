#ifndef __PRIV_H
#define __PRIV_H

#include <usb.h>	/* libusb */
#include <stdio.h>
#include <string.h>

#ifndef WIN32
 #include <errno.h>
#else
 #define __FUNCTION__	"fun()"
#endif

#define MAX_BUFFER_LEN		64

typedef unsigned char u8;


#include "ccid.h"

extern char output[];
extern char input[];

/* misc */
int is_needed(struct usb_device *dev);

#endif /* __PRIV_H */
