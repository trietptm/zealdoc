#ifndef __PRIV_H
#define __PRIV_H

#define LIBUSB_10

#ifdef LIBUSB_01
#include <usb.h>	/* libusb */
#endif
#ifdef LIBUSB_10
#include <libusb-1.0/libusb.h>	/* libusb */
#endif
#include <stdio.h>
#include <string.h>

#ifndef WIN32
 #include <errno.h>
#else
 #define __FUNCTION__	"fun()"
#endif

#define MAX_BUFFER_LEN		64

typedef unsigned char u8;

#ifdef LIBUSB_10
#define usb_init() libusb_init(NULL)
#define usb_find_busses() libusb_find_busses()
#define usb_find_devices() libusb_find_devices()
#define usb_set_debug(x) libusb_set_debug(NULL, x)
#define usb_device libusb_device
#define usb_dev_handle libusb_device_handle
#endif

#include "ccid.h"

extern char output[];
extern char input[];

/* misc */
int is_needed(struct usb_device *dev);

#endif /* __PRIV_H */
