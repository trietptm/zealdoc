#include <libusb-1.0/libusb.h>


int main(void)
{
	libusb_set_debug(NULL, 255);
	return 0;
}
