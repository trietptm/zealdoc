#include "priv.h"

static void i2dw(int value, unsigned char buffer[])
{
	buffer[0] = value & 0xFF;
	buffer[1] = (value >> 8) & 0xFF;
	buffer[2] = (value >> 16) & 0xFF;
	buffer[3] = (value >> 24) & 0xFF;
}

static void ccid_build_common(int bSlot, int bSeq, int type)
{
	output[0] = type;
	output[1] = 0x00;
	output[2] = 0x00;
	output[3] = 0x00;
	output[4] = 0x00;
	output[5] = bSlot;
	output[6] = bSeq;
	output[7] = 0x00;
	output[8] = 0x00;
	output[9] = 0x00;	
}

void ccid_build_PowerOn(int bSlot, int bSeq)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_ICCPOWERON);
	output[7] = 0x01;	/* v=5V */
	return;
}

void ccid_build_PowerOff(int bSlot, int bSeq)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_ICCPOWEROFF);
	return;
}

void ccid_build_GetSlotStatus(int bSlot, int bSeq)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_GETSLOTSTATUS);
	return;
}

void ccid_build_SetParameters(int bSlot, int bSeq, int proto, u8 *data, int len)
{
	if (len + 10 > MAX_BUFFER_LEN) {
		printf("err length\r\n");
		return;
	}

	ccid_build_common(bSlot, bSeq, PC_TO_RDR_SETPARAMETERS);
	i2dw(len, output + 1);
	output[7] = proto;
	/* apdu */
	memcpy(output + 10, data, len);
}

void ccid_build_GetParameters(int bSlot, int bSeq)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_GETPARAMETERS);
	return;
}

void ccid_build_ResetParameters(int bSlot, int bSeq)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_RESETPARAMETERS);
	return;
}

void ccid_build_Abort(int bSlot, int bSeq)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_ABORT);
	return;
}
