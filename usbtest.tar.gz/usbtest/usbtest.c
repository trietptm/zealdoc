#include "priv.h"
#include "cunit.h"

/* smartcard reader handle */
usb_dev_handle *g_dev = NULL; 

#define EP_IN 	0x84
#define EP_OUT 	0x05

char output[MAX_BUFFER_LEN];
char input[MAX_BUFFER_LEN];

int gSeq = 0;

#define DEF_SLOT	0
#define DEF_INTFC	0
#define DEF_TO		50


/* init usb bus and get set g_dev handle */
int get_usb_dev(void) 
{
	struct usb_bus *bus; 
	struct usb_device *dev; 
	usb_dev_handle *udev; 

	usb_init(); 
	usb_find_busses(); 
	usb_find_devices(); 
	usb_set_debug(255);

	for (bus = usb_busses; bus; bus = bus->next) { 
		for (dev = bus->devices; dev; dev = dev->next) { 
			udev = usb_open(dev);
			if (udev) {
				if (is_needed(dev)) {

#if 0
					if (usb_set_configuration(udev, 1) < 0) {
						printf("set_config err\r\n");
						usb_close(udev);
						break;
					}

					if (usb_set_altinterface(udev, 0) < 0) {
						printf("altset err\r\n");
						usb_close(udev);
						break;
					}

#endif
					if (usb_claim_interface(udev, DEF_INTFC) < 0) {
						printf("claim err\r\n");
						usb_close(udev);
						break;
					}
					printf("claim 1\r\n");
					if (usb_claim_interface(udev, DEF_INTFC) < 0) {
						printf("claim err\r\n");
						usb_close(udev);
						break;
					}
					printf("claim 2\r\n");
					g_dev = udev;
					break;
				}
				usb_close(udev);
			}
		}
	}
	/* found */
	if (g_dev)
		return 1;
	return 0;
}

/* t = 1 is receive */
void print_bin2hex(u8 *tmp_bin, int len, int t)
{
	int i;
	char buff[128];

	if (len > MAX_BUFFER_LEN) {
		printf("default output len is too samll, len=%d\r\n", len);
		return;
	}
	memset(buff, 0x00, sizeof (buff));

	for (i = 0; i < len; i++)
		sprintf(buff + 3 * i, "%02x ", tmp_bin[i]);
	if (t == 1)
		printf("\r\n<<< ");
	else
		printf("\r\n>>> ");
	printf("%s\n", buff);
}

/* bulk */
int test_snd_recv(u8 *snd, int sl, u8 *rcv, int rl, int print)
{
	int ret, ag = 0;

	ret = usb_bulk_write(g_dev, EP_OUT, snd, sl, DEF_TO);

	if (ret < 0) {
		//printf("\r\nusb_bulk_write fail, err=%s\r\n", strerror(errno));
		goto err;
	}
	if (print)
		print_bin2hex(snd, ret, 0);

again:
	ret = usb_bulk_read(g_dev, EP_IN, rcv, rl, DEF_TO);
	if (ret < 0) {
		if (ag == 0) {
			//printf("\r\nusb_bulk_read fail, err=%s\r\n", strerror(errno));
			goto err;
		}
	} else {
		if (print)
			print_bin2hex(rcv, ret, 1);
		ag = 1;
		goto again;
	}
	return 1;
err:
	return 0;
}

/* control */
int test_control_msg(int reqType, int req, int value, int intfc)
{
	int ret;
	/* snd & rcv */
	print_bin2hex(output, 10, 0);
	ret = usb_control_msg(g_dev, reqType, req, 
			      0/* value */, intfc, output, sizeof (output), DEF_TO);
	
	if (ret < 0) {
		printf("\r\nctrl msg err\r\n");
		return 0;
	}
	print_bin2hex(output, ret, 1);
	return 1;
}

int do_PowerOff(void)
{
	ccid_build_PowerOff(DEF_SLOT, gSeq++);
	printf("PowerOff:\r\n");
	return test_snd_recv(output, 10, input, sizeof (input), 1);
}

int do_PowerOn(void)
{
	ccid_build_PowerOn(DEF_SLOT, gSeq++);
	printf("PowerOn:\r\n");

	return test_snd_recv(output, 10, input, sizeof (input), 1);
}

int do_GetSlotStatus(void)
{
	ccid_build_GetSlotStatus(DEF_SLOT, gSeq++);
	printf("GetSlotStatus:\r\n");

	return test_snd_recv(output, 10, input, sizeof (input), 1);
}

int do_GetParameters(void)
{
	ccid_build_GetParameters(DEF_SLOT, gSeq++);
	printf("GetParameters:\r\n");

	return test_snd_recv(output, 10, input, sizeof (input), 1);
}
int do_ResetParameters(void)
{
	ccid_build_GetParameters(DEF_SLOT, gSeq++);
	printf("ResetParameters:\r\n");
	return test_snd_recv(output, 10, input, sizeof (input), 1);
}

int do_Abort(int type, int seq)
{
	/* abort last sent */
	ccid_build_Abort(DEF_SLOT, seq);
	printf("Abort(%s):\r\n", type ? "control" : "bulk-out");
	if (type) {
		uint16_t wValue;
		wValue = seq << 8;
		wValue |= DEF_SLOT;
		return test_control_msg(CCID_REQ_TYPE_ABORT, CCID_REQ_ABORT, wValue, 0);
	} else
		return test_snd_recv(output, 10, input, sizeof (input), 1);
}

int warm_up(void)
{
	int i = 3;
	while (i--) {
		ccid_build_GetSlotStatus(0, gSeq++);

		if (test_snd_recv(output, 10, input, sizeof (input), 0)) {
			return 1;
		}
	}

	return 0;
}

int test_cmd(void)
{
	do_PowerOn();
	do_PowerOn();
	do_Abort(1, gSeq);
	do_Abort(0, gSeq);
	//do_Abort(0, --gSeq);
	//do_GetSlotStatus();
	return 0;
}

/* get interested device and warm it up */
void CUNITCBK init_case(void)
{
	CUNIT_ASSERT_RET_TRUE(get_usb_dev);
	CUNIT_ASSERT_RET_TRUE(warm_up);
}

CUNIT_BEGIN_SUITE(init)
	CUNIT_INCLUDE_CASE(init_case)
CUNIT_END_SUITE

int main(void)
{
	CUNIT_RUN_SUITE(init);

	if (g_dev) {
		test_cmd();
		usb_release_interface(g_dev, 0);
		usb_close(g_dev);
		g_dev = NULL;
	}
	return 0;
}
