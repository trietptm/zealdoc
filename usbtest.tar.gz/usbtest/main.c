#include <libusb-1.0/libusb.h>
#include <stdlib.h>
#include <stdio.h>

libusb_context *g_ctx = NULL;
libusb_device **g_devs = NULL;

void cleanup(void)
{
	if (g_devs)
		libusb_free_device_list(g_devs, 0);
	if (g_ctx)
		libusb_exit(g_ctx);
}
int main_init(void)
{
	atexit(cleanup);

	libusb_init(&g_ctx);
	if (g_ctx)
		libusb_set_debug(g_ctx, 255);
}

int get_interest_dev(void)
{
	struct libusb_device_descriptor desc;
	int i, cnt, found = 0;

	cnt = libusb_get_device_list(g_ctx, &g_devs);
	if (cnt <= 0)
		return 0;

	for (i = 0; i < cnt; i++) {
		int config, j, k;

		libusb_get_device_descriptor(g_devs[i], &desc);
		config = desc.bNumConfigurations;
		printf("dev[%d], config=%d\r\n", i, config);

		for (j = 0; j < config; j++) {
			struct libusb_config_descriptor *c_desc = NULL;

			libusb_get_config_descriptor(g_devs[i], j, &c_desc);
			if (c_desc) {
				for (k = 0; k < c_desc->bNumInterfaces; k++) {
					struct libusb_interface *intfc = c_desc->interface;
					int num_alt;
					int a;

					intfc += k;
					num_alt = intfc->num_altsetting;
					for (a = 0; a < num_alt; a++) {
						if (intfc->altsetting->bInterfaceClass == 0x0b) {
							printf("got it, dev=%d, config=%d, intfc=%d\r\n",
									i, j, k);
							found = 1;
							goto out;
						}
					}

					
				}
				
			}
		
		}

	}
out:
	if (found) {
		;
	}
}

int main(void)
{
	main_init();
	get_interest_dev();
}
