/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2003
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@hzcnc.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)cuint_int.h: cunit internal interface
 * $Id: cunit_int.h,v 1.1 2009-03-31 09:30:55 zengjie Exp $
 */

#ifndef __CUNIT_INT_H_INCLUDE__
#define __CUNIT_INT_H_INCLUDE__

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <cunit.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>
#include <sys/timeb.h>

#define CUNIT_DEFAULT_FAILURE		128
#define CUNIT_DEFAULT_ERROR		128
#define CUNIT_DEFAULT_LISTENER		1
#define CUNIT_DEFAULT_TESTS		200
#define CUNIT_VECTOR_INCREMENT		64

#define CUNIT_FATAL_ERROR		127
#define CUNIT_UNCAUGHT_EXCEPTION	128

#define CUNIT_MAXIMUM_ROOTS		50

/*
 * This is a non-nesting use of setjmp/longjmp used solely for the purpose
 * of exiting the test runner in a clean way. By separating it out from
 * the exception mechanism above, we don't need to worry about whether or
 * not we are throwing an exception or exiting the runner in an
 * CUNIT_CATCH block.
 */
#define CUNIT_START						\
	{							\
		jmp_buf __env__;				\
		cunit_set_runner_scope(&(__env__));		\
		if (setjmp(__env__) == 0) {

#define CUNIT_EXIT(__code__)					\
		cunit_set_exit_code(__code__);			\
		longjmp(*((jmp_buf*)cunit_get_runner_scope()),1)

#define CUNIT_FINISH(__code__)					\
		} else {					\
			int __code__ = cunit_get_exit_code();

#define CUNIT_END_FINISH					\
		}						\
	}

typedef void *cunit_object_t;
typedef struct _cunit_vector_t *Vector;
typedef struct _cunit_listener_t *TestListener;
typedef struct _cunit_printer_t *ResultPrinter;

typedef TestResult (CUNITCBK *TestMain)(TestRunner, Test);

/* error or failure collector */
typedef void (CUNITCBK *ResultCollector)(TestListener, Test, Throwable);
typedef void (CUNITCBK *TestStart)(TestListener, Test);
typedef void (CUNITCBK *TestEnd)(TestListener, Test);

typedef int (*CaseCounter)(IN Test);
typedef void (*CaseRunner)(IN Test, IN TestResult);
typedef void (*CaseDestroyer)(IN Test);

/*=========================================================================
 * Data structure definitions
 *=======================================================================*/
typedef struct _cunit_vector_t {
	cunit_object_t *objects;
	int size;
	int coount;
} cunit_vector_t;

typedef union _cunit_cell_t {
	cell cell;
	cell *pointer;
} cunit_cell_t;

typedef struct _cunit_throwable_t {
	int type;
	char *message;
	int line;
	char *file;
} cunit_throwable_t;

typedef struct _cunit_runner_t {
	TestMain main;
	//TestResult result;
} cunit_runner_t;

typedef struct _cunit_listener_t {
	/* error occurred. */
	ResultCollector add_error;
	/* failure occurred. */
	ResultCollector add_failure;  
	/* test started flag */
	TestStart start_test;
	/* test ended flag */
	TestEnd end_test; 
} cunit_listener_t;

typedef struct _cunit_result_t {
	/* failure collector */
	Throwable *failures;
	int failure_count;
	int failure_size;
	
	/* error collector */
	Throwable *errors;
	int error_count;
	int error_size;
	
	/* registered listeners */
	TestListener *listeners;
	int listener_count;
	int listener_size;
	
	/* run tests */
	int runs;
	/* succeeded test count */
	int success_count;
	/* run seconds */
	double run_seconds;
	/* milli-seconds precision */
	unsigned short run_millitm;
	
	/* runner stopped */
	int stop;
} cunit_result_t;

typedef struct _cunit_test_t {
	/* test name */
	char *name;
	/* test counter */
	CaseCounter counter;
	/* test runner */
	CaseRunner runner;
	/* test destroyer */
	CaseDestroyer destroyer;
} cunit_test_t;

typedef struct _cunit_suite_t {
	/* invisible super class */
	cunit_test_t;
	
	/* test vector */
	Test *tests;
	int count;
	int size;
} cunit_suite_t;

typedef struct _cunit_case_t {
	/* invisible super class */
	cunit_test_t;
	
	/* case caller */
	TestCall call;
	/* bare test setUp */
	TestCall set_up;
	/* bare test tearDown */
	TestCall tear_down;
} cunit_case_t;

CUNITEXT Throwable cunit_new_throwable(CUNIT_SOURCE_LINE_DECL,
                                       IN int type,
				       IN const char *message);

CUNITEXT char *cunit_format_message(IN char *message, IN int size,
				    IN const char *format, ...);
CUNITEXT char *cunit_format_messagev(IN char *message, IN int size,
                                     IN const char *format,
				     IN va_list pvar);
CUNITEXT void cunit_output_message(IN const char *format, ...);
CUNITEXT void cunit_output_messagev(IN const char *oformat,
				    IN va_list pvar);
CUNITEXT void cunit_set_runner_scope(IN void *env);

CUNITEXT void *cunit_get_runner_scope();
CUNITEXT void cunit_set_exit_code(IN int code);
CUNITEXT int cunit_get_exit_code();

CUNITEXT TestResult cunit_new_result();
CUNITEXT int cunit_should_stop(TestResult result);
CUNITEXT void cunit_add_failure(IN TestResult result,
				IN Test test,
				IN Throwable failure);
CUNITEXT void cunit_add_error(IN TestResult result,
			      IN Test test,
			      IN Throwable error);
CUNITEXT void cunit_delete_result(IN TestResult result);
CUNITEXT void cunit_start_test(IN TestResult result,
			       IN Test test);
CUNITEXT void cunit_end_test(IN TestResult result,
			     IN Test test);
CUNITEXT void cunit_register_listener(IN TestResult result,
				      IN TestListener listener);

CUNITEXT void cunit_run_suite(TestSuite suite, TestResult result);
CUNITEXT void cunit_delete_suite(IN TestSuite suite);
CUNITEXT int cunit_count_suite(TestSuite suite);

CUNITEXT int cunit_count_cases(IN TestCase caze);
CUNITEXT void cunit_delete_case(IN TestCase caze);
CUNITEXT void cunit_run_case(IN TestCase caze, IN TestResult result);

extern TestRunner _default_runner;
extern ThrowableScope _throwable_scope;

#endif /* __CUNIT_CASE_H_INCLUDE__ */
