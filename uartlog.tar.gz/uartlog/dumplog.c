#include "dumplog.h"

#ifdef _CONSOLE
#define dumper	ConsoleDump
#else
#define dumper	WindowsDump
#endif

#define UART_LOG_SIZE		3
#define RAW_BYTES_PER_LINE	32

LPBYTE g_pszRawBuf = NULL;
DWORD g_dwRawSize = 0;
DWORD g_dwRawStored = 0;

BYTE g_szCmdBuf[UART_LOG_SIZE];
DWORD g_szCmdStored;

typedef struct _UARTLogString {
	const char *name;
	int id;
} UARTLogString;

typedef struct _UARTLogEvent {
	UARTLogString *table;
	int id;
} UARTLogEvent;

typedef struct _UARTLogEntry {
	BYTE type;
	DWORD flags;
#define UART_LOG_RAW_DETAILS	0x01
	VOID (*DumpFunc)(VOID *ctx, BYTE cmd, BYTE ch);
} UARTLogEntry;

static BOOL DumpLog(VOID *ctx, LPCBYTE pszLog);
static VOID StoreRaw(CONST BYTE *szNew, DWORD dwToStore);

static VOID USBDumpIntr(VOID *ctx, BYTE cmd, BYTE ch);
static VOID USBDumpEvent(VOID *ctx, BYTE cmd, BYTE ch);
static VOID USBDumpState(VOID *ctx, BYTE cmd, BYTE ch);
static VOID USBDumpEPEvent(VOID *ctx, BYTE cmd, BYTE ch);
static VOID USBDumpEPStage(VOID *ctx, BYTE cmd, BYTE ch);
static VOID USBDumpEPStatus(VOID *ctx, BYTE cmd, BYTE ch);
static VOID USBDumpSTReq(VOID *ctx, BYTE cmd, BYTE ch);
static VOID USBDumpIFReq(VOID *ctx, BYTE cmd, BYTE ch);
static VOID USBDumpEPReq(VOID *ctx, BYTE cmd, BYTE ch);
static VOID USBDumpDesc(VOID *ctx, BYTE cmd, BYTE ch);
static VOID USBDumpClass(VOID *ctx, BYTE cmd, BYTE ch);
static VOID USBDumpEndp(VOID *ctx, BYTE cmd, BYTE ch);
static VOID USBDumpIntf(VOID *ctx, BYTE cmd, BYTE ch);

static VOID SYSDumpInit(VOID *ctx, BYTE cmd, BYTE ch);
static VOID SYSDumpPanic(VOID *ctx, BYTE cmd, BYTE ch);

static VOID KBDDumpDown(VOID *ctx, BYTE cmd, BYTE ch);
static VOID KBDDumpUp(VOID *ctx, BYTE cmd, BYTE ch);

static VOID LCDDumpEvent(VOID *ctx, BYTE cmd, BYTE ch);
static VOID LCDDumpState(VOID *ctx, BYTE cmd, BYTE ch);
static VOID LCDDumpQueue(VOID *ctx, BYTE cmd, BYTE ch);
static VOID LCDDumpIdle(VOID *ctx, BYTE cmd, BYTE ch);
static VOID LCDDumpInit(VOID *ctx, BYTE cmd, BYTE ch);

static VOID SCSDumpIntr(VOID *ctx, BYTE cmd, BYTE ch);
static VOID SCSDumpSlotEvent(VOID *ctx, BYTE cmd, BYTE ch);
static VOID SCSDumpSlotState(VOID *ctx, BYTE cmd, BYTE ch);
static VOID SCSDumpUARTEvent(VOID *ctx, BYTE cmd, BYTE ch);
static VOID SCSDumpATRStage(VOID *ctx, BYTE cmd, BYTE ch);

static VOID HIDDumpSTReq(VOID *ctx, BYTE cmd, BYTE ch);
static VOID HIDDumpCSReq(VOID *ctx, BYTE cmd, BYTE ch);
static VOID HIDDumpDesc(VOID *ctx, BYTE cmd, BYTE ch);
static VOID HIDDumpEndp(VOID *ctx, BYTE cmd, BYTE ch);
static VOID HIDDumpReport(VOID *ctx, BYTE cmd, BYTE ch);

static VOID CCIDDumpSTReq(VOID *ctx, BYTE cmd, BYTE ch);
static VOID CCIDDumpCSReq(VOID *ctx, BYTE cmd, BYTE ch);
static VOID CCIDDumpDesc(VOID *ctx, BYTE cmd, BYTE ch);
static VOID CCIDDumpEndp(VOID *ctx, BYTE cmd, BYTE ch);
static VOID CCIDDumpSlot(VOID *ctx, BYTE cmd, BYTE ch);
static VOID CCIDDumpIntr(VOID *ctx, BYTE cmd, BYTE ch);
static VOID CCIDDumpState(VOID *ctx, BYTE cmd, BYTE ch);
static VOID CCIDDumpPC2RDR(VOID *ctx, BYTE cmd, BYTE ch);

UARTLogString LogTaskNames[] = {
	{ "timer", TIMER_TASK_PID },
	{ "wdt", WDT_TASK_PID },
	{ "uart", UART_TASK_PID },
	{ "scib", SCIB_TASK_PID },
	{ "ccid", CCID_TASK_PID },
	{ "hid", HID_TASK_PID },
	{ "usb", USB_TASK_PID },
	{ "lcd", LCD_TASK_PID },
	{ "kbd", KBD_TASK_PID },
	{ "test", TEST_TASK_PID },
	{ "main", MAIN_TASK_PID },
	{ "raw", RAW_TASK_PID },
	{ NULL, 0 },
};

UARTLogString LogKbdEvents[] = {
	{ "DOWN", KBD_DEBUG_DOWN },
	{ "UP", KBD_DEBUG_UP },
	{ NULL, 0 },
};

UARTLogString LogLcdEvents[] = {
	{ "EVENT", LCD_DEBUG_EVENT },
	{ "QUEUE", LCD_DEBUG_QUEUE },
	{ "STATE", LCD_DEBUG_STATE },
	{ "IDLE", LCD_DEBUG_IDLE },
	{ "INIT", LCD_DEBUG_INIT },
	{ NULL, 0 },
};

UARTLogString LogUsbEvents[] = {
	{ "INTR", USB_DEBUG_INTR },
	{ "EVENT", USB_DEBUG_EVENT },
	{ "STATE", USB_DEBUG_STATE },
	{ "EVENT", USB_DEBUG_EP_EVENT },
	{ "STAGE", USB_DEBUG_EP_STAGE },
	{ "STATE", USB_DEBUG_EP_STATUS },
	{ "STCTRL", USB_DEBUG_ST_REQ },
	{ "IFCTRL", USB_DEBUG_IF_REQ },
	{ "EPCTRL", USB_DEBUG_EP_REQ },
	{ "DESC", USB_DEBUG_DESC },
	{ "CLASS", USB_DEBUG_CLASS },
	{ "ENDP", USB_DEBUG_ENDP },
	{ "INTF", USB_DEBUG_INTF },
	{ NULL, 0 },
};

UARTLogString LogHidEvents[] = {
	{ "STREQ", HID_DEBUG_ST_REQ },
	{ "CSREQ", HID_DEBUG_CS_REQ },
	{ "DESC", HID_DEBUG_DESC },
	{ "ENDP", HID_DEBUG_ENDP },
	{ "REPORT", HID_DEBUG_REPORT },
	{ NULL, 0 },
};

UARTLogString LogCcidEvents[] = {
	{ "STREQ", CCID_DEBUG_ST_REQ },
	{ "CSREQ", CCID_DEBUG_CS_REQ },
	{ "PC2RDR", CCID_DEBUG_PC2RDR },
	{ "DESC", CCID_DEBUG_DESC },
	{ "ENDP", CCID_DEBUG_ENDP },
	{ "SLOT", CCID_DEBUG_SLOT },
	{ "INTR", CCID_DEBUG_INTR },
	{ "STATE", CCID_DEBUG_STATE },
	{ NULL, 0 },
};

UARTLogString LogMainEvents[] = {
	{ "INIT", MAIN_DEBUG_INIT },
	{ "PANIC", MAIN_DEBUG_PANIC },
	{ NULL, 0 },
};

UARTLogString LogRawEvents[] = {
	{ "DATA", RAW_EVENT_DATA },
	{ "ERROR", RAW_EVENT_ERROR },
	{ NULL, 0 },
};

UARTLogString LogScsEvents[] = {
	{ "INTR", SCS_DEBUG_INTR },
	{ "EVENT", SCS_DEBUG_SLOT_EVENT },
	{ "STATE", SCS_DEBUG_SLOT_STATE },
	{ "UART", SCS_DEBUG_UART_EVENT },
	{ "ATR", SCS_DEBUG_ATR_STAGE},
	{ NULL, 0 },
};

UARTLogEvent LogEventNames[] = {
	{ LogLcdEvents, LCD_TASK_PID },
	{ LogKbdEvents, KBD_TASK_PID },
	{ LogHidEvents, HID_TASK_PID },
	{ LogCcidEvents, CCID_TASK_PID },
	{ LogUsbEvents, USB_TASK_PID },
	{ LogScsEvents, SCIB_TASK_PID },
	{ LogMainEvents, MAIN_TASK_PID },
	{ LogRawEvents, RAW_TASK_PID },
	{ NULL, 0 },
};

UARTLogEntry LogDumpers[] = {
	{ USB_DEBUG_INTR, 0, USBDumpIntr, },
	{ USB_DEBUG_EVENT, 0, USBDumpEvent, },
	{ USB_DEBUG_STATE, 0, USBDumpState, },
	{ USB_DEBUG_EP_EVENT, 0, USBDumpEPEvent, },
	{ USB_DEBUG_EP_STAGE, 0, USBDumpEPStage, },
	{ USB_DEBUG_EP_STATUS, 0, USBDumpEPStatus, },
	{ USB_DEBUG_ST_REQ, 0, USBDumpSTReq, },
	{ USB_DEBUG_IF_REQ, 0, USBDumpIFReq, },
	{ USB_DEBUG_EP_REQ, 0, USBDumpEPReq, },
	{ USB_DEBUG_DESC, 0, USBDumpDesc, },
	{ USB_DEBUG_CLASS, 0, USBDumpClass, },
	{ USB_DEBUG_ENDP, 0, USBDumpEndp, },
	{ USB_DEBUG_INTF, 0, USBDumpIntf, },

	{ LCD_DEBUG_EVENT, 0, LCDDumpEvent,},
	{ LCD_DEBUG_QUEUE, 0, LCDDumpQueue,},
	{ LCD_DEBUG_STATE, 0, LCDDumpState,},
	{ LCD_DEBUG_IDLE, 0, LCDDumpIdle,},
	{ LCD_DEBUG_INIT, 0, LCDDumpInit,},

	{ CCID_DEBUG_ST_REQ, 0, CCIDDumpSTReq,},
	{ CCID_DEBUG_CS_REQ, 0, CCIDDumpCSReq,},
	{ CCID_DEBUG_PC2RDR, 0, CCIDDumpPC2RDR,},
	{ CCID_DEBUG_DESC, 0, CCIDDumpDesc,},
	{ CCID_DEBUG_ENDP, 0, CCIDDumpEndp,},
	{ CCID_DEBUG_SLOT, 0, CCIDDumpSlot,},
	{ CCID_DEBUG_INTR, 0, CCIDDumpIntr,},
	{ CCID_DEBUG_STATE, 0, CCIDDumpState,},

	{ HID_DEBUG_ST_REQ, 0, HIDDumpSTReq,},
	{ HID_DEBUG_CS_REQ, 0, HIDDumpCSReq,},
	{ HID_DEBUG_DESC, 0, HIDDumpDesc,},
	{ HID_DEBUG_ENDP, 0, HIDDumpEndp,},
	{ HID_DEBUG_REPORT, 0, HIDDumpReport,},

	{ KBD_DEBUG_DOWN, 0, KBDDumpDown,},
	{ KBD_DEBUG_UP, 0, KBDDumpUp,},

	{ SCS_DEBUG_INTR, 0, SCSDumpIntr,},
	{ SCS_DEBUG_SLOT_EVENT, 0, SCSDumpSlotEvent,},
	{ SCS_DEBUG_SLOT_STATE, 0, SCSDumpSlotState,},
	{ SCS_DEBUG_UART_EVENT, 0, SCSDumpUARTEvent,},
	{ SCS_DEBUG_ATR_STAGE, 0, SCSDumpATRStage,},

	{ MAIN_DEBUG_INIT, 0, SYSDumpInit, },
	{ MAIN_DEBUG_PANIC, UART_LOG_RAW_DETAILS, SYSDumpPanic, },

	{ 0, 0, NULL, },
};

#define strcasecmp	_stricmp

int name2int(const UARTLogString *table, LPCSTR name, int def)
{
	const UARTLogString *pMap;

	for (pMap = table; name && pMap->name != NULL; pMap++) {
		if (strcasecmp(pMap->name, name) == 0) {
			return pMap->id;
		}
	}
	return def;
}

/* convert an integer to a string */
const char *int2name(const UARTLogString *table, int id,
		     LPCSTR def)
{
	const UARTLogString *pMap;

	for (pMap = table; pMap->name != NULL; pMap++) {
		if (pMap->id == id) {
			return pMap->name;
		}
	}
	return def;
}

static VOID DumpRaw(VOID *ctx)
{
	CHAR szBuf[RAW_BYTES_PER_LINE * 3 + 1];
	DWORD dwIter = 0;

	while (g_dwRawStored) {
		memset(szBuf, 0, sizeof (szBuf));
		for (dwIter = 0;
		     g_dwRawStored && dwIter < RAW_BYTES_PER_LINE; dwIter++) {
			sprintf(szBuf + (dwIter * 3), "%02x ", g_pszRawBuf[0]);
			g_dwRawStored--;
			memmove(g_pszRawBuf, g_pszRawBuf+1, g_dwRawStored);
		}
		dumper(ctx, (RAW_TASK_PID<<4 | RAW_EVENT_DATA), "%s", szBuf);
	}
}

VOID CleanupLog(VOID)
{
	if (g_pszRawBuf)
		free(g_pszRawBuf);
}

VOID StoreRaw(CONST BYTE *szNew, DWORD dwToStore)
{
	BOOL bReady = FALSE;
	DWORD dwTotal = g_dwRawStored+dwToStore;

	if (dwTotal > g_dwRawSize) {
		if (!g_pszRawBuf) {
			g_pszRawBuf = malloc(256);
		} else {
			g_pszRawBuf = realloc(g_pszRawBuf, g_dwRawSize+256);
		}
		if (g_pszRawBuf) {
			bReady = TRUE;
			g_dwRawSize += 256;
		}
	} else {
		bReady = TRUE;
	}

	if (bReady) {
		if (g_pszRawBuf) {
			memcpy(g_pszRawBuf + g_dwRawStored, szNew, dwToStore);
			g_dwRawStored += dwToStore;
		}
	}
}

#define MAKECMD(pid, event)	(pid<<4 | event)

static VOID SYSDumpInit(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0:
		dumper(ctx, cmd, "powered");
		break;
	case 1:
		dumper(ctx, cmd, "module intialized");
		break;
	case 2:
		dumper(ctx, cmd, "IRQ enabled");
		break;
	default:
		dumper(ctx, cmd, "flavour");
		break;
	}
}

static VOID SYSDumpPanic(VOID *ctx, BYTE cmd, BYTE ch)
{
	LPSTR pszFile = NULL;
	DWORD nLine = 0;

	BYTE p = (ch & 0xF0) >> 4;
	switch (p) {
	case 0:
		dumper(ctx, cmd, "panic occurs at:");
		break;
	case 1:
		pszFile = malloc(g_dwRawStored+1);
		if (pszFile) {
			memcpy(pszFile, g_pszRawBuf, g_dwRawStored);
			pszFile[g_dwRawStored] = 0;
			dumper(ctx, cmd, "file: %s", pszFile);
			g_dwRawStored = 0;
			free(pszFile);
		}
		break;
	case 2:
		if (g_dwRawStored > 2) {
			DumpRaw(ctx);
		} else {
			nLine = g_pszRawBuf[0] + 256 * g_pszRawBuf[1];
			dumper(ctx, cmd, "line: %d", nLine);
			g_dwRawStored = 0;
		}
		break;
	default:
		dumper(ctx, cmd, "flavour");
		break;
	}
}

static VOID USBDumpIntr(VOID *ctx, BYTE cmd, BYTE ch)
{
	BYTE eid = (ch & 0xF0) >> 4;

	switch (ch & 0x0F) {
	case 0:
		dumper(ctx, cmd, "intr=NAKOUT, eid=%d", eid);
		break;
	case 1:
		dumper(ctx, cmd, "intr=NAKIN, eid=%d", eid);
		break;
	case 2:
		dumper(ctx, cmd, "intr=RXOUTB0, eid=%d", eid);
		break;
	case 3:
		dumper(ctx, cmd, "intr=TXCMPL, eid=%d", eid);
		break;
	case 4:
		dumper(ctx, cmd, "intr=STLCRC, eid=%d", eid);
		break;
	case 5:
		dumper(ctx, cmd, "intr=RXOUTB1, eid=%d", eid);
		break;
	case 6:
		dumper(ctx, cmd, "intr=RXSETUP, eid=%d", eid);
		break;
	case 7:
		dumper(ctx, cmd, "intr=EOR");
		break;
	case 8:
		dumper(ctx, cmd, "intr=WAKECPU");
		break;
	case 9:
		dumper(ctx, cmd, "intr=SUSPEND");
		break;
	default:
		dumper(ctx, cmd, "intr=%02x", ch & 0x0F);
		break;
	}
}

static VOID USBDumpEvent(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0:
		dumper(ctx, cmd, "event=HUB_DECONF");
		break;
	case 1:
		dumper(ctx, cmd, "event=HUB_CONF");
		printf("%d",ch);
		break;
	case 2:
		dumper(ctx, cmd, "event=POWER_INTR");
		break;
	case 3:
		dumper(ctx, cmd, "event=POWER_RESET");
		break;
	case 4:
		dumper(ctx, cmd, "event=BUS_INACTIVE");
		break;
	case 5:
		dumper(ctx, cmd, "event=BUS_ACTIVE");
		break;
	case 6:
		dumper(ctx, cmd, "event=ADDR_ASSIGN");
		break;
	case 7:
		dumper(ctx, cmd, "event=DEV_CONF");
		break;
	case 8:
		dumper(ctx, cmd, "event=DEV_DECONF");
		break;
	case 9:
		dumper(ctx, cmd, "event=ENDPOINT");
		break;
	default:
		dumper(ctx, cmd, "event=%02x", ch);
		break;
	}
}

static VOID USBDumpState(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0:
		dumper(ctx, cmd, "state=INIT");
		break;
	case 1:
		dumper(ctx, cmd, "state=ATTACHED");
		break;
	case 2:
		dumper(ctx, cmd, "state=POWERED");
		break;
	case 3:
		dumper(ctx, cmd, "state=DEFAULT");
		break;
	case 4:
		dumper(ctx, cmd, "state=ADDRESS");
		break;
	case 5:
		dumper(ctx, cmd, "state=CONFIGURED");
		break;
	case 6:
		dumper(ctx, cmd, "state=SUSPENDED");
		break;
	default:
		dumper(ctx, cmd, "state=%02x", ch);
		break;
	}
}

static VOID USBDumpEPStatus(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0:
		dumper(ctx, cmd, "status=NONE");
		break;
	case 1:
		dumper(ctx, cmd, "status=ZLP");
		break;
	case 2:
		dumper(ctx, cmd, "status=STALL");
		break;
	default:
		dumper(ctx, cmd, "status=%02x", ch);
		break;
	}
}

static VOID USBDumpEPEvent(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0:
		dumper(ctx, cmd, "event=READ_BEGIN");
		break;
	case 1:
		dumper(ctx, cmd, "event=READ_END");
		break;
	case 2:
		dumper(ctx, cmd, "event=WRITE_BEGIN");
		break;
	case 3:
		dumper(ctx, cmd, "event=CTRL_SETUP");
		break;
	default:
		dumper(ctx, cmd, "event=%02x", ch);
		break;
	}
}

static VOID USBDumpEPStage(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0:
		dumper(ctx, cmd, "state=SETUP");
		break;
	case 1:
		dumper(ctx, cmd, "state=DATA");
		break;
	case 2:
		dumper(ctx, cmd, "state=STATUS");
		break;
	case 3:
		dumper(ctx, cmd, "state=HALT");
		break;
	default:
		dumper(ctx, cmd, "state=%02x", ch);
		break;
	}
}

static VOID USBDumpSTReq(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x00:
		dumper(ctx, cmd, "req=GET_STATUS");
		break;
	case 0x01:
		dumper(ctx, cmd, "req=CLEAR_FEATURE");
		break;
	case 0x03:
		dumper(ctx, cmd, "req=SET_FEATURE");
		break;
	case 0x05:
		dumper(ctx, cmd, "req=SET_ADDRESS");
		break;
	case 0x06:
		dumper(ctx, cmd, "req=GET_DESCRIPTOR");
		break;
	case 0x07:
		dumper(ctx, cmd, "req=SET_DESCRIPTOR");
		break;
	case 0x08:
		dumper(ctx, cmd, "req=GET_CONFIGURATION");
		break;
	case 0x09:
		dumper(ctx, cmd, "req=SET_CONFIGURATION");
		break;
	case 0x0C:
		dumper(ctx, cmd, "req=SYNCH_FRAME");
		break;
	default:
		dumper(ctx, cmd, "req=%02x", ch);
		break;
	}
}

static VOID USBDumpIFReq(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x00:
		dumper(ctx, cmd, "req=GET_STATUS");
		break;
	case 0x01:
		dumper(ctx, cmd, "req=CLEAR_FEATURE");
		break;
	case 0x03:
		dumper(ctx, cmd, "req=SET_FEATURE");
		break;
	case 0x0A:
		dumper(ctx, cmd, "req=GET_INTERFACE");
		break;
	case 0x0B:
		dumper(ctx, cmd, "req=SET_INTERFACE");
		break;
	default:
		dumper(ctx, cmd, "req=%02x", ch);
		break;
	}
}

static VOID USBDumpEPReq(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x00:
		dumper(ctx, cmd, "req=GET_STATUS");
		break;
	case 0x01:
		dumper(ctx, cmd, "req=CLEAR_FEATURE");
		break;
	case 0x03:
		dumper(ctx, cmd, "req=SET_FEATURE");
		break;
	case 0x0C:
		dumper(ctx, cmd, "req=SYNCH_FRAME");
		break;
	default:
		dumper(ctx, cmd, "req=%02x", ch);
		break;
	}
}

static VOID USBDumpDesc(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x01:
		dumper(ctx, cmd, "desc=DEVICE");
		break;
	case 0x02:
		dumper(ctx, cmd, "desc=CONFIGURATION");
		break;
	case 0x03:
		dumper(ctx, cmd, "desc=STRING");
		break;
	case 0x04:
		dumper(ctx, cmd, "desc=INTERFACE");
		break;
	case 0x05:
		dumper(ctx, cmd, "desc=ENDPOINT");
		break;
	case 0x06:
		dumper(ctx, cmd, "desc=DEVICE_QUALIFIER");
		break;
	case 0x07:
		dumper(ctx, cmd, "desc=OTHER_SPEED_CONFIGURATION");
		break;
	case 0x08:
		dumper(ctx, cmd, "desc=INTERFACE_POWER");
		break;
	default:
		dumper(ctx, cmd, "desc=%02x", ch);
		break;
	}
}

static VOID USBDumpClass(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x03:
		dumper(ctx, cmd, "class=HID");
		break;
	case 0x0B:
		dumper(ctx, cmd, "class=CCID");
		break;
	default:
		dumper(ctx, cmd, "class=%02x", ch);
		break;
	}
}

static VOID USBDumpEndp(VOID *ctx, BYTE cmd, BYTE ch)
{
	dumper(ctx, cmd, "eid=%02x", ch);
}

static VOID USBDumpIntf(VOID *ctx, BYTE cmd, BYTE ch)
{
	dumper(ctx, cmd, "iid=%02x", ch);
}

static VOID HIDDumpSTReq(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x06:
		dumper(ctx, cmd, "req=GET_DESCRIPTOR");
		break;
	case 0x07:
		dumper(ctx, cmd, "req=SET_DESCRIPTOR");
		break;
	default:
		dumper(ctx, cmd, "req=%02x", ch);
		break;
	}
}

static VOID HIDDumpCSReq(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x01:
		dumper(ctx, cmd, "req=GET_REPORT");
		break;
	case 0x02:
		dumper(ctx, cmd, "req=GET_IDLE");
		break;
	case 0x03:
		dumper(ctx, cmd, "req=GET_PROTOCOL");
		break;
	case 0x09:
		dumper(ctx, cmd, "req=SET_REPORT");
		break;
	case 0x0A:
		dumper(ctx, cmd, "req=SET_IDLE");
		break;
	case 0x0B:
		dumper(ctx, cmd, "req=SET_PROTOCOL");
		break;
	default:
		dumper(ctx, cmd, "req=%02x", ch);
		break;
	}
}

static VOID HIDDumpDesc(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x02:
		dumper(ctx, cmd, "desc=CONFIGURATION");
		break;
	case 0x21:
		dumper(ctx, cmd, "desc=HID");
		break;
	case 0x22:
		dumper(ctx, cmd, "desc=REPORT");
		break;
	case 0x23:
		dumper(ctx, cmd, "desc=PHYSICAL");
		break;
	default:
		dumper(ctx, cmd, "desc=%02x", ch);
		break;
	}
}

static VOID HIDDumpEndp(VOID *ctx, BYTE cmd, BYTE ch)
{
	dumper(ctx, cmd, "eid=%02x", ch);
}

static VOID HIDDumpReport(VOID *ctx, BYTE cmd, BYTE ch)
{
	dumper(ctx, cmd, "rid=%02x", ch);
}

static VOID CCIDDumpSTReq(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x06:
		dumper(ctx, cmd, "req=GET_DESCRIPTOR");
		break;
	case 0x07:
		dumper(ctx, cmd, "req=SET_DESCRIPTOR");
		break;
	default:
		dumper(ctx, cmd, "req=%02x", ch);
		break;
	}
}

static VOID CCIDDumpCSReq(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x01:
		dumper(ctx, cmd, "req=ABORT");
		break;
	case 0x02:
		dumper(ctx, cmd, "req=GET_CLOCK_FREQUENCIES");
		break;
	case 0x03:
		dumper(ctx, cmd, "req=GET_DATA_RATES");
		break;
	default:
		dumper(ctx, cmd, "req=%02x", ch);
		break;
	}
}

static VOID CCIDDumpDesc(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x02:
		dumper(ctx, cmd, "desc=CONFIGURATION");
		break;
	case 0x21:
		dumper(ctx, cmd, "desc=SCD");
		break;
	default:
		dumper(ctx, cmd, "desc=%02x", ch);
		break;
	}
}

static VOID CCIDDumpEndp(VOID *ctx, BYTE cmd, BYTE ch)
{
	dumper(ctx, cmd, "eid=%02x", ch);
}

static VOID CCIDDumpSlot(VOID *ctx, BYTE cmd, BYTE ch)
{
	dumper(ctx, cmd, "sid=%02x", ch);
}

static VOID CCIDDumpIntr(VOID *ctx, BYTE cmd, BYTE ch)
{
	if (ch & 0x01)
		dumper(ctx, cmd, "intr=NotifySlotChange", ch);
	if (ch & 0x02)
		dumper(ctx, cmd, "intr=HardwareError", ch);
}

static VOID CCIDDumpState(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0:
		dumper(ctx, cmd, "state=PC2RDR", ch);
		break;
	case 1:
		dumper(ctx, cmd, "state=ISO7816", ch);
		break;
	case 2:
		dumper(ctx, cmd, "state=RDR2PC", ch);
		break;
	}
}

static VOID CCIDDumpPC2RDR(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x61:
		dumper(ctx, cmd, "cmd=SetParameters");
		break;
	case 0x62:
		dumper(ctx, cmd, "cmd=IccPowerOn");
		break;
	case 0x63:
		dumper(ctx, cmd, "cmd=IccPowerOff");
		break;
	case 0x65:
		dumper(ctx, cmd, "cmd=GetSlotStatus");
		break;
	case 0x69:
		dumper(ctx, cmd, "cmd=Secure");
		break;
	case 0x6A:
		dumper(ctx, cmd, "cmd=T0APDU");
		break;
	case 0x6B:
		dumper(ctx, cmd, "cmd=Escape");
		break;
	case 0x6C:
		dumper(ctx, cmd, "cmd=GetParameters");
		break;
	case 0x6D:
		dumper(ctx, cmd, "cmd=ResetParameters");
		break;
	case 0x6E:
		dumper(ctx, cmd, "cmd=IccClock");
		break;
	case 0x6F:
		dumper(ctx, cmd, "cmd=XfrBlock");
		break;
	case 0x71:
		dumper(ctx, cmd, "cmd=Mechanical");
		break;
	case 0x72:
		dumper(ctx, cmd, "cmd=Abort");
		break;
	case 0x73:
		dumper(ctx, cmd, "cmd=SetDataRateAndClock");
		break;
	default:
		dumper(ctx, cmd, "cmd=%02x", ch);
		break;
	}
}

static VOID LCDDumpEvent(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case (1 << 0):
		dumper(ctx, cmd, "event=IDLE");
		break;
	case (1 << 1):
		dumper(ctx, cmd, "event=EXEC");
		break;
	case (1 << 2):
		dumper(ctx, cmd, "event=NEXT");
		break;
	case (1 << 3):
		dumper(ctx, cmd, "event=DONE");
		break;
	default:
		dumper(ctx, cmd, "event=%02x", ch);
		break;
	}
}

static VOID LCDDumpState(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 4:
		dumper(ctx, cmd, "state=BUSY");
		break;
	case 5:
		dumper(ctx, cmd, "state=IDLE");
		break;
	case 6:
		dumper(ctx, cmd, "state=EXEC");
		break;
	default:
		dumper(ctx, cmd, "state=%02x", ch);
		break;
	}
}

static VOID LCDDumpQueue(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 4:
		dumper(ctx, cmd, "cmd=DISPLAY_ONOFF");
		break;
	case 5:
		dumper(ctx, cmd, "cmd=SHIFT_RIGHT");
		break;
	case 2:
		dumper(ctx, cmd, "cmd=RETURN_HOME");
		break;
	case 9:
		dumper(ctx, cmd, "cmd=SET_POSITION");
		break;
	case 10:
		dumper(ctx, cmd, "cmd=WRITE_DATA");
		break;
	default:
		dumper(ctx, cmd, "cmd=%02x", ch);
		break;
	}
}

static VOID LCDDumpIdle(VOID *ctx, BYTE cmd, BYTE ch)
{
	dumper(ctx, cmd, "%s", ch ? "idle" : "busy");
}

static VOID LCDDumpInit(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0:
		dumper(ctx, cmd, "stage0, INIT");
		break;
	case 1:
		dumper(ctx, cmd, "stage1, INIT");
		break;
	case 2:
		dumper(ctx, cmd, "stage2, BITS, LINES, FONTS");
		break;
	case 3:
		dumper(ctx, cmd, "stage2, DISPLAY, CURSOR");
		break;
	default:
		dumper(ctx, cmd, "stage=%02x", ch);
		break;
	}
}

static unsigned char bare_num_map[] = {
	0x1B,	0x30,	0x0D,	'+',
	0x31,	0x32,	0x33,	'-',
	0x34,	0x35,	0x36,	'x',
	0x37,	0x38,	0x39,	'%',
};

static VOID KBDDumpDown(VOID *ctx, BYTE cmd, BYTE ch)
{
	dumper(ctx, cmd, "scan=%02x, ascii=%c", ch, bare_num_map[ch]);
}

static VOID KBDDumpUp(VOID *ctx, BYTE cmd, BYTE ch)
{
	dumper(ctx, cmd, "scan=%02x, ascii=%c", ch, bare_num_map[ch]);
}

static VOID SCSDumpIntr(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0x00:
		dumper(ctx, cmd, "intr=SLOT_CHANGE");
		break;
	case 0x01:
		dumper(ctx, cmd, "intr=PARITY_ERR");
		break;
	case 0x02:
		dumper(ctx, cmd, "intr=RCHAR_AVAIL");
		break;
	case 0x03:
		dumper(ctx, cmd, "intr=TCHAR_COMP");
		break;
	case 0x04:
		dumper(ctx, cmd, "intr=WTC_TIMEOUT");
		break;
	case 0x05:
		dumper(ctx, cmd, "intr=TBUF_AVAIL");
		break;
	case 0x06:
		dumper(ctx, cmd, "intr=POWER_ERR");
		break;
	default:
		break;
	}
}

static VOID SCSDumpSlotEvent(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 1:
		dumper(ctx, cmd, "event=SLOT_CHANGE");
		break;
	case 2:
		dumper(ctx, cmd, "event=POWER_ON");
		break;
	case 4:
		dumper(ctx, cmd, "event=POWER_OK");
		break;
	case 8:
		dumper(ctx, cmd, "event=POWER_ERR");
		break;
	case 0x10:
		dumper(ctx, cmd, "event=TIMEOUT");
		break;
	case 0x20:
		dumper(ctx, cmd, "event=ATR_OK");
		break;
	case 0x40:
		dumper(ctx, cmd, "event=ATR_ERR");
		break;
	case 0x80:
		dumper(ctx, cmd, "event=PPS_OK");
		break;
	case 0x100:
		dumper(ctx, cmd, "event=PPS_ERR");
		break;
	case 0x200:
		dumper(ctx, cmd, "event=TRANS_CANCLE");
		break;
	case 0x400:
		dumper(ctx, cmd, "event=TRANS_IDLE");
		break;
	case 0x800:
		dumper(ctx, cmd, "event=TRANS_BUSY");
		break;
	case 0x1000:
		dumper(ctx, cmd, "event=UART_EVENT");
		break;
	default:
		dumper(ctx, cmd, "event=BUG");
		break;
	}
}

static VOID SCSDumpSlotState(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0:
		dumper(ctx, cmd, "state=ICC_NOTPRESENT");
		break;
	case 1:
		dumper(ctx, cmd, "state=ICC_PRESENT");
		break;
	case 2:
		dumper(ctx, cmd, "state=ACTIVATING_VOLTAGE");
		break;
	case 3:
		dumper(ctx, cmd, "state=ACTIVATING_ATR");
		break;
	case 4:
		dumper(ctx, cmd, "state=ACTIVATING_PPS");
		break;
	case 5:
		dumper(ctx, cmd, "state=TRANS_IDLE");
		break;
	case 6:
		dumper(ctx, cmd, "state=TRANS_BUSY");
		break;
	default:
		dumper(ctx, cmd, "state=BUG");
		break;
	}
}

static VOID SCSDumpUARTEvent(VOID *ctx, BYTE cmd, BYTE ch)
{
		switch (ch) {
	case 1:
		dumper(ctx, cmd, "event=PARITY_ERR");
		break;
	case 2:
		dumper(ctx, cmd, "event=RCHAR_AVAIL");
		break;
	case 4:
		dumper(ctx, cmd, "event=TCHAR_COMPLETE");
		break;
	case 8:
		dumper(ctx, cmd, "event=TIMEOUT");
		break;
	case 0x10:
		dumper(ctx, cmd, "event=POWER_ERR");
		break;
	case 0x20:
		dumper(ctx, cmd, "event=TBUF_AVAIL");
		break;
	default:
		dumper(ctx, cmd, "event=BUG");
		break;
	}
}

static VOID SCSDumpATRStage(VOID *ctx, BYTE cmd, BYTE ch)
{
	switch (ch) {
	case 0:
		dumper(ctx, cmd, "stage=STAGE_INIT");
		break;
	case 1:
		dumper(ctx, cmd, "stage=STAGE_START");
		break;
	case 2:
		dumper(ctx, cmd, "stage=STAGE_DONE");
		break;
	default:
		dumper(ctx, cmd, "stage=BUG");
		break;
	}
}

BOOL DumpLog(VOID *ctx, LPCBYTE pszLog)
{
	BYTE bCmd;
	DWORD dwIter;
	BOOL bDumped;

	bCmd = pszLog[0];
	bDumped = FALSE;

	for (dwIter = 0;
	     dwIter < sizeof (LogDumpers) / sizeof (UARTLogEntry);
	     dwIter++) {
			if (LogDumpers[dwIter].DumpFunc &&
			    LogDumpers[dwIter].type == bCmd) {
				if (g_dwRawStored &&
				    !(LogDumpers[dwIter].flags & UART_LOG_RAW_DETAILS))
					DumpRaw(ctx);
			     LogDumpers[dwIter].DumpFunc(ctx, bCmd, pszLog[1]);
			     bDumped = TRUE;
		     }
	}

	return bDumped;
}

VOID ProcessLog(VOID *ctx, DWORD dwRead)
{
	DWORD dwIter;

	g_szCmdStored += dwRead;

	if (g_szCmdStored == UART_LOG_SIZE && (g_szCmdBuf[0] == g_szCmdBuf[2])) {
		if (DumpLog(ctx, g_szCmdBuf)) {
			g_szCmdStored = 0;
			return;
		}
	}
	if (g_szCmdStored) {
		StoreRaw(g_szCmdBuf, 1);
		g_szCmdStored--;
		for (dwIter = 0; dwIter < g_szCmdStored; dwIter++) {
			g_szCmdBuf[dwIter] = g_szCmdBuf[dwIter+1];
		}
	}
}

DWORD LogSpace(VOID)
{
	return UART_LOG_SIZE - g_szCmdStored;
}

BYTE *LogPointer(VOID)
{
	return g_szCmdBuf + g_szCmdStored;
}

VOID StartupLog(VOID)
{
	g_szCmdStored = 0;
}

LPCSTR GetTaskName(BYTE bCmd)
{
	return int2name(LogTaskNames, CMD_TASK_PID(bCmd), "raw");
}

LPCSTR GetEventName(BYTE bCmd)
{
	const UARTLogEvent *pMap;

	for (pMap = LogEventNames; pMap->table != NULL; pMap++) {
		if (pMap->id == CMD_TASK_PID(bCmd)) {
			return int2name(pMap->table, bCmd, "UNDEF");
		}
	}
	return "UNDEF";
}
