#include "dumplog.h"

int g_hComFile = NULL;
DWORD g_dwLastError = 0;

static void DumpError(void)
{
	printf("<raw> ERROR: ");
	printf("%s", strerror(errno));
	printf("\r\n");
}

void cleanup(void)
{
	CleanupLog();
	if (g_hComFile)
		close(g_hComFile);
}

VOID ConsoleDump(VOID *ctx, BYTE bCmd, LPSTR szFormat, ...)
{
	FILE *pFile = (FILE *)ctx;
	va_list argList;
	char szBuf[1024];
	
	va_start(argList, szFormat );
	vsprintf(szBuf, szFormat, argList);
	va_end(argList);

	fprintf(pFile, "<%s> %s: ", GetTaskName(bCmd), GetEventName(bCmd));
	fprintf(pFile, "%s", szBuf);
	fprintf(pFile, "\r\n");
}

int main(int argc, char **argv)
{
	DCB dcb;

	atexit(cleanup);
	
	StartupLog();

opencom:
	while (1) {
		g_hComFile = open(argv[1], O_RDONLY);
		if (g_hComFile < 0) {
			DumpError();
			sleep(1000 * 1);
		} else {
			memset(&dcb, 0, sizeof(DCB));
			dcb.DCBlength = sizeof(DCB);
			if (!GetCommState(g_hComFile, &dcb)) {
				DumpError();
				Sleep(1000 * 1);
				CloseHandle(g_hComFile);
				g_hComFile = NULL;
				goto opencom;
			} else {
				dcb.BaudRate = CBR_115200;
				dcb.ByteSize = 8;
				dcb.Parity = 0;
				dcb.StopBits = 0;
				if (!SetCommState(g_hComFile, &dcb)) {
					DumpError();
					Sleep(1000 * 1);
					CloseHandle(g_hComFile);
					g_hComFile = NULL;
					goto opencom;
				} else {
					goto readcom;
				}
			}
		}
	}

readcom:
	while (1) {
		int dwRes;
		if ((dwRes = read(g_hComFile, LogPointer(), LogSpace())) <= 0) {
			DumpError();
			Sleep(1000);
			CloseHandle(g_hComFile);
			g_hComFile = NULL;
			goto opencom;
		}

		ProcessLog(stdout, dwRes);
	}

	return 0;
}
