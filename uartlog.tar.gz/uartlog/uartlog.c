// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
// Windows Header Files:
#include <windows.h>
#include <commctrl.h>
#include "resource.h"
#include "dumplog.h"

#define MAX_COM_COUNT			10
#define IDC_REBAR			199
#define IDM_TOOLBAR			200
#define IDM_EXITAPP			201
#define IDM_CONNECT			202
#define IDM_DISCONNECT			203
#define	IDT_REFRESH_COM			204
#define	IDT_WAIT_OVERLAP		205

/* following codes are dedicated to my dear ZuiZui */
#ifdef UNICODE
#define CML_TSTRTOUTF8(x, y)					\
	ULONG l##y = x ? _tcslen(x)+1 : 0;			\
	y = NULL;						\
	y = (LPSTR)malloc(sizeof (CHAR) * (l##y+1) * 8);	\
	WideCharToMultiByte(CP_UTF8, 0, x, _tcslen(x)+1,	\
			    y, l##y * 8,			\
			    NULL, NULL);
#define CML_TSTRTOMULTI(x, y)					\
	ULONG l##y = x ? _tcslen(x)+1 : 0;			\
	y = NULL;						\
	y = (LPSTR)malloc(sizeof (CHAR) * (l##y+1) * 8);	\
	WideCharToMultiByte(CP_ACP, 0, x, _tcslen(x)+1,		\
			    y, l##y * 8,			\
			    NULL, NULL);
#define CML_TSTRFROMUTF8(x, y)					\
	ULONG l##x = x ? strlen(x) : 0;				\
	y = NULL;						\
	y = (LPTSTR)malloc(sizeof (WCHAR) * (l##x+1));		\
	MultiByteToWideChar(CP_UTF8, 0, x, -1,			\
			    (LPWSTR)y, l##x+1);
#define CML_TSTRFROMMULTI(x, y)					\
	ULONG l##x = x ? strlen(x) : 0;				\
	y = NULL;						\
	y = (LPTSTR)malloc(sizeof (WCHAR) * (l##x+1));		\
	MultiByteToWideChar(CP_ACP, 0, x, -1,			\
			    (LPWSTR)y, l##x+1);
#else
#define CML_TSTRTOUTF8(x, y)					\
	ULONG l##y = x ? strlen(x)+1 : 0;			\
	y = NULL;						\
	y = (LPSTR)malloc(sizeof (CHAR) * (l##y+1));		\
	strcpy(y, x);
#define CML_TSTRTOMULTI(x, y)					\
	ULONG l##y = x ? strlen(x)+1 : 0;			\
	y = NULL;						\
	y = (LPSTR)malloc(sizeof (CHAR) * (l##y+1));		\
	strcpy(y, x);
#define CML_TSTRFROMUTF8(x, y)					\
	ULONG l##x = x ? strlen(x) : 0;				\
	y = NULL;						\
	y = (LPTSTR)malloc(sizeof (CHAR) * (l##x+1));		\
	strcpy(y, x);
#define CML_TSTRFROMMULTI(x, y)					\
	ULONG l##x = x ? strlen(x) : 0;				\
	y = NULL;						\
	y = (LPTSTR)malloc(sizeof (CHAR) * (l##x+1));		\
	strcpy(y, x);
#endif

struct CmbListItem {
	LPCTSTR text;
	DWORD val;
};

typedef struct { 
	OVERLAPPED oOverlap; 
	DWORD cbRead;
	HANDLE hEvents;
	BOOL fPendingIO; 
	BYTE bRetry;
} COMINST, *LPCOMINST; 

HWND CreateToolbar(HWND hWndParent);
HWND CreateRebar(HWND hWndParent);
void DestroyRebar(HWND hWndParent);
HWND CreateSetList(HWND hWndParent);
VOID CreateEventView(HWND hWnd);
void DestroyEventView(HWND hWndParent);
HWND CreateBaudRateList(HWND hToolBar);	
HWND CreateByteSizeList(HWND hWndToolbar);
HWND CreateParityList(HWND hWndToolbar);
HWND CreateStopBitsList(HWND hWndToolbar);
HWND CreateComList(HWND hWndToolbar);
BOOL OnConnect(HWND hWnd);
BOOL OnDisConnect(HWND hWnd);
void InitGlobalVals();
void DestroyGlobalVals();
void WriteLogToFile(LPCTSTR szTask, LPCTSTR szType, LPCTSTR szDetail);
VOID SetEventViewSize(LPRECT lpRect, HWND hWnd);
VOID SetRebarSize(LPRECT lpRect, HWND hCtrl);
INT EnumSerialPort(LPTSTR *comlist);
BOOL ConnectComPort(LPCTSTR name);
BOOL DisConnectComPort(VOID);
BOOL InitCOMInst(VOID);
BOOL SetCommParam(DWORD dwBaudRate, BYTE bParity, 
		  BYTE bByteSzie, BYTE bStopBits);
DWORD BeginReadLog(VOID);
VOID AddToEventView(DWORD dwModule, LPCTSTR szType, LPCTSTR szDetail);
CHAR *CML_tstr2multi(LPCTSTR string);
TCHAR *CML_multi2tstr(LPCSTR string);
TCHAR *CML_utf82tstr(LPCSTR string);
CHAR *CML_tstr2utf8(LPCTSTR string);
TCHAR *GetModulePath(VOID);

COMINST hCOMInst;
HANDLE g_hComFile;
HICON g_hIcon = NULL;

HINSTANCE g_hInst;
HANDLE g_hLogFile;
DWORD g_ListViewCnt;
HWND g_hListView;

LPTSTR comlist[MAX_COM_COUNT];

struct CmbListItem BaudRate[] =
{
	{_T("9600"), CBR_9600},
	{_T("19200"), CBR_19200},
	{_T("38400"), CBR_38400},
	{_T("57600"), CBR_57600},
	{_T("115200"), CBR_115200},
};

struct CmbListItem ByteSize[] =
{
	{_T("5"), 5},
	{_T("6"), 6},
	{_T("7"), 7},
	{_T("8"), 8},
};

struct CmbListItem Parity[] =
{
	{_T("��"), 0},
	{_T("��У��"), 1},
	{_T("żУ��"), 2},
};

struct CmbListItem StopBits[] =
{
	{_T("1"), 0},
	{_T("1.5"), 1},
	{_T("2"), 2},
};

int EnumSerialPort(LPTSTR *comlist)  
{
	HKEY hKey;
	LPCTSTR data_Set = _T("HARDWARE\\DEVICEMAP\\SERIALCOMM\\");
	DWORD dwIndex = 0;
	LONG ret;
	
	if (comlist == NULL)
		return 0;

	ret = RegOpenKeyEx(HKEY_LOCAL_MACHINE, data_Set, 0, KEY_READ, &hKey);
	
	if (ret != ERROR_SUCCESS)
		return 0;
	
	while (TRUE)
	{
		LONG Status;   
		TCHAR Name[256] = {0};   
		BYTE szPortName[80] = {0};
		DWORD dwName;   
		DWORD dwSizeofPortName;   
		DWORD Type;
		
		dwName = sizeof(Name);   
		dwSizeofPortName = sizeof(szPortName);   
		Status = RegEnumValue(hKey, dwIndex++, Name, &dwName, 
			NULL, &Type, szPortName, &dwSizeofPortName);   
		
		if ((Status == ERROR_SUCCESS) || (Status == ERROR_MORE_DATA)) {
			CML_TSTRFROMMULTI(szPortName, comlist[dwIndex - 1]);
		} else {
			break;
		}
	}
	RegCloseKey(hKey);
	return dwIndex - 1;  
}

BOOL ConnectComPort(LPCTSTR name)
{
	g_hComFile = CreateFile(name, GENERIC_READ, 0, 0, OPEN_EXISTING,
			   FILE_FLAG_OVERLAPPED, 0);
	if (g_hComFile == INVALID_HANDLE_VALUE)
		return FALSE;
	return InitCOMInst();
}

BOOL DisConnectComPort()
{
	if (g_hComFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(g_hComFile);
		g_hComFile = INVALID_HANDLE_VALUE;
	}
	if (!hCOMInst.hEvents)
	{
		CloseHandle(hCOMInst.hEvents);
		hCOMInst.hEvents = NULL;
	}
	return TRUE;
}

BOOL SetCommParam(DWORD dwBaudRate, BYTE bParity, 
		  BYTE bByteSzie, BYTE bStopBits)
{
	DCB dcb;
	
	if (g_hComFile == INVALID_HANDLE_VALUE)
		return FALSE;
	
	ZeroMemory(&dcb, sizeof(DCB));
	dcb.DCBlength = sizeof(DCB);
	if (!GetCommState(g_hComFile, &dcb))
		return FALSE;
	
	dcb.BaudRate = dwBaudRate;   // set the baud rate
	dcb.ByteSize = bByteSzie;    // data size, xmit, and rcv
	dcb.Parity = bParity;        // no parity bit
	dcb.StopBits = bStopBits;    // one stop bit
	
	if (!SetCommState(g_hComFile, &dcb))
		return FALSE;
	return TRUE;
}

BOOL InitCOMInst(void)
{
	if (hCOMInst.hEvents)
		CloseHandle(hCOMInst.hEvents);

	ZeroMemory(&hCOMInst, sizeof (COMINST));
	hCOMInst.fPendingIO = FALSE;
	hCOMInst.hEvents = CreateEvent(NULL, FALSE, TRUE, NULL);

	if (!hCOMInst.hEvents)
		return FALSE;
	hCOMInst.oOverlap.hEvent = hCOMInst.hEvents;
	hCOMInst.bRetry = 5;
	return TRUE;
}

/* ����0��ʾ�Ѿ����µ����ݱ�����
   ����1��ʾ�д������Ӧ��ֹͣ��ʱ��
   ����2��ʾ��ǰ����δ�� */
DWORD BeginReadLog(void)
{
	DWORD dwRet, cbRet;
	BOOL fSuccess;

	dwRet = WaitForSingleObject(hCOMInst.hEvents, 0);
	if (hCOMInst.fPendingIO == TRUE && dwRet != WAIT_OBJECT_0)
	{
		/* no event */
		return 2;
	}
	if (hCOMInst.fPendingIO == TRUE)
	{
		fSuccess = GetOverlappedResult(g_hComFile, &hCOMInst.oOverlap, &cbRet, FALSE);
		if (!fSuccess)
		{
			/* ����Ӧ���ǿ��Է��سɹ��ģ� ����Ӧ���д��� */
			hCOMInst.bRetry--;
			if (hCOMInst.bRetry == 0)
			{
				return 1;
			}
		}
		/* ���سɹ��������� */
		hCOMInst.cbRead += cbRet;
		ProcessLog(NULL, hCOMInst.cbRead);
		hCOMInst.fPendingIO = FALSE;
		return 0;
 	}
	else
	{
		DWORD dwErr;

		fSuccess = ReadFile(g_hComFile, LogPointer(), LogSpace(), 
				    &hCOMInst.cbRead, &hCOMInst.oOverlap); 
		if (fSuccess && hCOMInst.cbRead != 0)
		{
			/* �������� */
			ProcessLog(NULL, hCOMInst.cbRead);
			return 0;
		}
		else
		{
			dwErr = GetLastError();
			if (dwErr == ERROR_HANDLE_EOF)
			{
				return 1;
			}
			else if (dwErr == ERROR_IO_PENDING)
			{
				hCOMInst.fPendingIO = TRUE;
			}
			else
			{
				hCOMInst.bRetry--;
				if (hCOMInst.bRetry == 0)
				{
					return 1;
				}
			}
		}
	}
	return 2;
}

void UpdateWindowSize(HWND hWnd)
{
	RECT rect;
	GetClientRect(hWnd, &rect);
	SetRebarSize(&rect, GetDlgItem(hWnd, IDC_REBAR));
	SetEventViewSize(&rect, hWnd);
}

static VOID UnsetDialogIcon(HWND hWnd)
{
	if (g_hIcon)
		DestroyIcon(g_hIcon);
}

static VOID SetDialogIcon(HWND hWnd)
{
	g_hIcon = LoadImage(g_hInst,
			    MAKEINTRESOURCE(IDI_UARTLOG),
			    IMAGE_ICON,
			    GetSystemMetrics(SM_CXSMICON),
			    GetSystemMetrics(SM_CYSMICON),
			    0);
	if (g_hIcon)
	{
		SendMessage(hWnd, WM_SETICON, ICON_SMALL, (LPARAM)g_hIcon);
	}
}

INT_PTR CALLBACK MyDialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;

	switch (message) 
	{
		case WM_ERASEBKGND:
			return 1;

		case WM_INITDIALOG:
			InitGlobalVals();
			SetDialogIcon(hWnd);
			CreateRebar(hWnd);
			CreateEventView(hWnd);
			UpdateWindowSize(hWnd);
			SetTimer(hWnd, IDT_REFRESH_COM, 5000, NULL);
			return TRUE;

		case WM_SIZE:
			UpdateWindowSize(hWnd);
			break;

		case WM_TIMER:
			if (wParam == IDT_WAIT_OVERLAP)
			{
				DWORD dwRet = BeginReadLog();
				if (dwRet == 1)
				{
					KillTimer(hWnd, IDT_WAIT_OVERLAP);
				}
			}
			else if (wParam == IDT_REFRESH_COM)
			{
			}
			break;
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId)
			{
			case IDM_EXITAPP:
				DestroyWindow(hWnd);
				break;
			case IDM_CONNECT:
				OnConnect(hWnd);
				break;
			case IDM_DISCONNECT:
				OnDisConnect(hWnd);
				break;
			default:
				return 0;
			}
			break;
		case WM_CLOSE: 
			KillTimer(hWnd, IDT_REFRESH_COM);
			KillTimer(hWnd, IDT_WAIT_OVERLAP);
			DestroyWindow(hWnd); 
			return TRUE;
		case WM_DESTROY:
			DestroyEventView(hWnd);
			DestroyRebar(hWnd);
			DestroyGlobalVals();
			UnsetDialogIcon(hWnd);
			PostQuitMessage(0);
			return TRUE;
		default:
			return 0;
	}
	return 0;
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	MSG msg;
	HWND hDlg;

	g_hInst = hInstance;
	hDlg = CreateDialog(hInstance, (LPCTSTR)IDD_MAIN, NULL, (DLGPROC)MyDialogProc);
	if (hDlg == NULL)
		return FALSE;

	StartupLog();
	ShowWindow(hDlg, nCmdShow);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	CleanupLog();

	return msg.wParam;
}

HWND CreateBaudRateList(HWND hWndToolbar)
{
	HWND hWndCombo;
	int idx;

	hWndCombo = GetDlgItem(hWndToolbar, IDC_COMBO_BAUD);
	if (hWndCombo == NULL)
		return NULL;
	SendMessage(hWndCombo, CB_RESETCONTENT, 0, 0);
	for (idx = 0; idx < sizeof(BaudRate)/sizeof(BaudRate[0]); idx++)
		SendMessage(hWndCombo, CB_ADDSTRING, (WPARAM)0, (LPARAM)BaudRate[idx].text);
	SendMessage(hWndCombo, CB_SETCURSEL, 4, 0); 
	return hWndCombo;
}

HWND CreateParityList(HWND hWndToolbar)
{
	HWND hWndCombo;
	int idx;

	hWndCombo = GetDlgItem(hWndToolbar, IDC_COMBO_PARITY);
	if (hWndCombo == NULL)
		return NULL;
	SendMessage(hWndCombo, CB_RESETCONTENT, 0, 0); 
	for (idx = 0; idx < sizeof(Parity)/sizeof(Parity[0]); idx++)
		SendMessage(hWndCombo, CB_ADDSTRING, (WPARAM)0, (LPARAM)Parity[idx].text);
	SendMessage(hWndCombo, CB_SETCURSEL, 0, 0); 
	return hWndCombo;
}

HWND CreateByteSizeList(HWND hWndToolbar)
{
	HWND hWndCombo;
	int idx;

	hWndCombo = GetDlgItem(hWndToolbar, IDC_COMBO_BIT);
	if (hWndCombo == NULL)
		return NULL;
	SendMessage(hWndCombo, CB_RESETCONTENT, 0, 0); 
	for (idx = 0; idx < sizeof(ByteSize)/sizeof(ByteSize[0]); idx++)
		SendMessage(hWndCombo, CB_ADDSTRING, (WPARAM)0, (LPARAM)ByteSize[idx].text);
	SendMessage(hWndCombo, CB_SETCURSEL, 3, 0); 
	return hWndCombo;
}

HWND CreateStopBitsList(HWND hWndToolbar)
{
	HWND hWndCombo;
	int idx;

	hWndCombo = GetDlgItem(hWndToolbar, IDC_COMBO_STOPBIT);
	if (hWndCombo == NULL)
		return NULL;

	SendMessage(hWndCombo, CB_RESETCONTENT, 0, 0); 
	for (idx = 0; idx < sizeof(StopBits)/sizeof(StopBits[0]); idx++)
		SendMessage(hWndCombo, CB_ADDSTRING, (WPARAM)0, (LPARAM)StopBits[idx].text);
	SendMessage(hWndCombo, CB_SETCURSEL, 0, 0); 
	return hWndCombo;
}

HWND CreateComList(HWND hWndToolbar)
{
	HWND hWndCombo;
	int i;

	hWndCombo = GetDlgItem(hWndToolbar, IDC_COMBO_COM);
	if (hWndCombo == NULL)
		return NULL;

	SendMessage(hWndCombo, CB_RESETCONTENT, 0, 0); 
	for (i = 0; i < MAX_COM_COUNT; i++)
	{
		if (comlist[i] != NULL)
			SendMessage(hWndCombo, CB_ADDSTRING, (WPARAM)0, (LPARAM)comlist[i]);
	}
	SendMessage(hWndCombo, CB_SETCURSEL, 0, 0); 
	return hWndCombo;
}

HWND CreateSetList(HWND hWndParent)
{
	HWND hwndSetList;
	
	hwndSetList = CreateDialog(g_hInst, 
				   (LPCTSTR)IDD_SET_LIST, 
				   hWndParent, 
				   (DLGPROC)NULL);
	if (hwndSetList == NULL)
		return NULL;
	
	CreateBaudRateList(hwndSetList);
	CreateParityList(hwndSetList);
	CreateByteSizeList(hwndSetList);
	CreateStopBitsList(hwndSetList);
	CreateComList(hwndSetList);
	return hwndSetList;
}

HWND CreateToolbar(HWND hWndParent)
{
	HWND hwndToolBar;
	int ret;
	HIMAGELIST hImageList;
	HBITMAP hBitmap;
	TBBUTTON tbButtons[] = 
	{
		{ 0, IDM_EXITAPP, TBSTATE_ENABLED, TBSTYLE_AUTOSIZE, {0}, 0, (INT_PTR)_T("Exit UARTLog") },
		{ 1, IDM_CONNECT, TBSTATE_ENABLED, TBSTYLE_AUTOSIZE, {0}, 0, (INT_PTR)_T("Connect UART") },
		{ 2, IDM_DISCONNECT, TBSTATE_ENABLED, TBSTYLE_AUTOSIZE, {0}, 0, (INT_PTR)_T("Disconnect UART") }
	};
	
	hwndToolBar = CreateWindowEx(WS_EX_TOOLWINDOW, TOOLBARCLASSNAME, NULL, 
		WS_CHILD | CCS_NOPARENTALIGN | CCS_NODIVIDER |
		CCS_NORESIZE | TBSTYLE_FLAT | TBSTYLE_TOOLTIPS,
		0, 0, 0, 0,
		hWndParent, (HMENU)IDM_TOOLBAR, g_hInst, NULL);
	
	if (hwndToolBar == NULL)
		return NULL;
	
        {
            hImageList = ImageList_Create(16, 16, ILC_COLOR|ILC_MASK,
                                          sizeof(tbButtons)/sizeof(tbButtons[0]), 0); 
            hBitmap = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_TOOLBAR4BIT));
            ImageList_AddMasked(hImageList, hBitmap, RGB(255, 0, 255));
            DeleteObject(hBitmap);
        }
	
	// Set the image list.
	SendMessage(hwndToolBar, TB_SETIMAGELIST, (WPARAM)0, (LPARAM)hImageList);
	
	// Add buttons.
	SendMessage(hwndToolBar, TB_BUTTONSTRUCTSIZE, (WPARAM)sizeof (TBBUTTON), 0);
	ret = SendMessage(hwndToolBar, TB_ADDBUTTONS, (WPARAM)(sizeof (tbButtons) / sizeof (tbButtons[0])), 
		(LPARAM)&tbButtons);
	SendMessage(hwndToolBar, TB_SETMAXTEXTROWS, (WPARAM)0, (LPARAM)0);
	SendMessage(hwndToolBar, TB_SETBUTTONSIZE, 0, MAKELONG(20, 20));
	
	// Tell the toolbar to resize itself, and show it.
	//SendMessage(hwndToolBar, TB_AUTOSIZE, 0, 0); 
	SendMessage(hwndToolBar, TB_ENABLEBUTTON, IDM_CONNECT, TRUE);
	SendMessage(hwndToolBar, TB_ENABLEBUTTON, IDM_DISCONNECT, FALSE);
	
	return hwndToolBar;
}

VOID CreateEventView(HWND hWnd)
{
	LVCOLUMN col;
	HIMAGELIST hImageList;
	HBITMAP hBitmap;

	g_hListView = GetDlgItem(hWnd, IDC_EVT_VIEW);
	if (g_hListView == NULL)
		return;
	
	//SetWindowPos(hListView, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
	col.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	col.fmt = LVCFMT_LEFT;
	col.cx = 20;
	col.pszText = _T("");
	col.iSubItem = 0;
	ListView_InsertColumn(g_hListView, 0, &col);
	
	col.fmt = LVCFMT_LEFT;
	col.cx = 60;
	col.pszText = _T("���");
	col.iSubItem = 1;
	ListView_InsertColumn(g_hListView, 1, &col);
	
	col.fmt = LVCFMT_LEFT;
	col.cx = 800;
	col.pszText = _T("��ϸ");
	col.iSubItem = 2;
	ListView_InsertColumn(g_hListView, 2, &col);

	hImageList = ImageList_Create(16, 16, ILC_COLOR16 | ILC_MASK,
				      16, 0);
	hBitmap = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_LOGLIST4BIT));
	ImageList_AddMasked(hImageList, hBitmap, RGB(255, 0, 255));
	DeleteObject(hBitmap);

	ListView_SetImageList(g_hListView, hImageList, LVSIL_SMALL); 
	ListView_SetExtendedListViewStyle(g_hListView, LVS_EX_FULLROWSELECT);
	SendMessage(g_hListView, LVM_SETITEMCOUNT, (WPARAM)500, 0);
	g_ListViewCnt = 0;
}

void DestroyEventView(HWND hWnd)
{
	HIMAGELIST hImageList;

	hImageList = (HIMAGELIST)SendMessage(g_hListView, LVM_GETIMAGELIST, LVSIL_SMALL, 0);
	if (hImageList != NULL)
		ImageList_Destroy(hImageList);
}

void InitGlobalVals()
{
	TCHAR szFile[MAX_PATH + 12 * sizeof (TCHAR)];

	memset(comlist, 0, MAX_COM_COUNT);
	EnumSerialPort(comlist);
	/* open file to write into loginfo */
	g_hLogFile = INVALID_HANDLE_VALUE;
	memset(szFile, 0, sizeof (szFile));
	_tcscat(szFile, GetModulePath());
	_tcscat(szFile, _T("\\uartlog.log"));
	g_hLogFile = CreateFile(szFile, GENERIC_READ | GENERIC_WRITE, 
			   FILE_SHARE_READ, 0, CREATE_ALWAYS,
			   FILE_FLAG_WRITE_THROUGH, 0);
}

void DestroyGlobalVals()
{
	int i = 0;

	if (g_hLogFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(g_hLogFile);
		g_hLogFile = INVALID_HANDLE_VALUE;
	}
	for (i = 0; i < MAX_COM_COUNT; i++)
	{
		if (comlist[i] != NULL)
			free(comlist[i]);
	}
}

BOOL OnConnect(HWND hWnd)
{
	HWND hToolBar, hSetList, hList;
	REBARBANDINFO rbBand;
	DWORD dwBaudRate;
	BYTE bSelCom, bParity, bByteSzie, bStopBits;
	LRESULT lResult = CB_ERR;
	HWND hReBar = GetDlgItem(hWnd, IDC_REBAR);

	if (hReBar == NULL)
	{
		return FALSE;
	}

	hToolBar = GetDlgItem(hReBar, IDM_TOOLBAR);
	if (hToolBar == NULL)
	{
		return FALSE;
	}

	/* Get Com Info */
	rbBand.fMask = RBBIM_CHILD;
	rbBand.cbSize = sizeof (REBARBANDINFO);

	if (!SendMessage(hReBar, RB_GETBANDINFO, (WPARAM)1, (LPARAM)&rbBand))
	{
		return FALSE;
	}
	hSetList = rbBand.hwndChild;
	if (hSetList == NULL)
	{
		return FALSE;
	}
	hList = GetDlgItem(hSetList, IDC_COMBO_COM);
	lResult = SendMessage(hList, CB_GETCURSEL, 0, 0);
	if (lResult == CB_ERR)
	{
		return FALSE;
	}
	bSelCom = (BYTE)lResult;

	/* Open Comm port */
	if (ConnectComPort(comlist[bSelCom]) == FALSE)
	{
		MessageBox(hWnd, _T("Connect Error"), NULL, MB_OK);
		return FALSE;
	}

	/* Open Success */
	SendMessage(hToolBar, TB_ENABLEBUTTON, IDM_CONNECT, FALSE);
	SendMessage(hToolBar, TB_ENABLEBUTTON, IDM_DISCONNECT, TRUE);

	/* Get BaudRate Info */
	hList = GetDlgItem(hSetList, IDC_COMBO_BAUD);
	if (hList == NULL)
	{
		return FALSE;
	}
	lResult = SendMessage(hList, CB_GETCURSEL, 0, 0);
	if (lResult == CB_ERR)
	{
		return FALSE;
	}
	dwBaudRate = (DWORD)BaudRate[lResult].val;

	/* Get ByteSize Info */
	hList = GetDlgItem(hSetList, IDC_COMBO_BIT);
	if (hList == NULL)
	{
		return FALSE;
	}
	lResult = SendMessage(hList, CB_GETCURSEL, 0, 0);
	if (lResult == CB_ERR)
	{
		return FALSE;
	}
	bByteSzie = (BYTE)ByteSize[lResult].val;

	/* Get Parity Info */
	hList = GetDlgItem(hSetList, IDC_COMBO_PARITY);
	if (hList == NULL)
	{
		return FALSE;
	}
	lResult = SendMessage(hList, CB_GETCURSEL, 0, 0);
	if (lResult == CB_ERR)
	{
		return FALSE;
	}
	bParity = (BYTE)Parity[lResult].val;

	/* Get StopBits Info */
	hList = GetDlgItem(hSetList, IDC_COMBO_STOPBIT);
	if (hList == NULL)
	{
		return FALSE;
	}
	lResult = SendMessage(hList, CB_GETCURSEL, 0, 0);
	if (lResult == CB_ERR)
	{
		return FALSE;
	}
	bStopBits = (BYTE)StopBits[lResult].val;

	if (SetCommParam(dwBaudRate, bParity, bByteSzie, bStopBits) == FALSE)
	{
		return FALSE;
	}
	SetTimer(hWnd, IDT_WAIT_OVERLAP, 1, NULL);
	return TRUE;
}

BOOL OnDisConnect(HWND hWnd)
{
	HWND hReBar = GetDlgItem(hWnd, IDC_REBAR);
	HWND hToolBar;

	KillTimer(hWnd, IDT_WAIT_OVERLAP);
	if (hReBar == NULL)
	{
		return FALSE;
	}
	hToolBar = GetDlgItem(hReBar, IDM_TOOLBAR);
	if (hToolBar == NULL)
	{
		return FALSE;
	}
	/* Close Comm port */
	if (DisConnectComPort() == FALSE)
	{
		MessageBox(hWnd, _T("DisConnect Error"), NULL, MB_OK);
		return FALSE;
	}

	/* Close Success */
	SendMessage(hToolBar, TB_ENABLEBUTTON, IDM_CONNECT, TRUE);
	SendMessage(hToolBar, TB_ENABLEBUTTON, IDM_DISCONNECT, FALSE);
	return TRUE;
}

#define TOP    0x00
#define LEFT   0x01
#define BOTTOM 0x02
#define RIGHT  0x03

DWORD _dwRebarSide = TOP;

HWND CreateRebar(HWND hWndParent)
{
	HWND hwndRebar, hwndToolBar, hwndSetList;
	DWORD dwBtnSize;
	RECT rc;
	INITCOMMONCONTROLSEX icex;
	REBARBANDINFO rbBand = { sizeof(REBARBANDINFO) };
	
	// Initialize common controls.
	icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
	icex.dwICC   = ICC_COOL_CLASSES | ICC_BAR_CLASSES;
	InitCommonControlsEx(&icex);
	
	// Create the rebar.
	hwndRebar = CreateWindowEx(WS_EX_TOOLWINDOW,
				   REBARCLASSNAME, 
				   NULL,
				   WS_VISIBLE |
				   WS_BORDER | 
				   WS_CHILD | 
				   WS_CLIPCHILDREN | 
				   WS_CLIPSIBLINGS | 
				   RBS_VARHEIGHT | 
				   RBS_BANDBORDERS | 
				   //_dwRebarSide is odd if this is a vertical bar
				   ((_dwRebarSide & 0x01) ? CCS_VERT : 0) |
				   ((_dwRebarSide == BOTTOM) ? CCS_BOTTOM : 0) |
				   ((_dwRebarSide == RIGHT) ? CCS_RIGHT : 0) |
				   0,
				   0, 
				   0, 
				   200, 
				   32, 
				   hWndParent, 
				   (HMENU)IDC_REBAR, 
				   g_hInst, 
				   NULL);
	
	if (!hwndRebar)
	{
		return NULL;
	}
	
	hwndToolBar = CreateToolbar(hwndRebar);
	hwndSetList = CreateSetList(hwndRebar);
	// Initialize band info used by both bands.
	rbBand.fMask  = 
		RBBIM_STYLE       // fStyle is valid.
		| RBBIM_TEXT        // lpText is valid.
		| RBBIM_CHILD       // hwndChild is valid.
		| RBBIM_CHILDSIZE   // child size members are valid.
		| RBBIM_SIZE       // cx is valid
		| RBBIM_ID;
	rbBand.fStyle = RBBS_CHILDEDGE | RBBS_GRIPPERALWAYS | RBBS_BREAK; //RBBS_FIXEDSIZE
	
	// Get the height of the toolbar.
	dwBtnSize = (DWORD)SendMessage(hwndToolBar, TB_GETBUTTONSIZE, 0, 0);
	
	// Set values unique to the band with the toolbar.
	rbBand.lpText = TEXT("");
	rbBand.hwndChild = hwndToolBar;
	rbBand.cyChild = HIWORD(dwBtnSize);
	rbBand.cxMinChild = LOWORD(dwBtnSize);
	rbBand.cyMinChild = HIWORD(dwBtnSize);
	// The default width is the width of the buttons.
	rbBand.cx = LOWORD(dwBtnSize) * 2 + 15;
	rbBand.wID = IDM_TOOLBAR;
	
	// Add the band that has the toolbar.
	SendMessage(hwndRebar, RB_INSERTBAND, (WPARAM)-1, (LPARAM)&rbBand);
	
	// Set values unique to the band with the combo box.
	GetWindowRect(hwndSetList, &rc);
	rbBand.lpText = TEXT("");
	rbBand.hwndChild = hwndSetList;
	rbBand.cyChild = rc.bottom - rc.top;
	rbBand.cxMinChild = 100;
	rbBand.cyMinChild = rc.bottom - rc.top;
	// The default width should be set to some value wider than the text. The combo 
	// box itself will expand to fill the band.
	rbBand.cx = rc.right - rc.left;
	rbBand.wID = IDD_SET_LIST;
	
	// Add the band that has the combo box.
	SendMessage(hwndRebar, RB_INSERTBAND, (WPARAM)-1, (LPARAM)&rbBand);
	return (hwndRebar);
}

void DestroyRebar(HWND hWndParent)
{
	HWND hReBar = GetDlgItem(hWndParent, IDC_REBAR);
	HIMAGELIST hImageList;
	HWND hToolBar;

	if (hReBar == NULL)
	{
		return;
	}
	hToolBar = GetDlgItem(hReBar, IDM_TOOLBAR);
	if (hToolBar == NULL)
	{
		return;
	}
	hImageList = (HIMAGELIST)SendMessage(hToolBar, TB_GETIMAGELIST, 0, 0);
	ImageList_Destroy(hImageList);
}

VOID AddToEventView(DWORD dwModule, LPCTSTR szType, LPCTSTR szDetail)
{
	LVITEM lvI;
	DWORD dwItemIdx;

	if (g_hListView == NULL)
	{
		return;
	}
	dwItemIdx = g_ListViewCnt++;

	lvI.mask = LVIF_IMAGE; 
	lvI.iItem = 0;
	lvI.iSubItem = 0;
	lvI.iImage = dwModule;
	ListView_InsertItem(g_hListView, &lvI);

	lvI.mask = LVIF_TEXT; 
	lvI.iItem = 0;
	lvI.iSubItem = 1;
	lvI.pszText = (LPTSTR)szType;
	SendMessage(g_hListView, LVM_SETITEM, 0, (LPARAM)&lvI);

	lvI.mask = LVIF_TEXT; 
	lvI.iItem = 0;
	lvI.iSubItem = 2;
	lvI.pszText = (LPTSTR)szDetail;
	SendMessage(g_hListView, LVM_SETITEM, 0, (LPARAM)&lvI);
}

void WriteLogToFile(LPCTSTR szTask, LPCTSTR szType, LPCTSTR szDetail)
{
	TCHAR *szBuf = NULL;
	DWORD dwWrite = 0;
	DWORD dwLen = _tcslen(szTask) + _tcslen(szType) +
		      _tcslen(szDetail) + sizeof (TCHAR) * 4;

	szBuf = (TCHAR *)malloc(sizeof (TCHAR) * (dwLen + 1));
	if (szBuf == NULL)
		return;

	memset(szBuf, 0x00, dwLen * sizeof (TCHAR));
	_tcscat(szBuf, szTask);
	_tcscat(szBuf, TEXT(" "));
	_tcscat(szBuf, szType);
	_tcscat(szBuf, TEXT(" "));
	_tcscat(szBuf, szDetail);
	_tcscat(szBuf, TEXT("\r\n"));
	WriteFile(g_hLogFile, szBuf, dwLen, &dwWrite, NULL);
}

VOID SetEventViewSize(LPRECT lpRect, HWND hWnd)
{
	RECT rcBar;
	int Height, Width;

	GetWindowRect(GetDlgItem(hWnd, IDC_REBAR), &rcBar);
	Height = (lpRect->bottom - (lpRect->top + (rcBar.bottom - rcBar.top-4)));
	Width = (lpRect->right - lpRect->left);

	SetWindowPos(GetDlgItem(hWnd, IDC_EVT_VIEW), HWND_TOP,
		     0, (rcBar.bottom - rcBar.top-4),
		     Width, Height, SWP_NOZORDER);
}

VOID SetRebarSize(LPRECT lpRect, HWND hCtrl)
{
	int iWidth = lpRect->right - lpRect->left;
	REBARBANDINFO rbBand = { sizeof(REBARBANDINFO) };

	rbBand.fMask  = RBBIM_SIZE;       // cx is valid
	rbBand.cx = iWidth;

	SendMessage(hCtrl, RB_SETBANDINFO, 0, (LPARAM)&rbBand);
	SendMessage(hCtrl, RB_SETBANDINFO, 1, (LPARAM)&rbBand);
}

LPSTR CML_tstr2multi(LPCTSTR string)
{
	char *result = NULL;
	CML_TSTRTOMULTI(string, result);
	return result;
}

LPTSTR CML_multi2tstr(LPCSTR string)
{
	TCHAR *result = NULL;
	CML_TSTRFROMMULTI(string, result);
	return result;
}

LPTSTR CML_utf82tstr(LPCSTR string)
{
	TCHAR *result = NULL;
	CML_TSTRFROMUTF8(string, result);
	return result;
}

LPSTR CML_tstr2utf8(LPCTSTR string)
{
	char *result = NULL;
	CML_TSTRTOUTF8(string, result);
	return result;
}

/* following codes are used to initialize OpenLDAP */
void chomp(char *line)
{
	char *last = line+strlen(line);
	
	for (last; last >= line; last--) {
		if (strchr(" \r\n\t", *last))
			*last = '\0';
		else
			break;
	}
}

char *strcat_alloc(char *old_str, const char *str)
{
	int old_size;
	int new_size;
	char *text;
	int size = strlen(str);
	
	if (old_str) {
		old_size = strlen(old_str);
		new_size = old_size + size + 1;
		text = realloc(old_str, new_size);
		memcpy(text + old_size, str, size);
		text[new_size-1] = 0;
	} else {
		text = strdup(str);
	}
	return text;
}

VOID WindowsDump(VOID *ctx, BYTE bCmd, LPSTR szFormat, ...)
{
	FILE *pFile = (FILE *)ctx;
	va_list argList;
	char szBuf[1024];
	TCHAR *szDetail;
	TCHAR *szEvtName;
	
	va_start(argList, szFormat );
	vsprintf(szBuf, szFormat, argList);
	va_end(argList);

	szDetail = CML_multi2tstr(szBuf);
	szEvtName = CML_multi2tstr(GetEventName(bCmd));
	if (szDetail && szEvtName) {
		TCHAR *szTask = CML_multi2tstr(GetTaskName(bCmd));
		AddToEventView(CMD_TASK_PID(bCmd), szEvtName, szDetail);
		if (szTask) {
			WriteLogToFile(szTask, szEvtName, szDetail);
			free(szTask);
		}
	}
	if (szDetail) free(szDetail);
	if (szEvtName) free(szEvtName);
}

TCHAR *GetModulePath(VOID)
{
	int done = FALSE;
	static TCHAR res[MAX_PATH], *temp;
	
	if (done) return res;
	if (GetModuleFileName(g_hInst, res, MAX_PATH)) {
		temp = _tcsrchr(res, _T('\\'));
		if (temp != NULL)
			*temp = _T('\0');
		done = TRUE;
	}
	return res;
}