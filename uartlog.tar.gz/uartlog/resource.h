//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by uartlog.rc
//
#define IDD_SET_LIST                    101
#define IDD_MAIN                        114
#define IDB_TOOLBAR4BIT                 130
#define IDB_LOGLIST4BIT                 131
#define IDI_UARTLOG                     132
#define IDC_EVT_VIEW                    1007
#define IDC_COMBO_COM                   1008
#define IDC_STATIC1                     1009
#define IDC_STATIC2                     1010
#define IDC_STATIC3                     1011
#define IDC_COMBO_BAUD                  1012
#define IDC_COMBO_PARITY                1013
#define IDC_STATIC4                     1014
#define IDC_COMBO_BIT                   1015
#define IDC_COMBO_STOPBIT               1016
#define IDC_STATIC5                     1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
