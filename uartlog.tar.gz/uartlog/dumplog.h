#ifndef __DUMPLOG_H__
#define __DUMPLOG_H__

#ifdef WIN32
#include <windows.h>
#else
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#endif
#include <stdio.h>
#include <stdarg.h>

#ifndef WIN32
#define CloseHandle(x)	close(x)
typedef unsigned char * LPBYTE;
typedef unsigned int DWORD;
typedef unsigned short BYTE;
typedef void VOID;
typedef char * LPSTR;
typedef const char * LPCSTR;
typedef const LPBYTE LPCBYTE;
typedef char CHAR;
typedef char * LPCTSTR;
#define CONST const
#endif

#ifndef BOOL
typedef int BOOL;
#endif
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE 
#define FALSE (!TRUE)
#endif

#define TIMER_TASK_PID			0
#define WDT_TASK_PID			1
#define UART_TASK_PID			2
#define USB_TASK_PID			3
#define KBD_TASK_PID			4
#define SCIB_TASK_PID			5
#define CCID_TASK_PID			6
#define HID_TASK_PID			7
#define LCD_TASK_PID			8
#define SCS_TASK_PID			9
#define TEST_TASK_PID			10
#define NR_TASKS			11

#define MAIN_TASK_PID		NR_TASKS+1
#define RAW_TASK_PID		15

#define RAW_EVENT_BASE		(RAW_TASK_PID<<4)
#define RAW_EVENT_DATA		RAW_EVENT_BASE
#define RAW_EVENT_ERROR		RAW_EVENT_BASE+1

#define MAIN_DEBUG_BASE		((NR_TASKS+1)<<4)
#define MAIN_DEBUG_INIT		MAIN_DEBUG_BASE
#define MAIN_DEBUG_PANIC	MAIN_DEBUG_BASE+1

#define USB_DEBUG_BASE		(USB_TASK_PID<<4)
#define USB_DEBUG_INTR		USB_DEBUG_BASE
#define USB_DEBUG_EVENT		USB_DEBUG_BASE+1
#define USB_DEBUG_STATE		USB_DEBUG_BASE+2
#define USB_DEBUG_EP_EVENT	USB_DEBUG_BASE+3
#define USB_DEBUG_EP_STAGE	USB_DEBUG_BASE+4
#define USB_DEBUG_EP_STATUS	USB_DEBUG_BASE+5
#define USB_DEBUG_ST_REQ	USB_DEBUG_BASE+6
#define USB_DEBUG_IF_REQ	USB_DEBUG_BASE+7
#define USB_DEBUG_EP_REQ	USB_DEBUG_BASE+8
#define USB_DEBUG_DESC		USB_DEBUG_BASE+9
#define USB_DEBUG_CLASS		USB_DEBUG_BASE+10
#define USB_DEBUG_ENDP		USB_DEBUG_BASE+11
#define USB_DEBUG_INTF		USB_DEBUG_BASE+12

#define LCD_DEBUG_BASE		(LCD_TASK_PID<<4)
#define LCD_DEBUG_EVENT		LCD_DEBUG_BASE
#define LCD_DEBUG_QUEUE		LCD_DEBUG_BASE+1
#define LCD_DEBUG_STATE		LCD_DEBUG_BASE+2
#define LCD_DEBUG_IDLE		LCD_DEBUG_BASE+3
#define LCD_DEBUG_INIT		LCD_DEBUG_BASE+4

#define KBD_DEBUG_BASE		(KBD_TASK_PID<<4)
#define KBD_DEBUG_DOWN		KBD_DEBUG_BASE
#define KBD_DEBUG_UP		KBD_DEBUG_BASE+1

#define SCS_DEBUG_BASE		(SCIB_TASK_PID<<4)
#define SCS_DEBUG_INTR		SCS_DEBUG_BASE
#define SCS_DEBUG_SLOT_EVENT	SCS_DEBUG_BASE+1
#define SCS_DEBUG_SLOT_STATE	SCS_DEBUG_BASE+2
#define SCS_DEBUG_UART_EVENT	SCS_DEBUG_BASE+3
#define SCS_DEBUG_ATR_STAGE	SCS_DEBUG_BASE+4

#define HID_DEBUG_BASE		(HID_TASK_PID<<4)
#define HID_DEBUG_ST_REQ	HID_DEBUG_BASE
#define HID_DEBUG_CS_REQ	HID_DEBUG_BASE+1
#define HID_DEBUG_DESC		HID_DEBUG_BASE+2
#define HID_DEBUG_ENDP		HID_DEBUG_BASE+3
#define HID_DEBUG_REPORT	HID_DEBUG_BASE+4

#define CCID_DEBUG_BASE		(CCID_TASK_PID<<4)
#define CCID_DEBUG_ST_REQ	CCID_DEBUG_BASE
#define CCID_DEBUG_CS_REQ	CCID_DEBUG_BASE+1
#define CCID_DEBUG_PC2RDR	CCID_DEBUG_BASE+2
#define CCID_DEBUG_RDR2PC	CCID_DEBUG_BASE+3
#define CCID_DEBUG_DESC		CCID_DEBUG_BASE+4
#define CCID_DEBUG_ENDP		CCID_DEBUG_BASE+5
#define CCID_DEBUG_SLOT		CCID_DEBUG_BASE+6
#define CCID_DEBUG_INTR		CCID_DEBUG_BASE+7
#define CCID_DEBUG_STATE	CCID_DEBUG_BASE+8

void CleanupLog(void);
VOID ProcessLog(void *ctx, DWORD dwRead);
void StartupLog(void);
DWORD LogSpace(void);
BYTE *LogPointer(void);

#define CMD_TASK_PID(cmd)	((cmd&0xF0) >> 4)
#define CMD_EVENT_ID(cmd)	(cmd&0x0F)

VOID ConsoleDump(VOID *ctx, BYTE bCmd, LPSTR szFormat, ...);
VOID WindowsDump(VOID *ctx, BYTE bCmd, LPSTR szFormat, ...);
LPCSTR GetTaskName(BYTE bCmd);
LPCSTR GetEventName(BYTE bCmd);
#endif
