#include "dumplog.h"

HANDLE g_hComFile = NULL;
DWORD g_dwLastError = 0;

static void DumpError(void)
{
	DWORD dwCurrError = GetLastError();

	if (dwCurrError != g_dwLastError) {
		g_dwLastError = dwCurrError;
		printf("<raw> ERROR: ");
		printf("%d", dwCurrError);
		printf("\r\n");
	}
}

void cleanup(void)
{
	CleanupLog();
	if (g_hComFile)
		CloseHandle(g_hComFile);

}

VOID ConsoleDump(VOID *ctx, BYTE bCmd, LPSTR szFormat, ...)
{
	FILE *pFile = (FILE *)ctx;
	va_list argList;
	char szBuf[1024];
	
	va_start(argList, szFormat );
	vsprintf(szBuf, szFormat, argList);
	va_end(argList);

	fprintf(pFile, "<%s> %s: ", GetTaskName(bCmd), GetEventName(bCmd));
	fprintf(pFile, "%s", szBuf);
	fprintf(pFile, "\r\n");
}

int main(int argc, char **argv)
{
	DCB dcb;

	atexit(cleanup);
	
	StartupLog();

opencom:
	while (1) {
		g_hComFile = CreateFile(argv[1], GENERIC_READ, 0,
					0, OPEN_EXISTING, 0, 0);
		if (g_hComFile == INVALID_HANDLE_VALUE) {
			DumpError();
			Sleep(1000 * 1);
		} else {
			ZeroMemory(&dcb, sizeof(DCB));
			dcb.DCBlength = sizeof(DCB);
			if (!GetCommState(g_hComFile, &dcb)) {
				DumpError();
				Sleep(1000 * 1);
				CloseHandle(g_hComFile);
				g_hComFile = NULL;
				goto opencom;
			} else {
				dcb.BaudRate = CBR_115200;
				dcb.ByteSize = 8;
				dcb.Parity = 0;
				dcb.StopBits = 0;
				if (!SetCommState(g_hComFile, &dcb)) {
					DumpError();
					Sleep(1000 * 1);
					CloseHandle(g_hComFile);
					g_hComFile = NULL;
					goto opencom;
				} else {
					goto readcom;
				}
			}
		}
	}

readcom:
	while (1) {
		DWORD dwRes;
		if (ReadFile(g_hComFile, LogPointer(),
			     LogSpace(), &dwRes, NULL) <= 0) {
			DumpError();
			Sleep(1000);
			CloseHandle(g_hComFile);
			g_hComFile = NULL;
			goto opencom;
		}

		ProcessLog(stdout, dwRes);
	}

	return 0;
}
