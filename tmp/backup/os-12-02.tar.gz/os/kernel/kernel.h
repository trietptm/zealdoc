#ifndef __KERNEL_PRIV_H__
#define __KERNEL_PRIV_H__

#include "type.h"
#include "const.h"
#include "protect.h"
#include "proto.h"
#include "global.h"

#endif /* __KERNEL_PRIV_H__ */

