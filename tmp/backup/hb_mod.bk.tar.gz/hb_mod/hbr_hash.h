#ifndef _HBR_HASH_H
#define _HBR_HASH_H

#include <linux/socket.h>
#include <linux/types.h>
#include <linux/list.h>

/* hw_type for extent, now support ethernet */
static inline unsigned int __hbr_client_hash(int ifindex, __be32 per, __be32 cli,
			unsigned int hw_hash, unsigned int hmask)
{
	unsigned int h = ifindex;

	h ^= ntohl(per ^ cli);

	h ^= hw_hash;

	h = (h ^ (h >> 16)) & hmask;
	return h;
}

static inline unsigned int __hbr_peer_hash(int ifindex, __be32 per, __be32 cli,
			unsigned int hmask)
{
	unsigned int h = ifindex;

	h ^= ntohl(per ^ cli);

	h = (h ^ (h >> 16)) & hmask;

	return h;
}

extern struct hlist_head *hbr_hash_alloc(unsigned int sz);
extern void hbr_hash_free(struct hlist_head *n, unsigned int sz);

#endif /* _HBR_HASH_H */
