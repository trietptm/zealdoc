#ifndef __HBR_PRIV_H_
#define __HBR_PRIV_H_

#include <linux/module.h>
#include <asm/uaccess.h>
#include <asm/system.h>
#include <linux/kernel.h>
#include <linux/netdevice.h>
#include <linux/in.h>
#include <linux/skbuff.h>
#include <linux/init.h>
#include <linux/netfilter_ipv4.h>
#include <linux/netfilter_arp.h>
#include <linux/mii.h>
#include <net/netlink.h>
#include <net/ip.h>
#include <net/dst.h>
#include <net/route.h>
#include <net/sock.h>
#include <net/ax25.h>
#include <net/arp.h>
#include <net/netevent.h>
#include <linux/if_vlan.h>

struct hbr_entry {
	unsigned int per_idx;	/* should be less than HBR_HASH_SIZE */
	unsigned int cli_idx;	/* should be less than HBR_HASH_SIZE */

	/* In kernel, we cannot get client's hw_addr
	 * unless get its packet with L2 header.
	 * So keep the hw_hash in kernel struct */
	unsigned int cli_hw_hash;

	struct net_device *ppp_dev;
	struct net_device *hbr_dev;
	/* only care hdr, if ppp device down, this link will be cut off */
	int hbr_dev_valid;	
#define HBR_DEV_VALID	1
#define HBR_DEV_INVALID	0

	__be32 peer;	/* isp's ip address */
	__be32 client;	/* public given ip address by isp */

	unsigned short vlan_id;

	struct rtable *rt_cli;
	struct rtable *rt_per;

	atomic_t refcnt;

	struct hlist_node byper;	/* for hbr_arp_hlist link */
	struct hlist_node bycli;	

};

/* public helper functions, netlink use them */
struct hbr_entry *hbr_convert_entry(struct hbr_trans_entry *e);
void hbr_dump_entrys(void);

int hbr_x_verify_entry(struct hbr_trans_entry *e);
void hbr_nl_free_entry(struct hbr_entry *e);
void hbr_x_put_entry(struct hbr_entry *e);
struct hbr_entry *hbr_x_get_entry(struct hbr_trans_entry *e);

int hbr_nl_init(void);
void hbr_nl_exit(void);

#endif /* __HBR_PRIV_H_ */

