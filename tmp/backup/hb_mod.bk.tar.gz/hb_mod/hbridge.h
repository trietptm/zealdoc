#ifndef __HALF_BRIDGE_H
#define __HALF_BRIDGE_H

#include <linux/socket.h> /* struct sockaddr */
#include <linux/if.h>	/* IFNAMSIZ */

#define HBR_PROXY_PEER		1
#define HBR_PROXY_CLIENT	2
/* trans -> transition, userland struct */
struct hbr_trans_entry {
	/* our client */
	struct sockaddr client_ip;
	struct sockaddr netmask;
	struct sockaddr cli_hw_addr;

	/* remote ISP */
	struct sockaddr peer_ip;

	int vlan_open;
	unsigned short vlan_id;

	/* TODO: Now will support both side are PPP connect. */
	/* BOX interface face to our client */
	char hbr_dev[IFNAMSIZ];	/* userland set it */
	/* BOX virtual interface which out/input client's packet. */
	char ppp_dev[IFNAMSIZ];	/* userland set it */
};

/* Types of entry, netlink is like message: HBRM_ */
enum {
	HBRM_BASE	= 16,
#define HBRM_BASE	HBRM_BASE
	
	HBRM_NEWHBR	= 16,
#define HBRM_NEWHBR	HBRM_NEWHBR
	HBRM_DELHBR,
#define HBRM_DELHBR	HBRM_DELHBR
	HBRM_GETHBR,
#define HBRM_GETHBR	HBRM_GETHBR

	__HBRM_MAX,
};
#define HBRM_MAX	(__HBRM_MAX - 1)

#define HBRM_NR_MSGTYPES (HBRM_MAX + 1 - HBRM_BASE)

/* attributes */
enum {
	HBRA_UNSPEC,
	HBRA_CIP,
	HBRA_PIP,
	HBRA_CHWADDR,
	HBRA_HBRDEV,
	HBRA_PPPDEV,

	__HBRA_MAX
};
#define HBRA_MAX (__HBRA_MAX - 1)

#endif /* __HALF_BRIDGE_H */

