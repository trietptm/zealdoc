#include "pcsc_priv.h"

DECLARE_LIST(pcsc_handle_list);
DECLARE_NOTIFY_CHAIN(pcsc_handle_chain);

#define for_each_slot(e)		\
	list_for_each_entry(pcsc_slot_t, e, &pcsc_handle_list, link)

#define for_each_slot_safe(e, n)		\
	list_for_each_entry_safe(pcsc_slot_t, e, n, &pcsc_handle_list, link)

#define PCSC_DETECT_TIMEOUT	4	/* second(s) */

static inline int __detect_icc_insert(pcsc_slot_t *hd);
static inline int __detect_icc_remove(pcsc_slot_t *hd);
static inline uint16_t __build_slot_idx(uint16_t r_idx, int s_idx);
static void __detect_icc(void *eloop, void *data);
static void __detect_icc_cb(pcsc_slot_t *hd);
static void __slot_free_stop(pcsc_slot_t *hd);
static void __slot_free_start(pcsc_slot_t *hd);
static void __slot_free_timeout(void *e, void *data);
static void __destroy_transfer(pcsc_transfer_t *trans);
static pcsc_transfer_t *__build_transfer(pcsc_slot_t *hd,
					 pcsc_appcmd_complete cb,
					 void *user_data);

static int pcsc_need_pps(pcsc_slot_t *slot);

static void pcsc_slot_start(pcsc_slot_t *hd);
static void pcsc_slot_stop(pcsc_slot_t *hd);
static void pcsc_slot_free(pcsc_slot_t *hd);

/* ifd ops */
static int ifd_slot_cancel(pcsc_slot_t *hd);
static int ifd_slot_icc_status(pcsc_slot_t *hd);
static int ifd_slot_power_off(pcsc_slot_t *hd);
static int ifd_slot_power_on(pcsc_slot_t *hd);
static int ifd_slot_xfr_block(pcsc_slot_t *hd, pcsc_transfer_t *t);
#ifdef NO_REF
static int ifd_slot_ifd_ctl(pcsc_slot_t *hd, pcsc_transfer_t *t);
#endif

/* icc ops */
static int icc_slot_create_file(pcsc_slot_t *, struct icc_file *filp,
				pcsc_trans_cb cb,  pcsc_transfer_t *);
static int icc_slot_read_record(pcsc_slot_t *, int rec_nr, uint8_t *rbuf,
				size_t rbuf_len, uint32_t flags,
				pcsc_trans_cb cb, pcsc_transfer_t *);
static int icc_slot_read_binary(pcsc_slot_t *, uint32_t offset, uint8_t *rbuf,
				size_t rbuf_len, uint32_t flags,
				pcsc_trans_cb cb, pcsc_transfer_t *);
static int icc_slot_select_file(pcsc_slot_t *, struct icc_path *,
				struct icc_file **, pcsc_trans_cb cb,
				pcsc_transfer_t *);
static int icc_slot_get_challenge(pcsc_slot_t *hd, uint8_t *random, size_t len,
				  pcsc_trans_cb cb, pcsc_transfer_t *);

static void pcsc_raise_event(pcsc_slot_t *rd_ctx, int event);

static void pcsc_stm_exit(void *eloop, void *user_ctx);

static void pcsc_stm_log(const stm_instance_t *fsmi,
			int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}


#define PCSC_STATE_INIT		0
#define PCSC_STATE_OPEN		1	/* slot opening */
#define PCSC_STATE_ABSENT	2	/* ICC absent */
#define PCSC_STATE_PWRDOWN	3	/* ICC PowerDown (not actived) */
#define PCSC_STATE_PWRON	4	/* ICC PowerOn(actived) */
#define PCSC_STATE_PPS		5	/* TODO */
#define PCSC_STATE_EXIT		6	

#define PCSC_STATE_COUNT	7

#define PCSC_STATE_NAMES {	\
	"INIT",			\
	"OPEN",			\
	"ABSENT",		\
	"POWERDOWN",		\
	"POWERON",		\
	"PPS",			\
	"EXIT",			\
}

#define PCSC_EVENT_RIS		0	/* Reader InSert */
#define PCSC_EVENT_RRM		1	/* Reader ReMove */
#define PCSC_EVENT_IOS		2	/* I/O Success */
#define PCSC_EVENT_IOF		3	/* I/O Failure */
#define PCSC_EVENT_CAS		4	/* Card Active Success - PwrOn OK */
#define PCSC_EVENT_CAF		5	/* Card Active Failure - PwrOn not OK */
#define PCSC_EVENT_CDS		6	/* Card Deactive Success - PwrOff OK */
#define PCSC_EVENT_CDF		7	/* Card Deactive Failure - PwrOff not OK */
#define PCSC_EVENT_CIS		8	/* Card InSert */	
#define PCSC_EVENT_CRM		9	/* Card ReMove */
#define PCSC_EVENT_PPS		10	/* nego pps */
#define PCSC_EVENT_SVF		11	/* Select Voltage Finish */

#define PCSC_EVENT_COUNT	12

#define PCSC_EVENT_NAMES {	\
	"RIS",			\
	"RRM",			\
	"IOS",			\
	"IOF",			\
	"CAS",			\
	"CAF",			\
	"CDS",			\
	"CDF",			\
	"CIS",			\
	"CRM",			\
	"PPS",			\
	"SVF",			\
}

/* its not same as ICC status. */
const char *pcsc_slot_status_str(pcsc_slot_t *slot)
{
	if ((slot && slot->fsmi) == 0)
		return "unnormal";

	switch (slot->fsmi->state) {
	case PCSC_STATE_INIT: return "init";
	case PCSC_STATE_OPEN: return "open";
	case PCSC_STATE_ABSENT: return "absent";
	case PCSC_STATE_PWRDOWN: return "pwrdown";
	case PCSC_STATE_PWRON: return "pwron";
	case PCSC_STATE_PPS: return "pps";
	case PCSC_STATE_EXIT: return "exit";
	default:
		return "unknown";
	}
}

static void pcsc_raise_event(pcsc_slot_t *slot, int event)
{
	if (slot->fsmi)
		eloop_schedule_event(NULL, slot->fsmi, event, slot);
}

static void pcsc_raise_ris(pcsc_slot_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_RIS);
}

static void pcsc_raise_rrm(pcsc_slot_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_RRM);
}

static void pcsc_raise_ios(pcsc_slot_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_IOS);
}

static void pcsc_raise_iof(pcsc_slot_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_IOF);
}

static void pcsc_raise_cas(pcsc_slot_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_CAS);
}

static void pcsc_raise_caf(pcsc_slot_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_CAF);
}

static void pcsc_raise_cds(pcsc_slot_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_CDS);
}
static void pcsc_raise_cdf(pcsc_slot_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_CDF);
}

static void pcsc_raise_cis(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_CIS);
}

static void pcsc_raise_crm(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_CRM);
}

static void pcsc_raise_pps(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_PPS);
}

static void pcsc_raise_svf(pcsc_slot_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_SVF);
}


static int pcsc_action_init(stm_instance_t *fsmi, void *data)
{
	pcsc_raise_ios(data);
	return 1;
}

/* Set Oldstatus to Absent to receive CIS event */
static int pcsc_action_soa(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *slot = (pcsc_slot_t *)data;
	
	slot->old_icc_status = PCSC_ICC_ABSENT;
	pcsc_log(PCSC_LOG_INFO, "forse set status to Absent");
	return 1;
}

/* Set Oldstatus to PwrDown to avoid receive CIS event.
 *
 * Making slot with a non-PwrOn card may in the status that 
 * waiting for life cryle finish(remove the card from the slot).
 */
static int pcsc_action_sod(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *slot = (pcsc_slot_t *)data;
	slot->old_icc_status = PCSC_ICC_PRESENT_POWERDOWN;
	pcsc_log(PCSC_LOG_INFO, "forse set status to Pwrdown");
	return 1;
}

/* Need PPS */
static int pcsc_action_npps(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *slot = (pcsc_slot_t *)data;

	if (pcsc_need_pps(slot))
		pcsc_raise_pps(slot);
	return 1;
}

/* Do PPS */
static int pcsc_action_pps(stm_instance_t *fsmi, void *data)
{
#if 0
	pcsc_slot_t *slot = (pcsc_slot_t *)data;

	/* 1) stop __detect_icc since 7816-3 says 0xFF is the 1st character if do PPS */
	eloop_cancel_timeout(NULL, __detect_icc, NULL, hd);
	eloop_register_timeout(NULL, PCSC_DETECT_TIMEOUT, 0, __detect_icc, NULL, hd);
#endif
	return 0;
}

/* Updata Voltage Select */
static int pcsc_action_uvs(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *slot = (pcsc_slot_t *)data;

	/* next select voltage */
	slot->icc->voltage_id++;
	return 1;
}

static int pcsc_action_close(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *slot = (pcsc_slot_t *)data;

	pcsc_icc_down(slot->icc);
	pcsc_notify(PCSC_ICC_REMOVE, slot);

	return 1;
}

static int pcsc_action_erc(stm_instance_t *fsmi, void *data)
{
	eloop_register_timeout(NULL, 0, 0, 
		pcsc_stm_exit, NULL, data);
	return 1;
}

static void power_off_complete(pcsc_slot_t *slot)
{
	/* FIXME: need 10 milliseconds timeout? ISO7816-4 6.2.4 */
	if (slot->ret != PCSC_S_SUCCESS) {
		pcsc_raise_cdf(slot);
	} else {
		pcsc_raise_cds(slot);
	}
}

static void power_on_complete(pcsc_slot_t *slot)
{
	struct pcsc_atr_info atr_info;

	/* fail or ATR unnormal will raise IAF(ICC Active Failure)
	 * else will raise IAS.
	 */
	if (slot->ret < 0) {
		pcsc_raise_caf(slot);
		pcsc_log(PCSC_LOG_INFO, "power on fail 1");
	} else {
		slot->icc->atr_len = slot->ret;
		/* why? */
		if (slot->icc->atr_len == 0) {
			pcsc_raise_caf(slot);
			pcsc_log(PCSC_LOG_INFO, "power on fail 2");
			return;
		}

		if (pcsc_parse_atr(slot->icc->atr, slot->icc->atr_len, &atr_info) == PCSC_S_SUCCESS) {
			slot->icc->proto_default = atr_info.default_proto;
			slot->icc->proto_supported = atr_info.supported_protos;

			pcsc_log(PCSC_LOG_INFO, "card power on success, receive ATR");

			if (slot->icc->proto_supported & PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_INFO, "support protocol: T0");
			if (slot->icc->proto_supported & PCSC_PROTOCOL_T1)
				pcsc_log(PCSC_LOG_INFO, "support protocol: T1");

			if (slot->icc->proto_default == PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_INFO, "default/current protocol: T0");
		} else {
			slot->icc->proto_default = PCSC_PROTOCOL_UNKNOWN;
			slot->icc->proto_supported = PCSC_PROTOCOL_UNKNOWN;
		}
		
		pcsc_raise_cas(slot);
		/* for next time */
		slot->icc->voltage_id = 0;
		if (pcsc_icc_up(slot->icc)) {
			pcsc_log(PCSC_LOG_ERR, "not support icc up failure");
			BUG();
		}
		pcsc_notify(PCSC_ICC_INSERT, slot);
	}
}

/* PwrOff ICC to deactive it */
static int pcsc_action_off(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *slot = (pcsc_slot_t *)data;
	int r;

	slot->cb = power_off_complete;

	r = ifd_slot_power_off(slot);

	if (r != PCSC_S_SUCCESS)
		pcsc_raise_iof(slot);
	else
		pcsc_raise_ios(slot);
	return 1;
}

/* PwrOn ICC to get active it and may get ATR */
static int pcsc_action_on(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *slot = (pcsc_slot_t *)data;
	int r;

	slot->cb = power_on_complete;

	r = ifd_slot_power_on(slot);

	if (r != PCSC_S_SUCCESS) {
		/* exceed range */
		if (r == PCSC_E_INVALID_PARAMETER) {
			pcsc_log(PCSC_LOG_INFO, "arrive last select Voltage");
			pcsc_raise_svf(slot);
			/* for next time */
			slot->icc->voltage_id = 0;
		} else if (r == PCSC_E_INVALID_VOLTAGE) {
			/* reader not supp this vol, change a next one */
			pcsc_raise_caf(slot);
		} else
			pcsc_raise_iof(slot);
	} else
		pcsc_raise_ios(slot);
	return 1;
}

static int pcsc_action_null(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static const stm_action_fn pcsc_act_init [] = {
	pcsc_action_init,
};

static const stm_action_fn pcsc_act_erc [] = {
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_close [] = {
	pcsc_action_close,
};

static const stm_action_fn pcsc_act_close_erc [] = {
	pcsc_action_close,
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_on [] = {
	pcsc_action_on,
};

static const stm_action_fn pcsc_act_off [] = {
	pcsc_action_off,
};

static const stm_action_fn pcsc_act_uvs_soa [] = {
	pcsc_action_uvs,
	pcsc_action_soa,
};

static const stm_action_fn pcsc_act_soa [] = {
	pcsc_action_soa,
};

static const stm_action_fn pcsc_act_sod [] = {
	pcsc_action_sod,
};

static const stm_action_fn pcsc_act_npps [] = {
	pcsc_action_npps,
};

static const stm_action_fn pcsc_act_pps [] = {
	pcsc_action_pps,
};

static const stm_action_fn pcsc_act_null [] = {
	pcsc_action_null,
};

#define STATE(state)	PCSC_STATE_##state
#define EVENT(event)	PCSC_EVENT_##event
#define ACTION(stem)	pcsc_act_##stem, \
			sizeof(pcsc_act_##stem) / sizeof(stm_action_fn) 

/* TODO: what to do when get IOF event */
static const stm_entry_t pcsc_stm_entries[] = {
	/* state	event		action			new_state */
	{STATE(INIT),	EVENT(RIS),	ACTION(init),		STATE(OPEN),},

	{STATE(OPEN),	EVENT(IOS),	ACTION(null),		STATE(ABSENT),},
	{STATE(OPEN),	EVENT(IOF),	ACTION(erc),		STATE(EXIT),},

	{STATE(ABSENT),	EVENT(CIS),	ACTION(on),		STATE(PWRDOWN),},
	{STATE(ABSENT),	EVENT(RRM),	ACTION(erc),		STATE(EXIT),},

	{STATE(PWRDOWN),EVENT(IOS),	ACTION(null),		STATE(PWRDOWN),},
	{STATE(PWRDOWN),EVENT(IOF),	ACTION(erc),		STATE(EXIT),},
	{STATE(PWRDOWN),EVENT(CAS),	ACTION(npps),		STATE(PWRON),},
	{STATE(PWRDOWN),EVENT(CAF),	ACTION(off),		STATE(PWRDOWN),},
	{STATE(PWRDOWN),EVENT(CDS),	ACTION(uvs_soa),	STATE(ABSENT),},
	{STATE(PWRDOWN),EVENT(CDF),	ACTION(erc),		STATE(EXIT),},
	{STATE(PWRDOWN),EVENT(CRM),	ACTION(null),		STATE(ABSENT),},
	{STATE(PWRDOWN),EVENT(RRM),	ACTION(erc),		STATE(EXIT),},
	{STATE(PWRDOWN),EVENT(SVF),	ACTION(sod),		STATE(PWRDOWN),},

	{STATE(PWRON),	EVENT(PPS),	ACTION(pps),		STATE(PPS),},
	{STATE(PWRON),	EVENT(CRM),	ACTION(close),		STATE(ABSENT),},
	{STATE(PWRON),	EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(PPS),	EVENT(CRM),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(PPS),	EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{0,		0,		NULL,			0,},
};

static const char *pcsc_state_names[] = PCSC_STATE_NAMES;
static const char *pcsc_event_names[] = PCSC_EVENT_NAMES;

const stm_table_t pcsc_stm_table = {
	"PCSC",
	pcsc_stm_log,
	PCSC_STATE_COUNT,
	&pcsc_state_names[0],
	PCSC_EVENT_COUNT,
	&pcsc_event_names[0],
	pcsc_stm_entries,	
};

#undef STATE
#undef EVENT
#undef ACTION

static void pcsc_stm_exit(void *eloop, void *user_ctx) 
{
	pcsc_slot_t *rd_ctx = (pcsc_slot_t *)user_ctx;

	if (rd_ctx->fsmi) {
		eloop_delete_automaton(rd_ctx->fsmi);
		rd_ctx->fsmi = NULL;
	}

}

/* determine whether need pps at host-side */
static int pcsc_need_pps(pcsc_slot_t *slot)
{
	int need = 0;

	/* reader do it, neednt */
	if (slot->ifd->voltage & PCSC_CLASS_AUTO)
		goto out;

	/* icc only support one protocol, neednt */
	if (slot->icc->proto_supported == PCSC_PROTOCOL_T0)
		goto out;
	/* ifd only support one protocol, neednt */
	if (slot->ifd->protocol == PCSC_PROTOCOL_T0)
		goto out;
	
	need = 1;
out:
	pcsc_log(PCSC_LOG_INFO, "need %s pps", need ? NULL : "not");
	return need;
}

static inline uint16_t __build_slot_idx(uint16_t rdr_idx, int slot_idx)
{
	return (uint16_t)(rdr_idx << 8 | slot_idx);
}

pcsc_slot_t *pcsc_internel_first_slot(void)
{
	pcsc_slot_t *s;

	for_each_slot(s) {
		return s;
	}
	return NULL;
}

pcsc_slot_t *pcsc_get_slot_by_icc_name(const char *name)
{
	pcsc_slot_t *hd;
	for_each_slot(hd) {
		if (strcasecmp(hd->icc->drv->name, name) == 0)
			return pcsc_slot_get(hd);
	}
	return NULL;
}

pcsc_slot_t *pcsc_slot_by_icc(pcsc_icc_t *icc, int get)
{
	pcsc_slot_t *hd;
	for_each_slot(hd) {
		if (hd->icc == icc) {
			if (get)
				return pcsc_slot_get(hd);
			else
				return (hd);
		}
	}
	return NULL;
}

uint16_t pcsc_idx_by_iccidx(uint16_t iccidx)
{
	pcsc_slot_t *slot;

	for_each_slot(slot) {
		if (slot->icc->idx == iccidx)
			return slot->idx;
	}
	return 0xFFFF;
}

static void __slot_free_timeout(void *e, void *data)
{
	pcsc_slot_t *hd = (pcsc_slot_t *)data;

	if (hd->fsmi == NULL &&
	    atomic_read(&hd->refcnt) == 1) {
		__slot_free_stop(hd);
		pcsc_slot_free(hd);
	} else
		__slot_free_start(hd);
}

static void __slot_free_start(pcsc_slot_t *hd)
{
	eloop_register_timeout(NULL, 1, 0, __slot_free_timeout, NULL, hd);
}

static void __slot_free_stop(pcsc_slot_t *hd)
{
	eloop_cancel_timeout(NULL, __slot_free_timeout, NULL, hd);
}

void *pcsc_slot_reader(pcsc_slot_t *slot)
{
	return slot->ifd->lower;
}

pcsc_slot_t *pcsc_slot_new(pcsc_ifd_t *rdr, int slot_idx)
{
	pcsc_slot_t *slot;

	slot = malloc(sizeof (pcsc_slot_t));
	if (!slot)
		goto err;

	memset(slot, 0, sizeof (pcsc_slot_t));

	slot->fsmi = eloop_create_automaton(&pcsc_stm_table, rdr->name, 
					  PCSC_STATE_INIT);
	if (!slot->fsmi)
		goto err;

	slot->idx = __build_slot_idx(rdr->idx, slot_idx);
	slot->old_icc_status = PCSC_ICC_ABSENT;

	list_init(&slot->link);
	list_insert_before(&slot->link, &pcsc_handle_list);
	atomic_set(&slot->refcnt, 1);

	/* slot_start will get reader */
	slot->ifd = (rdr);
	slot->icc = pcsc_icc_new(slot->idx);

	pcsc_notify(PCSC_SLOT_ADD, slot);
	return slot;
err:
	if (slot)
		free(slot);
	return NULL;
}

static void pcsc_slot_free(pcsc_slot_t *hd)
{
	pcsc_notify(PCSC_SLOT_DEL, hd);
	if (hd->icc)
		pcsc_icc_free(hd->icc);
	list_delete(&hd->link);
	free(hd);
}

void pcsc_slot_free_all(pcsc_ifd_t *ifd)
{
	pcsc_slot_t *hd, *n;
	
	for_each_slot_safe(hd, n) {
		if (hd->ifd != ifd)
			continue;
		__slot_free_start(hd);
	}
}

void pcsc_start_by_ifd(pcsc_ifd_t *ifd)
{
	pcsc_slot_t *hd;
	for_each_slot(hd) {
		if (ifd == hd->ifd)
			pcsc_slot_start(hd);
	}
}

void pcsc_stop_by_ifd(pcsc_ifd_t *ifd)
{
	pcsc_slot_t *hd;
	for_each_slot(hd) {
		if (ifd == hd->ifd)
			pcsc_slot_stop(hd);
	}
}

void pcsc_get_feature(pcsc_ifd_t *ifd)
{
	pcsc_slot_t *slot;

	for_each_slot(slot) {
		/* may get fill ifd feature in desc->dwFeature */
		if (ifd == slot->ifd && ifd->drv->get_feature) {
			ifd->drv->get_feature(slot);
			/* only once */
			break;
		}
	}
}

static void pcsc_slot_start(pcsc_slot_t *hd)
{
	eloop_register_timeout(NULL, PCSC_DETECT_TIMEOUT, 0, __detect_icc, NULL, hd);
	pcsc_ifd_get(hd->ifd);

	/* sm start - reader insert event */
	pcsc_raise_ris(hd);
}

static void pcsc_slot_stop(pcsc_slot_t *hd)
{
	eloop_cancel_timeout(NULL, __detect_icc, NULL, hd);
	pcsc_ifd_put(hd->ifd);

	/* sm stop - reader remove event */
	pcsc_raise_rrm(hd);
}

static void __detect_icc_cb(pcsc_slot_t *hd)
{
#define notpresent(s)	\
	((s) == PCSC_ICC_ABSENT)
#define present(s)	\
	(((s) == PCSC_ICC_PRESENT_POWERUP) || ((s) == PCSC_ICC_PRESENT_POWERDOWN))

	/* XXX: we are outer and slot does not notify his sm dead. */
	if (!hd->fsmi)
		return;
	if (hd->icc->status != hd->old_icc_status) {
		pcsc_log(PCSC_LOG_INFO, "IFD: icc state changed, %s/%d -> %s/%d",
			 pcsc_card_status_str(hd->old_icc_status), hd->old_icc_status,
			 pcsc_card_status_str(hd->icc->status), hd->icc->status);

		if (notpresent(hd->old_icc_status) && present(hd->icc->status))
			__detect_icc_insert(hd);
		else if (notpresent(pcsc_icc_status(hd->icc)))
			__detect_icc_remove(hd);
		/* record new status */
		hd->old_icc_status = hd->icc->status;
	}
}

static void __detect_icc(void *eloop, void *data)
{
	pcsc_slot_t *hd = (pcsc_slot_t *)data;

	/* XXX: somebody who in slot SM may grab this callback.
	 * But it doesnt matter we dont mind.
	 * And this thing in the SM never occur as its state machine.
	 * */
	hd->cb = __detect_icc_cb;
	pcsc_log(PCSC_LOG_DEBUG, "IFD: icc state detect");
	ifd_slot_icc_status(hd);

	eloop_register_timeout(NULL, PCSC_DETECT_TIMEOUT, 0, __detect_icc, NULL, hd);
}

static inline int __detect_icc_insert(pcsc_slot_t *hd)
{
	pcsc_raise_cis(hd);
	return PCSC_S_SUCCESS;
}

static inline int __detect_icc_remove(pcsc_slot_t *hd)
{
	pcsc_raise_crm(hd);
	return PCSC_S_SUCCESS;
}

/* icc / ifd ops */
static int ifd_slot_cancel(pcsc_slot_t *hd)
{
	return pcsc_ifd_ops(hd)->cancel(hd);
}

static int ifd_slot_icc_status(pcsc_slot_t *hd)
{
	return pcsc_ifd_ops(hd)->icc_status(hd);	
}

static int ifd_slot_power_off(pcsc_slot_t *hd)
{
	return pcsc_ifd_ops(hd)->power_off(hd);	
}

static int ifd_slot_power_on(pcsc_slot_t *hd)
{
	return pcsc_ifd_ops(hd)->power_on(hd);	
}

static int ifd_slot_xfr_block(pcsc_slot_t *hd, pcsc_transfer_t *p)
{
	return pcsc_ifd_ops(hd)->xfr_block(hd, p);	
}

static int pcsc_voltage_valid(pcsc_slot_t *hd, int id);

#ifdef NO_REF
static int ifd_slot_ifd_ctl(pcsc_slot_t *hd, pcsc_transfer_t *p)
{
	return pcsc_ifd_ops(hd)->ifd_ctl(hd, p);	
}
#endif

static int icc_slot_create_file(pcsc_slot_t *hd, struct icc_file *filp,
				pcsc_trans_cb cb,  pcsc_transfer_t *trans)
{
	icc_driver_ops_t *ops;
	
	if (!hd->icc->drv)
		return -1;

	ops = pcsc_icc_ops(hd);
	if (ops && ops->create_file)
		return ops->create_file(hd, filp, cb, trans);
	return -1;
}

static int icc_slot_read_record(pcsc_slot_t *hd, int rec_nr,
			      uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
			      pcsc_trans_cb cb, pcsc_transfer_t *card_param)
{
	icc_driver_ops_t *ops;
	
	if (!hd->icc->drv)
		return -1;

	ops = pcsc_icc_ops(hd);
	if (ops && ops->read_record)
		return ops->read_record(hd, rec_nr, rbuf, rbuf_len, flags, cb, card_param);
	return -1;
}

static int icc_slot_read_binary(pcsc_slot_t *hd, uint32_t offset,
			      uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
			      pcsc_trans_cb cb, pcsc_transfer_t *card_param)
{
	icc_driver_ops_t *ops;
	
	if (!hd->icc->drv)
		return -1;
	ops = pcsc_icc_ops(hd);
	if (ops && ops->read_binary)
		return ops->read_binary(hd, offset, rbuf, rbuf_len, flags, cb, card_param);
	return -1;
}

static int icc_slot_get_challenge(pcsc_slot_t *hd,
				  uint8_t *ran, size_t len,
				  pcsc_trans_cb cb, pcsc_transfer_t *card_param)
{
	icc_driver_ops_t *ops;
	
	if (!hd->icc->drv)
		return -1;
	ops = pcsc_icc_ops(hd);
	if (ops && ops->get_challenge)
		return ops->get_challenge(hd, ran, len, cb, card_param);
	return -1;
}

static int icc_slot_select_file(pcsc_slot_t *hd, struct icc_path *in_path,
			      struct icc_file **file_out, 
			      pcsc_trans_cb cb, pcsc_transfer_t *trans)
{
	icc_driver_ops_t *ops;
	
	if (!hd->icc->drv)
		return -1;

	ops = pcsc_icc_ops(hd);
	if (ops && ops->select_file)
		return ops->select_file(hd, in_path, file_out, cb, trans);
	return -1;
}

pcsc_slot_t *pcsc_slot_get(pcsc_slot_t *hd)
{
	if (hd)
		atomic_inc(&hd->refcnt);
	return hd;
}

void pcsc_slot_put(pcsc_slot_t *hd)
{
	if (hd)	atomic_dec(&hd->refcnt);
}

void pcsc_slot_lock_put(pcsc_slot_t *hd)
{
	pcsc_notify(PCSC_SLOT_UNLOCK, hd);
	hd->locked = 0;
	pcsc_slot_put(hd);
}

uint16_t pcsc_slot_idx(pcsc_slot_t *slot)
{
	return slot->idx;
}

static inline void for_each_idle_slot(pcsc_slot_t *slot)
{
	for_each_slot(slot) {
		if (!slot->locked)
			return;
	}
	slot = NULL;
	return;
}

/* Return card on slot idx if comp is 1.
 * Return any exist slot idx if comp is 0.
 * XXX: we only care unlocked slot.
 *
 * return the first fixed slot->idx if @idx is PCSC_VALID_IDX,
 * otherwise return the next one
 */
static uint16_t __next_idle_slot(uint16_t idx, int comp)
{
	pcsc_slot_t *slot;
	int next = 0;

	for_each_slot(slot) {
		if (slot->locked)
			continue;

		if (idx == PCSC_VALID_IDX) {
			if (!comp ||
			    slot->icc->status == PCSC_ICC_PRESENT_POWERUP)
				return slot->idx;
		} else {
			if (slot->idx == idx)
				next = 1;
			if (next && 
			    (!comp ||
			     slot->icc->status == PCSC_ICC_PRESENT_POWERUP))
				return slot->idx;
		}
	}
	return PCSC_VALID_IDX;
}

uint16_t pcsc_next_present_unlock_slot(uint16_t idx)
{
	return __next_idle_slot(idx, 1);
}

uint16_t pcsc_next_unlock_slot(uint16_t idx)
{
	return __next_idle_slot(idx, 0);	
}

pcsc_slot_t *pcsc_slot_lock_get_by_idx(uint16_t idx)
{
	pcsc_slot_t *hd = pcsc_handle_get_by_idx(idx);
	if (hd) {
		if (hd->locked)
			goto locked;
		hd->locked = 1;
		pcsc_notify(PCSC_SLOT_LOCK, hd);

		return hd;
	}
locked:
	if (hd) pcsc_slot_put(hd);
	return NULL;
}

pcsc_slot_t *pcsc_handle_get_by_idx(uint16_t idx)
{
	pcsc_slot_t *hd;
	for_each_slot(hd) {
		if (hd->idx == idx)
			return pcsc_slot_get(hd);
	}
	return NULL;
}

uint8_t pcsc_slot_cap(pcsc_slot_t *slot)
{
	uint8_t cap = 0;
	if (slot->ifd->display)
		cap |= PCSC_SLOT_CAP_DISPLAY;
	if (slot->ifd->keypad)
		cap |= PCSC_SLOT_CAP_PIN_PAD;
	return cap;
}

/* refresh apdu bytes */
int pcsc_sync_apdu(pcsc_transfer_t *trans)
{
	int r = icc_check_apdu(trans->handle, trans->icc_param->apdu);
	size_t sbuf_len;

	if (r != ICC_SUCCESS)
		return r;

	sbuf_len = icc_apdu_get_length(trans->icc_param->apdu, trans->handle->icc->proto_default);
	if (sbuf_len != trans->ifd_param->sbuf_len) {
		free(trans->ifd_param->sbuf);

		trans->ifd_param->sbuf = malloc(sbuf_len);
		if (NULL == trans->ifd_param->sbuf)
			return -1;
		trans->ifd_param->sbuf_len = sbuf_len;
	}

	return icc_apdu2bytes(trans->icc_param->apdu, 
			      trans->handle->icc->proto_default, 
			      trans->ifd_param->sbuf,
			      trans->ifd_param->sbuf_len);
}

int pcsc_trans_proto(pcsc_transfer_t *t)
{
	return t->handle->icc->proto_default;
}

struct icc_apdu *pcsc_trans_apdu(pcsc_transfer_t *trans)
{
	return trans->icc_param->apdu;
}

int pcsc_transmit_from_icc(pcsc_transfer_t *trans, pcsc_trans_cb cb)
{
	pcsc_icc_trans_param *icc_param = trans->icc_param;

	uint8_t *rbuf = NULL;
	size_t rbuf_len;
	int r;

	r = ifd_build_param(trans, cb);
	if (r)
		return -1;

	rbuf_len = icc_param->apdu->rx_buflen < 256 ? 
			258 : icc_param->apdu->rx_buflen + 2;
	
	rbuf = malloc(rbuf_len);
	if (!rbuf) {
		return ICC_ERR_NO_MEM;
	}

	trans->rbuf = rbuf;		/* receive IFD response */
	trans->rbuf_len = rbuf_len;	/* max receive length */

	return pcsc_transmit(trans);
}

int pcsc_transmit(pcsc_transfer_t *trans)
{
	return ifd_slot_xfr_block(trans->handle, trans);
}

int pcsc_fetch_sw(pcsc_transfer_t *trans)
{
	uint8_t *rbuf;
	size_t rbuf_actual;
	int r = 0;
	pcsc_icc_trans_param *icc_trans = trans->icc_param;
	pcsc_ifd_trans_param *ifd_trans = trans->ifd_param;

	BUG_ON(!icc_trans || !ifd_trans);

	rbuf = trans->rbuf;
	rbuf_actual = trans->rbuf_actual;

	if (rbuf_actual < 2) {
		r = ICC_ERR_COMMUNICATION;
		goto ret;
	}

	icc_trans->apdu->sw1 = rbuf[rbuf_actual - 2];
	icc_trans->apdu->sw2 = rbuf[rbuf_actual - 1];

ret:
	return r;
}

/* fetch and check sw1,sw2 */
int pcsc_fetch_check_sw(pcsc_transfer_t *trans)
{
	int r = 0;

	r = pcsc_fetch_sw(trans);
	if (r != 0)
		return r;

	r = icc_check_sw(trans->handle->icc,
			 trans->icc_param->apdu->sw1,
			 trans->icc_param->apdu->sw2);

	if (r != ICC_CHECK_SW_FAIL)
		return r;
	
	return iso7816_check_sw(trans->handle->icc,
				trans->icc_param->apdu->sw1,
				trans->icc_param->apdu->sw2);
}

/* read_binary can share this */
static void __pcsc_cmd_common_cb(pcsc_transfer_t *trans)
{
	/* reach here, we don't need care icc param reclaim, thats by itself */
	if (trans) {
		if (trans->ret < ICC_SUCCESS)
			pcsc_log(PCSC_LOG_ERR, "SLOT: transfer fail");
		else
			pcsc_log(PCSC_LOG_DEBUG, "SLOT: transfer succ");
		
		if (trans->callback)
			trans->callback(trans->user_data, trans->ret);

		ifd_destroy_param(trans->ifd_param);

		__destroy_transfer(trans);
	}
}

/* APPLICATION API */

/* Note: doesnt know rbuf length and alloc it in future
 * but remember free it */
static pcsc_transfer_t *__build_transfer(pcsc_slot_t *hd, 
					 pcsc_appcmd_complete cb,
					 void *user_data)
{
	pcsc_transfer_t *trans = malloc(sizeof (pcsc_transfer_t));
	if (!trans)
		return NULL;

	memset(trans, 0, sizeof (pcsc_transfer_t));
	trans->callback = cb;
	trans->user_data = user_data;
	trans->ret = -1;
	trans->handle = hd;

	return trans;
}

static void __destroy_transfer(pcsc_transfer_t *trans)
{
	if (trans) {
		if (trans->rbuf) free(trans->rbuf);
		free(trans);
	}
}

/* PCSC API for user */
int pcsc_select_file(pcsc_slot_t *hd, struct icc_path *path,
		     struct icc_file **file_out,
		     pcsc_appcmd_complete cb, void *user_data)
{
	int ret;
	pcsc_transfer_t *trans = NULL;

	if (!hd)
		return -1;

	ret = icc_check_path(path);
	if (ret != 0)
		goto err;

	trans = __build_transfer(hd, cb, user_data);

	ret = icc_slot_select_file(hd, path, file_out, 
				 __pcsc_cmd_common_cb, trans);

	if (ret != 0)
		cb(user_data, ret);
	else
		goto out;
err:
	if (trans) __destroy_transfer(trans);
out:
	return ret;
}


int pcsc_create_file(pcsc_slot_t *hd, struct icc_file *filp,
		     pcsc_appcmd_complete cb, void *user_data)
{
	int ret;
	pcsc_transfer_t *trans;

	if (!hd)
		return -1;

	trans = __build_transfer(hd, cb, user_data);
	if (!trans)
		return -1;
	
	ret = icc_slot_create_file(hd, filp,
			__pcsc_cmd_common_cb, trans);
	if (ret != 0) {
		cb(user_data, ret);
		goto err;
	}
	return ret;
err:
	if (trans) __destroy_transfer(trans);
	return ret;

}

int pcsc_read_record(pcsc_slot_t *hd, int rec_nr,
		     uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
		     pcsc_appcmd_complete cb, void *user_data)
{
	int ret;
	pcsc_transfer_t *trans;

	if (!hd)
		return -1;

	trans = __build_transfer(hd, cb, user_data);
	if (!trans)
		return -1;

	ret = icc_slot_read_record(hd, rec_nr, rbuf, rbuf_len, flags,
				   __pcsc_cmd_common_cb, trans);

	if (ret != 0) {
		cb(user_data, ret);
		goto err;
	}
	return ret;
err:
	if (trans) __destroy_transfer(trans);
	return ret;
}

int pcsc_read_binary(pcsc_slot_t *hd, uint16_t offset,
		     uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
		     pcsc_appcmd_complete cb, void *user_data)
{
	int ret;
	pcsc_transfer_t *trans;

	if (!hd)
		return -1;

	trans = __build_transfer(hd, cb, user_data);
	if (!trans)
		return -1;

	ret = icc_slot_read_binary(hd, offset, rbuf, rbuf_len, flags,
				   __pcsc_cmd_common_cb, trans);

	if (ret != 0) {
		cb(user_data, ret);
		goto err;
	}
	return ret;
err:
	if (trans) __destroy_transfer(trans);
	return ret;
}

int pcsc_get_challenge(pcsc_slot_t *slot,
		       uint8_t *rnd, size_t rnd_len,
		       pcsc_appcmd_complete cb, void *cbarg)
{
	int ret;
	pcsc_transfer_t *trans;

	if (!slot)
		return -1;

	trans = __build_transfer(slot, cb, cbarg);
	if (!trans)
		return -1;

	ret = icc_slot_get_challenge(slot, rnd, rnd_len,
				     __pcsc_cmd_common_cb, trans);
	if (ret != 0) {
		cb(cbarg, ret);
		goto err;
	}
	return ret;
err:
	if (trans) __destroy_transfer(trans);
	return ret;
}

int pcsc_pin_cmd(pcsc_slot_t *hd, struct icc_pin_cmd_data *data, int *tries_left,
		 pcsc_appcmd_complete cb, void *cbarg)
{
	return -1;
}

void pcsc_lower_noneed_transfer(pcsc_transfer_t *trans)
{
	if (trans->callback)
		trans->callback(trans->user_data, trans->ret);
	
	ifd_destroy_param(trans->ifd_param);
	
	__destroy_transfer(trans);
}

pcsc_transfer_t *
pcsc_lower_need_transfer(pcsc_slot_t *hd,
			 pcsc_appcmd_complete cb,
			 void *user_data)
{
	pcsc_transfer_t *trans;

	if (!hd)
		return NULL;

	trans = __build_transfer(hd, cb, user_data);
	if (!trans)
		return NULL;
	return trans;
}

int pcsc_register_notify(notify_t *nb)
{
	pcsc_slot_t *hd;
	pcsc_slot_t *last;
	int err;

	err = register_notify_chain(&pcsc_handle_chain, nb);
	if (err)
		goto unlock;

	for_each_slot(hd) {
		err = nb->call(nb, PCSC_REGISTER, hd);
		err = notify_to_errno(err);
		if (err)
			goto rollback;
	}
unlock:
	return err;
rollback:
	last = hd;
	for_each_slot(hd) {
		if (hd == last)
			break;
		nb->call(nb, PCSC_UNREGISTER, hd);
	}
	goto unlock;
}

void pcsc_unregister_notify(notify_t *nb)
{
	unregister_notify_chain(&pcsc_handle_chain, nb);
}

int pcsc_notify(unsigned long val, void *v)
{
	return call_notify_chain(&pcsc_handle_chain, val, v);
}

static int pcsc_slot_cmd_dump(ui_session_t *sess, ui_entry_t *inst,
			     void *ctx, int argc, char **argv)
{
	pcsc_slot_t *hd;
	ui_table_t *table = ui_table_by_name(sess, "pcsc_handle_list");
	char buf[25] = "";
	int i = 0;

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "pcsc_handle_list");
	if (!table)
		return -1;

	ui_add_title(table, 0, "index");
	ui_add_title(table, 1, "reader");
	/* show slot state machine status */
	ui_add_title(table, 2, "slot");
	ui_add_title(table, 3, "card");
	ui_add_title(table, 4, "lock");

	i = 0;

	for_each_slot(hd) {
		snprintf(buf, sizeof(buf), "%04x", hd->idx);
		ui_add_value(table, "index", i, buf);
		ui_add_value(table, "reader", i, hd->ifd->name);
		snprintf(buf, sizeof(buf), "%02x", (hd->idx & 0x00FF));
		ui_add_value(table, "slot", i, buf);
		ui_add_value(table, "card", i, pcsc_slot_status_str(hd));
		ui_add_value(table, "lock", i, hd->locked ? "on" : "off");
		i++;
	}

	sess->result_table = table;
	return 0;
}

ui_command_t pscs_slot_command = {
	"dump",
	"Dump all slot on the system",
	".pcsc.slot",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(pscs_slot_command.link),
	pcsc_slot_cmd_dump,
};

ui_schema_t pscs_handle_scheme[] = {
	/* .pcsc.handle */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".pcsc.slot", "slot", "PCSC reader slot" },

	{ UI_TYPE_NONE },
};

int __init pcsc_handle_init(void)
{
	ui_register_schema(pscs_handle_scheme);
	ui_register_command(&pscs_slot_command);

	return 0;
}

void __exit pcsc_handle_exit(void)
{
	ui_unregister_command(&pscs_slot_command);
	ui_unregister_schema(pscs_handle_scheme);
}
