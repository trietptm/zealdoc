#ifndef __MUSCLE_FS_H__
#define __MUSCLE_FS_H__

#include <pcsc.h>

/* MUSCLE stand for: movement for the use of smart cards in a linux environment */
struct msc_id {
	uint8_t id[4];
};

struct mscfs_file {
	struct msc_id object_id;
	uint32_t size;
	uint16_t read, write, del;

	int ef;/* 1 for EF, 0 for DF */

	list_t link;
};

struct mscfs {
	uint8_t curr_file[2];
	uint8_t curr_path[2];
	struct mscfs_file *curr_filp;
	
	/* file cached */
	list_t file_cache_list;
	
	void *udata;	/* struct scard_handle */
};

/* MUSCLE has 16 mechainisms for Security model */
#define MSC_ACL_NONE		0x0000
#define MSC_ACL_PIN		0x0002
#define MSC_ACL_KEY		0x0004
#define MSC_ACL_NEVER		0xFFFF

/* Reference 'MUSCLE Cryptographic Card Edge Definition for Java Enabled 
 * SmartCards'*/

/* key blob encoding */
#define MSC_KEY_ENCODE_PLAIN		0x00
#define MSC_KEY_ENCODE_ENCRYPTED	0x01

/* Key blob type */
#define MSC_KEY_TYPE_RSA_PUBLIC		0x01
#define MSC_KEY_TYPE_RSA_PRIVATE	0x02
#define MSC_KEY_TYPE_RSA_PRIVATE_CRT	0x03
#define MSC_KEY_TYPE_DSA_PUBLIC		0x04
#define MSC_KEY_TYPE_DSA_PRIVATE	0x05
#define MSC_KEY_TYPE_DES		0x06
#define MSC_KEY_TYPE_3DES		0x07
#define MSC_KEY_TYPE_3DES_3KEY		0x08

/* Allowed valaue for key size 
 * RSA		512, 768, 1024, 2048 ...
 * DSA		512, 768, 1024, 2048 ...
 * DES		64
 * 3DES		128
 * 3DES3KEY	192
 */

struct msc_key_blob {
	uint8_t encoding;
	uint8_t type;
	uint16_t size; /* in bits */
	uint8_t *data;
};
/* MUSCLE apdu format :
 *		INS P1 P2 P3 Data	*/
enum msc_apdu_ins {
	/* Keys handling */
	MSC_INS_GEN_KEYPAIR		= 0x30,
	MSC_INS_IMPORT_KEY		= 0x32,
	MSC_INS_EXPORT_KEY		= 0x34,
	MSC_INS_COMPUTE_CRYPT		= 0x36,
	MSC_INS_EXT_AUTH		= 0x38,
	MSC_INS_LIST_KEYS		= 0x3A,
	
	/* PIN related commands */
	MSC_INS_CREATE_PIN		= 0x40,
	MSC_INS_VERIFY_PIN		= 0x42,
	MSC_INS_CHANGE_PIN		= 0x44,
	MSC_INS_UNBLOCK_PIN		= 0x46,
	MSC_INS_LIST_PINS		= 0x48,
	
	/* Object related commands */
	MSC_INS_CREATE_OBJ		= 0x5A,		/* S */
	MSC_INS_DELETE_OBJ		= 0x52,		/* S */
	MSC_INS_READ_OBJ		= 0x56,		/* S/R */
	MSC_INS_WRITE_OBJ		= 0x54,		/* S */
	MSC_INS_LIST_OBJECTS		= 0x58,		/* R */
	
	/* Other */
	MSC_INS_LOGOUT_ALL		= 0x60,
	MSC_INS_GET_CHALLENGE		= 0x62,
	MSC_INS_GET_STATUS		= 0x3C,
};

struct mscfs *mscfs_new(void);
void mscfs_free(struct mscfs *fs);
void mscfs_clear_cache(struct mscfs *fs);
int mscfs_cache_push (struct mscfs *fs, const struct mscfs_file *filp);
void mscfs_cache_pop(struct mscfs_file *filp);

int mscfs_select_applet(pcsc_icc_t *icc,
			pcsc_appcmd_complete cb,
			void *user_data);
int mscfs_list_objects(pcsc_icc_t *card_handle,
		     uint8_t next, struct mscfs_file *filp,
		     pcsc_appcmd_complete callback, void *user_data);
int mscfs_list_file(pcsc_icc_t *card_handle,
		    struct mscfs_file *filp, int reset,
		    pcsc_appcmd_complete callback, void *user_data);
int mscfs_update_cache(struct mscfs *fs, 
		       pcsc_appcmd_complete callback, void *user_data);
int mscfs_load_fileinfo(struct mscfs *fs, const uint8_t *path, int pathlen,
			struct mscfs_file **file_data);
int mscfs_check_selection(struct mscfs *fs, int required_item);
int mscfs_lookup_local(struct mscfs *fs, const int id, struct msc_id *obj_id);
uint16_t muscle_parse_single_acl(const struct icc_acl_entry *acl);
void muscle_parse_acls(const struct icc_file *filp, 
			      uint16_t *read_perm, uint16_t *write_perm, 
			      uint16_t *delete_perm);
#endif /* __MUSCLE_FS_H__ */

