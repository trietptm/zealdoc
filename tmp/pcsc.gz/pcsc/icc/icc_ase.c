#include "../pcsc_priv.h"

#define ICC_DRIVER_ASE_NAME		"ASE"

static icc_atr_table ase_atr_table[] = {
	{
		"Ase T=1 card", 
	 	"3B:D6:18:00:81:B1:80:7D:1F:03:80:51:00:61:10:30:8F",
	 	NULL,
	},

	{0},
};

/* used call-chain */
static void ase_bind(pcsc_icc_t *icc);
static void ase_unbind(pcsc_icc_t *icc);
static void ase_up(void *eloop_data, void *data);
static void ase_down(void *eloop_data, void *data);

static void ase_bind(pcsc_icc_t *icc)
{
	pcsc_icc_get(icc);
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: bind");
	/* not sure whether driver has some private data to bind */
}

static void ase_unbind(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: unbind");
	pcsc_icc_put(icc);
}

static void ase_up(void *eloop_data, void *data)
{
	pcsc_icc_t *icc = (pcsc_icc_t *)data;
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: up");
	icc_up(icc);
}

static void ase_down(void *eloop_data, void *data)
{
	pcsc_icc_t *icc = (pcsc_icc_t *)data;

	pcsc_log(LOG_CALL_CHAIN, "ICC_C: down");
	icc_down(icc);
	ase_unbind(icc);
}

static int ase_drv_match(pcsc_icc_t *icc)
{
	if (icc_match_atr(ase_atr_table, icc->atr, icc->atr_len)) {
		pcsc_log(PCSC_LOG_INFO, "ICC: ASE card matched");
		return 1;
	}
	return 0;
}

static int ase_drv_open(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "ASE: driver open");
	
	ase_bind(icc);

	/* async notify, but not necessary in these two layer. */
	eloop_register_timeout(NULL, 0, 0, 
			       ase_up, NULL, icc);
	return -1;
}

static int ase_drv_close(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "ASE: driver close");
	/* async notify, but not necessary in these two layer. */
	eloop_register_timeout(NULL, 0, 0, 
			       ase_down, NULL, icc);
	return -1;
}

static icc_driver_ops_t ase_ops = {
	iso7816_read_binary,
	iso7816_write_binary,
	iso7816_update_binary,
	NULL,
	iso7816_read_record,
	iso7816_write_record,
	iso7816_append_record,
	iso7816_update_record,
	NULL,
	NULL,
	iso7816_select_file,	//ase_select_file,
	iso7816_get_response,
	NULL,
	NULL,	//ase_pin_cmd,
	NULL,
	NULL,	//ase_external_auth,
	iso7816_get_challenge,	/* rnd_len is 0x04~0x10 */
	NULL,
	NULL,
	NULL,	//ase_create_file,
	iso7816_delete_file,
	NULL,
	iso7816_check_sw,	/* FIXME: need self? */
	NULL,
	iso7816_process_fci,
	NULL,
	NULL,	/* extension for private cmd */
	/*
		private cmd:
		decrease,
		increase,
	 */

};

static icc_driver_t ase_driver = {
	ICC_DRIVER_ASE_NAME,
	ICC_DRV_SYNC_MATCH,
	ase_drv_match,
	ase_drv_open,	/* call-chain */
	ase_drv_close,	/* call-chain */
	&ase_ops,
};

int __init icc_ase_init(void)
{
	icc_register_driver(&ase_driver);
	return 0;
}

void __exit icc_ase_exit(void)
{
	icc_unregister_driver(&ase_driver);
}
