#include "../pcsc_priv.h"
#include "muscle_fs.h"

#define ICC_DRIVER_MUSCLE_NAME		"MUSCLE"

static struct msc_id output_id = {{0xFF, 0xFF, 0xFF, 0xFE}};	/*Import large data to card */
static struct msc_id input_id = {{0xFF, 0xFF, 0xFF, 0xFF}};	/* Export large data from card */

struct mus_priv {
	unsigned short verifiedpins;
	struct mscfs *fs;
	int rsa_key_ref;
};

struct msc_obj_priv {
	struct msc_id obj_id;
	uint32_t offset;
	size_t obj_size;
};

/* used call-chain */
static struct mus_priv *msc_new(void);
static void msc_free(struct mus_priv *priv);
static void msc_bind(pcsc_icc_t *icc, struct mus_priv *priv);
static void msc_unbind(pcsc_icc_t *icc);
static void msc_up(void *eloop_data, void *data);
static void msc_down(void *eloop_data, void *data);

static void msc_match_finish(void *user, int ret);
static int msc_drv_match(pcsc_icc_t *icc);

static inline int MSC_RECV_MAX(pcsc_icc_t *icc)
{
	int len = ICC_RECV_MAX(icc);
	
	return len > 255 ? 255 : len;
}

static inline int MSC_SEND_MAX(pcsc_icc_t *icc)
{
	int len = ICC_SEND_MAX(icc);
	
	return len > 255 ? 255 : len;
}

static struct mus_priv *msc_new(void)
{
	struct mus_priv *priv;

	priv = malloc(sizeof(struct mus_priv));
	if (!priv)
		return NULL;
	memset(priv, 0, sizeof(struct mus_priv));
	priv->verifiedpins = 0;
	priv->fs = mscfs_new();
	if (!priv->fs) {
		free(priv);
		return NULL;
	}
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: new");
	return priv;
}

static void msc_free(struct mus_priv *priv)
{
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: free");
	if (priv->fs)
		mscfs_free(priv->fs);
	free(priv);
}

static void msc_bind(pcsc_icc_t *icc, struct mus_priv *priv)
{
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: bind");

	priv->fs->udata = pcsc_icc_get(icc);
	icc_bind_drv_priv(icc, priv);	
}

static void msc_unbind(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: unbind");

	icc_unbind_drv_priv(icc);
	pcsc_icc_put(icc);
}

static void msc_up(void *eloop_data, void *data)
{
	pcsc_icc_t *icc = (pcsc_icc_t *)data;
	/* FIXME: parent set this value, not child */
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: up");
	icc_up(icc);
}

static void msc_down(void *eloop_data, void *data)
{
	pcsc_icc_t *icc = (pcsc_icc_t *)data;
	struct mus_priv *priv = ICC_DRV_PRIV(icc);

	pcsc_log(LOG_CALL_CHAIN, "ICC_C: down");
	icc_down(icc);
	msc_unbind(icc);

	msc_free(priv);
}

/* async match template */
static void msc_match_finish(void *user, int ret)
{
	if (ret == 0) {
		pcsc_log(PCSC_LOG_INFO, "ICC: muscle card matched");
		icc_async_matched(user, ICC_DRIVER_MUSCLE_NAME, 1);
	} else
		pcsc_log(PCSC_LOG_INFO, "ICC: muscle card not matched");
}

static int msc_drv_match(pcsc_icc_t *icc)
{
	return mscfs_select_applet(icc, msc_match_finish, icc);
}

static int msc_drv_open(pcsc_icc_t *icc)
{
	struct mus_priv *priv;

	pcsc_log(LOG_CALL_CHAIN, "MSC: driver open");
	priv = msc_new();
	/* TODO: now icc not handle fail open */
	BUG_ON(!priv);

	icc->cla = 0xB0;
	icc->max_send = 1024 * 64;
	icc->max_recv = 1024 * 64;
	
	msc_bind(icc, priv);
	/* async notify, but not necessary in these two layer. */
	eloop_register_timeout(NULL, 0, 0, 
			       msc_up, NULL, icc);
	return ICC_SUCCESS;
}

static int msc_drv_close(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "MSC: driver close");

	/* async notify, but not necessary in these two layer. */
	eloop_register_timeout(NULL, 0, 0, 
			       msc_down, NULL, icc);
	return 0;
}

/* ============================================================ *
 * driver operations
 * ============================================================ */
static icc_card_error_t	msc_errors[] = {
	{ 0x9000, ICC_SUCCESS,			"Success"},
	{ 0x9C01, ICC_ERR_MEMORY_FAILURE,	"Insufficient memory" },
	{ 0x9C02, ICC_ERR_AUTH_FAILED,		"Unsuccessful authentication"},
	{ 0x9C03, ICC_ERR_NOT_ALLOWED,		"Operation not allowed"},
	{ 0x9C05, ICC_ERR_NO_CARD_SUPPORT,	"Not supported"},
	{ 0x9C06, ICC_ERR_UNAUTHORIZED,		"Security status not satisfied"},
	{ 0x9C07, ICC_ERR_FILE_NOT_FOUND,	"Object not found"},
	{ 0x9C08, ICC_ERR_FILE_EXISTS,		"Object already exists"},
	{ 0x9C09, ICC_ERR_INVALID_ALG,		"Invalid algorithm"},
	{ 0x9C0B, ICC_ERR_INVALID_SIG,		"Invalid signature"},
	{ 0x9C0C, ICC_ERR_AUTH_BLOCKED,		"Specified identity blocked"},
	{ 0x9C0D, ICC_ERR_UNSPECIFIED,		"no futher error info"},
	{ 0x9C0E, ICC_ERR_INCORRECT_PARAM,	"Invalid Parameters"},
	{ 0x9C10, ICC_ERR_INCORRECT_PARAM,	"Incorrect P1"},
	{ 0x9C11, ICC_ERR_INCORRECT_PARAM,	"Incorrect P2"},
	{ 0x9C12, ICC_ERR_INCORRECT_PARAM,	"Incorrect Le"},
	{ 0x6300, ICC_ERR_AUTH_FAILED,		"Unsuccessful auth(for ISO PIN Verify)"},
	{ 0x6983, ICC_ERR_AUTH_BLOCKED,		"PIN verify blocked"},
	{ 0x6A83, ICC_ERR_INCORRECT_PARAM,	"Incorrect P1P2"},
	{ 0x6D00, ICC_ERR_INS_NOT_SUPPORTED,	"Incorrect INS"},
};

static int msc_check_sw(pcsc_icc_t *icc, uint8_t sw1, uint8_t sw2)
{
	const int err_count = sizeof(msc_errors)/sizeof(msc_errors[0]);
	return icc_check_sw_core(icc, sw1, sw2, msc_errors, err_count);
}

static void muscle_load_signal_acl(struct icc_file *filp,
				   int op, uint16_t acl)
{
	int key_ref;

	if (acl == MSC_ACL_NEVER) {
		icc_file_add_acl_entry(filp, op, ICC_AC_NEVER, 
					 ICC_AC_KEY_REF_NONE);
		return;
	}

	for (key_ref = 0; key_ref < 16; key_ref++) {
		if (acl >> key_ref & 1) {
			icc_file_add_acl_entry(filp, op, ICC_AC_CHV, key_ref);
		}
	}
}

static void muscle_load_file_acls(struct icc_file *filp,
				  struct mscfs_file *file_data)
{
	muscle_load_signal_acl(filp, ICC_AC_OP_READ, file_data->read);
	muscle_load_signal_acl(filp, ICC_AC_OP_WRITE, file_data->write);
	muscle_load_signal_acl(filp, ICC_AC_OP_UPDATE, file_data->write);
	muscle_load_signal_acl(filp, ICC_AC_OP_DELETE, file_data->del);
}

static void muscle_load_dir_acls(struct icc_file *filp,
				 struct mscfs_file *file_data)
{
	muscle_load_signal_acl(filp, ICC_AC_OP_SELECT, MSC_ACL_NONE);
	muscle_load_signal_acl(filp, ICC_AC_OP_LIST_FILES, MSC_ACL_NONE);
	muscle_load_signal_acl(filp, ICC_AC_OP_LOCK, MSC_ACL_NEVER);
	muscle_load_signal_acl(filp, ICC_AC_OP_DELETE, file_data->del);
	muscle_load_signal_acl(filp, ICC_AC_OP_CREATE, file_data->write);
}

static void select_item_complete(void *user_data, int ret)
{
	pcsc_transfer_t *transfer = (pcsc_transfer_t *)user_data;
	pcsc_icc_trans_param *icc_param = transfer->icc_param;
	struct icc_path *in_path = icc_param->path;
	struct mus_priv *priv = ICC_DRV_PRIV(transfer->handle->icc);
	struct mscfs *fs = priv->fs;
	int r = ret;
	
	if (ret == ICC_SUCCESS) {
		struct mscfs_file *file_data = NULL;
		uint8_t *oid;

		r = mscfs_load_fileinfo(fs, in_path->value,
				in_path->len, &file_data);
		if (r < 0) goto out;

		oid = file_data->object_id.id;

		if (file_data->ef) {
			fs->curr_path[0] = oid[0];
			fs->curr_path[1] = oid[1];
			fs->curr_file[0] = oid[2];
			fs->curr_file[1] = oid[3];
		} else {
			fs->curr_path[0] = oid[in_path->len - 2];
			fs->curr_path[1] = oid[in_path->len - 1];
			fs->curr_file[0] = 0;
			fs->curr_file[1] = 0;
		}
		
		fs->curr_filp = file_data;
		if (icc_param->file_out) {
			struct icc_file *filp = icc_file_new();
			if (!filp) {
				r = ICC_ERR_NO_MEM;
				goto out;
			}
			filp->path = *in_path;
			filp->size = file_data->size;
			filp->id = (oid[2] << 8) | oid[3];
			memcpy(filp->df_name, in_path->value, in_path->len);
			filp->df_name_len = in_path->len;
			if (!file_data->ef) {
				filp->type = ICC_FILE_TYPE_DF;
			} else {
				filp->type = ICC_FILE_TYPE_WORKING_EF;
				filp->ef_structure = ICC_FILE_EF_TRANSPARENT;
			}
			/* Setup ACLs */
			if (file_data->ef) {
				muscle_load_file_acls(filp, file_data);
			} else {
				muscle_load_dir_acls(filp, file_data);
			}
			*icc_param->file_out = filp;
		}
	}
out:
	transfer->ret = r;
	icc_param->callback(transfer);
	free(in_path);
	icc_trans_param_free(icc_param);
}

/* Before select_item you should check cache. 
 * If the cache is empty, you should
 * first update the cache.
 */
static int select_item(pcsc_slot_t *slot, struct icc_path *in_path, struct icc_file **file_out, 
		       pcsc_trans_cb cb, pcsc_transfer_t *transfer)
{
	struct mus_priv *priv = ICC_DRV_PRIV(slot->icc);
	struct mscfs *fs = priv->fs;
	pcsc_icc_trans_param *icc_param;
	int r;

	icc_param = icc_trans_param_new();

	if (!icc_param)
		return ICC_ERR_NO_MEM;

	icc_param->path = malloc(sizeof(struct icc_path));
	if (!icc_param->path)
		goto fail;

	*icc_param->path = *in_path;
	icc_param->file_out = file_out;
	icc_param->callback = cb;

	transfer->icc_param = icc_param;

	if (list_empty(&fs->file_cache_list)) {
		r = mscfs_update_cache(fs, select_item_complete, transfer);
		if (r != ICC_SUCCESS)
			goto fail;
		return ICC_SUCCESS;
	} else {
		select_item_complete(transfer, ICC_SUCCESS);
		return ICC_SUCCESS;
	}
fail:
	if (icc_param) {
		if (icc_param->path) free(icc_param->path);
		icc_trans_param_free(icc_param);
	}
	return -1;
}

static int msc_select_file(pcsc_slot_t *icc, 
			   struct icc_path *in_path, struct icc_file **file_out, 
			   pcsc_trans_cb callback, pcsc_transfer_t *transfer)
{
	return select_item(icc, in_path, file_out, callback, transfer);	
}

static void msc_read_object_complete(pcsc_transfer_t *transfer)
{
	pcsc_slot_t *slot = transfer->handle;
	pcsc_icc_trans_param *icc_trans = transfer->icc_param;
	struct icc_apdu *apdu = icc_trans->apdu;
	struct msc_obj_priv *read_priv = (struct msc_obj_priv *)icc_trans->priv;
	uint8_t buffer[9];
	uint8_t le;
	int rbuf_actual, left;

//	pcsc_log(PCSC_LOG_WARN, "apdu->rx_buflen=%d", apdu->rx_buflen);

	if (transfer->ret != ICC_SUCCESS) {
		icc_trans->ret = transfer->ret;
		goto ret;
	}

	icc_trans->ret = pcsc_fetch_check_sw(transfer);

	rbuf_actual = transfer->rbuf_actual - 2;

	if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
		if (rbuf_actual == 0)
			goto ret;

		/* TODO :*/
		if (apdu->actual_recv + rbuf_actual > apdu->rx_buflen) {
			pcsc_log(PCSC_LOG_WARN, "apdu actural_recv=%d, rx_buflen=%d, this rx=%d",
					apdu->actual_recv, apdu->rx_buflen, rbuf_actual);
			icc_trans->ret = -1;
			goto ret;
			BUG_ON(apdu->actual_recv + rbuf_actual > apdu->rx_buflen);
		}			
		
		memcpy(apdu->rx_buf, transfer->rbuf, rbuf_actual);
		apdu->actual_recv += rbuf_actual;
		icc_trans->ret = apdu->actual_recv;
		/* receive finished */
		if (apdu->actual_recv == apdu->rx_buflen)
			goto ret;
		/* left to send */
		left = apdu->rx_buflen - apdu->actual_recv;
		
		memcpy(buffer, read_priv->obj_id.id, 4);
		
		read_priv->offset += rbuf_actual;
		ulong2bebytes(buffer + 4, read_priv->offset);
		
		le = (uint8_t) MIN(MSC_RECV_MAX(slot->icc), left);
		buffer[8] = le;

		apdu->cse = ICC_APDU_CASE_4_SHORT;
		apdu->cla = slot->icc->cla;
		apdu->ins = MSC_INS_READ_OBJ;
		apdu->p1 = 0x00;
		apdu->p2 = 0x00;
		apdu->le = le;
		apdu->lc = 9;	
		apdu->rx_buf += rbuf_actual;		
		apdu->tx_buf = buffer;
		apdu->tx_buflen = 9;
		
		pcsc_sync_apdu(transfer);
		if (pcsc_transmit(transfer) == 0)
			return;
		else
			icc_trans->ret = -1;
	} else if (apdu->sw1 == 0x9C) {
		if (apdu->sw2 == 0x07)
			icc_trans->ret = ICC_ERR_FILE_NOT_FOUND;
		else if (apdu->sw2 == 0x06) 
			icc_trans->ret = ICC_ERR_NOT_ALLOWED;
		else if (apdu->sw2 == 0x0F)
			icc_trans->ret = ICC_ERR_INVALID_ARGS;
	} else if (apdu->sw1 == 0x61) {
		int r;
		le = apdu->sw2 != 0 ? apdu->sw2 : 256;
		/* only T0 can use response for this */

		/* if rbuf_len < current - head or ... */
		transfer->rbuf += rbuf_actual;
		
		r = pcsc_icc_ops(transfer->handle)->get_response(
			transfer, transfer->rbuf, transfer->rbuf_len, le);
		if (r != 0) {
			icc_trans->ret = r;
			goto ret;
		}
		return;
	}
ret:
	transfer->ret = icc_trans->ret;
	icc_trans->callback(transfer);

	free(read_priv);
	icc_trans_param_free(icc_trans);
}

static int msc_read_object(pcsc_slot_t *slot, struct msc_id obj_id, uint32_t offset,
			   uint8_t *rbuf, size_t rbuf_len, 
			   pcsc_trans_cb callback, pcsc_transfer_t *transfer)
{
	pcsc_icc_trans_param *icc_trans = NULL;
	struct icc_apdu *apdu = NULL;
	struct msc_obj_priv *read_priv = NULL;
	uint8_t buffer[9];
	uint8_t le;
	int r;

	icc_trans = icc_trans_param_new();
	if (!icc_trans) 
		return ICC_ERR_NO_MEM;
	
	read_priv = malloc(sizeof(struct msc_obj_priv));
	if (!read_priv)
		goto fail;

	memset(read_priv, 0, sizeof(struct msc_obj_priv));
	read_priv->obj_id = obj_id;
	read_priv->offset = offset;
	
	apdu = malloc(sizeof (struct icc_apdu));
	if (!apdu)
		goto fail;
	memset(apdu, 0, sizeof (struct icc_apdu));

	memcpy(buffer, obj_id.id, 4);
	ulong2bebytes(buffer + 4, offset);

	le =  MIN((int)MSC_RECV_MAX(slot->icc),  (int)rbuf_len);
	buffer[8] = le;

	apdu->cse = ICC_APDU_CASE_4_SHORT;
	apdu->cla = slot->icc->cla;
	apdu->ins = MSC_INS_READ_OBJ;
	apdu->p1 = 0x00;
	apdu->p2 = 0x00;
	apdu->lc = 9;	
	apdu->le = le;
	apdu->tx_buf = buffer;
	apdu->tx_buflen = 9;
	apdu->rx_buf = rbuf;
	apdu->rx_buflen = rbuf_len;

	icc_trans->apdu = apdu;
	icc_trans->priv = read_priv;
	icc_trans->callback = callback;

	transfer->icc_param = icc_trans;
	
	r = pcsc_transmit_from_icc(transfer, msc_read_object_complete);	

	if (r != ICC_SUCCESS)
		goto fail;

	return ICC_SUCCESS;
fail:
	if (read_priv) free(read_priv);
	if (icc_trans) icc_trans_param_free(icc_trans);
	return -1;
}

static int msc_read_binary(pcsc_slot_t *slot, uint32_t offset,
			   uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
			   pcsc_trans_cb cb, pcsc_transfer_t *transfer)
{
	struct mus_priv *priv = ICC_DRV_PRIV(slot->icc);
	struct mscfs *fs = priv->fs;
	struct msc_id obj_id;
	uint8_t *oid = obj_id.id;
	struct mscfs_file *filp;
	int r;

	r = mscfs_check_selection(fs, -1);
	if (r < 0) return r;
	filp = fs->curr_filp;
	obj_id = filp->object_id;
	if (!filp->ef) {
		oid[0] = oid[2];
		oid[1] = oid[3];
		oid[2] = oid[3] = 0;
	}

	return msc_read_object(slot, obj_id, offset, rbuf, rbuf_len,
			       cb, transfer);
}

static void msc_update_object_complete(pcsc_transfer_t *card_param)
{
	pcsc_slot_t *card_handle = card_param->handle;
	pcsc_icc_trans_param *cmd_param = card_param->icc_param;
	struct icc_apdu *apdu = cmd_param->apdu;
	struct msc_obj_priv *update_priv = 
			(struct msc_obj_priv *)cmd_param->priv;
	uint8_t buffer[ICC_APDU_BUFFER_MAX];
	uint8_t data_max = (uint8_t)MSC_SEND_MAX(card_handle->icc) - 9;
	size_t data_transmitted, data_left;
	
	int r;

	if (card_param->ret != ICC_SUCCESS) {
		cmd_param->ret = card_param->ret;
	} else {
		cmd_param->ret = pcsc_fetch_check_sw(card_param);

		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
			data_transmitted = apdu->lc - 9;
			cmd_param->sbuf_transmitted += data_transmitted;

			if (cmd_param->sbuf_transmitted == cmd_param->sbuf_len) {
				cmd_param->ret = cmd_param->sbuf_len;
				goto ret;
			}
			data_left = cmd_param->sbuf_len - cmd_param->sbuf_transmitted;
			data_max = MIN(data_max, data_left);
			update_priv->offset += data_transmitted;

			memset(apdu, 0, sizeof(struct icc_apdu));
			apdu->cse = ICC_APDU_CASE_3_SHORT;
			apdu->cla = card_handle->icc->cla;
			apdu->ins = 0x54;
			apdu->p1 = 0x00;
			apdu->p2 = 0x00;

			apdu->lc = data_max + 9;
			
			memcpy(buffer, update_priv->obj_id.id, 4);
			ulong2bebytes(buffer + 4, update_priv->offset);
			buffer[8] = data_max;
			memcpy(buffer + 9, 
				cmd_param->sbuf + cmd_param->sbuf_transmitted,
				data_max);
			
			apdu->tx_buf = buffer;
			apdu->tx_buflen = data_left;

			pcsc_sync_apdu(card_param);
			r = pcsc_transmit(card_param);
			if (r == ICC_SUCCESS)
				return;
			else 
				cmd_param->ret = r;
		} else if (apdu->sw1 == 0x9C) {
			if (apdu->sw2 == 0x07)
				cmd_param->ret = ICC_ERR_FILE_NOT_FOUND;
			else if (apdu->sw2 == 0x06)
				cmd_param->ret = ICC_ERR_NOT_ALLOWED;
			else if (apdu->sw2 == 0x0F) 
				cmd_param->ret = ICC_ERR_INVALID_ARGS;
		}
	}

ret:
	card_param->ret = cmd_param->ret;
	cmd_param->callback(card_param);
	free(apdu);
	free(update_priv);
	free(cmd_param);
}

static int msc_update_object(pcsc_slot_t *slot, struct msc_id obj_id,
			     uint32_t offset, uint8_t *sbuf, size_t sbuf_len,
			     pcsc_trans_cb callback, pcsc_transfer_t *trans)
{
	pcsc_icc_trans_param *icc_param = NULL;
	struct icc_apdu *apdu;
	struct msc_obj_priv *update_priv;
	uint8_t buffer[ICC_APDU_BUFFER_MAX];
	uint8_t data_max = (uint8_t)MSC_SEND_MAX(slot->icc) - 9;
	int r;

	data_max = (uint8_t)MIN(data_max, sbuf_len);
	
	memcpy(buffer, obj_id.id, 4);
	ulong2bebytes(buffer + 4, offset);
	buffer[8] = data_max;
	memcpy(buffer + 9, sbuf, data_max);

	icc_param = icc_trans_param_new();
	if (!icc_param) 
		return ICC_ERR_NO_MEM;

	update_priv = malloc(sizeof (struct msc_obj_priv));
	if (!update_priv)
		goto fail;
	update_priv->obj_id = obj_id;
	update_priv->offset = offset;

	icc_param->priv = update_priv;
	icc_param->sbuf = sbuf;
	icc_param->sbuf_len = sbuf_len;
	icc_param->callback = callback;

	apdu = malloc(sizeof(struct icc_apdu));
	if (!apdu)
		goto fail;
	memset(apdu, 0, sizeof(struct icc_apdu));
	apdu->cse = ICC_APDU_CASE_3_SHORT;
	apdu->cla = slot->icc->cla;
	apdu->ins = 0x54;
	apdu->p1 = 0x00;
	apdu->p2 = 0x00;

	apdu->lc = data_max + 9;

	apdu->tx_buf = buffer;
	apdu->tx_buflen = sbuf_len; /* data left */

	icc_param->apdu = apdu;
	trans->icc_param = icc_param;

	r = pcsc_transmit_from_icc(trans, msc_update_object_complete);	

	if (r != ICC_SUCCESS)
		goto fail;

	return ICC_SUCCESS;
fail:
	if (update_priv) free(update_priv);
	if (icc_param) icc_trans_param_free(icc_param);
	return -1;
}

static int msc_update_binary(pcsc_slot_t *slot, uint32_t offset,
			  uint8_t *sbuf, size_t sbuf_len, uint32_t flags,
			  pcsc_trans_cb callback, 
			  pcsc_transfer_t *trans)

{
	struct mus_priv *priv = ICC_DRV_PRIV(slot->icc);
	struct mscfs *fs = priv->fs;
	struct msc_id obj_id;
	uint8_t *oid = obj_id.id;
	struct mscfs_file *filp;
	int r;

	r = mscfs_check_selection(fs, -1);
	if (r < 0) return r;

	filp = fs->curr_filp;
	obj_id = filp->object_id;

	if (!filp->ef) {
		oid[0] = oid[2];
		oid[1] = oid[3];
		oid[2] = oid[3] = 0;
	}
	/* XXX: We not support the size is more than file size,
	 *	while OpenSC supported.(first delte and create, write) */
	if (filp->size < offset + sbuf_len)
		return ICC_ERR_INVALID_ARGS;
	return msc_update_object(slot, obj_id, offset, sbuf, sbuf_len,
				 callback, trans);
}
#if 0

static void msc_zero_object_complete(void *user_data, int ret)
{
	struct icc_trans_param *cmd_param = 
			(struct icc_trans_param *)user_data;
	
	cmd_param->callback(cmd_param->user_data, ret);

	free((uint8_t *)cmd_param->sbuf);
	free(cmd_param);
}

static int msc_zero_object(struct scard_handle *card_handle, 
			   struct msc_id obj_id, size_t obj_size,
			   pcsc_ll_cb callback, void *user_data)
{
	struct icc_trans_param *cmd_param;
	uint8_t *zero_buf;
	
	cmd_param = malloc(sizeof(struct icc_trans_param));
	if (!cmd_param) 
		return ICC_ERR_NO_MEM;
	memset(cmd_param, 0, sizeof(struct icc_trans_param));

	zero_buf = malloc(obj_size);
	if (!zero_buf) {
		free(cmd_param);
		return ICC_ERR_NO_MEM;
	}
	memset(zero_buf, 0, obj_size);

	cmd_param->sbuf = zero_buf;
	cmd_param->sbuf_len = obj_size;
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;

	return msc_update_object(card_handle, obj_id, 0, 
				 cmd_param->sbuf, cmd_param->sbuf_len, 
				 msc_zero_object_complete, cmd_param);
}

static void msc_create_object_complete(struct icc_transfer *card_param)
{
	struct scard_handle *card_handle = card_param->handle;
	struct icc_trans_param *cmd_param = card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;
	struct msc_obj_priv *create_priv = 
			(struct msc_obj_priv *)cmd_param->priv_param;
	int r;

	if (card_param->ret != ICC_SUCCESS) {
		cmd_param->ret = card_param->ret;
	} else {
		cmd_param->ret = scard_check_sw(card_handle, apdu->sw1,
						apdu->sw2);
		
		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
			r = msc_zero_object(card_handle, 
					       create_priv->obj_id, 
					       create_priv->obj_size, 
					       cmd_param->callback, 
					       cmd_param->user_data);
			if (r == ICC_SUCCESS)
				return;
			else 
				cmd_param->ret = r;
		} else if (apdu->sw1 == 0x9C) {
			if (apdu->sw2 == 0x01)
				cmd_param->ret = ICC_ERR_NO_MEM;
			else if (apdu->sw2 == 0x08)
				cmd_param->ret = ICC_ERR_FILE_EXISTS;
			else if (apdu->sw2 == 0x06) 
				cmd_param->ret = ICC_ERR_NOT_ALLOWED;			
		}
	}

	cmd_param->callback(cmd_param->user_data, cmd_param->ret);

	free(apdu);
	free(cmd_param);
	free(card_param);
}

static int msc_create_object(struct scard_handle *card_handle, 
			     struct msc_id obj_id, size_t obj_size, 
			     uint16_t read_perm, uint16_t write_perm,
			     uint16_t delete_perm,
			     pcsc_ll_cb callback, void *user_data)
{
	struct icc_transfer *card_param;
	struct icc_trans_param *cmd_param;
	struct scard_apdu *apdu;
	struct msc_obj_priv *create_priv;
	uint8_t buffer[14];
	int r;

	cmd_param = malloc(sizeof(struct icc_transfer));
	if (!cmd_param)
		return ICC_ERR_NO_MEM;
	memset(cmd_param, 0, sizeof(struct icc_transfer));

	create_priv = malloc(sizeof(struct msc_obj_priv));
	if (!create_priv) {
		free(cmd_param);
		return ICC_ERR_NO_MEM;
	}
	create_priv->obj_id = obj_id;
	create_priv->obj_size = obj_size;

	cmd_param->priv_param = create_priv;
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;

	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(cmd_param);
		return ICC_ERR_NO_MEM;
	}
	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = ICC_APDU_CASE_3_SHORT;
	apdu->cla = card_handle->cla;
	apdu->ins = 0x5A;
	apdu->p1 = 0x00;
	apdu->p2 = 0x00;
	apdu->lc = 14;

	memcpy(buffer, obj_id.id, 4);
	ulong2bebytes(buffer + 4, obj_size);
	ushort2bebytes(buffer + 8, read_perm);
	ushort2bebytes(buffer + 10, write_perm);
	ushort2bebytes(buffer + 12, delete_perm);

	apdu->data = buffer;
	apdu->datalen = 14;

	card_param = malloc(sizeof(struct icc_transfer));
	if (!card_param) {
		free(apdu);
		free(cmd_param);
		return ICC_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct icc_transfer));
	card_param->handle = card_handle;
	card_param->cmd_param = cmd_param;
	card_param->apdu = apdu;
	card_param->callback = msc_create_object_complete;
		
	r = scard_reader_transmit(card_param);
	if (r != ICC_SUCCESS) {
		free(apdu);
		free(cmd_param);
		free(card_param);
	}
	
	return r;
}

struct msc_create_file_priv {
	struct scard_handle *card_handle;
	struct mscfs_file msc_file;

	pcsc_ll_cb callback;
	void *user_data;
};

static void msc_create_file_complete(void *user_data, int ret)
{
	struct msc_create_file_priv *create_priv = 
		(struct msc_create_file_priv *) user_data;
	struct scard_handle *card_handle = create_priv->card_handle;
	struct mus_priv *msc_priv = MSC_PRIV(card_handle);
	struct mscfs_file *filp = &create_priv->msc_file;

	if (ret == ICC_SUCCESS) {
		mscfs_cache_push(msc_priv->fs, filp);
	}

	create_priv->callback(create_priv->user_data, ret);
	free(create_priv);
}

static int msc_create_directory(struct scard_handle *card_handle, 
				struct icc_file *filp,
				pcsc_ll_cb callback, void *user_data)
{
	struct mus_priv *msc_priv = MSC_PRIV(card_handle);
	struct mscfs *fs = msc_priv->fs;
	struct msc_id obj_id;
	uint8_t *oid = obj_id.id;
	int fid =filp->id;
	uint16_t read_perm = 0, write_perm = 0, delete_perm = 0;
	size_t obj_size = filp->size;
	struct msc_create_file_priv *create_priv;

	if (fid == 0) /* No null name files */
		return ICC_ERR_INVALID_ARGS;
	/* No nesting directories */
	if (fs->curr_path[0] != 0x3F || fs->curr_path[1] != 0x00)
		return ICC_ERR_NOT_SUPPORTED;
	oid[0] = ((fid & 0xFF00) >> 8) & 0xFF;
	oid[1] = fid & 0xFF;
	oid[2] = oid[3] = 0;

	muscle_parse_acls(filp, &read_perm, &write_perm, &delete_perm);

	create_priv = malloc(sizeof(struct msc_create_file_priv));
	if (!create_priv)
		return ICC_ERR_NO_MEM;
	memset(create_priv, 0, sizeof(struct msc_create_file_priv));
	create_priv->card_handle = card_handle;
	create_priv->callback = callback;
	create_priv->user_data = user_data;

	create_priv->msc_file.object_id = obj_id;
	create_priv->msc_file.size = filp->size;
	create_priv->msc_file.ef = 0;
	create_priv->msc_file.read = read_perm;
	create_priv->msc_file.write = write_perm;
	create_priv->msc_file.del = delete_perm;

	return msc_create_object(card_handle, obj_id, obj_size, 
			      read_perm, write_perm, delete_perm, 
			      msc_create_file_complete, create_priv);
}

static int msc_create_file(struct scard_handle *card_handle, 
			   struct icc_file *filp,
			   pcsc_ll_cb callback, void *user_data)
{
	struct mus_priv *msc_priv = MSC_PRIV(card_handle);
	struct mscfs *fs = msc_priv->fs;
	size_t obj_size = filp->size;
	uint16_t read_perm = 0, write_perm = 0, delete_perm = 0;
	struct msc_id obj_id;
	struct msc_create_file_priv *create_priv;

	if (filp->type == ICC_FILE_TYPE_DF)
		return msc_create_directory (card_handle, filp, 
					     callback, user_data);
	if (filp->type != ICC_FILE_TYPE_WORKING_EF) 
		return ICC_ERR_NOT_SUPPORTED;
	if (filp->id == 0) /* No null name files */
		return ICC_ERR_INVALID_ARGS;

	muscle_parse_acls(filp, &read_perm, &write_perm, &delete_perm);
	mscfs_lookup_local(fs, filp->id, &obj_id);

	create_priv = malloc(sizeof(struct msc_create_file_priv));
	if (!create_priv)
		return ICC_ERR_NO_MEM;
	memset(create_priv, 0, sizeof(struct msc_create_file_priv));
	create_priv->card_handle = card_handle;
	create_priv->callback = callback;
	create_priv->user_data = user_data;

	create_priv->msc_file.object_id = obj_id;
	create_priv->msc_file.size = filp->size;
	create_priv->msc_file.ef = 1;
	create_priv->msc_file.read = read_perm;
	create_priv->msc_file.write = write_perm;
	create_priv->msc_file.del = delete_perm;

	return msc_create_object(card_handle, obj_id, obj_size, read_perm,
			      write_perm, delete_perm, 
			      msc_create_file_complete, create_priv);
}

static void msc_delete_object_complete(struct icc_transfer *card_param)
{
	struct scard_handle *card_handle = card_param->handle;
	struct icc_trans_param *cmd_param = card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;

	if (card_param->ret != ICC_SUCCESS)
		cmd_param->ret = card_param->ret;
	else {
		cmd_param->ret = scard_check_sw(card_handle, 
						apdu->sw1, apdu->sw2);
		if (apdu->sw1 == 0x9c) {
			if (apdu->sw2 == 0x07)
				cmd_param->ret = ICC_ERR_FILE_NOT_FOUND;
			else if (apdu->sw2 == 0x06)
				cmd_param->ret = ICC_ERR_NOT_ALLOWED;			
		}
	}

	cmd_param->callback(cmd_param->user_data, cmd_param->ret);
	free(cmd_param);
	free(apdu);
	free(card_param);	
}

static int msc_delete_object(struct scard_handle *card_handle, 
			     struct msc_id obj_id, int zero,
			     pcsc_ll_cb callback, void *user_data)
{
	struct icc_transfer *card_param;
	struct icc_trans_param *cmd_param;
	struct scard_apdu *apdu;
	int r;

	cmd_param = malloc(sizeof(struct icc_trans_param));
	if (!cmd_param)
		return ICC_ERR_NO_MEM;
	memset(cmd_param, 0, sizeof(struct icc_trans_param));
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;
	
	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(cmd_param);
		return ICC_ERR_NO_MEM;
	}
	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = ICC_APDU_CASE_3_SHORT;
	apdu->cla = card_handle->cla;
	apdu->ins = 0x52;
	apdu->p1 = 0x00;
	apdu->p2 = zero ? 0x01 : 0x00;
	apdu->lc = 4;
	apdu->data = obj_id.id;
	apdu->datalen = 4;

	card_param = malloc(sizeof(struct icc_transfer));
	if (!card_param) {
		free(apdu);
		free(cmd_param);
		return ICC_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct icc_transfer));
	card_param->handle = card_handle;
	card_param->cmd_param = cmd_param;
	card_param->apdu = apdu;
	card_param->callback = msc_delete_object_complete;

	r = scard_reader_transmit(card_param);
	if (r != ICC_SUCCESS) {
		free(cmd_param);
		free(apdu);
		free(card_param);
	}

	return r;
}

struct msc_delete_priv {
	struct scard_handle *card_handle;
	struct scard_path root_path;
	struct mscfs_file *leaf;
	pcsc_ll_cb callback;
	void *user_data;
};

static int msc_get_a_leaf(struct scard_handle *card_handle, 
			  struct mscfs_file *parent_filp,
			  struct mscfs_file **leaf)
{
	struct mus_priv *msc_priv = MSC_PRIV(card_handle);
	struct mscfs *fs = msc_priv->fs;
	struct mscfs_file *child_filp;
	const struct msc_id *parent_id, *child_id;
	int r;

	if (parent_filp->ef) {
		*leaf = parent_filp;
		return ICC_SUCCESS;
	}
	
	parent_id = &parent_filp->object_id;
	list_for_each_entry(struct mscfs_file, child_filp, 
			    &fs->file_cache_list, link) {
		child_id = &child_filp->object_id;

		if (0 == memcmp(parent_id->id + 2, child_id->id, 2)) {
			if (child_filp->ef) {
				*leaf = child_filp;
				return ICC_SUCCESS;
			} else {
				r = msc_get_a_leaf(card_handle, child_filp, leaf);
				 /* Directory 'child_filp' there are no children */
				if (r == ICC_SUCCESS && *leaf == NULL)
					*leaf = child_filp;
				return r;
			}
		}
	}
	
	*leaf = parent_filp;
	return ICC_SUCCESS;
}

static void msc_delete_file_complete(void *user_data, int ret)
{
	struct msc_delete_priv *delete_priv = 
			(struct msc_delete_priv *)user_data;
	struct scard_handle *card_handle = delete_priv->card_handle;
	struct mus_priv *msc_priv = MSC_PRIV(card_handle);
	
	struct msc_id obj_id;
	uint8_t *oid = obj_id.id;
	struct mscfs_file *tree_root, *deleted_leaf, *leaf;
	const struct scard_path *root_path = &delete_priv->root_path;
	int r;
	

	deleted_leaf = delete_priv->leaf;
	obj_id = deleted_leaf->object_id;

	/* Check if its the root... this file generally is virtual
	 * So don't return an error if it fails */
	if ((0 == memcpy(oid, "\x3F\x00\x00\x00", 4))
		|| (0 == memcpy(oid, "\x3F\x00\x3F\x00", 4))) {
		r = ICC_SUCCESS;
		goto ret;
	} else if (ret != ICC_SUCCESS) {
		r = ret;
		goto ret;
	}

	mscfs_cache_pop(deleted_leaf);
	
	r = mscfs_load_fileinfo(msc_priv->fs, root_path->value, root_path->len,
				&tree_root);
	if (r != ICC_SUCCESS)
		goto ret;

	r = msc_get_a_leaf(card_handle, tree_root, &leaf);
	if (r != ICC_SUCCESS)
		goto ret;

	obj_id = leaf->object_id;
	if (!leaf->ef) {
		oid[0] = oid[2];
		oid[1] = oid[3];
		oid[2] = oid[3] = 0;
	}

	delete_priv->leaf = leaf;
	r = msc_delete_object(card_handle, obj_id, 1, 
			      msc_delete_file_complete, delete_priv);
	if (r == ICC_SUCCESS) 
		return;

ret: 
	delete_priv->callback(delete_priv->user_data, r);
	free(delete_priv);
}

static int msc_delete_file (struct scard_handle *card_handle, 
			    const struct scard_path *in_path,
			    pcsc_ll_cb callback, void *user_data)
{
	struct mus_priv *msc_priv = MSC_PRIV(card_handle);
	struct mscfs_file *tree_root, *leaf;
	struct msc_id obj_id;
	uint8_t *oid;
	struct msc_delete_priv *delete_priv;
	int r;

	r = mscfs_load_fileinfo(msc_priv->fs, in_path->value, in_path->len,
				&tree_root);
	if (r != ICC_SUCCESS)
		return r;

	r = msc_get_a_leaf(card_handle, tree_root, &leaf);
	if (r != ICC_SUCCESS)
		return r;
	if (!leaf)
		leaf = tree_root;
	obj_id = leaf->object_id;
	oid = obj_id.id;
	if (!leaf->ef) {
		oid[0] = oid[2];
		oid[1] = oid[3];
		oid[2] = oid[3] = 0;
	}

	delete_priv = malloc(sizeof(struct msc_delete_priv));
	if (!delete_priv) 
		return ICC_ERR_NO_MEM;
	delete_priv->root_path = *in_path;
	delete_priv->leaf = leaf;
	delete_priv->callback = callback;
	delete_priv->user_data = user_data;

	r = msc_delete_object(card_handle, obj_id, 1, 
			      msc_delete_file_complete, delete_priv);
	if (r != ICC_SUCCESS) {
		free(delete_priv);
	}

	return 0;
}

struct msc_list_priv {
	struct scard_handle *card_handle;
	uint8_t *buf;
	size_t buflen;

	pcsc_ll_cb callback;
	void *user_data;
};

static int msc_get_linea_childs_id(struct mscfs *fs, uint8_t *buf, size_t buflen)
{
	struct mscfs_file *pos;
	uint8_t *oid;
	uint8_t *p = buf;
	int count = 0;

	list_for_each_entry(struct mscfs_file, pos, 
			    &fs->file_cache_list, link) {
		oid = pos->object_id.id;
		if (0 == memcmp(fs->curr_path, oid, 2)) {
			if (count == (int)buflen)
				break;

			p[0] = oid[2];
			p[1] = oid[3];
			/* No direcotries/null names outside of root */
			if (p[0] == 0x00 && p[1] == 0x00)
				continue;
			p += 2;
			count += 2;
		}
	}
	return count;
}

static void msc_list_file_complete(void *user_data, int ret)
{
	struct msc_list_priv *list_priv = 
			(struct msc_list_priv *)user_data;
	struct scard_handle *card_handle = list_priv->card_handle;
	struct mus_priv *msc_priv = MSC_PRIV(card_handle);
	struct mscfs *fs = msc_priv->fs;
	int r = ret;
	
	if (ret == ICC_SUCCESS) {
		r = msc_get_linea_childs_id(fs, list_priv->buf, 
					    list_priv->buflen);
	}

	list_priv->callback(list_priv->user_data, r);
	free(list_priv);
}

static int msc_list_file(struct scard_handle *card_handle, 
			 uint8_t *buf, size_t buflen,
			 pcsc_ll_cb callback, void *user_data)
{
	struct mus_priv *msc_priv = MSC_PRIV(card_handle);
	struct mscfs *fs = msc_priv->fs;
	struct msc_list_priv *list_priv;
	int r;
	
	if (list_empty(&fs->file_cache_list)) {
		list_priv = malloc(sizeof(struct msc_list_priv));
		if (!list_priv)
			return ICC_ERR_NO_MEM;
		list_priv->card_handle = card_handle;
		list_priv->buf = buf;
		list_priv->buflen = buflen;
		list_priv->callback = callback;
		list_priv->user_data = user_data;

		r = mscfs_update_cache(fs, msc_list_file_complete, list_priv);
		if (r != ICC_SUCCESS) {
			free(list_priv);
			return r;
		}
	} else {
		r = msc_get_linea_childs_id(fs, buf, buflen);
		callback(user_data, r);
	}

	return 0;
}

static void truncate_pin_nulls(const uint8_t *pin_val, int *pin_len)
{
	for (; *pin_len > 0; (*pin_len)--)
		if (pin_val[*pin_len - 1])
			break;
}

static int (*iso_pin_cmd)(struct scard_handle *card_handle,
		       struct scard_pin_cmd_data *pin_cmd, int tries_left, 
		       pcsc_ll_cb callback, void *user_data);

static int msc_build_pin_cmd(struct scard_handle *card_handle, 
			     struct scard_apdu *apdu, 
			     struct scard_pin_cmd_data *pin_cmd,
			     uint8_t *sbuf, size_t sbuf_len)
{
	uint8_t *p = sbuf;

	switch (pin_cmd->pin_type) {
	case ICC_AC_CHV:
		break;
	default:
		return ICC_ERR_INVALID_ARGS;
	}
	
	switch (pin_cmd->cmd) {
	case ICC_PIN_CMD_VERIFY:
		truncate_pin_nulls(pin_cmd->pin1.data, &pin_cmd->pin1.len);
		memcpy(sbuf, pin_cmd->pin1.data, pin_cmd->pin1.len);

		apdu->cse = ICC_APDU_CASE_3_SHORT;
		apdu->cla = card_handle->cla;
		apdu->ins = MSC_INS_VERIFY_PIN;
		apdu->p1 = pin_cmd->pin_ref;
		apdu->p2 = 0x00;
		apdu->lc = pin_cmd->pin1.len;
		apdu->data = sbuf;
		apdu->datalen = apdu->lc;

		pin_cmd->pin1.offset = 5;		
		break;
	case ICC_PIN_CMD_CHANGE:
		truncate_pin_nulls(pin_cmd->pin1.data, &pin_cmd->pin1.len);
		truncate_pin_nulls(pin_cmd->pin2.data, &pin_cmd->pin2.len);
		
		apdu->cse = ICC_APDU_CASE_3_SHORT;
		apdu->cla = card_handle->cla;
		apdu->ins = MSC_INS_CHANGE_PIN;
		apdu->p1 = pin_cmd->pin_ref;
		apdu->p2 = 0x00;
		/* Old PIN */
		*p++ = (uint8_t)pin_cmd->pin1.len;
		memcpy(p, pin_cmd->pin1.data, pin_cmd->pin1.len);
		p += pin_cmd->pin1.len;
		/* New PIN */
		*p++ = (uint8_t)pin_cmd->pin2.len;
		memcpy(p, pin_cmd->pin2.data, pin_cmd->pin2.len);
		p += pin_cmd->pin2.len;

		apdu->lc = p - sbuf;
		apdu->data = sbuf;
		apdu->datalen = apdu->lc;
		break;
	case ICC_PIN_CMD_UNLOCK:
		truncate_pin_nulls(pin_cmd->pin1.data, &pin_cmd->pin1.len);
		memcpy(sbuf, pin_cmd->pin1.data, pin_cmd->pin1.len);

		apdu->cse = ICC_APDU_CASE_3_SHORT;
		apdu->cla = card_handle->cla;
		apdu->ins = MSC_INS_UNBLOCK_PIN;
		apdu->p1 = pin_cmd->pin_ref;
		apdu->p2 = 0x00;
		apdu->lc = pin_cmd->pin1.len;
		apdu->data = sbuf;
		apdu->datalen = apdu->lc;
		break;
	default:
		return ICC_ERR_NOT_SUPPORTED;
	}

	return ICC_SUCCESS;
}

static int msc_pin_cmd(struct scard_handle *card_handle,
		       struct scard_pin_cmd_data *pin_cmd, int tries_left, 
		       pcsc_ll_cb callback, void *user_data)
{
	struct scard_apdu *apdu;
	uint8_t pin_buf[ICC_APDU_BUFFER_MAX];
	int r;

	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu)
		return ICC_ERR_NO_MEM;
	memset(apdu, 0, sizeof(struct scard_apdu));

	r = msc_build_pin_cmd(card_handle, apdu, 
			      pin_cmd, pin_buf, sizeof(pin_buf));
	if (r != ICC_SUCCESS) {
		free(apdu);
		return r;
	}
	pin_cmd->apdu = apdu;
	r = iso_pin_cmd(card_handle, pin_cmd, tries_left, callback, user_data);
	if (r == ICC_SUCCESS)
		return ICC_SUCCESS;

	return r;
}

#define MSC_DL_APDU	0x01
#define MSC_DL_OBJECT	0x02

struct msc_get_challenge_priv {
	uint8_t location;
};

static void msc_get_challenge_complete(struct icc_transfer *card_param)
{
	struct scard_handle *card_handle = card_param->handle;
	struct icc_trans_param *cmd_param = card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;
	struct msc_get_challenge_priv *get_rnd_priv = 
			(struct msc_get_challenge_priv *)cmd_param->priv_param;
	uint8_t location = get_rnd_priv->location;
	int r;

	if (card_param->ret != ICC_SUCCESS) {
		cmd_param->ret = card_param->ret;
		goto ret;
	} else {
		cmd_param->ret = scard_check_sw(card_handle, apdu->sw1, apdu->sw2);
		if (apdu->sw1 != 0x90 || apdu->sw2 == 0x00)
			goto ret;

		if (location == MSC_DL_APDU) {
			cmd_param->rbuf_actual = cmd_param->rbuf_len - apdu->resplen;
			cmd_param->ret = cmd_param->rbuf_actual;
			goto ret;			
		} else {
			r = msc_read_object(card_handle, input_id, 2, 
					    cmd_param->rbuf, 
					    cmd_param->rbuf_len,
					    cmd_param->callback, 
					    cmd_param->user_data);
			if (r != ICC_SUCCESS) {
				cmd_param->ret = r;
				goto ret;
			} else
				goto read_rnd;
		}
	}

ret:
	cmd_param->callback(cmd_param->user_data, cmd_param->ret);
read_rnd:
	free(get_rnd_priv);
	free((uint8_t *)cmd_param->sbuf);
	free(cmd_param);
	free(apdu);
	free(card_param);
}
static int _msc_get_challenge(struct scard_handle *card_handle,
			      uint8_t *seed, uint16_t seed_len,
			      uint8_t *rnd, uint16_t rnd_len,
			      pcsc_ll_cb callback, void *user_data)
{
	struct icc_transfer *card_param;
	struct icc_trans_param *cmd_param;
	struct scard_apdu *apdu;
	uint8_t location = (rnd_len < MSC_RECV_MAX(card_handle)) ? MSC_DL_APDU : MSC_DL_OBJECT;
	uint8_t cse = (location == MSC_DL_APDU) ? ICC_APDU_CASE_4_SHORT : ICC_APDU_CASE_3_SHORT;
	uint8_t *buffer, *p;
	struct msc_get_challenge_priv *get_rnd_priv;
	int r;

	buffer = malloc(4 + seed_len);
	if (!buffer) {
		return ICC_ERR_NO_MEM;
	}
	p = buffer;
	ushort2bebytes(p, rnd_len);
	p += 2;
	ushort2bebytes(p, seed_len);
	p += 2;
	if (seed_len > 0)
		memcpy(p, seed, seed_len);

	cmd_param = malloc(sizeof(struct icc_trans_param));
	if (!cmd_param) {
		free(buffer);
		return ICC_ERR_NO_MEM;
	}
	memset(cmd_param, 0, sizeof(struct icc_trans_param));
	get_rnd_priv = malloc(sizeof(struct msc_get_challenge_priv));
	if (!get_rnd_priv) {
		free(buffer);
		free(cmd_param);
		return ICC_ERR_NO_MEM;
	}
	get_rnd_priv->location = location;
	cmd_param->priv_param = get_rnd_priv;
	cmd_param->sbuf = buffer;
	cmd_param->sbuf_len = 4 + seed_len;
	cmd_param->rbuf = rnd;
	cmd_param->rbuf_len = rnd_len;
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;

	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(cmd_param);
		free(buffer);
		free(get_rnd_priv);
		return ICC_ERR_NO_MEM;
	}

	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = cse;
	apdu->cla = card_handle->cla;
	apdu->ins = MSC_INS_GET_CHALLENGE;
	apdu->p1 = 0x00;
	apdu->p2 = location;
	apdu->lc = 4 + seed_len;
	apdu->data = buffer;
	apdu->datalen = apdu->lc;

	/* FIXME: differenct from OpenSC */
	if (location == 1) {
		apdu->le = rnd_len;
		apdu->resp = rnd;
		apdu->resplen = rnd_len;
	}

	card_param = malloc(sizeof(struct icc_transfer));
	if (!card_param) {
		free(cmd_param);
		free(buffer);
		free(get_rnd_priv);
		free(apdu);
		return ICC_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct icc_transfer));
	card_param->handle = card_handle;
	card_param->cmd_param = cmd_param;
	card_param->apdu = apdu;
	card_param->callback = msc_get_challenge_complete;
	
	r = scard_reader_transmit(card_param);
	if (r != ICC_SUCCESS) {
		free(cmd_param);
		free(buffer);
		free(get_rnd_priv);
		free(apdu);
		free(card_param);	
	}

	return r;
}

static int msc_get_challenge(pcsc_slot_t *slot, uint8_t *rnd, size_t rnd_len,
			     pcsc_trans_cb cb, pcsc_transfer_t *card_param)
{
	return _msc_get_challenge(slot, NULL, 0, rnd, (uint16_t)rnd_len, 
				  cb, user_data);
}
#endif

static icc_driver_ops_t muscle_ops = {
	msc_read_binary,	/* read_binary */
	iso7816_write_binary,	/* write_binary */
	NULL,//msc_update_binary,	/* update_binary */
	NULL,			/* erase_binary */
	iso7816_read_record,	/* read_record */
	iso7816_write_record,	/* write_record */
	iso7816_append_record,	/* append_record */
	iso7816_update_record,	/* update_record */
	NULL,			/* get_data */
	NULL,			/* put_data */
	msc_select_file,	/* select_file */
	iso7816_get_response,	/* get_response */
	NULL,			/* envelope */
	NULL,//msc_pin_cmd,		/* pin_cmd */
	NULL,			/* inter_auth */
	NULL,			/* exter_auth */
	NULL,	//msc_get_challenge,	/* get_challenge */
	NULL,			/* manage_channel */
	NULL,			/* computer_signature */
	NULL,//msc_create_file,	/* create_file */
	NULL,//msc_delete_file,	/* delete_file */
	NULL,//msc_list_file,		/* list_file */
	msc_check_sw,		/* check_sw */
	NULL,			/* card_ctl */
	iso7816_process_fci,	/* process_fci */
	iso7816_construct_fci,	/* construct_fci */

	NULL,
};

static icc_driver_t muscle_driver = {
	ICC_DRIVER_MUSCLE_NAME,
	ICC_DRV_ASYNC_MATCH,
	msc_drv_match,
	msc_drv_open,
	msc_drv_close,
	&muscle_ops,
};

int __init icc_muscle_init(void)
{
	icc_register_driver(&muscle_driver);
	return 0;
}

void __exit icc_muscle_exit(void)
{
	icc_unregister_driver(&muscle_driver);
}
