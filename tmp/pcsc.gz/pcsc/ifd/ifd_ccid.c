#include "../pcsc_priv.h"
#include <ccid.h>

static int ccid2pcsc_errno(int ccid_errno)
{
	switch(ccid_errno) {
	case CCID_SUCCESS:
		return PCSC_S_SUCCESS;

	case CCID_ERROR_NO_MEM:
		return PCSC_E_NO_MEMORY;
	case CCID_ERROR_CANCELLED:
		return PCSC_E_CANCELLED;
	case CCID_ERROR_NOT_SUPPORTED:
	case CCID_ERROR_INCOMPATIBLE_DEV:
		return PCSC_E_NOT_SUPPORTED;
	case CCID_ERROR_INVALID_ARG:
		return PCSC_E_INVALID_PARAMETER;
	case CCID_ERROR_TIMEOUT:
	case CCID_ERROR_USER_TIMEOUT:
		return PCSC_E_TIMEOUT;
	case CCID_ERROR_USER_ABORT:
		return PCSC_E_CANCELLED;
	case CCID_ERROR_INVALID_SLOT:
		return PCSC_E_INVALID_SLOT;	

	case CCID_ERROR_STALL:
		return PCSC_E_READER_UNAVAILABLE;
	case CCID_ERROR_NO_DEVICE:
		return PCSC_E_NO_READER;
	case CCID_ERROR_BUSY:
		return PCSC_E_READER_BUSY;	
	
	case CCID_ERROR_NO_CARD:
		return PCSC_E_NO_SMARTCARD;
	case CCID_ERROR_NO_ATR:
		return PCSC_E_INVALID_ATR;
	case CCID_ERROR_COMMUNICATION:
	case CCID_ERROR_COMM_ERR:
	case CCID_ERROR_OVERFLOW:
	case CCID_ERROR_GENERIC:
	case CCID_ERROR_RESP_NOT_MATCH:
	default:
		return PCSC_F_INTERNAL_ERROR;
	}
}

static void __ccid_ifd_control_cb(void *user_data, int ret)
{
	pcsc_transfer_t *trans = (pcsc_transfer_t *)user_data;
	pcsc_ifd_trans_param *ifd_param = trans->ifd_param;

	if (ret < 0) {
		trans->ret = ccid2pcsc_errno(ret);
	} else {
		trans->ret = PCSC_S_SUCCESS;
		trans->rbuf_actual = ret;
	}

	ifd_param->callback(trans);	
}

static void __ccid_power_off_cb(void *user_data, int ret)
{
	pcsc_slot_t *hd = (pcsc_slot_t *)user_data;
	uint8_t card_status;
	
	if (ret < 0)
		hd->ret = ccid2pcsc_errno(ret);
	else {
		/* >= 0 is not error */
		card_status = ret;
		if (card_status == CCID_CARD_PRESENT_ACTIVE)
			hd->icc->status = PCSC_ICC_PRESENT_POWERUP;
		else if (card_status == CCID_CARD_PRESENT_DEACTIVE)
			hd->icc->status = PCSC_ICC_PRESENT_POWERDOWN;
		else
			hd->icc->status = PCSC_ICC_ABSENT;	
		hd->ret = PCSC_S_SUCCESS;
	}

	hd->cb(hd);
}

/* @ret is response length */
static void __ccid_xfr_block_cb(void *user_data, int ret)
{
	pcsc_transfer_t *trans;
	
	trans = (pcsc_transfer_t *)user_data;

	BUG_ON(!trans ||
	       !trans->ifd_param || 
	       !trans->ifd_param->callback);

	if (ret < 0) {
		trans->ret = ccid2pcsc_errno(ret);
	} else {
		trans->ret = PCSC_S_SUCCESS;
		trans->rbuf_actual = ret;
	}

	if (trans->ifd_param->callback)
		trans->ifd_param->callback(trans);
}

static void __ccid_power_on_cb (void *user_data, int ret)
{
	pcsc_slot_t *rd_ctx = (pcsc_slot_t *)user_data;

	if (ret < 0)
		rd_ctx->ret = ccid2pcsc_errno(ret);
	else
		rd_ctx->ret = ret;
	if (rd_ctx->cb)
		rd_ctx->cb(rd_ctx);
}

static void __ccid_icc_status_cb(void *user_data, int ret)
{
	pcsc_slot_t *hd = (pcsc_slot_t *)user_data;
	uint8_t card_status;
	
	if (ret < 0)
		hd->ret = ccid2pcsc_errno(ret);
	else {
		/* whats this meaning? */
		/* card_status = (uint8_t)slot->card_status; */
		card_status = ret;
		if (card_status == CCID_CARD_PRESENT_ACTIVE)
			hd->icc->status = PCSC_ICC_PRESENT_POWERUP;
		else if (card_status == CCID_CARD_PRESENT_DEACTIVE)
			hd->icc->status = PCSC_ICC_PRESENT_POWERDOWN;
		else
			hd->icc->status = PCSC_ICC_ABSENT;
		hd->ret = PCSC_S_SUCCESS;
	}
	if (hd->cb)
		hd->cb(hd);
}

static int __ccid_desc_attr(void *lower, int type, void *v)
{
	ccid_desc_t *desc = ccid_desc_get(lower);
	uint8_t *u8_v = (uint8_t *)v;
	uint32_t *u32_v = (uint32_t *)v;

	if (!desc)
		return -1;

	switch (type) {
	case PCSC_GET_ATTR_NSLOT:
		/* slot index start from 0x00 */
		*u8_v = (desc->bMaxSlotIndex + 1);
		break;
	case PCSC_GET_ATTR_FEATURE:
		*u32_v = (desc->dwFeatures);
		break;
	case PCSC_GET_ATTR_VOLTAGE:
		*u8_v = (desc->bVoltageSupport);
		break;
	case PCSC_GET_ATTR_PROTOCOL:
		*u32_v = (desc->dwProtocols);
		break;
	default:
		break;
	}
	ccid_desc_put(lower);
	return 0;
}

/* pinpad feature */
static int __ccid_feature_pinpad(pcsc_slot_t *hd)
{
	uint8_t feature_tlv[11 * sizeof (struct pcsc_feature_tlv)];
	int i, num, len;
	struct pcsc_feature_tlv *tlv;
	pcsc_ifd_t *reader;

	reader = hd->ifd;

	memset(feature_tlv, 0, sizeof(feature_tlv));

	len = ccid_ifd_control(hd->idx, CM_IOCTL_GET_FEATURE_REQUEST, 
			 NULL, 0, feature_tlv, sizeof(feature_tlv), NULL, NULL);
	if (len < 0)
		return len;
	if (len % sizeof(struct pcsc_feature_tlv))
		return PCSC_F_INTERNAL_ERROR;
	num = len / sizeof(struct pcsc_feature_tlv);

	tlv = (struct pcsc_feature_tlv *)feature_tlv;
	for (i = 0; i < num; i++) {		
		switch (tlv[i].tag) {
		case FEATURE_VERIFY_PIN_START:
			reader->path10.verify_ioctl_start = ntohl(tlv[i].value);
			break;
		case FEATURE_VERIFY_PIN_FINISH:
			reader->path10.verify_ioctl_finish = ntohl(tlv[i].value);
			break;
		case FEATURE_MODIFY_PIN_START:
			reader->path10.modify_ioctl_start = ntohl(tlv[i].value);
			break;
		case FEATURE_MODIFY_PIN_FINISH:
			reader->path10.modify_ioctl_finish = ntohl(tlv[i].value);
			break;
		case FEATURE_VERIFY_PIN_DIRECT:
			reader->path10.verify_ioctl = ntohl(tlv[i].value);
			break;
		case FEATURE_MODIFY_PIN_DIRECT:
			reader->path10.modify_ioctl = ntohl(tlv[i].value);
			break;
		default:
			break;
		}
	}
	if (reader->path10.verify_ioctl ||
	    (reader->path10.verify_ioctl_start && 
	    reader->path10.verify_ioctl_finish)) {
		reader->keypad = 1;
		reader->path10.pinpad_support |= CCID_CLASS_PIN_VERIFY;
	}
	if (reader->path10.modify_ioctl ||
	    (reader->path10.modify_ioctl_start && 
	    reader->path10.modify_ioctl_finish)) {
		reader->keypad = 1;
		reader->path10.pinpad_support |= CCID_CLASS_PIN_MODIFY;
	}
	return 0;
}

static void __ccid_feature_level(pcsc_slot_t *hd)
{
	uint32_t dwFeature;

	__ccid_desc_attr(hd->ifd->lower, PCSC_GET_ATTR_FEATURE, &dwFeature);

	switch (dwFeature & CCID_CLASS_EXCHANGE_MASK) {
	case CCID_CLASS_TPDU:
		hd->ifd->level = IFD_LEVEL_TPDU;
		break;
	case CCID_CLASS_SHORT_APDU:
		hd->ifd->level = IFD_LEVEL_APDUS;
		break;
	case CCID_CLASS_EXTENDED_APDU:
		hd->ifd->level = IFD_LEVEL_APDUE;
		break;
	case CCID_CLASS_CHARACTER:
		hd->ifd->level = IFD_LEVEL_CHAR;
		break;
	default:
		BUG();
		return;
	}
}

static void __ccid_feature_voltage(pcsc_slot_t *hd)
{
	uint8_t bVoltageSupport;
	uint32_t dwFeature;


	__ccid_desc_attr(hd->ifd->lower, PCSC_GET_ATTR_VOLTAGE, &bVoltageSupport);

	/* reader support */
	if (bVoltageSupport & CCID_VOLTAGE_5V)
		hd->ifd->voltage |= PCSC_CLASS_A;
	if (bVoltageSupport & CCID_VOLTAGE_3V)
		hd->ifd->voltage |= PCSC_CLASS_B;
	if (bVoltageSupport & CCID_VOLTAGE_1_8V)
		hd->ifd->voltage |= PCSC_CLASS_C;

	__ccid_desc_attr(hd->ifd->lower, PCSC_GET_ATTR_FEATURE, &dwFeature);
	if (dwFeature & CCID_FEA_AUTO_VOL_SELECT) {
		/* reader auto */
		hd->ifd->voltage |= PCSC_CLASS_AUTO;
	}
}

static void __ccid_feature_protocol(pcsc_slot_t *hd)
{
	uint32_t dwProtocols;

	__ccid_desc_attr(hd->ifd->lower, PCSC_GET_ATTR_PROTOCOL, &dwProtocols);

	if (dwProtocols & CCID_PROTOCOL_T0)
		hd->ifd->protocol |= PCSC_PROTOCOL_T0;
	if (dwProtocols & CCID_PROTOCOL_T1)
		hd->ifd->protocol |= PCSC_PROTOCOL_T1;
	/* others not support */
}

static int __ccid_get_feature(pcsc_slot_t *hd)
{
	__ccid_feature_pinpad(hd);
	
	__ccid_feature_level(hd);

	__ccid_feature_voltage(hd);

	__ccid_feature_protocol(hd);

	return PCSC_S_SUCCESS;
}

static int __ccid_cancel(pcsc_slot_t *hd)
{
	int r = ccid_cancel(hd->idx);

	return ccid2pcsc_errno(r);
}

static int __ccid_icc_status(pcsc_slot_t *hd)
{
	int r;

	r = ccid_get_slot_status(hd->idx, (uint8_t *) &hd->icc->status, 
				 __ccid_icc_status_cb, hd);
	return ccid2pcsc_errno(r);
}

uint8_t ifd_voltage(pcsc_slot_t *hd)
{
	int id = hd->icc->voltage_id;

	if (id > 3 || id < 0)
		return PCSC_E_INVALID_PARAMETER;
	
	switch (id) {
	case 0:
		if (hd->ifd->voltage & PCSC_CLASS_AUTO)
			return PCSC_CLASS_AUTO;
		break;
	case 1:
		if (hd->ifd->voltage & PCSC_CLASS_A)
			return PCSC_CLASS_A;
		break;
	case 2:
		if (hd->ifd->voltage & PCSC_CLASS_B)
			return PCSC_CLASS_B;
		break;
	case 3: if (hd->ifd->voltage & PCSC_CLASS_C)
			return PCSC_CLASS_C;
		break;
	}
	return PCSC_CLASS_INVALID;
}

static uint8_t __ccid_voltage(uint8_t ifd_vol)
{
	switch (ifd_vol) {
	case PCSC_CLASS_A: return CCID_VOLTAGE_5V;
	case PCSC_CLASS_B: return CCID_VOLTAGE_3V;
	case PCSC_CLASS_C: return CCID_VOLTAGE_1_8V;
	case PCSC_CLASS_AUTO: return CCID_VOLTAGE_AUTO;
	}
	BUG();
	return 0;
}

static int __ccid_power_on(pcsc_slot_t *hd)
{
	int r;
	uint8_t ifd_vol = ifd_voltage(hd);

	if (ifd_vol == PCSC_CLASS_INVALID)
		return PCSC_E_INVALID_VOLTAGE;

	/* arrive end maybe */
	if (ifd_vol == PCSC_E_INVALID_PARAMETER)
		return PCSC_E_INVALID_PARAMETER;

	r = ccid_power_on(hd->idx, hd->icc->atr, sizeof(hd->icc->atr), __ccid_voltage(ifd_vol),
			  __ccid_power_on_cb, hd);
	return ccid2pcsc_errno(r);
}

static int __ccid_power_off(pcsc_slot_t *hd) 
{
	int r;
	r = ccid_power_off(hd->idx, (uint8_t *)&hd->icc->status,
			   __ccid_power_off_cb, hd);
	return ccid2pcsc_errno(r);
}

static int __ccid_xfr_block(pcsc_slot_t *hd, pcsc_transfer_t *pcsc_param)
{
	pcsc_slot_t *handle = pcsc_param->handle;
	int proto;
	int r;
	
	proto = pcsc_trans_proto(pcsc_param);
	if (proto == -1)
		return PCSC_E_INVALID_PARAMETER;

	r = ccid_xfrblock(handle->idx, proto, 
			  pcsc_param->ifd_param->sbuf, pcsc_param->ifd_param->sbuf_len,
			  pcsc_param->rbuf, pcsc_param->rbuf_len, 
			  __ccid_xfr_block_cb, pcsc_param);
	return ccid2pcsc_errno(r);
}

static	int __ccid_ifd_control(pcsc_slot_t *hd, pcsc_transfer_t *pcsc_param)
{
	int r;

	r = ccid_ifd_control(pcsc_param->handle->idx, pcsc_param->ioctl, 
			     pcsc_param->ifd_param->sbuf, pcsc_param->ifd_param->sbuf_len, 
			     pcsc_param->rbuf, pcsc_param->rbuf_len, 
			     __ccid_ifd_control_cb, pcsc_param);
	
	return ccid2pcsc_errno(r);
}

static int __ccid_init_proto(pcsc_slot_t *s, uint16_t proto)
{
	int r = ccid_init_proto(s->ifd->lower, proto);
	return ccid2pcsc_errno(r);
}

static	int __ccid_abort(pcsc_slot_t *hd)
{
	int r = ccid_abort(hd->idx);

	return ccid2pcsc_errno(r);
}

static ifd_driver_t ccid_ops = {
	"CCID",
	__ccid_desc_attr,
	__ccid_get_feature,
	__ccid_cancel,
	__ccid_icc_status,
	__ccid_power_on,
	__ccid_power_off,
	__ccid_xfr_block,
	__ccid_ifd_control,
	__ccid_init_proto,
	__ccid_abort,
};

/* data is lower: ccid_reader_t */
static int __ccid_handle_event(notify_t *nb, unsigned long event, void *data)
{
	switch (event) {
	case CCID_RDR_INSERT:
		/* reader insert, callup a handle */
		pcsc_ifd_create(CCID_RDR_NAME(data), CCID_RDR_TYPE(data), 
			        data, &ccid_ops);
		break;
	case CCID_RDR_REMOVE:
		/* reader remove, calldown a handle */
		pcsc_ifd_delete(CCID_RDR_NAME(data), CCID_RDR_TYPE(data), data);
		break;
	default:
		break;
	}
	return NOTIFY_DONE;
}

static notify_t ifd_handle_notify = {
	NULL,
	__ccid_handle_event,
	9,
};


int __init ifd_ccid_init(void)
{
	ccid_register_notify(&ifd_handle_notify);
	return 0;
}

void __exit ifd_ccid_exit(void)
{
	ccid_unregister_notify(&ifd_handle_notify);
}
