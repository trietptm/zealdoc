#include <linux/hbridge.h>
#include "hbr_priv.h"
#include "hbr_hash.h"

#define MOD_NAME	"half_bridge"
#define MOD_NAME_SHORT	"HBR"

#define HBR_PEER	0
#define HBR_CLIENT	1

/* test for get/put dev count */
static int count = 0;
static __be32 netmask_static;
/* FIXME: not all frame is vlan_tagged. */
static int hbr_vlan_open = 0;

static DEFINE_SPINLOCK(hbr_lock);

static struct hlist_head *hbr_hlist_byper;
static struct hlist_head *hbr_hlist_bycli;

#define for_each_cli_entry(e, n, i) \
		hlist_for_each_entry(e, n, (hbr_hlist_bycli + i), bycli)
#define for_each_cli_entry_safe(e, p, n, idx)	\
	hlist_for_each_entry_safe(e, p, n, (hbr_hlist_bycli + idx), bycli)

#define for_each_per_entry(e, n, i) \
		hlist_for_each_entry(e, n, (hbr_hlist_byper + i), byper)
#define for_each_per_entry_safe(e, p, n, idx)	\
	hlist_for_each_entry_safe(e, p, n, (hbr_hlist_byper + idx), byper)

static unsigned int hbr_hlist_hmask;
static unsigned int hbr_hlist_hashmax = 1 * 1024 * 1024;
static unsigned int hbr_entry_num;	/* entry in list */

#define HASH_ERR	(hbr_hlist_hmask + 1)

static inline void hbr_entry_put(struct hbr_entry *e)
{
	atomic_dec(&e->refcnt);
}
static inline void hbr_entry_hold(struct hbr_entry *e)
{
	atomic_inc(&e->refcnt);
}
static inline struct hbr_entry *hbr_entry_get(struct hbr_entry *e)
{
	hbr_entry_hold(e);
	return e;
}

static void hbr_put_dev(struct net_device *dev);
static struct net_device *hbr_get_dev(const char *name);

static void hbr_init_hlist_node(struct hbr_entry *e);

static void hbr_hash_grow_check(int have_hash_collision);

struct hbr_entry *hbr_new_entry(void);
static void hbr_build_free_entry(struct hbr_entry *e);
static int hbr_set_dst_entry(struct hbr_entry *e);
static void hbr_free_entry_lock(struct hbr_entry *e);
static void hbr_free_entry(struct hbr_entry *e);
static struct hbr_entry *hbr_x_find_entry(struct hbr_trans_entry *e);
static int hbr_check_dev_is_client(struct net_device *dev);

static struct hbr_entry *hbr_get_cli_entry_byattr(unsigned int idx,
			struct net_device *dev, __be32 per, __be32 cli);

static struct hbr_entry *hbr_get_per_entry_byattr(unsigned int idx,
			struct net_device *dev, __be32 per, __be32 cli);
static unsigned int
hbr_arp_in_hook(unsigned int hook, struct sk_buff **pskb,
		const struct net_device *in, const struct net_device *out,
		int (*okfn)(struct sk_buff *));

static unsigned int
hbr_ip_pre_routing_hook(unsigned int hook, struct sk_buff **pskb,
		const struct net_device *in, const struct net_device *out,
		int (*okfn)(struct sk_buff *));

static int hbr_device_event(struct notifier_block *this,
			    unsigned long event, void *ptr);

static struct notifier_block hbr_device_notifier = {
	.notifier_call = hbr_device_event,
};

static struct net_device __fake_net_dev = {
	.hard_header_len = ETH_HLEN
};

static struct dst_ops __fake_dst_ops = {
#ifndef USE_IPV6
	.family = 	AF_INET,
	.protocol = 	__constant_htons(ETH_P_IP),
	.entry_size = 	sizeof(struct rtable),
#else
	.family = 	AF_INET6,
	.protocol = 	__constant_htons(ETH_P_IPV6),
	.entry_size = 	sizeof(struct rt6_info),
#endif
};

static void hbr_rtable_init(struct rtable *rt, struct net_device *dev, __be32 gw)
{
	if (dev)
		rt->u.dst.dev = hbr_get_dev(dev->name);
	else
		/* do not want to see panic */
		rt->u.dst.dev = &__fake_net_dev;

	rt->u.dst.path		= &rt->u.dst;
	rt->u.dst.input		= ip_forward;
	rt->u.dst.output	= ip_output;
	rt->u.dst.ops 		= &__fake_dst_ops;
	rt->u.dst.metrics[RTAX_MTU - 1] = 1500;
	rt->u.dst.flags		= DST_NOPOLICY;

	rt->rt_gateway		= gw;
	rt->rt_flags		= 0;

	atomic_set(&rt->u.dst.__refcnt, 1);
}

static void hbr_rtable_exit(struct rtable *rt)
{
	if (rt) {
		if (atomic_dec_and_test(&rt->u.dst.__refcnt)) {
			if (rt->u.dst.dev && rt->u.dst.dev != &__fake_net_dev)
				hbr_put_dev(rt->u.dst.dev);
			if (rt->u.dst.neighbour)
				neigh_release(rt->u.dst.neighbour);
			kfree(rt);
		}
	}
}

static struct nf_hook_ops hb_hook_ops[] = {
	/* For arp hook */
	{
		.hook		= hbr_arp_in_hook,
		.owner		= THIS_MODULE,
		.pf		= NF_ARP,	/* No PF_ARP */
		.hooknum	= NF_ARP_IN,
		.priority	= NF_ARP_NUMHOOKS, /* 3 */
	},
	/* For ip hook */
	{
		.hook		= hbr_ip_pre_routing_hook,
	 	.owner		= THIS_MODULE,
		.pf		= PF_INET,
		.hooknum	= NF_IP_PRE_ROUTING,
		.priority	= NF_IP_PRI_FIRST,
	}
};

#define DEBUG_HBR	0
static struct net_device *hbr_get_dev(const char *name)
{
	struct net_device *dev = dev_get_by_name(name);
#if DEBUG_HBR
	if (dev)
		printk(KERN_DEBUG "HBR: get dev %s [%d]\n", name, ++count);
#endif
	return dev;
}

static void hbr_put_dev(struct net_device *dev)
{
	if (dev) {
#if DEBUG_HBR
		printk(KERN_DEBUG "HBR: put dev %s [%d]\n", dev->name, count--);
#endif
		dev_put(dev);
	}
}

int walk_free_entry(void)
{
	int i;
	struct hlist_node *node, *pos;
	struct hbr_entry *tmp;

	for (i = 0; i < hbr_hlist_hmask; i++) {
		for_each_cli_entry_safe(tmp, pos, node, i)
				hbr_free_entry_lock(tmp);
		for_each_per_entry_safe(tmp, pos, node, i)
				hbr_free_entry_lock(tmp);
	}

	return 0;
}

static int hbr_flush_dev_down(struct net_device *dev)
{
	/* walk hlist, find out dev and set invalid flag */
	int i;
	struct hlist_node *node, *pos;
	struct hbr_entry *tmp;

	spin_lock_bh(&hbr_lock);
	for (i = 0; i < hbr_hlist_hmask; i++) {
		for_each_cli_entry_safe(tmp, pos, node, i) {
			if (tmp->hbr_dev == dev &&
			    tmp->hbr_dev_valid != HBR_DEV_INVALID) {
				hbr_put_dev(tmp->hbr_dev);
				tmp->hbr_dev_valid = HBR_DEV_INVALID;
			}
			else if (tmp->ppp_dev == dev) {
				hbr_free_entry(tmp);
			}
		}
		for_each_per_entry_safe(tmp, pos, node, i) {
			if (tmp->hbr_dev == dev &&
			    tmp->hbr_dev_valid != HBR_DEV_INVALID) {
				hbr_put_dev(tmp->hbr_dev);
				tmp->hbr_dev_valid = HBR_DEV_INVALID;
			}
			else if (tmp->ppp_dev == dev) {
				hbr_free_entry(tmp);
			}
		}
	}
	spin_unlock_bh(&hbr_lock);
	return 0;
}

static int hbr_flush_dev_up(struct net_device *dev)
{
	/* walk hlist, find out dev and set invalid flag */
	int i;
	struct hlist_node *node;
	struct hbr_entry *tmp;

	spin_lock_bh(&hbr_lock);
	for (i = 0; i < hbr_hlist_hmask; i++) {
		for_each_cli_entry(tmp, node, i) {
			if (tmp->hbr_dev == dev &&
			    tmp->hbr_dev_valid == HBR_DEV_INVALID) {
				hbr_get_dev(tmp->hbr_dev->name);
				tmp->hbr_dev_valid = HBR_DEV_VALID;
			}
			else if (tmp->ppp_dev == dev) {
				printk(KERN_DEBUG "HBR: should be error occur %d",
						__LINE__);
			}
		}
		for_each_per_entry(tmp, node, i) {
			if (tmp->hbr_dev == dev &&
			    tmp->hbr_dev_valid == HBR_DEV_INVALID) {
				hbr_get_dev(tmp->hbr_dev->name);
				tmp->hbr_dev_valid = HBR_DEV_VALID;
			}
			else if (tmp->ppp_dev == dev) {
				printk(KERN_DEBUG "HBR: should be error occur %d",
						__LINE__);
			}
		}
	}
	spin_unlock_bh(&hbr_lock);
	return 0;
}

static int hbr_flush_dev_unreg(struct net_device *dev)
{
	/* walk hlist, find out dev and set invalid flag */
	int i;
	struct hlist_node *node;
	struct hbr_entry *tmp;

	spin_lock_bh(&hbr_lock);
	for (i = 0; i < hbr_hlist_hmask; i++) {
		for_each_cli_entry(tmp, node, i) {
			if (tmp->hbr_dev == dev)
				hbr_free_entry(tmp);
			else if (tmp->ppp_dev == dev) {
				printk(KERN_DEBUG "HBR: should be error occur %d",
						__LINE__);
			}
		}
		for_each_per_entry(tmp, node, i) {
			if (tmp->hbr_dev == dev)
				hbr_free_entry(tmp);
			else if (tmp->ppp_dev == dev) {
				printk(KERN_DEBUG "HBR: should be error occur %d",
						__LINE__);
			}
		}
	}
	spin_unlock_bh(&hbr_lock);
	return 0;
}

/* entry->hbr_dev_valid flags are controled by up/down event only */
static int hbr_device_event(struct notifier_block *this,
			    unsigned long event, void *ptr)
{
	struct net_device *dev = (struct net_device *)ptr;

	switch (event) {
		case NETDEV_DOWN:
			/* find hlist, put dev and set invalid
			 * Note: before DOWN event dev->flags is UP,
			 * so do not check IFF_UP */
			hbr_flush_dev_down(dev);
			break;
		case NETDEV_UP:
			/* unless our entry has linked with this dev,
			 * we don't care this up event */
			hbr_flush_dev_up(dev);
			break;
		case NETDEV_UNREGISTER:
			hbr_flush_dev_unreg(dev);
			break;
		default:
			break;
	}
	return NOTIFY_DONE;
}

static inline unsigned int hbr_client_hash(int i, __be32 per, __be32 cli,
			unsigned int hw_hash, unsigned int hmask)
{
	return __hbr_client_hash(i, per, cli, hw_hash, hmask);
}

static inline unsigned int hbr_client_hw_hash(unsigned char *hw_addr,
			int addr_len)
{
	int i;
	unsigned int h = addr_len;

	for (i = 0; i < addr_len; i++)
		h ^= hw_addr[i];
	return h;
}

static unsigned int hbr_x_client_hash(struct hbr_trans_entry *e)
{
	struct sockaddr_in *c = (struct sockaddr_in *)&e->client_ip;
	struct sockaddr_in *p = (struct sockaddr_in *)&e->peer_ip;
	struct sockaddr *hw_addr = (struct sockaddr *)&e->cli_hw_addr;
	struct net_device *dev = NULL;
	unsigned int h, hw_hash;
	unsigned short ifindex;
	__be32 c_ip, p_ip;

	if ((dev = hbr_get_dev(e->hbr_dev)) != NULL) {
		c_ip = c->sin_addr.s_addr;
		p_ip = p->sin_addr.s_addr;
		hw_hash = hbr_client_hw_hash(hw_addr->sa_data, dev->addr_len);

		if (e->vlan_open)
			ifindex = dev->ifindex ^ e->vlan_id;
		else
			ifindex = dev->ifindex;

		h = __hbr_client_hash(ifindex, p_ip,
				      c_ip, hw_hash, hbr_hlist_hmask);
		hbr_put_dev(dev);
		return h;
	}

	printk(KERN_ERR "HBR: %s cannot get dev %s\n", __FUNCTION__, e->hbr_dev);
	return HASH_ERR;
}

static unsigned int hbr_x_peer_hash(struct hbr_trans_entry *e)
{
	struct sockaddr_in *c = (struct sockaddr_in *)&e->client_ip;
	struct sockaddr_in *p = (struct sockaddr_in *)&e->peer_ip;
	struct net_device *dev = NULL;
	unsigned int h;
	__be32 c_ip, p_ip;

	if ((dev = hbr_get_dev(e->ppp_dev)) != NULL) {
		c_ip = c->sin_addr.s_addr;
		p_ip = p->sin_addr.s_addr;
		h = __hbr_peer_hash(dev->ifindex, p_ip,
				      c_ip, hbr_hlist_hmask);
		hbr_put_dev(dev);
		return h;
	}

	printk(KERN_DEBUG "HBR: client hash err, cannot get dev %s\n", e->ppp_dev);
	return HASH_ERR;
}
static inline unsigned int hbr_peer_hash(int i, __be32 per, __be32 cli,
					unsigned int hmask)
{
	return __hbr_peer_hash(i, per, cli, hmask);
}

/*
 * In here, we'll check src_ip/src_mac/tar_ip/ethX
 * ethX is the one that connect with work PC
 * tar_ip is ISP's ip address
 * src_ip is given ip address by ISP
 * src_mac is work PC'w hw_addr
 */
static unsigned int
hbr_arp_in_hook(unsigned int hook, struct sk_buff **pskb,
		const struct net_device *in, const struct net_device *out,
		int (*okfn)(struct sk_buff *))
{
	struct hbr_entry entry, *e;
	/* FIXME: the way */
	struct arphdr *arp = arp_hdr(*pskb);
	unsigned char *arp_ptr;
	const struct net_device *dev = in;
	unsigned char *hw_addr;
	__be32 addr;
	unsigned short ifindex;
	unsigned short vlan_id = 0;

	if (dev == NULL)
		goto out;

	if (hbr_vlan_open == 1) {
		if (dev->features & NETIF_F_VLAN_CHALLENGED) {
			printk(KERN_DEBUG "%s not support vlan.\n", dev->name);
		} else {
			printk(KERN_DEBUG "%s support vlan.\n", dev->name);
			vlan_id = VLAN_DEV_INFO(dev)->vlan_id;
		}
	}

	memset(&entry, 0, sizeof(entry));

	switch (dev->type) {
	default:
		if (arp->ar_pro != htons(ETH_P_IP) ||
		    htons(dev->type) != arp->ar_hrd)
			goto out;
		break;
#ifdef CONFIG_NET_ETHERNET
	case ARPHRD_ETHER:
#endif
#ifdef CONFIG_TR
	case ARPHRD_IEEE802_TR:
#endif
#ifdef CONFIG_FDDI
	case ARPHRD_FDDI:
#endif
#ifdef CONFIG_NET_FC
	case ARPHRD_IEEE802:
#endif
#if defined(CONFIG_NET_ETHERNET) || defined(CONFIG_TR) || \
    defined(CONFIG_FDDI)	 || defined(CONFIG_NET_FC)
		/*
		 * ETHERNET, Token Ring and Fibre Channel (which are IEEE 802
		 * devices, according to RFC 2625) devices will accept ARP
		 * hardware types of either 1 (Ethernet) or 6 (IEEE 802.2).
		 * This is the case also of FDDI, where the RFC 1390 says that
		 * FDDI devices should accept ARP hardware of (1) Ethernet,
		 * however, to be more robust, we'll accept both 1 (Ethernet)
		 * or 6 (IEEE 802.2)
		 */
		if ((arp->ar_hrd != htons(ARPHRD_ETHER) &&
		     arp->ar_hrd != htons(ARPHRD_IEEE802)) ||
		     arp->ar_pro != htons(ETH_P_IP))
			goto out;
		break;
#endif
#if defined(CONFIG_AX25) || defined(CONFIG_AX25_MODULE)
	case ARPHRD_AX25:
		if (arp->ar_pro != htons(AX25_P_IP) ||
		    arp->ar_hrd != htons(ARPHRD_AX25))
			goto out;
		break;
#if defined(CONFIG_NETROM) || defined(CONFIG_NETROM_MODULE)
	case ARPHRD_NETROM:
		if (arp->ar_pro != htons(AX25_P_IP) ||
		    arp->ar_hrd != htons(ARPHRD_NETROM))
			goto out;
		break;
#endif
#endif
	}

	/* Understand only arp request message */
	if (arp->ar_op != htons(ARPOP_REQUEST))
		goto out;

/*
 *	Extract fields, note offset
 */
	/* FIXME: only handle ethernet/ipv4 packet */
	if (dev->type == ARPHRD_ETHER) {
		hw_addr = arp_ptr= (unsigned char *)(arp+1);
		/* offset is ethernet hw addr ETH_ALEN */
		arp_ptr += dev->addr_len;
		memcpy(&entry.client, arp_ptr, 4);
		arp_ptr += 4;
		arp_ptr += dev->addr_len;
		memcpy(&entry.peer, arp_ptr, 4);
		entry.hbr_dev = (struct net_device *)dev;

		if (LOOPBACK(entry.peer) || MULTICAST(entry.peer))
			goto out;

		if (entry.peer == 0 || entry.client == 0)
			goto out;

		if (netmask_static != 0)
			addr = entry.client & netmask_static;
		else
			addr = entry.client;

		entry.cli_hw_hash = hbr_client_hw_hash(hw_addr,
					(int)dev->addr_len);

		if (hbr_vlan_open == 1)
			ifindex = dev->ifindex ^ vlan_id;
		else
			ifindex = dev->ifindex;

		entry.cli_idx = hbr_client_hash(ifindex, entry.peer,
						addr, entry.cli_hw_hash,
						hbr_hlist_hmask);

		e = hbr_get_cli_entry_byattr(entry.cli_idx,
				entry.hbr_dev, entry.peer, entry.client);
		if (e) {
			arp_send(ARPOP_REPLY, ETH_P_ARP,
				 entry.client, (struct net_device *)dev,
				 entry.peer, hw_addr,
				 (unsigned char *)dev->dev_addr,
				 (unsigned char *)dev->dev_addr);
			hbr_entry_put(e);
			return NF_STOLEN;
		}
	}
out:
	return NF_ACCEPT;
}

static unsigned int
hbr_ip_pre_routing_hook(unsigned int hook, struct sk_buff **pskb,
		const struct net_device *in, const struct net_device *out,
		int (*okfn)(struct sk_buff *))
{
	/* FIXME: the way */
	struct iphdr *ip = ip_hdr(*pskb);
	struct hbr_entry entry, *e;
	struct net_device *dev = (struct net_device *)in;
	struct sk_buff *skb = *pskb;
	__be32 addr;
	unsigned char *hw_addr;
	unsigned short ifindex, vlan_id = 0;
	int from_cli = -1;

	if (dev == NULL)
		goto out;

	memset(&entry, 0, sizeof(entry));

	if (!ip && ip->version != 4)
		goto out;

	if (LOOPBACK(ip->saddr) || MULTICAST(ip->saddr))
		goto out;

	/* TODO: now need support two virtual interface's talk.
	 * So dev->type with these two nic is ARPHRD_PPP and
	 * current code cannot do that. */
	if (dev->type == ARPHRD_ETHER) {
		/* Note the offset */
		if (hbr_vlan_open == 1) {
			if (dev->features & NETIF_F_VLAN_CHALLENGED) {
				printk(KERN_DEBUG "%s not support vlan.\n",
						dev->name);
			} else {
				printk(KERN_DEBUG "%s support vlan.\n",
						dev->name);
				vlan_id = VLAN_DEV_INFO(dev)->vlan_id;
			}
		}

		/* FIXME: which header, the offset */
#if 0
		hw_addr = skb->mac.raw + ETH_ALEN;
#endif
		hw_addr = skb->mac_header;
		entry.client = ip->saddr;
		entry.peer = ip->daddr;
		entry.hbr_dev = dev;

		if (netmask_static != 0)
			addr = entry.client & netmask_static;
		else
			addr = entry.client;


		if (hbr_vlan_open == 1)
			ifindex = dev->ifindex ^ vlan_id;
		else
			ifindex = dev->ifindex;

		entry.cli_hw_hash = hbr_client_hw_hash(hw_addr,
					(int)dev->addr_len);
		entry.cli_idx = hbr_client_hash(ifindex, entry.peer,
						addr, entry.cli_hw_hash,
						hbr_hlist_hmask);

		dev_hold(dev);
		e = hbr_get_cli_entry_byattr(entry.cli_idx,
				entry.hbr_dev, entry.peer, entry.client);
		dev_put(dev);
		if (e) {
			if (e->rt_cli) {
				skb->dst = (struct dst_entry *)e->rt_cli;
				dst_hold(skb->dst);
			}
			hbr_entry_put(e);
			goto out;
		}
	} else if (dev->type == ARPHRD_PPP) {

		/* I dont know what's in this packet. Need test... */
		from_cli = hbr_check_dev_is_client(dev);
		/* Now support !from_cli PPP Packet */
		if (from_cli) {
#if 0
			/* Can use ARPHRD_ETHER handle? */
			hw_addr = skb->mac.raw + ETH_ALEN;
			entry.client = ip->saddr;
			entry.peer = ip->daddr;
			entry.hbr_dev = dev;

			if (netmask_static != 0)
				addr = entry.client & netmask_static;
			else
				addr = entry.client;

			if (hbr_vlan_open == 1)
				ifindex = dev->ifindex ^ vlan_id;
			else
				ifindex = dev->ifindex;

			entry.cli_hw_hash = hbr_client_hw_hash(hw_addr,
					(int)dev->addr_len);
			entry.cli_idx = hbr_client_hash(ifindex, entry.peer,
					addr, entry.cli_hw_hash,
					hbr_hlist_hmask);

			dev_hold(dev);
			e = hbr_get_cli_entry_byattr(entry.cli_idx,
					entry.hbr_dev, entry.peer, entry.client);
			dev_put(dev);
			if (e) {
				if (e->rt_cli) {
					skb->dst = (struct dst_entry *)e->rt_cli;
					dst_hold(skb->dst);
				}
				hbr_entry_put(e);
				goto out;
			}
#endif
			printk("PPP packet come from client. No handler...\n");
			goto out;
		}
		entry.peer = ip->saddr;
		entry.client = ip->daddr;
		entry.ppp_dev = dev;

		if (netmask_static != 0)
			addr = entry.client & netmask_static;
		else
			addr = entry.client;

		/* Proxy ppp do not need vlan_id */
		entry.per_idx = hbr_peer_hash(dev->ifindex, entry.peer,
					       addr, hbr_hlist_hmask);

		dev_hold(dev);
		e = hbr_get_per_entry_byattr(entry.per_idx, entry.ppp_dev,
				entry.peer, entry.client);
		dev_put(dev);
		if (e) {
			if (e->rt_per) {
				skb->dst = (struct dst_entry *)e->rt_per;
				dst_hold(skb->dst);
			}
			hbr_entry_put(e);
			goto out;
		}
	}
out:
	/* we don't steal this packet, just modify dst_entry */
	return NF_ACCEPT;
}

static struct hbr_entry *hbr_get_cli_entry_byattr(unsigned int idx,
			struct net_device *dev, __be32 per, __be32 cli)
{
	struct hlist_node *node;
	struct hbr_entry *tmp;

	spin_lock_bh(&hbr_lock);
	for_each_cli_entry(tmp, node, idx) {
		if (tmp->hbr_dev_valid == HBR_DEV_VALID &&
		    tmp->hbr_dev == dev &&
		    tmp->peer == per &&
		    tmp->client == cli) {
			hbr_entry_hold(tmp);
			spin_unlock_bh(&hbr_lock);
			return tmp;
		}
	}
	spin_unlock_bh(&hbr_lock);
	return NULL;
}

static struct hbr_entry *hbr_get_per_entry_byattr(unsigned int idx,
			struct net_device *dev, __be32 per, __be32 cli)
{
	struct hlist_node *node;
	struct hbr_entry *tmp;

	spin_lock_bh(&hbr_lock);
	for_each_per_entry(tmp, node, idx) {
		if (tmp->hbr_dev_valid == HBR_DEV_VALID &&
		    tmp->ppp_dev == dev &&
		    tmp->peer == per &&
		    tmp->client == cli) {
			/* Note to put */
			hbr_entry_hold(tmp);
			spin_unlock_bh(&hbr_lock);
			return tmp;
		}
	}
	spin_unlock_bh(&hbr_lock);
	return NULL;
}

struct hbr_entry *hbr_x_get_entry(struct hbr_trans_entry *e)
{
	struct hbr_entry *entry = hbr_x_find_entry(e);
	if (entry)
		hbr_entry_hold(entry);
	return entry;
}

void hbr_x_put_entry(struct hbr_entry *e)
{
	if (e)
		hbr_entry_put(e);
}

/* Check whether this dev is in our client entry list */
static int hbr_check_dev_is_client(struct net_device *dev)
{
	unsigned int hw_hash;
	int i, res = 0;
	struct hbr_entry *tmp;
	struct hlist_node *node;

	/* FIXME: where is the L2 header position */
	hw_hash = hbr_client_hw_hash(dev->perm_addr, dev->addr_len);

	/* walk list to compare hw_hash */
	spin_lock_bh(&hbr_lock);
	for (i = 0; i < hbr_hlist_hmask; i++) {
		for_each_cli_entry(tmp, node, i) {
			if (tmp->cli_hw_hash == hw_hash) {
				res = 1;
				break;
			}
		}
	}
	spin_unlock_bh(&hbr_lock);
	return res;
}

/* called by nl_del which get entry and want to delete this entry */
void hbr_nl_free_entry(struct hbr_entry *e)
{
	spin_lock_bh(&hbr_lock);
	hbr_entry_put(e);
	hbr_free_entry(e);
	spin_unlock_bh(&hbr_lock);
}

static struct hbr_entry *hbr_x_find_entry(struct hbr_trans_entry *e)
{
	unsigned int h_cli, h_per;
	struct hlist_node *cli_n, *per_n;
	struct hbr_entry *cli_tmp, *per_tmp;
	struct sockaddr_in *c = (struct sockaddr_in *)&e->client_ip;
	struct sockaddr_in *p = (struct sockaddr_in *)&e->peer_ip;

	h_cli = hbr_x_client_hash(e);
	h_per = hbr_x_peer_hash(e);

	spin_lock_bh(&hbr_lock);
	for_each_cli_entry(cli_tmp, cli_n, h_cli)
		for_each_per_entry(per_tmp, per_n, h_per) {
		/* This comparsion is not good, it's lack of dev */
		if (cli_tmp == per_tmp &&
		    cli_tmp->hbr_dev_valid == HBR_DEV_VALID &&
		    c->sin_addr.s_addr == cli_tmp->client &&
		    p->sin_addr.s_addr == cli_tmp->peer) {
			spin_unlock_bh(&hbr_lock);
			return cli_tmp;
		}
	}
	spin_unlock_bh(&hbr_lock);
	return NULL;
}

void hbr_insert_entry(struct hbr_entry *e)
{
	spin_lock_bh(&hbr_lock);
	hlist_add_head(&e->byper, (hbr_hlist_byper + e->per_idx));
	hlist_add_head(&e->bycli, (hbr_hlist_bycli + e->cli_idx));

	hbr_entry_num++;
	hbr_hash_grow_check(e->bycli.next != NULL);
	spin_unlock_bh(&hbr_lock);
}

int hbr_x_verify_entry(struct hbr_trans_entry *e)
{
	/* TODO: check which attribute? */
	return 0;
}

struct hbr_entry *hbr_new_entry(void)
{
	/* kzalloc: alloc and set 0 */
	struct hbr_entry *e = kzalloc(sizeof(struct hbr_entry), GFP_KERNEL);

	if (!e) {
		printk(KERN_ERR "hbr: kzalloc hbr entry failure.\n");
		return NULL;
	}

	hbr_init_hlist_node(e);

	atomic_set(&e->refcnt, 1);

	return e;
}

struct hbr_entry *hbr_build_entry(struct hbr_trans_entry *entry)
{
	struct hbr_entry *e;
	struct sockaddr_in *c = (struct sockaddr_in *)&entry->client_ip;
	struct sockaddr_in *p = (struct sockaddr_in *)&entry->peer_ip;
	int addr_len = 0;

	e = hbr_new_entry();
	if (!e)
		return NULL;

	if (entry->vlan_open) {
		e->vlan_id = entry->vlan_id;
		hbr_vlan_open = 1;
	} else {
		hbr_vlan_open = 0;
		e->vlan_id = -1;
	}

	e->cli_idx = hbr_x_client_hash(entry);
	e->per_idx = hbr_x_peer_hash(entry);

	if (e->cli_idx == HASH_ERR || e->per_idx == HASH_ERR)
		goto err;

	if (entry->cli_hw_addr.sa_family == ARPHRD_ETHER) {
		e->cli_hw_hash = hbr_client_hw_hash(entry->cli_hw_addr.sa_data,
						    ETH_ALEN);
		addr_len = ETH_ALEN;
	} else {
		/* arrive at here its an error now */
		e->cli_hw_hash = 0;
		addr_len = 0;
	}

	e->hbr_dev = hbr_get_dev(entry->hbr_dev);
	e->ppp_dev = hbr_get_dev(entry->ppp_dev);
	if (!e->hbr_dev || !e->ppp_dev)
		goto err;

	e->peer   = p->sin_addr.s_addr;
	e->client = c->sin_addr.s_addr;

	/* Currently, cannot set dst entry is not err.
	 * But we should not proxy that dst request.
	 * TODO: need a timeout to ensure we have dst entry and neighbour. */
	hbr_set_dst_entry(e);

	if ((e->hbr_dev->flags & IFF_UP) &&
	    (e->ppp_dev->flags & IFF_UP))
		e->hbr_dev_valid = HBR_DEV_VALID;
	else {
		printk(KERN_ERR "HBR: build fail since dev is not up.\n");
		goto err;
	}

	hbr_insert_entry(e);
	return e;
err:
	hbr_build_free_entry(e);
	return NULL;
}

/* only use in build function */
static void hbr_build_free_entry(struct hbr_entry *e)
{
	if (e) {
		if (atomic_dec_and_test(&e->refcnt)) {
			if (e->ppp_dev) {
				hbr_put_dev(e->ppp_dev);
			}
			/* Not care hbr flag here. */
			if (e->hbr_dev)
				hbr_put_dev(e->hbr_dev);

			kfree(e);
		} else
			BUG();
	}
}

static void hbr_free_entry_lock(struct hbr_entry *e)
{
	spin_lock_bh(&hbr_lock);
	hbr_free_entry(e);
	spin_unlock_bh(&hbr_lock);
}

static void hbr_free_entry(struct hbr_entry *e)
{
	if (!e)
		return;

	if (atomic_dec_and_test(&e->refcnt)) {
		if (e->ppp_dev)
			hbr_put_dev(e->ppp_dev);
		if (e->hbr_dev)
			hbr_put_dev(e->hbr_dev);

		hbr_rtable_exit(e->rt_per);
		hbr_rtable_exit(e->rt_cli);

		hlist_del(&e->bycli);
		hlist_del(&e->byper);

		kfree(e);
		hbr_entry_num--;
	}
}

static int hbr_dst_entry_set_bytype(struct hbr_entry *e, int type)
{
	int res;
	struct rtable *rt;

	rt = kzalloc(sizeof(struct rtable), GFP_KERNEL);
	if (rt) {
		/* Now only two kinds of type */
		if (type == HBR_PEER)
			hbr_rtable_init(rt, e->hbr_dev, e->client);
		else
			hbr_rtable_init(rt, e->ppp_dev, e->peer);
	} else
		return -1;
	res = arp_bind_neighbour((struct dst_entry *)rt);
	if (res != 0) {
		printk(KERN_DEBUG "HBR: No neighbour find.\n");
		hbr_rtable_exit(rt);
		return -1;
	}

	if (type == HBR_PEER)
		e->rt_per = rt;
	else
		e->rt_cli = rt;
	return 0;
}

static int hbr_set_dst_entry(struct hbr_entry *e)
{
	if (hbr_dst_entry_set_bytype(e, HBR_PEER) ||
	    hbr_dst_entry_set_bytype(e, HBR_CLIENT))
		return 1;
	/* set succ */
	return 0;
}

/* dynamic hlist implement */
static unsigned long hbr_hash_new_size(void);
static void hbr_hash_resize(struct work_struct *unused);
static DECLARE_WORK(hbr_hash_work, hbr_hash_resize);

static void hbr_hash_grow_check(int have_hash_collision)
{
	if (have_hash_collision &&
	    (hbr_hlist_hmask + 1) < hbr_hlist_hashmax &&
	    hbr_entry_num > hbr_hlist_hmask)
		schedule_work(&hbr_hash_work);
}

void hbr_dump_entrys(void)
{
	struct hlist_node *pos, *node;
	struct hbr_entry *x;
	int i, num = 1;

	printk(KERN_DEBUG "HBR: dump entry:\n");
	spin_lock_bh(&hbr_lock);
	for (i = 0; i < hbr_hlist_hmask; i++) {
		for_each_cli_entry_safe(x, pos, node, i) {
			printk(KERN_DEBUG "entry_no=%d\n", num++);
			/* HIPQUAD from kernel.h */
			printk(KERN_DEBUG "peer_ip="NIPQUAD_FMT"\t\tclient="NIPQUAD_FMT"\n",
					HIPQUAD(x->peer), HIPQUAD(x->client));
			printk(KERN_DEBUG "peer_idx=%d\t\tclient_idx=%d\n",
					x->per_idx, x->cli_idx);
			printk(KERN_DEBUG "hbr_dev[%d]: %s ppp_dev: %s\n",
					x->hbr_dev_valid,
					x->hbr_dev->name, x->ppp_dev->name);
		}
	}
	spin_unlock_bh(&hbr_lock);
}

int hbr_dump_entry(struct hbr_trans_entry *e)
{
	return -1;
}

static void hbr_hash_transfer(struct hlist_head *list,
			       struct hlist_head *nclitable,
			       struct hlist_head *npertable,
			       unsigned int nhashmask)
{
	struct hlist_node *entry, *tmp;
	struct hbr_entry *x;
	__be32 addr;
	unsigned short ifindex;

	hlist_for_each_entry_safe(x, entry, tmp, list, bycli) {
		unsigned int h1, h2;

		if (netmask_static != 0)
			addr = x->client & netmask_static;
		else
			addr = x->client;

		if (hbr_vlan_open)
			ifindex = x->hbr_dev->ifindex ^ x->vlan_id;
		else
			ifindex = x->hbr_dev->ifindex;

		h1 = hbr_client_hash(ifindex, x->peer,
			   	    addr, x->cli_hw_hash,
				    nhashmask);
		hlist_add_head(&x->bycli, nclitable + h1);

		h2 = hbr_peer_hash(x->ppp_dev->ifindex, x->peer,
				  addr, nhashmask);
		hlist_add_head(&x->byper, npertable + h2);
		x->cli_idx = h1;
		x->per_idx = h2;
	}
}

static unsigned long hbr_hash_new_size(void)
{
	return ((hbr_hlist_hmask + 1) << 1) * sizeof(struct hlist_head);
}

static DEFINE_MUTEX(hash_resize_mutex);

static void hbr_hash_resize(struct work_struct *unused)
{
	struct hlist_head *ncli, *nper, *ocli, *oper;
	unsigned long nsize, osize;
	unsigned int nhashmask, ohashmask;
	int i;

	mutex_lock(&hash_resize_mutex);

	printk(KERN_DEBUG "HBR: hlist resize...\n");

	nsize = hbr_hash_new_size();
	ncli = hbr_hash_alloc(nsize);
	if (!ncli)
		goto out_unlock;
	nper = hbr_hash_alloc(nsize);
	if (!nper) {
		hbr_hash_free(ncli, nsize);
		goto out_unlock;
	}

	spin_lock_bh(&hbr_lock);

	nhashmask = (nsize / sizeof(struct hlist_head)) - 1U;
	for (i = hbr_hlist_hmask; i >= 0; i--)
		hbr_hash_transfer(hbr_hlist_bycli + i, ncli, nper,
				   nhashmask);
	ocli = hbr_hlist_bycli;
	oper = hbr_hlist_byper;
	ohashmask = hbr_hlist_hmask;

	hbr_hlist_bycli = ncli;
	hbr_hlist_byper = nper;
	hbr_hlist_hmask = nhashmask;

	spin_unlock_bh(&hbr_lock);

	osize = (ohashmask + 1) * sizeof(struct hlist_head);
	hbr_hash_free(ocli, osize);
	hbr_hash_free(oper, osize);

out_unlock:
	mutex_unlock(&hash_resize_mutex);
}

static void hbr_init_hlist_node(struct hbr_entry *e)
{
	INIT_HLIST_NODE(&e->bycli);
	INIT_HLIST_NODE(&e->byper);
}

static int hbr_list_init(void)
{
	unsigned int sz;
	int i, ret = 0;

	sz = sizeof(struct hlist_head) * 8;
	hbr_hlist_hmask = ((sz / sizeof(struct hlist_head)) - 1);

	hbr_hlist_bycli = hbr_hash_alloc(sz);
	hbr_hlist_byper = hbr_hash_alloc(sz);

	if (!hbr_hlist_bycli || !hbr_hlist_byper) {
		printk(KERN_ERR "HBR: Cannot alloc byper/bycli hashes.");
		ret = -1;
		goto out;
	}

	for (i = 0; i < hbr_hlist_hmask; i++) {
		INIT_HLIST_HEAD(hbr_hlist_bycli + i);
		INIT_HLIST_HEAD(hbr_hlist_byper + i);
	}
out:
	return ret;
}

void hbr_list_exit(void)
{
	if (hbr_hlist_bycli)
		hbr_hash_free(hbr_hlist_bycli,
			      (hbr_hlist_hmask + 1) * sizeof(struct hlist_head));
	if (hbr_hlist_byper)
		hbr_hash_free(hbr_hlist_byper,
			      (hbr_hlist_hmask + 1) * sizeof(struct hlist_head));
}

static int __init hbr_init(void)
{
	int ret;
	ret = hbr_list_init();
	if (ret != 0)
		goto fail0;

	ret = hbr_nl_init();
	if (ret != 0)
		goto fail0;

	ret = register_netdevice_notifier(&hbr_device_notifier);
	if (ret < 0)
		goto fail1;

	nf_register_hooks(hb_hook_ops, ARRAY_SIZE(hb_hook_ops));

	printk(KERN_INFO "HBR: starting half bridge\n");
out:
	return 0;
fail1:
	hbr_nl_exit();
fail0:
	hbr_list_exit();
	goto out;
}

/* process context */
static void __exit hbr_exit(void)
{
	nf_unregister_hooks(hb_hook_ops, ARRAY_SIZE(hb_hook_ops));
	unregister_netdevice_notifier(&hbr_device_notifier);
	hbr_nl_exit();
	walk_free_entry();
	hbr_list_exit();
	printk(KERN_INFO "HBR: exiting half bridge\n");
}

module_init(hbr_init);
module_exit(hbr_exit);
MODULE_LICENSE("GPL");
