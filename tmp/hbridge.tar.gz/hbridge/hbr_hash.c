#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/bootmem.h>
#include <linux/vmalloc.h>
#include <linux/list.h>
#include <linux/slab.h>

#include "hbr_hash.h"

struct hlist_head *hbr_hash_alloc(unsigned int sz)
{
	struct hlist_head *n = NULL;

	if (sz <= PAGE_SIZE)
		n = kzalloc(sz, GFP_KERNEL);

#ifndef MODULE
	else if (hashdist)
		n = __vmalloc(sz, GFP_KERNEL | __GFP_ZERO, PAGE_KERNEL);
#endif
	else
		n = (struct hlist_head *)
			__get_free_pages(GFP_KERNEL | __GFP_NOWARN | __GFP_ZERO,
					 get_order(sz));
	return n;
}

void hbr_hash_free(struct hlist_head *n, unsigned int sz)
{
	if (sz <= PAGE_SIZE)
		kfree(n);
#ifndef MODULE
	else if (hashdist)
		vfree(n);
#endif
	else
		free_pages((unsigned long)n, get_order(sz));
}

