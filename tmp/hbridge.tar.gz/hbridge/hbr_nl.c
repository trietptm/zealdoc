/* half bridge netlink socket implement */
#include <linux/hbridge.h>
#include "hbr_priv.h"

/* our netlink is so simple now. entry struct is follow nlh and no attr. */
static int hbr_nl_add(struct sk_buff *skb, struct nlmsghdr *nlh, struct rtattr **arg)
{
	struct hbr_trans_entry *e = NLMSG_DATA(nlh);
	struct hbr_entry *entry = NULL;
	int err;

	/* Now it's empty */
	err = hbr_x_verify_entry(e);
	if (err != 0) {
		printk(KERN_ERR "HBR_NL: verify error.\n");
		return err;
	}
	/* find and get */
	entry = hbr_x_get_entry(e);
	if (entry) {
		printk(KERN_DEBUG "HBR_NL: fail, an existed entry.\n");
		hbr_x_put_entry(entry);
		return -EEXIST;
	}
	entry = hbr_build_entry(e);
	if (!entry)
		return -1;

	printk(KERN_DEBUG "HBR_NL: hbr nl add success\n");

	return 0;
}

static int hbr_nl_del(struct sk_buff *skb, struct nlmsghdr *nlh, struct rtattr **arg)
{
	struct hbr_trans_entry *e = NLMSG_DATA(nlh);
	struct hbr_entry *res = NULL;

	res = hbr_x_get_entry(e);
	if (res) {
		printk("HBR_NL: find entry, now delete it.\n");
		/* not same as free_entry_lock */
		hbr_nl_free_entry(res);
	}
	return 0;
}

static int hbr_nl_get(struct sk_buff *skb, struct nlmsghdr *nlh, struct rtattr **arg)
{
	/* just dump these entrys and no reply to user */
	hbr_dump_entrys();
	return 0;
}

static int hbr_nl_dump(struct sk_buff *skb, struct netlink_callback *cb)
{
	printk("%s\n", __FUNCTION__);
	return 0;
}

static const int hbr_nlmsg_min[HBRM_NR_MSGTYPES] = {
	[HBRM_NEWHBR - HBRM_BASE] = NLMSG_LENGTH(sizeof(struct hbr_trans_entry)),
	[HBRM_DELHBR - HBRM_BASE] = NLMSG_LENGTH(sizeof(struct hbr_trans_entry)),
	[HBRM_GETHBR - HBRM_BASE] = NLMSG_LENGTH(sizeof(struct hbr_trans_entry)),
};

struct hbr_link {
	int (*doit)(struct sk_buff *skb, struct nlmsghdr *h, struct rtattr **);
	int (*dump)(struct sk_buff *skb, struct netlink_callback *cb);
} hbr_link_table[HBRM_NR_MSGTYPES] = {
	 [HBRM_NEWHBR - HBRM_BASE] = { .doit 	= hbr_nl_add	},
	 [HBRM_DELHBR - HBRM_BASE] = { .doit 	= hbr_nl_del	},
	 [HBRM_GETHBR - HBRM_BASE] = { .doit 	= hbr_nl_get,
				       .dump	= hbr_nl_dump	},
};

struct sock *hbr_nl;
static DEFINE_MUTEX(hbr_nl_mutex);

static int hbr_user_rcv_msg(struct sk_buff *skb, struct nlmsghdr *nlh)
{
	struct rtattr *hbra[HBRA_MAX];
	struct hbr_link *link;
	int type, min_len;

	if (!(nlh->nlmsg_flags & NLM_F_REQUEST))
		return -EINVAL;

	type = nlh->nlmsg_type;

	if (type < HBRM_BASE || type > HBRM_MAX)
		return -EINVAL;

	/* justfy type to corresponding rigth messgae */
	type -= HBRM_BASE;
	link = &hbr_link_table[type];

	/* All operations require privileges, even GET */
	if (security_netlink_recv(skb, CAP_NET_ADMIN)) {
		return -EPERM;
	}

	/* get entry need dump it */
	if (type == HBRM_GETHBR - HBRM_BASE &&
	    nlh->nlmsg_flags & NLM_F_DUMP) {
		if (link->dump == NULL) {
			printk("HBR_NL: user require dump but"
					"module not support it.\n");
			return -EINVAL;
		}
		return netlink_dump_start(hbr_nl, skb, nlh, link->dump, NULL);
	}

	memset(hbra, 0, sizeof(hbra));

	if (nlh->nlmsg_len < (min_len = hbr_nlmsg_min[type]))
		return -EINVAL;

	if (nlh->nlmsg_len > min_len) {
		int attrlen = nlh->nlmsg_len - NLMSG_ALIGN(min_len);
		struct rtattr *attr = (void *)nlh + NLMSG_ALIGN(min_len);

		while (RTA_OK(attr, attrlen)) {
			unsigned short flavor = attr->rta_type;
			if (flavor) {
				if (flavor > HBRA_MAX)
					return -EINVAL;
				hbra[flavor - 1] = attr;
			}
			attr = RTA_NEXT(attr, attrlen);
		}
	}

	if (link->doit == NULL)
		return -EINVAL;
	return link->doit(skb, nlh, hbra);
}

static void hbr_nl_rcv(struct sock *sk, int len)
{
	unsigned int qlen = 0;

	do {
		mutex_lock(&hbr_nl_mutex);
		netlink_run_queue(sk, &qlen, &hbr_user_rcv_msg);
		mutex_unlock(&hbr_nl_mutex);
	} while (qlen);
}

int hbr_nl_init(void)
{
	printk(KERN_DEBUG "HBR: creating netlink socket\n");
	hbr_nl = netlink_kernel_create(NETLINK_HBRIDGE, 0, hbr_nl_rcv,
				       NULL, THIS_MODULE);

	if (!hbr_nl)
		return -ENOMEM;
	return 0;
}

void hbr_nl_exit(void)
{
	if (hbr_nl)
		sock_release(hbr_nl->sk_socket);
	hbr_nl = NULL;
}
