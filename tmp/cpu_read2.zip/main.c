#define G_ROCX	1
#define CONFIG_VTSS_ARCH_SPARX_28	1
#define CONFIG_VTSS_ARCH_SPARX		1

#include <sysdep.h>
#include "vtss_cpu.h"
#include "vtss_heathrow.h"
#include "vtss_sparx_reg.h"

#define VTSS_RC(expr)	{vtss_rc rc = (expr); if (rc < VTSS_OK) return rc;}
#define VTSS_CHIP_PORTS		7
#define VTSS_CHIP_PORTMASK	((1 << VTSS_CHIP_PORTS) - 1)
#define VTSS_CHIP_PORT_CPU	VTSS_CHIP_PORTS

/* ================================================================= *
 *  Packet Control
 * ================================================================= */
vtss_cpu_state_t vtss_cpu_state;

static int vit_fd;
static vtss_rc vtss_io_pi_rd_fast(uint block, uint subblock,
				  const uint reg, ulong *value)
{
	vtss_rc rc = VTSS_OK;
#ifdef CONFIG_VTSS_VITGENIO
	struct vitgenio_32bit_readwrite pibuf;
	
	pibuf.offset = (block<<12)|(subblock<<8)|(reg<<0);
	if (ioctl(vtss_mac_io_state.fd, VITGENIO_32BIT_READ, (unsigned long)&pibuf) < 0) {
		vtss_log(VTSS_LOG_ERR, "IO: ioctl(VITGENIO_32BIT_READ) failed");
		*value = 0;
		rc = VTSS_IO_READ_ERROR;
	} else {
		*value=pibuf.value;
	}
#endif
	return rc;
}

vtss_rc vtss_io_pi_rd(uint block, uint subblock, const uint reg, ulong * const value)
{
	vtss_rc rc;
	
	if (
		block == B_CAPTURE || block == B_SYSTEM) {
		rc = vtss_io_pi_rd_fast(block, subblock, reg, value);
	} else {
		int   i;
		ulong val;
		
		if ((rc = vtss_io_pi_rd_fast(block,subblock,reg,&val)) < 0)
			return rc;
		for (i=0;;i++) {
			if ((rc = vtss_io_pi_rd_fast(B_SYSTEM, 0, R_SYSTEM_CPUCTRL, &val)) < 0)
				break;
			if (val & (1 << 4)) {
				rc = vtss_io_pi_rd_fast(B_SYSTEM, 0, R_SYSTEM_SLOWDATA, value);
				break;
			}
			if (i == 25) {
				printf("IO: DONE failed after %d retries, block=0x%02x, subblock=0x%02x, reg=0x%02x",
					 i, block, subblock, reg);
				rc=-1;
				break;
			}
		};
	}
	return rc;
}


/* Read target register using current CPU interface */
vtss_rc ht_rd_wr(uint blk, uint sub, uint reg, ulong *value, BOOL do_write)
{
	vtss_rc rc;
	BOOL    error;
	
	if (do_write) {
		printf("not support write.\n");
		return -1;
	}
	switch (blk) {
	case B_PORT:
		/* By default, it is an error if the sub block is not included in chip port mask */
		error = ((sub > VTSS_CHIP_PORTS) ||
			(VTSS_CHIP_PORTMASK & (1<<sub)) == 0);
#ifdef CONFIG_VTSS_ARCH_SPARX_28
		if (sub == VTSS_CHIP_PORT_CPU)
			error = 0;
#endif
		if (error)
			break;
		if (sub >= 16) {
			blk = B_PORT_HI;
			sub -= 16;
		}
		break;
	case B_MIIM: /* B_MEMINIT/B_ACL/B_VAUI */
#ifdef CONFIG_VTSS_ARCH_SPARX_28
		error = (sub > S_ACL);
#else
		error = (sub > S_MEMINIT);
#endif
		break;
	case B_CAPTURE:
		error = 0;
		break;
	case B_ANALYZER:
	case B_ARBITER:
	case B_SYSTEM:
		error = (sub != 0);
		break;
	case B_PORT_HI: /* vtss_ll_register_read/write may access this directly */
		error = 0;
		break;
	default:
		error = 1;
		break;
	}
	
	if (error) {
		printf("SPARX: illegal access, blk=0x%02x, sub=0x%02x, reg=0x%02x",
			 blk, sub, reg);
		return -1;
	}
	
	rc =	vtss_io_pi_rd(blk, sub, reg, value);
	
	 printf("SPARX: %s access, blk=%d, sub=%2d, reg=0x%02x, value=0x%08lx",
		 do_write ? "write" : "read ", blk, sub, reg, *value);
	return rc;
}

/* Read target register using current CPU interface */
vtss_rc ht_rd(uint blk, uint sub, uint reg, ulong *value)
{
	return ht_rd_wr(blk, sub, reg, value, 0);
}

/* Write target register using current CPU interface */
vtss_rc ht_wr(uint blk, uint sub, uint reg, ulong value)
{
	return ht_rd_wr(blk, sub, reg, &value, 1);
}

/* Read-modify-write target register using current CPU interface */
vtss_rc ht_wrm(uint blk, uint sub, uint reg, ulong value, ulong mask)
{
	vtss_rc rc;
	ulong val;
	
	if ((rc = ht_rd_wr(blk, sub, reg, &val, 0))>=0) {
		val = ((val & ~mask) | (value & mask));
		rc = ht_rd_wr(blk, sub, reg, &val, 1);
	}
	return rc;
}

/* Read target register field using current CPU interface */
vtss_rc ht_rdf(uint blk, uint sub, uint reg, uint offset, ulong mask, ulong *value)
{
	vtss_rc rc;
	
	rc = ht_rd_wr(blk, sub, reg, value, 0);
	*value = ((*value >> offset) & mask);
	return rc;
}

/* Read-modify-write target register field using current CPU interface */
vtss_rc ht_wrf(uint blk, uint sub, uint reg, uint offset, ulong mask, ulong value)
{
	return ht_wrm(blk, sub, reg, value<<offset, mask<<offset);
}


#if 1
/* ================================================================= *
 * CPU frame extraction
 * ================================================================= */

/* Enable/disable frame ready interrupt */
vtss_rc vtss_ll_frame_rx_ready_int(vtss_cpu_rx_queue_t queue_no, BOOL enable)
{
#ifdef CONFIG_VTSS_ARCH_SPARX
	ulong offset = (queue_no-VTSS_CPU_RX_QUEUE_START);
#ifdef CONFIG_VTSS_ARCH_SPARX_28
	offset += 9;
#endif
	HT_WRF(SYSTEM, 0, CAPCTRL, offset, 0x1, enable ? 1 : 0);
#endif
	return VTSS_OK;
}

#if (VTSS_CPU_RX_QUEUES>1)
/* Setup Rx queue map */
vtss_rc vtss_ll_cpu_rx_queue_map_set(vtss_cpu_rx_queue_map_t * const map)
{
#ifdef CONFIG_VTSS_ARCH_SPARX_28
	ulong i, value = 0;
	
	HT_WR(ANALYZER, 0, CAPQUEUE,
	      ((map->learn_queue-VTSS_CPU_RX_QUEUE_START)<<12) |
	      ((map->mac_vid_queue-VTSS_CPU_RX_QUEUE_START)<<10) |
	      ((map->igmp_queue-VTSS_CPU_RX_QUEUE_START)<<8) |
	      ((map->ipmc_ctrl_queue-VTSS_CPU_RX_QUEUE_START)<<6) |
	      ((map->igmp_queue-VTSS_CPU_RX_QUEUE_START)<<4) |
	      (0<<2) | /* 01-80-C2-00-00-10 */
	      ((map->bpdu_queue-VTSS_CPU_RX_QUEUE_START)<<0));
	
	for (i = 0; i < 16; i++) {
		value |= ((map->garp_queue-VTSS_CPU_RX_QUEUE_START)<<(i*2));
	}
	HT_WR(ANALYZER, 0, CAPQUEUEGARP, value);
#endif
	return VTSS_OK;
}

#endif /* VTSS_CPU_RX_QUEUES>1 */

/* Determine if a frame is ready in the CPU Rx queue */
/* Returns: 0: no frame ready, <0: error, >0: frame ready */
vtss_rc vtss_ll_frame_rx_ready(vtss_cpu_rx_queue_t queue_no)
{
	ulong ready;
#ifdef CONFIG_VTSS_ARCH_SPARX
	ulong offset;
#ifdef CONFIG_VTSS_ARCH_SPARX_28
	offset = 28;
#endif
	HT_RDF(SYSTEM, 0, CAPCTRL,
	       offset + queue_no - VTSS_CPU_RX_QUEUE_START, 0x1, &ready);
#endif
	return ready;
}

static vtss_rc ht_cpurx_readbuffer(vtss_cpu_rx_queue_t queue_no,
				   const uint addr, ulong *value)
{
	uint sub, offset;
	
#ifdef CONFIG_VTSS_ARCH_SPARX_28
	/* sub : 0, 2, 4, 6 */
	sub = (S_CAPTURE_DATA + (queue_no - VTSS_CPU_RX_QUEUE_START)*2);
	offset = 0; /* SparX-28 uses FIFO mode */
#endif
	HT_RD(CAPTURE, sub, FRAME_DATA + offset, value);
	return VTSS_OK;
}

static ulong ht_cpu_ulong_from_buffer(const uchar *const buffer)
{
	return (buffer[0] << 24) |
	       (buffer[1] << 16) |
	       (buffer[2] <<  8) |
	       (buffer[3]      ) ;
}

/* chip_port? */
int vtss_port_map(int chip_port)
{
	switch (chip_port) {
	case 5:	return 1;
	case 0:	return 2;
	case 1:	return 3;
	case 2:	return 4;
	case 3:	return 5;
	case 6: return 6;
	case 4: return 7;
	default:
		return -1;
	}
}

int vtss_chip_map(int port_no)
{
	switch (port_no) {
	case 1:	return 5;
	case 2:	return 0;
	case 3:	return 1;
	case 4:	return 2;
	case 5:	return 3;
	case 6:	return 6;
	case 7: return 4;
	default:
		return -1;
	}
	
}

static vtss_rc ht_cpurx_systemheader(vtss_cpu_rx_queue_t queue_no, 
                                     vtss_system_frame_header_t * const sys_header)
{
	/* IFH is 8 bytes */
	ulong ifh0, ifh1;
	
	VTSS_RC(ht_cpurx_readbuffer(queue_no, 0, &ifh0));
	VTSS_RC(ht_cpurx_readbuffer(queue_no, 1, &ifh1));
	
	sys_header->length = (IFH_GET(ifh0, ifh1, LENGTH) - VTSS_FCS_SIZE);
	/* XXX: */
	sys_header->source_port_no = vtss_port_map(IFH_GET(ifh0, ifh1, PORT));

	sys_header->arrived_tagged = IFH_GET(ifh0, ifh1, TAGGED);
	sys_header->tag.tagprio = IFH_GET(ifh0, ifh1, UPRIO);
	sys_header->tag.cfi = IFH_GET(ifh0, ifh1, CFI);
	sys_header->tag.vid = IFH_GET(ifh0, ifh1, VID);
#ifdef VTSS_FEATURE_CPU_RX_LEARN
	sys_header->learn = IFH_GET(ifh0, ifh1, LEARN);
#endif

	/* Check port */
	if (!VTSS_PORT_IS_PORT(sys_header->source_port_no)) {
		printf("SPARX: illegal portno, port=%u, ifh0=0x%08lx, ifh1=0x%08lx",
			 sys_header->source_port_no, ifh0, ifh1);
		return -1;
	}
	return VTSS_OK;
}

/* Get frame from CPU Rx queue */
vtss_rc vtss_ll_frame_rx(vtss_cpu_rx_queue_t queue_no,
			 vtss_system_frame_header_t *sys_header,
                         uchar *frame, uint maxlength)
{
	uint w, len;
	ulong data;
	/* IFH used 0 and 1 */
	uint addr = 2;
	vtss_packet_rx_t *packet;
	
	packet = &vtss_cpu_state.rx_packet[queue_no-VTSS_CPU_RX_QUEUE_START];
	if (packet->used) {
		/* Header has already been read, copy from API state */
		*sys_header = packet->sys_header;
	} else {
		/* Read header and copy to API state */
		VTSS_RC(ht_cpurx_systemheader(queue_no, sys_header));
		packet->used = 1;
		packet->sys_header = *sys_header;
	}
	
	/* Check if the application is just requesting the header */
	if (frame == NULL)
		return VTSS_OK;
	
	len = (sys_header->length < maxlength) ? sys_header->length : maxlength;
	/* DS: 3.11.1 read even times, see vtss_ll_frame_rx_discard */
	for (w = 0; w < (len + 3) / 4; w++) {
		VTSS_RC(ht_cpurx_readbuffer(queue_no, addr++, &data));
		frame[w * 4 + 0] = (uchar)((data>>24) & 0xff);
		frame[w * 4 + 1] = (uchar)((data>>16) & 0xff);
		frame[w * 4 + 2] = (uchar)((data>>8) & 0xff);
		frame[w * 4 + 3] = (uchar)(data & 0xff);
	}
	
	if (maxlength < sys_header->length) {
#ifdef CONFIG_VTSS_ARCH_SPARX_28
		printf("SPARX: buffer too small\n");
#endif
		return -1;
	}
#ifdef CONFIG_VTSS_ARCH_SPARX_28
	packet->words_read = w;
#endif
	return vtss_ll_frame_rx_discard(queue_no);
}

/* Discard frame from CPU Rx queue */
vtss_rc vtss_ll_frame_rx_discard(vtss_cpu_rx_queue_t queue_no)
{
#ifdef CONFIG_VTSS_ARCH_SPARX_28
	vtss_packet_rx_t *packet;
	ulong w, w_max, value;
	
	packet = &vtss_cpu_state.rx_packet[queue_no - VTSS_CPU_RX_QUEUE_START];
	if (packet->used) {
		/* Calculate number of words to read */
		w_max = (packet->sys_header.length + 7) / 4; /* Include FCS */
		if (w_max & 1)
			w_max++; /* Read even number of words */
		
		/* Read out rest of frame */
		for (w = packet->words_read; w < w_max; w++) {
			VTSS_RC(ht_cpurx_readbuffer(queue_no, 0, &value));
		}
		packet->used = 0;
		packet->words_read = 0;
	}
#endif
	return VTSS_OK;
}

/* ================================================================= *
 * CPU frame injection
 * ================================================================= */

static vtss_rc ht_cputx_autoupdate_crc(const BOOL enable)
{
	vtss_port_no_t port_no;
	uint port_on_chip;
	ulong mask = (1<<1);
	
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
	{
		port_on_chip = HT_CHIP_PORT(port_no);
		HT_WRM(PORT, port_on_chip, TXUPDCFG, enable ? mask : 0, mask);
	}
	return VTSS_OK;
}

#define VTSS_CPUTX_WAIT_MAXRETRIES 1000000

static vtss_rc ht_wr_cputxdat_chipport(uint port_on_chip, const ulong value)
{
	uint  read_attempt=0;
	ulong pending;
	
	HT_WR(PORT, port_on_chip, CPUTXDAT, value);
	do {
		HT_RDF(PORT, port_on_chip, MISCSTAT, 8, 0x1, &pending);
		if (!pending)
			return VTSS_OK; /* Done */
	} while (read_attempt++ < VTSS_CPUTX_WAIT_MAXRETRIES);
	
	/* Timeout, cancel transmission */
	HT_WR(PORT, port_on_chip, MISCFIFO, (1<<1) | MISCFIFO_TAILDROP);
	return -1;
}

/* Transmit frame on port, optionally with tag. Padding may be done */
vtss_rc vtss_ll_frame_tx(vtss_port_no_t port_no, const uchar *frame, 
                         uint length, vtss_vid_t vid)
{
	uint  w, addw, framelen;
	ulong ifh0 = 0, ifh1 = 0;
	uint  port_on_chip = HT_CHIP_PORT(port_no);
	
	/* Calculate and send IFH0 and IFH1 */
	addw = 1; /* CRC */
	if (vid != VTSS_VID_NULL)
		addw++; /* VLAN tag */
	
	framelen = (length + addw*4);
	IFH_PUT(ifh0, ifh1, LENGTH, framelen < 64 ? 64 : framelen);
	
	/* FIXME: which one : CPUTXDAT or CPUTXHDR? */
	VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, ifh0));
	VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, ifh1));
	
	/* Send frame data */
	for (w=0; w <= (length-1)/4; w++) {
		if (w == 3) {
			if (vid != VTSS_VID_NULL) {
				/* Insert tag */
				VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, 
					(0x8100<<16) | (0<<13) | (0<<12) | vid));
			}
		}
		VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, 
			ht_cpu_ulong_from_buffer(&(frame[w*4]))));
	}
	
	/* Add padding when the frame is too short */
	w += addw;
	while (w < (64/4)) {
		VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, 0));
		w++;
	}
	
	/* Add dummy CRC */
	VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, 0));
	
	/* We must write an even number of longs, so write an extra */
	if (w & 1)
		VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, 0));
	
	/* Transmit data */
	HT_WR(PORT, port_on_chip, MISCFIFO, (1<<0) | MISCFIFO_TAILDROP);
	
	return VTSS_OK;
}

vtss_rc ht_cpu_frame_reset(void)
{
	return ht_cputx_autoupdate_crc(1/*TRUE*/);
}

/* ================================================================= *
 *  Packet RX/TX
 * ================================================================= */

/* - RX frame registration ----------------------------------------- */

#if (VTSS_CPU_RX_QUEUES>1)
vtss_rc vtss_cpu_rx_queue_map_set(vtss_cpu_rx_queue_map_t * const map)
{
	vtss_cpu_rx_queue_t queue_no;
	int i;
	
	/* Check queues */
	for (i=0; i<(sizeof(*map)/sizeof(queue_no)); i++) {
		queue_no = *((vtss_cpu_rx_queue_t *)map+i);
		if (queue_no<VTSS_CPU_RX_QUEUE_START || queue_no>=VTSS_CPU_RX_QUEUE_END) {
			printf("SWITCH: illegal queue, queue=%d, index=%d",
				 queue_no, i);
			return -1;
		}
		printf("SWITCH: legal queue, queue=%d, index=%d",
			 queue_no, i);
	}
	
	return vtss_ll_cpu_rx_queue_map_set(map);
}

#endif /* VTSS_CPU_RX_QUEUES>1 */

vtss_rc vtss_cpu_rx_registration_get(vtss_cpu_rx_registration_t *const registration)
{
	*registration = vtss_cpu_state.rx_registration;
	return VTSS_OK;
}

/* - RX frames ----------------------------------------------------- */
vtss_rc vtss_cpu_rx_frameready_int_enable(const vtss_cpu_rx_queue_t queue_no,
                                          const BOOL enable)
{
	return vtss_ll_frame_rx_ready_int(queue_no, enable);
}

vtss_rc vtss_cpu_rx_frameready(const vtss_cpu_rx_queue_t queue_no)
{
	vtss_rc rc;
	
	rc = vtss_ll_frame_rx_ready(queue_no);
	return rc;
}

vtss_rc vtss_cpu_rx_frame(const vtss_cpu_rx_queue_t queue_no,
                          vtss_system_frame_header_t * const sys_header,
                          uchar * const frame, 
                          const uint maxlength)
{
	return vtss_ll_frame_rx(queue_no, sys_header, frame, maxlength);
}

vtss_rc vtss_cpu_rx_discard_frame(const vtss_cpu_rx_queue_t queue_no)
{
	return vtss_ll_frame_rx_discard(queue_no);
}

/* Rx frames to CPU */
static void cpu_frame_rx(void) 
{
	vtss_system_frame_header_t header;
	uchar                      frame[VTSS_MAXFRAMELENGTH_STANDARD];
	vtss_cpu_rx_queue_t        queue_no;
	ushort                     etype;
	ulong                      data;

	for (queue_no = VTSS_CPU_RX_QUEUE_START; 
			queue_no < VTSS_CPU_RX_QUEUE_END; queue_no++) {
		/* Check if frame is ready in Rx queue */
		if (vtss_cpu_rx_frameready(queue_no) != 1)
			continue;

		/* Get frame */
		if (vtss_cpu_rx_frame(queue_no, &header, frame, 
				VTSS_MAXFRAMELENGTH_STANDARD) != VTSS_OK)
			continue;

		fprintf(stdout, "received frame on port_no=%d, queue_no=%d, length=%d",
		        header.source_port_no, queue_no, header.length);

		/* Process frame */
		{
			int  i;
			char buf[100], *p;

			//for (i = 0, p = &buf[0]; i < header.length; i++) {
			for (i = 0, p = &buf[0]; i < 100; i++) {
				if ((i % 16) == 0) {
					p = &buf[0];
					p += sprintf(p, "%04x: ", i);
				}
				p += sprintf(p, "%02x%c", frame[i], ((i + 9) % 16) == 0 ? '-' : ' ');
				if (((i+1) % 16) == 0 || (i+1) == header.length) {
					printf(("%s", buf));
				}
			}
		}
		etype = ((frame[12]<<8) | (frame[13]<<0));
		data  = ((frame[14]<<24) | (frame[15]<<16) | (frame[16]<<8) | (frame[17]<<0));
		printf("etype=%04x.\n", etype);
	}
}
#endif

/* Set frame registration */
vtss_rc vtss_ll_frame_reg_set(const vtss_cpu_rx_registration_t *reg)
{
#ifdef CONFIG_VTSS_ARCH_SPARX
	{
		ulong value = 0;
		
		value |= ((MAKEBOOL01(reg->bpdu_cpu_only)<<16) |
			  (MAKEBOOL01(reg->mcast_igmp_cpu_only)<<18));
#ifdef CONFIG_VTSS_ARCH_SPARX_28
		value |= (MAKEBOOL01(reg->ipmc_ctrl_cpu_copy)<<19);
#endif
		/* Update all CAPENAB fields */
		HT_WR(ANALYZER, 0, CAPENAB, value);
	}
#endif
	return VTSS_OK;
}

vtss_rc vtss_cpu_rx_registration_set(const vtss_cpu_rx_registration_t *const registration)
{
	vtss_cpu_state.rx_registration = *registration;
	return vtss_ll_frame_reg_set(registration);
}

/* - TX frames ----------------------------------------------------- */

vtss_rc vtss_cpu_tx_raw_frame(const vtss_poag_no_t poag_no,
                              const uchar * const  frame,
                              const uint           length)
{
	vtss_port_no_t         port_no;
	
	if (VTSS_PORT_IS_PORT(poag_no)) {
		port_no = poag_no;
#if 0
		if (vtss_mac_state.stp_state[port_no] == VTSS_STP_STATE_DISABLED) {
			vtss_log(VTSS_LOG_ERR,
				 "SWITCH: port_no STP disabled, port=%d", port_no);
			return VTSS_UNSPECIFIED_ERROR;
		}
#endif
	} else {
		printf("Not support AGGR mode.\n");
		return VTSS_OK;
	}
#if 0
	/* If egress mirroring is enabled, send on mirror port */
	if (vtss_mac_state.mirror_egress[port_no] && port_no != vtss_mac_state.mirror_port && 
		vtss_mac_state.mirror_port != 0 && VTSS_STP_FORWARDING(vtss_mac_state.stp_state[vtss_mac_state.mirror_port])) {
		vtss_rc rc;
		
		if ((rc = vtss_ll_frame_tx(vtss_mac_state.mirror_port, frame, length, VTSS_VID_NULL)) < 0)
			return rc;
	}
#endif
	return vtss_ll_frame_tx(port_no, frame, length, VTSS_VID_NULL);
}

vtss_rc vtss_cpu_start(void)
{
	vtss_cpu_rx_registration_t reg;
	/* Initialize CPU frame registration, enable BPDUs */
	memset(&reg, 0, sizeof(reg));

	reg.bpdu_cpu_only = 1;
	reg.mcast_igmp_cpu_only = 1;

	vtss_cpu_rx_registration_set(&reg);
	return VTSS_OK;
}

static char *build_packet(void)
{
	unsigned char *frame = NULL;
	int i;
	frame = (unsigned char *)malloc(64);

	if (!frame) {
		printf("Out of memory.\n");
		return NULL;
	}
	for (i = 0; i < 64; i++)
		*frame++ = i;
	return frame;
}

static void tx_by_cpu()
{
	int res = -1;
	unsigned char *frame = build_packet();	/* len 64 */

	if (frame) {
		/* 2 is port_no */
		res = vtss_cpu_tx_raw_frame(2, frame, 64);
		if (VTSS_OK == res)
			printf("tx_by_cpu success.\n");
		else
			printf("tx_by_cpu failure.\n");

		free(frame);
	}
}

int main(void)
{

	vtss_cpu_start();
	vit_fd = open("/dev/vitgenio", 0);

	if (vit_fd < 0) {
		printf("open fail.\n");
		return 0;
	}

	for(;;) {
		cpu_frame_rx();
	}

}

