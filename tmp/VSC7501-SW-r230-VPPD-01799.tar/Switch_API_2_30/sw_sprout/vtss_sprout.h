/*

 Vitesse Switch Software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_sprout.h,v 1.37 2008/02/20 15:05:13 cpj Exp $
 $Revision: 1.37 $


 This file is part of SPROUT - "Stack Protocol using ROUting Technology".
*/

#ifndef _VTSS_SPROUT_H_
#define _VTSS_SPROUT_H_

#include <vtss_module_id.h>
#include <vtss_os.h>


#if !defined(VTSS_SWITCH) 
#define VTSS_SWITCH 0
#elif (VTSS_SWITCH != 0 && VTSS_SWITCH != 1)
#error VTSS_SWITCH must be set to 0 or 1
#endif

#if !defined(VTSS_SPROUT_UNMGD) 
#define VTSS_SPROUT_UNMGD 0
#elif (VTSS_SPROUT_UNMGD != 0 && VTSS_SPROUT_UNMGD != 1)
#error VTSS_SPROUT_UNMGD must be set to 0 or 1
#endif

#if !defined(VTSS_SPROUT_MULTI_THREAD) || (VTSS_SPROUT_MULTI_THREAD != 0 && VTSS_SPROUT_MULTI_THREAD != 1)
#error VTSS_SPROUT_MULTI_THREAD must be set to 0 or 1.
#endif
#if !defined(VTSS_SPROUT_CRIT_CHK) || (VTSS_SPROUT_CRIT_CHK != 0 && VTSS_SPROUT_CRIT_CHK != 1)
#error VTSS_SPROUT_CRIT_CHK must be set to 0 or 1.
#endif




#include <vtss_trace_lvl_api.h>

#define VTSS_TRACE_MODULE_ID VTSS_MODULE_ID_SPROUT

#define VTSS_TRACE_GRP_DEFAULT  0
#define TRACE_GRP_PKT_DUMP      1
#define VTSS_TRACE_GRP_TOP_CHG  2
#define TRACE_GRP_MST_ELECT     3
#define TRACE_GRP_CRIT          4
#define TRACE_GRP_CNT           5

#include <vtss_trace_api.h>


#include "vtss_sprout_api.h"


#define VTSS_SPROUT_RIT_SIZE           (VTSS_SPROUT_MAX_UNITS_IN_STACK + VTSS_SPROUT_MAX_UNITS_IN_STACK/2)

#include "vtss_sprout_types.h"
#include "vtss_sprout_crit.h"
#include "vtss_sprout_util.h"
#include "vtss_sprout_xit.h"


#if VTSS_SWITCH
  #include <main.h>
#else
  #define VTSS_RCS(rc, expr) {rc = expr;}
#endif

#ifndef VTSS_SPROUT_ASSERT
#define VTSS_SPROUT_ASSERT(expr, msg) { \
    if (!(expr)) { \
        T_E("ASSERTION FAILED"); \
        T_E msg; \
        VTSS_ASSERT(expr); \
    } \
}
#endif




#define VTSS_SPROUT_MST_TIME_DIFF_MIN 10 

extern vtss_sprout__switch_state_t switch_state;

#endif 






