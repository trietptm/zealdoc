/*

Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
$Id: vtss_trace_api.h,v 1.45 2008/09/04 10:12:18 fj Exp $
$Revision: 1.45 $

*/

/*
 * API for trace module
 */

/*
 * Introduction to trace module
 * ============================
 * The trace module provides macros for generating printf-trace to be output 
 * on - e.g. - a serial console. Each trace statement is categorized by:
 * - module
 * - group within module
 * - trace level
 *
 * For each (module, group) and each thread (eCos only), a trace level can be 
 * configured.
 * A given trace statement is only output if its trace level is 
 * - higher than the trace level configured for (module, group).
 * - higher than the trace level configured for the thread (eCos only)
 * - higher than the compile-time minimum trace level.
 *
 * The following trace levels are defined:
 * - ERROR   Code error encountered
 * - WARNING Potential code error, manual inspection required
 * - INFO    Useful information
 * - DEBUG   Some debug information
 * - NOISE   Lot's of debug information
 * - RACKET  Even more ...
 *
 * "RACKET" generates the most output, "ERROR" generates the least amount of 
 * output. By default, modules should have trace level set to ERROR for all 
 * groups.
 * 
 *
 * Registering a module with vtss_trace
 * ------------------------------------
 * In order for a module to use vtss_trace the following is required (here using
 * sw_sprout/vtss_sprout* as example):
 * - In module's header file (vtss_sprout.h) include <vtss_trace_lvl_api.h>
 * - In module's header file (vtss_sprout.h) define
 *    - Constant VTSS_TRACE_MODULE_ID 
 *      Usually the same as the module's vtss_module_id_t.
 *    - Constants for each of the module's trace group.
 *      Trace group 0, must be used for default group.
 * - In module's header file (vtss_sprout.h) include <vtss_trace_api.h>
 * 
 * - In module's .c file define 
 *    - trace registration (vtss_trace_reg_t)
 *    - trace groups (vtss_trace_grp_t)
 * 
 * - In module's initialization function
 *    - Call VTSS_TRACE_REG_INIT
 *    - Call VTSS_TRACE_REGISTER
 * 
 * Pls. refer to an existing module for detailed code example 
 * (e.g. vtss_sprout.h+vtss_sprout.c).
 * 
 * 
 * Controlling trace level at compile-time
 * ---------------------------------------
 * To control the trace level at compile time, VTSS_TRACE_LVL_MIN must be used.
 * To have all trace included, use the value VTSS_TRACE_LVL_ALL.
 * To have only error trace included, use the value VTSS_TRACE_LVL_ERROR.
 * To have all trace excluded, use the value VTSS_TRACE_LVL_NONE.
 * 
 * See vtss_trace_lvl_api.h for the exact numeric values of these constants.
 * 
 *
 * Controlling trace level at run-time
 * -----------------------------------
 * Functions are available for controlling the trace level at 
 * compile time. 
 * 
 * Additional each module provides can provide a default trace level in its
 * registration of trace groups. If no such default level is set, ERROR
 * is used.
 *
 *
 * Using trace in module code
 * --------------------------
 * Once a module has been registered with the vtss_trace, the T_... macroes 
 * below can be used.
 * The simplest type of trace is:
 *   T_D("bla bla");
 * This call will output "bla bla" if trace level for the module's default group
 * is DEBUG or lower.
 * If the trace shall be part of another group than the default group, then
 * macro T_DG must be used.
 * Macroes for hex-dumping (e.g. a packet) also exist. See below.
 *
 *
 * trace io
 * --------
 * The trace io functions are defined in vtss_trace_io.
 * By default trace is output with fputs/putchar on stdout.
 * Additional trace output devices can be registered, e.g. for Telnet 
 * connections.
 * 
 *
 * Dependencies
 * ============
 * vtss_trace requires the following modules:
 * - Switch API (gw_api/...)
 * 
 *
 * Compilation Directives
 * ======================
 * The following defines are used to control the compilation of vtss_trace:
 * + VTSS_TRACE_LVL_MIN
 *   The amount of trace included at compile time. By default all trace is 
 *   included. Must be set to one of the values defined in vtss_trace_lvl_api.h.
 *   It is recommended always to include error trace.
 * + VTSS_TRACE_MULTI_THREAD
 *   Must be set to 1, if trace macroes are called from multiple threads.
 * + VTSS_SWITCH
 *   Must be set to 1 when compiling SPROUT for Vitesse turnkey SW solution 
 *   (managed as well as unmanaged).
 *   If not defined, 0 is assumed.
 */

#ifndef _VTSS_TRACE_API_H_
#define _VTSS_TRACE_API_H_

#include <stdarg.h>
#include <vtss_os.h>
#include <vtss_module_id.h>
#include <vtss_switch_api.h>

#ifndef _VTSS_TRACE_LVL_API_H_
#error "vtss_trace_lvl_api.h has not been included prior to including vtss_trace_api.h"
#endif

#ifndef VTSS_TRACE_LVL_MIN
#define VTSS_TRACE_LVL_MIN VTSS_TRACE_LVL_ALL   /* Include all trace by default */
#endif

/* 
 * Compile-time trace disabling 
 */
#ifndef VTSS_TRACE_LVL_MIN
#define VTSS_TRACE_LVL_MIN 0 /* Default: All trace enabled */
#endif

#ifdef VTSS_TRACE_ENABLED
#error "VTSS_TRACE_ENABLED defined outside vtss_trace_api.h. Not allowed. Use VTSS_TRACE_LVL_MIN instead."
#endif


#if (VTSS_TRACE_LVL_MIN < VTSS_TRACE_LVL_NONE)
#define VTSS_TRACE_ENABLED 1
#else
#define VTSS_TRACE_ENABLED 0
#endif

/* Default trace group */
#define VTSS_TRACE_GRP_DEFAULT 0

/* ===========================================================================
 * Trace registration
 * ------------------------------------------------------------------------ */

/* 
 * Before using the trace macroes, each module must register with vtss_trace.
 * This is done using the vtss_trace_reg_t and vtss_trace_grp_t structures 
 * and the macroes VTSS_TRACE_REG_INIT and VTSS_TRACE_REGISTER:
 * 1) Allocate vtss_trace_reg_t and vtss_trace_grp_t (not on the stack)
 *    Typically allocated statically.
 * 2) memset both structs to 0 (if allocated statically, this is 'C' default).
 * 3) Set the desired values in both structures.
 * 4) Call VTSS_TRACE_REG_INIT.
 * 5) Call VTSS_TRACE_REGISTER.
 * 
 * The module may now call the trace macroes (T_...).
 */

/* 
 * Note:
 * First call to VTSS_TRACE_REG_INIT() must be done in single-thread context,
 * since this call is used for internal initialization within the trace module.
 * After the initial call to VTSS_TRACE_REG_INIT(), the macro becomes 
 * reentrant and any following calls to VTSS_TRACE_REG_INIT() may thus be done 
 * in multi-thread context (provided trace has been compiled with 
 * VTSS_TRACE_MULTI_THREAD=1).
 */

#define VTSS_TRACE_MAX_NAME_LEN  10
#define VTSS_TRACE_MAX_DESCR_LEN 60

/* Group definition */
typedef struct {
    uint cookie;                            /* VTSS_TRACE_GRP_T_COOKIE */

    char name[VTSS_TRACE_MAX_NAME_LEN+1];   /* Name of group        */
    char descr[VTSS_TRACE_MAX_DESCR_LEN+1]; /* Description of group */

    int  lvl;       /* Default trace level. If 0, ERROR is used */
    BOOL timestamp; /* Include wall clock time stamp in trace   */
    BOOL usec;      /* Include usec time stamp in trace         */

    /* ----- Internal fields, not to be changed by application ----- */
    int  lvl_prv;   /* Trace level prior to previous call to 
                       vtss_trace_module_lvl_set */
} vtss_trace_grp_t;

/* Module registration */
/* See registration procedure above */
typedef struct {
    uint cookie;                            /* VTSS_TRACE_REG_T_COOKIE */

    int  module_id;                         /* Module ID             */
    char name[VTSS_TRACE_MAX_NAME_LEN+1];   /* Name of module        */
    char descr[VTSS_TRACE_MAX_DESCR_LEN+1]; /* Description of module */
  
    /* ----- Internal fields, not to be changed by application ----- */
    /* Pointer to array of trace groups. */
    int               grp_cnt;
    vtss_trace_grp_t* grps;
} vtss_trace_reg_t;


/* Registration macroes */
#if (VTSS_TRACE_LVL_MIN < VTSS_TRACE_LVL_NONE)
#define VTSS_TRACE_REG_INIT(trace_reg, trace_grps, grp_cnt) vtss_trace_reg_init(trace_reg, trace_grps, grp_cnt)
#define VTSS_TRACE_REGISTER(trace_reg)                      vtss_trace_register(trace_reg)
#else
#define VTSS_TRACE_REG_INIT(trace_reg, trace_grps, grp_cnt)
#define VTSS_TRACE_REGISTER(trace_reg)
#endif

/* ======================================================================== */


/* ===========================================================================
 * Trace macroes
 *
 * T_E/T_W/T_I/T_D/T_N/T_R:
 * Printf-style trace output for default trace group.
 * 
 * T_E_HEX/T_W_HEX/T_I_HEX/T_D_HEX/T_N_HEX/T_R_HEX:
 * Hex dump of any number of bytes, e.g. a packet, for default trace group.
 * 
 * T_EG/T_WG/T_IG/T_DG/T_NG/T_RG:
 * Printf-style trace output for specific trace group.
 * 
 * T_EG_HEX/T_WG_HEX/T_IG_HEX/T_DG_HEX/T_NG_HEX/T_RG_HEX:
 * Hex dump of any number of bytes, e.g. a packet, for specific trace group.
 * ------------------------------------------------------------------------ */


#define __VTSS_LOCATION__	__FUNCTION__

/* ERROR level trace macroes */
#if (VTSS_TRACE_LVL_MIN <= VTSS_TRACE_LVL_ERROR)
#define T_E(fmt, ...)                       vtss_trace_printf(  VTSS_TRACE_MODULE_ID, VTSS_TRACE_GRP_DEFAULT, VTSS_TRACE_LVL_ERROR,   __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_EG(grp_idx, fmt, ...)             vtss_trace_printf(  VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_ERROR,   __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_E_HEX(byte_p, byte_cnt)           vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, VTSS_TRACE_GRP_DEFAULT, VTSS_TRACE_LVL_ERROR,   __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#define T_EG_HEX(grp_idx, byte_p, byte_cnt) vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_ERROR,   __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#else
#define T_E(fmt, ...)
#define T_EG(grp_idx, fmt, ...)
#define T_E_HEX(byte_p, byte_cnt)           
#define T_EG_HEX(grp_idx, byte_p, byte_cnt) 
#endif

/* WARNING level trace macroes */
#if (VTSS_TRACE_LVL_MIN <= VTSS_TRACE_LVL_WARNING)
#define T_W(fmt, ...)                       vtss_trace_printf(  VTSS_TRACE_MODULE_ID, VTSS_TRACE_GRP_DEFAULT, VTSS_TRACE_LVL_WARNING, __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_WG(grp_idx, fmt, ...)             vtss_trace_printf(  VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_WARNING, __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_W_HEX(byte_p, byte_cnt)           vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, VTSS_TRACE_GRP_DEFAULT, VTSS_TRACE_LVL_WARNING, __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#define T_WG_HEX(grp_idx, byte_p, byte_cnt) vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_WARNING, __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#else
#define T_W(fmt, ...)
#define T_WG(grp_idx, fmt, ...)
#define T_W_HEX(byte_p, byte_cnt)
#define T_WG_HEX(grp_idx, byte_p, byte_cnt)
#endif

/* INFO level trace macroes */
#if (VTSS_TRACE_LVL_MIN <= VTSS_TRACE_LVL_INFO)
#define T_I(fmt, ...)                       vtss_trace_printf(  VTSS_TRACE_MODULE_ID, VTSS_TRACE_GRP_DEFAULT, VTSS_TRACE_LVL_INFO,    __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_IG(grp_idx, fmt, ...)             vtss_trace_printf(  VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_INFO,    __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_I_HEX(byte_p, byte_cnt)           vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, VTSS_TRACE_GRP_DEFAULT, VTSS_TRACE_LVL_INFO,    __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#define T_IG_HEX(grp_idx, byte_p, byte_cnt) vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_INFO,    __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#else
#define T_I(fmt, ...)
#define T_IG(grp_idx, fmt, ...)
#define T_I_HEX(byte_p, byte_cnt)
#define T_IG_HEX(grp_idx, byte_p, byte_cnt)
#endif

/* DEBUG level trace macroes */
#if (VTSS_TRACE_LVL_MIN <= VTSS_TRACE_LVL_DEBUG)
#define T_D(fmt, ...)                       vtss_trace_printf(  VTSS_TRACE_MODULE_ID, VTSS_TRACE_GRP_DEFAULT, VTSS_TRACE_LVL_DEBUG,   __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)

#define T_DG(grp_idx, fmt, ...)             vtss_trace_printf(  VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_DEBUG,   __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_DG_PORT(grp_idx,port_index, fmt, ...)  vtss_trace_port_printf(port_index,  VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_DEBUG,   __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_D_HEX(byte_p, byte_cnt)           vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, VTSS_TRACE_GRP_DEFAULT, VTSS_TRACE_LVL_DEBUG,   __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#define T_DG_HEX(grp_idx, byte_p, byte_cnt) vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_DEBUG,   __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#else
#define T_D(fmt, ...)
#define T_DG(grp_idx, fmt, ...)
#define T_DG_PORT(port_index,grp_idx, fmt, ...)
#define T_D_HEX(byte_p, byte_cnt)
#define T_DG_HEX(grp_idx, byte_p, byte_cnt)
#endif

/* NOISE level trace macroes */
#if (VTSS_TRACE_LVL_MIN <= VTSS_TRACE_LVL_NOISE)
#define T_N(fmt, ...)                       vtss_trace_printf(  VTSS_TRACE_MODULE_ID, VTSS_TRACE_GRP_DEFAULT, VTSS_TRACE_LVL_NOISE,   __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_NG(grp_idx, fmt, ...)             vtss_trace_printf(  VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_NOISE,   __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_NG_PORT(grp_idx,port_index, fmt, ...)  vtss_trace_port_printf(port_index,  VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_NOISE,   __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_N_HEX(byte_p, byte_cnt)           vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, VTSS_TRACE_GRP_DEFAULT, VTSS_TRACE_LVL_NOISE,   __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#define T_NG_HEX(grp_idx, byte_p, byte_cnt) vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_NOISE,   __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#else
#define T_N(fmt, ...)
#define T_NG(grp_idx, fmt, ...)
#define T_NG_PORT(grp_idx,port_index, fmt, ...)
#define T_N_HEX(byte_p, byte_cnt)
#define T_NG_HEX(grp_idx, byte_p, byte_cnt)
#endif

/* RACKET level trace macroes */
#if (VTSS_TRACE_LVL_MIN <= VTSS_TRACE_LVL_RACKET)
#define T_R(fmt, ...)                       vtss_trace_printf(  VTSS_TRACE_MODULE_ID, VTSS_TRACE_GRP_DEFAULT, VTSS_TRACE_LVL_RACKET,  __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_RG(grp_idx, fmt, ...)             vtss_trace_printf(  VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_RACKET,  __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_RG_PORT(grp_idx,port_index, fmt, ...)  vtss_trace_port_printf(port_index,  VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_RACKET,   __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_R_HEX(byte_p, byte_cnt)           vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, VTSS_TRACE_GRP_DEFAULT, VTSS_TRACE_LVL_RACKET,  __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#define T_RG_HEX(grp_idx, byte_p, byte_cnt) vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, grp_idx,                VTSS_TRACE_LVL_RACKET,  __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#else
#define T_R(fmt, ...)
#define T_RG(grp_idx, fmt, ...)
#define T_RG_PORT(grp_idx,port_index, fmt, ...)  
#define T_R_HEX(byte_p, byte_cnt)
#define T_RG_HEX(grp_idx, byte_p, byte_cnt)
#endif

/* Trace macroes with trace level as argument */
#if (VTSS_TRACE_LVL_MIN < VTSS_TRACE_LVL_NONE)
#define T(grp_idx, lvl, fmt, ...)             vtss_trace_printf(  VTSS_TRACE_MODULE_ID, grp_idx, lvl, __VTSS_LOCATION__, __LINE__, fmt, ##__VA_ARGS__)
#define T_HEX(grp_idx, lvl, byte_p, byte_cnt) vtss_trace_hex_dump(VTSS_TRACE_MODULE_ID, grp_idx, lvl, __VTSS_LOCATION__, __LINE__, byte_p, byte_cnt)
#else
#define T(grp_idx, lvl, fmt, ...)
#define T_HEX(grp_idx, lvl, byte_p, byte_cnt)
#endif

/* Macro for checking whether trace is enabled for (module, grp, lvl) */
#if (VTSS_TRACE_LVL_MIN < VTSS_TRACE_LVL_NONE)
#define T_LVL_GET(module_id, grp_idx) (vtss_trace_module_lvl_get(module_id, grp_idx))
#else
#define T_LVL_GET(module_id, grp_idx) (VTSS_TRACE_LVL_NONE)
#endif

/* Trace macroes with module, group and level as argument */
#if (VTSS_TRACE_LVL_MIN < VTSS_TRACE_LVL_NONE)
#define T_EXPLICIT(module_id, grp_idx, lvl, func, line_no, fmt, ...) \
             vtss_trace_printf(module_id, grp_idx, lvl, func, line_no, fmt, ##__VA_ARGS__)
#define T_HEX_EXPLICIT(module_id, grp_idx, lvl, func, line_no, byte_p, byte_cnt) \
        vtss_trace_hex_dump(module_id, grp_idx, lvl, func, line_no, byte_p, byte_cnt)
#else
#define T_EXPLICIT(module_id, grp_idx, lvl, func, line_no, fmt, ...)
#define T_HEX_EXPLICIT(module_id, grp_idx, lvl, func, line_no, byte_p, byte_cnt)
#endif

/* ======================================================================== */


/* ===========================================================================
 * Run-time trace level control
 *
 * These functions can be used to implement CLI-based trace control
 * ------------------------------------------------------------------------ */

/*
 * Set trace level for module/group
 * 
 * module_id/grp_idx may be set to -1 for wildcarding.
 */
void vtss_trace_module_lvl_set( int module_id, int grp_idx, int lvl);


/*
 * Limit trace for thread. -1 = all threads. eCos only.
 */
void vtss_trace_thread_lvl_set(int thread_id, int lvl);


/* 
 * Reverse the lastest trace level change
 */
void vtss_trace_lvl_reverse(void);

/* ======================================================================== */


/* ===========================================================================
 * Run-time trace format control
 *
 * These functions can be used to implement CLI-based trace control
 * ------------------------------------------------------------------------ */

/*
 * Enable timestamp/usec for module/group. eCos only.
 */
typedef enum {VTSS_TRACE_MODULE_PARM_TIMESTAMP,
              VTSS_TRACE_MODULE_PARM_USEC
} vtss_trace_module_parm_t;
void vtss_trace_module_parm_set(
    vtss_trace_module_parm_t parm,
    int module_id, 
    int grp_idx, 
    BOOL enable);

/*
 * Include/exclude stack size in trace for thread. -1 = all threads.
 * eCos only.
 */
void vtss_trace_thread_stackuse_set(int thread_id, BOOL enable);

/* ======================================================================== */


/* ===========================================================================
 * Utility functions
 * ------------------------------------------------------------------------ */

void vtss_trace_port_set(int port_index,BOOL trace_enabled);
BOOL vtss_trace_port_get(int port_index);

/* Trace settings for thread */
typedef struct {
    /* Limit trace for thread (default: all trace enabled) */
    int  lvl;

    /* Enable stack size output for thread's trace (default: disabled) */
    BOOL stackuse;

    /* ----- Internal fields, not to be changed by application ----- */
    int  lvl_prv;   /* Trace level prior to previous call to 
                       vtss_trace_thread_lvl_set */
} vtss_trace_thread_t;

/*
 * Get trace settings for thread. eCos only.
 */
void vtss_trace_thread_get(int thread_id, vtss_trace_thread_t *trace_thread);

/*
 * Get trace level for (module, group)
 */
int vtss_trace_module_lvl_get(int module_id, int grp_idx);

/* 
 * Get name of next module or group with id/idx greater than the specified 
 * value.
 * 
 * NULL pointer is returned when no more modules/groups.
 * To get all names, start by requesting id/idx -1 and keep requesting until 
 * NULL is returned.
 * *module_id_p / *grp_idx_p is updated to correspond to the returned name.
 */  
char *vtss_trace_module_name_get_nxt(int *module_id_p);
char *vtss_trace_grp_name_get_nxt(int module_id, int *grp_idx_p);

/* Get module/group description */
char *vtss_trace_module_get_descr(int module_id);
char *vtss_trace_grp_get_descr(int module_id, int grp_idx);

/* Get parm setting for group */  
BOOL vtss_trace_grp_get_parm(
    vtss_trace_module_parm_t parm,
    int module_id, int grp_idx);

/*
 * Convert module/group name to module_id/grp_idx
 * Name only needs to be unique, not complete.
 *
 * Returns 1 if id/idx was found. 
 */
BOOL vtss_trace_module_to_val(const char *name, int *module_id_p);
BOOL vtss_trace_grp_to_val(   const char *name, int  module_id, int *grp_idx_p);

/* Convert trace level name to value */
BOOL  vtss_trace_lvl_to_val(const char *name, int *lvl_p);
const char *vtss_trace_lvl_to_str(int lvl);
/* ======================================================================== */


/* ===========================================================================
 * Additional IO
 *
 * By default serial port is the only output device for trace macroes.
 * Additional IO devices can be registered using below functions.
 * Such IO devices could - e.g. - be telnet connections.
 * ------------------------------------------------------------------------ */

/* IO layer */
typedef struct _vtss_trace_io_t {
    void (*trace_putchar)      (struct _vtss_trace_io_t *pIO, char ch);
    int  (*trace_vprintf)      (struct _vtss_trace_io_t *pIO, const char *fmt, va_list ap);
    void (*trace_write_string) (struct _vtss_trace_io_t *pIO, const char *str);
    void (*trace_flush)        (struct _vtss_trace_io_t *pIO);
} vtss_trace_io_t;

/* 
 * Registration function. 
 * trace_io_t must NOT be allocated on stack.
 * 
 * io_reg_id is returned. 
 * To be used if later calling vtss_trace_io_unregister().
 */
vtss_rc vtss_trace_io_register(
    vtss_trace_io_t   *io,
    vtss_module_id_t  module_id,
    uint              *io_reg_id);

/* 
 * Unregistration function
 */
vtss_rc vtss_trace_io_unregister(
    uint *io_reg_id);

/* ======================================================================== */


/* ===========================================================================
 * Internal definitions - do NOT use outside trace module
 * ------------------------------------------------------------------------ */

/* Do not use these functions - use the wrappers above */
void vtss_trace_reg_init(vtss_trace_reg_t* trace_reg_p, vtss_trace_grp_t* trace_grp_p, int grp_cnt);
vtss_rc vtss_trace_register(vtss_trace_reg_t* trace_reg_p);
void vtss_trace_printf(int module_id, 
                       int grp_idx,
                       int lvl,
                       const char *location,
                       uint line_no,
                       const char *fmt,
                       ...)
__attribute__ ((format (printf, 6, 7)));



// Macro for only printing out trace for ports that has trace enabled
#define vtss_trace_port_printf(pi, mi, gi, lvl, lo, ln, fmt, ...) \
  do { \
    if(pi < VTSS_PORTS && vtss_trace_port_get(pi)) { \
        char str[150]; \
        sprintf(str,"Port %d: ",pi + VTSS_PORT_NO_START); \
        strcat(str,fmt); \
        vtss_trace_printf(mi, gi, lvl, lo, ln, &str[0], ##__VA_ARGS__); \
    } \
  } while(0);

void vtss_trace_hex_dump(int module_id, 
                         int grp_idx,
                         int lvl,
                         const char *location,
                         uint line_no,
                         const uchar *byte_p,
                         int  byte_cnt);

/* ======================================================================== */


/* ===========================================================================
 * Special macroes, only intended for use in Switch API
 * ------------------------------------------------------------------------ */
#if (VTSS_TRACE_ENABLED)
#define T_EXPLICIT_NO_VA(module_id, grp_idx, lvl, func, line_no, msg) \
  vtss_trace_printf(module_id, grp_idx, lvl, func, line_no, "%s", msg)
#else
#define T_EXPLICIT_NO_VA(module_id, grp_idx, lvl, func, line_no, msg)
#endif /* (VTSS_TRACE_LVL_MIN < VTSS_TRACE_LVL_NONE) */
/* ======================================================================== */


#endif /* _VTSS_TRACE_API_H_ */


/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
