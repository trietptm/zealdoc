/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_trace_io.c,v 1.14 2008/02/20 15:05:13 cpj Exp $
 $Revision: 1.14 $

*/


#if defined(VTSS_OPSYS_ECOS)
#include <cyg/infra/diag.h>
#else
#include <stdio.h>
#define diag_sprintf		sprintf
#define diag_printf		printf
#define diag_vprintf		vprintf
#define diag_write_string(s)	fputs(s, stdout)
#define diag_write_char(c)	putchar(c)
#endif

#include "vtss_trace.h"


#define TRACE_MAX_IO_REGS 3
typedef struct _trace_io_reg_t {
    vtss_trace_io_t  *io;
    vtss_module_id_t module_id;
} trace_io_reg_t;

static int trace_io_reg_cnt = 0;
static trace_io_reg_t trace_io_regs[TRACE_MAX_IO_REGS];



/* ###########################################################################
 * Internal functions
 * 
 * The "err_buf" argument is used to store a copy of the trace message,
 * used for writing error messages to flash.
 * If err_buf is NULL, then such copy is generated.
 * ------------------------------------------------------------------------ */

int  trace_sprintf(char *buf, const char *fmt, ...)
{
    int rv;
    va_list ap;
    va_start(ap, fmt);

    rv = diag_sprintf(buf, fmt, ap);

    va_end(ap);

    return rv;
} /* trace_sprintf */


int  trace_printf(char *err_buf,  const char *fmt, ...)
{
    int rv = 0;

    va_list ap;
    va_start(ap, fmt);

    rv = trace_vprintf(err_buf, fmt, ap);

    va_end(ap);

    return rv;
} /* trace_printf */


int  trace_vprintf(char *err_buf, const char *fmt, va_list ap)
{
    int rv;
    rv = diag_vprintf(fmt, ap);

    if (trace_io_reg_cnt) {
        int i = 0;
        for (i = 0; i < TRACE_MAX_IO_REGS; i++) {
            if (trace_io_regs[i].io != NULL) {
                trace_io_regs[i].io->trace_vprintf(trace_io_regs[i].io, fmt, ap);
            }
        }
    }

    if (err_buf) {
        vsprintf(&err_buf[strlen(err_buf)], fmt, ap);
    }

    return rv;
} /* trace_vprintf */


void trace_write_string(char *err_buf, const char *str)
{
    diag_write_string(str);

    if (trace_io_reg_cnt) {
        int i = 0;
        for (i = 0; i < TRACE_MAX_IO_REGS; i++) {
            if (trace_io_regs[i].io != NULL) {
                trace_io_regs[i].io->trace_write_string(trace_io_regs[i].io, str);
            }
        }
    }

    if (err_buf) {
        sprintf(&err_buf[strlen(err_buf)], str);
    }
    
} /* trace_write_string */


void trace_write_char(char *err_buf, char c)
{
    diag_write_char(c);

    if (trace_io_reg_cnt) {
        int i = 0;
        for (i = 0; i < TRACE_MAX_IO_REGS; i++) {
            if (trace_io_regs[i].io != NULL) {
                trace_io_regs[i].io->trace_putchar(trace_io_regs[i].io, c);
            }
        }
    }

    if (err_buf) {
        sprintf(&err_buf[strlen(err_buf)], "%c", c);
    }

} /* trace_write_char */


void trace_flush(void)
{
    if (trace_io_reg_cnt) {
        int i = 0;
        for (i = 0; i < TRACE_MAX_IO_REGS; i++) {
            if (trace_io_regs[i].io != NULL) {
                trace_io_regs[i].io->trace_flush(trace_io_regs[i].io);
            }
        }
    }
} /* trace_flush */

/* ---------------------------------------------------------------------------
 * Internal functions
 * ######################################################################## */

/* ###########################################################################
 * API functions
 * ------------------------------------------------------------------------ */

vtss_rc vtss_trace_io_register(
    vtss_trace_io_t  *trace_io,
    vtss_module_id_t module_id,
    uint        *io_reg_id)
{
    vtss_rc rc = VTSS_OK;
    uint         i;

    T_D("enter, module_id=%d", module_id);
    
#if VTSS_TRACE_MULTI_THREAD
    VTSS_OS_SEM_WAIT(&trace_crit);
#endif

    /* Find an unused entry in registration table */
    for (i = 0; i < TRACE_MAX_IO_REGS; i++) {
        if (trace_io_regs[i].io == NULL) {
            break;
        }
    }
    
    if (trace_io_regs[i].io == NULL) {
        trace_io_regs[i].io = trace_io;
        trace_io_regs[i].module_id = module_id;
        *io_reg_id = i;
        trace_io_reg_cnt++;
    } else {
        T_E("All io registrations in use(!), TRACE_MAX_IO_REGS=%d, trace_io_reg_cnt=%d",
            TRACE_MAX_IO_REGS, trace_io_reg_cnt);
        rc = VTSS_UNSPECIFIED_ERROR;
    }
    
#if VTSS_TRACE_MULTI_THREAD
    VTSS_OS_SEM_POST(&trace_crit);
#endif

    T_D("exit, module_id=%d, rc=%d, io_reg_id=%u", module_id, rc, *io_reg_id);
    
    return rc;
} /* vtss_trace_io_register */


vtss_rc vtss_trace_io_unregister(
    uint *io_reg_id)
{
    vtss_rc rc = VTSS_OK;
    
    T_D("enter, *io_reg_id=%u", *io_reg_id);
    
#if VTSS_TRACE_MULTI_THREAD
    VTSS_OS_SEM_WAIT(&trace_crit);
#endif

    TRACE_ASSERT(*io_reg_id < TRACE_MAX_IO_REGS, ("*io_reg_id=%d", *io_reg_id));

    trace_io_regs[*io_reg_id].io = NULL;
    trace_io_reg_cnt--;
    
#if VTSS_TRACE_MULTI_THREAD
    VTSS_OS_SEM_POST(&trace_crit);
#endif

    T_D("exit, module_id=%d, rc=%d, io_reg_id=%u", trace_io_regs[*io_reg_id].module_id, rc, *io_reg_id);
    
    return rc;
} /* vtss_trace_io_unregister */



/* ---------------------------------------------------------------------------
 * API functions
 * ######################################################################## */


/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
