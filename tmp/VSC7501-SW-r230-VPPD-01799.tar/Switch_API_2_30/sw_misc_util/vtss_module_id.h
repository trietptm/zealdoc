/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_module_id.h,v 1.41 2008/09/09 04:51:48 pchen Exp $
 $Revision: 1.41 $

*/

#ifndef _VTSS_MODULE_ID_H_
#define _VTSS_MODULE_ID_H_

/* Module IDs */
/* 
 * !!!!! IMPORTANT !!!!!
 * ---------------------
 * When adding new module IDs, these MUST be added at the end of the current 
 * list. Also module IDs MUST NEVER be deleted from the list.
 * This is necessary to ensure that the Msg protocol can rely on consistent
 * module IDs between different SW versions.
 */
typedef enum {
    /* Switch API */
    VTSS_MODULE_ID_API_IO = 0, /* API I/O Layer */
    VTSS_MODULE_ID_API_CI,     /* API Chip Interface Layer */
    VTSS_MODULE_ID_API_AI,     /* API Application Interface Layer */
    VTSS_MODULE_ID_SPROUT,     /* SPROUT (3) */
    VTSS_MODULE_ID_MAIN,
    VTSS_MODULE_ID_TOPO,       /* 5 */
    VTSS_MODULE_ID_CONF,
    VTSS_MODULE_ID_MSG,
    VTSS_MODULE_ID_PACKET,
    VTSS_MODULE_ID_TRACE,      /* 9 */
    VTSS_MODULE_ID_IP_STACK_GLUE,
    VTSS_MODULE_ID_PORT,
    VTSS_MODULE_ID_MAC,
    VTSS_MODULE_ID_VLAN,
    VTSS_MODULE_ID_QOS,
    VTSS_MODULE_ID_MIRROR,
    VTSS_MODULE_ID_MISC,
    VTSS_MODULE_ID_ACL,
    VTSS_MODULE_ID_IP,
    VTSS_MODULE_ID_AGGR,
    VTSS_MODULE_ID_RSTP,
    VTSS_MODULE_ID_DOT1X,
    VTSS_MODULE_ID_IGMP,
    VTSS_MODULE_ID_PVLAN,
    VTSS_MODULE_ID_SYSTEM,
    VTSS_MODULE_ID_CLI,
    VTSS_MODULE_ID_WEB,
    VTSS_MODULE_ID_PING,
    VTSS_MODULE_ID_FIRMWARE,
    VTSS_MODULE_ID_UNMGD,    /* Appl. code for unmanaged, single-threaded switch */
    VTSS_MODULE_ID_MSG_TEST, /* 30. Used for test-purposes only. */
    VTSS_MODULE_ID_LED,      /* LED handling */
    VTSS_MODULE_ID_CRITD,    /* Critical regions with debug facilities */
    VTSS_MODULE_ID_L2PROTO,
    VTSS_MODULE_ID_LLDP,
    VTSS_MODULE_ID_LACP,
    VTSS_MODULE_ID_SNMP,
    VTSS_MODULE_ID_SYSLOG,
    VTSS_MODULE_ID_IGMPS,    /* 38 */
    VTSS_MODULE_ID_CONF_XML,
    VTSS_MODULE_ID_VTSS_LB,
    VTSS_MODULE_ID_INTERRUPT,
    VTSS_MODULE_ID_SYNCE,
    VTSS_MODULE_ID_POE,
    VTSS_MODULE_ID_MODULE_CONFIG,
    VTSS_MODULE_ID_EPS,
    VTSS_MODULE_ID_MEP,
    VTSS_MODULE_ID_HTTPS,

    /* INSERT NEW MODULE IDS HERE. AND ONLY HERE!!!             */
    /* REMEMBER ALSO TO ADD ENTRY IN vtss_module_names BELOW!!! */

    /* Last entry, default */
    VTSS_MODULE_ID_NONE
} vtss_module_id_t;


extern const char* vtss_module_names[VTSS_MODULE_ID_NONE+1];

#ifdef _VTSS_MODULE_ID_C_
/* This code is compiled in vtss_module_id.c, but placed here for convience */
const char* vtss_module_names[VTSS_MODULE_ID_NONE+1] =
{
    [VTSS_MODULE_ID_API_IO]   = "api_io",
    [VTSS_MODULE_ID_API_CI]   = "api_ci",
    [VTSS_MODULE_ID_API_AI]   = "api_ai",
    [VTSS_MODULE_ID_SPROUT]   = "sprout",
    [VTSS_MODULE_ID_MAIN]     = "main",
    [VTSS_MODULE_ID_TOPO]     = "topo",
    [VTSS_MODULE_ID_CONF]     = "conf",
    [VTSS_MODULE_ID_MSG]      = "msg",
    [VTSS_MODULE_ID_PACKET]   = "packet",
    [VTSS_MODULE_ID_TRACE]    = "trace",
    [VTSS_MODULE_ID_IP_STACK_GLUE] = "ip_stack_glue",
    [VTSS_MODULE_ID_PORT]     = "port",
    [VTSS_MODULE_ID_MAC]      = "mac",
    [VTSS_MODULE_ID_VLAN]     = "vlan",
    [VTSS_MODULE_ID_QOS]      = "qos",
    [VTSS_MODULE_ID_MIRROR]   = "mirror",
    [VTSS_MODULE_ID_MISC]     = "misc",
    [VTSS_MODULE_ID_ACL]      = "acl",
    [VTSS_MODULE_ID_IP]       = "ip",
    [VTSS_MODULE_ID_AGGR]     = "aggr",
    [VTSS_MODULE_ID_L2PROTO]  = "l2proto",
    [VTSS_MODULE_ID_RSTP]     = "rstp",
    [VTSS_MODULE_ID_DOT1X]    = "802.1X",
    [VTSS_MODULE_ID_IGMP]     = "igmp",
    [VTSS_MODULE_ID_PVLAN]    = "pvlan",
    [VTSS_MODULE_ID_SYSTEM]   = "system",
    [VTSS_MODULE_ID_CLI]      = "cli",
    [VTSS_MODULE_ID_WEB]      = "web",
    [VTSS_MODULE_ID_PING]     = "ping",
    [VTSS_MODULE_ID_FIRMWARE] = "firmware",
    [VTSS_MODULE_ID_UNMGD]    = "unmgd",
    [VTSS_MODULE_ID_MSG_TEST] = "msg_test",
    [VTSS_MODULE_ID_LED]      = "led",
    [VTSS_MODULE_ID_CRITD]    = "critd",
    [VTSS_MODULE_ID_L2PROTO]  = "l2",
    [VTSS_MODULE_ID_LLDP]     = "lldp",
    [VTSS_MODULE_ID_LACP]     = "lacp",
    [VTSS_MODULE_ID_SNMP]     = "snmp",
    [VTSS_MODULE_ID_SYSLOG]   = "syslog",
    [VTSS_MODULE_ID_IGMPS]    = "igmps",
    [VTSS_MODULE_ID_CONF_XML] = "conf_xml",
    [VTSS_MODULE_ID_VTSS_LB]  = "vtss_lb",
    [VTSS_MODULE_ID_INTERRUPT] = "interrupt",
    [VTSS_MODULE_ID_SYNCE]    = "SyncE",
    [VTSS_MODULE_ID_POE]      = "poe",
    [VTSS_MODULE_ID_MODULE_CONFIG] = "module_config",
    [VTSS_MODULE_ID_EPS]      = "eps",
    [VTSS_MODULE_ID_MEP]      = "mep",
    [VTSS_MODULE_ID_MEP]      = "https",
    [VTSS_MODULE_ID_NONE]     = "none"
};
#endif /* _VTSS_MODULE_ID_C_ */


#endif /* VTSS_MODULE_ID_H_ */
/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
