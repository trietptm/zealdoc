/*

 Vitesse PHY API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_phy.h,v 1.55 2008/09/05 20:45:54 jkrishna Exp $
 $Revision: 1.55 $

*/

#ifndef _VTSS_PHY_AL_H_
#define _VTSS_PHY_AL_H_

#if (defined(VTSS_API))
#include "vtss_switch_api.h"
#endif

/* Get common definitions, types and macros */
#include "vtss_os.h"
/* #include "vtss_basic_trace.h" */
#include "vtss_types.h"
#include "vtss_options.h"
#include "vtss_phy_state.h"

/* ================================================================= *
 *  Supplemental
 * ================================================================= */

/* - Initialization ------------------------------------------------ */

/**********************************************************************
* PHY State information handle allocated by application
*  
* typedef struct _vtss_phy_state_t {
*   vtss_phy_io_state_t io;     // PHY I/O Layer state information 
*   void                *al;    // Pointer to PHY API state memory,
*                               // size: vtss_phy_sizeof_al() 
* } vtss_phy_state_t;
*  
***********************************************************************/

vtss_phy_state_t *vtss_phy_state;   /* Full PHY API state */

/******************************************************************************
 * Description : Get PHY API state information size. 
 *
 * \param ports (input): Number of ports.
 *
 * \return : Size of memory for PHY Application Interface Layer state
 *           information.
 ******************************************************************************/
uint vtss_phy_sizeof_al(const uint ports);


/******************************************************************************
 * Description: Select PHY API context.
 *
 * \param state (input): Pointer to memory allocated for API state information.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_select_context(vtss_phy_state_t * const state);

/**********************************************************************
 * Initialization setup
 *  
 * typedef struct _vtss_phy_init_setup_t {
 *      uint                ports;
 * } vtss_phy_init_setup_t;
 * 
***********************************************************************/

/******************************************************************************
 * Description: Initialize PHY API.
 *
 * \param setup (input): Pointer to initialization setup.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_init(const vtss_phy_init_setup_t * const setup);

/******************************************************************************
 * Description: Initialize PHY API. (Re-entrant)
 *
 * \param state (input)  : Full API State
 * \param setup (input)  : Pointer to initialization setup.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_init_r(vtss_phy_state_t * const            state, 
                        const vtss_phy_init_setup_t * const setup);

/* - Port mapping -------------------------------------------------- */

/****************************************************************************
 * 
 * typedef struct _vtss_phy_mapped_port_t {
 *      vtss_phy_io_bus_t   bus;
 *      int                 addr;
 * } vtss_phy_mapped_port_t;
 * 
*****************************************************************************/

/******************************************************************************
 * Description: Setup port mapping.
 *
 * \param mapped_ports (input): PHY port map array indexed by vtss_port_no_t.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_port_map_set( const vtss_phy_mapped_port_t * mapped_ports );

/******************************************************************************
 * Description: Setup port mapping. (Re-entrant)
 *
 * \param state (input)       : Full API State
 * \param mapped_ports (input): PHY port map array indexed by vtss_port_no_t.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_port_map_set_r( vtss_phy_state_t * const       state, 
                                 const vtss_phy_mapped_port_t * mapped_ports );

/******************************************************************************
 * Description: Setup port mapping for a port. Port 0 can be used for accessing
 *              PHYs by their (bus,address) location.
 *
 * \param port_no (input): Port number connected to PHY.
 * \param bus (input)    : PHY MIIM bus.
 * \param addr (input)   : PHY address on MIIM bus.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_map_port( const vtss_port_no_t    port_no,
                           const vtss_phy_io_bus_t bus,
                           const int               addr );

/******************************************************************************
 * Description: Setup port mapping for a port. Port 0 can be used for accessing
 *              PHYs by their (bus,address) location. (Re-entrant)
 *
 * \param state (input)  : Full API State
 * \param port_no (input): Port number connected to PHY.
 * \param bus (input)    : PHY MIIM bus.
 * \param addr (input)   : PHY address on MIIM bus.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_map_port_r ( vtss_phy_state_t * const       state, 
                              const vtss_port_no_t           port_no,
                              const vtss_phy_io_bus_t        bus,
                              const int                      addr );

/******************************************************************************
 * Description: Functions that change PHY register pages
 *
 * \param port_no (input): Port number connected to PHY.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_page_std(vtss_port_no_t port_no);

vtss_rc vtss_phy_page_ext(vtss_port_no_t port_no);

vtss_rc vtss_phy_page_gpio(vtss_port_no_t port_no);

vtss_rc vtss_phy_page_test(vtss_port_no_t port_no);

vtss_rc vtss_phy_page_tr(vtss_port_no_t port_no);

/* - PHY reset ----------------------------------------------------- */

/******************************************************************************
 * Media interface type
 *  
 * typedef enum _vtss_phy_media_interface_t {
 *  VTSS_PHY_MEDIA_INTERFACE_COPPER,      // Copper interface
 *  VTSS_PHY_MEDIA_INTERFACE_FIBER,       // SerDes/Fiber interface 
 *  VTSS_PHY_MEDIA_INTERFACE_AMS_COPPER,  // Automatic selection, copper preferred 
 *  VTSS_PHY_MEDIA_INTERFACE_AMS_FIBER    // Automatic selection, fiber preferred 
 * } vtss_phy_media_interface_t;
 * 
 * typedef struct _vtss_phy_reset_t {
 *  vtss_port_interface_t      mac_if;   // MAC interface
 *  vtss_phy_media_interface_t media_if; // Media inteface
 *  
 *      // RGMII setup 
 *      struct {
 *          uint rx_clk_skew_ps; // Rx clock skew in pico seconds 
 *          uint tx_clk_skew_ps; // Tx clock skew in pico seconds 
 *      } rgmii;
 * 
 *      // TBI setup 
 *      struct {
 *          BOOL aneg_enable; // Enable auto negotiation 
 *      } tbi;
 * } vtss_phy_reset_setup_t;
 * 
 *******************************************************************************/
 
/******************************************************************************
 * Description: Reset PHY.
 *
 * \param port_no (input): Port number of PHY.
 * \param setup (input)  : Reset setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_reset( const vtss_port_no_t port_no, 
                        const vtss_phy_reset_setup_t * const setup );

/******************************************************************************
 * Description: Reset PHY. (Re-entrant)
 *
 * \param state (input)  : Full API State
 * \param port_no (input): Port number of PHY.
 * \param setup (input)  : Reset setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_reset_r ( vtss_phy_state_t * const             state,
                           const vtss_port_no_t                 port_no, 
                           const vtss_phy_reset_setup_t * const setup );

/******************************************************************************
 * Description: Detect PHY Type, Family, Revision.
 *
 * \param reg2    (input)   : MII Register 2 value.
 * \param reg3    (input)   : MII Register 3 value.
 * \param mac_if  (input)   : MAC I/F being used.
 * \param ps      (output)  : PHY port state populated with the PHY Type, Family 
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_detect ( const ushort reg2, const ushort reg3, 
                          const vtss_port_interface_t mac_if,
                          vtss_phy_port_state_info_t* ps );                      

/******************************************************************************
 * Description: Detect PHY Type, Family, Revision. (Re-entrant)
 *
 * \param state (input)     : Full API State
 * \param reg2    (input)   : MII Register 2 value.
 * \param reg3    (input)   : MII Register 3 value.
 * \param mac_if  (input)   : MAC I/F being used.
 * \param ps      (output)  : PHY port state populated with the PHY Type, Family 
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_detect_r ( vtss_phy_state_t * const state,
                            const ushort reg2, const ushort reg3, 
                            const vtss_port_interface_t mac_if,
                            vtss_phy_port_state_info_t* ps );
                          
/* - PHY setup ----------------------------------------------------- */
/******************************************************************************
 * typedef struct _vtss_phy_setup_t {
 *  // PHY mode 
 *  enum {
 *      VTSS_PHY_MODE_ANEG,      // Auto negoatiation 
 *      VTSS_PHY_MODE_FORCED,    // Forced mode 
 *      VTSS_PHY_MODE_POWER_DOWN // Power down (disabled) 
 *  } mode;
 *
 *  // Forced mode 
 *  struct {
 *      vtss_speed_t speed; // Speed 
 *      BOOL         fdx;   // Full duplex 
 *  } forced;
 *  
 *  // Auto negotiation advertisement 
 *  struct {
 *      BOOL speed_10m_hdx;    // 10Mbps, half duplex 
 *      BOOL speed_10m_fdx;    // 10Mbps, full duplex 
 *      BOOL speed_100m_hdx;   // 100Mbps, half duplex 
 *      BOOL speed_100m_fdx;   // 100Mbps, full duplex 
 *      BOOL speed_1g_fdx;     // 1000Mpbs, full duplex 
 *      BOOL symmetric_pause;  // Symmetric pause 
 *      BOOL asymmetric_pause; // Asymmetric pause 
 *  } aneg;
 * } vtss_phy_setup_t;
 * 
 *******************************************************************************/

/******************************************************************************
 * Description: Setup PHY
 *
 * \param port_no (input): Port number of PHY.
 * \param setup (input)  : Setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_setup( const vtss_port_no_t           port_no, 
                        const vtss_phy_setup_t * const setup ); 

/******************************************************************************
 * Description: Setup PHY (Re-entrant)
 *
 * \param state (input)  : Full API State.
 * \param port_no (input): Port number of PHY.
 * \param setup (input)  : Setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_setup_r( vtss_phy_state_t * const       state, 
                          const vtss_port_no_t           port_no, 
                          const vtss_phy_setup_t * const setup ); 

/******************************************************************************
// 1000-BT Control 
typedef struct _vtss_phy_setup_1g_t {
    enum {
        VTSS_PHY_TX_TMOD_NORMAL,                // Normal - (Default)
        VTSS_PHY_TX_TMOD_WAVE_FORM_TEST,        // Xmit Waveform Test 
        VTSS_PHY_TX_TMOD_JTR_TST_MSTR,          // Xmit Jitter test as Master 
        VTSS_PHY_TX_TMOD_JTR_TST_SLV,           // Xmit Jitter test as Slave 
        VTSS_PHY_TX_TMOD_XMIT_DSTN_TEST         // Xmitter Distortion test 
    } txmtr_test_mode;                          // Transmitter Test Mode 
    
    struct {
        BOOL cfg;                               // Manual Mst/Slv Cfg. 0=disabled (Default) 
        BOOL val;                               // Mst/Slv Cfg val, 0=Slave (Default) 
    } master_slave;
    
    BOOL multi_port;                           // Multi-port device? (default = 1)
    BOOL 1G_FDX_cap;                           // 1G FDX capable? (default = CMODE)
    BOOL 1G_HDX_cap;                           // 1G HDX capable? (default = CMODE)
} vtss_phy_setup_1g;
 *******************************************************************************/
 
/******************************************************************************
 * Description: Setup PHY 1G mode 
 *
 * \param port_no (input): Port number of PHY.
 * \param setup_1g (input)  : Setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_setup_1g ( const vtss_port_no_t           port_no, 
                            const vtss_phy_setup_1g_t * const setup_1g );

/******************************************************************************
 * Description: Setup PHY 1G mode (Re-entrant)
 *
 * \param state (input)  : Full API State.
 * \param port_no (input): Port number of PHY.
 * \param setup_1g (input)  : Setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_setup_1g_r ( vtss_phy_state_t * const       state, 
                           const vtss_port_no_t           port_no, 
                           const vtss_phy_setup_1g_t * const setup_1g ); 
                                                  
/******************************************************************************
 * // Power Save/Reduction modes 
 * typedef enum _vtss_phy_power_mode {
 *  VTSS_PHY_POWER_NOMINAL,    // Default power settings 
 *  VTSS_PHY_POWER_ACTIPHY,    // ActiPHY - Link down power savings enabled
 *  VTSS_PHY_POWER_DYNAMIC,    // SimpliGreen - Link up power savings enabled
 *  VTSS_PHY_POWER_ENABLED,    // ActiPHY + SimpliGreen enabled 
 * } vtss_phy_power_mode_t;
 * 
 * typedef struct _vtss_phy_power_setup_t {
 *  BOOL vtss_phy_power_dynamic;
 *  BOOL vtss_phy_actiphy_on;
 * } vtss_phy_power_setup;
 * 
 *****************************************************************************/
 
/******************************************************************************
 * Description: Setup PHY Power Savings Modes
 *
 * \param port_no (input): Port number of PHY.
 * \param setup (input)  : Setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_power_setup( const vtss_port_no_t           port_no, 
                              const vtss_phy_power_mode_t    dpower ); 


/******************************************************************************
 * Description: Setup PHY Power Savings Modes
 *
 * \param port_no (input): Port number of PHY.
 *
 * \return : Power Usage Level.
 ******************************************************************************/
uint vtss_phy_power_status_get( const vtss_port_no_t        port_no);

/* - PHY status ---------------------------------------------------- */

/******************************************************************************
 * Description: Get PHY status.
 *
 * \param port_no (input): Port number of PHY.
 * \param status (output): Status structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_status_get( const vtss_port_no_t       port_no,
                             vtss_port_status_t * const status );

/******************************************************************************
 * Description: Get PHY status. (Re-entrant)
 *
 * \param state (input)  : Full API State.
 * \param port_no (input): Port number of PHY.
 * \param status (output): Status structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_status_get_r( vtss_phy_state_t * const   state, 
                               const vtss_port_no_t       port_no,
                               vtss_port_status_t * const status );

/******************************************************************************
 * Description: Get PHY 1G status.
 *
 * \param port_no (input): Port number of PHY.
 * \param status_1g (output): 1G Status structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_status_1g_get( const vtss_port_no_t       port_no,
                                vtss_port_status_1g_t * const status_1g );

/******************************************************************************
 * Description: Get PHY status. (Re-entrant)
 *
 * \param state (input)  : Full API State.
 * \param port_no (input): Port number of PHY.
 * \param status_1g (output): 1G Status structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_status_1g_get_r( vtss_phy_state_t * const   state, 
                                  const vtss_port_no_t       port_no,
                                  vtss_port_status_1g_t * const status_1g );
                                                              
/* - PHY optimization ---------------------------------------------- */

/******************************************************************************
 * Description: PHY optimization called approximately every second.
 *
 * \param port_no (input): Port number of PHY.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_optimize_1sec(const vtss_port_no_t port_no);

/* - PHY read/write ------------------------------------------------ */

/* PHY register pages */
#define VTSS_PHY_PAGE_STANDARD 0x0000 /* Standard registers */
#define VTSS_PHY_PAGE_EXTENDED 0x0001 /* Extended registers */
#define VTSS_PHY_PAGE_GPIO     0x0010 /* GPIO registers */
#define VTSS_PHY_PAGE_TEST     0x2A30 /* Test registers */
#define VTSS_PHY_PAGE_TR       0x52B5 /* Token ring registers */

/* PHY register page access for a single register can be done 
   using an OR operation of the register address and the page below */
#define VTSS_PHY_REG_STANDARD (VTSS_PHY_PAGE_STANDARD<<5)
#define VTSS_PHY_REG_EXTENDED (VTSS_PHY_PAGE_EXTENDED<<5)
#define VTSS_PHY_REG_GPIO     (VTSS_PHY_PAGE_GPIO<<5)
#define VTSS_PHY_REG_TEST     (VTSS_PHY_PAGE_TEST<<5)
#define VTSS_PHY_REG_TR       (VTSS_PHY_PAGE_TR<<5)

/******************************************************************************
 * Description: Read value from PHY register.
 *
 * \param port_no (input): Port number connected to PHY.
 * \param reg (input)    : PHY register address.
 * \param value (output) : Register value (16 bit).
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_read( const vtss_port_no_t port_no,
                       const uint           reg,
                       ushort *const        value );

/******************************************************************************
 * Description: Read value from PHY register. (Re-entrant)
 *
 * \param port_no (input): Port number connected to PHY.
 * \param reg (input)    : PHY register address.
 * \param value (output) : Register value (16 bit).
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_read_r( vtss_phy_state_t * const       state,
                         const vtss_port_no_t           port_no,
                         const uint                     reg,
                         ushort *const                  value );

/******************************************************************************
 * Description: Write value to PHY register.
 *
 * \param port_no (input): Port number connected to PHY.
 * \param reg (input)    : PHY register address.
 * \param value (input)  : Register value (16 bit).
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_write( const vtss_port_no_t port_no,
                        const uint           reg,
                        const ushort         value );

/******************************************************************************
 * Description: Write value to PHY register. (Re-entrant)
 *
 * \param state (input)  : Full API State.
 * \param port_no (input): Port number connected to PHY.
 * \param reg (input)    : PHY register address.
 * \param value (input)  : Register value (16 bit).
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_write_r(  vtss_phy_state_t * const       state,
                           const vtss_port_no_t           port_no,
                           const uint                     reg,
                           const ushort                   value );

/******************************************************************************
 * Description: Read, modify and write value to PHY register.
 *
 * \param port_no (input): Port number connected to PHY.
 * \param reg (input)    : PHY register address.
 * \param value  (input) : Register value (16 bit).
 * \param mask (input)   : Register mask, only bits enabled are changed.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_writemasked( const vtss_port_no_t port_no,
                              const uint           reg,
                              const ushort         value,
                              const ushort         mask );

/******************************************************************************
 * Description: Read, modify and write value to PHY register. (Re-entrant)
 *
 * \param state (input)  : Full API State.
 * \param port_no (input): Port number connected to PHY.
 * \param reg (input)    : PHY register address.
 * \param value  (input) : Register value (16 bit).
 * \param mask (input)   : Register mask, only bits enabled are changed.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_writemasked_r( vtss_phy_state_t * const       state,
                                const vtss_port_no_t           port_no,
                                const uint                     reg,
                                const ushort                   value,
                                const ushort                   mask );

/* - VeriPHY --------------------------------------------------------------- */

/******************************************************************************
 * Description: Start VeriPHY process on port.
 *
 * \param port_no (input): Port number of PHY.
 * \param mode (input)   : VeriPHY operating mode
 *                0 ==> full VeriPHY algorithm
 *                1 ==> anomaly-search and x-pair (no cable length search)
 *                2 ==> anomaly-search  (no cable length search and no x-pair search)
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_veriphy_start(const vtss_port_no_t port_no, uchar mode);

/******************************************************************************
 * Description: Start VeriPHY process on port. (Re-entrant)
 *
 * \param state (input)  : Full API State.
 * \param port_no (input): Port number of PHY.
 * \param mode (input)   : VeriPHY operating mode
 *                0 ==> full VeriPHY algorithm
 *                1 ==> anomaly-search and x-pair (no cable length search)
 *                2 ==> anomaly-search  (no cable length search and no x-pair search)
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_phy_veriphy_start_r (vtss_phy_state_t * const       state,
                                  const vtss_port_no_t port_no, uchar mode);

/* VeriPHY status */
typedef enum {
    VTSS_VERIPHY_STATUS_OK      = 0,  /* Correctly terminated pair */
    VTSS_VERIPHY_STATUS_OPEN    = 1,  /* Open pair */
    VTSS_VERIPHY_STATUS_SHORT   = 2,  /* Short pair */
    VTSS_VERIPHY_STATUS_ABNORM  = 4,  /* Abnormal termination */
    VTSS_VERIPHY_STATUS_SHORT_A = 8,  /* Cross-pair short to pair A */
    VTSS_VERIPHY_STATUS_SHORT_B = 9,  /* Cross-pair short to pair B */
    VTSS_VERIPHY_STATUS_SHORT_C = 10, /* Cross-pair short to pair C */
    VTSS_VERIPHY_STATUS_SHORT_D = 11, /* Cross-pair short to pair D */
    VTSS_VERIPHY_STATUS_COUPL_A = 12, /* Abnormal cross-pair coupling, pair A */
    VTSS_VERIPHY_STATUS_COUPL_B = 13, /* Abnormal cross-pair coupling, pair B */
    VTSS_VERIPHY_STATUS_COUPL_C = 14, /* Abnormal cross-pair coupling, pair C */
    VTSS_VERIPHY_STATUS_COUPL_D = 15  /* Abnormal cross-pair coupling, pair D */
} vtss_phy_veriphy_status_t;

/* VeriPHY result */
typedef struct {
    BOOL                      link;      /* Link status */
    vtss_phy_veriphy_status_t status[4]; /* Status, pair A-D (0-3) */
    uchar                     length[4]; /* Length (meters), pair A-D (0-3) */
} vtss_phy_veriphy_result_t;

/******************************************************************************
 * Description: Get VeriPHY process result on port.
 *
 * \param port_no (input): Port number of PHY.
 * \param result (output): VeriPHY result, valid if VTSS_OK is returned.
 *
 * \return : Return code, VTSS_INCOMPLETE until result is valid.
 ******************************************************************************/
vtss_rc vtss_phy_veriphy_get (const vtss_port_no_t port_no, 
                              vtss_phy_veriphy_result_t * const result);

/******************************************************************************
 * Description: Get VeriPHY process result on port. (Re-entrant)
 *
 * \param state (input)  : Full API State.
 * \param port_no (input): Port number of PHY.
 * \param result (output): VeriPHY result, valid if VTSS_OK is returned.
 *
 * \return : Return code, VTSS_INCOMPLETE until result is valid.
 ******************************************************************************/
vtss_rc vtss_phy_veriphy_get_r (vtss_phy_state_t * const state, 
                                const vtss_port_no_t port_no, 
                                vtss_phy_veriphy_result_t * const result);
                             
/******************************************************************************
 * Description: Run Init scripts for VSC8204 
 *
 * \param port_no (input), Phy State.
 * \return : Return code, Default VTSS_OK.
 ******************************************************************************/
vtss_rc vtss_phy_init_seq_blazer (vtss_phy_port_state_info_t* ps, 
                                  const vtss_port_no_t port_no);

/******************************************************************************
 * Description: Run Init scripts for VSC8211 
 *
 * \param port_no (input), Phy State.
 * \return : Return code, Default VTSS_OK.
 ******************************************************************************/
vtss_rc vtss_phy_init_seq_cobra (vtss_phy_port_state_info_t* ps, 
                                  const vtss_port_no_t port_no);
                                  
/******************************************************************************
 * Description: Run Init scripts for VSC8224/VSC8234/VSC8244 
 *
 * \param port_no (input), Phy State.
 * \return : Return code, Default VTSS_OK.
 ******************************************************************************/
vtss_rc vtss_phy_init_seq_quattro (vtss_phy_port_state_info_t* ps, 
                                   const vtss_phy_reset_setup_t * const setup,
                                   const vtss_port_no_t port_no);

/******************************************************************************
 * Description: Run Init scripts for VSC8538/VSC8558/VSC8658 
 *
 * \param port_no (input), Phy State.
 * \return : Return code, Default VTSS_OK.
 ******************************************************************************/
vtss_rc vtss_phy_init_seq_spyder (vtss_phy_port_state_info_t* ps, 
                                  const vtss_port_no_t port_no);

/******************************************************************************
 * Description: Run Init scripts for VSC8601/VSC8641 
 *
 * \param port_no (input), Phy State.
 * \return : Return code, Default VTSS_OK.
 ******************************************************************************/
vtss_rc vtss_phy_init_seq_cooper (vtss_phy_port_state_info_t* ps,
                                  const vtss_port_no_t port_no);

/******************************************************************************
 * Description: Run Init scripts for VSC7385/VSC7388/VSC7395/VSC7398/VSC7389/VSC7390/VSC7391
 *
 * \param port_no (input), Phy State
 * \return : Return code, Default VTSS_OK.
 ******************************************************************************/
vtss_rc vtss_phy_init_seq_luton ( vtss_phy_port_state_info_t* ps,
                                  const vtss_phy_reset_setup_t * const setup,
                                  const vtss_port_no_t port_no);

/******************************************************************************
 * Description: Run Init scripts for VSC7500-VSC7507
 *
 * \param port_no (input), Phy State.
 * \return : Return code, Default VTSS_OK.
 ******************************************************************************/
vtss_rc vtss_phy_init_seq_intrigue ( vtss_phy_port_state_info_t* ps,
                                     const vtss_phy_reset_setup_t * const setup, 
                                     const vtss_port_no_t port_no);

/* Active Clock Out */
typedef enum {
    VTSS_PHY_RECOV_CLK1,
    VTSS_PHY_RECOV_CLK2
} vtss_phy_recov_clk_t;

/* PHY Clock Sources */
typedef enum {
    VTSS_PHY_SERDES_MEDIA,        /* SerDes PHY */
    VTSS_PHY_COPPER_MEDIA,        /* Copper PHY */
    VTSS_PHY_TCLK_OUT,            /* Transmitter TCLK */
    VTSS_PHY_LOCAL_XTAL,          /* Local XTAL */
    VTSS_PHY_CLK_DISABLED         /* Recovered Clock Disable */
} vtss_phy_clk_source_t;

/* Clock Frequencies */
typedef enum {
    VTSS_PHY_FREQ_25M,
    VTSS_PHY_FREQ_125M
} vtss_phy_freq_t;

/* Clock Squelch Levels */
typedef enum {
    VTSS_PHY_CLK_SQUELCH_MAX,
    VTSS_PHY_CLK_SQUELCH_MED,
    VTSS_PHY_CLK_SQUELCH_MIN,
    VTSS_PHY_CLK_SQUELCH_NONE
} vtss_phy_clk_squelch;

typedef struct _vtss_phy_recov_clk_config_t {
    vtss_phy_freq_t clk_freq;
    vtss_phy_clk_squelch clk_squelch;
    vtss_phy_clk_source_t clk_src;
} vtss_phy_recov_clk_config_t;

/******************************************************************************
 * Description: Configure PHY Recovered clock 
 *
 * \param port_no (input), clock_port (input), clk_config (input)
 * \return : Return code, Default VTSS_OK.
 ******************************************************************************/
vtss_rc  vtss_phy_recov_clk_configure ( const vtss_port_no_t port_no, 
                                        vtss_phy_recov_clk_t clock_port,
                                        const vtss_phy_recov_clk_config_t * const clk_config );
                                        
/******************************************************************************
 * Description: Run Init scripts for VSC8634,VSC8664
 *
 * \param port_no (input), Phy State.
 * \return : Return code, Default VTSS_OK.
 ******************************************************************************/

vtss_rc vtss_phy_init_seq_enzo ( vtss_phy_port_state_info_t* ps,
                                 const vtss_phy_reset_setup_t * const setup, 
                                 const vtss_port_no_t port_no);

#endif /* _VTSS_PHY_AL_H_ */
