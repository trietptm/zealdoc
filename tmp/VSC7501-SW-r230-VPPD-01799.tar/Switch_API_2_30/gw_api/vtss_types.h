/*

 Vitesse Switch/PHY API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_types.h,v 1.10 2008/06/25 07:50:57 cpj Exp $
 $Revision: 1.10 $

*/

#ifndef _VTSS_TYPES_H_
#define _VTSS_TYPES_H_

/* - Port Numbers -------------------------------------------------- */

/* Port Number: 1..VTSS_PORTS */
typedef uint vtss_port_no_t;    /* VTSS_PORT_NO_START..(VTSS_PORT_NO_END-1) */

/* - MAC interface ------------------------------------------------- */

/* The different interfaces for connecting MAC and PHY. */
typedef enum _vtss_port_interface_t {
    VTSS_PORT_INTERFACE_NO_CONNECTION, /* No connection */
    VTSS_PORT_INTERFACE_LOOPBACK,      /* Internal loopback in MAC */
    VTSS_PORT_INTERFACE_INTERNAL,      /* Internal interface */
    VTSS_PORT_INTERFACE_MII,           /* MII (RMII does not exist) */
    VTSS_PORT_INTERFACE_GMII,          /* GMII */
    VTSS_PORT_INTERFACE_RGMII,         /* RGMII */
    VTSS_PORT_INTERFACE_TBI,           /* TBI */
    VTSS_PORT_INTERFACE_RTBI,          /* RTBI */
    VTSS_PORT_INTERFACE_SGMII,         /* SGMII */
    VTSS_PORT_INTERFACE_SERDES,        /* SERDES */
    VTSS_PORT_INTERFACE_VAUI,          /* VAUI */
    VTSS_PORT_INTERFACE_100FX,         /* 100FX */
    VTSS_PORT_INTERFACE_XAUI,          /* XAUI */
    VTSS_PORT_INTERFACE_XGMII          /* XGMII */
} vtss_port_interface_t;

/* - Speed --------------------------------------------------------- */

/* Speed type */
typedef enum _vtss_speed_t {
    VTSS_SPEED_UNDEFINED,
    VTSS_SPEED_10M,
    VTSS_SPEED_100M,
    VTSS_SPEED_1G,
    VTSS_SPEED_2500M, /* 2.5G */
    VTSS_SPEED_5G,    /* 5G or 2x2.5G */
    VTSS_SPEED_10G
} vtss_speed_t;

/* - Port Status --------------------------------------------------- */

typedef struct _vtss_port_status_t {
    vtss_event_t link_down;    /* Link down event occurred since last call */
    BOOL         link;         /* Link is up. Remaining fields only valid if TRUE */
    vtss_speed_t speed;        /* Speed */
    BOOL         fdx;          /* Full duplex */
    BOOL         remote_fault; /* Remote fault signalled */
    
    /* Auto negotiation result */
    struct {
        BOOL obey_pause;     /* This port should obey PAUSE frames */
        BOOL generate_pause; /* Link partner obeys PAUSE frames */
    } aneg;
} vtss_port_status_t;

typedef struct _vtss_port_status_1g_t {
    BOOL mstr_slv_cfg_fault;    /* Master/Slave Configuration fault */ 
    BOOL mstr;                  /* Master = 1, Slave = 0 */
    BOOL loc_recv_status;       /* Local Receiver Status =1, OK */
    BOOL remt_recv_status;      /* Remote Receiver Status =1, OK */
    BOOL lp_1g_fdx_cap;         /* Link Partner 1G FDX capable? */
    BOOL lp_1g_hdx_cap;         /* Link Partner 1G HDX capable? */
    ushort idle_err_count;      /* Idle Error Count */
} vtss_port_status_1g_t;

#define VTSS_RC(expr) { vtss_rc rc = (expr); if (rc < VTSS_OK) return rc; }

#endif /* _VTSS_TYPES_H_ */
