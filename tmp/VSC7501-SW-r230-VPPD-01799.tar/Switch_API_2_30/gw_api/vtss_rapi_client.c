/*
 nr 2
 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>

#include "vtss_rapi.h"

/****************************************************************************
 * Private data
 */

static int udpSocket;
static struct sockaddr_in 
    serverName = { 0 }, 
    clientName = { 0 };

static vtss_rapi_msg rapireq;

/****************************************************************************
 * Private functions
 */

static size_t
vtss_rapi_send(void *msg, size_t size)
{
    size_t sent = sendto(udpSocket, msg, size, 0,
                         (struct sockaddr *) &serverName,
                         sizeof(serverName));
    if(size != sent)
        fprintf(stderr, "sendto(): short write (%u vs. %u).\n", size, sent);
#if 0
    else
        fprintf(stderr, "sendto(): wrote %u bytes.\n", size);
#endif

    return sent;
}

static size_t
vtss_rapi_recive(void *msg, size_t size)
{
    size_t clientLength = sizeof(struct sockaddr_in);
    if((size = recvfrom(udpSocket, msg,
                        size, 0,
                        (struct sockaddr *) &clientName,
                        &clientLength)) == -1){
            perror("recvfrom()");
            return 0;
    }
    /* fprintf(stderr, "recvfrom(): read %u bytes.\n", size); */
    return size;
}

static size_t 
vtss_rapi_initmsg(vtss_rapi_msg *msg, vtss_rapi_req_t reqtype)
{
    size_t size = vtss_rapi_msgsize(reqtype);

    /* Format request */
    memset(msg, 0, size);
    msg->req = reqtype;
    msg->rc = VTSS_INCOMPLETE; /* Pending */
    return size;
}

static vtss_rc
vtss_rapi_exec(vtss_rapi_msg *msg, size_t size)
{
    if(vtss_rapi_send(msg, size) != size)
        return (msg->rc = VTSS_UNSPECIFIED_ERROR);
        
    if(!vtss_rapi_recive(msg, size))
        return (msg->rc = VTSS_INCOMPLETE);

    return msg->rc;
}

/****************************************************************************
 * Initialization functions
 */

int vtss_rapi_init(void)
{
    int myPort = PORT;

    if((udpSocket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
        perror("socket()");
        return -1;
    }

    memset(&serverName, 0, sizeof(serverName));
    memset(&clientName, 0, sizeof(clientName));
    
    serverName.sin_family = AF_INET;
    inet_aton("127.0.0.1", &serverName.sin_addr);
    serverName.sin_port = htons(myPort);
    
    clientName.sin_family = AF_INET;
    clientName.sin_addr.s_addr = htonl(INADDR_ANY);
    clientName.sin_port = 0;
    
    if(bind(udpSocket, (struct sockaddr *) &clientName, sizeof(clientName)) == -1) {
        perror("bind()");
        return -1;
    }

    return 0;
}

/****************************************************************************
 * Exposed API
 */

vtss_rc vtss_appl_port_status_get(const vtss_port_no_t            port_no,
                                  vtss_appl_port_status_t * const status)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_APPL_PORT_STATUS_GET);
    rapireq.var.appl_port_status_get.port_no = port_no;

    /* Execute and copy result */
    if (vtss_rapi_exec(&rapireq, size) == VTSS_OK)
        *status = rapireq.var.appl_port_status_get.status;

    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_appl_port_conf_get(const vtss_port_no_t          port_no,
                                vtss_appl_port_conf_t * const conf)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_APPL_PORT_CONF_GET);
    rapireq.var.appl_port_conf_get.port_no = port_no;

    /* Execute and copy result */
    if (vtss_rapi_exec(&rapireq, size) == VTSS_OK)
        *conf = rapireq.var.appl_port_conf_get.conf;

    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_appl_port_conf_set(const vtss_port_no_t                port_no,
                                const vtss_appl_port_conf_t * const conf)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_APPL_PORT_CONF_SET);
    rapireq.var.appl_port_conf_set.port_no = port_no;
    rapireq.var.appl_port_conf_set.conf = *conf;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_appl_grocx_port_map_get(const vtss_port_no_t            port_no,
                                  vtss_appl_grocx_port_map_t * const map)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_APPL_GROCX_PORT_MAP_GET);
    rapireq.var.appl_grocx_port_map_get.port_no = port_no;

    /* Execute and copy result */
    if (vtss_rapi_exec(&rapireq, size) == VTSS_OK)
        *map = rapireq.var.appl_grocx_port_map_get.map;

    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_phy_setup(const vtss_port_no_t port_no,
                       const vtss_phy_setup_t * const setup)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_PHY_SETUP);
    rapireq.var.phy_setup.port_no = port_no;
    rapireq.var.phy_setup.setup = *setup;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_port_status_get(const vtss_port_no_t port_no,
                             vtss_port_status_t * const status)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_PORT_STATUS_GET);
    rapireq.var.port_status_get.port_no = port_no;

    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;

    /* Copyout results */
    *status = rapireq.var.port_status_get.status;

    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_port_setup(const vtss_port_no_t port_no,
                        const vtss_port_setup_t * const setup)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_PORT_SETUP);
    rapireq.var.port_setup.port_no = port_no;
    rapireq.var.port_setup.setup = *setup;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_poag_counters_get(const vtss_poag_no_t         poag_no,
                               vtss_poag_counters_t * const counters)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_POAG_COUNTERS_GET);
    rapireq.var.poag_counters_get.poag_no = poag_no;

    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;

    /* Copyout results */
    *counters = rapireq.var.poag_counters_get.counters;

    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_poag_counters_clear(const vtss_poag_no_t poag_no)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_POAG_COUNTERS_CLEAR);
    rapireq.var.poag_counters_clear.poag_no = poag_no;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

#if defined(VTSS_FEATURE_ACL)
vtss_rc vtss_acl_policy_no_set(const vtss_port_no_t       port_no,
                               const vtss_acl_policy_no_t policy_no)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_ACL_POLICY_NO_SET);
    rapireq.var.acl_policy_no_set.port_no = port_no;
    rapireq.var.acl_policy_no_set.policy_no = policy_no;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_acl_port_action_set(const vtss_port_no_t            port_no,
                                 const vtss_acl_action_t * const action)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_ACL_PORT_ACTION_SET);
    rapireq.var.acl_port_action_set.port_no = port_no;
    rapireq.var.acl_port_action_set.action = *action;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_acl_policer_rate_set(const vtss_acl_policer_no_t policer_no,
                                  const vtss_packet_rate_t    rate)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_ACL_POLICER_RATE_SET);
    rapireq.var.acl_policer_rate_set.policer_no = policer_no;
    rapireq.var.acl_policer_rate_set.rate = rate;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_acl_port_counter_get(const vtss_port_no_t            port_no,
                                  vtss_acl_port_counter_t * const counter)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_ACL_PORT_COUNTER_GET);
    rapireq.var.acl_port_counter_get.port_no = port_no;

    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;

    /* Copyout results */
    *counter = rapireq.var.acl_port_counter_get.counter;

    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_acl_port_counter_clear(const vtss_port_no_t port_no)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_ACL_PORT_COUNTER_CLEAR);
    rapireq.var.acl_port_counter_clear.port_no = port_no;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_ace_counter_get(const vtss_ace_id_t ace_id,
                             vtss_ace_counter_t * const counter)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_ACE_COUNTER_GET);
    rapireq.var.ace_counter_get.ace_id = ace_id;

    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;

    /* Copyout results */
    *counter = rapireq.var.ace_counter_get.counter;

    /* Return result */
    return rapireq.rc;
}                                  

vtss_rc vtss_ace_counter_clear(const vtss_ace_id_t ace_id)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_ACE_COUNTER_CLEAR);
    rapireq.var.ace_counter_clear.ace_id = ace_id;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_ace_init(const vtss_ace_type_t type, vtss_ace_t * const ace)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_ACE_INIT);
    rapireq.var.ace_init.type = type;
    
    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;
        
    /* Copyout results */
    *ace = rapireq.var.ace_init.ace;
    
    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_ace_add(const vtss_ace_id_t ace_id, const vtss_ace_t * const ace)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_ACE_ADD);
    rapireq.var.ace_add.ace_id = ace_id;
    rapireq.var.ace_add.ace = *ace;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_ace_del(const vtss_ace_id_t ace_id)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_ACE_DEL);
    rapireq.var.ace_del.ace_id = ace_id;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

#endif /* VTSS_FEATURE_ACL */

#if defined(VTSS_FEATURE_QCL_PORT)
vtss_rc vtss_qce_add(const vtss_qcl_id_t         qcl_id,
                     const vtss_qce_id_t         qce_id,
                     const vtss_qce_t    * const qce)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_QCE_ADD);
    rapireq.var.qce_add.qcl_id = qcl_id;
    rapireq.var.qce_add.qce_id = qce_id;
    rapireq.var.qce_add.qce = *qce;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_qce_del(const vtss_qcl_id_t  qcl_id,
                     const vtss_qce_id_t  qce_id)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_QCE_DEL);
    rapireq.var.qce_del.qcl_id = qcl_id;
    rapireq.var.qce_del.qce_id = qce_id;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

#endif /* VTSS_FEATURE_QCL_PORT */


vtss_rc vtss_qos_setup_get(vtss_qos_setup_t * const qos)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_QOS_SETUP_GET);

    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;

    /* Copyout results */
    *qos = rapireq.var.qos_setup_get.qos;

    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_qos_setup_set(const vtss_qos_setup_t * const qos)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_QOS_SETUP_SET);
    rapireq.var.qos_setup_set.qos = *qos;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_qos_prios_set(vtss_prio_t prios)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_QOS_PRIOS_SET);
    rapireq.var.qos_prios_set.prios = prios;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_port_qos_get(const vtss_port_no_t port_no,
                          vtss_port_qos_setup_t * const qos)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_PORT_QOS_GET);
    rapireq.var.port_qos_get.port_no = port_no;

    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;

    /* Copyout results */
    *qos = rapireq.var.port_qos_get.qos;

    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_port_qos_set(const vtss_port_no_t port_no,
                          const vtss_port_qos_setup_t * const qos)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_PORT_QOS_SET);
    rapireq.var.port_qos_set.port_no = port_no;
    rapireq.var.port_qos_set.qos = *qos;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_vlan_port_mode_get(const vtss_port_no_t port_no,
                                vtss_vlan_port_mode_t * const vlan_mode)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_VLAN_PORT_MODE_GET);
    rapireq.var.vlan_port_mode_get.port_no = port_no;
    
    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;
    
    *vlan_mode = rapireq.var.vlan_port_mode_get.vlan_mode;

    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_vlan_port_mode_set(const vtss_port_no_t port_no,
                                const vtss_vlan_port_mode_t * const vlan_mode)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_VLAN_PORT_MODE_SET);
    rapireq.var.vlan_port_mode_set.port_no = port_no;
    rapireq.var.vlan_port_mode_set.vlan_mode = *vlan_mode;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_vlan_port_members_get(const vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_VLAN_PORT_MEMBERS_GET);
    rapireq.var.vlan_port_members_get.vid = vid;
    
    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;
    
    memcpy(member, rapireq.var.vlan_port_members_get.member,  
           sizeof(rapireq.var.vlan_port_members_get.member));

    /* Return result */
    return rapireq.rc;
}


vtss_rc vtss_vlan_port_members_set(const vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_VLAN_PORT_MEMBERS_SET);
    rapireq.var.vlan_port_members_set.vid = vid;
    memcpy(rapireq.var.vlan_port_members_set.member, member, 
           sizeof(rapireq.var.vlan_port_members_set.member));

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}



vtss_rc vtss_pvlan_port_members_get(const vtss_pvlan_no_t pvlan_no,
                                    BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_PVLAN_PORT_MEMBERS_GET);
    rapireq.var.pvlan_port_members_get.pvlan_no = pvlan_no;
    
    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;
    
    memcpy(member, rapireq.var.pvlan_port_members_get.member,  
           sizeof(rapireq.var.pvlan_port_members_get.member));

    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_pvlan_port_members_set(
    const vtss_pvlan_no_t pvlan_no,
    const BOOL            member[VTSS_PORT_ARRAY_SIZE])
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_PVLAN_PORT_MEMBERS_SET);
    rapireq.var.pvlan_port_members_set.pvlan_no = pvlan_no;
    memcpy(rapireq.var.pvlan_port_members_set.member, member, 
           sizeof(rapireq.var.pvlan_port_members_set.member));

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_isolated_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{


    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_ISOLATED_PORTS_SET);
    memcpy(rapireq.var.isolated_ports_set.member, member, 
           sizeof(rapireq.var.isolated_ports_set.member));

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

#if defined(VTSS_FEATURE_ISOLATED_PORT)
vtss_rc vtss_isolated_vlan_set(const vtss_vid_t vid,
                               const BOOL       isolated)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_ISOLATED_VLAN_SET);
    rapireq.var.isolated_vlan_set.vid = vid;
    rapireq.var.isolated_vlan_set.isolated = isolated;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}
#endif /* VTSS_FEATURE_ISOLATED_PORT */

#if defined(VTSS_FEATURE_MAC_AGE_AUTO)
vtss_rc vtss_mac_table_age_time_set(const vtss_mac_age_time_t age_time)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_MAC_TABLE_AGE_TIME_SET);
    rapireq.var.mac_table_age_time_set.age_time = age_time;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}
#endif /* VTSS_FEATURE_MAC_AGE_AUTO */

vtss_rc vtss_mac_table_learn(const vtss_mac_table_entry_t * const entry)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_MAC_TABLE_LEARN);
    rapireq.var.mac_table_learn.entry = *entry;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_mac_table_forget_vid_mac(const vtss_vid_mac_t * const vid_mac)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_MAC_TABLE_FORGET_VID_MAC);
    rapireq.var.mac_table_forget_vid_mac.vid_mac = *vid_mac;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_mac_table_get_next(const vtss_vid_mac_t * const   vid_mac,
                                vtss_mac_table_entry_t * const entry)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_MAC_TABLE_GET_NEXT);
    rapireq.var.mac_table_get_next.vid_mac = *vid_mac;

    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;

    /* Copyout results */
    *entry = rapireq.var.mac_table_get_next.entry;

    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_mac_table_lookup(const vtss_vid_mac_t * const vid_mac,
                              vtss_mac_table_entry_t * const entry)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_MAC_TABLE_LOOKUP);
    rapireq.var.mac_table_lookup.vid_mac = *vid_mac;

    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;

    /* Copyout results */
    *entry = rapireq.var.mac_table_get_next.entry;

    /* Return result */
    return rapireq.rc;
}

vtss_rc vtss_mac_table_flush(void)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_MAC_TABLE_FLUSH);

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}


vtss_rc vtss_igmp_set_mode(BOOL *mode)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_IGMP_MODE_SET);
    rapireq.var.igmp_mode_set.mode = *mode;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}

vtss_rc vtss_igmp_get_mode(BOOL *mode)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_IGMP_MODE_GET);
    
    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;
    
    *mode = rapireq.var.igmp_mode_get.mode;

    /* Return result */
    return rapireq.rc;    
}


vtss_rc vtss_igmp_set_unreg_flood(BOOL *mode)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_IGMP_UNREG_FLOOD_SET);
    rapireq.var.igmp_unreg_flood_set.mode = *mode;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}


vtss_rc vtss_igmp_get_unreg_flood(BOOL *mode)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_IGMP_UNREG_FLOOD_GET);
    
    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;
    
    *mode = rapireq.var.igmp_unreg_flood_get.mode;

    /* Return result */
    return rapireq.rc;    

}


vtss_rc vtss_igmp_set_fast_leave_port(vtss_igmp_fast_leave_port_t *fast_leave_port)
{
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_IGMP_FAST_LEAVE_PORT_SET);
    rapireq.var.igmp_fast_leave_port_set.fast_leave_port = *fast_leave_port;

    /* Execute, return result */
    return vtss_rapi_exec(&rapireq, size);
}


vtss_rc vtss_igmp_get_fast_leave_port(vtss_igmp_fast_leave_port_t *fast_leave_port)
{    
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_IGMP_FAST_LEAVE_PORT_GET);
    
    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;
    
    *fast_leave_port = rapireq.var.igmp_fast_leave_port_get.fast_leave_port;

    /* Return result */
    return rapireq.rc;      
    
}


vtss_rc vtss_igmp_get_vlan_info (ushort vid, vtss_igmp_vid_stat_entry_t *vid_entry)
{    
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_IGMP_VLAN_INFO_GET);
    
    rapireq.var.igmp_vlan_info_get.vid = vid;
    
    /* Execute */
    if(VTSS_OK != vtss_rapi_exec(&rapireq, size))
        return rapireq.rc;
    
    *vid_entry = rapireq.var.igmp_vlan_info_get.vid_entry;
    /* Return result */
    return rapireq.rc;      
    
}

vtss_rc vtss_igmp_clear_stat_counter (void)
{    
    /* Setup request */
    size_t size = vtss_rapi_initmsg(&rapireq, RAPI_MSG_IGMP_CLEAR_STAT_COUNTER);
    
    /* Execute */
    return vtss_rapi_exec(&rapireq, size);  
    
}


/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
