/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/

/*
 * This file describe the board-dependent functions for the switch application
 */

#ifndef _VTSS_APPL_H_

#include "vtss_appl_api.h"    /* for vtss_appl_port_conf_t */

#define ARR_SZ(a)	(sizeof(a)/sizeof(a[0]))

typedef enum {
    VTSS_LINKEVENT_UP,  /* Link Went Up */
    VTSS_LINKEVENT_DOWN  /* Link Went Down */
} vtss_linkevent_t;

typedef struct vtss_board {
    /*
     * Mandatory to fill int by vtss_board_hookup()
     */
    const char		*name;  /* Board name */
    vtss_mapped_port_t	*port_map; /* Board port map */
    /* 1st level init - connect CPU if */
    void		(*connect)(int argc, const char **argv, vtss_io_state_t *io);

    /*
     * Rest is optional!
     */
    /* Called before vtss_init_setup() - can change *setup */
    void 		(*init_setup_hook)(int argc, const char **argv, vtss_init_setup_t *setup);
    /* 2nd level init - Called before port reset */
    void		(*init)(int argc, const char **argv);
    /* After port reset - start running */
    void 		(*startup)(void);
    /* Called each tick */
    void 		(*run)(void);
    /* Called upon linkevents detected */
    void		(*linkevent)(vtss_linkevent_t event, vtss_port_no_t port_no);
    /* Called to update port LED's */
    void		(*port_led_update)(vtss_port_no_t port_no, vtss_port_status_t *port_status, BOOL act_update);
    /* Called for additional PHY reset - *after* vtss_phy_reset() */
    void 		(*phy_reset)(vtss_port_no_t port_no);
    /* Override vtss_port_setup() */
    void		(*port_setup)(vtss_port_no_t port_no, vtss_port_setup_t * const setup);
    /* Return mac interface type for a port */
    vtss_port_interface_t (*port_mac_interface)(vtss_port_no_t port_no);
    /* - Router support - */
    /* Return whether a port is a router interface */
    BOOL		(*router_port)(vtss_port_no_t port_no);
    /* Set up a router interface 
     * - can modify *pc 
     * - called before port_setup()
     */
    void		(*router_port_setup)(vtss_port_no_t port_no, vtss_appl_port_conf_t *pc);
} vtss_board_t;

extern void vtss_board_hookup(struct vtss_board *board, int argc, const char **argv);

#define _VTSS_APPL_H_
#endif /* _VTSS_APPL_H_ */
