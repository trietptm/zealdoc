/*

 Vitesse Switch/PHY API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_os.h,v 1.82 2008/09/04 14:41:09 lpovlsen Exp $
 $Revision: 1.82 $

*/

#ifndef _VTSS_COMMON_H_
#define _VTSS_COMMON_H_

/* Get the vtss_rc error type and error codes */
#include "vtss_errors.h"

/* ================================================================= *
 *  Basic types:
 *    uint, ulong, ushort, uchar - unsigned standard types.
 *    longlong, ulonglong - 64 bit integers.
 *    BOOL - The boolean type. false: 0, true: anything but 0.
 * ================================================================= */

/* - uint, ulong, ushort ------------------------------------------- */

#if (_POSIX_C_SOURCE > 0)
#include <sys/types.h>
#endif
#if defined(_SYS_TYPES_H) && defined(__USE_MISC)
/* uint, ulong, ushort already typedef'd in <sys/types.h>. */
#else
typedef unsigned int        uint;
typedef unsigned long       ulong;
typedef unsigned short      ushort;
#endif /* _SYS_TYPES_H && __USE_MISC */

/* - uchar, schar -------------------------------------------------- */

typedef unsigned char       uchar;
typedef signed char         schar;

/* - longlong, ulonglong ------------------------------------------- */

/* longlong and ulonglong: 64 bit integers */
#ifdef __GNUC__
typedef long long           longlong;
typedef unsigned long long  ulonglong;
#endif /* __GNUC__ */
#ifdef _MSC_VER
typedef __int64             longlong;
typedef unsigned __int64    ulonglong;
#endif /* _MSC_VER */

/* - BOOL ---------------------------------------------------------- */

/* BOOL: The boolean type. false: 0, true: anything but 0. */
/* You may redefine it to any other type, e.g. int. */
typedef unsigned char                 BOOL;


/* ================================================================= *
 *  Custom types
 * ================================================================= */

/* Big counter type, may be 32 or 64 bits depending on the OS */
/* You may redefine it to ulong or ulonglong */
typedef ulonglong vtss_counter_t;


/* ================================================================= *
 * Endianess 
 * ================================================================= */
ulong vtss_htonl(const ulong hostlong);
ulong vtss_ntohl(const ulong netlong);
uint  vtss_htons(const uint  hostshort);
uint  vtss_ntohs(const uint  netshort);

/* ================================================================= *
 *  Macros:
 *    VTSS_ASSERT(expr) - Call assert(expr).
 *    VTSS_NSLEEP(nsec) - Sleep at least nsec nanoseconds.
 *    VTSS_MSLEEP(msec) - Sleep at least msec milliseconds.
 *  Notes:
 *    VTSS_NSLEEP uses busy waiting, so it should only be used for
 *    very short intervals.
 *    VTSS_MSLEEP should not use busy waiting, but may do so.
 * ================================================================= */

/* - VTSS_ASSERT(expr) -------------------------------------------------- */

/* VTSS_ASSERT(expr): Call assert(). */
#if !defined(VTSS_ASSERT)
/* You may define your own VTSS_ASSERT here. */
#endif

#if !defined(VTSS_ASSERT) && defined(VTSS_OPSYS_ECOS)
#include <cyg/infra/cyg_ass.h>
/* Allow for assertion-is-going-to-fail callback. */
typedef void (*vtss_common_assert_cb_t)(const char *file_name, const unsigned long line_num, const char *msg);
extern vtss_common_assert_cb_t vtss_common_assert_cb;
void vtss_common_assert_cb_set(vtss_common_assert_cb_t cb);

/* Note, that the vtss_common_assert_cb() function will be called whether or
   not the image is compiled assertions enabled. */
#define VTSS_COMMON_ASSERT_CB(expr) {if(vtss_common_assert_cb && !(expr)) vtss_common_assert_cb(__FILE__, __LINE__, "Assertion failed");}
/* Trying hard to avoid expr to be evaluated twice (which may cause side effects if it's a function call for instance, or a register read with read-side-effects). */
#define VTSS_ASSERT(expr) {if(!(expr)) {VTSS_COMMON_ASSERT_CB(0); CYG_ASSERT(0, "Assertion failed"); }}
#endif

#if !defined(VTSS_ASSERT) && (_POSIX_C_SOURCE > 0)
#include <assert.h>
#define VTSS_ASSERT(expr) { assert(expr); }
#endif

/* - VTSS_NSLEEP(nsec) -------------------------------------------------- */

/* VTSS_NSLEEP(nsec): Sleep nsec nanoseconds. Use busy waiting. */
#if !defined(VTSS_NSLEEP)
/* You may define your own VTSS_NSLEEP here. */
#endif

#if !defined(VTSS_NSLEEP) && defined(VTSS_OPSYS_ECOS)
#include <cyg/hal/hal_diag.h>   /* Sorry - this is where it lives... */
#define VTSS_NSLEEP(nsec) HAL_DELAY_US(nsec/100)
#endif
#if !defined(VTSS_NSLEEP) && defined(_BSD_SOURCE)
/* The function "gettimeofday" is available, so use it. */
#include <sys/time.h>
#define VTSS_NSLEEP(nsec) { \
    struct timeval tve, tv; \
    gettimeofday(&tve,NULL); \
    tve.tv_usec+=(nsec+999)/1000;\
    if (tve.tv_usec>=1000000) { tve.tv_sec+=tve.tv_usec/1000000; tve.tv_usec%=1000000; } \
    do { gettimeofday(&tv,NULL); } \
    while ( timercmp(&tv,&tve,<) ); \
}
#endif /* _BSD_SOURCE */
#if !defined(VTSS_NSLEEP) && ( (_POSIX_C_SOURCE - 0) >= 199309L )
/* The function "nanosleep" is available, so use it. */
#include <time.h>
#include <errno.h>
#define VTSS_NSLEEP(nsec) {struct timespec ts = { 0, nsec }; while (nanosleep(&ts,&ts)==-1 && errno==EINTR) ;}
#endif /* (_POSIX_C_SOURCE - 0) >= 199309L */
#if !defined(VTSS_NSLEEP) && defined(_WIN32)
#define VTSS_NSLEEP(nsec) {VOID Sleep(DWORD); Sleep((nsec+999999)/1000000);}
#endif /* _WIN32 */

/* VTSS_NSLEEP is required by the API. */
#if defined(__VTSS_LIBRARY__) && !defined(VTSS_NSLEEP)
#error Macro function VTSS_NSLEEP must be defined in vtss_common.h.
#endif /* __VTSS_LIBRARY__ && !VTSS_NSLEEP */

/* - VTSS_MSLEEP(msec) -------------------------------------------------- */

/* VTSS_MSLEEP(msec): Sleep msec milliseconds. Avoid busy waiting. */
#if !defined(VTSS_MSLEEP)
/* You may define your own VTSS_MSLEEP here. */
#endif

#if !defined(VTSS_MSLEEP) && defined(VTSS_OPSYS_ECOS)
#define ECOS_MSECS_PER_HWTICK	(1000 / CYGNUM_HAL_RTC_DENOMINATOR)
#define ECOS_HWCLOCKS_PER_MSEC	(CYGNUM_HAL_RTC_PERIOD / ECOS_MSECS_PER_HWTICK)
#define VTSS_MSLEEP(msec)	cyg_thread_delay((msec*CYGNUM_HAL_RTC_DENOMINATOR)/1000)
#endif
#if !defined(VTSS_MSLEEP) && ( (_POSIX_C_SOURCE - 0) >= 199309L )
/* The function "nanosleep" is available, so use it. */
#include <time.h>
#include <errno.h>
#define VTSS_MSLEEP(msec) { \
    struct timespec ts; \
    ts.tv_sec = msec/1000; \
    ts.tv_nsec = (msec%1000)*1000000; \
    while (nanosleep(&ts,&ts)==-1 && errno==EINTR) ; \
}
#endif /* (_POSIX_C_SOURCE - 0) >= 199309L */
#if !defined(VTSS_MSLEEP) && defined(_WIN32)
#define VTSS_MSLEEP(msec) { Sleep(msec);}
#endif /* _WIN32 */

/* VTSS_MSLEEP is required by the API. */
#if defined(__VTSS_LIBRARY__) && !defined(VTSS_MSLEEP)
#error Macro function VTSS_MSLEEP must be defined in vtss_common.h.
#endif /* __VTSS_LIBRARY__ && !VTSS_MSLEEP */


/* ================================================================= *
 *  Timers
 * ================================================================= *
 *  Type declarations:
 *    vtss_mtimer_t - Millisecond timer type.
 *  Macros:
 *    VTSS_MTIMER_START(&timer,msec) - Start timer of msec milliseconds.
 *    VTSS_MTIMER_TIMEOUT(&timer) - Returns TRUE if timer timed out.
 *    VTSS_MTIMER_CANCEL(&timer) - Cancel the timer.
 *  Usage Example:
 *    vtss_mtimer_t t;
 *    int i = 1;
 *    VTSS_MTIMER_START(&t,1000);
 *    while (!VTSS_MTIMER_TIMEOUT(&t)) {
 *        VTSS_MSLEEP(200);
 *        printf("loop %d\n",i);
 *        if (i++>=10) {
 *            printf("break\n");
 *            VTSS_MTIMER_CANCEL(&t);
 *            return;
 *        }
 *    }
 *    printf("done\n");
 *  Notes:
 *    Before a running timer is deallocated, VTSS_MTIMER_CANCEL()
 *    must be called, to make sure that no pointers in the O/S are
 *    pointing to the timer being deallocated.
 *    It is harmless calling VTSS_MTIMER_CANCEL() with a timer which
 *    has already timed out.
 * ================================================================= */

#if !defined(VTSS_MTIMER_START)
/* You may type define your own vtss_mtimer_t here. */
/* You may define your own VTSS_MTIMER_START here. */
/* You may define your own VTSS_MTIMER_TIMEOUT here. */
/* You may define your own VTSS_MTIMER_CANCEL here. */
#endif

#if !defined(VTSS_MTIMER_START) && defined(VTSS_OPSYS_ECOS)
#include <cyg/kernel/kapi.h>
typedef cyg_tick_count_t vtss_mtimer_t;
#define VTSS_MTIMER_START(pTimer,msec)	*pTimer = cyg_current_time() + (msec/10) + 1
#define VTSS_MTIMER_TIMEOUT(pTimer)	(cyg_current_time() > *pTimer)
#define VTSS_MTIMER_CANCEL(pTimer)	/* No action in this implementation. */
#endif
#if !defined(VTSS_MTIMER_START) && defined(_BSD_SOURCE)
/* The function "gettimeofday" is available, so use it. */
#include <sys/time.h>

typedef struct _vtss_mtimer_t {
    struct timeval  timeout;
    struct timeval  now;
} vtss_mtimer_t;

#define VTSS_MTIMER_START(timer,msec) { \
    gettimeofday(&((timer)->timeout),NULL); \
    (timer)->timeout.tv_usec+=msec*1000; \
    if ((timer)->timeout.tv_usec>=1000000) { (timer)->timeout.tv_sec+=(timer)->timeout.tv_usec/1000000; (timer)->timeout.tv_usec%=1000000; } \
}

#define VTSS_MTIMER_TIMEOUT(timer) (gettimeofday(&((timer)->now),NULL)==0 && timercmp(&((timer)->now),&((timer)->timeout),>))

#define VTSS_MTIMER_CANCEL(timer) /* No action in this implementation. */
#endif /* _BSD_SOURCE */

/* VTSS_MTIMER_START is required by the API. */
#if defined(__VTSS_LIBRARY__) && !defined(VTSS_MTIMER_START)
#error Type vtss_mtimer_t and macro functions VTSS_MTIMER_START and VTSS_MTIMER_TIMEOUT must be defined in vtss_common.h.
#endif /* __VTSS_LIBRARY__ && !VTSS_MTIMER_START */


/* ================================================================= *
 *  Semaphores
 * ================================================================= *
 *  Type declarations:
 *    vtss_os_sem_t - Semaphore type.
 *  Macros:
 *    VTSS_OS_SEM_CREATE(&sem,count) - Create semaphore with count.
 *    VTSS_OS_SEM_DESTROY(&sem) - Destroy semaphore.
 *    VTSS_OS_SEM_WAIT(&sem) - Acquire the semaphore.
 *    VTSS_OS_SEM_POST(&sem) - Release the semaphore.
 *  Usage Example:
 *    //Initialization:
 *    vtss_os_sem_t s;
 *    int i=0;
 *    VTSS_OS_SEM_CREATE(&s,1);
 *    //Use the semaphore to protect a critical region:
 *    VTSS_OS_SEM_WAIT(&s);
 *    i+=1;
 *    VTSS_OS_SEM_POST(&s);
 *    printf("done\n");
 *    //Deallocation:
 *    VTSS_OS_SEM_DESTROY(&s);
 *  Notes:
 *    When the semaphore is created, it is initialized to its count.
 *    When the semaphore is destroyed, no thread may be waiting for
 *    it.
 * ================================================================= */

#if !defined(VTSS_OS_SEM_CREATE)
/* You may type define your own vtss_os_sem_t here. */
/* You may define your own VTSS_OS_SEM_CREATE here. */
/* You may define your own VTSS_OS_SEM_DESTROY here. */
/* You may define your own VTSS_OS_SEM_WAIT here. */
/* You may define your own VTSS_OS_SEM_POST here. */
#endif

#if !defined(VTSS_OS_SEM_CREATE) && ( (_POSIX_C_SOURCE - 0) >= 199309L )
#include <semaphore.h>
typedef sem_t vtss_os_sem_t;
#define VTSS_OS_SEM_CREATE(sem,count) sem_init(sem,0/*not shared between processes*/,count)
#define VTSS_OS_SEM_DESTROY(sem) { sem_destroy(sem); *sem=(vtss_os_sem_t)NULL; }
#define VTSS_OS_SEM_WAIT(sem) sem_wait(sem)
#define VTSS_OS_SEM_POST(sem) sem_post(sem)
#endif /* (_POSIX_C_SOURCE - 0) >= 199309L */

#if !defined(VTSS_OS_SEM_CREATE) && defined(_WIN32)
DECLARE_HANDLE(vtss_os_sem_t);
#define VTSS_OS_SEM_CREATE(sem,count) { const int c=count; *sem=CreateSemaphore(NULL/*not inherited by child processes*/,c,c,NULL/*no name*/); }
#define VTSS_OS_SEM_DESTROY(sem) { CloseHandle(*sem); *sem=(vtss_os_sem_t)NULL; }
#define VTSS_OS_SEM_WAIT(sem) WaitForSingleObject(*sem,INFINITE)
#define VTSS_OS_SEM_POST(sem) ReleaseSemaphore(*sem,1/*release one*/,NULL)
#endif /* _WIN32 */

#if !defined(VTSS_OS_SEM_CREATE) && defined(VTSS_OPSYS_ECOS)
#include <cyg/kernel/kapi.h>
typedef cyg_sem_t vtss_os_sem_t;
#define VTSS_OS_SEM_CREATE(sem, count) cyg_semaphore_init(sem, count)
#define VTSS_OS_SEM_DESTROY(sem)       cyg_semaphore_destroy(sem)
#define VTSS_OS_SEM_WAIT(sem)          cyg_semaphore_wait(sem)
#define VTSS_OS_SEM_POST(sem)          cyg_semaphore_post(sem)
#define VTSS_OS_SEM_PEEK(sem, count)   cyg_semaphore_peek(sem, count)
#endif /* VTSS_OPSYS_ECOS */

/* VTSS_OS_SEM_CREATE is required by the API. */
#if defined(__VTSS_LIBRARY__) && !defined(VTSS_OS_SEM_CREATE)
#error Type vtss_os_sem_t and macro functions VTSS_OS_SEM_CREATE, VTSS_OS_SEM_DESTROY, VTSS_OS_SEM_WAIT and VTSS_OS_SEM_POST must be defined in vtss_common.h.
#endif /* __VTSS_LIBRARY__ && !VTSS_MSLEEP */

/* ================================================================= *
 *  Various definitions and macros
 * ================================================================= */

/* MAKEBOOL01(value): Convert BOOL value to 0 (false) or 1 (true). */
/* Use this to ensure BOOL values returned are always 1 or 0. */
#ifndef MAKEBOOL01
#define MAKEBOOL01(value) ((value)?1:0)
#endif

/* Event type. When a variable of this type is used as an input parameter,
   the API will set the variable if the event has occured. The API will 
   never clear the variable. If is up to the application to clear the
   variable, when the event has been handled. */
typedef BOOL vtss_event_t;

/* - Basic defines/macros: NULL, offsetof() ------------------------ */

#ifndef NULL
#ifdef __cplusplus
#define NULL 0
#else
#define NULL ((void *)0)
#endif
#endif

#ifndef offsetof
#define offsetof(TYPE, MEMBER) ((size_t) &((TYPE *)0)->MEMBER)
#endif

/* - Compiler Hints ------------------------------------------------ */

#ifdef __GNUC__
/* "__attribute__ ((const))" informs the GNU C compiler that a
 * function does not change any states anywhere
 */
#define __VTSS_ATTRIB_CONST_FUNCTION__ __attribute__ ((const))
#else
#define __VTSS_ATTRIB_CONST_FUNCTION__ /* no "const" compiler hint */
#endif

#ifdef __GNUC__
/* "__attribute__ ((unused))" informs the GNU C compiler that a
 * function is not used, so we don't get a warning about it
 */
#define __VTSS_ATTRIB_UNUSED_FUNCTION__ __attribute__ ((unused))
#else
#define __VTSS_ATTRIB_UNUSED_FUNCTION__ /* no "unused" compiler hint */
#endif

/* ================================================================= *
 *  Private data and functions (used internally by VTSS library)
 * ================================================================= */
#ifdef __VTSS_LIBRARY__

/* - Compiler Hints ------------------------------------------------ */

#ifdef __GNUC__
/* "__attribute__ ((unused))" informs the GNU C compiler that a
 * variable is not used, so we don't get a warning about it
 */
#define __VTSS_ATTRIB_UNUSED_VARIABLE__ __attribute__ ((unused))
#else
#define __VTSS_ATTRIB_UNUSED_VARIABLE__ /* no "unused" compiler hint */
#endif

#endif /* __VTSS_LIBRARY__ */

#endif /* _VTSS_COMMON_H_ */

