/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>

#include "vtss_rapi.h"

static     int udpSocket;
struct sockaddr_in 
    serverName = { 0 }, 
    clientName = { 0 };

static vtss_rapi_msg msg;
static const int const_int_1 = 1;

int vtss_rapi_init(void)
{
    int myPort = PORT;

    if((udpSocket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
        perror("socket()");
        return -1;
    }

    if(setsockopt(udpSocket, SOL_SOCKET, SO_REUSEADDR, &const_int_1, sizeof(const_int_1)))
        perror("setsockopt()");

    memset(&serverName, 0, sizeof(serverName));
    memset(&clientName, 0, sizeof(clientName));
    
    serverName.sin_family = AF_INET;
    serverName.sin_addr.s_addr = htonl(INADDR_ANY);
    serverName.sin_port = htons(myPort);
        
    if(bind(udpSocket, (struct sockaddr *) &serverName, sizeof(serverName)) == -1) {
        perror("bind()");
        return -1;
    }

    return 0;
}

static vtss_rc
vtss_rapi_handle_request(vtss_rapi_msg *pm)
{
    vtss_rc rc = -1;
    /* fprintf(stderr, "server: req %d dispatch\n", pm->req); */
    switch(pm->req) {
    case RAPI_MSG_APPL_PORT_STATUS_GET:
        rc = vtss_appl_port_status_get(pm->var.appl_port_status_get.port_no,
                                       &pm->var.appl_port_status_get.status);
        break;
    case RAPI_MSG_APPL_PORT_CONF_GET:
        rc = vtss_appl_port_conf_get(pm->var.appl_port_conf_get.port_no,
                                     &pm->var.appl_port_conf_get.conf);
        break;
    case RAPI_MSG_APPL_PORT_CONF_SET:
        rc = vtss_appl_port_conf_set(pm->var.appl_port_conf_set.port_no,
                                     &pm->var.appl_port_conf_set.conf);

    case RAPI_MSG_APPL_GROCX_PORT_MAP_GET:
        rc = vtss_appl_grocx_port_map_get(pm->var.appl_grocx_port_map_get.port_no,
                                       &pm->var.appl_grocx_port_map_get.map);

        break;
    case RAPI_MSG_PORT_STATUS_GET:
        rc = vtss_port_status_get(pm->var.port_status_get.port_no,
                                  &pm->var.port_status_get.status);
        break;
    case RAPI_MSG_PORT_SETUP:
        rc =  vtss_port_setup(pm->var.port_setup.port_no,
                              &pm->var.port_setup.setup);
        break;
    case RAPI_MSG_POAG_COUNTERS_GET:
        rc =  vtss_poag_counters_get(pm->var.poag_counters_get.poag_no,
                                     &pm->var.poag_counters_get.counters);
        break;
    case RAPI_MSG_POAG_COUNTERS_CLEAR:
        rc =  vtss_poag_counters_clear(pm->var.poag_counters_clear.poag_no);
        break;
    case RAPI_MSG_PHY_SETUP:
        rc = vtss_phy_setup(pm->var.phy_setup.port_no,
                            &pm->var.phy_setup.setup);
        break;
#if defined(VTSS_FEATURE_ACL)
    case RAPI_MSG_ACL_POLICY_NO_SET:
        rc = vtss_acl_policy_no_set(pm->var.acl_policy_no_set.port_no,
                                    pm->var.acl_policy_no_set.policy_no);
        break;
    case RAPI_MSG_ACL_PORT_ACTION_SET:
        rc = vtss_acl_port_action_set(pm->var.acl_port_action_set.port_no,
                                      &pm->var.acl_port_action_set.action);
        break;
    case RAPI_MSG_ACL_POLICER_RATE_SET:
        rc = vtss_acl_policer_rate_set(pm->var.acl_policer_rate_set.policer_no,
                                       pm->var.acl_policer_rate_set.rate);
        break;
    case RAPI_MSG_ACL_PORT_COUNTER_GET:
        rc = vtss_acl_port_counter_get(pm->var.acl_port_counter_get.port_no,
                                       &pm->var.acl_port_counter_get.counter);
        break;
    case RAPI_MSG_ACL_PORT_COUNTER_CLEAR:
        rc = vtss_acl_port_counter_clear(pm->var.acl_port_counter_clear.port_no);
        break;
    case RAPI_MSG_ACE_INIT:
        rc = vtss_ace_init(pm->var.ace_init.type, &pm->var.ace_init.ace);
        break;
    case RAPI_MSG_ACE_ADD:
        rc = vtss_ace_add(pm->var.ace_add.ace_id, &pm->var.ace_add.ace);
        break;
    case RAPI_MSG_ACE_DEL:
        rc = vtss_ace_del(pm->var.ace_del.ace_id);
        break;
    case RAPI_MSG_ACE_COUNTER_GET:
        rc = vtss_ace_counter_get(pm->var.ace_counter_get.ace_id,
                                  &pm->var.ace_counter_get.counter);
        break;
    case RAPI_MSG_ACE_COUNTER_CLEAR:
        rc = vtss_ace_counter_clear(pm->var.ace_counter_clear.ace_id);
        break;
#endif /* VTSS_FEATURE_ACL */
#if defined(VTSS_FEATURE_QCL_PORT)
    case RAPI_MSG_QCE_ADD:
        rc = vtss_qce_add(pm->var.qce_add.qcl_id,
                          pm->var.qce_add.qce_id,
                          &pm->var.qce_add.qce);
        break;
    case RAPI_MSG_QCE_DEL:
        rc = vtss_qce_del(pm->var.qce_del.qcl_id,
                          pm->var.qce_del.qce_id);
        break;
#endif /* VTSS_FEATURE_QCL_PORT */
    case RAPI_MSG_QOS_SETUP_GET:
        rc = vtss_qos_setup_get(&pm->var.qos_setup_get.qos);
        break;
    case RAPI_MSG_QOS_SETUP_SET:
        rc = vtss_qos_setup_set(&pm->var.qos_setup_set.qos);
        break;
    case RAPI_MSG_QOS_PRIOS_SET:
        rc = vtss_qos_prios_set(pm->var.qos_prios_set.prios);
        break;
    case RAPI_MSG_PORT_QOS_GET:
        rc = vtss_port_qos_get(pm->var.port_qos_get.port_no,
                               &pm->var.port_qos_get.qos);
        break;
    case RAPI_MSG_PORT_QOS_SET:
        rc = vtss_port_qos_set(pm->var.port_qos_set.port_no,
                               &pm->var.port_qos_set.qos);
        break;
    case RAPI_MSG_VLAN_PORT_MODE_GET:
        rc = vtss_vlan_port_mode_get(pm->var.vlan_port_mode_get.port_no,
                                     &pm->var.vlan_port_mode_get.vlan_mode);
        break;
    case RAPI_MSG_VLAN_PORT_MODE_SET:
        rc = vtss_vlan_port_mode_set(pm->var.vlan_port_mode_set.port_no,
                                     &pm->var.vlan_port_mode_set.vlan_mode);
        break;
    case RAPI_MSG_VLAN_PORT_MEMBERS_GET:
        rc = vtss_vlan_port_members_get(pm->var.vlan_port_members_get.vid,
                                        pm->var.vlan_port_members_get.member);
        break;
    case RAPI_MSG_VLAN_PORT_MEMBERS_SET:
        rc = vtss_vlan_port_members_set(pm->var.vlan_port_members_set.vid,
                                        pm->var.vlan_port_members_set.member);
        break;
    case RAPI_MSG_PVLAN_PORT_MEMBERS_GET:
        fprintf(stderr, "RAPI_MSG_PVLAN_PORT_MEMBERS_GET.\n"); 
        rc = vtss_pvlan_port_members_get(pm->var.pvlan_port_members_get.pvlan_no,
                                        pm->var.pvlan_port_members_get.member);
        break;
    case RAPI_MSG_PVLAN_PORT_MEMBERS_SET:
        rc = vtss_pvlan_port_members_set(pm->var.pvlan_port_members_set.pvlan_no,
                                        pm->var.pvlan_port_members_set.member);
        break;
    case RAPI_MSG_ISOLATED_PORTS_SET:
        rc = vtss_isolated_ports_set(pm->var.isolated_ports_set.member);
        break;
#if defined(VTSS_FEATURE_ISOLATED_PORT)
    case RAPI_MSG_ISOLATED_VLAN_SET:
        rc = vtss_isolated_vlan_set(pm->var.isolated_vlan_set.vid,
                                    pm->var.isolated_vlan_set.isolated);
        break;
#endif /* VTSS_FEATURE_ISOLATED_PORT */
#if defined(VTSS_FEATURE_MAC_AGE_AUTO)
    case RAPI_MSG_MAC_TABLE_AGE_TIME_SET:
        rc = vtss_mac_table_age_time_set(pm->var.mac_table_age_time_set.age_time);
        break;
#endif /* VTSS_FEATURE_MAC_AGE_AUTO */
    case RAPI_MSG_MAC_TABLE_LEARN:
        rc = vtss_mac_table_learn(&pm->var.mac_table_learn.entry);
        break;
    case RAPI_MSG_MAC_TABLE_FORGET_VID_MAC:
        rc = vtss_mac_table_forget_vid_mac(&pm->var.mac_table_forget_vid_mac.vid_mac);
        break;
    case RAPI_MSG_MAC_TABLE_GET_NEXT:
        rc = vtss_mac_table_get_next(&pm->var.mac_table_get_next.vid_mac,
                                     &pm->var.mac_table_get_next.entry);
        break;
    case RAPI_MSG_MAC_TABLE_LOOKUP:
        rc = vtss_mac_table_lookup(&pm->var.mac_table_lookup.vid_mac,
                                   &pm->var.mac_table_lookup.entry);
        break;
    case RAPI_MSG_MAC_TABLE_FLUSH:
        rc = vtss_mac_table_flush();
        break;
    case RAPI_MSG_IGMP_MODE_SET:
        rc = vtss_igmp_set_mode(&pm->var.igmp_mode_set.mode);
        break;        
    case RAPI_MSG_IGMP_MODE_GET:
        rc = vtss_igmp_get_mode(&pm->var.igmp_mode_get.mode);
        break;
    case RAPI_MSG_IGMP_UNREG_FLOOD_SET:
        rc = vtss_igmp_set_unreg_flood(&pm->var.igmp_unreg_flood_set.mode);
        break;
    case RAPI_MSG_IGMP_UNREG_FLOOD_GET:
        rc = vtss_igmp_get_unreg_flood(&pm->var.igmp_unreg_flood_get.mode);
        break;
    case RAPI_MSG_IGMP_FAST_LEAVE_PORT_SET:
        rc = vtss_igmp_set_fast_leave_port(&pm->var.igmp_fast_leave_port_set.fast_leave_port);
        break; 
    case RAPI_MSG_IGMP_FAST_LEAVE_PORT_GET:
        rc = vtss_igmp_get_fast_leave_port(&pm->var.igmp_fast_leave_port_set.fast_leave_port);
        break;
    case RAPI_MSG_IGMP_VLAN_INFO_GET:
        rc = vtss_igmp_get_vlan_info(pm->var.igmp_vlan_info_get.vid, &pm->var.igmp_vlan_info_get.vid_entry);
        break;
    case RAPI_MSG_IGMP_CLEAR_STAT_COUNTER:
        rc = vtss_igmp_clear_stat_counter();
        break;
    default:
        rc = VTSS_NOT_IMPLEMENTED;
    }
    /* fprintf(stderr, "server: req %d rc %d\n", pm->req, rc); */
    return rc;
}

void vtss_rapi_poll(void)
{
    size_t clientLength = sizeof(struct sockaddr_in);
    fd_set rfd,wfd,efd;
    struct timeval tv;
    size_t size;

    FD_ZERO(&rfd);
    FD_ZERO(&wfd);
    FD_ZERO(&efd);
    FD_SET(udpSocket, &rfd);
    tv.tv_sec = 0;
    tv.tv_usec = 500;

    if (select(udpSocket+1, &rfd, &wfd, &efd, &tv) <= 0 || errno == EINTR)
        return;

    if((size = recvfrom(udpSocket, &msg,
                        sizeof(msg), 0,
                        (struct sockaddr *) &clientName,
                        &clientLength)) == -1){
        perror("recvfrom()");
        return;
    }

#if 0
    fprintf(stderr, "server: received %d bytes (%d) %s:%d\n", 
            size, clientLength,
            inet_ntoa(clientName.sin_addr), ntohs(clientName.sin_port));
#endif

    if(size != vtss_rapi_msgsize(msg.req)) {
        fprintf(stderr, "server: req %d length error (got %d, expected %d).\n", 
                msg.req, size, vtss_rapi_msgsize(msg.req));
        msg.rc = VTSS_PACKET_PROTOCOL_ERROR;
    } else {
        /* fprintf(stderr, "server: req %d.\n", msg.req); */
        msg.rc = vtss_rapi_handle_request(&msg);
    }

    if(sendto(udpSocket, &msg, size, 0,
              (struct sockaddr *) &clientName,
              clientLength) != size) {
        perror("sendto()");
        fprintf(stderr, "sendto(): short write.\n");
        return;
    }
}

/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
