/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_b2.c,v 1.23 2008/09/09 11:49:53 cpj Exp $
 $Revision: 1.23 $

*/

#define VTSS_TRACE_LAYER 2
#define VTSS_TRACE_FILE "ll"

/* API public headers */
#include "vtss_switch_api.h"

/* API private headers */
#include "vtss_state.h"
#include "vtss_cil.h"
#include "vtss_b2_reg.h"

/* ================================================================= *
 *  Read/write functions
 * ================================================================= */

#define VTSS_BIT(x)                  (1 << (x))
#define VTSS_BITMASK(x)              ((1 << (x)) - 1)
#define VTSS_EXTRACT_BITFIELD(x,o,w) (((x) >> (o)) & VTSS_BITMASK(w))
#define VTSS_ENCODE_BITFIELD(x,o,w)  (((x) & VTSS_BITMASK(w)) << (o))

/* Extract field from register */
#define B2F(tgt, addr, fld, value) \
VTSS_EXTRACT_BITFIELD(value, VTSS_OFF_##tgt##_##addr##_##fld, VTSS_LEN_##tgt##_##addr##_##fld)

/* Read register */
#define B2_RD(tgt, addr, port, value) \
{ \
    vtss_rc rc; \
    if ((rc = b2_rd(VTSS_TGT_##tgt, VTSS_ADDR_##tgt##_##addr, port, value))<0) \
        return rc; \
}

/* Read replicated register */
#define B2_RDX(tgt, addr, x, value) \
{ \
    vtss_rc rc; \
    if ((rc = b2_rd(VTSS_TGT_##tgt, VTSS_ADDX_##tgt##_##addr(x), 0, value))<0) \
        return rc; \
}

/* Read replicated register x,y*/
#define B2_RDXY(tgt, addr, x, y, value) \
{ \
    vtss_rc rc; \
    if ((rc = b2_rd(VTSS_TGT_##tgt, VTSS_ADDXY_##tgt##_##addr(x,y), 0, value))<0) \
        return rc; \
}

/* Write register */
#define B2_WR(tgt, addr, port, value) \
{ \
    vtss_rc rc; \
    if ((rc = b2_wr(VTSS_TGT_##tgt, VTSS_ADDR_##tgt##_##addr, port, value))<0) \
        return rc; \
}

/* Write replicated register */
#define B2_WRX(tgt, addr, x, value) \
{ \
    vtss_rc rc; \
    if ((rc = b2_wr(VTSS_TGT_##tgt, VTSS_ADDX_##tgt##_##addr(x), 0, value))<0) \
        return rc; \
}

/* Write replicated register with a mask */
#define B2_WRXM(tgt, addr, x, value, mask) \
{ \
    ulong val_tmp; \
    vtss_rc rc; \
    if ((rc = b2_rd(VTSS_TGT_##tgt, VTSS_ADDX_##tgt##_##addr(x), 0, &val_tmp))<0) \
        return rc; \
    mask = 0xFFFFFFFF^mask; \
    value = value | (val_tmp & mask); \
    if ((rc = b2_wr(VTSS_TGT_##tgt, VTSS_ADDX_##tgt##_##addr(x), 0, value))<0) \
        return rc; \
}

/* Write replicated register x,y */
#define B2_WRXY(tgt, addr, x, y, value) \
{ \
    vtss_rc rc; \
    if ((rc = b2_wr(VTSS_TGT_##tgt, VTSS_ADDXY_##tgt##_##addr(x,y), 0, value))<0) \
        return rc; \
}

/* Read register field */
#define B2_RDF(tgt, addr, fld, port, value) \
{ \
    vtss_rc rc; \
    if ((rc = b2_rdf(VTSS_TGT_##tgt, VTSS_ADDR_##tgt##_##addr, VTSS_OFF_##tgt##_##addr##_##fld, VTSS_LEN_##tgt##_##addr##_##fld, port, value))<0) \
        return rc; \
}

/* Write register field */
#define B2_WRF(tgt, addr, fld, port, value) \
{ \
    vtss_rc rc; \
    if ((rc = b2_wrf(VTSS_TGT_##tgt, VTSS_ADDR_##tgt##_##addr, VTSS_OFF_##tgt##_##addr##_##fld, VTSS_LEN_##tgt##_##addr##_##fld, port, value))<0) \
        return rc; \
}

/* Read/write register */
static vtss_rc b2_rd_wr(uint tgt, uint addr, uint port, ulong *value, BOOL read)
{
    switch (tgt) {
    case VTSS_TGT_ASM:
        if (addr < VTSS_ADDR_ASM_STAT_CFG) {
            if (VTSS_PORT_IS_1G(port))
                addr += port*VTSS_WIDTH_ASM_DEV_STATISTICS;
            else {
                VTSS_E(("illegal port for 1G target: %u", port));
                return VTSS_UNSPECIFIED_ERROR;
            }
        } else if (port) {
            VTSS_E(("non-zero port for ASM target"));
            return VTSS_UNSPECIFIED_ERROR;
        }
        break;
    case VTSS_TGT_DEV1G:
        if (VTSS_PORT_IS_1G(port))
            tgt += port;
        else {
            VTSS_E(("illegal port for 1G target: %u", port));
            return VTSS_UNSPECIFIED_ERROR;
        }
        break;
    case VTSS_TGT_DEV10G:
    case VTSS_TGT_XAUI_PHY_STAT:
        if (port == CHIP_PORT_10G_1)
            tgt += 2;
        else if (port != CHIP_PORT_10G_0) {
            VTSS_E(("illegal port for 10G target: %u", port));
            return VTSS_UNSPECIFIED_ERROR;
        }
        break;
    case VTSS_TGT_DEVCPU_ORG:
    case VTSS_TGT_DEVCPU_GCB:
    case VTSS_TGT_DSM:
    case VTSS_TGT_ANA_CL:
    case VTSS_TGT_ANA_AC:
    case VTSS_TGT_SCH:
    case VTSS_TGT_QSS:
    case VTSS_TGT_DEVSPI:
    case VTSS_TGT_FAST_REGS:
        if (port) {
            VTSS_E(("non-zero port for target: 0x%02x", tgt));
            return VTSS_UNSPECIFIED_ERROR;
        }
        break;
    default:
        VTSS_E(("illegal target: 0x%02x", tgt));
        return VTSS_UNSPECIFIED_ERROR;
    }

    VTSS_RC(vtss_io_pi_rd_wr(tgt, addr, value, read));
    if (vtss_api_state->debug_read_write) {
        VTSS_D(("%s, tgt: 0x%02x, addr: 0x%04x, value: 0x%08lx", 
               read ? "RD" : "WR", tgt, addr, *value));
    } else {
        VTSS_N(("%s, tgt: 0x%02x, addr: 0x%04x, value: 0x%08lx", 
                read ? "RD" : "WR", tgt, addr, *value));
    }
    return VTSS_OK;
}

/* Read register */
static vtss_rc b2_rd(uint tgt, uint addr, uint port, ulong *value)
{
    return b2_rd_wr(tgt, addr, port, value, 1);
}

/* Write register */
static vtss_rc b2_wr(uint tgt, uint addr, uint port, ulong value)
{
    return b2_rd_wr(tgt, addr, port, &value, 0);
}


/* Read register field */
static vtss_rc b2_rdf(uint tgt, uint addr, ulong offset, ulong length, uint port, ulong *value)
{
    VTSS_RC(b2_rd_wr(tgt, addr, port, value, 1));
    *value = VTSS_EXTRACT_BITFIELD(*value, offset, length);
    return VTSS_OK;
}

/* Write register field */
static vtss_rc b2_wrf(uint tgt, uint addr, ulong offset, ulong length, uint port, ulong value)
{
    ulong val, mask;
    
    mask = VTSS_BITMASK(length);
    if ((value & mask) != value) {
        VTSS_E(("illegal value: 0x%08lx, tgt: %u, addr: %u, offs: %lu, length: %lu, port: %u",
                value, tgt, addr, offset, length, port));
        return VTSS_UNSPECIFIED_ERROR;
    }

    VTSS_RC(b2_rd_wr(tgt, addr, port, &val, 1));
    val = ((val & ~(mask << offset)) | (value << offset));
    VTSS_RC(b2_rd_wr(tgt, addr, port, &val, 0));
    return VTSS_OK;
}



/* ================================================================= *
 *  Port Control      
 * ================================================================= */

/* PHY commands */
#define PHY_CMD_ADDRESS  0 /* 10G only */
#define PHY_CMD_WRITE    1 
#define PHY_CMD_READ_INC 2 /* NB: READ for 1G */
#define PHY_CMD_READ     3 /* 10G only */

static vtss_rc b2_miim_cmd(uint phy_cmd, uint sof, uint miim_controller,
                           uint phy_addr, uint phy_reg, ushort *data)
{
    uint  i, n;
    ulong value;

    switch (miim_controller) {
    case VTSS_MIIM_CONTROLLER_0:
        i = 0;
        break;
    case VTSS_MIIM_CONTROLLER_1:
        i = 1;
        break;
    default:
        VTSS_E(("illegal miim_controller: %d",miim_controller));
        return VTSS_INVALID_PARAMETER;
    }

    /* Set Start of frame field */
    B2_WRX(DEVCPU_GCB, MIIM_CFG, i,
           (sof << VTSS_OFF_DEVCPU_GCB_MIIM_CFG_MIIM_ST_CFG_FIELD) |
           (0x20 << VTSS_OFF_DEVCPU_GCB_MIIM_CFG_MIIM_CFG_PRESCALE));

    /* Read command is different for Clause 22 */
    if (sof == 1 && phy_cmd == PHY_CMD_READ) {
        phy_cmd = PHY_CMD_READ_INC;
    }

    B2_WRX(DEVCPU_GCB, MIIM_CMD, i,
           (1 << VTSS_OFF_DEVCPU_GCB_MIIM_CMD_MIIM_CMD_VLD) |
           (phy_addr << VTSS_OFF_DEVCPU_GCB_MIIM_CMD_MIIM_CMD_PHYAD) |
           (phy_reg << VTSS_OFF_DEVCPU_GCB_MIIM_CMD_MIIM_CMD_REGAD) |
           (*data << VTSS_OFF_DEVCPU_GCB_MIIM_CMD_MIIM_CMD_WRDATA) |
           (phy_cmd << VTSS_OFF_DEVCPU_GCB_MIIM_CMD_MIIM_CMD_OPR_FIELD));
                   
    /* Wait for access to complete */
    for (n = 0; ; n++) {
        B2_RDX(DEVCPU_GCB, MIIM_STATUS, i, &value);
        if (B2F(DEVCPU_GCB, MIIM_STATUS, MIIM_STAT_PENDING_RD, value) == 0 &&
            B2F(DEVCPU_GCB, MIIM_STATUS, MIIM_STAT_PENDING_WR, value) == 0)
            break;
        if (n == 1000) {
            VTSS_E(("miim failed, cmd: %u, addr: %u, reg: %u", phy_cmd, phy_addr, phy_reg));
            return VTSS_PHY_TIMEOUT;
        }
    }

    /* Read data */
    if (phy_cmd == PHY_CMD_READ || phy_cmd == PHY_CMD_READ_INC) {
        B2_RDX(DEVCPU_GCB, MIIM_DATA, i, &value);
        if (B2F(DEVCPU_GCB, MIIM_DATA, MIIM_DATA_SUCCESS, value)) {
            VTSS_E(("miim read fail, cmd: %u, addr: %u, reg: %u", phy_cmd, phy_addr, phy_reg));
            return VTSS_PHY_READ_ERROR;
        }
        *data = B2F(DEVCPU_GCB, MIIM_DATA, MIIM_DATA_RDDATA, value);
    }
    return VTSS_OK;
}

vtss_rc vtss_ll_phy_read(uint miim_controller, uint phy_addr, uint phy_reg, ushort *value)
{
    return b2_miim_cmd(PHY_CMD_READ, 1, miim_controller, phy_addr, phy_reg, value);
}

vtss_rc vtss_ll_phy_write(uint miim_controller, uint phy_addr, uint phy_reg, ushort value)
{
    return b2_miim_cmd(PHY_CMD_WRITE, 1, miim_controller, phy_addr, phy_reg, &value);
}

/* MMD (MDIO Management Devices (10G)) read */
vtss_rc vtss_ll_mmd_read(uint miim_controller, uint phy_addr, uint mmd, uint address, ushort *value)
{
    ushort addr = address;

    VTSS_N(("mii_controller: %d, phy_addr: 0x%02x, mmd: 0x%02x",
            miim_controller,phy_addr,mmd));
    
    VTSS_RC(b2_miim_cmd(PHY_CMD_ADDRESS,0,miim_controller,phy_addr,mmd,&addr));
    return b2_miim_cmd(PHY_CMD_READ,0,miim_controller,phy_addr,mmd,value);
}

/* MMD (MDIO Management Devices (10G)) write */
vtss_rc vtss_ll_mmd_write(uint miim_controller, uint phy_addr, uint mmd, uint address, ushort data)
{
    ushort addr = address;

    VTSS_N(("mii_controller: %d, phy_addr: 0x%02x, mmd: 0x%02x, data: 0x%04x",
            miim_controller,phy_addr,mmd,data));

    VTSS_RC(b2_miim_cmd(PHY_CMD_ADDRESS,0,miim_controller,phy_addr,mmd,&addr));
    return b2_miim_cmd(PHY_CMD_WRITE,0,miim_controller,phy_addr,mmd,&data);
}


/* Is the MAC PCS enabled? */
vtss_rc vtss_ll_port_tbi_enabled(uint port_no, BOOL *enabled)
{    
    vtss_port_interface_t type = vtss_api_state->setup[port_no].interface_mode.interface_type;
    *enabled = (type == VTSS_PORT_INTERFACE_SERDES || type == VTSS_PORT_INTERFACE_LOOPBACK);
    
    return VTSS_OK;
}

/* Is the PCS autoneg enabled? */
vtss_rc vtss_ll_port_tbi_autoneg_enabled(uint port_no, BOOL *enabled)
{
    ulong val;
    uint port = vtss_api_state->port_map.chip_port[port_no];

    B2_RDF(DEV1G, PCS1G_ANEG_CFG, ANEG_ENA, port, &val);
    *enabled=MAKEBOOL01(val);
    return VTSS_OK;    
}

/* Get the port PCS autoneg capabilities */
vtss_rc vtss_ll_port_tbi_get_aneg_advertisement(uint port_no, 
                                                vtss_autoneg_1000base_x_advertisement_t * adv)
{
    ulong val;    
    uint port = vtss_api_state->port_map.chip_port[port_no];



    B2_RDF(DEV1G, PCS1G_ANEG_CFG, DAR, port, &val);

    adv->fdx              = MAKEBOOL01(val &   (1<< 5));
    adv->hdx              = MAKEBOOL01(val &   (1<< 6));
    adv->symmetric_pause  = MAKEBOOL01(val &   (1<< 7));
    adv->asymmetric_pause = MAKEBOOL01(val &   (1<< 8));
    adv->remote_fault     =           (val & (0x3<<12)) >> 12;
    adv->acknowledge      = MAKEBOOL01(val &   (1<<14));
    adv->next_page        = MAKEBOOL01(val &   (1<<15));

    return VTSS_OK;
}

/* Set PCS autoneg capabilities and enable/disable aneg */
vtss_rc vtss_ll_port_tbi_aneg_control(const vtss_port_no_t port_no,
                                      const vtss_tbi_autoneg_control_t * const control)
{
    ulong value;
    const vtss_autoneg_1000base_x_advertisement_t *adv = &control->advertisement;
    uint port = vtss_api_state->port_map.chip_port[port_no];
       
    value =  (((adv->next_page ? 1 : 0)<<15) |
              ((adv->acknowledge ? 1 : 0)<<14) |
              (adv->remote_fault<<12) |
              ((adv->asymmetric_pause ? 1 : 0)<<8) |
              ((adv->symmetric_pause ? 1 : 0)<<7) |
              ((adv->hdx ? 1 : 0)<<6) |
              ((adv->fdx ? 1 : 0)<<5));
     
    /* Set aneg capabilities                   */
    B2_WRF(DEV1G, PCS1G_ANEG_CFG, DAR, port, value);

    if (!control->enable) {
        /* Restart aneg before disabling it */
        B2_WRF(DEV1G, PCS1G_ANEG_CFG, ANEG_ENA, port, 1);
        B2_WRF(DEV1G, PCS1G_ANEG_CFG, ANEG_RESTART, port, 1);
    } 

    /* Enable/Disable aneg and restart                 */
    B2_WRF(DEV1G, PCS1G_ANEG_CFG, ANEG_ENA, port, control->enable);
    B2_WRF(DEV1G, PCS1G_ANEG_CFG, ANEG_RESTART, port, 1); 

    return VTSS_OK;
}

/* Restart PCS aneg */
vtss_rc vtss_ll_port_tbi_aneg_restart(uint port_no)
{
    uint port = vtss_api_state->port_map.chip_port[port_no];
    B2_WRF(DEV1G, PCS1G_ANEG_CFG, ANEG_RESTART, port, 1);

    return VTSS_OK;
}

/* Get the PCS status */
vtss_rc vtss_ll_port_tbi_status_get(uint port_no, vtss_tbi_status_t *status)
{
    ulong value;
    uint port = vtss_api_state->port_map.chip_port[port_no];

    if (vtss_api_state->setup[port_no].powerdown) {
        memset(status,0,sizeof(vtss_tbi_status_t));
        status->autoneg.pcs_state = VTSS_TBI_PCS_STATE_IDLE;
        return VTSS_OK;
    }

    /* Get the link state 'down' sticky bit  */
    B2_RDF(DEV1G, PCS1G_STICKY, LINK_DOWN_STICKY, port, &value);

    if (MAKEBOOL01(value)) {
        /* The link has been down. Clear the sticky bit and return the 'down' value  */
        B2_WRF(DEV1G, PCS1G_STICKY, LINK_DOWN_STICKY, port, 1);
    } else {
        /*  Return the current status     */
        B2_RDF(DEV1G, PCS1G_LINK_STATUS, LINK_DOWN, port, &value);
    }
    status->link_status = MAKEBOOL01(value) ? 0 : 1;
    
    /* Get link down counter  */
    B2_RDF(DEV1G, PCS1G_LINK_DOWN_CNT, LINK_DOWN_CNT, port, &value);
    status->link_down_counter = value;

    /* pcs_state not available in B2 */
    status->autoneg.pcs_state = VTSS_TBI_PCS_STATE_NA;

    /* Get PCS ANEG status register */
    B2_RD(DEV1G, PCS1G_ANEG_STATUS, port, &value);
    
    /* Priority resolution and aneg complete   */
    status->autoneg.priority_resolution =                   MAKEBOOL01(value & (1<<4));
    status->autoneg.complete =                              MAKEBOOL01(value & (1<<0));
  
    /* Get Link partner aneg status */
    B2_RDF(DEV1G, PCS1G_ANEG_STATUS, LPA, port, &value);
    status->autoneg.partner_advertisement.fdx =             MAKEBOOL01(value & (1<<5));
    status->autoneg.partner_advertisement.hdx =             MAKEBOOL01(value & (1<<6));
    status->autoneg.partner_advertisement.symmetric_pause = MAKEBOOL01(value & (1<<7));
    status->autoneg.partner_advertisement.asymmetric_pause =MAKEBOOL01(value & (1<<8));
    status->autoneg.partner_advertisement.remote_fault =    (value>>12)&0x3;
    status->autoneg.partner_advertisement.acknowledge =     MAKEBOOL01(value & (1<<14));
    status->autoneg.partner_advertisement.next_page =       MAKEBOOL01(value & (1<<15));

    return VTSS_OK;
}

/* Convert from chip port to line port */
static uint b2_port2line(uint port)
{
    if (port >= CHIP_PORT_10G_0)
        port -= CHIP_PORT_10G_0;
    return port; 
}

/* Port setup common for 1G and 10G ports */
static vtss_rc b2_port_setup(uint port, const vtss_port_setup_t *setup)
{
    const uchar *mac;
    ulong wm_low = 0, wm_high, wm_stop = 3, mac_hi, mac_lo;
    
    switch (setup->interface_mode.speed) {
    case VTSS_SPEED_10M:
        wm_high = 3;
        break;
    case VTSS_SPEED_100M:
        wm_high = 21;
        break;
    case VTSS_SPEED_1G:
        wm_low = 204;
        wm_high = 206;
        break;
    case VTSS_SPEED_10G:
        wm_low = 511;
        wm_high = 513;
        wm_stop = 5;
        break;
    default:
        VTSS_E(("illegal speed"));
        return VTSS_INVALID_PARAMETER;
    }

    B2_WRX(DSM, SCH_STOP_WM_CFG, port, wm_stop << VTSS_OFF_DSM_SCH_STOP_WM_CFG_SCH_STOP_WM);
    B2_WRX(DSM, RATE_CTRL, port, 
           (12 << VTSS_OFF_DSM_RATE_CTRL_FRM_GAP_COMP) |
           (wm_high << VTSS_OFF_DSM_RATE_CTRL_TAXI_RATE_HIGH) |
           (wm_low << VTSS_OFF_DSM_RATE_CTRL_TAXI_RATE_LOW));

    B2_WRX(DSM, RX_PAUSE_CFG, port, 
           (setup->flowcontrol.obey ? 1 : 0) << VTSS_OFF_DSM_RX_PAUSE_CFG_RX_PAUSE_EN);
    
    B2_WRX(DSM, ETH_FC_GEN, port, 
           (setup->flowcontrol.generate ? 1 : 0) << VTSS_OFF_DSM_ETH_FC_GEN_ETH_PORT_FC_GEN);
    
    B2_WRX(DSM, MAC_CFG, port, 
           (0xff << VTSS_OFF_DSM_MAC_CFG_TX_PAUSE_VAL) |
           ((setup->fdx ? 0 : 1) << VTSS_OFF_DSM_MAC_CFG_HDX_BACKPRESSURE) |
           (0 << VTSS_OFF_DSM_MAC_CFG_SEND_PAUSE_FRM_TWICE) |
           (1 << VTSS_OFF_DSM_MAC_CFG_TX_PAUSE_XON_XOFF));
    
    mac = setup->flowcontrol.smac.addr;
    mac_hi = ((mac[0] << 16) | (mac[1] << 8) | (mac[2] << 0));
    mac_lo = ((mac[3] << 16) | (mac[4] << 8) | (mac[5] << 0)); 
    B2_WRX(DSM, MAC_ADDR_HIGH_CFG, port, 
           mac_hi << VTSS_OFF_DSM_MAC_ADDR_HIGH_CFG_MAC_ADDR_HIGH);
    B2_WRX(DSM, MAC_ADDR_LOW_CFG, port, 
           mac_lo << VTSS_OFF_DSM_MAC_ADDR_LOW_CFG_MAC_ADDR_LOW);
    B2_WRX(ASM, MAC_ADDR_HIGH_CFG, port, 
           mac_hi << VTSS_OFF_ASM_MAC_ADDR_HIGH_CFG_MAC_ADDR_HIGH);
    B2_WRX(ASM, MAC_ADDR_LOW_CFG, port, 
           mac_lo << VTSS_OFF_ASM_MAC_ADDR_LOW_CFG_MAC_ADDR_LOW);
    B2_WRX(ASM, PAUSE_CFG, port, 1 << VTSS_OFF_ASM_PAUSE_CFG_ABORT_PAUSE_ENA);
    
    return VTSS_OK;
}

/* Flush queue */
static vtss_rc b2_queue_flush(uint port, uint queue)
{
    ulong i, value;
    
    B2_WR(QSS, Q_FLUSH, 0,
          (queue << VTSS_OFF_QSS_Q_FLUSH_Q_FLUSH_PRIO) |
          (port << VTSS_OFF_QSS_Q_FLUSH_Q_FLUSH_PORT));
    B2_WR(QSS, Q_FLUSH_REQ, 0, 1 << VTSS_OFF_QSS_Q_FLUSH_REQ_Q_FLUSH_REQ);

    for (i = 0; i < 100; i++) {
        B2_RDF(QSS, Q_FLUSH_REQ, Q_FLUSH_REQ, 0, &value);
        if (value == 0)
            return VTSS_OK;
    }
    VTSS_E(("flush failed, port: %u, queue: %u", port, queue));
    return VTSS_UNSPECIFIED_ERROR;
}

vtss_rc vtss_ll_port_speed_mode_tbi_gmii(vtss_port_no_t port_no,
                                         const vtss_port_setup_t *setup)
{
    uint         port, aport;
    ulong        giga = 0, fdx, clk, rx_ifg1, rx_ifg2, tx_ifg;
    ulong        sgmii = 0, serdes = 0, if_100fx = 0, disabled;
    vtss_speed_t speed;
    
    port = vtss_api_state->port_map.chip_port[port_no];
    disabled = (setup->powerdown ? 1 : 0);
    VTSS_D(("port_no: %u, port: %u", port_no, port));

    fdx = setup->fdx;
    speed = setup->interface_mode.speed;
    switch (speed) {
    case VTSS_SPEED_10M:
        clk = 0;
        break;
    case VTSS_SPEED_100M:
        clk = 1;
        break;
    case VTSS_SPEED_1G:
        clk = 2;
        giga = 1;
        break;
    default:
        VTSS_E(("illegal speed: %d", speed));
        return VTSS_INVALID_PARAMETER;
    }

    /* Interface type */
    switch (setup->interface_mode.interface_type) {
    case VTSS_PORT_INTERFACE_SGMII:
        sgmii = 1;
        break;
    case VTSS_PORT_INTERFACE_SERDES:
        serdes = 1;
        break;
    case VTSS_PORT_INTERFACE_100FX:
        if_100fx = 1;
        break;
    default:
        VTSS_E(("illegal interface type"));
        return VTSS_INVALID_PARAMETER;
        break;
    }

    /* Disable and flush Tx queue */
    aport = b2_port2line(port);
    B2_WRX(QSS, PORT_ENA, aport, 0 << VTSS_OFF_QSS_PORT_ENA_PORT_ENA);
    VTSS_RC(b2_queue_flush(aport, 0));

    /* Disable Rx and Tx in MAC */
    B2_WR(DEV1G, MAC_ENA_CFG, port, 
          (0 << VTSS_OFF_DEV1G_MAC_ENA_CFG_RX_ENA) |
          (0 << VTSS_OFF_DEV1G_MAC_ENA_CFG_TX_ENA));


    /* Reset MAC */
    B2_WR(DEV1G, DEV_RST_CTRL, port, 
          (1 << VTSS_OFF_DEV1G_DEV_RST_CTRL_MAC_TX_RST) |
          (1 << VTSS_OFF_DEV1G_DEV_RST_CTRL_MAC_RX_RST));
    
    /* Common port setup */
    VTSS_RC(b2_port_setup(port, setup));

    /* Interframe gaps */
    rx_ifg1 = setup->frame_gaps.hdx_gap_1;
    if (rx_ifg1 == VTSS_FRAME_GAP_DEFAULT)
        rx_ifg1 = (giga ? 5 : 7);
    
    rx_ifg2 = setup->frame_gaps.hdx_gap_2;
    if (rx_ifg2 == VTSS_FRAME_GAP_DEFAULT)
        rx_ifg2 = (giga ? 1 : fdx ? 11 : 8);

    tx_ifg = setup->frame_gaps.fdx_gap;
    if (tx_ifg == VTSS_FRAME_GAP_DEFAULT)
        tx_ifg = (giga ? 6 : (fdx==0 && speed == VTSS_SPEED_100M) ? 15 : 17);
    
    B2_WR(DEV1G, MAC_IFG_CFG, port,
          (tx_ifg << VTSS_OFF_DEV1G_MAC_IFG_CFG_TX_IFG) |
          (rx_ifg2 << VTSS_OFF_DEV1G_MAC_IFG_CFG_RX_IFG2) |
          (rx_ifg1 << VTSS_OFF_DEV1G_MAC_IFG_CFG_RX_IFG1));
    
    /* Frame length */
    B2_WR(DEV1G, MAC_MAXLEN_CFG, port, setup->maxframelength);

    /* Half duplex */
    B2_WR(DEV1G, MAC_HDX_CFG, port,
          (setup->flowcontrol.smac.addr[5] >> VTSS_OFF_DEV1G_MAC_HDX_CFG_SEED) |
          ((fdx ? 0 : 1) << VTSS_OFF_DEV1G_MAC_HDX_CFG_SEED_LOAD) |
          (0 << VTSS_OFF_DEV1G_MAC_HDX_CFG_RETRY_AFTER_EXC_COL_ENA) |
          (0x41 << VTSS_OFF_DEV1G_MAC_HDX_CFG_LATE_COL_POS));

    /* SGMII */
    B2_WR(DEV1G, PCS1G_MODE_CFG, port, sgmii << VTSS_OFF_DEV1G_PCS1G_MODE_CFG_SGMII_MODE_ENA);

    /* Signal detect */
    B2_WR(DEV1G, PCS1G_SD_CFG, port, 
          ((setup->tbi_signaldetect_activehigh ? 1 : 0) << 
           VTSS_OFF_DEV1G_PCS1G_SD_CFG_SD_POL) |
          ((setup->tbi_use_signaldetect ? 1 : 0) << VTSS_OFF_DEV1G_PCS1G_SD_CFG_SD_ENA));

    /* Release MAC from reset */
    B2_WR(DEV1G, DEV_RST_CTRL, port, 
          ((disabled ? 5 : clk) << VTSS_OFF_DEV1G_DEV_RST_CTRL_SPEED_SEL) |
          (if_100fx << VTSS_OFF_DEV1G_DEV_RST_CTRL_FX100_ENABLE) |
          (0 << VTSS_OFF_DEV1G_DEV_RST_CTRL_SGMII_MACRO_RST) |
          (0 << VTSS_OFF_DEV1G_DEV_RST_CTRL_FX100_PCS_TX_RST) |
          (0 << VTSS_OFF_DEV1G_DEV_RST_CTRL_FX100_PCS_RX_RST) |
          (disabled << VTSS_OFF_DEV1G_DEV_RST_CTRL_PCS_TX_RST) |
          (disabled << VTSS_OFF_DEV1G_DEV_RST_CTRL_PCS_RX_RST) |
          (disabled << VTSS_OFF_DEV1G_DEV_RST_CTRL_MAC_TX_RST) |
          (disabled << VTSS_OFF_DEV1G_DEV_RST_CTRL_MAC_RX_RST));


    /* MAC mode */
    B2_WR(DEV1G, MAC_MODE_CFG, port, 
          (giga << VTSS_OFF_DEV1G_MAC_MODE_CFG_GIGA_MODE_ENA) |
          (fdx << VTSS_OFF_DEV1G_MAC_MODE_CFG_FDX_ENA));

    /* Enable Rx and Tx in MAC */
    B2_WR(DEV1G, MAC_ENA_CFG, port, 
          (1 << VTSS_OFF_DEV1G_MAC_ENA_CFG_RX_ENA) |
          (1 << VTSS_OFF_DEV1G_MAC_ENA_CFG_TX_ENA));

    /* Enable Tx queue */
    B2_WRX(QSS, PORT_ENA, aport, 1 << VTSS_OFF_QSS_PORT_ENA_PORT_ENA);
      
    return VTSS_OK;
}

static vtss_rc b2_xaui_port_setup(uint port, const vtss_port_setup_t * setup)
{
    ulong disabled;
    int   host_mode;
    BOOL  hih;
    
    VTSS_D(("port: %u", port));

    disabled = (setup->powerdown ? 1 : 0);
    host_mode = vtss_api_state->init_setup.host_mode;
    hih = (host_mode < 4 || host_mode == 8 || host_mode > 9);
    if (setup->interface_mode.speed != VTSS_SPEED_10G) {
        VTSS_E(("illegal speed"));
        return VTSS_INVALID_PARAMETER;
    }

    /* Disable Rx and Tx in MAC */
    B2_WR(DEV10G, MAC_ENA_CFG, port, 
          (0 << VTSS_OFF_DEV10G_MAC_ENA_CFG_RX_ENA) |
          (0 << VTSS_OFF_DEV10G_MAC_ENA_CFG_TX_ENA));
    
    /* Reset MAC */
    B2_WR(DEV10G, DEV_RST_CTRL, port, 
          (0 << VTSS_OFF_DEV10G_DEV_RST_CTRL_CLK_DIVIDE_SEL) |
          (4 << VTSS_OFF_DEV10G_DEV_RST_CTRL_SPEED_SEL) |
          (0 << VTSS_OFF_DEV10G_DEV_RST_CTRL_CLK_DRIVE_EN) |
          (1 << VTSS_OFF_DEV10G_DEV_RST_CTRL_PCS_TX_RST) |
          (1 << VTSS_OFF_DEV10G_DEV_RST_CTRL_PCS_RX_RST) |
          (1 << VTSS_OFF_DEV10G_DEV_RST_CTRL_MAC_TX_RST) |
          (1 << VTSS_OFF_DEV10G_DEV_RST_CTRL_MAC_RX_RST));
    
    /* Common port setup */
    VTSS_RC(b2_port_setup(port, setup));

    /* Frame length */
    B2_WR(DEV10G, MAC_MAXLEN_CFG, port, setup->maxframelength);

    /* Preamble checking */
    B2_WR(DEV10G, MAC_ADV_CHK_CFG, port,
          (0 << VTSS_OFF_DEV10G_MAC_ADV_CHK_CFG_FCS_ERROR_DISCARD_DIS) |
          (0 << VTSS_OFF_DEV10G_MAC_ADV_CHK_CFG_EXT_EOP_CHK_ENA) |
          (0 << VTSS_OFF_DEV10G_MAC_ADV_CHK_CFG_EXT_SOP_CHK_ENA) |
          ((hih ? 0 : 1) << VTSS_OFF_DEV10G_MAC_ADV_CHK_CFG_SFD_CHK_ENA) |
          (1 << VTSS_OFF_DEV10G_MAC_ADV_CHK_CFG_PRM_SHK_CHK_DIS) |
          (0 << VTSS_OFF_DEV10G_MAC_ADV_CHK_CFG_PRM_CHK_ENA) |
          (0 << VTSS_OFF_DEV10G_MAC_ADV_CHK_CFG_OOR_ERR_ENA) |
          (0 << VTSS_OFF_DEV10G_MAC_ADV_CHK_CFG_INR_ERR_ENA));
    
    /* Link fault signalling used for line ports */
    B2_WR(DEV10G, MAC_LFS_CFG, port, 
          (0 << VTSS_OFF_DEV10G_MAC_LFS_CFG_LFS_INH_TX) |
          (0 << VTSS_OFF_DEV10G_MAC_LFS_CFG_LFS_DIS_TX) |
          ((hih ? 0 : 1) << VTSS_OFF_DEV10G_MAC_LFS_CFG_LFS_MODE_ENA));
    
    /* Release MAC from reset */
    B2_WR(DEV10G, DEV_RST_CTRL, port, 
          (0 << VTSS_OFF_DEV10G_DEV_RST_CTRL_CLK_DIVIDE_SEL) |
          ((disabled ? 5 : 4) << VTSS_OFF_DEV10G_DEV_RST_CTRL_SPEED_SEL) |
          (0 << VTSS_OFF_DEV10G_DEV_RST_CTRL_CLK_DRIVE_EN) |
          (disabled << VTSS_OFF_DEV10G_DEV_RST_CTRL_PCS_TX_RST) |
          (disabled << VTSS_OFF_DEV10G_DEV_RST_CTRL_PCS_RX_RST) |
          (disabled << VTSS_OFF_DEV10G_DEV_RST_CTRL_MAC_TX_RST) |
          (disabled << VTSS_OFF_DEV10G_DEV_RST_CTRL_MAC_RX_RST));
    
    /* Enable Rx and Tx in MAC */
    B2_WR(DEV10G, MAC_ENA_CFG, port, 
          (1 << VTSS_OFF_DEV10G_MAC_ENA_CFG_RX_ENA) |
          (1 << VTSS_OFF_DEV10G_MAC_ENA_CFG_TX_ENA));

    return VTSS_OK;
}

vtss_rc vtss_ll_port_speed_mode_xgmii(vtss_port_no_t port_no,
                                      const vtss_port_setup_t * setup)
{
    VTSS_D(("port_no: %u", port_no));
    return b2_xaui_port_setup(vtss_api_state->port_map.chip_port[port_no], setup);
}

/* Determine queue ID */
static uint b2_qid(uint dport, uint queue)
{
    return ((dport - (vtss_api_state->init_setup.host_mode < 4 ? 24 : 48))*VTSS_PRIOS + queue);
}

vtss_rc vtss_ll_port_counters_get(uint port_no, vtss_chip_counters_t * counters)
{
    uint port, aport, dport, i, qid;
    
    port = vtss_api_state->port_map.chip_port[port_no];
    aport = b2_port2line(port);
    dport = vtss_api_state->dep_port[aport];
    
    VTSS_D(("port_no: %u, port: %u, aport: %u, dport: %u", port_no, port, aport, dport));

    if (port < CHIP_PORT_10G_0) {
        /* 1G/Rx */
        B2_RD(ASM, RX_IN_BYTES_CNT, port, &counters->rx_in_bytes);
        B2_RD(ASM, RX_SYMBOL_ERR_CNT, port, &counters->rx_symbol_carrier_err);
        B2_RD(ASM, RX_PAUSE_CNT, port, &counters->rx_pause);
        B2_RD(ASM, RX_UNSUP_OPCODE_CNT, port, &counters->rx_unsup_opcode);
        B2_RD(ASM, RX_OK_BYTES_CNT, port, &counters->rx_ok_bytes);
        B2_RD(ASM, RX_BAD_BYTES_CNT, port, &counters->rx_bad_bytes);
        B2_RD(ASM, RX_UC_CNT, port, &counters->rx_unicast);
        B2_RD(ASM, RX_MC_CNT, port, &counters->rx_multicast);
        B2_RD(ASM, RX_BC_CNT, port, &counters->rx_broadcast);
        B2_RD(ASM, RX_CRC_ERR_CNT, port, &counters->rx_crc_err);
        B2_RD(ASM, RX_UNDERSIZE_CNT, port, &counters->rx_undersize);
        B2_RD(ASM, RX_FRAGMENTS_CNT, port, &counters->rx_fragments);
        B2_RD(ASM, RX_IN_RANGE_LEN_ERR_CNT, port, &counters->rx_in_range_length_err);
        B2_RD(ASM, RX_OUT_OF_RANGE_LEN_ERR_CNT, port, &counters->rx_out_of_range_length_err);
        B2_RD(ASM, RX_OVERSIZE_CNT, port, &counters->rx_oversize);
        B2_RD(ASM, RX_JABBERS_CNT, port, &counters->rx_jabbers);
        B2_RD(ASM, RX_SIZE64_CNT, port, &counters->rx_size64);
        B2_RD(ASM, RX_SIZE65TO127_CNT, port, &counters->rx_size65_127);
        B2_RD(ASM, RX_SIZE128TO255_CNT, port, &counters->rx_size128_255);
        B2_RD(ASM, RX_SIZE256TO511_CNT, port, &counters->rx_size256_511);
        B2_RD(ASM, RX_SIZE512TO1023_CNT, port, &counters->rx_size512_1023);
        B2_RD(ASM, RX_SIZE1024TO1518_CNT, port, &counters->rx_size1024_1518);
        B2_RD(ASM, RX_SIZE1519TOMAX_CNT, port, &counters->rx_size1519_max);
        B2_RD(ASM, RX_IPG_SHRINK_CNT, port, &counters->rx_ipg_shrink);
    
        /* 1G/Tx */
        B2_RD(ASM, TX_OUT_BYTES_CNT, port, &counters->tx_out_bytes);
        B2_RD(ASM, TX_PAUSE_CNT, port, &counters->tx_pause);
        B2_RD(ASM, TX_OK_BYTES_CNT, port, &counters->tx_ok_bytes);
        B2_RD(ASM, TX_UC_CNT, port, &counters->tx_unicast);
        B2_RD(ASM, TX_MC_CNT, port, &counters->tx_multicast);
        B2_RD(ASM, TX_BC_CNT, port, &counters->tx_broadcast);
        B2_RD(ASM, TX_SIZE64_CNT, port, &counters->tx_size64);
        B2_RD(ASM, TX_SIZE65TO127_CNT, port, &counters->tx_size65_127);
        B2_RD(ASM, TX_SIZE128TO255_CNT, port, &counters->tx_size128_255);
        B2_RD(ASM, TX_SIZE256TO511_CNT, port, &counters->tx_size256_511);
        B2_RD(ASM, TX_SIZE512TO1023_CNT, port, &counters->tx_size512_1023);
        B2_RD(ASM, TX_SIZE1024TO1518_CNT, port, &counters->tx_size1024_1518);
        B2_RD(ASM, TX_SIZE1519TOMAX_CNT, port, &counters->tx_size1519_max);
        B2_RD(ASM, TX_MULTI_COLL_CNT, port, &counters->tx_multi_coll);
        B2_RD(ASM, TX_LATE_COLL_CNT, port, &counters->tx_late_coll);
        B2_RD(ASM, TX_XCOLL_CNT, port, &counters->tx_xcoll);
        B2_RD(ASM, TX_DEFER_CNT, port, &counters->tx_defer);
        B2_RD(ASM, TX_XDEFER_CNT, port, &counters->tx_xdefer);
        B2_RD(ASM, TX_BACKOFF1_CNT, port, &counters->tx_backoff1);
        B2_RD(ASM, TX_CSENSE_CNT, port, &counters->tx_csense);
    } else { 
        /* 10G/Rx */
        B2_RD(DEV10G, RX_IN_BYTES_CNT, port, &counters->rx_in_bytes);
        B2_RD(DEV10G, RX_SYMBOL_ERR_CNT, port, &counters->rx_symbol_carrier_err);
        B2_RD(DEV10G, RX_PAUSE_CNT, port, &counters->rx_pause);
        B2_RD(DEV10G, RX_UNSUP_OPCODE_CNT, port, &counters->rx_unsup_opcode);
        B2_RD(DEV10G, RX_OK_BYTES_CNT, port, &counters->rx_ok_bytes);
        B2_RD(DEV10G, RX_BAD_BYTES_CNT, port, &counters->rx_bad_bytes);
        B2_RD(DEV10G, RX_UC_CNT, port, &counters->rx_unicast);
        B2_RD(DEV10G, RX_MC_CNT, port, &counters->rx_multicast);
        B2_RD(DEV10G, RX_BC_CNT, port, &counters->rx_broadcast);
        B2_RD(DEV10G, RX_CRC_ERR_CNT, port, &counters->rx_crc_err);
        B2_RD(DEV10G, RX_UNDERSIZE_CNT, port, &counters->rx_undersize);
        B2_RD(DEV10G, RX_FRAGMENTS_CNT, port, &counters->rx_fragments);
        B2_RD(DEV10G, RX_IN_RANGE_LEN_ERR_CNT, port, &counters->rx_in_range_length_err);
        B2_RD(DEV10G, RX_OUT_OF_RANGE_LEN_ERR_CNT, port, &counters->rx_out_of_range_length_err);
        B2_RD(DEV10G, RX_OVERSIZE_CNT, port, &counters->rx_oversize);
        B2_RD(DEV10G, RX_JABBERS_CNT, port, &counters->rx_jabbers);
        B2_RD(DEV10G, RX_SIZE64_CNT, port, &counters->rx_size64);
        B2_RD(DEV10G, RX_SIZE65TO127_CNT, port, &counters->rx_size65_127);
        B2_RD(DEV10G, RX_SIZE128TO255_CNT, port, &counters->rx_size128_255);
        B2_RD(DEV10G, RX_SIZE256TO511_CNT, port, &counters->rx_size256_511);
        B2_RD(DEV10G, RX_SIZE512TO1023_CNT, port, &counters->rx_size512_1023);
        B2_RD(DEV10G, RX_SIZE1024TO1518_CNT, port, &counters->rx_size1024_1518);
        B2_RD(DEV10G, RX_SIZE1519TOMAX_CNT, port, &counters->rx_size1519_max);
        B2_RD(DEV10G, RX_IPG_SHRINK_CNT, port, &counters->rx_ipg_shrink);
    
        /* 10G/Tx */
        B2_RD(DEV10G, TX_OUT_BYTES_CNT, port, &counters->tx_out_bytes);
        B2_RDX(DSM, TX_PAUSE_CNT, aport, &counters->tx_pause);
        B2_RD(DEV10G, TX_OK_BYTES_CNT, port, &counters->tx_ok_bytes);
        B2_RD(DEV10G, TX_UC_CNT, port, &counters->tx_unicast);
        B2_RD(DEV10G, TX_MC_CNT, port, &counters->tx_multicast);
        B2_RD(DEV10G, TX_BC_CNT, port, &counters->tx_broadcast);
        B2_RD(DEV10G, TX_SIZE64_CNT, port, &counters->tx_size64);
        B2_RD(DEV10G, TX_SIZE65TO127_CNT, port, &counters->tx_size65_127);
        B2_RD(DEV10G, TX_SIZE128TO255_CNT, port, &counters->tx_size128_255);
        B2_RD(DEV10G, TX_SIZE256TO511_CNT, port, &counters->tx_size256_511);
        B2_RD(DEV10G, TX_SIZE512TO1023_CNT, port, &counters->tx_size512_1023);
        B2_RD(DEV10G, TX_SIZE1024TO1518_CNT, port, &counters->tx_size1024_1518);
        B2_RD(DEV10G, TX_SIZE1519TOMAX_CNT, port, &counters->tx_size1519_max);
        counters->tx_multi_coll = 0;
        counters->tx_late_coll = 0;
        counters->tx_xcoll = 0;
        counters->tx_defer = 0;
        counters->tx_xdefer = 0;
        counters->tx_backoff1 = 0;
        counters->tx_csense = 0;
    }

    /* These counters are not supported */
    counters->rx_drops = 0;
    counters->rx_alignment_err = 0;
    counters->tx_queue_system_drops = 0;
    counters->tx_mac_drop = 0;
    counters->tx_underrun = 0;

    /* Filtered frames is counter 0 */
    B2_RDX(ANA_AC, PORT_STAT_LSB_CNT_0, aport, &counters->rx_filter_drops);
    
    /* Policed frames are counter 4 and 6 */
    B2_RDX(ANA_AC, PORT_STAT_LSB_CNT_4, aport, &counters->rx_policer_drops[0]);
    B2_RDX(ANA_AC, PORT_STAT_LSB_CNT_6, aport, &counters->rx_policer_drops[1]);
    
    /* QSS Tx drop counters based on line port */
    qid = (192 + aport);
    B2_RDX(QSS, Q_BRM_DROP_FCNT, qid, &counters->tx_queue_drops);
    B2_RDX(QSS, Q_RED_DROP_FCNT, qid, &counters->tx_red_drops);
    B2_RDX(QSS, Q_ERR_DROP_FCNT, qid, &counters->tx_error_drops);

    /* QSS Rx counters based on departure port */
    for (i = 0; i < VTSS_PRIOS; i++) {
        qid = b2_qid(dport, i);
        B2_RDX(QSS, Q_FCNT, qid, &counters->rx_class[i]);
        B2_RDX(QSS, Q_BRM_DROP_FCNT, qid, &counters->rx_queue_drops[i]);
        B2_RDX(QSS, Q_RED_DROP_FCNT, qid, &counters->rx_red_drops[i]);
        B2_RDX(QSS, Q_ERR_DROP_FCNT, qid, &counters->rx_error_drops[i]);
    }
    
    return VTSS_OK;
}

vtss_rc vtss_ll_port_queue_enable(vtss_port_no_t port_no, BOOL enable)
{
    return VTSS_OK;
}

vtss_rc vtss_ll_port_queue_setup(vtss_port_no_t port_no)
{
    return VTSS_OK;
}

vtss_rc vtss_ll_10g_status_get(vtss_port_no_t port_no, vtss_port_status_t * const status)
{
    uint  port;
    ulong value;
    
    port = vtss_api_state->port_map.chip_port[port_no];
    VTSS_N(("port_no: %u, port: %u", port_no, port));

    B2_RDF(DEV10G, PCS10G_RX_LANE_STAT, LANE_SYNC, port, &value);
    status->link = (value == 0xf ? 1 : 0);

    /* TBD: MAC_TX_MONITOR is currently debug field */
    VTSS_RC(b2_rdf(VTSS_TGT_DEV10G, 0x15, 0, 1, port, &value));
    status->remote_fault = (value ? 1 : 0);
    
    return VTSS_OK;
}
/* ================================================================= *
 *  Port Filters
 * ================================================================= */
vtss_rc vtss_ll_port_filter_set(const vtss_port_no_t port_no, 
                                const vtss_port_filter_t * const filter)
{
    ulong tags, value, mask=0;
    int line_port;


    if (filter->max_tags == VTSS_TAG_ONE) {
        tags = 1;
    } else if (filter->max_tags == VTSS_TAG_TWO) {
        tags = 2;
    } else {
        tags = 0;
    }

    line_port = b2_port2line(vtss_api_state->port_map.chip_port[port_no]);

    VTSS_N(("port_no: %u, mac_ctrl_enable:%d, mac_zero_enable:%d dmac_bc_enable:%d smac_mc_enable:%d \
             tags:%d stag_enable:%d, ctag_enable:%d, prio_tag_enable:%d, untag_enable:%d",\
            filter->mac_ctrl_enable,filter->mac_zero_enable,filter->dmac_bc_enable,filter->smac_mc_enable,\
            tags,filter->stag_enable,filter->ctag_enable,filter->prio_tag_enable,filter->untag_enable));

    /* Only write to the specific fields in the FILTER_CTRL register    */
    mask = 1 << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_MAC_CTRL_ENA |
           1 << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_NULL_MAC_ENA |
           1 << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_BC_ENA | 
           1 << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_SMAC_MC_ENA;

    value = (1^filter->mac_ctrl_enable) << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_MAC_CTRL_ENA | 
            (1^filter->mac_zero_enable) << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_NULL_MAC_ENA |
            (1^filter->dmac_bc_enable)  << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_BC_ENA |
            (1^filter->smac_mc_enable)  << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_SMAC_MC_ENA;

    B2_WRXM(ANA_CL, FILTER_CTRL, line_port, value, mask);       

    /* Only write to the specific fields in the TAG_AND_LBL_CFG register    */
    mask = 3 << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_MAX_VLAN_TAGS |
           1 << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_VLAN_STAGGED_DIS |
           1 << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_VLAN_TAGGED_DIS | 
           1 << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_VLAN_PRIO_TAGGED_DIS |
           1 << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_VLAN_UNTAGGED_DIS;

    value = tags                        << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_MAX_VLAN_TAGS |
           (1^filter->stag_enable)     << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_VLAN_STAGGED_DIS |
           (1^filter->ctag_enable)     << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_VLAN_TAGGED_DIS | 
           (1^filter->prio_tag_enable) << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_VLAN_PRIO_TAGGED_DIS |
           (1^filter->untag_enable)    << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_VLAN_UNTAGGED_DIS;
    
    B2_WRXM(ANA_CL, TAG_AND_LBL_CFG, line_port, value, mask);
          
    return VTSS_OK;
}

/* ================================================================= *
 *  Quality of Service
 * ================================================================= */

/* Minimum weight is 2*MTU */
static ulong b2_min_weight(ulong weight)
{
    ulong min = (2 * vtss_api_state->init_setup.qs.mtu);
    
    return (weight < min ? min : weight);
}

/* Minimum rate corresponding to minimum weight */
static vtss_bitrate_t b2_min_rate(vtss_bitrate_t rate)
{
    ulonglong min;

    min = b2_min_weight(0);
    min = min*vtss_api_state->init_setup.sch_max_rate/0x1fffff;
    if (rate == VTSS_BITRATE_FEATURE_DISABLED || rate < min)
        rate = min;

    return rate;
}

/* Calculate port scheduler weight */
static vtss_rc b2_weight(vtss_bitrate_t rate, ulong *weight)
{
    ulong     max;
    ulonglong w;

    max = vtss_api_state->init_setup.sch_max_rate;
    if (rate == VTSS_BITRATE_FEATURE_DISABLED)
        w = 0;
    else if (rate > max) {
        VTSS_E(("sch_max_rate exceeded"));
        return VTSS_INVALID_PARAMETER;
    } else {
        w = rate;
        w = (0x1fffff*w)/max;
    }
    *weight = b2_min_weight(w);
    return VTSS_OK;
}

/* Check that the sum of scheduler rates do not exceed the XAUI/SPI4 rate */
static vtss_rc b2_scheduler_check(void)
{
    int               host_mode, chip_port;
    vtss_spi4_setup_t *spi4;
    vtss_bitrate_t    rate, spi4_rate = 0, x0_rate = 0, x1_rate = 0, spi4_max, x0_max, x1_max;
    vtss_port_no_t    port_no;
    vtss_lport_no_t   lport_no;
    uint              count;
    
    host_mode = vtss_api_state->init_setup.host_mode;

    /* SPI4 maximum rate */
    spi4 = &vtss_api_state->init_setup.spi4;
    spi4_max = ((spi4->ob.clock*2 + 8)*1000000); /* 8/10/12/14/16 Gbps */
    rate = spi4->qos.shaper.rate;
    if (rate < spi4_max)
        spi4_max = rate;

    /* XAUI maximum rate */
    x0_max = 10000000; /* 10G */
    rate = vtss_api_state->init_setup.xaui.qos.shaper.rate;
    if (host_mode < 4 && rate < x0_max) /* XAUI host port shaper used */
        x0_max = rate;
    x1_max = x0_max;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (host_mode > 6) {
            /* Check if XAUI line port shapers are used */
            rate = vtss_api_state->qos[port_no].shaper_port.rate;
            chip_port = vtss_api_state->port_map.chip_port[port_no];
            if (chip_port == CHIP_PORT_10G_0 && rate < x0_max)
                x0_max = rate;
            if (chip_port == CHIP_PORT_10G_1 && rate < x1_max)
                x1_max = rate;
            continue;
        }

        if (vtss_api_state->port_map.vtss_port_unused[port_no])
            continue;
        rate = b2_min_rate(vtss_api_state->qos[port_no].scheduler.rate);
        lport_no = vtss_api_state->port_map.lport_no[port_no];
        if (host_mode > 3)
            spi4_rate += rate;
        else if (host_mode == 0 || (host_mode == 3 && lport_no < 12))
            x0_rate += rate;
        else
            x1_rate += rate;
    }
    
    if (host_mode > 6) {
        /* Aggregator/converter mode */
        count = (host_mode == 9 ? 16 : 48);
        for (lport_no = 0; lport_no < count; lport_no++) {
            /* Rx rate towards SPI4 */
            rate = b2_min_rate(vtss_api_state->lport_qos[lport_no].scheduler.rx_rate);
            spi4_rate += rate;
            
            /* Tx rate towards XAUI */
            rate = b2_min_rate(vtss_api_state->lport_qos[lport_no].scheduler.tx_rate);
            if (lport_no < (count/2))
                x0_rate += rate;
            else
                x1_rate += rate;
        }
    }
    VTSS_D(("spi4_rate: %lu, x0_rate: %lu, x1_rate: %lu", spi4_rate, x0_rate, x1_rate));
    VTSS_D(("spi4_max: %lu, x0_max: %lu, x1_max: %lu", spi4_max, x0_max, x1_max));

    /* Now, check the SPI4/XAUI rates */
    if (spi4_rate > spi4_max) {
        VTSS_E(("SPI4 rate exceeded: %lu, max: %lu", spi4_rate, spi4_max));
        return VTSS_INVALID_PARAMETER;
    }
    if (x0_rate > x0_max) {
        VTSS_E(("XAUI0 rate exceeded: %lu, max: %lu", x0_rate, x0_max));
        return VTSS_INVALID_PARAMETER;
    }
    if (x1_rate > x1_max) {
        VTSS_E(("XAUI1 rate exceeded: %lu, max: %lu", x1_rate, x1_max));
        return VTSS_INVALID_PARAMETER;
    }

    return VTSS_OK;
}

/* Calculate rate register value */
static ulong b2_rate(vtss_bitrate_t rate)
{
    ulonglong value;
    
    value = rate;
    value = (value*1000/1589);
    if (value > 0x7fffff)
        value = 0x7fffff;
    return value;
}

/* Setup shaper */
static vtss_rc b2_shaper_setup(uint port, const vtss_qos_shaper_t *shaper)
{
    ulong value;
    
    /* Threshold, must be setup first */
    value = (shaper->level/1024);
    if (value > 0xff)
        value = 0xff;
    if (value < 2)
        value = 2;
    B2_WRX(SCH, SHAPER_THRESHOLD, port, 
           value << VTSS_OFF_SCH_SHAPER_THRESHOLD_SHAPER_THRESHOLD);

    /* Rate */
    value = b2_rate(shaper->rate);
    B2_WRX(SCH, SHAPER_RATE, port, value << VTSS_OFF_SCH_SHAPER_RATE_SHAPER_RATE);

    /* GAP per frame */
    B2_WRX(SCH, RATE_CONVERSION, port, 20 << VTSS_OFF_SCH_RATE_CONVERSION_RATE_CONVERSION);

    /* Enable/disable */
    return b2_wrf(VTSS_TGT_SCH, VTSS_ADDR_SCH_SPR_PORT_ENABLE, port, 1, 0, 
                  shaper->rate == VTSS_BITRATE_FEATURE_DISABLED ? 0 : 1);
}

/* Setup port/queue policer */
static vtss_rc b2_policer_setup(int offset, const vtss_qos_policer_t *policer, BOOL queue)
{
    ulong cfg, level, rate;

    /* Unicast/multicast/broadcast flags */
    cfg = (((policer->multicast ? 1 : 0) << 1) |
           ((policer->broadcast ? 1 : 0) << 2) |
           ((policer->unicast ? 1 : 0) << 3));

    /* Burst level */
    level = (policer->level / 1024); /* Unit is 1024 bytes. */
    if (level > 0xff)
        level = 0xff;

    /* Rate */
    rate = b2_rate(policer->rate);

    if (queue) {
        /* Queue policer */
        B2_WRX(ANA_AC, POL_PRIO_CFG, offset, cfg);
        B2_WRX(ANA_AC, POL_PRIO_THRES_CFG_0, offset, level);
        B2_WRX(ANA_AC, POL_PRIO_RATE_CFG, offset, rate);
    } else {
        /* Port policer */
        B2_WRX(ANA_AC, POL_PORT_CFG, offset, cfg);
        B2_WRX(ANA_AC, POL_PORT_THRES_CFG_0, offset, level);
        B2_WRX(ANA_AC, POL_PORT_RATE_CFG, offset, rate);
    }
    return VTSS_OK;
}

/* Chip priority */
#define B2_PRIO(qos) (qos.prio - VTSS_PRIO_START)

/* Initialize QoS for chip port */
static vtss_rc b2_port_qos_set(int chip_port, const vtss_port_qos_setup_t *qos)
{
    int   line_port, indx, queue, filt_no;
    ulong mask, value, max_pct, pct, weight;
    const uchar *dmac_p;

    line_port = b2_port2line(chip_port);

    mask = ((1 << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_TAG_SEL) |
            (1 << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_VLAN_AWARE_ENA) | 
            (1 << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_CTAG_STOP_ENA) |
            (1 << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_CTAG_CFI_STOP_ENA));
           
    value = qos->tag_inner     << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_TAG_SEL | 
            qos->vlan_aware    << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_VLAN_AWARE_ENA | 
            qos->ctag_cfi_stop << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_CTAG_CFI_STOP_ENA |
            qos->ctag_stop     << VTSS_OFF_ANA_CL_TAG_AND_LBL_CFG_CTAG_STOP_ENA;    


    /* Only write to the specific fields in the TAG_AND_LBL_CFG register    */    
    B2_WRXM(ANA_CL, TAG_AND_LBL_CFG, line_port, value, mask);    

    /* Set the Primary endpoint order    */
    for (indx = 0; indx < VTSS_QOS_ORDER_COUNT; indx++) {
        B2_WRXY(ANA_CL, ENDPT_REMAP_PRIO_CFG, line_port, indx, qos->order[indx]);            
    }
    
    /* Set DMAC/VID/EType filter */
    for (indx = 0; indx < 2; indx++) {
        dmac_p = qos->dmac_vid_etype.filter[indx].dmac.value;

        /* DMAC Pattern MSB bits 47:32  */
        B2_WRXY(ANA_CL, FILTER_LOCAL_CFG_0, line_port, indx, dmac_p[0] << 8 |
                                                             dmac_p[1] << 0); 

        /* DMAC Pattern LSB bits 31:0  */
        B2_WRXY(ANA_CL, FILTER_LOCAL_CFG_1, line_port, indx, dmac_p[2] << 24 | 
                                                             dmac_p[3] << 16 | 
                                                             dmac_p[4] << 8  | 
                                                             dmac_p[5] << 0);            

        dmac_p = qos->dmac_vid_etype.filter[indx].dmac.mask;
        /* DMAC Mask MSB bits 47:32  */
        B2_WRXY(ANA_CL, FILTER_LOCAL_CFG_2, line_port, indx, dmac_p[0] << 8 |
                                                             dmac_p[1] << 0);
        /* DMAC Mask LSB bits 31:0  */
        B2_WRXY(ANA_CL, FILTER_LOCAL_CFG_3, line_port, indx, dmac_p[2] << 24 | 
                                                             dmac_p[3] << 16 | 
                                                             dmac_p[4] << 8  | 
                                                             dmac_p[5] << 0);            
        /* Ethernet type value */
        B2_WRXY(ANA_CL, FILTER_LOCAL_ETYPE_CFG_0, line_port, indx, qos->dmac_vid_etype.filter[indx].etype.value);
        /* Ethernet type mask */
        B2_WRXY(ANA_CL, FILTER_LOCAL_ETYPE_CFG_1, line_port, indx, qos->dmac_vid_etype.filter[indx].etype.mask);

        /* VLAN ID value */
        B2_WRXY(ANA_CL, FILTER_VID_CFG_0, line_port, indx, qos->dmac_vid_etype.filter[indx].vid.value);
        /* VLAN ID mask  */
        B2_WRXY(ANA_CL, FILTER_VID_CFG_1, line_port, indx, qos->dmac_vid_etype.filter[indx].vid.mask);        
    }

    /* Enable/Disable filter instances (2) */        
    mask = 3 << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_VID_ENA |
           3 << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_ETYPE_ENA |
           3 << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_DMAC_ENA;
    value = qos->dmac_vid_etype.filter[0].enable << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_VID_ENA |
            qos->dmac_vid_etype.filter[1].enable << (VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_VID_ENA+1) |
            qos->dmac_vid_etype.filter[0].enable << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_ETYPE_ENA |
            qos->dmac_vid_etype.filter[1].enable << (VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_ETYPE_ENA+1) |
            qos->dmac_vid_etype.filter[0].enable << VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_DMAC_ENA |
            qos->dmac_vid_etype.filter[1].enable << (VTSS_OFF_ANA_CL_FILTER_CTRL_FILTER_DMAC_ENA+1);        
    B2_WRXM(ANA_CL, FILTER_CTRL, line_port, value, mask);       
    

    
    /* Enable/disable alternate ordering.  Disable means that non-matching frames are dropped  */
    mask = 1 << VTSS_OFF_ANA_CL_FILTER_CTRL_ALT_ORDER_ENA;
    value = qos->dmac_vid_etype.order_enable << VTSS_OFF_ANA_CL_FILTER_CTRL_ALT_ORDER_ENA;
    B2_WRXM(ANA_CL, FILTER_CTRL, line_port, value, mask);       

    /* Set the alternate endpoint order    */
    for (indx = 0; indx < VTSS_QOS_ORDER_COUNT; indx++) {
        B2_WRXY(ANA_CL, ENDPT_REMAP_ALT_CFG, line_port, indx, qos->dmac_vid_etype.order[indx]);
    }
    
    /* Default endpoint, RED and Prio   */
    B2_WRX(ANA_CL, ENDPT_DEFAULT_CFG, line_port, 
           qos->default_qos.red << VTSS_OFF_ANA_CL_ENDPT_DEFAULT_CFG_QOS_DEFAULT_RED |
           B2_PRIO(qos->default_qos) << VTSS_OFF_ANA_CL_ENDPT_DEFAULT_CFG_QOS_DEFAULT_PRIO);

    /* Endpoint for L2 control frames, RED and Prio   */
    B2_WRX(ANA_CL, ENDPT_L2_CTRL_CFG, line_port, 
           qos->l2_control_qos.red << VTSS_OFF_ANA_CL_ENDPT_L2_CTRL_CFG_QOS_L2_CTRL_RED |
           B2_PRIO(qos->l2_control_qos) << VTSS_OFF_ANA_CL_ENDPT_L2_CTRL_CFG_QOS_L2_CTRL_PRIO);

    /* Endpoint for L3 control frames, RED and Prio   */
    B2_WRX(ANA_CL, ENDPT_L3_CTRL_CFG, line_port, 
           qos->l3_control_qos.red << VTSS_OFF_ANA_CL_ENDPT_L3_CTRL_CFG_QOS_L3_CTRL_RED |
           B2_PRIO(qos->l3_control_qos) << VTSS_OFF_ANA_CL_ENDPT_L3_CTRL_CFG_QOS_L3_CTRL_PRIO);

    /* Endpoint for CFI set, RED and Prio             */
    B2_WRX(ANA_CL, ENDPT_CFI_CFG, line_port, 
           qos->cfi_qos.red << VTSS_OFF_ANA_CL_ENDPT_CFI_CFG_QOS_VLAN_CFI_RED |
           B2_PRIO(qos->cfi_qos) << VTSS_OFF_ANA_CL_ENDPT_CFI_CFG_QOS_VLAN_CFI_PRIO);

    /* Endpoint for IPv4 and ARP, RED and Prio        */
    B2_WRX(ANA_CL, ENDPT_IP4_CFG, line_port, 
           qos->ipv4_arp_qos.red << VTSS_OFF_ANA_CL_ENDPT_IP4_CFG_QOS_IP4_RED |
           B2_PRIO(qos->ipv4_arp_qos) << VTSS_OFF_ANA_CL_ENDPT_IP4_CFG_QOS_IP4_PRIO);

    /* Endpoint for IPv6, RED and Prio                */
    B2_WRX(ANA_CL, ENDPT_IP6_CFG, line_port, 
           qos->ipv6_qos.red << VTSS_OFF_ANA_CL_ENDPT_IP6_CFG_QOS_IP6_RED |
           B2_PRIO(qos->ipv6_qos) << VTSS_OFF_ANA_CL_ENDPT_IP6_CFG_QOS_IP6_PRIO);

    /* Endpoint for EXP MPLS, RED and Prio            */
    for (indx = 0; indx < 8; indx++) {
        B2_WRXY(ANA_CL, ENDPT_MPLS_CFG, line_port, indx, 
                qos->mpls_exp_qos[indx].red << VTSS_OFF_ANA_CL_ENDPT_MPLS_CFG_QOS_MPLS_RED |
                B2_PRIO(qos->mpls_exp_qos[indx]) << VTSS_OFF_ANA_CL_ENDPT_MPLS_CFG_QOS_MPLS_PRIO);    
    }

    /* Endpoint for VLAN UserPrio, RED and Prio       */
    for (indx = 0; indx < 8; indx++) {
        B2_WRXY(ANA_CL, ENDPT_UPRIO_CFG, line_port, indx, 
                qos->vlan_tag_qos[indx].red << VTSS_OFF_ANA_CL_ENDPT_UPRIO_CFG_QOS_UPRIO_RED |
                B2_PRIO(qos->vlan_tag_qos[indx]) << VTSS_OFF_ANA_CL_ENDPT_UPRIO_CFG_QOS_UPRIO_PRIO);    
    }    

    /* Endpoint for LLC SNAP frame, RED and Prio      */
    B2_WRX(ANA_CL, ENDPT_SNAP_CFG, line_port, 
           qos->llc_qos.red << VTSS_OFF_ANA_CL_ENDPT_SNAP_CFG_QOS_SNAP_RED |
           B2_PRIO(qos->llc_qos) << VTSS_OFF_ANA_CL_ENDPT_SNAP_CFG_QOS_SNAP_PRIO);

    /* Endpoint for IP protocol (0-255), RED and Prio      */
    B2_WRX(ANA_CL, ENDPT_IP_PROTO_CFG, line_port, 
           qos->ip_proto.proto << VTSS_OFF_ANA_CL_ENDPT_IP_PROTO_CFG_QOS_IP_PROTO_VAL |
           qos->ip_proto.qos.red << VTSS_OFF_ANA_CL_ENDPT_IP_PROTO_CFG_QOS_IP_PROTO_RED |
           B2_PRIO(qos->ip_proto.qos) << VTSS_OFF_ANA_CL_ENDPT_IP_PROTO_CFG_QOS_IP_PROTO_PRIO);

    /* Endpoint for Ethernet Type, RED and Prio      */
    B2_WRX(ANA_CL, ENDPT_ETYPE_CFG, line_port, 
           qos->etype.etype << VTSS_OFF_ANA_CL_ENDPT_ETYPE_CFG_QOS_ETYPE_VAL |
           qos->etype.qos.red << VTSS_OFF_ANA_CL_ENDPT_ETYPE_CFG_QOS_ETYPE_RED |
           B2_PRIO(qos->etype.qos) << VTSS_OFF_ANA_CL_ENDPT_ETYPE_CFG_QOS_ETYPE_PRIO);

    /* Endpoint for VLAN ID (2), RED and Prio      */
    for (indx = 0; indx < 2; indx++) {
        B2_WRXY(ANA_CL, ENDPT_VID_CFG, line_port, indx, 
                qos->vlan[indx].vid << VTSS_OFF_ANA_CL_ENDPT_VID_CFG_QOS_VID_VAL |
                qos->vlan[indx].qos.red << VTSS_OFF_ANA_CL_ENDPT_VID_CFG_QOS_VID_RED |
                B2_PRIO(qos->vlan[indx].qos) << VTSS_OFF_ANA_CL_ENDPT_VID_CFG_QOS_VID_PRIO);
    }  

    /* Port index 0-23 to DSCP tables 0-1  */
    VTSS_RC(b2_wrf(VTSS_TGT_ANA_CL, VTSS_ADDR_ANA_CL_DSCP_REMAP_IDX_CFG, line_port, 1, 0, qos->dscp_table_no-1));

    /* Local TCP/UDP port settings */
    for(indx=0; indx<2; indx++) {
        B2_WRXY(ANA_CL, ENDPT_TCPUDP_CFG_1, line_port, indx, 
                qos->udp_tcp.local.pair[indx].port << VTSS_OFF_ANA_CL_ENDPT_TCPUDP_CFG_1_QOS_LOCAL_TCPUDP_PORT_VAL |
                qos->udp_tcp.local.pair[indx].qos.red << VTSS_OFF_ANA_CL_ENDPT_TCPUDP_CFG_1_QOS_LOCAL_TCPUDP_PORT_RED |
                B2_PRIO(qos->udp_tcp.local.pair[indx].qos) << VTSS_OFF_ANA_CL_ENDPT_TCPUDP_CFG_1_QOS_LOCAL_TCPUDP_PORT_PRIO);
    }
        
    /* Global TCP/UDP enable settings and local TCP/UDP range settings */
    value = 0;
    mask = 0;
    for(indx=0; indx < VTSS_UDP_TCP_PAIR_COUNT; indx++) {
        value = value | (qos->udp_tcp.global_enable[indx][0] << mask) | (qos->udp_tcp.global_enable[indx][1] << (mask+1));
        mask = mask+2;
    }   

    B2_WRX(ANA_CL, ENDPT_TCPUDP_CFG_0, line_port, value << VTSS_OFF_ANA_CL_ENDPT_TCPUDP_CFG_0_QOS_GLOBAL_TCPUDP_PORT_ENA |
                               qos->udp_tcp.local.range << VTSS_OFF_ANA_CL_ENDPT_TCPUDP_CFG_0_QOS_LOCAL_TCPUDP_RNG_ENA);


    /* Global filter enable/disable for each port */
    value = 0;
    for (indx = 0; indx < VTSS_CUSTOM_FILTER_COUNT; indx++) {
        value = value | (qos->custom_filter.global_enable[indx] << indx);
    }
    B2_WRX(ANA_CL, FILTER_GLOBAL_CUSTOM_CFG, line_port, value);


    /* Local filter setup for each port. If matched, drop frame or forward to endpoint */
    mask = 1 << VTSS_OFF_ANA_CL_MISC_PORT_CFG_FILTER_LOCAL_CUSTOM_ENA;
    value = 1^qos->custom_filter.local.forward << VTSS_OFF_ANA_CL_MISC_PORT_CFG_FILTER_LOCAL_CUSTOM_ENA;
    B2_WRXM(ANA_CL, MISC_PORT_CFG, line_port, value, mask);       
     
    for (filt_no = 0; filt_no < 7; filt_no++) {
        /*  Position the filter in L2, L3 or L4 Header and set the offset   */
        B2_WRXY(ANA_CL, FILTER_LOCAL_CUSTOM_CFG_0, line_port, filt_no, 
                qos->custom_filter.local.filter[filt_no].header << VTSS_OFF_ANA_CL_FILTER_LOCAL_CUSTOM_CFG_0_FILTER_LOCAL_CUSTOM_TYPE | 
                qos->custom_filter.local.filter[filt_no].offset << VTSS_OFF_ANA_CL_FILTER_LOCAL_CUSTOM_CFG_0_FILTER_LOCAL_CUSTOM_POS);
        
        /* Set the 2 byte mask and pattern */
        B2_WRXY(ANA_CL, FILTER_LOCAL_CUSTOM_CFG_1, line_port, filt_no, 
                qos->custom_filter.local.filter[filt_no].mask << VTSS_OFF_ANA_CL_FILTER_LOCAL_CUSTOM_CFG_1_FILTER_LOCAL_CUSTOM_MASK | 
                qos->custom_filter.local.filter[filt_no].val  << VTSS_OFF_ANA_CL_FILTER_LOCAL_CUSTOM_CFG_1_FILTER_LOCAL_CUSTOM_PATTERN);        
    }

    /*  Endpoint for local custom filter               */
    B2_WRX(ANA_CL, ENDPT_LOCAL_CUSTOM_FILTER_CFG, line_port, 
           qos->custom_filter.local.qos.red  << VTSS_OFF_ANA_CL_ENDPT_LOCAL_CUSTOM_FILTER_CFG_QOS_LOCAL_CUSTOM_FILTER_RED | 
           B2_PRIO(qos->custom_filter.local.qos) << VTSS_OFF_ANA_CL_ENDPT_LOCAL_CUSTOM_FILTER_CFG_QOS_LOCAL_CUSTOM_FILTER_PRIO);                
  

    /** Port policing (2 policers) **/
    for (indx = 0; indx < VTSS_PORT_POLICER_COUNT; indx++) {
        VTSS_RC(b2_policer_setup(VTSS_PORT_POLICER_COUNT * line_port + indx, 
                                 &qos->policer_port[indx], 0));
    }
    B2_WRX(ANA_AC, POL_PORT_GAP, line_port, 20); /* 20 bytes IFG */

    /** Queue policing (8 policers) **/
    for (queue = VTSS_QUEUE_START; queue < VTSS_QUEUE_END; queue++) {
        VTSS_RC(b2_policer_setup(VTSS_QUEUES * line_port + queue - VTSS_QUEUE_START,
                                 &qos->policer_queue[queue], 1));
    }

    /** Shaper (1 shaper per port) **/
    VTSS_RC(b2_shaper_setup(chip_port, &qos->shaper_port));

    /** RED (Random Early Detection) queue configuration         **/
    for (queue = VTSS_QUEUE_START; queue < VTSS_QUEUE_END; queue++) {
        if (qos->red[queue].max < qos->red[queue].min) {
            VTSS_E(("red max is less than red min"));
            return VTSS_INVALID_PARAMETER;
        }
        /* Convert Red min/max bytes to 128B cells and max_prob % to a number between 0-255*/       
        indx = VTSS_QUEUES * line_port + (queue - VTSS_QUEUE_START);
        B2_WRX(QSS, Q_RED_WQ, indx, qos->red[queue].weight);
        B2_WRX(QSS, Q_RED_MIN_MAX_TH, indx, 
               (qos->red[queue].max/128 - qos->red[queue].min/128) << VTSS_OFF_QSS_Q_RED_MIN_MAX_TH_Q_RED_MAXMIN_TH |
               qos->red[queue].min/128 << VTSS_OFF_QSS_Q_RED_MIN_MAX_TH_Q_RED_MIN_TH);
        B2_WRX(QSS, Q_RED_MISC_CFG, indx, 
               qos->red[queue].enable << VTSS_OFF_QSS_Q_RED_MISC_CFG_Q_RED_ENA |
               qos->red[queue].max_prob_1*255/100 << VTSS_OFF_QSS_Q_RED_MISC_CFG_Q_RED_MAXP_1 |
               qos->red[queue].max_prob_2*255/100 << VTSS_OFF_QSS_Q_RED_MISC_CFG_Q_RED_MAXP_2 |
               qos->red[queue].max_prob_3*255/100 << VTSS_OFF_QSS_Q_RED_MISC_CFG_Q_RED_MAXP_3);
    }
    
    /* Queue percentages, 6 queues per port */
    max_pct = 0; /* Maximum percentage */
    for (queue = VTSS_QUEUE_START; queue < (VTSS_QUEUE_END - 2); queue++) {
        pct = qos->scheduler.queue_pct[queue];
        if (pct > 100) {
            VTSS_E(("illegal queue_pct: %lu", pct));
            return VTSS_INVALID_PARAMETER;
        }
        if (pct > max_pct)
            max_pct = pct;
    }
    if (max_pct == 0)
        max_pct = 100;
    for (queue = VTSS_QUEUE_START; queue < (VTSS_QUEUE_END - 2); queue++) {
        weight = b2_min_weight(0x1fffff*qos->scheduler.queue_pct[queue]/max_pct);
        B2_WRX(SCH, QS0_WEIGHT, 
               line_port * (VTSS_QUEUES - 2) + queue - VTSS_QUEUE_START, 
               weight << VTSS_OFF_SCH_QS0_WEIGHT_QS0_WEIGHT);
    }

    return VTSS_OK;    
}

vtss_rc vtss_ll_port_qos_setup_set(vtss_port_no_t port_no, const vtss_port_qos_setup_t *qos)
{
    int             host_mode;
    vtss_lport_no_t lport_no;
    ulong           weight;
    
    VTSS_RC(b2_scheduler_check());
    
    VTSS_RC(b2_port_qos_set(vtss_api_state->port_map.chip_port[port_no], qos));

    /* Host interface scheduler */
    host_mode = vtss_api_state->init_setup.host_mode;
    if (host_mode < 8) {
        lport_no = vtss_api_state->port_map.lport_no[port_no];
        VTSS_RC(b2_weight(qos->scheduler.rate, &weight));
        
        VTSS_D(("port_no %u, lport_no: %u, weight: 0x%08lx", port_no, lport_no, weight));
        if (host_mode > 3) {
            /* SPI4 */
            B2_WRX(SCH, SPI4_PS_WEIGHT, lport_no, 
                   weight << VTSS_OFF_SCH_SPI4_PS_WEIGHT_SPI4_PS_WEIGHT);
        } else if (host_mode == 0 || (host_mode == 3 && lport_no < 12)) {
            /* XAUI0 */
            B2_WRX(SCH, XAUI0_PS_WEIGHT, lport_no, 
                   weight << VTSS_OFF_SCH_XAUI0_PS_WEIGHT_XAUI0_PS_WEIGHT);
        } else {
            /* XAUI1 */
            if (host_mode == 3) /* Logical port 12-23 means XAUI1 LPID 0-11 */
                lport_no -= 12;
            B2_WRX(SCH, XAUI1_PS_WEIGHT, lport_no, 
                   weight << VTSS_OFF_SCH_XAUI1_PS_WEIGHT_XAUI1_PS_WEIGHT);
        }
    }

    return VTSS_OK;
}

/* Global chip QoS  */
vtss_rc vtss_ll_qos_setup_set(const vtss_qos_setup_t *qos)
{
    int glb_no, filt_no, pair_no, offset;

    /* Global filter configuration         */
    for (glb_no = 0; glb_no < VTSS_CUSTOM_FILTER_COUNT; glb_no++) {
        /*  If matched, drop frame or forward to endpoint  */
        B2_WRX(ANA_CL, FILTER_GLOBAL_CUSTOM_CFG_2, glb_no, 1^qos->custom_filter[glb_no].forward);                        
        /*  Assign RED profile and Priority to this filter              */
        B2_WRX(ANA_CL, ENDPT_GLOBAL_CUSTOM_FILTER_CFG, glb_no, 
           qos->custom_filter[glb_no].qos.red  << VTSS_OFF_ANA_CL_ENDPT_GLOBAL_CUSTOM_FILTER_CFG_QOS_GLOBAL_CUSTOM_FILTER_RED | 
               B2_PRIO(qos->custom_filter[glb_no].qos) << VTSS_OFF_ANA_CL_ENDPT_GLOBAL_CUSTOM_FILTER_CFG_QOS_GLOBAL_CUSTOM_FILTER_PRIO);                

        for (filt_no = 0; filt_no < 7; filt_no++) {
            
            /*  Position the filter in L2, L3 or L4 Header and set the offset   */
            B2_WRXY(ANA_CL, FILTER_GLOBAL_CUSTOM_CFG_0, glb_no, filt_no, 
                    qos->custom_filter[glb_no].filter[filt_no].header << VTSS_OFF_ANA_CL_FILTER_GLOBAL_CUSTOM_CFG_0_FILTER_GLOBAL_CUSTOM_TYPE | 
                    qos->custom_filter[glb_no].filter[filt_no].offset/2 << VTSS_OFF_ANA_CL_FILTER_GLOBAL_CUSTOM_CFG_0_FILTER_GLOBAL_CUSTOM_POS);

            /* Set the 2 byte mask and pattern */
            B2_WRXY(ANA_CL, FILTER_GLOBAL_CUSTOM_CFG_1, glb_no, filt_no, 
                    qos->custom_filter[glb_no].filter[filt_no].mask << VTSS_OFF_ANA_CL_FILTER_GLOBAL_CUSTOM_CFG_1_FILTER_GLOBAL_CUSTOM_MASK | 
                    qos->custom_filter[glb_no].filter[filt_no].val << VTSS_OFF_ANA_CL_FILTER_GLOBAL_CUSTOM_CFG_1_FILTER_GLOBAL_CUSTOM_PATTERN);

        }
    }
        
    /* Global TCP/UDP port parameters (8)   */
    for (pair_no = 0; pair_no < VTSS_UDP_TCP_PAIR_COUNT; pair_no++) {        
        offset = pair_no * 2;
            
        B2_WRX(ANA_CL, ENDPT_GLOBAL_TCPUDP_CFG, offset, 
               qos->udp_tcp[pair_no].pair[0].port     << VTSS_OFF_ANA_CL_ENDPT_GLOBAL_TCPUDP_CFG_QOS_GLOBAL_TCPUDP_VAL | 
               qos->udp_tcp[pair_no].pair[0].qos.red  << VTSS_OFF_ANA_CL_ENDPT_GLOBAL_TCPUDP_CFG_QOS_GLOBAL_TCPUDP_PORT_RED | 
               B2_PRIO(qos->udp_tcp[pair_no].pair[0].qos) << VTSS_OFF_ANA_CL_ENDPT_GLOBAL_TCPUDP_CFG_QOS_GLOBAL_TCPUDP_PORT_PRIO); 

        B2_WRX(ANA_CL, ENDPT_GLOBAL_TCPUDP_CFG, offset+1, 
               qos->udp_tcp[pair_no].pair[1].port     << VTSS_OFF_ANA_CL_ENDPT_GLOBAL_TCPUDP_CFG_QOS_GLOBAL_TCPUDP_VAL | 
               qos->udp_tcp[pair_no].pair[1].qos.red  << VTSS_OFF_ANA_CL_ENDPT_GLOBAL_TCPUDP_CFG_QOS_GLOBAL_TCPUDP_PORT_RED | 
               B2_PRIO(qos->udp_tcp[pair_no].pair[1].qos) << VTSS_OFF_ANA_CL_ENDPT_GLOBAL_TCPUDP_CFG_QOS_GLOBAL_TCPUDP_PORT_PRIO); 
        
        b2_wrf(VTSS_TGT_ANA_CL, VTSS_ADDR_ANA_CL_ENDPT_GLOBAL_TCPUDP_RNG_CFG, pair_no, 1, 0, qos->udp_tcp[pair_no].range);
    }    
    
    
    
    return VTSS_OK;
}

/* 2x64 DSCP entry tables exists    */
vtss_rc vtss_dscp_table_set(const vtss_dscp_table_no_t table_no,
                            const vtss_dscp_entry_t    dscp_table[64])
{
    uint indx, offset;

    if (table_no == 1) {
        offset = 0;
    } else if (table_no == 2) {
        offset = 64;
    } else {
        return VTSS_UNSPECIFIED_ERROR;
    }
        
    for (indx = 0; indx < 64; indx++) {   
        B2_WRX(ANA_CL, ENDPT_DSCP_CFG, offset+indx, 
               dscp_table[indx].enable   << VTSS_OFF_ANA_CL_ENDPT_DSCP_CFG_QOS_DSCP_TRUST_ENA | 
               dscp_table[indx].qos.red  << VTSS_OFF_ANA_CL_ENDPT_DSCP_CFG_QOS_DSCP_RED | 
               B2_PRIO(dscp_table[indx].qos) << VTSS_OFF_ANA_CL_ENDPT_DSCP_CFG_QOS_DSCP_PRIO);
        
    }
    
    return VTSS_OK;
}

/* Set QoS setup for logical port */
vtss_rc vtss_ll_lport_qos_set(const vtss_lport_no_t                lport_no,
                              const vtss_lport_qos_setup_t * const qos)
{
    int   host_mode, count;
    ulong w;
    
    /* Ignore call for normal MAC modes */
    host_mode  = vtss_api_state->init_setup.host_mode;
    if (host_mode < 8)
        return VTSS_OK;
    
    /* Check against logical port range */
    count = (host_mode == 9 ? 16 : 48);
    if (lport_no >= count) {
        VTSS_E(("illegal lport_no: %u", lport_no));
        return VTSS_INVALID_PARAMETER;
    }

    vtss_api_state->lport_qos[lport_no] = *qos;

    VTSS_RC(b2_scheduler_check());
    VTSS_RC(b2_weight(qos->scheduler.rx_rate, &w));
    B2_WRX(SCH, SPI4_PS_WEIGHT, lport_no, w << VTSS_OFF_SCH_SPI4_PS_WEIGHT_SPI4_PS_WEIGHT);
    
    VTSS_RC(b2_weight(qos->scheduler.tx_rate, &w));
    if (lport_no < (count/2)) {
        B2_WRX(SCH, XAUI0_PS_WEIGHT, lport_no, 
               w << VTSS_OFF_SCH_XAUI0_PS_WEIGHT_XAUI0_PS_WEIGHT);
    } else {
        B2_WRX(SCH, XAUI1_PS_WEIGHT, lport_no, 
               w << VTSS_OFF_SCH_XAUI1_PS_WEIGHT_XAUI1_PS_WEIGHT);
    }
    
    return VTSS_OK;
}

/* Set port forwarding state */
vtss_rc vtss_ll_port_forward_state_set(vtss_port_no_t      port_no, 
                                       vtss_port_forward_t forward)
{
    int  host_mode, rx, tx, queue, is_10g;
    uint port, aport, dport, iport;
    
    host_mode = vtss_api_state->init_setup.host_mode;
    if (host_mode > 6) /* Converter/aggregator mode always forwarding */
        return VTSS_OK;
    
    /* Arrival and departure ports */
    port = vtss_api_state->port_map.chip_port[port_no];
    aport = b2_port2line(port);
    dport = vtss_api_state->dep_port[aport];
    is_10g = VTSS_PORT_IS_10G(port);

    rx = VTSS_PORT_RX_FORWARDING(forward);
    
    if (rx) {
        /* Enable Rx queues */
        B2_WRX(QSS, PORT_ENA, dport, rx << VTSS_OFF_QSS_PORT_ENA_PORT_ENA);
    }

    /* Enable/disable arrival port in Rx direction */
    B2_WRX(QSS, APORT_ENA_CLASS_MAP, aport,
           (rx << VTSS_OFF_QSS_APORT_ENA_CLASS_MAP_APORT_ENA) |
           (0 << VTSS_OFF_QSS_APORT_ENA_CLASS_MAP_APORT_CLASS) |
           (dport << VTSS_OFF_QSS_APORT_ENA_CLASS_MAP_APORT_MAP));

    if (!rx) {
        /* Disable and flush Rx queues */
        B2_WRX(QSS, PORT_ENA, dport, rx << VTSS_OFF_QSS_PORT_ENA_PORT_ENA);
        for (queue = 0; queue < VTSS_QUEUES; queue++) {
            VTSS_RC(b2_queue_flush(dport, queue));
        }
    }
    
    tx = VTSS_PORT_TX_FORWARDING(forward);
    if (tx) {
        /* Enable Tx queue */
        B2_WRX(QSS, PORT_ENA, aport, tx << VTSS_OFF_QSS_PORT_ENA_PORT_ENA);
    }
    
    /* Enable/disable arrival port in Tx direction */
    for (iport = 0; iport < VTSS_INT_PORT_COUNT; iport++) {
        if (vtss_api_state->dep_port[iport] == aport) {
            B2_WRX(QSS, APORT_ENA_CLASS_MAP, iport,
                   (tx << VTSS_OFF_QSS_APORT_ENA_CLASS_MAP_APORT_ENA) |
                   (0 << VTSS_OFF_QSS_APORT_ENA_CLASS_MAP_APORT_CLASS) |
                   (aport << VTSS_OFF_QSS_APORT_ENA_CLASS_MAP_APORT_MAP));
        }
    }
    
    if (!tx) {
        /* Disable and flush Tx queue */
        B2_WRX(QSS, PORT_ENA, aport, tx << VTSS_OFF_QSS_PORT_ENA_PORT_ENA);
        VTSS_RC(b2_queue_flush(aport, 0));
    }
    
    return VTSS_OK;
}

/* ================================================================= *
 *  Supplemental
 * ================================================================= */

vtss_rc vtss_ll_optimize_1sec(void)
{
    return VTSS_OK;
}

vtss_rc vtss_ll_optimize_100msec(void)
{
    return VTSS_OK;
}

vtss_rc vtss_ll_chipid_get(vtss_chipid_t *chip_id)
{
    ulong value;

    B2_RD(DEVCPU_GCB, CHIP_ID, 0, &value);
    if (B2F(DEVCPU_GCB, CHIP_ID, MFG_ID, value) != 0x074) {
        VTSS_E(("CPU interface error, chip_id: 0x%08lx", value));
        return VTSS_UNSPECIFIED_ERROR;
    }
    chip_id->part_number = B2F(DEVCPU_GCB, CHIP_ID, PART_ID, value);
    chip_id->revision = B2F(DEVCPU_GCB, CHIP_ID, REV_ID, value);
    VTSS_D(("part_number: 0x%04x, revision: %u", chip_id->part_number, chip_id->revision));
    return VTSS_OK;
}

vtss_rc vtss_ll_register_read(ulong reg, ulong *value)
{
    return vtss_io_pi_rd_wr(reg >> 16, reg & 0xffff, value, 1);
}

vtss_rc vtss_ll_register_write(ulong reg, ulong value)
{
    return vtss_io_pi_rd_wr(reg >> 16, reg & 0xffff, &value, 0);
}

/* Poll bit until zero */
static vtss_rc b2_poll_bit(uint tgt, uint addr, ulong offset)
{
    ulong value, count = 0;

    VTSS_N(("tgt: %u, addr: %u, offset: %u", tgt, addr, offset));
    do {
        VTSS_RC(b2_rdf(tgt, addr, offset, 1, 0, &value));
        VTSS_MSLEEP(1);
        count++;
        if (count == 100) {
            VTSS_E(("timeout, tgt: %u, addr: %u, offset: %u", tgt, addr, offset));
            return VTSS_UNSPECIFIED_ERROR;
        }
    } while (value);
    
    VTSS_N(("done, count: %u", count));

    return VTSS_OK;
}

#define B2_POLL_BIT(tgt, addr, fld) \
{ \
    vtss_rc rc; \
    if ((rc = b2_poll_bit(VTSS_TGT_##tgt, VTSS_ADDR_##tgt##_##addr, VTSS_OFF_##tgt##_##addr##_##fld)) < 0) \
        return rc; \
}

/* Initialize ANA_CL and ANA_AC */
static vtss_rc b2_ana_init(const vtss_init_setup_t *setup)
{
    ulong port, queue, i;
    
    /* ANA_CL initialization */
    B2_WR(ANA_CL, DEBUG_CFG, 0, 1 << VTSS_OFF_ANA_CL_DEBUG_CFG_CFG_RAM_INIT);

    /* ANA_AC initialization */
    B2_WR(ANA_AC, POL_ALL_CFG, 0, 1 << VTSS_OFF_ANA_AC_POL_ALL_CFG_FORCE_INIT);
    B2_WR(ANA_AC, PORT_STAT_RESET, 0, 1 << VTSS_OFF_ANA_AC_PORT_STAT_RESET_RESET);
    B2_WR(ANA_AC, QUEUE_STAT_RESET, 0, 1 << VTSS_OFF_ANA_AC_QUEUE_STAT_RESET_RESET);
    
    /* Poll one shot bits */
    B2_POLL_BIT(ANA_CL, DEBUG_CFG, CFG_RAM_INIT);
    B2_POLL_BIT(ANA_AC, POL_ALL_CFG, FORCE_INIT);
    B2_POLL_BIT(ANA_AC, PORT_STAT_RESET, RESET);
    B2_POLL_BIT(ANA_AC, QUEUE_STAT_RESET, RESET);

    /* S-tag Ethernet type */
    B2_WR(ANA_CL, STAG_ETYPE_CFG, 0, 
          setup->stag_etype << VTSS_OFF_ANA_CL_STAG_ETYPE_CFG_STAG_ETYPE_VAL);

    /* ANA_AC port counters */
    for (i = 0; i < 8; i++) {
        /* Enable port counters */
        B2_WR(ANA_AC, PORT_STAT_GLOBAL_EVENT_MASK_0 + i, 0, 
              1 << VTSS_OFF_ANA_AC_PORT_STAT_GLOBAL_EVENT_MASK_0_GLOBAL_EVENT_MASK_0);
        
        /* Counter 0,2,4 and 6 are used for dropped frames.
           Counter 1,3,5 and 7 are used for dropped bytes */
        for (port = 0; port < 24; port++) {
            VTSS_RC(b2_wr(VTSS_TGT_ANA_AC, 
                          VTSS_ADDX_ANA_AC_PORT_STAT_CFG_0(port) + i*3, 0, 
                          (i & 1) << VTSS_OFF_ANA_AC_PORT_STAT_CFG_0_CFG_CNT_BYTE_0));
        }
    }
    
    /* Setup the first classifier counter to count all filter events */
    B2_WRX(ANA_CL, TAG_AND_LBL_MASK, 0, 0xffffffff);
    B2_WRX(ANA_CL, DETECTION_MASK, 0, 0xffffffff);

    /* ANA_AC queue counters */
    for (i = 0; i < 2; i++) {
        /* Enable queue counters */
        B2_WR(ANA_AC, QUEUE_STAT_GLOBAL_EVENT_MASK_0 + i, 0, 
              1 << VTSS_OFF_ANA_AC_QUEUE_STAT_GLOBAL_EVENT_MASK_0_GLOBAL_EVENT_MASK_0);
        B2_WR(ANA_AC, QUEUE_STAT_GLOBAL_EVENT_MASK_0 + i, 0, 
              1 << VTSS_OFF_ANA_AC_QUEUE_STAT_GLOBAL_EVENT_MASK_0_GLOBAL_EVENT_MASK_0);
        
        /* Counter 0 is used for dropped frames.
           Counter 1 is used for dropped bytes */
        for (port = 0; port < 24; port++) {
            for (queue = 0; queue < 8; queue++) {
                VTSS_RC(b2_wr(VTSS_TGT_ANA_AC, 
                              VTSS_ADDX_ANA_AC_QUEUE_STAT_CFG_0(port*8 + queue) + i*3, 0,
                              (i & 1) << VTSS_OFF_ANA_AC_QUEUE_STAT_CFG_0_CFG_CNT_BYTE_0));
            }
        }
    }
    return VTSS_OK;
}

/* Initialize ASM */
static vtss_rc b2_asm_init(int host_mode)
{
    ulong i, value, port_1g, port_10g;
    BOOL  spi4, xaui0, xaui1, sgmii0_1, sgmii2_23, next_10g;
    
    /* Determine which interfaces are used for the host mode */
    sgmii0_1 = (host_mode < 5);
    sgmii2_23 = (host_mode < 6);
    spi4 = (host_mode > 3);
    xaui0 = (host_mode != 1 && host_mode != 4 && host_mode != 11);
    xaui1 = (host_mode != 0 && host_mode != 4 && host_mode != 10);
    
    /* Calculate Cell Bus Calendar */
    port_1g = 0;
    port_10g = CHIP_PORT_10G_0;
    next_10g = 1;
    for (i = 0; i < 64; i++) {
        if ((i % 4) == 0) {
            /* SPI4 slot */
            value = (spi4 ? CHIP_PORT_SPI4 : CHIP_PORT_IDLE);
        } else if (next_10g) {
            /* 10G slot */
            if (port_10g == CHIP_PORT_10G_0) {
                value = (xaui0 ? port_10g : CHIP_PORT_IDLE);
                port_10g = CHIP_PORT_10G_1;
            } else {
                value = (xaui1 ? port_10g : CHIP_PORT_IDLE);
                port_10g = CHIP_PORT_10G_0;
            }
            next_10g = 0;
        } else {
            /* 1G slot */
            if (port_1g < 2)
                value = (sgmii0_1 ? port_1g : CHIP_PORT_IDLE);
            else 
                value = (sgmii2_23 ? port_1g : CHIP_PORT_IDLE); 
            port_1g += 8;
            if (port_1g > 23)
                port_1g -= 23;
            next_10g = 1;
        }
        B2_WRX(ASM, CBC_CFG, i, value);
    }

    /* Clear lookup table */
    B2_WR(ASM, LUT_INIT_CFG, 0, 1 << VTSS_OFF_ASM_LUT_INIT_CFG_LPORT_MAP_INIT);

    /* Clear ASM statistics */
    B2_WR(ASM, STAT_CFG, 0, 1 << VTSS_OFF_ASM_STAT_CFG_STAT_CNT_CLR_SHOT);
    
    /* Poll one shot bits */
    B2_POLL_BIT(ASM, LUT_INIT_CFG, LPORT_MAP_INIT);
    B2_POLL_BIT(ASM, STAT_CFG, STAT_CNT_CLR_SHOT);

    /* Reset FIFOs */
    B2_WR(ASM, DBG_CFG, 0, 0xffffffff);
    B2_WR(ASM, DBG_CFG, 0, 0);

    /* Clear sticky bits */
    B2_WR(ASM, CSC_STICKY, 0, 0xffffffff);

    return VTSS_OK;
}

/* BRM threshold disabled */
#define BRM_DISABLED 8191

/* Division with round up */
#define ROUND_UP_DIV(x, y) ((x) + (y) - 1)/(y)

/* Setup QSS */
static vtss_rc b2_qss_setup(void)
{
    vtss_init_setup_t *setup;
    vtss_qs_setup_t   *qs;
    int               host_mode, aport, dport;
    vtss_port_no_t    port_no;
    uint              rx = 0, tx = 1; /* Used as index 0/1 */
    uint              port, chan, port_min, port_max, lport_count, rsvd;
    uint              hport_count, chan_min, chan_max, rx_share;
    uint              mtu, total_size[2], gbl_shmax[2], gbl_fc_hth[2], gbl_drop_hth[2];
    uint              gbl_skid[2], gbl_sum_rsvd[2], host_skid;
    uint              port_skid_1g, port_skid_10g, port_skid;
    uint              host_lat_1g, host_lat_10g, host_lat;
    uint              port_shmax, port_rsvd, port_fc_hth, port_alloc, q6_rsvd, q7_rsvd;
    uint              port_rsvd_min, clock, ratio, sum_rsvd, max_skid;
    uint              i, lport, port_1g = 0, port_10g = 0;
    
    setup = &vtss_api_state->init_setup;
    qs = &setup->qs;
    host_mode = setup->host_mode;

    if (host_mode < 8) {
        /* Normal mode: Calculate number of active ports */
        lport_count = 0;
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (vtss_api_state->port_map.vtss_port_unused[port_no])
                continue;
            lport_count++;
            if (VTSS_PORT_IS_10G(vtss_api_state->port_map.chip_port[port_no]))
                port_10g++;
            else
                port_1g++;
        }
        VTSS_D(("lport_count: %u", lport_count));
    } else {
        /* Aggregator/Converter: Setup fixed mapping from arrival ports to departure ports */
        lport_count = (host_mode == 9 ? 16 : 48);
        port_10g = lport_count;
        for (port = 0; port < lport_count; port++) {
            aport = (port + (host_mode == 9 && port > 7 ? 16 : 0));
            dport = (port + 48);
            VTSS_D(("aport: %d, dport: %d", aport, dport));
            vtss_api_state->dep_port[aport] = dport;
            vtss_api_state->dep_port[dport] = aport;
        }
    }
    
    rsvd = ((qs->resv_q6 ? 1 : 0) + (qs->resv_q7 ? 1 : 0));
    if ((rx_share = qs->rx_share) == 0) {
        /* Default Rx share */
        if (qs->mtu <= VTSS_MAXFRAMELENGTH_STANDARD)
            rx_share = 50;
        else if (host_mode == 6)
            rx_share = 50;
        else if (host_mode == 8 || host_mode == 9) {
            if (qs->rx_mode == VTSS_RX_MODE_SHARED_DROP)
                rx_share = 50;
            else if (qs->tx_mode == VTSS_TX_MODE_PORT_FIFO)
                rx_share = 60;
            else
                rx_share = 67;
        } else if (qs->rx_mode == VTSS_RX_MODE_SHARED_DROP && 
                   qs->tx_mode == VTSS_TX_MODE_PORT_FIFO)
            rx_share = (rsvd == 2 ? 65 : rsvd == 1 ? 56 : 50);
        else if (qs->tx_mode == VTSS_TX_MODE_PORT_FIFO)
            rx_share = (rsvd == 2 ? 70 : rsvd == 1 ? 67 : 60);
        else if (qs->rx_mode == VTSS_RX_MODE_SHARED_DROP && 
                 qs->tx_mode == VTSS_TX_MODE_SHARED_LOSSLESS)
            rx_share = (rsvd == 2 ? 80 : rsvd == 1 ? 75 : 50);
        else if (qs->tx_mode == VTSS_TX_MODE_SHARED_LOSSLESS)
            rx_share = (rsvd == 2 ? 86 : rsvd == 1 ? 80 : 67);
    }
    
    /* Rx and Tx total size */
    total_size[rx] = (8192*rx_share/100);
    total_size[tx] = (8192 - total_size[rx]);
    B2_WR(QSS, RX_TOTAL_SIZE, 0, total_size[rx]);
    B2_WR(QSS, TX_TOTAL_SIZE, 0, total_size[tx]);

    /* QssMTU */
    mtu = ROUND_UP_DIV(qs->mtu + 24, 128);
    port_skid_1g = (3 * mtu + 2 + 1);
    port_skid_10g = (port_skid_1g + 4);
    
    /* GblRxSkidCells */
    gbl_skid[rx] = (port_1g*port_skid_1g + port_10g*port_skid_10g);
    if (lport_count >= 12)
        gbl_skid[rx] = gbl_skid[rx]*12/lport_count;

    /* HostSkidCells (52.5 = 105/2) */
    host_skid = ROUND_UP_DIV((qs->mtu + (host_mode > 3 ? 1560 : 1240))*2, 105);

    /* GblTxSkidCells */
    hport_count = (host_mode == 3 ? 2 : 1);
    gbl_skid[tx] = hport_count*host_skid;
    
    /* HostAvgSchLat for 1G and 10G port */
    clock = setup->spi4.ob.clock;
    ratio = 2*(host_mode < 4 ? 10 : 
               clock == VTSS_SPI4_CLOCK_250_0 ? 8 :
               clock == VTSS_SPI4_CLOCK_312_5 ? 10 :
               clock == VTSS_SPI4_CLOCK_375_0 ? 12 :
               clock == VTSS_SPI4_CLOCK_437_5 ? 14 : 16);
    host_lat_1g = ROUND_UP_DIV(mtu*(lport_count/hport_count - 1), ratio);
    host_lat_10g = ROUND_UP_DIV(10*mtu*(lport_count/hport_count - 1), ratio);
    
    /* GblRxSumRsvd and GblTxSumRsvd */
    port_rsvd_min = 2*mtu;
    if (port_rsvd_min > 81)
        port_rsvd_min = 81;
    sum_rsvd = rsvd*(port_1g*(mtu + host_lat_1g) + port_10g*(mtu + host_lat_10g));
    gbl_sum_rsvd[rx] = (lport_count*port_rsvd_min + sum_rsvd);
    gbl_sum_rsvd[tx] = lport_count*mtu;

    VTSS_D(("------ QSS Setup ---------------------------------"));
    VTSS_D(("MaxNumPorts       : %u", lport_count));
    VTSS_D(("QssRxBufferStyle  : %s", 
            qs->rx_mode == VTSS_RX_MODE_PORT_FIFO ? "Port_FIFO" : 
            qs->rx_mode == VTSS_RX_MODE_SHARED_DROP ? "Shared_Drop" : "Shared_Lossless"));
    VTSS_D(("QssTxBufferStyle  : %s", 
            qs->tx_mode == VTSS_TX_MODE_PORT_FIFO ? "Port_FIFO" : "Shared_Lossless"));
    VTSS_D(("QssCBMPctRx       : %u", rx_share));
    VTSS_D(("QssReserveQ6      : %u", qs->resv_q6));
    VTSS_D(("QssReserveQ7      : %u", qs->resv_q7));
    VTSS_D(("QssMTU            : %u", mtu));
    VTSS_D(("PortSkidCells(1G) : %u", port_skid_1g));
    VTSS_D(("PortSkidCells(10G): %u", port_skid_10g));
    VTSS_D(("GblRxSkidCells    : %u", gbl_skid[rx]));
    VTSS_D(("GblTxSkidCells    : %u", gbl_skid[tx]));
    VTSS_D(("GblRxSumRsvd      : %u", gbl_sum_rsvd[rx]));
    VTSS_D(("GblTxSumRsvd      : %u", gbl_sum_rsvd[tx]));
    VTSS_D(("HostNumIF         : %u", hport_count));
    VTSS_D(("HostSkidCells     : %u", host_skid));
    VTSS_D(("HostAvgSchLat(1G) : %u", host_lat_1g));
    VTSS_D(("HostAvgSchLat(10G): %u", host_lat_10g));
    VTSS_D(("--------------------------------------------------"));

    /* Configuration rules */
    if (qs->rx_mode == VTSS_RX_MODE_PORT_FIFO &&
        total_size[rx] < (lport_count*mtu + gbl_skid[rx] + sum_rsvd)) {
        VTSS_E(("illegal setup for RX_MODE_PORT_FIFO"));
        return VTSS_INVALID_PARAMETER;
    }
    
    max_skid = (port_10g ? port_skid_10g : port_skid_1g);
    if (qs->rx_mode == VTSS_RX_MODE_SHARED_DROP &&
        total_size[rx] < (gbl_sum_rsvd[rx] + max_skid)) {
        VTSS_E(("illegal setup for RX_MODE_SHARED_DROP"));
        return VTSS_INVALID_PARAMETER;
    }
    
    if (qs->rx_mode == VTSS_RX_MODE_SHARED_LOSSLESS &&
        total_size[rx] < (gbl_sum_rsvd[rx] + gbl_skid[rx] + max_skid)) {
        VTSS_E(("illegal setup for RX_MODE_SHARED_LOSSLESS"));
        return VTSS_INVALID_PARAMETER;
    }

    if (qs->tx_mode == VTSS_TX_MODE_PORT_FIFO &&
        total_size[tx] < (lport_count*(mtu + host_skid))) {
        VTSS_E(("illegal setup for TX_MODE_PORT_FIFO"));
        return VTSS_INVALID_PARAMETER;
    }

    if (qs->tx_mode == VTSS_TX_MODE_SHARED_LOSSLESS &&
        total_size[tx] < (gbl_sum_rsvd[tx] + gbl_skid[tx] + host_skid)) {
        VTSS_E(("illegal setup for TX_MODE_SHARED_LOSSLESS"));
        return VTSS_INVALID_PARAMETER;
    }
        
    /* Rx settings */
    gbl_drop_hth[rx] = BRM_DISABLED;
    switch (qs->rx_mode) {
    case VTSS_RX_MODE_PORT_FIFO:
        VTSS_D(("VTSS_RX_MODE_PORT_FIFO"));
        gbl_shmax[rx] = 0;
        gbl_fc_hth[rx] = BRM_DISABLED;
        break;
    case VTSS_RX_MODE_SHARED_DROP:
        VTSS_D(("VTSS_RX_MODE_SHARED_DROP"));
        gbl_shmax[rx] = (total_size[rx] - gbl_sum_rsvd[rx]);
        gbl_fc_hth[rx] = BRM_DISABLED;
        break;
    case VTSS_RX_MODE_SHARED_LOSSLESS:
        VTSS_D(("VTSS_RX_MODE_SHARED_LOSSLESS"));
        gbl_shmax[rx] = (total_size[rx] - gbl_sum_rsvd[rx]);
        gbl_fc_hth[rx] = (gbl_shmax[rx] - gbl_skid[rx]);
        break;
    default:
        VTSS_E(("illegal rx_mode"));
        return VTSS_INVALID_PARAMETER;
    }

    /* Tx settings */
    gbl_drop_hth[tx] = BRM_DISABLED;
    switch (qs->tx_mode) {
    case VTSS_TX_MODE_PORT_FIFO:
        VTSS_D(("VTSS_TX_MODE_PORT_FIFO"));
        gbl_shmax[tx] = 0;
        gbl_fc_hth[tx] = BRM_DISABLED;
        break;
    case VTSS_TX_MODE_SHARED_LOSSLESS:
        VTSS_D(("VTSS_TX_MODE_SHARED_LOSSLESS"));
        gbl_shmax[tx] = (total_size[tx] - gbl_sum_rsvd[tx]);
        gbl_fc_hth[tx] = (gbl_shmax[tx] - gbl_skid[tx]);
        break;
    default:
        VTSS_E(("illegal tx_mode"));
        return VTSS_INVALID_PARAMETER;
    }

    /* Setup Rx and Tx for classes 0 and 1 */
    for (i = 0; i < 2; i++) {
        /* Rx */
        B2_WRX(QSS, RX_GBL_SHMAX, i, gbl_shmax[rx] << VTSS_OFF_QSS_RX_GBL_SHMAX_RX_GBL_SHMAX);
        B2_WRX(QSS, RX_GBL_DROP_HLTH, i,
               (gbl_drop_hth[rx] << VTSS_OFF_QSS_RX_GBL_DROP_HLTH_RX_GBL_DROP_HTH) |
               (gbl_drop_hth[rx] << VTSS_OFF_QSS_RX_GBL_DROP_HLTH_RX_GBL_DROP_LTH));
        B2_WRX(QSS, RX_GBL_FC_HLTH, i,
               (gbl_fc_hth[rx] << VTSS_OFF_QSS_RX_GBL_FC_HLTH_RX_GBL_FC_HTH) |
               (gbl_fc_hth[rx] << VTSS_OFF_QSS_RX_GBL_FC_HLTH_RX_GBL_FC_LTH));
        B2_WRX(QSS, RX_GBL_ENA, i, 1 << VTSS_OFF_QSS_RX_GBL_ENA_RX_GBL_ENA);
        
        /* Tx */
        B2_WRX(QSS, TX_GBL_SHMAX, i, gbl_shmax[tx] << VTSS_OFF_QSS_TX_GBL_SHMAX_TX_GBL_SHMAX);
        B2_WRX(QSS, TX_GBL_DROP_HLTH, i,
               (gbl_drop_hth[tx] << VTSS_OFF_QSS_TX_GBL_DROP_HLTH_TX_GBL_DROP_HTH) |
               (gbl_drop_hth[tx] << VTSS_OFF_QSS_TX_GBL_DROP_HLTH_TX_GBL_DROP_LTH));
        B2_WRX(QSS, TX_GBL_FC_HLTH, i,
               (gbl_fc_hth[tx] << VTSS_OFF_QSS_TX_GBL_FC_HLTH_TX_GBL_FC_HTH) |
               (gbl_fc_hth[tx] << VTSS_OFF_QSS_TX_GBL_FC_HLTH_TX_GBL_FC_LTH));
        B2_WRX(QSS, TX_GBL_ENA, i, 1 << VTSS_OFF_QSS_TX_GBL_ENA_TX_GBL_ENA);
    }

    /* Port settings */
    port_min = (host_mode < 5 ? 0 : host_mode == 5 ? 2 : host_mode == 11 ? 25 : 24);
    port_max = (host_mode < 5 ? 23 : host_mode == 10 ? 24 : 25);
    chan_min = 0;
    chan_max = (host_mode < 8 ? 0 : host_mode == 8 ? 23 : host_mode == 9 ? 7 : 47);
    for (port = port_min; port <= port_max; port++) {
        for (chan = chan_min; chan <= chan_max; chan++) {
            aport = (host_mode > 6 ? 
                     port == CHIP_PORT_10G_0 ? chan : (chan + 24) :
                     b2_port2line(port));
            if ((dport = vtss_api_state->dep_port[aport]) < 0)
                continue; /* Skip unused ports */
            if (VTSS_PORT_IS_10G(port)) {
                port_skid = port_skid_10g;
                host_lat = host_lat_10g;
            } else {
                port_skid = port_skid_1g;
                host_lat = host_lat_1g;
            }
            for (i = rx; i <= tx; i++) {
                port_alloc = 1;
                if (i == rx) {
                    /* Rx */
                    lport = dport;
                    q6_rsvd = (qs->resv_q6 ? (mtu + host_lat) : 0);
                    q7_rsvd = (qs->resv_q7 ? (mtu + host_lat) : 0);
                    switch (qs->rx_mode) {
                    case VTSS_RX_MODE_PORT_FIFO:
                        port_shmax = (total_size[rx]/lport_count - q6_rsvd - q7_rsvd);
                        port_rsvd = port_shmax;
                        port_fc_hth = (port_shmax - port_skid);
                        break;
                    case VTSS_RX_MODE_SHARED_DROP:
                        port_rsvd = port_rsvd_min;
                        port_shmax = (port_rsvd + gbl_shmax[rx]);
                        port_fc_hth = (port_shmax - port_skid);
                        port_alloc = mtu;
                        break;
                    case VTSS_RX_MODE_SHARED_LOSSLESS:
                    default:
                        port_rsvd = port_rsvd_min;
                        port_shmax = (port_rsvd + gbl_shmax[rx]);
                        port_fc_hth = BRM_DISABLED;
                        break;
                    }
                    B2_WRX(QSS, Q_RSVD, b2_qid(dport, 6), q6_rsvd);
                    B2_WRX(QSS, Q_RSVD, b2_qid(dport, 7), q7_rsvd);
                } else {
                    /* Tx */
                    lport = aport;
                    switch (qs->tx_mode) {
                    case VTSS_TX_MODE_PORT_FIFO:
                        port_shmax = total_size[tx]/lport_count;
                        port_rsvd = port_shmax;
                        port_fc_hth = (port_shmax - host_skid);
                        break;
                    case VTSS_TX_MODE_SHARED_LOSSLESS:
                    default:
                        port_rsvd = mtu;
                        port_shmax = (port_rsvd + gbl_shmax[tx]);
                        port_fc_hth = BRM_DISABLED;
                        break;
                    }
                } 

                B2_WRX(QSS, PORT_RSVD_GFC_LTH, lport,
                       (port_rsvd << VTSS_OFF_QSS_PORT_RSVD_GFC_LTH_PORT_RSVD) |
                       (port_rsvd << VTSS_OFF_QSS_PORT_RSVD_GFC_LTH_PORT_GFC_LTH));
                B2_WRX(QSS, PORT_SHMAX, lport,
                       port_shmax << VTSS_OFF_QSS_PORT_SHMAX_PORT_SHMAX);
                B2_WRX(QSS, PORT_DROP_HLTH, lport,
                       (BRM_DISABLED << VTSS_OFF_QSS_PORT_DROP_HLTH_PORT_DROP_HTH) |
                       (BRM_DISABLED << VTSS_OFF_QSS_PORT_DROP_HLTH_PORT_DROP_LTH));
                B2_WRX(QSS, PORT_FC_HLTH, lport,
                       (port_fc_hth << VTSS_OFF_QSS_PORT_FC_HLTH_PORT_FC_HTH) |
                       (port_fc_hth << VTSS_OFF_QSS_PORT_FC_HLTH_PORT_FC_LTH));
                B2_WRX(QSS, PORT_PRE_ALLOC, lport,
                       port_alloc << VTSS_OFF_QSS_PORT_PRE_ALLOC_PORT_PRE_ALLOC);
                B2_WRX(QSS, PORT_ENA, lport, 1 << VTSS_OFF_QSS_PORT_ENA_PORT_ENA);

                /* Arrival port map */
                B2_WRX(QSS, APORT_ENA_CLASS_MAP, lport,
                       (1 << VTSS_OFF_QSS_APORT_ENA_CLASS_MAP_APORT_ENA) |
                       (0 << VTSS_OFF_QSS_APORT_ENA_CLASS_MAP_APORT_CLASS) |
                       (vtss_api_state->dep_port[lport] << 
                        VTSS_OFF_QSS_APORT_ENA_CLASS_MAP_APORT_MAP));
            }
        }
    }

    return VTSS_OK;
}

/* Initialize QSS */
static vtss_rc b2_qss_init(const vtss_init_setup_t *setup, int host_mode)
{
    BOOL xaui, spi4;
    
    B2_WR(QSS, QSS_INIT, 0, 1 << VTSS_OFF_QSS_QSS_INIT_QSS_INIT);
    B2_POLL_BIT(QSS, QSS_INIT, QSS_INIT);
    spi4 = (setup->spi4.fc.three_level_enable ? 1 : 0);
    xaui = (setup->xaui.fc.three_level_enable ? 1 : 0);
    B2_WR(QSS, FC_3LVL, 0,
          (2 << VTSS_OFF_QSS_FC_3LVL_DISABLED_PORT_FC) |
          (spi4 << VTSS_OFF_QSS_FC_3LVL_SPI4_FC_3LVL) |
          (xaui << VTSS_OFF_QSS_FC_3LVL_XAUI1_FC_3LVL) |
          (xaui << VTSS_OFF_QSS_FC_3LVL_XAUI0_FC_3LVL));
          
    return (host_mode > 6 ? b2_qss_setup() : VTSS_OK);
}

/* Initialize SCH */
static vtss_rc b2_sch_init(const vtss_init_setup_t *setup)
{
    BOOL  xaui, spi4;
    ulong i, w;
    
    B2_WR(SCH, SPR_INIT, 0, 1 << VTSS_OFF_SCH_SPR_INIT_SPR_INIT);
    B2_POLL_BIT(SCH, SPR_INIT, SPR_INIT);
    B2_WR(SCH, SPR_PORT_ENABLE, 0, 0 << VTSS_OFF_SCH_SPR_PORT_ENABLE_SPR_PORT_ENABLE);

    xaui = (setup->xaui.fc.channel_enable ? 1 : 0);
    spi4 = (setup->spi4.fc.enable ? 1 : 0);
    B2_WR(SCH, FLOW_CONTROL_ENABLE, 0, 
          (xaui << VTSS_OFF_SCH_FLOW_CONTROL_ENABLE_XAUI0_FC_EN) |
          (xaui << VTSS_OFF_SCH_FLOW_CONTROL_ENABLE_XAUI1_FC_EN) |
          (spi4 << VTSS_OFF_SCH_FLOW_CONTROL_ENABLE_SPI4_STATUS_FC_EN) |
          (0 << VTSS_OFF_SCH_FLOW_CONTROL_ENABLE_SPI4_PS_BM_STATUS_FC_EN));

    /* Scheduler weights */
    VTSS_RC(b2_weight(VTSS_BITRATE_FEATURE_DISABLED, &w));
    for (i = 0; i < 48; i++) {
        B2_WRX(SCH, SPI4_PS_WEIGHT, i, w << VTSS_OFF_SCH_SPI4_PS_WEIGHT_SPI4_PS_WEIGHT);
    }
    for (i = 0; i < 24; i++) {
        B2_WRX(SCH, XAUI0_PS_WEIGHT, i, w << VTSS_OFF_SCH_XAUI0_PS_WEIGHT_XAUI0_PS_WEIGHT);
        B2_WRX(SCH, XAUI1_PS_WEIGHT, i, w << VTSS_OFF_SCH_XAUI1_PS_WEIGHT_XAUI1_PS_WEIGHT);
    }
    return VTSS_OK;
}

/* Initialize DSM */
static vtss_rc b2_dsm_init(void)
{
    return VTSS_OK;
}

/* Determine total number of logical ports based on departure port mapping */
static uint b2_lport_count(void)
{
    uint iport, count = 0;

    for (iport = 0; iport < VTSS_INT_PORT_COUNT; iport++)
        if (vtss_api_state->dep_port[iport] >= 0)
            count++;
    return (count/2);
}

/* Initialize SPI4.2 */
static vtss_rc b2_spi4_init(int host_mode)
{
    int               i, count;
    vtss_spi4_setup_t *spi4;
    ulong             vco, cmu;
    
    if (host_mode < 4) {
        /* XAUI mode, power down SPI4 */
        B2_WR(DEVSPI, SPI4_DDS_CONFIG, 0, 1 << VTSS_OFF_DEVSPI_SPI4_DDS_CONFIG_CONF_POWEROFF);
    } else {
        /* SPI4.2 setup */
        spi4 = &vtss_api_state->init_setup.spi4;
        
        /* Shaper */
        VTSS_RC(b2_shaper_setup(26, &spi4->qos.shaper));

        /* Inbound */
        B2_WR(ASM, SPI4_CH_CFG, 0,
              ((spi4->ib.fcs == VTSS_SPI4_FCS_ADD ? 2 : 0) << 
               VTSS_OFF_ASM_SPI4_CH_CFG_SPI4_FRM_FCS_MODE_SEL) |
              ((spi4->ib.fcs == VTSS_SPI4_FCS_DISABLED ? 0 : 1) << 
               VTSS_OFF_ASM_SPI4_CH_CFG_SPI4_FRM_FCS_ENA));
        if (spi4->ib.clock > VTSS_SPI4_CLOCK_450_TO_500) {
            VTSS_E(("illegal inbound clock: %d", spi4->ib.clock));
            return VTSS_INVALID_PARAMETER;
        }
        B2_WR(DEVSPI, SPI4_DDS_IB_CONFIG, 0,
              (spi4->ib.clock << VTSS_OFF_DEVSPI_SPI4_DDS_IB_CONFIG_CONF_IB_VCO_RANGE) |
              ((spi4->ib.data_swap ? 1 : 0) << 
               VTSS_OFF_DEVSPI_SPI4_DDS_IB_CONFIG_CONF_IB_DATA_SWAP) |
              ((spi4->ib.data_invert ? 0x1ffff : 0) << 
               VTSS_OFF_DEVSPI_SPI4_DDS_IB_CONFIG_CONF_IB_INV_DATA));

        /* Outbound */
        switch (spi4->ob.clock) {
        case VTSS_SPI4_CLOCK_250_0:
            cmu = 0;
            vco = 0;
            break;
        case VTSS_SPI4_CLOCK_312_5:
            cmu = 2;
            vco = 1;
            break;
        case VTSS_SPI4_CLOCK_375_0:
            cmu = 4;
            vco = 2;
            break;
        case VTSS_SPI4_CLOCK_437_5:
            cmu = 6;
            vco = 2;
            break;
        case VTSS_SPI4_CLOCK_500_0:
            cmu = 8;
            vco = 3;
            break;
        default:
            VTSS_E(("illegal outbound clock: %d", spi4->ob.clock));
            return VTSS_INVALID_PARAMETER;
        }
        if (spi4->ob.burst_size > VTSS_SPI4_BURST_256) {
            VTSS_E(("illegal burst_size: %d", spi4->ob.burst_size));
            return VTSS_INVALID_PARAMETER;
        }
        B2_WR(DSM, SPI4_CFG, 0,
              ((spi4->ob.max_burst_2) << VTSS_OFF_DSM_SPI4_CFG_MAXBURST2) |
              ((spi4->ob.max_burst_1) << VTSS_OFF_DSM_SPI4_CFG_MAXBURST1) |
              ((spi4->ob.burst_size + 2) << VTSS_OFF_DSM_SPI4_CFG_SPI4_BURST_SIZE) |
              (0 << VTSS_OFF_DSM_SPI4_CFG_SPI4_ALTER_HIH_PLI_VALUE) |
              (0 << VTSS_OFF_DSM_SPI4_CFG_SPI4_STRIP_FCS) |
              ((spi4->ob.hih_enable ? 1 : 0) << VTSS_OFF_DSM_SPI4_CFG_SPI4_HDR_CFG));
        if (spi4->ob.clock_phase > VTSS_SPI4_CLOCK_PHASE_270) {
            VTSS_E(("illegal clock phase: %d", spi4->ob.clock_phase));
            return VTSS_INVALID_PARAMETER;
        }
        B2_WR(DEVSPI, SPI4_DDS_OB_CONFIG, 0,
              (vco << VTSS_OFF_DEVSPI_SPI4_DDS_OB_CONFIG_CONF_OB_VCO_RANGE) |
              (spi4->ob.clock_phase << VTSS_OFF_DEVSPI_SPI4_DDS_OB_CONFIG_CONF_OB_CLK_PHASE) |
              (cmu << VTSS_OFF_DEVSPI_SPI4_DDS_OB_CONFIG_CONF_OB_CMU_RATIO) |
              ((spi4->ob.data_swap ? 1 : 0) << 
               VTSS_OFF_DEVSPI_SPI4_DDS_OB_CONFIG_CONF_OB_DATA_SWAP) |
              ((spi4->ob.data_invert ? 0x1ffff : 0) << 
               VTSS_OFF_DEVSPI_SPI4_DDS_OB_CONFIG_CONF_OB_INV_DATA));
        B2_WR(DEVSPI, SPI4_IB_TC_CONFIG, 0,
              (1 << VTSS_OFF_DEVSPI_SPI4_IB_TC_CONFIG_CONF_IB_TC_NO_LOCK) |
              (1 << VTSS_OFF_DEVSPI_SPI4_IB_TC_CONFIG_CONF_IB_TC_ENA));
        B2_WR(DEVSPI, SPI4_IB_SYNC_CONFIG, 0,
              (1 << VTSS_OFF_DEVSPI_SPI4_IB_SYNC_CONFIG_CONF_IB_DIP4_RESYNC_EN) |
              (1 << VTSS_OFF_DEVSPI_SPI4_IB_SYNC_CONFIG_CONF_IB_FRC_DSKW_RESYNC));
        if (vtss_api_state->chip_id.revision == 2) {
            /* Revision B reset using IB_QUARTER_RATE field */
            B2_WRF(DEVSPI, SPI4_DDS_IB_CONFIG, CONF_IB_QUARTER_RATE, 0, 1);
        }
        VTSS_MSLEEP(500);
        B2_WR(DEVSPI, SPI4_IB_TC_CONFIG, 0,
              (1 << VTSS_OFF_DEVSPI_SPI4_IB_TC_CONFIG_CONF_IB_TC_NO_LOCK) |
              (0 << VTSS_OFF_DEVSPI_SPI4_IB_TC_CONFIG_CONF_IB_TC_ENA));
    
        /* Calendar */
        count = b2_lport_count();
        for (i = 0; i < count; i++) {
            B2_WRX(DEVSPI, SPI4_IBS_CALENDAR, i, 
                   (i + 48)<< VTSS_OFF_DEVSPI_SPI4_IBS_CALENDAR_CONF_IBS_CAL_VAL);
            B2_WRX(DEVSPI, SPI4_OBS_CALENDAR, i, 
                   (i + 48)<< VTSS_OFF_DEVSPI_SPI4_OBS_CALENDAR_CONF_OBS_CAL_VAL);
        }
        B2_WR(DEVSPI, SPI4_OBS_LINK_CONFIG, 0,
              (8 << VTSS_OFF_DEVSPI_SPI4_OBS_LINK_CONFIG_CONF_OBS_IDLE_THRESH) |
              (0 << VTSS_OFF_DEVSPI_SPI4_OBS_LINK_CONFIG_CONF_OBS_LINK_DOWN_DIS) |
              ((spi4->ob.link_up_limit - 1)<< 
               VTSS_OFF_DEVSPI_SPI4_OBS_LINK_CONFIG_CONF_OBS_LINKUP_LIM) |
              ((spi4->ob.link_down_limit - 1)<< 
               VTSS_OFF_DEVSPI_SPI4_OBS_LINK_CONFIG_CONF_OBS_LINKDN_LIM));
        B2_WR(DEVSPI, SPI4_OBS_CONFIG, 0,
              ((spi4->ob.clock_shift ? 1 : 0) << 
               VTSS_OFF_DEVSPI_SPI4_OBS_CONFIG_CONF_OBS_CLK_SHIFT) | 
              (0 << VTSS_OFF_DEVSPI_SPI4_OBS_CONFIG_CONF_OBS_CAL_M) |
              (count << VTSS_OFF_DEVSPI_SPI4_OBS_CONFIG_CONF_OBS_CAL_LEN));
        B2_WR(DEVSPI, SPI4_OB_TRAIN_CONFIG, 0,
              ((spi4->ob.training_mode == VTSS_SPI4_TRAINING_AUTO ? 1 : 0) <<
               VTSS_OFF_DEVSPI_SPI4_OB_TRAIN_CONFIG_CONF_OB_ENA_AUTO_TRAINING) |
              ((spi4->ob.training_mode == VTSS_SPI4_TRAINING_FORCED ? 1 : 0) <<
               VTSS_OFF_DEVSPI_SPI4_OB_TRAIN_CONFIG_CONF_OB_SEND_TRAINING) |
              (spi4->ob.alpha << VTSS_OFF_DEVSPI_SPI4_OB_TRAIN_CONFIG_CONF_OB_ALPHA_MAX_T) |
              ((spi4->ob.training_mode == VTSS_SPI4_TRAINING_DISABLED ? 0 : 
                (spi4->ob.data_max_t/128)) << 
               VTSS_OFF_DEVSPI_SPI4_OB_TRAIN_CONFIG_CONF_OB_DATA_MAX_T));
        B2_WR(DEVSPI, SPI4_IBS_CONFIG, 0,
              ((spi4->ib.clock_shift ? 1 : 0) << 
               VTSS_OFF_DEVSPI_SPI4_IBS_CONFIG_CONF_IBS_CLK_SHIFT) |
              (0 << VTSS_OFF_DEVSPI_SPI4_IBS_CONFIG_CONF_IBS_FORCE_IDLE) |
              (1 << VTSS_OFF_DEVSPI_SPI4_IBS_CONFIG_CONF_IBS_DSKW_GENS_IDLE) |
              (1 << VTSS_OFF_DEVSPI_SPI4_IBS_CONFIG_CONF_IBS_DIP4_GENS_IDLE) |
              (0 << VTSS_OFF_DEVSPI_SPI4_IBS_CONFIG_CONF_IBS_CAL_M) |
              (count << VTSS_OFF_DEVSPI_SPI4_IBS_CONFIG_CONF_IBS_CAL_LEN));
    }

    /* Clear sticky bits */
    B2_WR(DEVSPI, SPI4_IB_STICKY, 0, 0xffffffff); 
    B2_WR(DEVSPI, SPI4_OB_STICKY, 0, 0xffffffff); 
    B2_WR(DEVSPI, SPI4_OBS_STICKY, 0, 0xffffffff); 

    /* Clear counters */
    B2_WR(DEVSPI, SPI4_IB_DIP4_ERR_CNT, 0, 0);
    B2_WR(DEVSPI, SPI4_IB_PKT_CNT, 0, 0);
    B2_WR(DEVSPI, SPI4_IB_EOPA_CNT, 0, 0);
    B2_WR(DEVSPI, SPI4_IB_BYTE_CNT, 0, 0);
    B2_WR(DEVSPI, SPI4_OB_PKT_CNT, 0, 0);
    B2_WR(DEVSPI, SPI4_OB_EOPA_CNT, 0, 0);
    B2_WR(DEVSPI, SPI4_OB_BYTE_CNT, 0, 0);
    B2_WR(DEVSPI, SPI4_OBS_DIP2_ERR_CNT, 0, 0);

    return VTSS_OK;
}

/* Initialize XAUI */
static vtss_rc b2_xaui_init(int host_mode)
{
    vtss_xaui_setup_t *xaui;
    uint              port, port_min, port_max, i, count, offs;
    vtss_port_setup_t setup;
    
    if (host_mode > 3 && host_mode < 8) {
        /* SPI4 mode */
        return VTSS_OK;
    }

    /* XAUI setup */
    xaui = &vtss_api_state->init_setup.xaui;
    port_min = ((host_mode == 1 || host_mode == 11) ? 25 : 24);
    port_max = ((host_mode == 0 || host_mode == 10) ? 24 : 25);
    count = b2_lport_count()/(port_max - port_min + 1);
    memset(&setup, 0, sizeof(setup));
    setup.interface_mode.interface_type = VTSS_PORT_INTERFACE_XAUI;
    setup.interface_mode.speed = VTSS_SPEED_10G;
    setup.fdx = 1;
    setup.flowcontrol.obey = xaui->fc.obey_pause;
    setup.maxframelength = VTSS_MAXFRAMELENGTH_MAX;
    for (port = port_min; port <= port_max; port++) {
        VTSS_RC(b2_xaui_port_setup(port, &setup));

        /* Enable HIH checksum */
        B2_WRX(ASM, HIH_CFG, port - 24, 
               (xaui->hih.cksum_enable ? 1 : 0) << VTSS_OFF_ASM_HIH_CFG_HIH_CHK_ENA);

        /* Shaper */
        VTSS_RC(b2_shaper_setup(port, &xaui->qos.shaper));
        
        /* Status channel */
        offs = ((host_mode == 3 && port == 25) ? 36 : (host_mode == 8 && port == 25) ? 72 :
                (host_mode == 9 && port == 25) ? 56 : (host_mode < 8) ? 24 : 48);
        for (i = 0; i < count; i++) {
            VTSS_RC(b2_wr(VTSS_TGT_XAUI_PHY_STAT, 
                          VTSS_ADDX_XAUI_PHY_STAT_XAUI_IBS_CAL(i), port,
                          (i + offs) << VTSS_OFF_XAUI_PHY_STAT_XAUI_IBS_CAL_CONF_IBS_CAL_VAL));
            VTSS_RC(b2_wr(VTSS_TGT_XAUI_PHY_STAT, 
                          VTSS_ADDX_XAUI_PHY_STAT_XAUI_OBS_CAL(i), port,
                          (i + offs) << VTSS_OFF_XAUI_PHY_STAT_XAUI_OBS_CAL_CONF_OBS_CAL_VAL));
        }
        B2_WR(XAUI_PHY_STAT, XAUI_IBS_CFG, port, 
              (0 << VTSS_OFF_XAUI_PHY_STAT_XAUI_IBS_CFG_CONF_IBS_CLK_SOURCE) |
              ((xaui->ib.clock_shift ? 1 : 0) << 
               VTSS_OFF_XAUI_PHY_STAT_XAUI_IBS_CFG_CONF_IBS_CLK_SHIFT) |
              (0 << VTSS_OFF_XAUI_PHY_STAT_XAUI_IBS_CFG_CONF_IBS_FORCE_IDLE) |
              (0 << VTSS_OFF_XAUI_PHY_STAT_XAUI_IBS_CFG_CONF_IBS_CAL_M) |
              (count << VTSS_OFF_XAUI_PHY_STAT_XAUI_IBS_CFG_CONF_IBS_CAL_LEN));
        B2_WR(XAUI_PHY_STAT, XAUI_OBS_CFG, port, 
              ((xaui->ob.clock_shift ? 1 : 0) << 
               VTSS_OFF_XAUI_PHY_STAT_XAUI_OBS_CFG_CONF_OBS_CLK_SHIFT) |
              (0 << VTSS_OFF_XAUI_PHY_STAT_XAUI_OBS_CFG_CONF_OBS_CAL_M) |
              (count << VTSS_OFF_XAUI_PHY_STAT_XAUI_OBS_CFG_CONF_OBS_CAL_LEN));
    }
    return VTSS_OK;
}    

/* Setup port map */
vtss_rc vtss_ll_port_map_set(const vtss_mapped_port_t mapped_ports[VTSS_PORT_ARRAY_SIZE])
{
    vtss_port_no_t  port_no;
    int             host_mode, chip_port, max_port;
    uint            aport, dport;
    vtss_lport_no_t lport_no;

    host_mode = vtss_api_state->init_setup.host_mode;

     /* Converter/aggregator mode, fixed host port mapping */
    if (host_mode > 6)
        return VTSS_OK;
    
    /* Check and store host port numbers */
    max_port = (host_mode == 6 ? 1 : 23);
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        chip_port = mapped_ports[port_no].chip_port;
        if (chip_port < 0)
            continue;
        lport_no = mapped_ports[port_no].lport_no;
        if (lport_no == VTSS_LPORT_MAP_DEFAULT) /* Default mapping */
            lport_no = (port_no - VTSS_PORT_NO_START);
        if (lport_no > max_port) {
            VTSS_E(("illegal lport_no: %d for port_no: %d, host mode: %u", 
                    lport_no, port_no, host_mode));
            return VTSS_INVALID_PARAMETER;
        }
        vtss_api_state->port_map.lport_no[port_no] = lport_no;
        aport = b2_port2line(chip_port);
        dport = (lport_no + (host_mode < 4 ? 24 : 48));
        vtss_api_state->dep_port[aport] = dport;
#ifdef VTSS_IO_RABBIT
        /* For loopback test, 0<->1, 2<->3, ... , 22<->23 */
        aport = ((aport & 1) ? (aport - 1) : (aport + 1)); 
#endif /* VTSS_IO_RABBIT */
        vtss_api_state->dep_port[dport] = aport;
    }
    
    /* Update chip mappings */
    VTSS_RC(b2_qss_setup());
    VTSS_RC(b2_xaui_init(host_mode));
    VTSS_RC(b2_spi4_init(host_mode));
    return VTSS_OK;
}

/* Setup PSI */
vtss_rc vtss_ll_psi_set(const uint clock)
{
    ulong value;

    value = (clock ? (9765625/clock) : 0); /* 312.500.000/(32*clock) - 1 */
    if (value > 255)
        value = 255;
    else if (value != 0)
        value--;
    B2_WR(FAST_REGS, PSI_CFG, 0, 
          (value << VTSS_OFF_FAST_REGS_PSI_CFG_PSI_CFG_PRESCALE) |
          ((clock ? 1 : 0) << VTSS_OFF_FAST_REGS_PSI_CFG_PSI_ENABLE));
    
    return VTSS_OK;
}

vtss_rc vtss_ll_init(const vtss_init_setup_t *setup)
{
    ulong value;
    int   host_mode, port;
    
    /* Mark all internal ports as unused */
    for (port = 0; port < VTSS_INT_PORT_COUNT; port++)
        vtss_api_state->dep_port[port] = -1;

    /* Check host mode */
    host_mode = setup->host_mode;
    if (host_mode > 9 || host_mode == 2 || 
#if defined(VTSS_CHIP_SCHAUMBURG_II)
        host_mode == 3 || host_mode > 5 ||
#endif /* VTSS_CHIP_SCHAUMBURG_II */
#if defined(VTSS_CHIP_EXEC_1)
        host_mode < 6 ||
#endif /* VTSS_CHIP_EXEC_1 */
        host_mode == 7) {
        VTSS_E(("illegal host_mode: %d", host_mode));
        return VTSS_INVALID_PARAMETER;
    }
    VTSS_D(("host_mode: %d", host_mode));

    /* Setup PI */
    if (setup->pi_cs_wait_ns > 200) {
        VTSS_E(("illegal pi_cs_wait_ns: %u", setup->pi_cs_wait_ns));
        return VTSS_INVALID_PARAMETER;
    }
    value = ((setup->pi_cs_wait_ns/13) << VTSS_OFF_FAST_REGS_CFG_STATUS_2_PI_WAIT);
    B2_WR(FAST_REGS, CFG_STATUS_2, 0, value);
    
    /* Read chip ID */
    VTSS_RC(vtss_ll_chipid_get(&vtss_api_state->chip_id));

    /* Reset chip */
    B2_WR(DEVCPU_GCB, DEVCPU_RST_REGS, 0, 
          (0 << VTSS_OFF_DEVCPU_GCB_DEVCPU_RST_REGS_AUTO_BIST_DISABLE) |
          (0 << VTSS_OFF_DEVCPU_GCB_DEVCPU_RST_REGS_MEMLOCK_ENABLE) |
          (1 << VTSS_OFF_DEVCPU_GCB_DEVCPU_RST_REGS_SOFT_CHIP_RST) |
          (0 << VTSS_OFF_DEVCPU_GCB_DEVCPU_RST_REGS_SOFT_NON_CFG_RST));
    VTSS_MSLEEP(10);
    
    /* Setup PI again */
    B2_WR(FAST_REGS, CFG_STATUS_2, 0, value);

    /* Setup host mode */
    B2_WR(DEVCPU_GCB, CHIP_MODE, 0,
          ((setup->spi4.ob.frame_interleave ? 0 : 1) << 
           VTSS_OFF_DEVCPU_GCB_CHIP_MODE_SPI4_INTERLEAVE_MODE) |
          ((setup->xaui.hih.format == VTSS_HIH_PRE_SFD ? 1 : 0) << 
           VTSS_OFF_DEVCPU_GCB_CHIP_MODE_XAUI_TAG_FORM) |
          (host_mode << VTSS_OFF_DEVCPU_GCB_CHIP_MODE_HOST_MODE));
    VTSS_MSLEEP(10);
    
    /* ANA_CL and ANA_AC initialization */
    VTSS_RC(b2_ana_init(setup));

    /* ASM initialization */
    VTSS_RC(b2_asm_init(host_mode));

    /* QSS initialization */
    VTSS_RC(b2_qss_init(setup, host_mode));
    
    /* SCH initialization */
    VTSS_RC(b2_sch_init(setup));
    
    /* DSM initialization */
    VTSS_RC(b2_dsm_init());

    /* For normal MAC modes, SPI4/XAUI is initialized after port map setup */
    if (host_mode > 6) {
        /* SPI4.2 initialization */
        VTSS_RC(b2_spi4_init(host_mode));
        
        /* XAUI initialization */
        VTSS_RC(b2_xaui_init(host_mode));
    }
    
    /* QoS and filter initialization */
    for (port = 0; port < 26; port++) {

        if (VTSS_PORT_IS_1G(port)) {
        } else {
            B2_WR(DEV10G, MAC_TX_MONITOR_STICKY, port, 0xffffffff);
        }
        VTSS_RC(b2_port_qos_set(port, &vtss_api_state->qos[1]));
        VTSS_RC(vtss_ll_port_filter_set(port, &vtss_api_state->filter[1]));
    }
    return VTSS_OK;
}


#if defined(VTSS_GPIOS)

/* ================================================================= *
 *  GPIO's
 * ================================================================= */

/* Set GPIO direction, read:0  write:1 */
vtss_rc vtss_ll_gpio_direction_set(vtss_gpio_no_t gpio_no, BOOL output)
{
    b2_wrf(VTSS_TGT_DEVCPU_GCB, VTSS_ADDR_DEVCPU_GCB_GPIO_OUTPUT_ENA, gpio_no, 1, 0, output);
    return VTSS_OK;
}

/* Read GPIO input pin */
vtss_rc vtss_ll_gpio_input_read(vtss_gpio_no_t gpio_no, BOOL *value)
{
    ulong val;
    if (gpio_no >= VTSS_GPIO_NO_START && gpio_no < VTSS_GPIO_NO_END) {
        b2_rdf(VTSS_TGT_DEVCPU_GCB, VTSS_ADDR_DEVCPU_GCB_GPIO_I, gpio_no, 1, 0, &val);
        *value=MAKEBOOL01(val);
        return VTSS_OK;
    } 
    VTSS_E(("illegal gpio_no: %d",gpio_no));
    return VTSS_INVALID_PARAMETER;
}

/* Write GPIO output pin */
vtss_rc vtss_ll_gpio_output_write(vtss_gpio_no_t gpio_no, BOOL value)
{
    if (gpio_no >= VTSS_GPIO_NO_START && gpio_no < VTSS_GPIO_NO_END) {
        b2_wrf(VTSS_TGT_DEVCPU_GCB, VTSS_ADDR_DEVCPU_GCB_GPIO_O, gpio_no, 1, 0, value);
        return VTSS_OK;
    }
    
    VTSS_E(("illegal gpio_no: %d",gpio_no));
    return VTSS_INVALID_PARAMETER;
}
#endif

/* ================================================================= *
 *  Interrupts
 * ================================================================= */

/* Set the interrupt masks      */
vtss_rc vtss_ll_intr_mask_set(vtss_intr_t *mask) {
    vtss_port_no_t port_no;
    int            chip_port;    
    long           rev_id;
    ulong          reg_mask,value,val_tmp = 0;
    BOOL           if_100fx=0, if_xaui=0;  

    /****  Set link change interrupt on XAUI 100FX or 1000-X ports   ****/
    /*  Chip Rev 01 only supports 1000-X ports.  The interrupts         */
    /*  are enabled on device level as well as for each sticky bit.     */
    /*  The sticky bits are initially cleared.                           */

    /* Get chip rev id                        */
    B2_RDF(DEVCPU_GCB, CHIP_ID, REV_ID, 0, &rev_id);

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        
        chip_port = vtss_api_state->port_map.chip_port[port_no];

        if_100fx = 0;
        if_xaui = 0;
        if (vtss_api_state->setup[port_no].interface_mode.interface_type == VTSS_PORT_INTERFACE_100FX) {
            if_100fx = 1;
        } else if (vtss_api_state->setup[port_no].interface_mode.interface_type == VTSS_PORT_INTERFACE_XAUI) {
            if_xaui = 1;
        } else if (vtss_api_state->setup[port_no].interface_mode.interface_type != VTSS_PORT_INTERFACE_SERDES) {
            continue;
        } 
        
        /* Link change interrupt not supported for XAUI and 100FX in chip rev 1     */
        if (((rev_id == 1) && if_xaui) || ((rev_id == 1) && if_100fx))
            continue;
                
        /* Enable/disable sticky bit interrupt mask   */
        if (if_xaui) {
            /* XAUI       */
//            B2_WR(DEV10G, DEV_STICKY, chip_port, 0x3000000);   /* Clear the sticky */
//            B2_WRF(DEV10G, DEV_INT_MASK, LINK_UP_MASK, chip_port, mask->link_change[port_no]);
//            B2_WRF(DEV10G, DEV_INT_MASK, LINK_DOWN_MASK, chip_port, mask->link_change[port_no]);
        } else if (if_100fx) {
            /* 100-FX     */
            B2_WR(DEV1G, FX100_STICKY, chip_port, 0x3);  /* Clear the sticky */
            B2_WRF(DEV1G, FX100_INT_MASK, FX100_LINK_UP_INT_MASK, chip_port, mask->link_change[port_no]);
            B2_WRF(DEV1G, FX100_INT_MASK, FX100_LINK_DOWN_INT_MASK, chip_port, mask->link_change[port_no]);            
        } else {
            /* 1000-X     */
            B2_WR(DEV1G, PCS1G_STICKY, chip_port, 0x30); /* Clear the sticky */
            B2_WRF(DEV1G, PCS1G_INT_MASK, LINK_UP_INT_MASK, chip_port, mask->link_change[port_no]);
            B2_WRF(DEV1G, PCS1G_INT_MASK, LINK_DOWN_INT_MASK, chip_port, mask->link_change[port_no]);
        }

        /* Enable/disable dev1g/dev10g port device interrupts    */
        if (if_xaui) {
            if (port_no == 1) {
                reg_mask = 1 << VTSS_OFF_FAST_REGS_INT_ENABLE_3_XAUI_INT_ENABLE_0;
                value = mask->link_change[port_no] << VTSS_OFF_FAST_REGS_INT_ENABLE_3_XAUI_INT_ENABLE_0;
            } else {
                reg_mask = 1 << VTSS_OFF_FAST_REGS_INT_ENABLE_3_XAUI_INT_ENABLE_1;
                value = mask->link_change[port_no] << VTSS_OFF_FAST_REGS_INT_ENABLE_3_XAUI_INT_ENABLE_1;
            }
            B2_RD(FAST_REGS, INT_ENABLE_3, 0, &val_tmp);            
            reg_mask = 0xFFFF^reg_mask;
            value = value | (val_tmp & reg_mask);
            B2_WR(FAST_REGS, INT_ENABLE_3, 0, value);            
        } else {
            if (chip_port < 16) {
                reg_mask = 1 << (15-chip_port);
                value = mask->link_change[port_no] << (15-chip_port);
                B2_RD(FAST_REGS, INT_ENABLE_1, 0, &val_tmp);            
                reg_mask = 0xFFFF^reg_mask;
                value = value | (val_tmp & reg_mask);
                B2_WR(FAST_REGS, INT_ENABLE_1, 0, value);            
            } else {
                reg_mask = 1 << (23-chip_port);
                value = mask->link_change[port_no] << (23-chip_port);
                B2_RD(FAST_REGS, INT_ENABLE_2, 0, &val_tmp);            
                reg_mask = 0xFF^reg_mask;
                value = value | (val_tmp & reg_mask);
                B2_WR(FAST_REGS, INT_ENABLE_2, 0, value);            
            }            
        }
    }       
    return VTSS_OK;
}

/* Get the status of the interrupt sources    */
vtss_rc vtss_ll_intr_status_get(vtss_intr_t *status) {
    vtss_port_no_t port_no;
    int            chip_port;    
    long           int_status, intr=0, value, mask;
    BOOL           dev1g_intr_en;
    BOOL           if_100fx=0, if_xaui=0;  


    /****  Get link change interrupt status XAUI, 100FX or 1000-X ports *****/    
    /* The status is checked on device level before checking each sticky bit */    
    /* Only sticky bits with the interrupt mask enabled are checked.         */    
    /* The sticky bits are cleared after reading.                            */    

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        chip_port = vtss_api_state->port_map.chip_port[port_no];

        if_100fx = 0;
        if_xaui = 0;
        if (vtss_api_state->setup[port_no].interface_mode.interface_type == VTSS_PORT_INTERFACE_100FX) {
            if_100fx = 1;
        } else if (vtss_api_state->setup[port_no].interface_mode.interface_type == VTSS_PORT_INTERFACE_XAUI) {
            if_xaui = 1;
        } else if (vtss_api_state->setup[port_no].interface_mode.interface_type != VTSS_PORT_INTERFACE_SERDES) {
            continue;
        } 
        
        if (if_xaui) {
            continue; /*  10G not supported for this release     */
            /* Get the device level interrupt status   */
            B2_RD(FAST_REGS, INT_STATUS_3, 0, &int_status);
            /* Check if dev10g interrupt is enabled           */
            if (MAKEBOOL01(int_status & (1<<(1^(port_no-1))))) {
//                B2_RDF(DEV10G, DEV_INT_MASK, LINK_UP_MASK, chip_port, mask);
                if(mask) {
                    B2_RD(DEV10G, DEV_STICKY, chip_port, &value);
                    B2_WR(DEV10G, DEV_STICKY, chip_port, 0x3000000);   /* Clear the sticky */
                }
                /* Return  Link up || link down sticky        */
                status->link_change[port_no] = MAKEBOOL01(value & (24<<3));
            }            
        } else {
            /* Check if dev1g interrupt is enabled            */
            if (port_no < 17) {
                /* Get the device level interrupt status   */
                B2_RD(FAST_REGS, INT_STATUS_1, 0, &int_status);
                dev1g_intr_en = MAKEBOOL01(int_status & (1<<(0xf^chip_port)));
            } else {
                /* Get the device level interrupt status   */
                B2_RD(FAST_REGS, INT_STATUS_2, 0, &int_status);
                dev1g_intr_en = MAKEBOOL01(int_status & (1<<(0x17^chip_port)));
            }
                        
            if (dev1g_intr_en) {                
                /* dev1g interrupt is enabled.  */
                
                if (if_100fx) {
                    /* 100-FX  */
                    B2_RDF(DEV1G, FX100_INT_MASK, FX100_LINK_UP_INT_MASK, chip_port, &mask);
                    if(mask) {
                        B2_RD(DEV1G, FX100_STICKY, chip_port, &intr);
                        B2_WR(DEV1G, FX100_STICKY, chip_port, 0x3);  /* Clear the sticky */
                        status->link_change[port_no] = MAKEBOOL01(intr & (3<<0));
                    }
                } else {                    
                    /* 1000-X  */
                    B2_RDF(DEV1G, PCS1G_INT_MASK, LINK_UP_INT_MASK, chip_port, &mask);
                    if(mask) {
                        B2_RD(DEV1G, PCS1G_STICKY, chip_port, &intr);              
                        B2_WR(DEV1G, PCS1G_STICKY, chip_port, 0x30); /* Clear the sticky */
                        status->link_change[port_no] = MAKEBOOL01(intr & (3<<4));
                    }
                }               
            } else {
                status->link_change[port_no] = 0;
            }
        }
    }
    return VTSS_OK;
}
