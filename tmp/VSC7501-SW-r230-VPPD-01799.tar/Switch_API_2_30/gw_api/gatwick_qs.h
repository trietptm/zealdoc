/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: gatwick_qs.h,v 1.22 2008/02/20 15:04:52 cpj Exp $
 $Revision: 1.22 $
 
*/

/* Gatwick queue system settings */

/* Tx Pause values for 1G port and 10G port */
#define GW_PAUSE_VAL_FC_1G                0xffff
#define GW_PAUSE_VAL_FC_10G               0xffff

/* Flow control mode, 1G port, standard frame size */
#define GW_IN_WM_HIGH_FC_1G               9
#define GW_IN_WM_LOW_FC_1G                6
#define GW_IN_QUEUE_LVL_3_FC_1G           127
#define GW_IN_QUEUE_LVL_2_FC_1G           127
#define GW_IN_QUEUE_LVL_1_FC_1G           127
#define GW_IN_QUEUE_LVL_0_FC_1G           127
#define GW_IN_PORT_LVL_FC_1G              17

#define GW_EG_WM_HIGH_FC_1G               11
#define GW_EG_WM_LOW_FC_1G                11
#define GW_EG_QUEUE_LVL_3_FC_1G           18
#define GW_EG_QUEUE_LVL_2_FC_1G           18
#define GW_EG_QUEUE_LVL_1_FC_1G           18 
#define GW_EG_QUEUE_LVL_0_FC_1G           18
#define GW_EG_PORT_LVL_FC_1G              18

/* Flow control mode, 1G port, jumbo frame size */
#define GW_IN_WM_HIGH_FC_1G_JUMBO         4
#define GW_IN_WM_LOW_FC_1G_JUMBO          4
#define GW_IN_QUEUE_LVL_3_FC_1G_JUMBO     140
#define GW_IN_QUEUE_LVL_2_FC_1G_JUMBO     140
#define GW_IN_QUEUE_LVL_1_FC_1G_JUMBO     140
#define GW_IN_QUEUE_LVL_0_FC_1G_JUMBO     140
#define GW_IN_PORT_LVL_FC_1G_JUMBO        20

#define GW_EG_WM_HIGH_FC_1G_JUMBO         2
#define GW_EG_WM_LOW_FC_1G_JUMBO          2
#define GW_EG_QUEUE_LVL_3_FC_1G_JUMBO     63
#define GW_EG_QUEUE_LVL_2_FC_1G_JUMBO     63
#define GW_EG_QUEUE_LVL_1_FC_1G_JUMBO     63
#define GW_EG_QUEUE_LVL_0_FC_1G_JUMBO     63
#define GW_EG_PORT_LVL_FC_1G_JUMBO        63

/* Flow control mode, 10G port, standard frame size */
#define GW_IN_WM_HIGH_FC_10G              46
#define GW_IN_WM_LOW_FC_10G               40
#define GW_IN_QUEUE_LVL_3_FC_10G          0
#define GW_IN_QUEUE_LVL_2_FC_10G          0
#define GW_IN_QUEUE_LVL_1_FC_10G          0
#define GW_IN_QUEUE_LVL_0_FC_10G          0
#define GW_IN_PORT_LVL_FC_10G             0

#define GW_EG_WM_HIGH_FC_10G              55
#define GW_EG_WM_LOW_FC_10G               55
#define GW_EG_QUEUE_LVL_3_FC_10G          63
#define GW_EG_QUEUE_LVL_2_FC_10G          63
#define GW_EG_QUEUE_LVL_1_FC_10G          63
#define GW_EG_QUEUE_LVL_0_FC_10G          63
#define GW_EG_PORT_LVL_FC_10G             63

/* Flow control mode, 10G port, jumbo frame size */
#define GW_IN_WM_HIGH_FC_10G_JUMBO        21
#define GW_IN_WM_LOW_FC_10G_JUMBO         21
#define GW_IN_QUEUE_LVL_3_FC_10G_JUMBO    0
#define GW_IN_QUEUE_LVL_2_FC_10G_JUMBO    0
#define GW_IN_QUEUE_LVL_1_FC_10G_JUMBO    0
#define GW_IN_QUEUE_LVL_0_FC_10G_JUMBO    0
#define GW_IN_PORT_LVL_FC_10G_JUMBO       0

#define GW_EG_WM_HIGH_FC_10G_JUMBO        44
#define GW_EG_WM_LOW_FC_10G_JUMBO         44
#define GW_EG_QUEUE_LVL_3_FC_10G_JUMBO    63
#define GW_EG_QUEUE_LVL_2_FC_10G_JUMBO    63
#define GW_EG_QUEUE_LVL_1_FC_10G_JUMBO    63
#define GW_EG_QUEUE_LVL_0_FC_10G_JUMBO    63
#define GW_EG_PORT_LVL_FC_10G_JUMBO       63

/* Drop mode, 1G port, standard frame size, 4 priorities */
#define GW_IN_WM_HIGH_DROP_1G_PRIO_4      15
#define GW_IN_WM_LOW_DROP_1G_PRIO_4       15
#define GW_IN_QUEUE_LVL_3_DROP_1G_PRIO_4  127
#define GW_IN_QUEUE_LVL_2_DROP_1G_PRIO_4  127
#define GW_IN_QUEUE_LVL_1_DROP_1G_PRIO_4  127
#define GW_IN_QUEUE_LVL_0_DROP_1G_PRIO_4  127
#define GW_IN_PORT_LVL_DROP_1G_PRIO_4     17

#define GW_EG_WM_HIGH_DROP_1G_PRIO_4      2
#define GW_EG_WM_LOW_DROP_1G_PRIO_4       2
#define GW_EG_QUEUE_LVL_3_DROP_1G_PRIO_4  16
#define GW_EG_QUEUE_LVL_2_DROP_1G_PRIO_4  6
#define GW_EG_QUEUE_LVL_1_DROP_1G_PRIO_4  6
#define GW_EG_QUEUE_LVL_0_DROP_1G_PRIO_4  6
#define GW_EG_PORT_LVL_DROP_1G_PRIO_4     24

/* Drop mode, 1G port, standard frame size, 2 priorities */
#define GW_IN_WM_HIGH_DROP_1G_PRIO_2      15
#define GW_IN_WM_LOW_DROP_1G_PRIO_2       15
#define GW_IN_QUEUE_LVL_3_DROP_1G_PRIO_2  127
#define GW_IN_QUEUE_LVL_2_DROP_1G_PRIO_2  127
#define GW_IN_QUEUE_LVL_1_DROP_1G_PRIO_2  127
#define GW_IN_QUEUE_LVL_0_DROP_1G_PRIO_2  127
#define GW_IN_PORT_LVL_DROP_1G_PRIO_2     17

#define GW_EG_WM_HIGH_DROP_1G_PRIO_2      2
#define GW_EG_WM_LOW_DROP_1G_PRIO_2       2
#define GW_EG_QUEUE_LVL_3_DROP_1G_PRIO_2  16
#define GW_EG_QUEUE_LVL_2_DROP_1G_PRIO_2  8
#define GW_EG_QUEUE_LVL_1_DROP_1G_PRIO_2  0
#define GW_EG_QUEUE_LVL_0_DROP_1G_PRIO_2  0
#define GW_EG_PORT_LVL_DROP_1G_PRIO_2     16

/* Drop mode, 1G port, standard frame size, 1 priorities */
#define GW_IN_WM_HIGH_DROP_1G_PRIO_1      15
#define GW_IN_WM_LOW_DROP_1G_PRIO_1       15
#define GW_IN_QUEUE_LVL_3_DROP_1G_PRIO_1  127
#define GW_IN_QUEUE_LVL_2_DROP_1G_PRIO_1  127
#define GW_IN_QUEUE_LVL_1_DROP_1G_PRIO_1  127
#define GW_IN_QUEUE_LVL_0_DROP_1G_PRIO_1  127
#define GW_IN_PORT_LVL_DROP_1G_PRIO_1     17

#define GW_EG_WM_HIGH_DROP_1G_PRIO_1      12
#define GW_EG_WM_LOW_DROP_1G_PRIO_1       12
#define GW_EG_QUEUE_LVL_3_DROP_1G_PRIO_1  16
#define GW_EG_QUEUE_LVL_2_DROP_1G_PRIO_1  16
#define GW_EG_QUEUE_LVL_1_DROP_1G_PRIO_1  16
#define GW_EG_QUEUE_LVL_0_DROP_1G_PRIO_1  16
#define GW_EG_PORT_LVL_DROP_1G_PRIO_1     16

/* Drop mode, 10G port, standard frame size, 4 priorities */
#define GW_IN_WM_HIGH_DROP_10G_PRIO_4     56
#define GW_IN_WM_LOW_DROP_10G_PRIO_4      56
#define GW_IN_QUEUE_LVL_3_DROP_10G_PRIO_4 511
#define GW_IN_QUEUE_LVL_2_DROP_10G_PRIO_4 511
#define GW_IN_QUEUE_LVL_1_DROP_10G_PRIO_4 511
#define GW_IN_QUEUE_LVL_0_DROP_10G_PRIO_4 511
#define GW_IN_PORT_LVL_DROP_10G_PRIO_4    63

#define GW_EG_WM_HIGH_DROP_10G_PRIO_4     8
#define GW_EG_WM_LOW_DROP_10G_PRIO_4      8
#define GW_EG_QUEUE_LVL_3_DROP_10G_PRIO_4 63
#define GW_EG_QUEUE_LVL_2_DROP_10G_PRIO_4 16
#define GW_EG_QUEUE_LVL_1_DROP_10G_PRIO_4 16
#define GW_EG_QUEUE_LVL_0_DROP_10G_PRIO_4 16
#define GW_EG_PORT_LVL_DROP_10G_PRIO_4    63

/* Drop mode, 10G port, standard frame size, 2 priorities */
#define GW_IN_WM_HIGH_DROP_10G_PRIO_2     56
#define GW_IN_WM_LOW_DROP_10G_PRIO_2      56
#define GW_IN_QUEUE_LVL_3_DROP_10G_PRIO_2 511
#define GW_IN_QUEUE_LVL_2_DROP_10G_PRIO_2 511
#define GW_IN_QUEUE_LVL_1_DROP_10G_PRIO_2 1
#define GW_IN_QUEUE_LVL_0_DROP_10G_PRIO_2 1
#define GW_IN_PORT_LVL_DROP_10G_PRIO_2    63

#define GW_EG_WM_HIGH_DROP_10G_PRIO_2     24
#define GW_EG_WM_LOW_DROP_10G_PRIO_2      24
#define GW_EG_QUEUE_LVL_3_DROP_10G_PRIO_2 63
#define GW_EG_QUEUE_LVL_2_DROP_10G_PRIO_2 32
#define GW_EG_QUEUE_LVL_1_DROP_10G_PRIO_2 0
#define GW_EG_QUEUE_LVL_0_DROP_10G_PRIO_2 0
#define GW_EG_PORT_LVL_DROP_10G_PRIO_2    63

/* Drop mode, 10G port, standard frame size, 1 priorities */
#define GW_IN_WM_HIGH_DROP_10G_PRIO_1     56
#define GW_IN_WM_LOW_DROP_10G_PRIO_1      56
#define GW_IN_QUEUE_LVL_3_DROP_10G_PRIO_1 511
#define GW_IN_QUEUE_LVL_2_DROP_10G_PRIO_1 511
#define GW_IN_QUEUE_LVL_1_DROP_10G_PRIO_1 511
#define GW_IN_QUEUE_LVL_0_DROP_10G_PRIO_1 511
#define GW_IN_PORT_LVL_DROP_10G_PRIO_1    63

#define GW_EG_WM_HIGH_DROP_10G_PRIO_1     55
#define GW_EG_WM_LOW_DROP_10G_PRIO_1      55
#define GW_EG_QUEUE_LVL_3_DROP_10G_PRIO_1 63
#define GW_EG_QUEUE_LVL_2_DROP_10G_PRIO_1 63
#define GW_EG_QUEUE_LVL_1_DROP_10G_PRIO_1 63
#define GW_EG_QUEUE_LVL_0_DROP_10G_PRIO_1 63
#define GW_EG_PORT_LVL_DROP_10G_PRIO_1    63

/* Drop mode, 1G port, jumbo frame size */
#define GW_IN_WM_HIGH_DROP_1G_JUMBO       15
#define GW_IN_WM_LOW_DROP_1G_JUMBO        15
#define GW_IN_QUEUE_LVL_3_DROP_1G_JUMBO   127
#define GW_IN_QUEUE_LVL_2_DROP_1G_JUMBO   127
#define GW_IN_QUEUE_LVL_1_DROP_1G_JUMBO   127
#define GW_IN_QUEUE_LVL_0_DROP_1G_JUMBO   127
#define GW_IN_PORT_LVL_DROP_1G_JUMBO      17

#define GW_EG_WM_HIGH_DROP_1G_JUMBO       10
#define GW_EG_WM_LOW_DROP_1G_JUMBO        10
#define GW_EG_QUEUE_LVL_3_DROP_1G_JUMBO   16
#define GW_EG_QUEUE_LVL_2_DROP_1G_JUMBO   16
#define GW_EG_QUEUE_LVL_1_DROP_1G_JUMBO   16
#define GW_EG_QUEUE_LVL_0_DROP_1G_JUMBO   16
#define GW_EG_PORT_LVL_DROP_1G_JUMBO      16

/* Drop mode, 10G port, jumbo frame size */
#define GW_IN_WM_HIGH_DROP_10G_JUMBO      46
#define GW_IN_WM_LOW_DROP_10G_JUMBO       46
#define GW_IN_QUEUE_LVL_3_DROP_10G_JUMBO  511
#define GW_IN_QUEUE_LVL_2_DROP_10G_JUMBO  511
#define GW_IN_QUEUE_LVL_1_DROP_10G_JUMBO  511
#define GW_IN_QUEUE_LVL_0_DROP_10G_JUMBO  511
#define GW_IN_PORT_LVL_DROP_10G_JUMBO     63

#define GW_EG_WM_HIGH_DROP_10G_JUMBO      34
#define GW_EG_WM_LOW_DROP_10G_JUMBO       34
#define GW_EG_QUEUE_LVL_3_DROP_10G_JUMBO  63
#define GW_EG_QUEUE_LVL_2_DROP_10G_JUMBO  63
#define GW_EG_QUEUE_LVL_1_DROP_10G_JUMBO  63
#define GW_EG_QUEUE_LVL_0_DROP_10G_JUMBO  63
#define GW_EG_PORT_LVL_DROP_10G_JUMBO     63






