/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/

#if defined(VTSS_TRACE)
/* Advanced trace system used */
#define VTSS_TRACE_MODULE_ID   VTSS_MODULE_ID_RSTP
#define VTSS_TRACE_GRP_DEFAULT 0
#define TRACE_GRP_CNT          1
#define VTSS_TRACE_LAYER       4
#else
#define VTSS_TRACE_FILE        "rstp"
#define VTSS_TRACE_LAYER       3
#endif /* VTSS_TRACE */

/* API public headers */
#include "vtss_switch_api.h"
#include "vtss_basic_trace.h"

#include <vtss_appl_plugins.h>
#include <vtss_rstp.h>

#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
static vtss_trace_reg_t trace_reg =
{ 
    .module_id = VTSS_TRACE_MODULE_ID,
    .name      = "rstp",
    .descr     = "Rapid Spanning Tree Protocol"
};

static vtss_trace_grp_t trace_grps[TRACE_GRP_CNT] =
{
    [VTSS_TRACE_GRP_DEFAULT] = { 
        .name      = "default",
        .descr     = "Default",
        .lvl       = VTSS_TRACE_LVL_WARNING,
        .timestamp = 0,
    },
};
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */

#define VTSS_RSTP_TICK	1000    /* One second protocol tick */

static const vtss_common_macaddr_t vtss_rstp_bpdu = { VTSS_RSTP_MULTICAST_MACADDR };
static vtss_mtimer_t plugin_timer;

/*
 * Module Frame Receive
 */
static vtss_rc plugin_recv(const vtss_system_frame_header_t *header, const unsigned char *frame)
{
    VTSS_N(("RSTP %s(%d)", __FUNCTION__, header->length));
    if (memcmp(frame, vtss_rstp_bpdu.macaddr, sizeof(vtss_rstp_bpdu.macaddr)) == 0) {
        vtss_rstp_receive(header->source_port_no, frame, header->length);
        return VTSS_OK;         /* Frame consumed */
    }
    VTSS_N(("RSTP %s() - not a BPDU", __FUNCTION__));
    return VTSS_PACKET_PROTOCOL_ERROR; /* Not for me! */
}

/*
 * Module Startup
 */
static void plugin_startup(int argc, const char **argv)
{
    vtss_port_no_t port_no;
    vtss_rstp_port_config_t conf, *pc = &conf;

    VTSS_D(("RSTP %s()", __FUNCTION__));

    vtss_rstp_init();

    for (port_no = VTSS_PORT_NO_START; VTSS_RSTP_IS_PORT(port_no); port_no++) {
#if defined(G_ROCX)
        vtss_appl_grocx_port_map_t mapentry;
        if(vtss_appl_grocx_port_map_get(port_no, &mapentry) == VTSS_OK)
            pc->enable_rstp = (mapentry.port_role == LAN_PORT);
        else
            break;              /* No more ports */
#else
        pc->enable_rstp = 1;
#endif
        pc->path_cost = 0;  /* Auto */
        pc->port_prio = VTSS_RSTP_DEFAULT_PORTPRIO;
        pc->is_edge = VTSS_RSTP_DEFAULT_EDGE;
        pc->p2p = VTSS_RSTP_DEFAULT_P2P;
        vtss_rstp_set_portconfig(port_no, pc);
    }

    pc->enable_rstp = 0;
    vtss_rstp_set_portconfig(0, pc); /* 0 for the auto port */

    VTSS_MTIMER_START(&plugin_timer, VTSS_RSTP_TICK);
}

/*
 * Module Run
 */
static void plugin_run(void)
{
    if (VTSS_MTIMER_TIMEOUT(&plugin_timer)) {
        VTSS_N(("RSTP %s()", __FUNCTION__));
        vtss_rstp_tick();
        VTSS_MTIMER_START(&plugin_timer, VTSS_RSTP_TICK);
    }
}

/*
 * Module Link Events
 */
static void plugin_linkevent(vtss_linkevent_t event, vtss_port_no_t port_no)
{
    if(VTSS_RSTP_IS_PORT(port_no)) {
        VTSS_D(("RSTP %s(%d, %d)", __FUNCTION__, event, port_no));
        switch(event) {
        case VTSS_LINKEVENT_DOWN:
            vtss_rstp_linkstate_changed(port_no, VTSS_COMMON_LINKSTATE_DOWN);
            break;
        case  VTSS_LINKEVENT_UP:
            vtss_rstp_linkstate_changed(port_no, VTSS_COMMON_LINKSTATE_UP);
            break;
        }
    } else {
        VTSS_I(("%s(%d, %d) - RSTP unaware port", __FUNCTION__, event, port_no));
        vtss_port_stp_state_set(port_no, event == VTSS_LINKEVENT_UP ? 
                                VTSS_STP_STATE_ENABLED : VTSS_STP_STATE_DISABLED);
    }
}

/*
 * Module Initialisation
 */
vtss_rc vtss_plugin_rstp_init(vtss_plugin_t *plugin)
{
    /* Install plugin hooks */
    plugin->startup = plugin_startup;
    plugin->run = plugin_run;
    plugin->recv = plugin_recv;
    plugin->linkevent = plugin_linkevent;
    plugin->flags = VTSS_PLUGIN_FLAG_LAYER2;

#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    VTSS_TRACE_REG_INIT(&trace_reg, trace_grps, TRACE_GRP_CNT);
    VTSS_TRACE_REGISTER(&trace_reg);
#endif /* VTSS_TRACE */

    return VTSS_OK;
}
