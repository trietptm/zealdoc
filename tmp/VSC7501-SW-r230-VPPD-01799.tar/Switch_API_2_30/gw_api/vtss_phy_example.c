/*

 Vitesse PHY API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.

 VeriPHY is a trademark of Vitesse Semiconductor.
 
 $Id: vtss_phy_example.c,v 1.20 2008/02/20 15:04:54 cpj Exp $
 $Revision: 1.20 $

*/

#include <stdlib.h>
#include <errno.h>
#include <string.h>

/* **
 * Vitesse Vitgenio Generic Hardhat Linux Driver.
 * You should subsitute this with your own specific Driver includes *
 * **/ 
#if defined(VTSS_VITGENIO)
#include <linux/vitgenio.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#endif /* VTSS_VITGENIO */

#include "vtss_phy.h"
#include "vtss_phy_veriphy.h"

/* **
 * Uncomment the following constant out to build for 
 * SPARX Switch-based MIIM Access.
 * **/
/* #define SPARX_INTERNAL_MIIM 1 */ 

/***
 * The following bit is to be included for SPARX switch-based MIIM. 
 ***/
#if defined(SPARX_INTERNAL_MIIM)
#include "vtss_switch_api.h"
#include "vtss_state.h"

/***
 * Set this constant to build for QUADs as external PHYs that is not connected 
 * to any internal Sparx MACs - Does not apply to SPARX G24 
 ***/
/* #define QUAD_PHY 1 */

#if defined(QUAD_PHY)
#undef  VTSS_PORT_ARRAY_SIZE
#undef  VTSS_PORT_NO_END
#define VTSS_PORT_NO_END (VTSS_PORTS+5)
#define VTSS_PORT_ARRAY_SIZE (VTSS_PORTS+5)
#endif  /* QUAD_PHY */

/* **
 * Use this for a PHY only part 
 * **/ 

#else /* SPARX_INTERNAL_MIIM */

#define VTSS_PORTS 8         /* Number of PHY ports on part */
#define VTSS_PORT_NO_START   ((vtss_port_no_t)1) 
#define VTSS_PORT_NO_END     (VTSS_PORT_NO_START+VTSS_PORTS)
#define VTSS_PORT_ARRAY_SIZE VTSS_PORT_NO_END
#endif /* SPARX_INTERNAL_MIIM */

/* Couple of typedefs that are used in context */
typedef unsigned char ubyte;
typedef signed char sbyte;

/* **
 * Vitesse Generic Driver (Vitgenio) specific functions. */ 
/* These functions are used with SPARX-based MIIM Access. 
 * **/
#if defined(SPARX_INTERNAL_MIIM)
#if defined(VTSS_VITGENIO)
/* Initialize board: Setup timing for Parallel Interface 
   and reset switch and PHY chips */ 
static int board_init(int master) {
    int                             fd;
    struct vitgenio_cs_setup_timing timing;

    /* Open driver */
    if ((fd = open("/dev/vitgenio",0))<0) {
        VTSS_E(("open(\"/dev/vitgenio\"): %s",strerror(errno)));
        return fd;
    }

#if defined(VTSS_OPT_SPARX_USE_SI)
{   /* Setup SI interface */
        struct vitgenio_cpld_spi_setup timing = {
            /* char ss_select; Which of the GPIOs is used for Slave Select */
            VITGENIO_SPI_SS_CPLD_GPIO0,
            VITGENIO_SPI_SS_ACTIVE_LOW, /* char ss_activelow; Slave Select (Chip Select) active low: true, active high: false */
            VITGENIO_SPI_CPOL_0, /* char sck_activelow; CPOL=0: false, CPOL=1: true */
            VITGENIO_SPI_CPHA_0, /* char sck_phase_early; CPHA=0: false, CPHA=1: true */
            VITGENIO_SPI_MSBIT_FIRST, /* char bitorder_msbfirst; */
            0, /* char reserved1; currently unused, only here for alignment purposes */
            0, /* char reserved2; currently unused, only here for alignment purposes */
            0, /* char reserved3; currently unused, only here for alignment purposes */
            20 /* unsigned int ndelay; minimum delay in nanoseconds, two of these delays are used per clock cycle */
        };
                  
        VTSS_D(("Setting up SPI timing"));
        /* Setup the SPI timing of the I/O Layer driver */
        ioctl(fd,VITGENIO_CPLD_SPI_SETUP,&timing);
}
#endif /* VTSS_OPT_SPARX_USE_SI */

    /* Setup Parallel Interface timing */

#if defined(SPARX_G24)
    timing.cs = VITGENIO_CS3;
    timing.bw = 16; /* Bus Width: bme=0,1,2 (aliases 8,16,32 accepted) */
    timing.bme = 0; /* Burst Mode Enable. */
    timing.twt = 40; /* Transfer Wait. Only used when bme=0. (255 is max) */
    timing.fwt = 0; /* First Wait. Only used when bme=1. */
    timing.bwt = 0; /* Burst Wait. Only used when bme=1. */
    timing.csn = 1; /* Chip Select */
    timing.oen = 1; /* Output Enable */
    timing.wbn = 0; /* Write Byte Enable On */
    timing.wbf = 1; /* Write Byte Enable Off */
    timing.th = 2;  /* Transfer Hold (7 is max) */
    timing.re = 0;  /* Ready Enable */
    timing.sor = 0; /* Sample On Ready */
    timing.bem = 1; /* Byte Enable Mode */
    timing.pen = 0; /* Parity Enable */
#endif 

#if defined(SPARX_G8) || defined(SPARX_G5)
    timing.cs = VITGENIO_CS3;
    timing.bw = 8; /* Bus Width: bme=0,1,2 (aliases 8,16,32 accepted) */
    timing.bme = 0; /* Burst Mode Enable. */
    timing.twt = 40; /* Transfer Wait. Only used when bme=0. (255 is max) */
    timing.fwt = 0; /* First Wait. Only used when bme=1. */
    timing.bwt = 0; /* Burst Wait. Only used when bme=1. */
    timing.csn = 1; /* Chip Select */
    timing.oen = 1; /* Output Enable */
    timing.wbn = 0; /* Write Byte Enable On */
    timing.wbf = 1; /* Write Byte Enable Off */
    timing.th = 2;  /* Transfer Hold (7 is max) */
    timing.re = 0;  /* Ready Enable */
    timing.sor = 0; /* Sample On Ready */
    timing.bem = 1; /* Byte Enable Mode */
    timing.pen = 0; /* Parity Enable */
#endif 

    VTSS_D(("Using CS%d", timing.cs));
    ioctl(fd, VITGENIO_CS_SELECT, timing.cs );

    return fd;
}
#endif /* VTSS_VITGENIO */

static int switch_api_setup (vtss_state_t *api_state)
{
    /* Allocate API state memory */
    if ((api_state = malloc(sizeof(vtss_state_t)))==NULL ||
        (api_state->al = malloc(vtss_sizeof_al()))==NULL) {
        VTSS_E(("malloc api_state failed"));
        return 0;
    }
    
    /* Allocate PHY API state memory */
    if ((api_state->phy = malloc(sizeof(vtss_phy_state_t)))==NULL ||
        (((vtss_phy_state_t*)(api_state->phy))->al = 
         malloc(vtss_phy_sizeof_al(VTSS_PORTS)))==NULL) {
        VTSS_E(("malloc phy_api_state failed"));
        return 0;
    }

#if defined(VTSS_VITGENIO)
#if defined(VTSS_CHIPS)
    /* Initialize board and I/O Layer for each chip */
    api_state->io[VTSS_CHIP_NO_START].fd = board_init(1);
    api_state->io[VTSS_CHIP_NO_START+1].fd = board_init(0);
#else
    /* Initialize board and I/O Layer */
    api_state->io.fd = board_init(1);
#endif /* VTSS_CHIPS */
#endif /* VTSS_VITGENIO */

    vtss_select_chip(api_state);  
    return 1;
}

static vtss_port_interface_t port_mac_interface(vtss_port_no_t port_no)
{   
#if defined(SPARX_INTERNAL_MIIM)
#if defined(VTSS_FEATURE_VAUI)
    if (port_vaui(port_no))
        return VTSS_PORT_INTERFACE_VAUI;
#endif /* VTSS_FEATURE_VAUI */

#if defined(SPARX_G24)
    return (port_no < 9 || port_no > 16 ? VTSS_PORT_INTERFACE_SGMII :
            VTSS_PORT_INTERFACE_INTERNAL);
#endif /* SPARX_G24 */

#if defined(SPARX_G16) 
    return (port_no < 9 ? VTSS_PORT_INTERFACE_SGMII : VTSS_PORT_INTERFACE_INTERNAL);
#endif /* SPARX_G16 */

#if defined(SPARX_G8)
    return VTSS_PORT_INTERFACE_INTERNAL;
#endif /* SPARX_G8 */

#if defined(SPARX_G5)
    return (port_no < 6 ? VTSS_PORT_INTERFACE_INTERNAL : VTSS_PORT_INTERFACE_RGMII);
#endif /* SPARX_G5 */
#endif
	return 0;
}
#endif  /* SPARX_INTERNAL_MIIM */

#if defined(SPARX_INTERNAL_MIIM)
static int sparx_phy_setup(void)
{
    vtss_state_t       *api_state=0;

    if (!(switch_api_setup (api_state)))
        return 0;
        
    /* Setup the PI/SPI interface */
    {
        vtss_init_setup_t setup;

        setup.reset_chip = 1;
        setup.use_cpu_si = 0;
#if defined(VTSS_FEATURE_PI_WIDTH)
#if defined(SPARX_G24) 
        setup.pi_width = VTSS_PI_WIDTH_16;
#else
        setup.pi_width = VTSS_PI_WIDTH_8;
#endif 
#endif 

#if defined(VTSS_FEATURE_PI_TIMING_CS)
        setup.pi_cs_wait_ns = 0;
#endif

#if defined(VTSS_FEATURE_PI_SLOWMODE)
        setup.pi_use_extended_buscycle = 0;
#endif 

#if defined(VTSS_FEATURE_LAYER3)
        setup.ipmc_size = VTSS_IPMC_SIZE_0;
#endif 

#if defined(VTSS_OPT_SPARX_USE_SI)
        setup.use_cpu_si = 1;
#endif 
        vtss_init(&setup);
    }
    
    /* Read chip ID */
    {
        vtss_chipid_t chipid;
        
        if (vtss_chipid_get(&chipid)<0) {
            VTSS_E(("vtss_chipid_get failed"));
        } else {
            VTSS_D(("part_number: 0x%04x, revision: %d",
                    chipid.part_number, chipid.revision));
        }
    }

    /* Setup port map for board */
    {
        vtss_mapped_port_t port_map[VTSS_PORT_NO_END] = { 
            { -1,-1, -1 },
#if defined(SPARX_G24) 
            {  0, VTSS_MIIM_CONTROLLER_1,  0 },
            {  1, VTSS_MIIM_CONTROLLER_1,  1 },
            {  2, VTSS_MIIM_CONTROLLER_1,  2 },
            {  3, VTSS_MIIM_CONTROLLER_1,  3 },
            {  4, VTSS_MIIM_CONTROLLER_1,  4 },
            {  5, VTSS_MIIM_CONTROLLER_1,  5 },
            {  6, VTSS_MIIM_CONTROLLER_1,  6 },
            {  7, VTSS_MIIM_CONTROLLER_1,  7 },
            {  8, VTSS_MIIM_CONTROLLER_0,  0 },
            {  9, VTSS_MIIM_CONTROLLER_0,  1 },
            { 10, VTSS_MIIM_CONTROLLER_0,  2 },
            { 11, VTSS_MIIM_CONTROLLER_0,  3 },
            { 12, VTSS_MIIM_CONTROLLER_0,  4 },
            { 13, VTSS_MIIM_CONTROLLER_0,  5 },
            { 14, VTSS_MIIM_CONTROLLER_0,  6 },
            { 15, VTSS_MIIM_CONTROLLER_0,  7 },
            { 16, VTSS_MIIM_CONTROLLER_1, 16 },
            { 17, VTSS_MIIM_CONTROLLER_1, 17 },
            { 18, VTSS_MIIM_CONTROLLER_1, 18 },
            { 19, VTSS_MIIM_CONTROLLER_1, 19 },
            { 20, VTSS_MIIM_CONTROLLER_1, 20 },
            { 21, VTSS_MIIM_CONTROLLER_1, 21 },
            { 22, VTSS_MIIM_CONTROLLER_1, 22 },
            { 23, VTSS_MIIM_CONTROLLER_1, 23 }
#endif 
#if defined(SPARX_G5) 
            {  0, VTSS_MIIM_CONTROLLER_0,  0 },
            {  1, VTSS_MIIM_CONTROLLER_0,  1 },
            {  2, VTSS_MIIM_CONTROLLER_0,  2 },
            {  3, VTSS_MIIM_CONTROLLER_0,  3 },
            {  4, VTSS_MIIM_CONTROLLER_0,  4 },
            {  5, VTSS_MIIM_CONTROLLER_0,  5 },
#if defined(QUAD_PHY)             
            {  0, VTSS_MIIM_CONTROLLER_1,  0 },
            {  1, VTSS_MIIM_CONTROLLER_1,  1 },
            {  2, VTSS_MIIM_CONTROLLER_1,  2 },
            {  3, VTSS_MIIM_CONTROLLER_1,  3 }                       
#endif           
#endif 
#if defined(SPARX_G8) 
            /*- PHY 3, 7 could be connected to VTSS_MIIM_CONTROLLER_1 for certain boards */
            {  0, VTSS_MIIM_CONTROLLER_0,  0 },
            {  1, VTSS_MIIM_CONTROLLER_0,  1 },
            {  2, VTSS_MIIM_CONTROLLER_0,  2 },
            {  7, VTSS_MIIM_CONTROLLER_0,  3 },
            {  3, VTSS_MIIM_CONTROLLER_0,  4 },
            {  6, VTSS_MIIM_CONTROLLER_0,  5 },
            {  4, VTSS_MIIM_CONTROLLER_0,  6 },
            {  5, VTSS_MIIM_CONTROLLER_0,  7 },
#endif 
        };
        vtss_port_map_set(port_map);
    }       

    /* Reset all PHYs and setup for auto negotiation or fixed speed */
    {
        vtss_port_no_t    port_no;

        for (port_no = VTSS_PORT_NO_START; 
             port_no < VTSS_PORT_NO_END; port_no++) {
            vtss_phy_reset_setup_t reset;
            vtss_phy_setup_t       setup;
            vtss_port_status_t     status;
                
            /* 1G port, reset PHY and start auto negotiation */
            reset.mac_if = port_mac_interface(port_no);
#if defined(BOARD_RUNWAY16) || defined(BOARD_RUNWAY)
            reset.rgmii.rx_clk_skew_ps = 0;
            reset.rgmii.tx_clk_skew_ps = 0;
#else
            reset.rgmii.rx_clk_skew_ps = 1800;
            reset.rgmii.tx_clk_skew_ps = 1800;
#endif /* BOARD_RUNWAY16/BOARD_RUNWAY */
            /* Media interface: Copper by default */
            reset.media_if = VTSS_PHY_MEDIA_INTERFACE_COPPER;
            vtss_phy_reset(port_no, &reset);
            
#if defined(VTSS_FEATURE_SGMII)
            /* Setup the ports, so the SGMII clock gets up and running towards the PHYs. */
            {
                vtss_port_setup_t setup;
                int i;

                memset(&setup, 0, sizeof(setup));
                setup.interface_mode.interface_type = VTSS_PORT_INTERFACE_SGMII;
                setup.interface_mode.speed = VTSS_SPEED_1G;
                setup.powerdown = 0;
                setup.fdx = 1;
                setup.flowcontrol.obey = 0;
                setup.flowcontrol.generate = 0;
                for (i=0; i<6; i++) {
                    setup.flowcontrol.smac.addr[i] = (i==5 ? port_no : 0);
                }
                setup.maxframelength = VTSS_MAXFRAMELENGTH_STANDARD;
                setup.frame_gaps.hdx_gap_1 = VTSS_FRAME_GAP_DEFAULT;
                setup.frame_gaps.hdx_gap_2 = VTSS_FRAME_GAP_DEFAULT;
                setup.frame_gaps.fdx_gap = VTSS_FRAME_GAP_DEFAULT;
                setup.sgmii_dc_coupled = 0;
                vtss_port_setup(port_no, &setup);
            }
#endif /* VTSS_FEATURE_SGMII */

            /* Setup PHY for auto negotiation */
            setup.mode = VTSS_PHY_MODE_ANEG;
            setup.aneg.speed_10m_hdx = 1;
            setup.aneg.speed_10m_fdx = 1;
            setup.aneg.speed_100m_hdx = 1;
            setup.aneg.speed_100m_fdx = 1;
            setup.aneg.speed_1g_fdx = 1;
            setup.aneg.symmetric_pause = 0;
            setup.aneg.asymmetric_pause = 0;
            vtss_phy_setup(port_no, &setup);

            /* Sleep for a small duration to let link come up, if it was taken down */            
            VTSS_MSLEEP (3000);

            /* Get PHY Status and run link-up code */
            VTSS_RC(vtss_phy_status_get(port_no, &status));
        }
    }      
    
    return 1;
}

#else /* SPARX_INTERNAL_MIIM */

/* **
 * Function demonstrates the use of Vitesse PHY API Functions 
 * **/
static int non_sparx_phy_setup (void)
{
    vtss_rc rc;
    vtss_phy_state_t   *phy_api_state=0;
    
    if ((phy_api_state = malloc(sizeof(vtss_phy_state_t)))==NULL ||
        (phy_api_state->al = malloc(vtss_phy_sizeof_al(VTSS_PORTS)))==NULL) {
        VTSS_E(("malloc phy_api_state failed"));
        return 0;
    }

#if defined(VTSS_VITGENIO)
    /* Initialize I/O Layer */
    if ((phy_api_state->io.fd = open("/dev/vitgenio",0))<0) {
        VTSS_E(("open(\"/dev/vitgenio\"): %s",strerror(errno)));
        return 0;
    } 
#endif /* VTSS_VITGENIO */

    /* Use the allocated PHY state memory */
    rc = vtss_phy_select_context(phy_api_state);
    if (rc<VTSS_WARNING) {
        VTSS_E(("vtss_select_context():0x%04X",rc));
        return 0;
    }

    /* Initialize PHY API */
    {
        vtss_phy_init_setup_t setup;

        setup.ports = VTSS_PORTS;
        rc = vtss_phy_init(&setup);
        if (rc<VTSS_WARNING) {
            VTSS_E(("vtss_phy_init():0x%04X",rc));
            return 0;
        }
        printf ("\n\n vtss_phy_init() - PHY API Initialized successfully\n");
    }

    /* Setup port map for board */
    {   /* (bus, address) pairs */
        int i;
        vtss_phy_mapped_port_t port_map[VTSS_PORT_ARRAY_SIZE] = { 
            { -1, -1 },
            {  0, 0 }, 
            {  0, 1 }, 
            {  0, 2 },
            {  0, 3 },
            {  0, 4 }, 
            {  0, 5 }, 
            {  0, 6 },
            {  0, 7 }
        };
        rc = vtss_phy_port_map_set(port_map);
        if (rc<VTSS_WARNING) {
            VTSS_E(("vtss_phy_port_map_set():0x%04X",rc));
            return 0;
        }
        printf ("\n\n vtss_phy_port_map() - Port Map Initialized \n");
        printf ("\n PHY Port Map \n");
        for (i=0; i<VTSS_PORT_ARRAY_SIZE;i++)
            printf ("MIIM Bus = %d, Address = %d\n", port_map[i].bus, port_map[i].addr);
        printf ("\n");
    }    

    /* Reset PHYs */
    {
        vtss_phy_reset_setup_t reset;
        vtss_port_no_t         port_no;
        
        reset.mac_if = VTSS_PORT_INTERFACE_SGMII;
        reset.media_if = VTSS_PHY_MEDIA_INTERFACE_COPPER;
        reset.rgmii.rx_clk_skew_ps = 0;
        reset.rgmii.tx_clk_skew_ps = 0;

        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if ((rc = vtss_phy_reset(port_no, &reset)) < 0) {
                VTSS_E(("vtss_phy_reset():0x%04X",rc));
                return 0;
            } 
        }
        /* Sleep for a small duration to let link come up, if it was taken down */            
        VTSS_MSLEEP (3000);
        printf ("Setup %d ports for SGMII\n", (VTSS_PORT_NO_END-1));
    }
    return 1;
}
#endif  /* SPARX_INTERNAL_MIIM */

int main(void)
{
#if defined(SPARX_INTERNAL_MIIM)
    printf ("\n ****** Sparx Internal MIIM Interface used ****** \n");
    if (!sparx_phy_setup()) {
        printf ("\n ******* Error! Setting up Sparx Interface ***** \n\n");
        return 0;
    }
#else
    printf ("\n ******* CPLD MIIM Interface used *****\n\n");
    if (!non_sparx_phy_setup()) {
        printf ("\n ******* Error! Setting up CPLD MIIM Interface ***** \n\n");
        return 0;
    }
#endif    /* SPARX_INTERNAL_MIIM */
    printf ("PHY Setup completed\n");    

    /* **
     * Example of Running VeriPHY Cable Diagnostics Suite on an external CPU. 
     * Some of the Vitesse PHYs such as VSC8558, VSC8658 have internal triggers
     * to run VeriPHY on the internal V-Core of the part. 
     * Refer to the Device Data Sheet for triggering VeriPHY internally. 
     * **/  
#define VERIPHY_PORTS VTSS_PORT_NO_END
    {
        int                       port,i,done;
        vtss_phy_veriphy_result_t result;
        vtss_phy_veriphy_status_t status;
        
        printf("\n\n======= VeriPHY task starts =======\n");
        for (port = 1; port <= VERIPHY_PORTS; port++) {
            /* VeriPHY initialized in Mode 0 - Full VeriPHY algorithm */
            vtss_phy_veriphy_start(port-1, 0);
        }
        
        /* Call vtss_phy_veriphy_get until we finish VeriPHY on the selected PHYs */
        do {
            done = 1;
            for (port = VTSS_PORT_NO_START; port < VERIPHY_PORTS; port++) {
                if (vtss_phy_veriphy_get(port, &result) == VTSS_INCOMPLETE)
                    done = 0;
            }
            VTSS_MSLEEP(5);
        } while (!done);
        
        /* Print result for each port */
        for (port = VTSS_PORT_NO_START; port < VERIPHY_PORTS; port++) {
            if (vtss_phy_veriphy_get(port, &result) != VTSS_OK)
                continue;
            printf("----- Port %d -----\n", port);
            printf("VeriPHY link status: %s\n", result.link ? "Up" : "Down");
            for (i = 0; i < 4; i++) {
                status = result.status[i];
                printf("VeriPHY status for wire pair %c: %s\n", 
                       'A'+i,
                       status == VTSS_VERIPHY_STATUS_OK ? "Correctly terminated pair" :
                       status == VTSS_VERIPHY_STATUS_OPEN ? "Open pair" :
                       status == VTSS_VERIPHY_STATUS_SHORT ? "Short pair" :
                       status == VTSS_VERIPHY_STATUS_ABNORM ? "Abnormal termination" :
                       status == VTSS_VERIPHY_STATUS_SHORT_A ? "Cross-pair short to pair A" :
                       status == VTSS_VERIPHY_STATUS_SHORT_B ? "Cross-pair short to pair B" :
                       status == VTSS_VERIPHY_STATUS_SHORT_C ? "Cross-pair short to pair C" :
                       status == VTSS_VERIPHY_STATUS_SHORT_D ? "Cross-pair short to pair D" :
                       status == VTSS_VERIPHY_STATUS_COUPL_A ? "Abnormal coupling with pair A" :
                       status == VTSS_VERIPHY_STATUS_COUPL_B ? "Abnormal coupling with pair B" :
                       status == VTSS_VERIPHY_STATUS_COUPL_C ? "Abnormal coupling with pair C" :
                       status == VTSS_VERIPHY_STATUS_COUPL_D ? "Abnormal coupling with pair D" :
                       "Unknown");
            }
            for (i = 0; i < 4; i++) {
                printf("VeriPHY length %c: %d\n", 'A'+i, result.length[i]); 
            }
        }
        printf("======= VeriPHY task done =======\n");
    }
    return 0;
}

/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
