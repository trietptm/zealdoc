/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 

*/


#ifndef _VTSS_IGMP_API_H_
#define _VTSS_IGMP_API_H_

#include "vtss_switch_api.h"

//#if VTSS_OPT_IGMP

/* The maximum number of supported VIDs */
#define IGMP_NUM_SUPPORTED_VIDS                 1
/* The maximum number of supported V3 entries for each port */
#define V3_SRC_LIST_ARRAY_SIZE                  8
/* The maximum number of supported multicast groups */
#define IGMP_NO_OF_SUPPORTED_GROUPS             32
/* this one can be 16, 32, 64, 128 and is a tradeof of 
 * number of supported groups, lookup time for groups MAC clashes and RAM usage */
#define IGMP_NO_OF_ROWS_IN_HASH_TABLE	        64
/* The maximum number of supported leave msg queued */
#define IGMP_POST_LEAVE_QUEUE_LEN	            16
/* remove a dynamically discovered router port after 5 minutes of inactivity */
#define ROUTER_PORT_TIMEOUT                     300
#define IGMP_QUERIER_NO_QUERY_HEARD_INTERVAL    255
/* number of seconds to wait for response before timing out current entries */
#define IGMP_GENERAL_QUERY_RESPONSE_INTERVAL    15
#define IGMP_GENERAL_LEAVE_INTERVAL             2
/* the value to use for MAX response time, 0x64 is 100 decimal => 10 seconds */   
#define IGMP_QUERIER_TX_QUERY_RESPONSE_INTERVAL 0x64

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#define VTSS_IGMP_ENABLED           TRUE
#define VTSS_IGMP_DISABLED          FALSE
#define VTSS_IGMP_NO_ENTRY          100
#define VTSS_OPT_IGMP_CHECK_TIMER   1000
#define port_bit_mask_t             ulong
#define HASH_TABLE_VOID_ENTRY       0xffff
#define IGMP_VID_VOID               0xffff
#define IGMP_MEMB(name, size, num) \
        static unsigned char memb_ ## name ## mem[(size + 4) * num]; \
        static struct igmp_memb_blocks name = {size, num, memb_ ## name ## mem}

#define IGMP_MEMBERSHIP_QUERY           0x11
#define IGMP_V2_MEMBERSHIP_REPORT       0x16
#define IGMP_LEAVE_GROUP                0x17
#define IGMP_V1_MEMBERSHIP_REPORT       0x12
#define IGMP_V3_MEMBERSHIP_REPORT       0x22

#define IGMP_V3_MODE_IS_INCLUDE         1
#define IGMP_V3_MODE_IS_EXCLUDE         2
#define IGMP_V3_CHANGE_TO_INCLUDE       3
#define IGMP_V3_CHANGE_TO_EXCLUDE       4
#define IGMP_V3_ALLOW_NEW_SOURCES       5
#define IGMP_V3_BLOCK_OLD_SOURCES       6

#define IGMP_V3_INCLUDE_MODE            1
#define IGMP_V3_EXCLUDE_MODE            2



struct igmp_memb_blocks {
  ushort    size;
  ushort    num;
  uchar     * mem;
};

/* MAC address, simpler to use than vtss_mac_t */
typedef uchar mac_addr_t[6];


// Packet format Declaration
typedef struct
{
    uchar					type;
    uchar					max_resp_time;
    ushort					checksum;
    ulong					group_address;   
}__attribute__((packed)) igmp_packet_t;

/**
 * Representation of a 48-bit Ethernet address.
 */
typedef struct {
  uchar addr[6];
}__attribute__((packed)) igmp_eth_addr;

/**
 * The Ethernet header. 
 */
typedef struct {
  igmp_eth_addr dest;
  igmp_eth_addr src;
  ushort type;
}__attribute__((packed)) igmp_ip_eth_hdr;

/**
 * The VLAN header. 
 */
typedef struct {
  ushort ether_type;
  ushort vid;
}__attribute__((packed)) igmps_vlan_hdr;


/* The IGMP and IP headers. */
typedef struct {
  /* IP header. */
  uchar     vhl,
            tos,          
            len[2],       
            ipid[2],        
            ipoffset[2],  
            ttl,          
            proto;     
  ushort    ipchksum;
  ushort    srcipaddr[2], 
            destipaddr[2];
  uchar     router_option[4];
  
  /* IGMP header. */
  uchar     igmp_type,
            max_response_time;
  ushort    igmpchksum;
  uchar     group[4];    
} __attribute__((packed)) igmp_igmpip_hdr;


typedef struct
{
    uchar						record_type;
    uchar						aux_data_len;
    ushort						num_sources;
    ulong						multicast_address;
    ulong                       src_addr[V3_SRC_LIST_ARRAY_SIZE];
} __attribute__((packed)) igmp_v3_group_record;


typedef ushort vtss_igmp_idx_t;

typedef enum
{
    QUERIER_IDLE,
    QUERIER_ACTIVE
} vtss_igmp_querier_states_t;

typedef struct
{
    uchar					        querier_enabled;
    vtss_igmp_querier_states_t	    state;
    uchar					        timeout;
    ushort					        general_queries_sent;
    ushort					        group_queries_sent;    
} vtss_igmp_querier_sm_t;

typedef struct
{
    ushort					        igmp_queries;
    ushort					        v2_membership_reports;
    ushort					        v2_leave_group_reports;
    ushort					        v1_membership_reports;
    ushort					        v3_membership_reports;
} vtss_igmp_statistics_t;


typedef struct
{
    ulong                           src_ip;
    BOOL            		        valid;
} vtss_igmp_v3_src_entry_t;


typedef struct
{
    ushort					        v3_mode;
    int                             src_cnt[VTSS_PORT_ARRAY_SIZE];
    vtss_igmp_v3_src_entry_t        src_list[VTSS_PORT_ARRAY_SIZE][V3_SRC_LIST_ARRAY_SIZE];
} vtss_igmp_v3_mode_srclist_t;

typedef struct _vtss_igmp_group_entry_t vtss_igmp_group_entry_t;
struct _vtss_igmp_group_entry_t
{
    ulong					        group_addr;
    port_bit_mask_t			        port_mask;
    port_bit_mask_t			        general_query_reply_mask;
    uchar                           hash_tbl_row;
    vtss_igmp_idx_t                 hash_tbl_idx;
    vtss_igmp_group_entry_t		    *next_group;
    vtss_igmp_v3_mode_srclist_t     *v3_mode_srclist;
};


typedef struct
{    
    ushort                          vid;
    uchar                           general_query_response_timeout;
    uchar                           general_leave_timeout;
    vtss_igmp_querier_sm_t          querier;
    vtss_igmp_statistics_t          stats;
    vtss_igmp_group_entry_t         *ipmc_groups;
    ulong                           ipmc_group_cnt;
    ulong                           vlan_ports;
    uchar                           fast_leave_status;
} vtss_igmp_vid_entry_t;


typedef struct
{    
    ushort                          vid;
    uchar                           general_query_response_timeout;
    uchar                           general_leave_timeout;
    vtss_igmp_querier_sm_t          querier;
    vtss_igmp_statistics_t          stats;
    vtss_igmp_group_entry_t         ipmc_groups[IGMP_NO_OF_SUPPORTED_GROUPS];
    ulong                           ipmc_group_cnt;
    ulong                           vlan_ports;
    uchar                           fast_leave_status;
} vtss_igmp_vid_stat_entry_t;


typedef struct
{
    vtss_igmp_group_entry_t			* grp;
    vtss_igmp_idx_t					next_idx;
    ushort						    vid;
} vtss_igmp_hash_entry_t;

typedef struct
{
		uchar   src_port;
		ushort  vid;
		ulong   group_address;
		ulong   timeout;
		uchar	valid;
}vtss_igmp_post_leave_entry_t;


typedef struct
{    
    BOOL    ports[VTSS_PORT_ARRAY_SIZE]; /* Port mask */
} vtss_igmp_fast_leave_port_t;


vtss_rc vtss_igmps_init(int grocx_config);

vtss_rc vtss_igmp_set_mode(BOOL *mode);

vtss_rc vtss_igmp_get_mode(BOOL *mode);

vtss_rc vtss_igmp_set_unreg_flood(BOOL *mode);

vtss_rc vtss_igmp_get_unreg_flood(BOOL *mode);

vtss_rc vtss_igmp_set_fast_leave_port(vtss_igmp_fast_leave_port_t *fast_leave_port);

vtss_rc vtss_igmp_get_fast_leave_port(vtss_igmp_fast_leave_port_t *fast_leave_port);

vtss_rc vtss_igmp_get_vlan_info (ushort vid, vtss_igmp_vid_stat_entry_t *vid_entry);

vtss_rc vtss_igmp_clear_stat_counter(void);

//#endif /* VTSS_OPT_IGMP */

#endif /* _VTSS_IGMP_API_H_ */



