/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/

#include <stdlib.h>
#include <string.h>
#include <linux/vitgenio.h>
#include <sys/ioctl.h>
#include <fcntl.h>

/* API public headers */
#include "vtss_switch_api.h"
#include "vtss_appl.h"

/* Board port map */
static vtss_mapped_port_t board_port_map[VTSS_PORT_ARRAY_SIZE] = { 
    { -1,-1, -1 } /*unused*/,
#if defined(SPARX_G5)
    {  0, VTSS_MIIM_CONTROLLER_0,  0 },
    {  1, VTSS_MIIM_CONTROLLER_0,  1 },
    {  2, VTSS_MIIM_CONTROLLER_0,  2 },
    {  3, VTSS_MIIM_CONTROLLER_0,  3 },
    {  4, VTSS_MIIM_CONTROLLER_0,  4 },
#if VTSS_OPT_ROUTER
    {  6, VTSS_MIIM_CONTROLLER_NONE, -1 }
#else
    {  6, VTSS_MIIM_CONTROLLER_1,  3 }
#endif /* VTSS_OPT_ROUTER */
#endif /* SPARX_G5 */
#if defined(SPARX_G8)
    {  0, VTSS_MIIM_CONTROLLER_0,  0 },
    {  1, VTSS_MIIM_CONTROLLER_0,  1 },
    {  2, VTSS_MIIM_CONTROLLER_0,  2 },
    {  7, VTSS_MIIM_CONTROLLER_0,  3 },
    {  3, VTSS_MIIM_CONTROLLER_0,  4 },
    {  6, VTSS_MIIM_CONTROLLER_0,  5 },
    {  4, VTSS_MIIM_CONTROLLER_0,  6 },
    {  5, VTSS_MIIM_CONTROLLER_0,  7 }
#endif /* SPARX_G8 */
#if defined(BOARD_SPARX_G24_EVAL)
    {  0, VTSS_MIIM_CONTROLLER_1,  0 },
    {  1, VTSS_MIIM_CONTROLLER_1,  1 },
    {  2, VTSS_MIIM_CONTROLLER_1,  2 },
    {  3, VTSS_MIIM_CONTROLLER_1,  3 },
    {  4, VTSS_MIIM_CONTROLLER_1,  4 },
    {  5, VTSS_MIIM_CONTROLLER_1,  5 },
    {  6, VTSS_MIIM_CONTROLLER_1,  6 },
    {  7, VTSS_MIIM_CONTROLLER_1,  7 },
    {  8, VTSS_MIIM_CONTROLLER_0,  0 },
    {  9, VTSS_MIIM_CONTROLLER_0,  1 },
    { 10, VTSS_MIIM_CONTROLLER_0,  2 },
    { 11, VTSS_MIIM_CONTROLLER_0,  3 },
    { 12, VTSS_MIIM_CONTROLLER_0,  4 },
    { 13, VTSS_MIIM_CONTROLLER_0,  5 },
    { 14, VTSS_MIIM_CONTROLLER_0,  6 },
    { 15, VTSS_MIIM_CONTROLLER_0,  7 },
    { 16, VTSS_MIIM_CONTROLLER_1, 16 },
    { 17, VTSS_MIIM_CONTROLLER_1, 17 },
    { 18, VTSS_MIIM_CONTROLLER_1, 18 },
    { 19, VTSS_MIIM_CONTROLLER_1, 19 },
    { 20, VTSS_MIIM_CONTROLLER_1, 20 },
    { 21, VTSS_MIIM_CONTROLLER_1, 21 },
    { 22, VTSS_MIIM_CONTROLLER_1, 22 },
    { 23, VTSS_MIIM_CONTROLLER_1, 23 }
#endif /* BOARD_SPARX_G24_EVAL */
};

static vtss_port_interface_t
board_port_mac_interface(vtss_port_no_t port_no)
{
    vtss_port_interface_t if_type = VTSS_PORT_INTERFACE_INTERNAL;
#if !defined(SPARX_G8)
    int chip_port = board_port_map[port_no].chip_port;
#endif

#if defined(VTSS_ARCH_SPARX_G24)
    if_type = (chip_port < 8 || chip_port > 15 ? VTSS_PORT_INTERFACE_SGMII : 
               VTSS_PORT_INTERFACE_INTERNAL);
#endif /* SPARX_G24 */

#if defined(SPARX_G8)
    if_type = VTSS_PORT_INTERFACE_INTERNAL;
#endif /* SPARX_G8 */

#if defined(SPARX_G5)
    if_type = (chip_port < 6 ? VTSS_PORT_INTERFACE_INTERNAL : 
               VTSS_OPT_ROUTER_PORT_CPU_IF ? VTSS_PORT_INTERFACE_GMII :
               VTSS_PORT_INTERFACE_RGMII);
#endif /* SPARX_G5 */
 
    return if_type;
}

#if VTSS_OPT_ROUTER
static BOOL board_router_port(vtss_port_no_t port_no)
{
#if defined(SPARX_G5)
    return (board_port_map[port_no].chip_port == 6);
#else
#error "Configuration error"
#endif /* SPARX_G5 */
}
#endif /* VTSS_OPT_ROUTER */


/* Initialize CPU/switch interface */
static void
board_connect(int argc, const char **argv, vtss_io_state_t *io) 
{
    int fd;
    struct vitgenio_cs_setup_timing timing;

    /* Open driver */
    if ((fd = open("/dev/vitgenio", 0)) < 0) {
        VTSS_E(("open(\"/dev/vitgenio\"): %s",strerror(errno)));
        exit(1);
    }

    /* Setup Parallel Interface timing */
#if defined(BOARD_SPARX_G5_EVAL) || defined(BOARD_SPARX_G8_EVAL) || defined(BOARD_SPARX_G24_EVAL)
    timing.cs = VITGENIO_CS3;
#if defined(BOARD_SPARX_G24_EVAL)
    timing.bw = 16; /* Bus Width: bme=0,1,2 (aliases 8,16,32 accepted) */
#else
    timing.bw = 8; /* Bus Width: bme=0,1,2 (aliases 8,16,32 accepted) */
#endif /* BOARD_SPARX_G24_EVAL */
    timing.bme = 0; /* Burst Mode Enable. */
    timing.twt = 40; /* Transfer Wait. Only used when bme=0. (255 is max) */
    timing.fwt = 0; /* First Wait. Only used when bme=1. */
    timing.bwt = 0; /* Burst Wait. Only used when bme=1. */
    timing.csn = 1; /* Chip Select */
    timing.oen = 1; /* Output Enable */
    timing.wbn = 0; /* Write Byte Enable On */
    timing.wbf = 1; /* Write Byte Enable Off */
    timing.th = 2;  /* Transfer Hold (7 is max) */
    timing.re = 0;  /* Ready Enable */
    timing.sor = 0; /* Sample On Ready */
    timing.bem = 1; /* Byte Enable Mode */
    timing.pen = 0; /* Parity Enable */
    ioctl(fd, VITGENIO_CS_SETUP_TIMING, &timing);
#endif /* BOARD_SPARX_G8_EVAL/G5_EVAL */

    VTSS_D(("Using CS%d", timing.cs));
    ioctl(fd, VITGENIO_CS_SELECT, timing.cs );
    io->fd = fd;
}

void vtss_board_hookup(struct vtss_board *board, int argc, const char **argv)
{
#if defined(SPARX_G5)
    board->name = "SparX-G5";
#endif
#if defined(SPARX_G8)
    board->name = "SparX-G8";
#endif
#if defined(BOARD_SPARX_G24_EVAL)
    board->name = "SparX-G24 Eval";
#endif
    board->port_map = board_port_map;
    board->connect = board_connect;
#if VTSS_OPT_ROUTER
    board->router_port = board_router_port;
#endif
    board->port_mac_interface = board_port_mac_interface;
}

