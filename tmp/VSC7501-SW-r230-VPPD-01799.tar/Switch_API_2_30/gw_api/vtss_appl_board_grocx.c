/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/

/* Standard headers */
#include <string.h>
#include <signal.h>
#include <stdlib.h>

#include <linux/vitgenio.h>
#include <sys/ioctl.h>
#include <fcntl.h>

/* API public headers */
#include "vtss_switch_api.h"
#include "vtss_appl.h"
#include "vtss_grocx_switch_api.h"

/* Extra interfaces */
#include <syslog.h>

#if !defined(VTSS_OPT_ROUTER) || (VTSS_OPT_ROUTER == 0)
#error "This code assumes a routing environment - check your makefile!"
#endif

/* Router VLAN definitions */
#define VTSS_ROUTER_VLAN_LAN  VTSS_OPT_ROUTER_VLAN_LAN
#define VTSS_ROUTER_VLAN_WAN  VTSS_OPT_ROUTER_VLAN_WAN
#define VTSS_ROUTER_VLAN_WAN2 VTSS_OPT_ROUTER_VLAN_WAN2

/*   Grocx port properties are defined here       */
static int port_config_type;       
static vtss_mtimer_t booting_wait_timer;
static BOOL booting_start = 0;  
static vtss_port_qos_setup_t qos_port_ll_conf;

static int vtss_opt_router_wlan_rgmii=0;   /* set 1 if rgmii wifi module supported  */ 
static int vtss_opt_port_count=0;   /* total port count */
static int vtss_opt_router_port_wan=0; /* set 1 if wan port is on vtss switch(config A/B) */

static BOOL flash_update = 0;   /* LED control for flashing in progress */

/* Board port map */
static vtss_mapped_port_t board_port_map[VTSS_PORT_ARRAY_SIZE] = { 
    { -1,-1, -1 } /*unused*/,
#if defined(BOARD_GROCX_EVAL)
    {  5, VTSS_MIIM_CONTROLLER_1, 2 },    /* 5: (R)GMII */
    {  6, VTSS_MIIM_CONTROLLER_1, 3 },    /* 6: RGMII */
    {  0, VTSS_MIIM_CONTROLLER_0, 0 },    /* 0: Internal PHY */
    {  1, VTSS_MIIM_CONTROLLER_0, 1 },    /* 1: Internal PHY */
    {  2, VTSS_MIIM_CONTROLLER_0, 2 },    /* 2: Internal PHY */
    {  3, VTSS_MIIM_CONTROLLER_0, 3 },    /* 3: Internal PHY */
    {  4, VTSS_MIIM_CONTROLLER_NONE, -1 } /* 4: Internal GMII */
#endif /* BOARD_GROCX_EVAL */
#if defined(BOARD_GROCX_REF)
    {  5, VTSS_MIIM_CONTROLLER_1, 0 },     /* 5: (R)GMII (WAN) */
    {  0, VTSS_MIIM_CONTROLLER_0, 0 },     /* 0: Internal PHY */
    {  1, VTSS_MIIM_CONTROLLER_0, 1 },     /* 1: Internal PHY */
    {  2, VTSS_MIIM_CONTROLLER_0, 2 },     /* 2: Internal PHY */
    {  3, VTSS_MIIM_CONTROLLER_0, 3 },     /* 3: Internal PHY */
#if (VTSS_PORTS == 7)
    {  6, VTSS_MIIM_CONTROLLER_NONE, -1 }, /* 6: Internal GMII or external RGMII (Wi) */
#endif /* VTSS_PORTS == 7 */
    {  4, VTSS_MIIM_CONTROLLER_NONE, -1 }, /* 4: Internal GMII */
#endif /* BOARD_GROCX_REF */
};

#if defined(G_ROCX)
static vtss_appl_grocx_port_map_t grocx_port_map[VTSS_PORT_ARRAY_SIZE];
#endif /* GROCX */

/* Determine if port is first router port */
static BOOL board_router_port_0(vtss_port_no_t port_no)
{
    return (board_port_map[port_no].chip_port == 4);
} 

/* Determine if port is second router port */
static BOOL board_router_port_1(vtss_port_no_t port_no)
{
    if (vtss_opt_router_wlan_rgmii)
        return 0;
    
    return (board_port_map[port_no].chip_port == 6 && 
            board_port_map[port_no].miim_controller == VTSS_MIIM_CONTROLLER_NONE);
} 

static BOOL board_router_port(vtss_port_no_t port_no)
{
    return (board_router_port_0(port_no) || board_router_port_1(port_no));
}

static vtss_port_interface_t
board_port_mac_interface(vtss_port_no_t port_no)
{
    vtss_port_interface_t if_type = VTSS_PORT_INTERFACE_INTERNAL;
    int chip_port = board_port_map[port_no].chip_port;
    if (chip_port == 5) 
        if_type = (VTSS_OPT_ROUTER_PORT_5_IF ? VTSS_PORT_INTERFACE_GMII : 
                   VTSS_PORT_INTERFACE_RGMII);
    if (chip_port == 6 && !board_router_port_1(port_no))
        if_type = VTSS_PORT_INTERFACE_RGMII;
    return if_type;
}

static void phy_reset(vtss_port_no_t port_no)
{
    /* THIS WILL BE MOVED INTO PHY API BY JAMES */
    /* IT EXECUTES PER PORT WHICH IS AN ERROR */

    /* Set WAN port phy 8601 RGMII skew value to 2.0ns */
       
    /* vtss_phy_page_ext(1); */
    vtss_phy_write(1, 31, 0x1);
    vtss_phy_writemasked(1, 28, 0xf000, 0xf000);    
    vtss_phy_write(1, 31, 0x0);
    /* vtss_phy_page_std(1); */       
}

static void 
board_port_setup(vtss_port_no_t port_no, vtss_port_setup_t * const setup)
{
    if (vtss_opt_router_port_wan == 0) {
        if(port_no == 1) {
            vtss_grocx_port_conf_t grocx_port_setup;
        
            grocx_port_setup.enable = 1;
            grocx_port_setup.speed = setup->interface_mode.speed;
            grocx_port_setup.fdx = setup->fdx;
            grocx_port_setup.flow_control = setup->flowcontrol.obey;
        
            vtss_grocx_port_setup(port_no, &grocx_port_setup);
            return;
        }
    }

    /* config A */
    if (vtss_opt_port_count == 7) {
        if(vtss_opt_router_port_wan == 1) {
            if(port_no == 7){
                setup->length_check = VTSS_LENGTH_TAG_SINGLE;
            }
        }
    }

#if defined(VTSS_FEATURE_QOS_TAG_REMARK)
    if(board_router_port(port_no)) {
        setup->length_check = VTSS_LENGTH_TAG_SINGLE;
    }
#endif

    vtss_port_setup(port_no, setup);
}

static void board_router_port_setup(vtss_port_no_t port_no, vtss_appl_port_conf_t *pc)
{
    /* Gnats 6214
       set shaper limiter at 500kbps to prevent unnecessary traffic from
       interrupting the cpu booting sequence */
    vtss_port_qos_get(port_no, &qos_port_ll_conf);
    qos_port_ll_conf.policer_port = VTSS_BITRATE_FEATURE_DISABLED;
    qos_port_ll_conf.shaper_port = 500;   
    vtss_port_qos_set(port_no, &qos_port_ll_conf);                           
    if (board_router_port_0(port_no)) {
#if VTSS_OPT_ROUTER_PORT_0_FLOW_CONTROL
        pc->flow_control = 1;
#else
        pc->flow_control = 0;
#endif /* VTSS_OPT_ROUTER_PORT_0_FLOW_CONTROL */
    }
}

#if defined(VTSS_FEATURE_QOS_TAG_REMARK)
/* Setup router VLANs */
static void board_router_vlan_setup(void)
{
    vtss_port_no_t        port_no;
    BOOL                  member[VTSS_PORT_ARRAY_SIZE];
    vtss_vlan_port_mode_t mode;
    uint                  count = 0;

    /* Count number of router ports */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        if (board_router_port(port_no))
            count++;
    
    /* Setup VLAN port mode */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        mode.aware = board_router_port(port_no);
        mode.pvid = (port_no == vtss_opt_router_port_wan || board_router_port_1(port_no) ? 
                     VTSS_ROUTER_VLAN_WAN : 
                     (port_no == VTSS_OPT_ROUTER_PORT_WAN2 ? VTSS_ROUTER_VLAN_WAN2 : 
                      VTSS_ROUTER_VLAN_LAN));
#if defined(VTSS_FEATURE_QOS_TAG_REMARK)
       mode.untagged_vid = ((board_router_port(port_no)) ? VTSS_VID_NULL : VTSS_VID_ALL);
        mode.frame_type = ((board_router_port(port_no)) ? VTSS_VLAN_FRAME_TAGGED : VTSS_VLAN_FRAME_UNTAGGED);
#else
        mode.untagged_vid = ((count == 1 && board_router_port(port_no)) ||
                             (count == 2 && VTSS_OPT_ROUTER_PORT_WAN2 && 
                              board_router_port_1(port_no)) ? VTSS_VID_NULL : VTSS_VID_ALL);
        mode.frame_type = VTSS_VLAN_FRAME_ALL;
#endif
        
        mode.ingress_filter = 0;
#if defined(VTSS_FEATURE_VLAN_TYPE_STAG)
        mode.stag = 0;
#endif /* VTSS_FEATURE_VLAN_TYPE_STAG */
        vtss_vlan_port_mode_set(port_no, &mode);
        member[port_no] = (mode.pvid == VTSS_ROUTER_VLAN_LAN);
    }
    
    /* Setup LAN VLAN members */
    vtss_vlan_port_members_set(VTSS_ROUTER_VLAN_LAN, member);
    
    /* Setup WAN VLAN members */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        member[port_no] = (port_no == vtss_opt_router_port_wan || 
                           (count == 1 && board_router_port_0(port_no)) ||
                           (count == 2 && board_router_port_1(port_no)));
    vtss_vlan_port_members_set(VTSS_ROUTER_VLAN_WAN, member);
    
#if VTSS_OPT_ROUTER_PORT_WAN2
    /* Setup WAN2 VLAN members */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        member[port_no] = (port_no == VTSS_OPT_ROUTER_PORT_WAN2 || 
                           (count == 1 && board_router_port_0(port_no)) ||
                           (count == 2 && board_router_port_1(port_no)));
    vtss_vlan_port_members_set(VTSS_ROUTER_VLAN_WAN2, member);
#endif /* VTSS_OPT_ROUTER_PORT_WAN2 */
}
#endif /* VTSS_FEATURE_QOS_TAG_REMARK */

static void board_startup(void)
{
    VTSS_MTIMER_START(&booting_wait_timer, 10000); /* Gnats 6214: 10 seconds */
}

static void board_run(void)
{
    if (!booting_start) { /* Gnats 6214 */
        if (port_config_type == GROCX_CONFIG_D) {  /* Config D's WAN port using star's MAC and connect to PHY-8601 */
            vtss_phy_writemasked(1, 0, 0x400 , 0x400); /* phy0 bit 10 is isolate from MAC to PHY */
        }
        if (VTSS_MTIMER_TIMEOUT(&booting_wait_timer)) {
            vtss_port_no_t          qos_port_no;
            
            booting_start = 1;
            /* Release the following setting  
             * set shaper limiter at 500kbps to prevent unnecessary traffic from
             * interrupting the cpu booting sequence */
            if (port_config_type == GROCX_CONFIG_D) { /* if config D, Remove isolate and Restart AN */
                vtss_phy_writemasked(1, 0, 0 , 0x400); 
            }
            for (qos_port_no = VTSS_PORT_NO_START; qos_port_no < VTSS_PORT_NO_END; qos_port_no++) { 
                if (board_router_port(qos_port_no)) {
                    vtss_port_qos_get(qos_port_no, &qos_port_ll_conf);
                    qos_port_ll_conf.policer_port = VTSS_BITRATE_FEATURE_DISABLED;
                    qos_port_ll_conf.shaper_port = VTSS_BITRATE_FEATURE_DISABLED;   
                    vtss_port_qos_set(qos_port_no, &qos_port_ll_conf); 
                }    
            }          
        }             
    }
}

static void
board_linkevent(vtss_linkevent_t event, vtss_port_no_t port_no)
{
    switch(event) {
    case VTSS_LINKEVENT_DOWN:
        if(grocx_port_map[port_no].port_role == WAN_PORT) {
            syslog(LOG_NOTICE, "%s port link loss detected", grocx_port_map[port_no].web_name);
            system("/sbin/ifdown wan");
        }
        break;
    case  VTSS_LINKEVENT_UP:
        if(grocx_port_map[port_no].port_role == WAN_PORT) {
            syslog(LOG_NOTICE, "%s port signal detect", grocx_port_map[port_no].web_name);
            system("/sbin/ifup wan");
        }
        break;
    }
}

static void sighandler_flash(int signum)
{
#if defined(BOARD_GROCX_REF) /* LED init for GROCX_REF Board */
    vtss_led_port_t led_port; 
    vtss_led_mode_t    led_mode[] = { VTSS_LED_MODE_10, VTSS_LED_MODE_10, VTSS_LED_MODE_10};
    flash_update++;
    for (led_port = 0; led_port <= 3; led_port++) {
        vtss_serial_led_set(led_port, led_mode);
    }
#endif /* BOARD_GROCX_REF */
    signal(SIGUSR1, sighandler_flash);
}

static void 
board_port_led_update(vtss_port_no_t port_no, vtss_port_status_t *port_status, BOOL act_update)
{   
#if defined(BOARD_GROCX_REF)
    static BOOL             is_init = 0;
    static vtss_counter_t   port_counter[4];
    static BOOL             act_status[4] = {0,0,0,0};
    static vtss_mtimer_t           act_timer;

    /* BOARD_GROCX_REF LED hardware spec(configuration B).
       
       Logical port number       LED port number
       =======================================
       P5/P4/P3/P2 ACT ---> LED0/1/2/3.0
       P5/P4/P3/P2 10/100 mode --> LED0/1/2/3.1
       P5/P4/P3/P2 GIGA mode --> LED0/1/2/3.2 
       
     */   
    vtss_port_no_t     port_maps[8] = {0xff,0xff,3,2,1,0,0xff,0xff}; /* Logic port map to LED port(Config B) */
    vtss_led_port_t    led_port; 
    vtss_led_mode_t    led_mode[3];
    vtss_poag_counters_t    counters;
    vtss_counter_t          current_counter;
    BOOL                    is_act = 0;
    
     if (is_init == 0) {
        memset(port_counter, 0, sizeof(port_counter));
        is_init = 1;
    }
    
    /* Check Active LED timer */
    if (VTSS_MTIMER_TIMEOUT(&act_timer)) {
        memset(act_status, 0, sizeof(act_status));
        VTSS_MTIMER_START(&act_timer, 200); /* 200ms */
    }
       
    led_port = port_maps[port_no];
    if (led_port == 0xff) {
        return;
    }
    
    if (act_status[led_port] == 1 && act_update == 1) {
        return; /* Don't change LED status too fast */
    } else if (act_update == 1) {
        vtss_poag_counters_get(port_no, &counters);
        current_counter  = (counters.if_group.ifInOctets + counters.if_group.ifOutOctets);
        if (current_counter != port_counter[port_no-2]) {
            is_act = 1;
            act_status[led_port] = 1;
            port_counter[port_no-2] = current_counter;
        }            
    }
        
    if (port_status->link) {
        /* Link up */
        if (!is_act) {
            led_mode[0] = VTSS_LED_MODE_OFF;
        } else {
            led_mode[0] = VTSS_LED_MODE_5;   
        }    
        if (port_status->speed == VTSS_SPEED_1G)
        {   /* Giga mode*/
            led_mode[1] = VTSS_LED_MODE_OFF;
            led_mode[2] = VTSS_LED_MODE_ON;
        } else {
            /* 10/100 mode */
            led_mode[1] = VTSS_LED_MODE_ON;
            led_mode[2] = VTSS_LED_MODE_OFF;
        }
        if(!flash_update)
            vtss_serial_led_set(led_port, &led_mode[0]);
    }            
    else {
        /* Link down */
        led_mode[0] = VTSS_LED_MODE_OFF;
        led_mode[1] = VTSS_LED_MODE_OFF;
        led_mode[2] = VTSS_LED_MODE_OFF;
        if(!flash_update)
            vtss_serial_led_set(led_port, &led_mode[0]);
    }             
#endif
} 

static void board_init(int argc, const char **argv)
{
    vtss_port_no_t port_no;

    /* initialize grocx router-core control interface */
    vtss_grocx_router_ioctl_init();
    vtss_grocx_router_port_config_type_get(&port_config_type);

    /* Catch SIGUSR1 - flash being updated */
    signal(SIGUSR1, sighandler_flash);

    if(port_config_type == GROCX_CONFIG_A) {
        vtss_opt_router_wlan_rgmii=1;
        vtss_opt_port_count=7;
        vtss_opt_router_port_wan=1;
    }
    else if(port_config_type == GROCX_CONFIG_D) {
        vtss_opt_router_wlan_rgmii=1;
    }
    else{
        vtss_opt_router_port_wan=1;
    }

    /*  Initilize structure   */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        grocx_port_map[port_no].port_role = LAN_PORT;
        strcpy(grocx_port_map[port_no].web_name,"N/A");
    }
    
#if (VTSS_PORTS == 7)
    /* Port 7 is always router if VTSS_PORTS equal 7 */
    grocx_port_map[7].port_role = ROUTER_PORT;
#else
    /* Port 6 is always router if VTSS_PORTS equal 6 */
    grocx_port_map[6].port_role = ROUTER_PORT;
#endif

    if (port_config_type == GROCX_CONFIG_A) {
        grocx_port_map[1].port_role = WAN_PORT;
        strcpy(grocx_port_map[1].web_name,"WAN");
        strcpy(grocx_port_map[2].web_name,"LAN1");
        strcpy(grocx_port_map[3].web_name,"LAN2");
        strcpy(grocx_port_map[4].web_name,"LAN3");
        strcpy(grocx_port_map[5].web_name,"LAN4");
#if defined(BOARD_GROCX_REF)
        strcpy(grocx_port_map[6].web_name,"WiFi1");
        grocx_port_map[6].port_role = WIFI_PORT;
#endif
    }

    if (port_config_type == GROCX_CONFIG_B) {
        grocx_port_map[1].port_role = WAN_PORT;
        grocx_port_map[6].port_role = ROUTER_PORT;
        grocx_port_map[7].port_role = ROUTER_PORT;
        strcpy(grocx_port_map[1].web_name,"WAN");
        strcpy(grocx_port_map[2].web_name,"LAN1");
        strcpy(grocx_port_map[3].web_name,"LAN2");
        strcpy(grocx_port_map[4].web_name,"LAN3");
        strcpy(grocx_port_map[5].web_name,"LAN4");
    }

    if (port_config_type == GROCX_CONFIG_C) {        
        grocx_port_map[7].port_role = NOT_CONNECTED;
        strcpy(grocx_port_map[1].web_name,"LAN1");
        strcpy(grocx_port_map[2].web_name,"LAN2");
        strcpy(grocx_port_map[3].web_name,"LAN3");
        strcpy(grocx_port_map[4].web_name,"LAN4");
        strcpy(grocx_port_map[5].web_name,"LAN5");
        strcpy(grocx_port_map[7].web_name,"WAN");

    }

    if (port_config_type == GROCX_CONFIG_D) {
        grocx_port_map[1].port_role = NOT_CONNECTED;
        strcpy(grocx_port_map[1].web_name,"WAN");
        strcpy(grocx_port_map[2].web_name,"LAN1");
        strcpy(grocx_port_map[3].web_name,"LAN2");
        strcpy(grocx_port_map[4].web_name,"LAN3");
        strcpy(grocx_port_map[5].web_name,"LAN4");
#if defined(BOARD_GROCX_REF)
        strcpy(grocx_port_map[6].web_name,"WiFi1");
        grocx_port_map[6].port_role = WIFI_PORT;
#else        
        strcpy(grocx_port_map[6].web_name,"LAN5");
#endif
    }

#if defined(VTSS_FEATURE_QOS_TAG_REMARK)
    board_router_vlan_setup();
#endif

#if defined(BOARD_GROCX_REF) /* LED init for GROCX_REF Board */
    vtss_led_port_t led_port; 
    vtss_led_mode_t led_mode[3];

    led_mode[0] = VTSS_LED_MODE_OFF;
    led_mode[1] = VTSS_LED_MODE_OFF;
    led_mode[2] = VTSS_LED_MODE_OFF;
    /* set the first four ports to "off" mode */
    for (led_port = 0; led_port <= 3; led_port++) {
        vtss_serial_led_set(led_port, &led_mode[0]);
    }    

    led_mode[0] = VTSS_LED_MODE_DISABLED;
    led_mode[1] = VTSS_LED_MODE_DISABLED;
    led_mode[2] = VTSS_LED_MODE_DISABLED;
    /* set the rest ports to "disable" mode */
    for (led_port = 4; led_port <= 15; led_port++) {
        vtss_serial_led_set(led_port, &led_mode[0]);
    }
    
    /* use enhanced led mode for VSC8601 */
    vtss_phy_write(1, 31, 0x1);
    vtss_phy_write(1, 17, 0x10);
    vtss_phy_write(1, 16, 0x61a);
    vtss_phy_write(1, 17, 0x14d6);
    vtss_phy_write(1, 31, 0x0);
#endif /* BOARD_GROCX_REF */
}

/* Initialize CPU/switch interface */
static void
board_connect(int argc, const char **argv, vtss_io_state_t *io) 
{
    /* Open driver */
    if ((io->fd = open("/dev/vitgenio", 0)) < 0) {
        VTSS_E(("open(\"/dev/vitgenio\"): %s",strerror(errno)));
        exit(1);
    }
}

void vtss_board_hookup(struct vtss_board *board, int argc, const char **argv)
{
#if defined(BOARD_GROCX_EVAL)
    board->name = "Intrigue Validation";
#endif
#if defined(BOARD_GROCX_REF)
    board->name = "G-RocX (Scutum)";
#endif
    board->port_map = board_port_map;
    board->connect = board_connect;
    board->init = board_init;
    board->port_mac_interface = board_port_mac_interface;
    board->phy_reset = phy_reset;
    board->port_setup = board_port_setup;
    board->router_port = board_router_port;
    board->router_port_setup = board_router_port_setup;
    board->startup = board_startup;
    board->run = board_run;
    board->linkevent = board_linkevent;
    board->port_led_update = board_port_led_update;
}

#if defined(G_ROCX)
vtss_rc vtss_appl_grocx_port_map_get(const vtss_port_no_t port_no, vtss_appl_grocx_port_map_t * const map)
{
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }    
    *map = grocx_port_map[port_no];
    return VTSS_OK;
}
#endif /* G_ROCX */
