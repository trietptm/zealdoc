/*

 Vitesse Switch/PHY API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_os.c,v 1.7 2008/02/20 15:04:53 cpj Exp $
 $Revision: 1.7 $

*/

#include "vtss_os.h"
#include "vtss_basic_trace.h"

#ifdef VTSS_OPSYS_ECOS
vtss_common_assert_cb_t vtss_common_assert_cb=NULL;

void vtss_common_assert_cb_set(vtss_common_assert_cb_t cb)
{
    VTSS_ASSERT(vtss_common_assert_cb==NULL);
    vtss_common_assert_cb = cb;
}
#endif

/* ================================================================= *
 * Endianess 
 * ================================================================= */

ulong vtss_htonl(const ulong hostlong)
{
#ifdef VTSS_BIG_ENDIAN
    return hostlong;
#else
    /* Little endian */
    return 
        (hostlong >> 24) | 
        ((hostlong & 0xff0000) >> 8)  |
        ((hostlong & 0xff00)   << 8)  | 
        (hostlong << 24);
#endif
} /* vtss_htonl */


ulong vtss_ntohl(const ulong netlong)
{
    return vtss_htonl(netlong); /* Operation is symmetric */
} /* vtss_ntohl */


uint  vtss_htons(const uint hostshort)
{
#ifdef VTSS_BIG_ENDIAN
    return hostshort;
#else
    return ((hostshort & 0xff00) >> 8) | ((hostshort & 0x00ff)  << 8);
#endif
} /* vtss_htons */


uint  vtss_ntohs(const uint netshort)
{
    return vtss_htons(netshort); /* Operation is symmetric */
} /* vtss_ntohs */
