/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_io.c,v 1.23 2008/06/25 07:50:57 cpj Exp $
 $Revision: 1.23 $

*/

#define VTSS_TRACE_LAYER 1
#define VTSS_TRACE_FILE "io"

/* Standard headers */
#ifdef VTSS_VITGENIO
#include <string.h>
#include <linux/vitgenio.h>
#include <sys/ioctl.h> /* ioctl() */
#endif /* VTSS_VITGENIO */
#ifdef VTSS_LINUX_RAWSOCK_IO
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#endif /* VTSS_LINUX_RAWSOCK_IO */

#ifdef VTSS_IO_RABBIT
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#undef __USE_EXTERN_INLINES /* Avoid warning */
#include <sys/socket.h>
#endif /* VTSS_IO_RABBIT */

/* API public headers */
#include "vtss_switch_api.h"
#include "vtss_basic_trace.h"

/* API private headers */
#include "vtss_state.h"
#ifdef VTSS_IO_HEATHROW
#include "vtss_sparx_reg.h"
#endif /* VTSS_IO_HEATHROW */
#ifdef VTSS_IO_GATWICK
#include "vtss_gatwick_reg.h"
#endif /* VTSS_IO_GATWICK */
#ifdef VTSS_ARCH_B2
#include "vtss_b2_reg.h"
#endif /* VTSS_ARCH_B2 */

static vtss_io_state_t *vtss_io_state;

/* Select chip */
void vtss_io_select_chip(vtss_io_state_t *io)
{
    vtss_io_state=io;
}

/* Reset I/O Layer, must be called before any other function */
void vtss_io_init(void)
{
    VTSS_D(("enter"));
}

#ifdef VTSS_IO_HEATHROW

vtss_rc vtss_io_si_rd(uint block, uint subblock, const uint reg, ulong * const value)
{
    vtss_rc rc=VTSS_OK;
#ifdef VTSS_VITGENIO
    struct vitgenio_cpld_spi_readwrite spibuf;
  
    spibuf.length=6;

    spibuf.buffer[0]=(block<<5) | (0/*READ*/<<4) | (subblock<<0);
    spibuf.buffer[1]=reg;
    spibuf.buffer[2]=0;
    spibuf.buffer[3]=0;
    spibuf.buffer[4]=0;
    spibuf.buffer[5]=0;
    if (ioctl(vtss_io_state->fd,VITGENIO_CPLD_SPI_READWRITE,&spibuf)<0) {
        VTSS_E(("ioctl(fd,VITGENIO_CPLD_SPI_READWRITE) failed"));
        *value=0;
        rc=VTSS_IO_READ_ERROR;
    } else {
        *value=((spibuf.buffer[2]<<24) | (spibuf.buffer[3]<<16) | \
                (spibuf.buffer[4]<<8) | (spibuf.buffer[5]<<0));
    }
#endif /* VTSS_VITGENIO */

    VTSS_N(("block: 0x%02x, subblock: 0x%02x, reg: 0x%02x, value: 0x%08lx",
            block,subblock,reg,*value));

    return rc;
}

vtss_rc vtss_io_si_wr(uint block, uint subblock, const uint reg, const ulong value)
{
    vtss_rc rc=VTSS_OK;
#ifdef VTSS_VITGENIO
    struct vitgenio_cpld_spi_readwrite spibuf;
  
    spibuf.length=6;

    spibuf.buffer[0]=(block<<5) | (1/*WRITE*/<<4) | (subblock<<0);
    spibuf.buffer[1]=reg;
    spibuf.buffer[2]=((value>>24) & 0xff);
    spibuf.buffer[3]=((value>>16) & 0xff);
    spibuf.buffer[4]=((value>>8) & 0xff);
    spibuf.buffer[5]=(value & 0xff);
    if (ioctl(vtss_io_state->fd,VITGENIO_CPLD_SPI_READWRITE,&spibuf)<0) {
        VTSS_E(("ioctl(fd,VITGENIO_CPLD_SPI_READWRITE) failed"));
        rc=VTSS_IO_WRITE_ERROR;
    }
#endif /* VTSS_VITGENIO */

    VTSS_N(("block: 0x%02x, subblock: 0x%02x, reg: 0x%02x, value: 0x%08lx",
            block,subblock,reg,value));
    return rc;
}

static vtss_rc vtss_io_pi_rd_fast(uint block, uint subblock, const uint reg, ulong *value)
{
    vtss_rc                         rc=VTSS_OK;
#ifdef VTSS_VITGENIO
    struct vitgenio_32bit_readwrite pibuf;
    
    pibuf.offset=(block<<12)|(subblock<<8)|(reg<<0);
#ifdef BOARD_SPARX_G24_STAR
    /* The address pins on this board is connected shifted by 1 */
    pibuf.offset<<=1;
#endif
    if (ioctl(vtss_io_state->fd,VITGENIO_32BIT_READ,&pibuf)<0) {
        VTSS_E(("ioctl(fd,VITGENIO_32BIT_READ) failed"));
        *value=0;
        rc=VTSS_IO_READ_ERROR;
    } else {
        *value=pibuf.value;
    }
#endif /* VTSS_VITGENIO */
#ifdef VTSS_MEMORYMAPPEDIO
    uint offset = (block<<12)|(subblock<<8)|(reg<<0);
#ifdef BOARD_SPARX_G24_STAR
    /* The address pins on this board is connected shifted by 1 */
    offset<<=1;
#endif
    *value=vtss_io_state->baseaddr[offset];
#endif /* VTSS_MEMORYMAPPEDIO */

/*
    VTSS_N(("block: 0x%02x, subblock: 0x%02x, reg: 0x%02x, value: 0x%08lx",
            block,subblock,reg,*value));
*/
    return rc;
}

vtss_rc vtss_io_pi_rd(uint block, uint subblock, const uint reg, ulong * const value)
{
    vtss_rc rc;

    if (
#if defined(VTSS_FEATURE_PI_SLOWMODE)
        vtss_api_state->init_setup.pi_use_extended_buscycle ||
#endif /* VTSS_FEATURE_PI_SLOWMODE */
        block == B_CAPTURE || block == B_SYSTEM) {
        rc=vtss_io_pi_rd_fast(block,subblock,reg,value);
    } else {
        int   i;
        ulong val;

        if ((rc=vtss_io_pi_rd_fast(block,subblock,reg,&val))<0)
            return rc;
        for (i=0;;i++) {
            if ((rc=vtss_io_pi_rd_fast(B_SYSTEM,0,R_SYSTEM_CPUCTRL,&val))<0)
                break;
            if (val & (1<<4)) {
                rc=vtss_io_pi_rd_fast(B_SYSTEM,0,R_SYSTEM_SLOWDATA,value);
                break;
            }
            if (i==25) {
                VTSS_E(("block: 0x%02x, subblock: 0x%02x, reg: 0x%02x, DONE failed after %d retries",
                         block,subblock,reg,i));
                rc=VTSS_IO_READ_ERROR;
                break;
            }
        };
    }

    VTSS_N(("block: 0x%02x, subblock: 0x%02x, reg: 0x%02x, value: 0x%08lx",
            block,subblock,reg,*value));
    return rc;
}

vtss_rc vtss_io_pi_wr(uint block, uint subblock, const uint reg, const ulong value)
{
    vtss_rc                         rc=VTSS_OK;
#ifdef VTSS_VITGENIO
    struct vitgenio_32bit_readwrite pibuf;
    
    pibuf.offset=(block<<12)|(subblock<<8)|(reg<<0);
#ifdef BOARD_SPARX_G24_STAR
    /* The address pins on this board is connected shifted by 1 */
    pibuf.offset<<=1;
#endif
    pibuf.value=value;
    if (ioctl(vtss_io_state->fd,VITGENIO_32BIT_WRITE,&pibuf)<0) {
        VTSS_E(("ioctl(fd,VITGENIO_32BIT_WRITE) failed"));
        rc=VTSS_IO_WRITE_ERROR;
    }
#endif /* VTSS_VITGENIO */
#ifdef VTSS_MEMORYMAPPEDIO
    uint offset = (block<<12)|(subblock<<8)|(reg<<0);
#ifdef BOARD_SPARX_G24_STAR
    /* The address pins on this board is connected shifted by 1 */
    offset<<=1;
#endif
    vtss_io_state->baseaddr[offset]=value;
#endif /* VTSS_MEMORYMAPPEDIO */

    VTSS_N(("block: 0x%02x, subblock: 0x%02x, reg: 0x%02x, value: 0x%08lx",
            block,subblock,reg,value));

    return rc;
}

#endif /* VTSS_IO_HEATHROW */

#ifdef VTSS_IO_GATWICK

#if VTSS_OPT_DMA
static vtss_rc vtss_io_dma_start(void)
{
#ifdef VTSS_VITGENIO
    struct vitgenio_dma_start vds;

    memset(&vds, 0, sizeof(vds));
    vds.channel = vtss_io_state->dma_ch;
    vds.direction_write = 0;
    vds.autoinc = 0;
    vds.offset = 0;		/* for device selected by CS */
    vds.count = vtss_io_state->dma_size / sizeof(long);
    vds.nonblocking = 1;
    VTSS_D(("Starting DMA for channel %d", vtss_io_state->dma_ch));
    vtss_io_state->dma_offs = 0;
    if (ioctl(vtss_io_state->fd, VITGENIO_DMA_START, &vds) < 0) {
        VTSS_E(("VITGENIO_DMA_START (channel %d) failed: %s", 
                vtss_io_state->dma_ch, strerror(errno)));
        return VTSS_IO_READ_ERROR;
    }
#endif /* VTSS_VITGENIO */
    return VTSS_OK;
}

vtss_rc vtss_io_dma_init(void)
{
#ifdef VTSS_VITGENIO
    struct vitgenio_dma_setup_timing vdst;

    memset(&vdst, 0, sizeof(vdst));
    vdst.channel = vtss_io_state->dma_ch;
    vdst.mode = VITGENIO_DMA_MODE_REQACK;
    vdst.cp = VITGENIO_DMA_PRIO_LOW;
    vdst.ben = VITGENIO_DMA_BUFFER_32BYTE;
    vdst.eot_activelow = 1;
    vdst.dmareq_activelow = 1;
    vdst.dmaack_activelow = 1;
    vdst.psc = 0;
    vdst.pwc = 4;
    vdst.phc = 0;
    VTSS_D(("Setting DMA timing for channel %d\n", vtss_io_state->dma_ch));
    if (ioctl(vtss_io_state->fd, VITGENIO_DMA_SETUP_TIMING, &vdst) < 0) {
        VTSS_E(("VITGENIO_DMA_SETUP_TIMING (channel %d) failed: %s", 
                vtss_io_state->dma_ch, strerror(errno)));
        return VTSS_IO_READ_ERROR;
    }
    return vtss_io_dma_start();
#endif /* VTSS_VITGENIO */
    return VTSS_OK;
}

/* Read data from DMA buffer and move forward. Parameters:
   len : Number of bytes to read
   data: Data buffer
   skip: Number of additional bytes to skip (e.g. FCS) */
vtss_rc vtss_io_dma_read(int len, uchar *data, int skip)
{
#ifdef VTSS_VITGENIO
    int i, n, size, copy_len, skip_len, data_offs = 0;
    
    for (i = 0; i < 1000; i++) {

        /* Read DMA status */
        if ((n = ioctl(vtss_io_state->fd, VITGENIO_DMA_STATUS, vtss_io_state->dma_ch)) < 0) {
            VTSS_D(("DMA Status (channel %d) failed: %s",
                    vtss_io_state->dma_ch, strerror(errno)));
            return VTSS_IO_DMA;
        }

        /* Calculate current DMA data size */
        size = (vtss_io_state->dma_size - n * sizeof(long) - vtss_io_state->dma_offs);
        
        /* If buffer is empty from the start, return */
        if (i == 0 && size == 0) {
            return VTSS_DATA_NOT_READY;
        }

        VTSS_D(("Ch: %d, i: %d, len: %d, skip: %d, size: %d",
                vtss_io_state->dma_ch,i,len,skip,size));
        
        /* Copy data if there is room for more */
        if (len != data_offs) {
            copy_len = (size > (len - data_offs) ? (len - data_offs) : size);
            memcpy(data + data_offs, vtss_io_state->dma_mem + vtss_io_state->dma_offs, copy_len);
            vtss_io_state->dma_offs += copy_len;
            size -= copy_len;
            data_offs += copy_len;
            VTSS_D(("Copied %d bytes, data_offs: %d",copy_len,data_offs));
        }

        /* Skip specified data if all data has been copied */
        if (len == data_offs) {
            skip_len = (size > skip ? skip : size); 
            vtss_io_state->dma_offs += skip_len;
            skip -= skip_len;
            size -= skip_len;
            VTSS_D(("Skipped %d bytes",skip_len));
            /* If all data has been copied and skipped and more data is available, return */
            if (skip == 0 && size != 0) {
                VTSS_D(("More data, remaining size: %d",size));
                return VTSS_OK;
            }
        }

        /* If DMA buffer full, restart DMA */
        if (vtss_io_state->dma_size == vtss_io_state->dma_offs) {
            VTSS_D(("DMA Restart (channel %d)", vtss_io_state->dma_ch));
            vtss_io_dma_start();
        }

        /* If all data has been copied and skipped, return */
        if (len == data_offs && skip == 0) {
            VTSS_D(("Last data, remaining size: %d",size));
            return VTSS_OK;
        }
    }
    VTSS_E(("DMA failed (channel %d)", vtss_io_state->dma_ch));
#endif /* VTSS_VITGENIO */
    return VTSS_IO_DMA;
}
#endif /* VTSS_OPT_DMA */

/* Read SI register */
vtss_rc vtss_io_si_rd(uint target, uint address, ulong *value) 
{
    vtss_rc rc = VTSS_OK;
#ifdef VTSS_VITGENIO
    struct vitgenio_cpld_spi_readwrite spibuf;
  
    spibuf.length = 6;

    spibuf.buffer[0] = target;
    spibuf.buffer[1] = address;
    spibuf.buffer[2] = 0;
    spibuf.buffer[3] = 0;
    spibuf.buffer[4] = 0;
    spibuf.buffer[5] = 0;
    if (ioctl(vtss_io_state->fd, VITGENIO_CPLD_SPI_READWRITE, &spibuf)<0) {
        VTSS_E(("ioctl(fd,VITGENIO_CPLD_SPI_READWRITE) failed"));
        *value = 0;
        rc = VTSS_IO_READ_ERROR;
    } else {
        *value = ((spibuf.buffer[2]<<24) | (spibuf.buffer[3]<<16) |
                  (spibuf.buffer[4]<<8) | (spibuf.buffer[5]<<0));
    }
#endif /* VTSS_VITGENIO */

    VTSS_N(("target: 0x%02x, address: 0x%02x, value: 0x%08lx",target,address,*value));

    return rc;
}

/* Write SI register */
vtss_rc vtss_io_si_wr(uint target, uint address, ulong value)
{
    vtss_rc rc = VTSS_OK;
#ifdef VTSS_VITGENIO
    struct vitgenio_cpld_spi_readwrite spibuf;
  
    spibuf.length = 6;

    spibuf.buffer[0] = (0x80 | target);
    spibuf.buffer[1] = address;
    spibuf.buffer[2] = ((value>>24) & 0xff);
    spibuf.buffer[3] = ((value>>16) & 0xff);
    spibuf.buffer[4] = ((value>>8) & 0xff);
    spibuf.buffer[5] = (value & 0xff);
    if (ioctl(vtss_io_state->fd, VITGENIO_CPLD_SPI_READWRITE, &spibuf)<0) {
        VTSS_E(("ioctl(fd,VITGENIO_CPLD_SPI_READWRITE) failed"));
        rc = VTSS_IO_WRITE_ERROR;
    }
#endif /* VTSS_VITGENIO */
    VTSS_N(("target: 0x%02x, address: 0x%02x, value: 0x%08lx",target,address,value));

    return rc;
}

/* Read PI register */
vtss_rc vtss_io_pi_rd(uint block, uint address, ulong *value) 
{
    vtss_rc rc = VTSS_OK;
#ifdef VTSS_VITGENIO
    struct vitgenio_32bit_readwrite pibuf;
    
    pibuf.offset = ((block<<5) | address);
    if (ioctl(vtss_io_state->fd, VITGENIO_32BIT_READ, &pibuf)<0) {
        VTSS_E(("ioctl(fd,VITGENIO_32BIT_READ) failed"));
        *value = 0;
        rc = VTSS_IO_READ_ERROR;
    } else {
        *value = pibuf.value;
    }
#endif /* VTSS_VITGENIO */
#ifdef VTSS_MEMORYMAPPEDIO
    *value = vtss_io_state->baseaddr[(block<<5)|address];
#endif /* VTSS_MEMORYMAPPEDIO */

    VTSS_N(("block: 0x%02x (%s), address: 0x%02x, value: 0x%08lx",
            block,
            block==T_CPU_PMB ? "cpu_pmb" : 
            block==T_CPU_PIA ? "cpu_pia" : 
            block==T_CPU_PQS ? "cpu_pqs" : "cpu_???",
            address,*value));
    return rc;
}

/* Write PI register */
vtss_rc vtss_io_pi_wr(uint block, uint address, ulong value)
{
    vtss_rc rc = VTSS_OK;
#ifdef VTSS_VITGENIO
    struct vitgenio_32bit_readwrite pibuf;
#endif /* VTSS_VITGENIO */

    VTSS_N(("block: 0x%02x (%s), address: 0x%02x, value: 0x%08lx",
            block,
            block==T_CPU_PMB ? "cpu_pmb" : 
            block==T_CPU_PIA ? "cpu_pia" : 
            block==T_CPU_PQS ? "cpu_pqs" : "cpu_???",
            address,value));
    
#ifdef VTSS_VITGENIO
    pibuf.offset = ((block<<5) | address);
    pibuf.value = value;
    if (ioctl(vtss_io_state->fd, VITGENIO_32BIT_WRITE, &pibuf)<0) {
        VTSS_E(("ioctl(fd,VITGENIO_32BIT_WRITE) failed"));
        rc = VTSS_IO_WRITE_ERROR;
    } 
#endif /* VTSS_VITGENIO */
#ifdef VTSS_MEMORYMAPPEDIO
    vtss_io_state->baseaddr[(block<<5)|address] = value;
#endif /* VTSS_MEMORYMAPPEDIO */

    return rc;
}

/* Read target register using PI */
vtss_rc vtss_io_pi_tgt_rd(uint target, uint address, ulong *value)
{
    vtss_rc rc;
    uint    i;
    ulong   addr_reply;

    /* Write a target read request */
    if ((rc = vtss_io_pi_wr(TR(CPU_PIA,ADDR_REQ),
                            (address<<O_CPU_PIA_ADDR_REQ_REQ_TARGET_ADDRESS) |
                            (target<<O_CPU_PIA_ADDR_REQ_REQ_TARGET_MODULE) |
                            (0<<O_CPU_PIA_ADDR_REQ_REQ_WRITE_REQUEST) |
                            (1<<O_CPU_PIA_ADDR_REQ_REQ_STATUS)))<0) {
        return rc;
    }

    /* Read reply FIFO until valid */
    for (i=0;; i++) {
        if ((rc = vtss_io_pi_rd(TR(CPU_PIA,ADDR_REPLY),&addr_reply))<0) {
            break;
        }
        if (i==25) {
            VTSS_E(("target: 0x%02x, address: 0x%02x address failed after %d retries",
               target,address,i));
            rc = VTSS_IO_READ_ERROR;
            break;
        }

        if (TRF(addr_reply,CPU_PIA,ADDR_REPLY,REP_VALID)) {
            /* Reply register is valid */

            /* Check target unknown field */
            if (TRF(addr_reply,CPU_PIA,ADDR_REPLY,REP_TGT_UNKNOWN)) {
                VTSS_E(("target: 0x%02x, address: 0x%02x unknown",target,address));
                rc = VTSS_IO_READ_ERROR;
                break;
            }
            
            /* Check target busy field */
            if (TRF(addr_reply,CPU_PIA,ADDR_REPLY,REP_TGT_BUSY)) {
                VTSS_E(("target: 0x%02x, address: 0x%02x busy",target,address));
                rc = VTSS_IO_READ_ERROR;
                break;
            }
            
            /* Check target status field */
            if (TRF(addr_reply,CPU_PIA,ADDR_REPLY,REP_STATUS)==0) {
                VTSS_E(("target: 0x%02x, address: 0x%02x status error",target,address));
                rc = VTSS_IO_READ_ERROR;
                break;
            }
            
            /* Check that the reply target matches */
            if (TRF(addr_reply,CPU_PIA,ADDR_REPLY,REP_TARGET_MODULE)!=target) {
                VTSS_E(("target: 0x%02x, address: 0x%02x target mismatch",target,address));
                rc = VTSS_IO_READ_ERROR;
                break;
            }

            /* Check that the reply address matches */
            if (TRF(addr_reply,CPU_PIA,ADDR_REPLY,REP_TARGET_ADDRESS)!=address) {
                VTSS_E(("target: 0x%02x, address: 0x%02x address mismatch",target,address));
                rc = VTSS_IO_READ_ERROR;
                break;
            }

            /* Success, read reply data */
            rc = vtss_io_pi_rd(TR(CPU_PIA,DATA_REPLY), value);
            break;
        }
        VTSS_NSLEEP(100);
    }

    return rc;
}

/* Write target register using PI */
vtss_rc vtss_io_pi_tgt_wr(uint target, uint address, ulong value)
{
    vtss_rc rc;

    /* Write a target write request */
    rc = vtss_io_pi_wr(TR(CPU_PIA,ADDR_REQ),
                       (address<<O_CPU_PIA_ADDR_REQ_REQ_TARGET_ADDRESS) |
                       (target<<O_CPU_PIA_ADDR_REQ_REQ_TARGET_MODULE) |
                       (1<<O_CPU_PIA_ADDR_REQ_REQ_WRITE_REQUEST) |
                       (0<<O_CPU_PIA_ADDR_REQ_REQ_STATUS));
    if (rc>=0) {
        /* Write the data */
        rc = vtss_io_pi_wr(TR(CPU_PIA,DATA_REQ), value);
    }

    return rc;
}

#endif /* VTSS_IO_GATWICK */

#if VTSS_OPT_NICIO
/* --- Functions provided by NIC Driver to Switch API's I/O Layer --- */

/* ----------- TX ----------- */

/* Copy raw frame to OS driver's tx frame buffer and enqueue OS buffer for transmission */
/* This function will calculate and append checksum */
/* This function will also pad frame to 64 bytes length (incl. checksum) */
vtss_rc vtss_io_nic_tx( const uchar * const frame,
                        const uint          length )
{
#ifdef VTSS_LINUX_RAWSOCK_IO
    const int rc = send(vtss_io_state->nic_fd, frame, length, 0);

    if (rc != length) {
        VTSS_E(("send(nic_fd) failed. Length=%0d rc=%d errno %d (%s)",
                length, rc, errno, strerror(errno)));
        return VTSS_IO_NIC_WRITE_ERROR;
    }
    return VTSS_OK;
#else
    /* Roll your own interface to HW driver */
    return VTSS_OK;
#endif
}

/* ----------- RX ----------- */

/* Is an OS rx frame buffer ready for reading */
/* Returns: 0: no frame ready, <0: error, >0: frame ready */
vtss_rc vtss_io_nic_rx_ready(void)
{
#ifdef VTSS_LINUX_RAWSOCK_IO
    fd_set readfds;
    struct timeval tv;
    int n;

    FD_ZERO(&readfds);
    FD_SET(vtss_io_state->nic_fd, &readfds);
    timerclear(&tv);
    if ((n = select(vtss_io_state->nic_fd + 1, &readfds, NULL, NULL, &tv)) < 0) {
        VTSS_E(("select(nic_fd %d) failed: errno %d", vtss_io_state->nic_fd, errno));
        return VTSS_IO_NIC_ERROR;
    }
    return MAKEBOOL01(n);
#else
    /* Roll your own interface to HW driver */
    return 0;
#endif
}

/* Copy raw frame from OS driver's rx frame buffer and release OS driver's rx frame buffer */
vtss_rc vtss_io_nic_rx(uchar * const frame,
                       const uint maxlength)
{
#ifdef VTSS_LINUX_RAWSOCK_IO
    const int length = recv(vtss_io_state->nic_fd, frame, maxlength, 0);

    if (length <= 0) {
        VTSS_E(("recv(nic_fd) failed. MaxLength=%0d, rc = %d errno %d (%s)",
                maxlength, length, errno, strerror(errno)));
        return VTSS_IO_NIC_READ_ERROR;
    }
    return length;
#else
    /* Roll your own interface to HW driver */
    return 0;
#endif
}
#endif /* VTSS_OPT_NICIO */

#if defined(VTSS_ARCH_B2)

#if defined(VTSS_IO_RABBIT)
/* Execute Rabbit command */
vtss_rc vtss_rabbit_cmd(const char *cmd, ulong *value)
{
    char buf[100];
    int  n;

    /* Send command terminated by newline */
    strcpy(buf, cmd);
    n = strlen(buf);
    buf[n] = '\n';
    if (send(vtss_io_state->s, buf, n + 1, 0) < 0) {
        VTSS_E(("send cmd failed: %s", cmd));
        return VTSS_IO_WRITE_ERROR;
    }
    VTSS_N(("send: %s", cmd));
    /* Receive command reply */
    if ((n = recv(vtss_io_state->s, buf, sizeof(buf), 0)) < 0) {
        VTSS_E(("recv cmd failed: %s", cmd));
        return VTSS_IO_READ_ERROR;
    }
    buf[n - 1] = '\0';
    VTSS_N(("recv: %s", buf));

    if (value != NULL && n == sizeof("[0x12345678]") && strstr(buf, "[0x") == buf) {
        *value = strtoul(buf + 1, NULL, 0);
        VTSS_N(("value: 0x%08lx", *value));
    }
    return VTSS_OK;
}    

/* Execute Rabbit direct read/write command */
static vtss_rc vtss_rabbit_rd_wr(ulong addr, ulong *value, BOOL read)
{
    char  cmd[64], data[9];
    
    if (read)
        data[0] = '\0';
    else
        sprintf(data, "%08lx", *value);
    sprintf(cmd, "%s%08lx%s%s", 
            read ? "WPRP 0x2018 0x" : "WP 0x2000 0x", 
            0x84000000 + addr, 
            data, 
            read ? "03" : "02");
    return vtss_rabbit_cmd(cmd, value);
}
#endif /* VTSS_IO_RABBIT */    

/* Read register via PI */
static vtss_rc vtss_pi_rd(ulong addr, ulong *value) 
{
#if defined(VTSS_IO_RABBIT)
    return vtss_rabbit_rd_wr(addr, value, 1);
#endif /* VTSS_IO_RABBIT */
    return VTSS_OK;
}

/* Write register via PI */
static vtss_rc vtss_pi_wr(ulong addr, ulong value)
{
#if defined(VTSS_IO_RABBIT)
    return vtss_rabbit_rd_wr(addr, &value, 0);
#endif /* VTSS_IO_RABBIT */    
    return VTSS_OK;
}

/* Read or write target register via PI */
vtss_rc vtss_io_pi_rd_wr(uint tgt, uint addr, ulong *value, BOOL read)
{
    int   i;
    ulong address, val, mask;
    
    address = (tgt << 18);
    if (tgt == VTSS_TGT_DEVCPU_ORG || tgt == VTSS_TGT_FAST_REGS) {
        /* Direct operation */
        address += (addr << 1);
        return (read ? vtss_pi_rd(address, value) : vtss_pi_wr(address, *value));
    }

    /* Indirect operation */
    address += (addr << 2);
    if (read) {
        VTSS_RC(vtss_pi_rd(address, &val));
    } else {
        val = *value;
        VTSS_RC(vtss_pi_wr(address,     val >> 16));    /* MSB */
        VTSS_RC(vtss_pi_wr(address + 2, val & 0xffff)); /* LSB */
    }

    /* Wait for operation to complete */
    mask = ((1 << VTSS_OFF_FAST_REGS_CFG_STATUS_2_WR_IN_PROGRESS) |
            (1 << VTSS_OFF_FAST_REGS_CFG_STATUS_2_RD_IN_PROGRESS));
    for (i = 0; i < 25; i++) {
        VTSS_RC(vtss_io_pi_rd_wr(VTSS_TGT_FAST_REGS, 
                                 VTSS_ADDR_FAST_REGS_CFG_STATUS_2, &val, 1));
        if ((val & mask) == 0) {
            /* Read/write operation completed */
            if (read) {
                VTSS_RC(vtss_io_pi_rd_wr(VTSS_TGT_FAST_REGS, 
                                         VTSS_ADDR_FAST_REGS_SLOWDATA_MSB, &val, 1));
                VTSS_RC(vtss_io_pi_rd_wr(VTSS_TGT_FAST_REGS, 
                                         VTSS_ADDR_FAST_REGS_SLOWDATA_LSB, value, 1));
                *value += (val << 16);
            }
            return VTSS_OK;
        }
        VTSS_NSLEEP(100);
    }    
    return (read ? VTSS_IO_READ_ERROR : VTSS_IO_WRITE_ERROR);
}
#endif /* VTSS_ARCH_B2 */
