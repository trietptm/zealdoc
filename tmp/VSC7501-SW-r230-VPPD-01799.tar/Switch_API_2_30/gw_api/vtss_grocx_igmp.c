/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 

*/

#define VTSS_TRACE_FILE "igmp" /* IGMP Snooping */

#include <string.h>
#include <stdlib.h>

#include "vtss_grocx_igmp_api.h"

//#if VTSS_OPT_IGMP


/* ************************************************************************ **
 *
 *
 * Local data
 *
 *
 *
 * ************************************************************************ */
static uchar igmp_enabled = FALSE;
static uchar igmps_unreg_flood_enabled = FALSE;
static vtss_igmp_vid_entry_t        igmp_vlan_entries[IGMP_NUM_SUPPORTED_VIDS];
static vtss_igmp_hash_entry_t       hash_tbl_entries[IGMP_NUM_SUPPORTED_VIDS*IGMP_NO_OF_SUPPORTED_GROUPS];
static vtss_igmp_idx_t              hash_tbl[IGMP_NO_OF_ROWS_IN_HASH_TABLE];
static vtss_igmp_post_leave_entry_t igmp_post_leave_tbl[IGMP_POST_LEAVE_QUEUE_LEN];

/* quick access pointer to most recently used VLAN entry, used when
 * processing incoming reports */
static vtss_igmp_vid_entry_t        * current_entry = NULL;
static mac_addr_t igmp_general_query_mac = {0x01, 0x00, 0x5E, 0x00, 0x00, 0x01};
static mac_addr_t ipmc_mac = {0x01, 0x00, 0x5E, 0x00, 0x00, 0x00};

/* declare a memory pool with the following parameters:
 *     entry size = sizeof(vtss_igmp_group_entry_t)
 *   # buffers = IGMP_NO_OF_SUPPORTED_GROUPS */
IGMP_MEMB(igmp_groups, sizeof(vtss_igmp_group_entry_t), (IGMP_NUM_SUPPORTED_VIDS*IGMP_NO_OF_SUPPORTED_GROUPS));

/* general router port mask, common to all VLANs */
static port_bit_mask_t wan_vlan_port_mask = 0, router_port_mask = 0, static_router_port_mask = 0, static_fast_leave_port_mask = 0;
static port_bit_mask_t next_router_port_mask = 0;
static ushort router_port_timer = ROUTER_PORT_TIMEOUT;
static ushort igmp_leave_timer =2 ;
static uchar igmp_leave_event=0;
static uchar igmp_leave_port=0;
static uchar igmp_post_leave_event=0;
static ulong igmp_leave_group_address = 0;
static uchar igmp_still_member_no_leave_event=0;
/* counter for checksum_errors */
static ushort cksum_error_count = 0;
static uchar num_free_groups = IGMP_NO_OF_SUPPORTED_GROUPS;
/* Forward mask for forwarding of reports/queries */
port_bit_mask_t igmp_fwd_mask;

static int grocx_config_mode;

static void construct_ipmc_mac (uchar  * mcast_add);
static void hash_tbl_add (vtss_igmp_group_entry_t * grp, ushort vid);
static void hash_tbl_del (vtss_igmp_group_entry_t * grp);
static void igmp_write_mac_entry(mac_addr_t mac, ushort vid, port_bit_mask_t mask);
static void general_leave_process (vtss_igmp_vid_entry_t * entry, uchar src_port, ulong group_address);

#define IGMP_WRITE_PORT_BIT_MASK(bit_no,bit_val,dst_ptr)  write_bit_32((bit_no), (bit_val), (dst_ptr))
static void write_bit_32 (uchar bit_no, uchar value, ulong *dst_ptr)
{
    ulong tmp = 1;
    
    if (value == 0) {
        *dst_ptr &= (~(tmp << (bit_no-1)));
    } else {
        *dst_ptr |= (tmp << (bit_no-1));
    }      
    
    return;  
}

/*------------------------------------------------------------------------------*/
/**
 * Initialize a memory block that was declared with MEMB().
 *
 * \param m A memory block previosly declared with MEMB().
 */
/*------------------------------------------------------------------------------*/
static void igmp_memb_init(struct igmp_memb_blocks * m)
{
  memset(m->mem, 0, (m->size + 4) * m->num); // for 4byte alignment
}
/*------------------------------------------------------------------------------*/
/**
 * Allocate a memory block from a block of memory declared with MEMB().
 *
 * \param m A memory block previously declared with MEMB().
 */
/*------------------------------------------------------------------------------*/
static uchar * igmp_memb_alloc(struct igmp_memb_blocks * m)
{
  ushort i;
  uchar * ptr;

  ptr = m->mem;
  for(i = 0; i < m->num; ++i) {
    if(*ptr == 0) {
      /* If this block was unused, we increase the reference count to
	 indicate that it now is used and return a pointer to the
	 first byte following the reference counter. */
      ++*ptr;
      
      return ptr + 4; // for 4byte alignment, Jack 20060727
    }
    ptr += m->size + 4; // for 4byte alignment, Jack 20060727
  }

  /* No free block was found, so we return NULL to indicate failure to
     allocate block. */
  return NULL;
}
/*------------------------------------------------------------------------------*/
/**
 * Deallocate a memory block from a memory block previously declared
 * with MEMB().
 *
 * \param ptr A pointer to the memory block that is to be deallocated.
 *            Assumed to be a legal pointer! Only check is that reference count 
 *            is 1
 *
 * \return The new reference count for the memory block (should be 0
 * if successfully deallocated) or 0xFF if the pointer "ptr" did not
 * point to a legal allocated memory block.
 */
/*------------------------------------------------------------------------------*/
static uchar igmp_memb_free(uchar * ptr)
{
  uchar * ptr2;
  
  /* decrease reference count */
  ptr2 = ptr - 4; // for 4byte alignment, Jack 20060727
  if(*ptr2 != 1) {
      return 0xFF;
  }
  return --*ptr2;
}


void set_querying_enable(vtss_igmp_vid_entry_t  * igmp_entry, uchar mode)
{
    if(igmp_entry->querier.querier_enabled != mode) {
        igmp_entry->querier.querier_enabled = mode;
        igmp_entry->querier.state = QUERIER_IDLE;
        igmp_entry->querier.timeout = IGMP_QUERIER_NO_QUERY_HEARD_INTERVAL;
    }
}



/* for group maintaining */
static vtss_igmp_group_entry_t  * igmp_group_alloc (void)
{

    uchar  * ret;
    ret = igmp_memb_alloc(&igmp_groups);
    if(ret == NULL) {
        VTSS_D(("The MAX number of supporting group is %d whole switch, it is full now!!!",(IGMP_NUM_SUPPORTED_VIDS*IGMP_NO_OF_SUPPORTED_GROUPS)));
    }
    --num_free_groups;
    return (vtss_igmp_group_entry_t *)ret;
}

static uchar igmp_group_free (vtss_igmp_group_entry_t  * grp)
{   
    uchar ret;
    ret = igmp_memb_free((uchar  *) grp);
    if(ret == 0xFF) {
        VTSS_D(("Error freeing group!"));
    }

    ++num_free_groups;
    return ret;
}

static vtss_igmp_group_entry_t  * find_group (vtss_igmp_vid_entry_t  * vlan_entry, ulong group_addr)
{
    vtss_igmp_group_entry_t  * grp;

    grp = vlan_entry->ipmc_groups;
    while(grp != NULL) {
        if(grp->group_addr == group_addr) {
            /* found it */
            return grp;
        } else {
            grp = grp->next_group;
        }
    }
    
    return NULL;
}


typedef struct {
    ushort          vid;
    mac_addr_t      mac_addr;
    port_bit_mask_t port_mask;
} mac_tab_t;

static mac_tab_t mac_tab_entry;
static uchar igmp_mac_hash (mac_addr_t mac_address, ushort vid)
{
    ushort hash;
    
    /* fill MAC-tab entry with current values */
    memcpy(&mac_tab_entry.mac_addr, mac_address,6*sizeof(uchar));
    mac_tab_entry.vid = vid;

    hash = ((mac_tab_entry.vid & 0x3f) << 4) ^ mac_tab_entry.mac_addr[0] ^ 
        (((ushort) mac_tab_entry.mac_addr[1] << 2) | (mac_tab_entry.mac_addr[2] >> 6)) ^
        (((ushort) mac_tab_entry.mac_addr[2] << 4) | (mac_tab_entry.mac_addr[3] >> 4)) ^
        (((ushort) mac_tab_entry.mac_addr[3] << 6) | (mac_tab_entry.mac_addr[4] >> 2)) ^
        (((ushort) mac_tab_entry.mac_addr[4] << 8) | mac_tab_entry.mac_addr[5]);

    return (uchar)(hash & (IGMP_NO_OF_ROWS_IN_HASH_TABLE-1));
}


static void init_group(vtss_igmp_group_entry_t  * grp, ulong group_addr, ushort vid)
{
    grp->group_addr = group_addr;
    grp->port_mask = 0;
    grp->general_query_reply_mask = 0;
    grp->next_group = NULL; 
    grp->v3_mode_srclist = NULL;           
    
    /* calculate hash row for this group */
    construct_ipmc_mac((uchar  *) &group_addr);
    grp->hash_tbl_row = igmp_mac_hash(ipmc_mac, vid);
    grp->hash_tbl_idx = HASH_TABLE_VOID_ENTRY;
}

static port_bit_mask_t search_other_groups(ushort vid, vtss_igmp_group_entry_t  * grp)
{
    port_bit_mask_t port_mask = 0;
    ulong masked_group_addr = grp->group_addr & 0x7fffff;
    vtss_igmp_idx_t idx;
    vtss_igmp_idx_t grpidx = grp->hash_tbl_idx;

    /* run through all entries that hashed to same value
       hashing to same value means that the IPMC group <-> MAC may be the same */
    for(idx = hash_tbl[grp->hash_tbl_row];
        idx != HASH_TABLE_VOID_ENTRY;
        idx = hash_tbl_entries[idx].next_idx) {
       
        /* if in right vid, same group address mapping and not same index */
        if((hash_tbl_entries[idx].vid == vid) && 
           ((hash_tbl_entries[idx].grp->group_addr & 0x7fffff) == masked_group_addr) &&
           (hash_tbl_entries[idx].grp->hash_tbl_idx != grpidx)) {
            /* then include this entry's port mask */
            port_mask |= hash_tbl_entries[idx].grp->port_mask;
        }
    }
    
    return port_mask;
}


static vtss_igmp_group_entry_t  * add_group (vtss_igmp_vid_entry_t  * vlan_entry, ulong group_addr)
{
    vtss_igmp_group_entry_t  * grp;
    int                 found_flag = 1;
    int                 first_flag = 0;
    vtss_igmp_group_entry_t  * group_temp = NULL;
    vtss_igmp_group_entry_t  * prev_grp = NULL;
    VTSS_D(("add_group"));
    /* is it the first group ? */
    if(vlan_entry->ipmc_groups == NULL) {
        /* allocate to this group */
        if( (vlan_entry->ipmc_groups = igmp_group_alloc()) != NULL) {
            vlan_entry->ipmc_group_cnt++;
            init_group(vlan_entry->ipmc_groups, group_addr, vlan_entry->vid);
            hash_tbl_add(vlan_entry->ipmc_groups, vlan_entry->vid);
        }
        return vlan_entry->ipmc_groups;
    } else {
        if(vlan_entry->ipmc_groups->group_addr > group_addr)
            first_flag = 1;
        grp = vlan_entry->ipmc_groups;
        while (grp->group_addr < group_addr) {
            if (grp->next_group != NULL) {
                prev_grp = grp;
                grp = grp->next_group;
            }
            else {
                found_flag = 0;
                break;
            }
        }
        
        if(found_flag == 1 && first_flag != 1) {
            grp = prev_grp;
            group_temp = grp->next_group;
        }
        if(first_flag) {
            group_temp = vlan_entry->ipmc_groups;
            if( (vlan_entry->ipmc_groups = igmp_group_alloc()) != NULL) {
                vlan_entry->ipmc_group_cnt++;
                init_group(vlan_entry->ipmc_groups, group_addr, vlan_entry->vid);
                hash_tbl_add(vlan_entry->ipmc_groups, vlan_entry->vid);
                if(found_flag == 1) {
                    vlan_entry->ipmc_groups->next_group = group_temp;
                }
            }
            return vlan_entry->ipmc_groups;
        }
        else {
            /* now grp->next_group == NULL, allocate it here */
            if((grp->next_group = igmp_group_alloc()) != NULL) {
                vlan_entry->ipmc_group_cnt++;
                init_group(grp->next_group, group_addr, vlan_entry->vid);
                hash_tbl_add(grp->next_group, vlan_entry->vid);
                if(found_flag == 1) {
                    grp->next_group->next_group = group_temp;
                }
            }
            return grp->next_group;
        }    
    }
}

static void construct_ipmc_mac (uchar  * mcast_add)
{
#define IGMPS_LITTLE_ENDIAN 1   

    #if IGMPS_LITTLE_ENDIAN
        ipmc_mac[3] = mcast_add[2] & 0x7F;
        ipmc_mac[4] = mcast_add[1];
        ipmc_mac[5] = mcast_add[0];
    #else
        ipmc_mac[3] = mcast_add[1] & 0x7F;
        ipmc_mac[4] = mcast_add[2];
        ipmc_mac[5] = mcast_add[3];
    #endif
}

static void delete_group(vtss_igmp_vid_entry_t  * vlan_entry, ulong group_addr, uchar force_deletion)
{
    vtss_igmp_group_entry_t             * grp;
    vtss_igmp_group_entry_t             * prev_grp;
    port_bit_mask_t                     other_groups;
    vtss_vid_mac_t                      vid_mac_entry;
//    vtss_mac_table_entry_t      entry;
    vtss_rc                             rc = 0;
//    int i;

    grp = vlan_entry->ipmc_groups;
    prev_grp = NULL;
    while(grp != NULL) {            
        if(grp->group_addr == group_addr) {
            /* search for any other groups before deleting entry */
            other_groups = search_other_groups(vlan_entry->vid, grp);

            if(prev_grp != NULL) {
                /* take this entry out of chain */
                prev_grp->next_group = grp->next_group;
            } else {
                vlan_entry->ipmc_groups = grp->next_group;
            }

            /* delete hash table entry */
            hash_tbl_del(grp);

            /* we need to construct MAC lookup value in both cases */
            construct_ipmc_mac((uchar  *) &group_addr);            

            /* either delete MAC entry (if other groups does not map into same MAC address) 
             * or update mac entry with ports from other groups mapping to same MAC address
             */
            if((other_groups == 0) || force_deletion) {
                /* delete group in MAC */                
                //Simon (in igmpfunc.c)   igmp_delete_mac_entry(ipmc_mac, vlan_entry->vid);
                vid_mac_entry.vid = vlan_entry->vid;
                memcpy(vid_mac_entry.mac.addr, ipmc_mac, 6);
                //mac_mgmt_table_del(VTSS_ISID_LOCAL, &vid_mac_entry);
                rc = vtss_mac_table_forget_vid_mac(&vid_mac_entry);
            } else {
                 /* other groups map into same entry, update entry with these ports */
                igmp_write_mac_entry(ipmc_mac, vlan_entry->vid, other_groups);       
            }
            if (grp->v3_mode_srclist != NULL)
                free(grp->v3_mode_srclist);
            /* free memory */
            igmp_group_free(grp);
            vlan_entry->ipmc_group_cnt--;
            return;
        }
        
        prev_grp = grp;
        grp = grp->next_group;
    }
}


static void update_group(vtss_igmp_vid_entry_t * vlan_entry, ulong group_addr)
{
    vtss_igmp_group_entry_t * grp;
    port_bit_mask_t other_groups;


    grp = vlan_entry->ipmc_groups;
    VTSS_D(("update_group"));
    while(grp != NULL) {
        if(grp->group_addr == group_addr) {
            /* search for any other groups before deleting entry */
            other_groups = search_other_groups(vlan_entry->vid, grp);

            /* we need to construct MAC lookup value in both cases */
            construct_ipmc_mac((uchar *) &group_addr);

            /* other groups map into same entry, update entry with these ports */
            igmp_write_mac_entry(ipmc_mac, vlan_entry->vid, other_groups|grp->port_mask);
            
            return;
        }
        
        grp = grp->next_group;
    }
}



/* Get the IPMC MAC address */
static vtss_rc ipmc_get_mac_entry(vtss_vid_mac_t *vid_mac,  
                                vtss_mac_table_entry_t *entry)
{
    vtss_rc rc;
    rc = vtss_mac_table_lookup(vid_mac, entry);

    return rc;
}


static void igmp_write_mac_entry(mac_addr_t mac, ushort vid, port_bit_mask_t mask)
{
    vtss_vid_mac_t              vid_mac_entry;
    vtss_mac_table_entry_t      entry;
    vtss_rc                     rc = 0;
    int i;

    vid_mac_entry.vid = vid;
    memcpy(vid_mac_entry.mac.addr, mac, 6);
    if (ipmc_get_mac_entry(&vid_mac_entry,&entry) == VTSS_OK) {
        for(i=1; i<=(VTSS_PORT_ARRAY_SIZE-1); i++ ) {
            entry.destination[i] = ((mask>>(i-1))&1);
        }
    }
    else {
        memset(&entry,0,sizeof(vtss_mac_table_entry_t));
        entry.vid_mac.vid = vid;
        memcpy(entry.vid_mac.mac.addr, mac, 6);
        entry.copy_to_cpu = 0;
        entry.locked = 1;
        entry.aged = 0;
        for(i=1; i<=(VTSS_PORT_ARRAY_SIZE-1); i++ ) {
            entry.destination[i] = ((mask>>(i-1))&1);
        }        
    }
         
    rc = vtss_mac_table_learn(&entry);
}


vtss_igmp_vid_entry_t  * vtss_igmps_get_vlan_entry (ushort vid)
{
    uchar i;
    for(i = 0; i < IGMP_NUM_SUPPORTED_VIDS; i++) {
        if(igmp_vlan_entries[i].vid == vid) {
            return &igmp_vlan_entries[i];
        }
    }
    
    return NULL;
}

void vtss_igmps_delete_vlan_entry (ushort vid)
{
    vtss_igmp_vid_entry_t           * entry;
    vtss_igmp_group_entry_t         * grp;
    ulong group_addr;
   
    entry = vtss_igmps_get_vlan_entry (vid);
    if(entry != NULL) {                
        /* we must run through ipmc groups for this VLAN and invalidate them... */
        grp = entry->ipmc_groups;
        while(grp != NULL) {                        
            /* latch address before moving on */
            group_addr = grp->group_addr;
                
            /* make sure to walk next entry before deleting this one */
            grp = grp->next_group;
            
            /* force deletion of group regardless of other groups */
            delete_group(entry, group_addr, TRUE);
        }

        /* and finally clear the entry */
        entry->vid =  0;
        entry->general_query_response_timeout  = 0;
        entry->querier.state   = QUERIER_IDLE;
        entry->querier.timeout = 0;
        entry->querier.querier_enabled = FALSE;
        entry->querier.general_queries_sent = 0;
        entry->querier.group_queries_sent = 0;
        memset(&entry->stats, 0 , sizeof(entry->stats));
    }
}

vtss_igmp_vid_entry_t  * vtss_igmps_add_vlan_entry (ushort vid, uchar querier_enabled, ulong vlan_ports)
{
    vtss_igmp_vid_entry_t  * entry;

    /* look if already present, and re-use it if available */
    entry = vtss_igmps_get_vlan_entry(vid);
    if(entry == NULL) {        
        /* look for unused entry */
        entry = vtss_igmps_get_vlan_entry (0);
        if(entry == NULL) {
            /* no free entries */
            return NULL;
        }
        
        /* only reset statistics if not re-using current entry */
        memset(&entry->stats, 0 , sizeof(entry->stats));
        /* "start" IGMP snooping in this VLAN */
        entry->vid = vid;
        entry->general_query_response_timeout = 0;  
    }
    entry->vlan_ports = vlan_ports;
    /* always update this parameter */
    set_querying_enable(entry, querier_enabled);

    return entry;
}




void vtss_igmps_update_iflodmsk (void)
{
    port_bit_mask_t port_mask = 0;
    BOOL            member[VTSS_PORT_ARRAY_SIZE];
    ushort          i;
    vtss_rc         rc;
            
    if((!igmp_enabled) || igmps_unreg_flood_enabled) {
        memset(member, 1, sizeof(member)); 
    } else {
        port_mask = static_router_port_mask | router_port_mask | wan_vlan_port_mask;
        for(i = 1; i < VTSS_PORT_ARRAY_SIZE; i++)
            member[i]=(port_mask>>(i-1))&1;      
    }

    rc = vtss_ipv4_mc_flood_mask_set(member); 

}


vtss_rc vtss_igmp_frame_is_igmp(
    const vtss_system_frame_header_t * const    sys_header,
	const uchar * const                         frame )
{
    igmp_packet_t   *igmp;
    int             i , rc;
    port_bit_mask_t temp_fast_leave_ports=0;
    ulong           src_ip_addr, group_addr;
    uchar           ip_hdr_len;
    ip_hdr_len = ((*(frame + 14))& (0xf))*4;
    igmp = (igmp_packet_t  *) (frame + 14 + ip_hdr_len);
    
    if(igmp->type == IGMP_MEMBERSHIP_QUERY)
        return VTSS_OK;
    else if(igmp->type == IGMP_V2_MEMBERSHIP_REPORT)
        return VTSS_OK;
    else if(igmp->type == IGMP_LEAVE_GROUP)
        return VTSS_OK;
    else if(igmp->type == IGMP_V1_MEMBERSHIP_REPORT)
        return VTSS_OK;
    else if(igmp->type == IGMP_V3_MEMBERSHIP_REPORT)
        return VTSS_OK;
    else
        return VTSS_PACKET_PROTOCOL_ERROR;
}


/* checksum calculating */
static ushort igmp_chksum(ushort *sdata, ulong len)
{
  ushort acc;

  for(acc = 0; len > 1; len -= 2) {
    acc += *sdata;
    if(acc < *sdata) {
      /* Overflow, so we add the carry to acc (i.e., increase by
         one). */
      ++acc;
    }
    ++sdata;
  }

  /* add up any odd byte */
  if(len == 1) {
    acc += htons(((ushort)(*(uchar *)sdata)) << 8);
    if(acc < htons(((ushort)(*(uchar *)sdata)) << 8)) {
      ++acc;
    }
  }

  return acc;
}

static uchar igmp_cksum_ok (igmp_packet_t  * igmp, ulong len)
{
    ushort cksum_packet;
    cksum_packet = igmp->checksum;
    igmp->checksum = 0;    
    igmp->checksum = ~(igmp_chksum((ushort *)igmp, len));    

    if(igmp->checksum != cksum_packet) {
        igmp->checksum = cksum_packet;       
        return FALSE;
    }
    return TRUE;
}

port_bit_mask_t igmp_calculate_dst_ports(ushort vid, uchar port_no)
{
    vtss_igmp_vid_entry_t  * entry;
    port_bit_mask_t ret=0, temp_mask;
    
    temp_mask = 0xFFFFFFFF;
    temp_mask -= (1<<(port_no-1));
    entry = vtss_igmps_get_vlan_entry (vid);
    if (entry != NULL) {
        ret = entry->vlan_ports & temp_mask;
    }
    
    return ret;   
}


static void update_statistics (igmp_packet_t  * igmp)
{
    switch(igmp->type) {
    case IGMP_MEMBERSHIP_QUERY:        
        current_entry->stats.igmp_queries++;
        break;

    case IGMP_V2_MEMBERSHIP_REPORT:
        current_entry->stats.v2_membership_reports++;
        break;

    case IGMP_LEAVE_GROUP:
        current_entry->stats.v2_leave_group_reports++;
        break;

    case IGMP_V1_MEMBERSHIP_REPORT:
        current_entry->stats.v1_membership_reports++;
        break;

    case IGMP_V3_MEMBERSHIP_REPORT:
        current_entry->stats.v3_membership_reports++;
        break;
    }
}


static port_bit_mask_t get_router_port_mask (uchar port_no)
{
    port_bit_mask_t ret=0, temp_mask;
    
    temp_mask = 0xFFFFFFFF;
    temp_mask -= (1<<(port_no-1));
    ret |= static_router_port_mask;
    ret |= router_port_mask;
    ret &= temp_mask;

    return ret;

}


static void hash_tbl_add (vtss_igmp_group_entry_t * grp, ushort vid)
{
    vtss_igmp_idx_t free_idx;
    vtss_igmp_idx_t idx;

    /* find first free entry */
    free_idx = 0;
    while(hash_tbl_entries[free_idx].grp != NULL) {
        free_idx++;
        if(free_idx >= (IGMP_NUM_SUPPORTED_VIDS*IGMP_NO_OF_SUPPORTED_GROUPS))
            VTSS_D(("IGMPS HASH TAB OVERFLOW!!!"));
    }

    /* insert it */
    hash_tbl_entries[free_idx].grp = grp;
    hash_tbl_entries[free_idx].vid = vid;
    hash_tbl_entries[free_idx].next_idx = HASH_TABLE_VOID_ENTRY;
    grp->hash_tbl_idx = free_idx;

    /* find previous last entry, and make it point to this entry */
    
    /* first, check if it is at head of table */
    if(hash_tbl[grp->hash_tbl_row] == HASH_TABLE_VOID_ENTRY) {
        /* chain it here */
        hash_tbl[grp->hash_tbl_row] = free_idx;
    } else {
        /* run through starting from head until finding a void entry */
        for(idx = hash_tbl[grp->hash_tbl_row]; 
            hash_tbl_entries[idx].next_idx != HASH_TABLE_VOID_ENTRY; 
            idx = hash_tbl_entries[idx].next_idx) {
            /* nothing */
        }
        /* when we get here, idx points to an entry with void next index */

        /* chain it here */
        hash_tbl_entries[idx].next_idx = free_idx;
    }
}

static void hash_tbl_del (vtss_igmp_group_entry_t * grp)
{
    vtss_igmp_idx_t idx;
    vtss_igmp_idx_t pointer_idx;
    vtss_igmp_idx_t backup_idx;

    /* make idx points to entry with grp */
    idx = grp->hash_tbl_idx;
    backup_idx = hash_tbl_entries[idx].next_idx;

    hash_tbl_entries[idx].grp = NULL;
    hash_tbl_entries[idx].vid = IGMP_VID_VOID;
    hash_tbl_entries[idx].next_idx = HASH_TABLE_VOID_ENTRY;

    /* find the entry pointing to his entry */
    
    /* is this from the head ? */
    if(hash_tbl[grp->hash_tbl_row] == idx) {
        /* make head point to successor */
        hash_tbl[grp->hash_tbl_row] = backup_idx;
    } else {
        /* run through starting from head until finding the entry */
        for(pointer_idx = hash_tbl[grp->hash_tbl_row];
            hash_tbl_entries[pointer_idx].next_idx != idx;
            pointer_idx = hash_tbl_entries[pointer_idx].next_idx) {
            /* nothing */
        }

        /* now pointer_idx points to the entry pointing to the one we want to delete */
        hash_tbl_entries[pointer_idx].next_idx = backup_idx;
    }
}


static void ipmc_add_port_to_mac_entry (uchar src_port, mac_addr_t mac, ushort vid)
{

    vtss_vid_mac_t              vid_mac;
    vtss_mac_table_entry_t      entry;
    vtss_rc                     rc = 0;

    vid_mac.vid = vid;
    memcpy(vid_mac.mac.addr, mac, 6);

    if (ipmc_get_mac_entry(&vid_mac,&entry) != VTSS_OK) {
        memset(&entry,0,sizeof(vtss_mac_table_entry_t));
        entry.vid_mac.vid = vid;
        memcpy(entry.vid_mac.mac.addr, mac, 6);
        entry.copy_to_cpu = 0;
        entry.locked = 1;
        entry.aged = 0;
    }
    entry.destination[src_port] = 1;
   
    rc = vtss_mac_table_learn(&entry);
}


static void transmit_specific_query(vtss_igmp_vid_entry_t * entry, ulong query_group_addr,uchar src_port)
{
#if 0
    #define UIP_BUFSIZE     1514
    #define UIP_LLH_LEN     14
    #define UIP_ETHTYPE_IP  0x0800
    #define UIP_PROTO_IGMP  2
    static uchar            t = 0;
    uchar                   uip_buf[UIP_BUFSIZE+2];
    /* point to UIP buffer */
    igmp_ip_eth_hdr         *eth_hdr;
    igmp_igmpip_hdr         *ip_igmp_hdr;    
    ushort                  src_addr[2];
    port_bit_mask_t         dst_ports = 0;
    size_t                  uip_len;
    uchar                   mac_addr[6];
    int                     i;


    eth_hdr = (igmp_ip_eth_hdr *)uip_buf;
    ip_igmp_hdr = (igmp_igmpip_hdr *)&uip_buf[UIP_LLH_LEN];

    IGMP_WRITE_PORT_BIT_MASK(src_port, 1, &dst_ports);

    VTSS_D(("transmit_specific_query")); 
    if(dst_ports != 0) {
        query_group_addr=(((query_group_addr & 0xFF)<<24)|((query_group_addr & 0xFF00)<<8)|((query_group_addr & 0xFF0000)>>8)|((query_group_addr & 0xFF000000)>>24));
        /* set IP Hdr */
        memcpy(eth_hdr->dest.addr, igmp_general_query_mac, sizeof(uchar)*6);
        eth_hdr->src.addr[0] = 0x01;  // should be ported later Simon (LAN MAC Address)
        eth_hdr->src.addr[1] = 0x01;  // should be ported later Simon (LAN MAC Address)
        eth_hdr->src.addr[2] = 0x01;  // should be ported later Simon (LAN MAC Address)
        eth_hdr->src.addr[3] = 0x01;  // should be ported later Simon (LAN MAC Address)
        eth_hdr->src.addr[4] = 0x01;  // should be ported later Simon (LAN MAC Address)
        eth_hdr->src.addr[5] = 0x01;  // should be ported later Simon (LAN MAC Address)
        eth_hdr->type = htons(UIP_ETHTYPE_IP);

        ip_igmp_hdr->vhl = 0x46;
        ip_igmp_hdr->tos = 0x00;
        ip_igmp_hdr->len[0] = 0x00;
        ip_igmp_hdr->len[1] = 0x20;
        ip_igmp_hdr->ipid[0] = 0x00;
        ip_igmp_hdr->ipid[1] = ++t;
        ip_igmp_hdr->ipoffset[0] = 0x00;
        ip_igmp_hdr->ipoffset[1] = 0x00;
        ip_igmp_hdr->ttl = 0x01;
        ip_igmp_hdr->proto = UIP_PROTO_IGMP;
        ip_igmp_hdr->ipchksum = 0x0000;
        ip_igmp_hdr->router_option[0] = 0x94;
        ip_igmp_hdr->router_option[1] = 0x04;
        ip_igmp_hdr->router_option[2] = 0x00;
        ip_igmp_hdr->router_option[3] = 0x00;
        /* src address */
        ip_igmp_hdr->srcipaddr[0] = 0x0101; // should be ported later Simon (LAN IP Address)
        ip_igmp_hdr->srcipaddr[1] = 0x0101; // should be ported later Simon (LAN IP Address)

        /* dst address */
        if(query_group_addr == 0) {      
            /* general query, dest ip = 224.0.0.1 */
            ip_igmp_hdr->destipaddr[0] = htons(0xe000); //jack 20060726
            ip_igmp_hdr->destipaddr[1] = htons(0x0001); //jack 20060726 
            entry->querier.general_queries_sent++;
        } else {
            /* dest ip = group address */
            memcpy(ip_igmp_hdr->destipaddr, &query_group_addr, 4);

            entry->querier.group_queries_sent++;
        }
        
        /* update hdr checksum */
        ip_igmp_hdr->ipchksum = ~(igmp_chksum((ushort *)&uip_buf[UIP_LLH_LEN], 24));
        
        ip_igmp_hdr->igmp_type = IGMP_MEMBERSHIP_QUERY;
        if(query_group_addr == 0) {
            ip_igmp_hdr->max_response_time = IGMP_QUERIER_TX_QUERY_RESPONSE_INTERVAL;
        } else {
            ip_igmp_hdr->max_response_time = 0xa;
        }
        memcpy(ip_igmp_hdr->group, &query_group_addr, 4);
        
        ip_igmp_hdr->igmpchksum = 0;
        ip_igmp_hdr->igmpchksum = ~(igmp_chksum((ushort *)&uip_buf[24+UIP_LLH_LEN], 8));
        
        /* length = eth_len [14] + ip_hdr [20] + igmp_hdr [8] = total [42] */
        uip_len = 46;
        
        /* not entirely a snooped frame, but in this context this is what we want */
        VTSS_D(("\n\rIGMPS transmit spec quier packet"));
        for(i=1; i<=VTSS_PORT_COUNT; i++ ) {
            if(((dst_ports>>(i-1))&1)== 1) {
                VTSS_D(("(Simon!!!!) TX spec quier pk on port %d", i));
                vtss_cpu_tx_raw_frame(dst_ports, &uip_buf[0], uip_len);
            }
        }
    }
#endif
}



static void handle_membership_report(uchar src_port, ushort vid, ulong group_address)
{
    vtss_igmp_group_entry_t  * grp;

    /* lookup group for address */
    grp = find_group(current_entry, group_address);
    if(grp == NULL) {
        /* try to allocate a new group */
        if(current_entry->ipmc_group_cnt < IGMP_NO_OF_SUPPORTED_GROUPS)
            grp = add_group(current_entry, group_address);
        else {
            VTSS_D(("The MAX number of supporting group is %d per VLAN, it is full now!!!",IGMP_NO_OF_SUPPORTED_GROUPS));
            return;
        }
    }

    if(grp != NULL) {
        /* if in general query timeout */
        if(current_entry->general_query_response_timeout) {
            /* remember this */
            IGMP_WRITE_PORT_BIT_MASK(src_port, 1, &grp->general_query_reply_mask);
        }

        /* construct lookup mac address */
        construct_ipmc_mac((uchar  *) &group_address);
        
        /* remember this in MAC shadow entry */
        IGMP_WRITE_PORT_BIT_MASK(src_port, 1, &grp->port_mask);     
        /* v1/v2 membership report */
        /* immediately add to MAC table entry */
        ipmc_add_port_to_mac_entry(src_port, ipmc_mac, vid);
    }
}


#if 1
static int handle_v3_membership_report (uchar src_port, uchar  * content, ushort vid, int fast_leave)
{
    igmp_packet_t   *igmp = (igmp_packet_t   *)content;
    ushort no_records = htonl(igmp->group_address) & 0xFFFF;
    int             i,j;

    /* the group record follows the igmp header, which is almost the same in v3 as for v1 / v2*/
    igmp_v3_group_record * group_record = (igmp_v3_group_record *)(content + sizeof(igmp_packet_t));
    uchar * temp = (uchar *)group_record;
    ulong group_address,temp_group_address;

    vtss_igmp_group_entry_t  * grp;

    /* assume it is a membership-like report */
    uchar is_membership_report = TRUE;
    uchar is_leave_report = 0;
    int   fast_leave_event = 0;

    while(no_records--) {
        group_address = htonl(group_record->multicast_address);
        /* only regard the packet as membership report in some cases */
        switch(group_record->record_type) {
        case IGMP_V3_MODE_IS_INCLUDE:
        case IGMP_V3_CHANGE_TO_INCLUDE: 
            if(htons(group_record->num_sources) == 0) {
                is_membership_report = FALSE;
                is_leave_report = 1 ;
                break;
            }
            /* lookup group for address */
            grp = find_group(current_entry, group_address);
            if(grp == NULL) {
                /* try to allocate a new group */
                if(current_entry->ipmc_group_cnt < IGMP_NO_OF_SUPPORTED_GROUPS)
                    grp = add_group(current_entry, group_address);
                else {
                    VTSS_D(("The MAX number of supporting group is %d per VLAN, it is full now!!!",IGMP_NO_OF_SUPPORTED_GROUPS));
                    break;
                }
            }
            if (grp->v3_mode_srclist == NULL) {
                grp->v3_mode_srclist =  malloc(sizeof(vtss_igmp_v3_mode_srclist_t));
                for(i=1; i<=VTSS_PORTS ; i++) {
                    grp->v3_mode_srclist->src_cnt[i] = 0;
                    for(j=0; j<V3_SRC_LIST_ARRAY_SIZE; j++) {
                        grp->v3_mode_srclist->src_list[i][j].src_ip = 0;
                        grp->v3_mode_srclist->src_list[i][j].valid = FALSE;
                    }
                }
                grp->v3_mode_srclist->v3_mode = IGMP_V3_INCLUDE_MODE;
            }
            if(grp->v3_mode_srclist->v3_mode == IGMP_V3_INCLUDE_MODE) {
                grp->v3_mode_srclist->src_cnt[src_port] = htons(group_record->num_sources);
                if(htons(group_record->num_sources) != 0) {                  
                    for(i=0 ; (i<htons(group_record->num_sources)) && (i<V3_SRC_LIST_ARRAY_SIZE); i++){
                        grp->v3_mode_srclist->src_list[src_port][i].src_ip = htonl(group_record->src_addr[i]);
                        grp->v3_mode_srclist->src_list[src_port][i].valid = TRUE;
                    }
                }
            }
            break;
        case IGMP_V3_MODE_IS_EXCLUDE:
        case IGMP_V3_CHANGE_TO_EXCLUDE:
            /* lookup group for address */
            grp = find_group(current_entry, group_address);
            if(grp == NULL) {
                /* try to allocate a new group */
                if(current_entry->ipmc_group_cnt < IGMP_NO_OF_SUPPORTED_GROUPS)
                    grp = add_group(current_entry, group_address);
                else {
                    VTSS_D(("The MAX number of supporting group is %d per VLAN, it is full now!!!",IGMP_NO_OF_SUPPORTED_GROUPS));
                    break;
                }
            }
            if((igmp_leave_event == 1 ) && (group_address == igmp_leave_group_address) && (src_port == igmp_leave_port)) {
                igmp_still_member_no_leave_event=1;
            }
            if(grp->v3_mode_srclist == NULL) {
                grp->v3_mode_srclist =  malloc(sizeof(vtss_igmp_v3_mode_srclist_t));
                for(i=1; i<=VTSS_PORTS ; i++) {
                    grp->v3_mode_srclist->src_cnt[i] = 0;
                    for(j=0; j<V3_SRC_LIST_ARRAY_SIZE; j++) {
                        grp->v3_mode_srclist->src_list[i][j].src_ip = 0;
                        grp->v3_mode_srclist->src_list[i][j].valid = FALSE;
                    }
                }
                grp->v3_mode_srclist->v3_mode = IGMP_V3_EXCLUDE_MODE;
            }
            else {
                if(grp->v3_mode_srclist->v3_mode == IGMP_V3_INCLUDE_MODE) {
                    grp->v3_mode_srclist->v3_mode = IGMP_V3_EXCLUDE_MODE;
                }
            }
            break;
        case IGMP_V3_ALLOW_NEW_SOURCES:
            /* lookup group for address */
            grp = find_group(current_entry, group_address);
            if(grp == NULL) {
                /* try to allocate a new group */
                if(current_entry->ipmc_group_cnt < IGMP_NO_OF_SUPPORTED_GROUPS)
                    grp = add_group(current_entry, group_address);
                else {
                    VTSS_D(("The MAX number of supporting group is %d per VLAN, it is full now!!!",IGMP_NO_OF_SUPPORTED_GROUPS));
                    break;
                }
            }
            if(grp->v3_mode_srclist == NULL) {
                grp->v3_mode_srclist =  malloc(sizeof(vtss_igmp_v3_mode_srclist_t));
                for(i=1; i<=VTSS_PORTS ; i++) {
                    grp->v3_mode_srclist->src_cnt[i] = 0;
                    for(j=0; j<V3_SRC_LIST_ARRAY_SIZE; j++) {
                        grp->v3_mode_srclist->src_list[i][j].src_ip = 0;
                        grp->v3_mode_srclist->src_list[i][j].valid = FALSE;
                    }
                }
                grp->v3_mode_srclist->v3_mode = IGMP_V3_INCLUDE_MODE;
            }
            if(grp->v3_mode_srclist->v3_mode == IGMP_V3_INCLUDE_MODE) {
                grp->v3_mode_srclist->src_cnt[src_port] = htons(group_record->num_sources);
                if(htons(group_record->num_sources) != 0) {                  
                    for(i=0 ; (i<htons(group_record->num_sources)) && (i<V3_SRC_LIST_ARRAY_SIZE); i++){
                        if(grp->v3_mode_srclist->src_list[src_port][i].valid == FALSE) {
                            grp->v3_mode_srclist->src_list[src_port][i].src_ip = htonl(group_record->src_addr[i]);
                            grp->v3_mode_srclist->src_list[src_port][i].valid = TRUE;
                        }
                    }
                }
            }
            break;
        case IGMP_V3_BLOCK_OLD_SOURCES:
            grp = find_group(current_entry, group_address);
            if(grp != NULL) {
                if(grp->v3_mode_srclist->v3_mode == IGMP_V3_INCLUDE_MODE) {
                    is_membership_report = FALSE;
                    if(htons(group_record->num_sources) != 0) {
                            for(i=0 ; i<htons(group_record->num_sources); i++){
                            temp_group_address = htonl(group_record->src_addr[i]);
                            for(j=0 ; j<V3_SRC_LIST_ARRAY_SIZE ;j++) {
                                if(grp->v3_mode_srclist->src_list[src_port][j].valid == TRUE) {
                                    if(grp->v3_mode_srclist->src_list[src_port][j].src_ip == temp_group_address)
                                        grp->v3_mode_srclist->src_list[src_port][j].valid = FALSE;
                                        is_leave_report = 1;
                                }
                            }
                            for(j=0 ; j<V3_SRC_LIST_ARRAY_SIZE ;j++) {
                                if(grp->v3_mode_srclist->src_list[src_port][j].valid == TRUE) {
                                        is_leave_report = 0;
                                }
                            }
                        }
                    }
                }
            }
            else {
                is_membership_report = FALSE;
            }
            break;
        }

        if(is_membership_report) {
            handle_membership_report(src_port, vid, group_address);
        }
    
        if (is_leave_report) {
            if(fast_leave) {
                general_leave_process(current_entry,src_port,group_address);
                fast_leave_event = 1;
            }
            else {
                /* we rely on general query timeout to age out groups 
                 * so we need not do anything to this report but 
                 * fwd it to router port */
                for (i = 0; i < IGMP_POST_LEAVE_QUEUE_LEN; i++) {
                    if(igmp_post_leave_tbl[i].valid == 0) {
                        igmp_post_leave_tbl[i].src_port = src_port;
                        igmp_post_leave_tbl[i].vid = vid;
                        igmp_post_leave_tbl[i].timeout = IGMP_GENERAL_LEAVE_INTERVAL;
                        igmp_post_leave_tbl[i].group_address = group_address;
                        igmp_post_leave_tbl[i].valid = 1;
                        break;
                    }
                }
                igmp_post_leave_event = 1;            
            }
        }
            

        /* point to 1st source address */
        temp = (uchar *)(&group_record->multicast_address);
        temp += sizeof(ulong);
        
        /* skip past all source addresses to get to the next group record */
        temp += htons(group_record->num_sources) * sizeof(ulong);
        group_record = (igmp_v3_group_record *)temp;

        /* as it in v3 is not allowed to have any aux data included, we ignore this optional part */
    }
    return fast_leave_event;
}
#endif


static void general_leave_process (vtss_igmp_vid_entry_t * entry, uchar src_port, ulong group_address)
{
    vtss_igmp_group_entry_t * grp;
    ulong group_addr;
    
    /* we must run through all groups in this VLAN */
    grp = entry->ipmc_groups;
    while(grp != NULL) {
        if (group_address != grp->group_addr) {
            grp = grp->next_group;
            continue;
        }
        IGMP_WRITE_PORT_BIT_MASK(src_port, 0, &grp->port_mask);

        /* latch address before moving on */
        group_addr = grp->group_addr;

        /* delete entry if no more ports */
        if(grp->port_mask == 0) {
            /* make sure to walk next entry before deleting this one */
            grp = grp->next_group;

            delete_group(entry, group_addr, FALSE);
        } else {
            /* replace the MAC entry (if different) */
			update_group(entry, group_addr);

            grp = grp->next_group;
        }
    }
}


static void post_leave_process (ushort vid, uchar src_port, ulong group_address)
{
    vtss_igmp_group_entry_t * grp;
    ulong group_addr;
    vtss_igmp_vid_entry_t * entry;
    
    entry = vtss_igmps_get_vlan_entry(1);
    
    /* we must run through all groups in this VLAN */
    grp = entry->ipmc_groups;
    while(grp != NULL) {
        if (group_address != grp->group_addr) {
            grp = grp->next_group;
            continue;
        }
        IGMP_WRITE_PORT_BIT_MASK(src_port, 0, &grp->port_mask);

        /* latch address before moving on */
        group_addr = grp->group_addr;

        /* delete entry if no more ports */
        if(grp->port_mask == 0) {
            /* make sure to walk next entry before deleting this one */
            grp = grp->next_group;

            delete_group(entry, group_addr, FALSE);
        } else {
            /* replace the MAC entry (if different) */
			update_group(entry, group_addr);

            grp = grp->next_group;
        }
    }
}


void vtss_igmp_del_group_member_port(uchar port_no)
{
    vtss_igmp_group_entry_t     * grp;
    ulong                       group_addr;
    vtss_igmp_vid_entry_t       * entry;
    
    /* clear statistics */
    entry = vtss_igmps_get_vlan_entry(1);
    if(entry != NULL) {                
        /* we must run through all groups in this VLAN */
        grp = entry->ipmc_groups;
        while(grp != NULL) {
            
            IGMP_WRITE_PORT_BIT_MASK(port_no, 0, &grp->port_mask);
        
            /* latch address before moving on */
            group_addr = grp->group_addr;
        
            /* delete entry if no more ports */
            if(grp->port_mask == 0) {
                /* make sure to walk next entry before deleting this one */
                grp = grp->next_group;
        
                delete_group(entry, group_addr, FALSE);
            } else {
                /* replace the MAC entry (if different) */
        		update_group(entry, group_addr);
        
                grp = grp->next_group;
            }
        }
    }
}



void vtss_igmp_receive (ulong src_port, ulong vid, uchar  *frame, ulong frame_len)
{

    igmp_packet_t   *igmp;
    uchar           *content;
    int             i , rc;
    port_bit_mask_t temp_fast_leave_ports=0;
    ulong           src_ip_addr, group_addr;
    uchar           ip_hdr_len;
    ip_hdr_len = ((*(frame + 14))& (0xf))*4;
    igmp = (igmp_packet_t  *) (frame + 14 + ip_hdr_len);
    src_ip_addr = (*(frame + 0x1A)<<24)+ (*(frame + 0x1B)<<16)+ (*(frame + 0x1C)<<8)+ (*(frame + 0x1D));
    
    if(igmp_enabled) {
        if(igmp->type!= IGMP_V3_MEMBERSHIP_REPORT) {
            if(!igmp_cksum_ok(igmp, sizeof(igmp_packet_t))) {
                ++cksum_error_count;
                return;
            }
        }
        /* optionally update current pointer if VID is different than last time around */
        if((current_entry == NULL) || (current_entry->vid != vid)) {
            current_entry = vtss_igmps_get_vlan_entry(vid);
            if(current_entry == NULL) {
                /* not enabled in VLAN => flood this message */
                igmp_fwd_mask = igmp_calculate_dst_ports(vid, src_port);
                return;
            }
        }
 
      
        /* update statistics (only for packets comming from front ports) */
        if(src_port != 7)
            update_statistics(igmp);

         
       //igmp->group_address=htons(igmp->group_address);
       /* Translation of Network to Host */
       group_addr = htonl(igmp->group_address);
       //vid=HTONS(vid);//Jack add 20060726

     
       switch(igmp->type) {
        case IGMP_MEMBERSHIP_QUERY:
                VTSS_D(("GOT IGMP_MEMBERSHIP_QUERY"));
                /* check if this is a router port */
                /* if it is a router port, then Source address is not 0.0.0.0 */
                if(src_ip_addr == 0) {
                    
                    /* src_port is a router port */
                    IGMP_WRITE_PORT_BIT_MASK(src_port, 1, &router_port_mask);
                    
                    /* remember this one */
                    IGMP_WRITE_PORT_BIT_MASK(src_port, 1, &next_router_port_mask);
              
                    /* update iflodmsk */
                    vtss_igmps_update_iflodmsk();
                 
                    if(current_entry->querier.state == QUERIER_ACTIVE) {
                        VTSS_D(("IGMP: Disabling query functionality in VLAN "));
                    }
                
                    /* we heard a query from a router, so querying in this VLAN goes idle */                
                    current_entry->querier.state = QUERIER_IDLE;
                
                    /* if not querier => restart no query heard timeout */
                    current_entry->querier.timeout = IGMP_QUERIER_NO_QUERY_HEARD_INTERVAL;
                }
                
                /* If this a general query ? */            
                if(group_addr == 0) {
                    /* restart response timer */
                    current_entry->general_query_response_timeout = IGMP_GENERAL_QUERY_RESPONSE_INTERVAL;
                }
            /* we basically want to flood this to all ports within VLAN, PVLAN ... */
            igmp_fwd_mask = igmp_calculate_dst_ports(vid, src_port);

            break;

        case IGMP_V2_MEMBERSHIP_REPORT:        /* fall-through  */
        case IGMP_V1_MEMBERSHIP_REPORT:
            VTSS_D(("GOT IGMP_V2/1_MEMBERSHIP_REPORT"));
            handle_membership_report(src_port, vid, group_addr);
            if((igmp_leave_event == 1 ) && (group_addr == igmp_leave_group_address) && (src_port == igmp_leave_port)) {
                igmp_still_member_no_leave_event=1;
            }
            
            /* frame must be fwd'ed to router port */
            igmp_fwd_mask = get_router_port_mask(src_port);
            break;

        case IGMP_LEAVE_GROUP:
            VTSS_D(("(Simon !!!) IGMP_LEAVE_GROUP"));
            temp_fast_leave_ports |= (1<<(src_port-1));
            if(((static_fast_leave_port_mask & temp_fast_leave_ports)!=0)) {
                general_leave_process(current_entry,src_port,group_addr);
                igmp_fwd_mask = 0;
            }
            else
            {
                /* we rely on general query timeout to age out groups 
                 * so we need not do anything to this report but 
                 * fwd it to router port */
                for (i = 0; i < IGMP_POST_LEAVE_QUEUE_LEN; i++) {
                    if(igmp_post_leave_tbl[i].valid == 0) {
                        igmp_post_leave_tbl[i].src_port = src_port;
                        igmp_post_leave_tbl[i].vid = vid;
                        igmp_post_leave_tbl[i].timeout = IGMP_GENERAL_LEAVE_INTERVAL;
                        igmp_post_leave_tbl[i].group_address = group_addr;
                        igmp_post_leave_tbl[i].valid = 1;
                        break;
                    }
                }
                igmp_post_leave_event = 1;
                igmp_fwd_mask = get_router_port_mask(src_port); 
            }       
            break;
          
        case IGMP_V3_MEMBERSHIP_REPORT:
            VTSS_D(("GOT IGMP_V3_MEMBERSHIP_REPORT"));
            content = (uchar *)igmp;
            temp_fast_leave_ports |= (1<<(src_port-1));
            {
                rc = handle_v3_membership_report(src_port, content, vid, (static_fast_leave_port_mask & temp_fast_leave_ports));
                if(((static_fast_leave_port_mask & temp_fast_leave_ports)!=0)) {
                    if(rc) {
                        igmp_fwd_mask = 0;
                    }
                    else {
                        igmp_fwd_mask = get_router_port_mask(src_port);
                    }
                }
                else {
                   igmp_fwd_mask = get_router_port_mask(src_port);
                } 
            }
            break;
        default:
            VTSS_D(("GOT IGMP_unknown type"));
            /* unknown type, we shall flood this one */
            igmp_fwd_mask = igmp_calculate_dst_ports(vid, src_port);
            break;
        }
        if(igmp->type == IGMP_MEMBERSHIP_QUERY)
        {
            VTSS_D(("(Simon!!!!) igmp_fwd_mask %d", igmp_fwd_mask));
            for(i=0; i<VTSS_PORT_COUNT; i++ ) {
                if(((igmp_fwd_mask>>i)&1)== 1) {
                    VTSS_D(("(Simon!!!!) TX pk on port %d", i));
                    vtss_cpu_tx_raw_frame(i, frame, frame_len);
                }
            }
        }
        else {
            VTSS_D(("(Simon!!!!) igmp_fwd_mask %d", igmp_fwd_mask));
            for(i=0; i<VTSS_PORT_COUNT; i++ ) {
                if(((igmp_fwd_mask>>i)&1)== 1) {
                    VTSS_D(("(Simon!!!!) TX pk on port %d", i+1));
                    vtss_cpu_tx_raw_frame(i+1, frame, frame_len);
                }
            }
        }    
    }
}


vtss_rc vtss_igmps_timer (void)
{
    uchar i;
    uchar post_leave_status=0;

    if(igmp_enabled) {
   
        /* IGMP Leave messages Post Handler timeout */
        if(igmp_post_leave_event) {
             for(i = 0; i < IGMP_POST_LEAVE_QUEUE_LEN; i++) {
                if(igmp_post_leave_tbl[i].valid == 1) {
                    igmp_post_leave_tbl[i].timeout--;
                    if(igmp_post_leave_tbl[i].timeout == 0) {
                        post_leave_process(1,igmp_post_leave_tbl[i].src_port,igmp_post_leave_tbl[i].group_address);
                        igmp_post_leave_tbl[i].valid = 0;
                    }
                    post_leave_status=1;
                    break;
                }
            }
            if(post_leave_status == 0) {
                igmp_post_leave_event = 0;
            }
         }
    }    
}




vtss_rc vtss_igmps_init (int grocx_config)
{
    ulong i;
    grocx_config_mode = grocx_config;
    /* explicitly clear all IGMPS entries */
    for(i = 0; i < IGMP_NUM_SUPPORTED_VIDS; i++) {
        igmp_vlan_entries[i].vid = 0;
        igmp_vlan_entries[i].ipmc_groups = NULL;
        igmp_vlan_entries[i].ipmc_group_cnt = 0;
    }
    
    for(i = 0; i < sizeof(hash_tbl) / sizeof(hash_tbl[0]); i++) {
        hash_tbl[i] = HASH_TABLE_VOID_ENTRY;
    }
    
    for(i = 0; i < sizeof(hash_tbl_entries) / sizeof(hash_tbl_entries[0]); i++) {
        hash_tbl_entries[i].grp = NULL;
        hash_tbl_entries[i].vid = IGMP_VID_VOID;
        hash_tbl_entries[i].next_idx = HASH_TABLE_VOID_ENTRY;
    }

    for(i = 0; i < IGMP_POST_LEAVE_QUEUE_LEN; i++)
    	igmp_post_leave_tbl[i].valid=0;

   
    /* initialize memory pool */
    igmp_memb_init(&igmp_groups);
    
    /* initialize Router Ports */
//    router_port_mask = 0xFFFF;
    router_port_mask |= 1<<(7-1);

    if(grocx_config_mode ==1) {
        wan_vlan_port_mask |= 1<<(7-1);
        wan_vlan_port_mask |= 1<<(1-1);
    }
    else if(grocx_config_mode ==4) { 
        wan_vlan_port_mask = 0;
    }
    else {
        wan_vlan_port_mask |= 1<<(1-1);
        wan_vlan_port_mask |= 1<<(6-1);
    }

    next_router_port_mask = 0;
    router_port_timer = ROUTER_PORT_TIMEOUT; 


    if(igmp_enabled == TRUE)
    {
        if(grocx_config_mode ==1) 
            vtss_igmps_add_vlan_entry(1,0, 0xfc);
        else if(grocx_config_mode ==4) 
            vtss_igmps_add_vlan_entry(1,0, 0xfc);
        else
            vtss_igmps_add_vlan_entry(1,0, 0xbc);
        
        vtss_cpu_rx_registration_t reg;

        VTSS_D(("Register for IGMP messages"));
        vtss_cpu_rx_registration_get(&reg);
        reg.mcast_igmp_cpu_only = 1;
        vtss_cpu_rx_registration_set(&reg);
    }

    return VTSS_OK;
}


vtss_rc vtss_igmp_set_mode(BOOL *mode)
{
    vtss_cpu_rx_registration_t reg;
    if(igmp_enabled != *mode) {
        igmp_enabled = *mode;
        if(igmp_enabled == TRUE)
        {
            if(grocx_config_mode ==1) 
                vtss_igmps_add_vlan_entry(1,0, 0xfc);
            else if(grocx_config_mode ==4) 
                vtss_igmps_add_vlan_entry(1,0, 0xfc);
            else
                vtss_igmps_add_vlan_entry(1,0, 0xbc);
        
            VTSS_D(("Register for IGMP messages"));
            vtss_cpu_rx_registration_get(&reg);
            reg.mcast_igmp_cpu_only = 1;
            vtss_cpu_rx_registration_set(&reg);
            /* update unknown flood mask */
            vtss_igmps_update_iflodmsk();
        }
        else
        {
            vtss_igmps_delete_vlan_entry(1);
        
            VTSS_D(("Register for IGMP messages"));
            vtss_cpu_rx_registration_get(&reg);
            reg.mcast_igmp_cpu_only = 0;
            vtss_cpu_rx_registration_set(&reg);
            /* update unknown flood mask */
            vtss_igmps_update_iflodmsk();
        }
    }
    return VTSS_OK;
}

vtss_rc vtss_igmp_get_mode(BOOL *mode)
{
    *mode = igmp_enabled;
    return VTSS_OK;
}


vtss_rc vtss_igmp_set_unreg_flood(BOOL *mode)
{
    if(igmps_unreg_flood_enabled != *mode) {
        igmps_unreg_flood_enabled = *mode;
        vtss_igmps_update_iflodmsk();
    }
    return VTSS_OK;
}


vtss_rc vtss_igmp_get_unreg_flood(BOOL *mode)
{
    *mode = igmps_unreg_flood_enabled;
    return VTSS_OK;    
}


vtss_rc vtss_igmp_set_fast_leave_port(vtss_igmp_fast_leave_port_t *fast_leave_port)
{
    port_bit_mask_t temp_fast_leave_ports=0;
    int i;

    for(i=1; i<=(VTSS_PORTS); i++ ) {
        if (fast_leave_port->ports[i] == 1) {
            temp_fast_leave_ports |= (1<<(i-1));
        }
    }
    
    static_fast_leave_port_mask = temp_fast_leave_ports;
    return VTSS_OK;
}


vtss_rc vtss_igmp_get_fast_leave_port(vtss_igmp_fast_leave_port_t *fast_leave_port)
{
    int i;
    
    for(i=1; i<=(VTSS_PORTS); i++ ) {
        fast_leave_port->ports[i] = ((static_fast_leave_port_mask>>(i-1))&1);
    }
    return VTSS_OK;
}


vtss_rc vtss_igmp_get_vlan_info (ushort vid, vtss_igmp_vid_stat_entry_t *vid_entry)
{
    vtss_igmp_vid_entry_t *vid_entry_temp;
    int i;
    vtss_igmp_group_entry_t *grp;
    
    vid_entry_temp = vtss_igmps_get_vlan_entry (vid);
    if(vid_entry_temp != NULL){
        vid_entry->vid = vid_entry_temp->vid;
        vid_entry->general_query_response_timeout = vid_entry_temp->general_query_response_timeout;
        vid_entry->general_leave_timeout = vid_entry_temp->general_leave_timeout;
        memcpy(&vid_entry->querier,&vid_entry_temp->querier, sizeof(vtss_igmp_querier_sm_t));
        memcpy(&vid_entry->stats,&vid_entry_temp->stats, sizeof(vtss_igmp_statistics_t));
        vid_entry->ipmc_group_cnt = vid_entry_temp->ipmc_group_cnt;
        vid_entry->vlan_ports = vid_entry_temp->vlan_ports;
        vid_entry->fast_leave_status = vid_entry_temp->fast_leave_status;
        if(vid_entry_temp->ipmc_group_cnt != 0)
            grp = vid_entry_temp->ipmc_groups;
        for(i=0 ; i<vid_entry_temp->ipmc_group_cnt; i++) {
            memcpy(&vid_entry->ipmc_groups[i],grp, sizeof(vtss_igmp_group_entry_t));
            if(grp->next_group != NULL )
                grp = grp->next_group;
        }
        return VTSS_OK;
    }
    else
        return VTSS_IGMP_NO_ENTRY;
}


vtss_rc vtss_igmp_clear_stat_counter(void)
{
    int                         i;
    vtss_igmp_vid_entry_t       * entry;
    
    /* clear statistics */
//    for(i = 1; i <=4096 ; i++) {
        i = 1;
        entry = vtss_igmps_get_vlan_entry(i);
        if(entry != NULL) {                
            memset(&entry->stats, 0 , sizeof(entry->stats));
            entry->querier.general_queries_sent = 0;
            entry->querier.group_queries_sent = 0;
        }
//    }
    return VTSS_OK;
}


//#endif /* VTSS_OPT_IGMP */

