/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_mld_api.h,v 1.4 2008/02/20 15:04:53 cpj Exp $
 $Revision: 1.4 $

*/

#ifndef _VTSS_MLD_API_H_
#define _VTSS_MLD_API_H_

#include "vtss_switch_api.h"

#if VTSS_OPT_MLD

typedef struct _vtss_mldsnooping_init_setup_t {
    vtss_vid_t  lan_vid;
    BOOL        router_port[VTSS_PORT_ARRAY_SIZE];
} vtss_mldsnooping_init_setup_t;

vtss_rc vtss_mldsnooping_init(
    const vtss_mldsnooping_init_setup_t * const setup );

/* Returns VTSS_PACKET_PROTOCOL_ERROR if not for this handler, otherwise VTSS_OK or error code. */
vtss_rc vtss_mldsnooping_frame_is_mld(
    const vtss_system_frame_header_t * const    sys_header,
	const uchar * const                         frame );

vtss_rc vtss_mldsnooping_frame(
    const vtss_system_frame_header_t * const    sys_header,
	const uchar * const                         frame );

vtss_rc vtss_mldsnooping_aging( void );

#endif /* VTSS_OPT_MLD */

#endif /* _VTSS_MLD_API_H_ */
