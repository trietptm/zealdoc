/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_cli.c,v 1.37 2008/09/08 14:06:31 cpj Exp $
s $Revision: 1.37 $

*/


/* Standard Headers */
#include <ctype.h>
#include <stdlib.h>

#if !defined(VTSS_OPSYS_ECOS)
#include <stdio.h>
#include <termios.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#endif /* VTSS_OPSYS_ECOS */

#if defined(VTSS_OPSYS_ECOS)
#include <cyg/hal/luton28.h>
#include <cyg/io/io.h>
#include <cyg/io/serialio.h>
#include <cyg/io/config_keys.h>
#include <cyg/io/flash.h>
#include <cyg/crc/crc.h>
#else
#endif /* VTSS_OPSYS_ECOS */

#if defined(VTSS_TRACE)
/* Advanced trace system used */
#include <vtss_trace_lvl_api.h>
#include <vtss_trace_api.h>

#define VTSS_TRACE_MODULE_ID   VTSS_MODULE_ID_CLI
#define VTSS_TRACE_GRP_DEFAULT 0
#define TRACE_GRP_CNT          1
#define VTSS_TRACE_LAYER       4
#else
#define VTSS_TRACE_FILE        "cli"
#define VTSS_TRACE_LAYER       3
#endif /* VTSS_TRACE */

# /* API public headers */
#include "vtss_switch_api.h"
#include "vtss_appl_api.h"
#include "vtss_cli.h"
#include "vtss_version.h"

#if VTSS_OPT_CLI

#if defined(VTSS_OPT_RSTP) && VTSS_OPT_RSTP
#include <vtss_rstp.h>
#endif /* VTSS_OPT_RSTP */

#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
static vtss_trace_reg_t trace_reg =
{ 
    .module_id = VTSS_TRACE_MODULE_ID,
    .name      = "cli",
    .descr     = "Command Line Interface"
};

static vtss_trace_grp_t trace_grps[TRACE_GRP_CNT] =
{
    [VTSS_TRACE_GRP_DEFAULT] = { 
        .name      = "default",
        .descr     = "Default",
        .lvl       = VTSS_TRACE_LVL_ERROR,
        .timestamp = 0,
    },
};

#define TRACE_MODULE_ID_ALL         -1
#define TRACE_GRP_IDX_ALL           -1

#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */

#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE 1
#endif

#define MAX_CMD_LEN      (160 + 1)
#define MAX_CMD_HISTORY_LEN 20
#define MAX_WORD_LEN        64

#define CURSOR_UP    0X41
#define CURSOR_DOWN  0X42
#define CURSOR_RIGHT 0x43
#define CURSOR_LEFT  0x44

#define CURSOR_HOME  0x48
#define CURSOR_END   0x4B

#define BS  0x08
#define BEL 0x07
#define LF  0x0a
#define CR  0x0d
#define ESC 0x1b

#define SKIP_SPACES(p) while(*curp && *curp==' ') {curp++;}
#define IS_HEX(p) (*curp=='0' && toupper(*(curp+1)) == 'X')

static char cmd_buf [MAX_CMD_LEN];
static uint cmd_len = 0;
static uint cmd_cursor = 0;

static BOOL suspended = FALSE;

/* CLI state */
struct {
    vtss_port_forward_t port_forward[VTSS_PORT_ARRAY_SIZE];
#if defined(VTSS_ARCH_B2)
    vtss_dscp_entry_t   dscp_table[2][64];
#endif /* VTSS_ARCH_B2 */
} cli_state;


#if !defined(VTSS_OPSYS_ECOS)
static struct termios stored_settings;
static fd_set fdset;
static struct timeval tv;

static void restore_keypress(void)
{
    tcsetattr(0,TCSANOW,&stored_settings);
}

static void set_keypress(void)
{
    struct termios new_settings;

    tcgetattr(0,&stored_settings);

    new_settings = stored_settings;

    /* Disable canonical mode, and set buffer size to 1 byte */
    new_settings.c_lflag &= (~ICANON);
    new_settings.c_lflag &= (~ECHO);
    new_settings.c_cc[VTIME] = 0;
    new_settings.c_cc[VMIN] = 1;

    tcsetattr(0,TCSANOW,&new_settings);
    
    atexit(restore_keypress);
    
    return;
}
#endif /* VTSS_OPSYS_ECOS */

#if defined(VTSS_OPSYS_ECOS)
static cyg_io_handle_t ser_handle;
#endif  /* VTSS_OPSYS_ECOS */

struct {
    uint idx;
    uint len;
    uint scroll;
    struct {
        uint  cmd_len;
        char cmd [MAX_CMD_LEN];
    } buf [MAX_CMD_HISTORY_LEN];

} cmd_history;

static BOOL cli_char_available(unsigned char *c)
{
#if defined(VTSS_OPSYS_ECOS)
    Cyg_ErrNo err;    
    cyg_uint32 len = 1;
    err = cyg_io_read(ser_handle, c, &len);
    if((ENOERR == err) && (len > 0)) {
        return TRUE;
    }
    return FALSE;
#else
    FD_ZERO(&fdset);
    FD_SET(0, &fdset);
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    if(select(1, &fdset, NULL, NULL, &tv) > 0) {
        *c = getchar();        
        return TRUE;
    }
        return FALSE;
    
#endif
}

static void prompt(void)
{
    putchar('>');
    fflush(stdout);
}

static void cursor_left (void)
{
    if (cmd_cursor > 0) {
        cmd_cursor--;

        putchar(ESC);
        putchar(0x5b);
        putchar(CURSOR_LEFT);
        fflush(stdout);
    }
}

static void cursor_right (void)
{
    if (cmd_cursor < cmd_len) {
        cmd_cursor++;

        putchar(ESC);
        putchar(0x5b);
        putchar(CURSOR_RIGHT);
        fflush(stdout);
    }
}

static void cursor_home (void)
{
    while (cmd_cursor > 0) {
        cursor_left();
    }
}

static void delete_to_eol (void)
{
    putchar(ESC);
    putchar(0x5b);
    putchar(CURSOR_END);
    fflush(stdout);
}

static void rewrite_to_eol (void)
{
    while (cmd_cursor < cmd_len) {
        putchar(cmd_buf[cmd_cursor++]);
    }
    fflush(stdout);
}

static void delete_line (void)
{
    cursor_home();
    delete_to_eol();
}

static void append_line (void)
{
    uint cursor_save;

    cursor_save = cmd_cursor;
    rewrite_to_eol();
    while (cmd_cursor > cursor_save) {
        cursor_left();
    }
}

static void delete_char(BOOL backspace)
{
    uint j;

    if (cmd_len == 0 || 
        (backspace && cmd_cursor == 0) || 
        (!backspace && cmd_cursor == cmd_len))
        return;
    
    if (backspace)
        cursor_left();
    delete_to_eol();

    /* concatenate command string */
    cmd_len--;
    for (j = cmd_cursor; j < cmd_len; j++) {
        cmd_buf[j] = cmd_buf[j + 1];
    }

    /* rewrite command part to the right of cursor */
    append_line();
}

static void insert_char (char ch)
{
    uint j;

    delete_to_eol();
    for (j = cmd_len; j > cmd_cursor; j--) {
        cmd_buf[j] = cmd_buf[j - 1];
    }
    cmd_len++;
    cmd_buf[cmd_cursor++] = ch;

    append_line();
}

static void cmd_history_put (void)
{
    memcpy(&cmd_history.buf[cmd_history.idx].cmd, &cmd_buf, cmd_len);
    cmd_history.buf[cmd_history.idx].cmd_len = cmd_len - 1; /* don't include CR */
    if (cmd_history.len < MAX_CMD_HISTORY_LEN) {
        cmd_history.len++;
    }
    if (++cmd_history.idx >= MAX_CMD_HISTORY_LEN) {
        cmd_history.idx = 0;
    }
    cmd_history.scroll = 0;
}

static void cmd_history_get (void)
{
    uint idx;

    if (cmd_history.idx >= cmd_history.scroll) {
        idx = cmd_history.idx - cmd_history.scroll;
    }
    else {
        idx = MAX_CMD_HISTORY_LEN - (cmd_history.scroll - cmd_history.idx);
    }

    cmd_len = cmd_history.buf[idx].cmd_len;
    memcpy(&cmd_buf, &cmd_history.buf[idx].cmd, cmd_len);

}

static void get_old_cmd (void)
{
    delete_line();
    cmd_history_get();
    rewrite_to_eol();
}

static void process_escape_seq (char ch_1, char ch_2)
{
    if (ch_1 == 0x5b) {
        switch (ch_2) {
        case CURSOR_UP:
            if (cmd_history.scroll < cmd_history.len) {
                cmd_history.scroll++;
                get_old_cmd();
            }
            else {
                putchar(BEL);
                fflush(stdout);
            }
            break;

        case CURSOR_DOWN:
            if (cmd_history.scroll > 0) {
                cmd_history.scroll--;

                if (cmd_history.scroll > 0) {
                    get_old_cmd();
                }
                else {
                    delete_line();
                    cmd_len = 0;
                    cmd_cursor = 0;
                }
            }
            else {
                putchar(BEL);
                fflush(stdout);
            }
            break;

        case CURSOR_RIGHT:
            cursor_right();
            break;

        case CURSOR_LEFT:
            cursor_left();
            break;

        case CURSOR_HOME:
            cursor_home();
            break;

        case CURSOR_END:
            while (cmd_cursor < cmd_len) {
                cursor_right();
            }
            break;

        default:
            break;
        }
    }
}

static BOOL empty_cmd_line (void)
{
    uint j;

    for (j = 0; j < cmd_len; j++) {
        if ((cmd_buf[j] != ' ') && (cmd_buf[j] != CR)) {
            return FALSE;
        }
    }
    return TRUE;
}

static BOOL cmd_ready (void)
{
    unsigned char ch;
    uint loop_count;
#if defined(VTSS_OPSYS_ECOS)
    static uint escape_seq_flag = FALSE;
    static uint escape_seq_count = 0;
    static char escape_seq [2];
#endif

    loop_count = 0;
    while (cli_char_available(&ch) && (loop_count++ < 20)) {

#if !defined(VTSS_OPSYS_ECOS)
/*         printf("CHAR_1: %02X\n", ch);  */
        /* convert LF into CR for linux terminal usage */
        if(ch==LF) ch=CR;
#endif
        if (ch != LF) { /* discard LF chars */
            
            if (ch == BS) /* Backspace */
                delete_char(TRUE);
            else if (ch == 0x7f) /* DEL */
                delete_char(TRUE); 
#if defined(VTSS_OPSYS_ECOS)
            else if (ch == ESC) {
                escape_seq_flag = TRUE;
                escape_seq_count = 0;
            }
            else if (escape_seq_flag) {
                escape_seq[escape_seq_count++] = ch;
                if (escape_seq_count >= 2) {
                    process_escape_seq(escape_seq[0], escape_seq[1]);
                    escape_seq_flag = FALSE;
                }
            }
#else
            else if (ch == ESC) {                
                ch = getc(stdin);
                process_escape_seq(ch, getc(stdin));
            }
#endif

            else {
                
                if (cmd_len < MAX_CMD_LEN) {
                    /* echo */
                    putchar(ch);
                    fflush(stdout);
                }
                
                if (ch != CR) {
                    if (cmd_len < MAX_CMD_LEN) {
                        if (cmd_cursor < cmd_len) {
                            insert_char(ch);
                        }
                        else {
                            cmd_buf[cmd_cursor++] = ch;
                            if (cmd_len < cmd_cursor) {
                                cmd_len++;
                            }
                        }
                    }
                }
                else {
                    putchar(LF);
                    fflush(stdout);

                    /* error handling: ensure that CR is present in buffer in case of buffer overflow */
                    if (cmd_len == MAX_CMD_LEN) {
                        cmd_buf[MAX_CMD_LEN - 1] = CR;
                    }
                    else {
                        cmd_buf[cmd_len++] = CR;
                    }
                    if (!empty_cmd_line()) {
                        cmd_history_put();
                    }
                    cmd_buf[cmd_len++] = '\0';                    

                    fflush(stdout);
                    return TRUE;
                }
            }
        }
    }
    return FALSE;
}

static char *cmd_get (void)
{
    cmd_len = 0;
    cmd_cursor = 0;

    return &cmd_buf[0];
}

/* 
** this variable is nice-to-have when debugging; can be used in a GDB script
** to check if the CPU survived the SwC reset...
*/
uint cli_initialized = 0;

void cli_init (void)
{
    vtss_port_no_t port_no;

#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    VTSS_TRACE_REG_INIT(&trace_reg, trace_grps, TRACE_GRP_CNT);
    VTSS_TRACE_REGISTER(&trace_reg);
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */

#if !defined(VTSS_OPSYS_ECOS)
    set_keypress();
#endif

#if defined(VTSS_OPSYS_ECOS)
    Cyg_ErrNo err;
    cyg_uint32 val, len = sizeof(val);

    err = cyg_io_lookup("/dev/ser1", &ser_handle);
    if(ENOERR == err) {
        /* set read nonblocking */
        val = 0;
        err = cyg_io_set_config(ser_handle, 
                                CYG_IO_SET_CONFIG_READ_BLOCKING,
                                &val,
                                &len);
        if(err != ENOERR) {
            printf("CLI: Error setting nonblocking read\n");
        }                                
    }
#endif /* VTSS_OPSYS_ECOS */

    /* Initialize state */
    memset(&cli_state, 0, sizeof(cli_state));
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        cli_state.port_forward[port_no] = VTSS_PORT_FORWARD_ENABLED;
    }
#if defined(VTSS_ARCH_B2)
    {
        uint i, dscp;
        for (i = 0; i < 2; i++)
            for (dscp = 0; dscp < 64; dscp++)
                cli_state.dscp_table[i][dscp].qos.prio = VTSS_PRIO_START;
    }
#endif
    
    cmd_history.len = 0;
    cmd_history.idx = 0;
    cmd_history.scroll = 0;
    printf("\n\nWelcome to the Vitesse Command Line Interface.\n");
    printf("Press <enter> to get the list of commands.\n");
    prompt();
    cli_initialized = 1;
}

/****************************************************************************/
/*  Command parsing                                                         */
/****************************************************************************/

/* CLI command ID */
typedef enum {
    CLI_CMD_ID_NONE,
    CLI_CMD_ID_HELP,
    CLI_CMD_ID_SYSTEM_CONF,
    CLI_CMD_ID_SYSTEM_INIT,
    CLI_CMD_ID_PORT_CONF,
    CLI_CMD_ID_PORT_MODE,
    CLI_CMD_ID_PORT_FLOW_CONTROL,
    CLI_CMD_ID_PORT_STATE,
    CLI_CMD_ID_PORT_MAX_FRAME,
    CLI_CMD_ID_PORT_STATS,
    CLI_CMD_ID_PORT_VERIPHY,
    CLI_CMD_ID_PORT_FILTER,
    CLI_CMD_ID_QOS_PORT_POLICE,
    CLI_CMD_ID_QOS_PORT_SHAPER,
    CLI_CMD_ID_QOS_QUEUE_POLICE,
    CLI_CMD_ID_PORT_FORWARD,
    CLI_CMD_ID_PORT_PSI,
    CLI_CMD_ID_QOS_GLOBAL_DSCP,
    CLI_CMD_ID_QOS_GLOBAL_TCPUDP,
    CLI_CMD_ID_QOS_GLOBAL_TCPUDP_ENABLE,
    CLI_CMD_ID_QOS_GLOBAL_FILTTRIG,
    CLI_CMD_ID_QOS_GLOBAL_FILTACTION,
    CLI_CMD_ID_QOS_GLOBAL_FILTENABLE,
    CLI_CMD_ID_QOS_FILTTRIG,
    CLI_CMD_ID_QOS_FILTACTION,
    CLI_CMD_ID_QOS_PRIORDER,
    CLI_CMD_ID_QOS_CLASS_MISC,
    CLI_CMD_ID_QOS_CLASS_TCPUDP,
    CLI_CMD_ID_QOS_CLASS_IP_PROTO,
    CLI_CMD_ID_QOS_CLASS_ETYPE,
    CLI_CMD_ID_QOS_CLASS_VID,
    CLI_CMD_ID_QOS_CLASS_TAG_PRIO,
    CLI_CMD_ID_QOS_CLASS_MPLS,
    CLI_CMD_ID_QOS_DSCP_TABLE,
    CLI_CMD_ID_QOS_TAG,
    CLI_CMD_ID_QOS_L2_FILTER_ALTORDER,
    CLI_CMD_ID_QOS_L2_FILTER_DMAC,
    CLI_CMD_ID_QOS_L2_FILTER_VID,
    CLI_CMD_ID_QOS_L2_FILTER_ETYPE,
    CLI_CMD_ID_QOS_L2_FILTER_PORT,
    CLI_CMD_ID_QOS_L2_FILTER_CONF,
    CLI_CMD_ID_QOS_RED_THRESHOLD,
    CLI_CMD_ID_QOS_RED_PROBABILITY,
    CLI_CMD_ID_QOS_RED_PROFILE,
    CLI_CMD_ID_QOS_PORT_SCHEDULER,
    CLI_CMD_ID_QOS_LPORT_SCHEDULER,
    CLI_CMD_ID_QOS_QUEUE_SCHEDULER,
    CLI_CMD_ID_DEBUG_REG_READ,
    CLI_CMD_ID_DEBUG_REG_WRITE,
    CLI_CMD_ID_DEBUG_REG_CHECK,
    CLI_CMD_ID_DEBUG_PHY_READ,
    CLI_CMD_ID_DEBUG_PHY_WRITE,
    CLI_CMD_ID_DEBUG_MMD_READ,
    CLI_CMD_ID_DEBUG_MMD_WRITE,
    CLI_CMD_ID_DEBUG_SUSPEND,
    CLI_CMD_ID_DEBUG_CHIP_ID,
    CLI_CMD_ID_DEBUG_RESUME,
    CLI_CMD_ID_DEBUG_TRACE_MODULE_LEVEL,
    CLI_CMD_ID_DEBUG_TRACE_MODULE_TIMESTAMP,
    CLI_CMD_ID_DEBUG_TRACE_MODULE_USEC,
    CLI_CMD_ID_DEBUG_REVERSE,
    CLI_CMD_ID_DEBUG_FPGA_STATUS,
    CLI_CMD_ID_DEBUG_GPIO_OUTPUT,
    CLI_CMD_ID_DEBUG_GPIO_READ,
    CLI_CMD_ID_DEBUG_GPIO_WRITE,
    CLI_CMD_ID_DEBUG_INTERRUPT,
    CLI_CMD_ID_DEBUG_QSS,
    CLI_CMD_ID_DEBUG_BUF,
    CLI_CMD_ID_DEBUG_RED_CNT,
    CLI_CMD_ID_DEBUG_XAUI,
    CLI_CMD_ID_DEBUG_SPI4,
#if defined(VTSS_OPT_RSTP) && VTSS_OPT_RSTP
    CLI_CMD_ID_RSTP_STATUS,
    CLI_CMD_ID_RSTP_STATISTICS,
#endif /* VTSS_OPT_RSTP */
    CLI_CMD_ID_LAST,
} cli_cmd_id_t;

/* CLI command entry */
typedef struct cli_cmd_t {
    const char         *syntax; /* Syntax string */
    const char         *descr;  /* Description string */
    const cli_cmd_id_t id;      /* ID */
} cli_cmd_t;

/* CLI parameter type */
typedef enum {
    /* General */
    CLI_PARM_TYPE_PORT_LIST,
    CLI_PARM_TYPE_CHIP_PORT_LIST,
    CLI_PARM_TYPE_GPIO_LIST,
    CLI_PARM_TYPE_LPORT_LIST,
    CLI_PARM_TYPE_MAX_FRAME,
    CLI_PARM_TYPE_KEYWORD,
    CLI_PARM_TYPE_BLK_LIST,
    CLI_PARM_TYPE_SUB_LIST,
    CLI_PARM_TYPE_ADDR_LIST,
    CLI_PARM_TYPE_VALUE,
    CLI_PARM_TYPE_PHY_ADDR_LIST,
    CLI_PARM_TYPE_PHY_VALUE,
    CLI_PARM_TYPE_MMD_LIST,
    CLI_PARM_TYPE_MMD_ADDR,
    CLI_PARM_TYPE_GPIO_VALUE,
    CLI_PARM_TYPE_PAGE,
    CLI_PARM_TYPE_TRACE_MODULE,
    CLI_PARM_TYPE_TRACE_GROUP,
    CLI_PARM_TYPE_PSI_CLOCK,
    CLI_PARM_TYPE_TABLE_ID,
    CLI_PARM_TYPE_TABLE_INDEX,
    CLI_PARM_TYPE_TRIG_INDEX,
    CLI_PARM_TYPE_TCP_UDP_PORT,
    CLI_PARM_TYPE_QOS_ORDER,
    CLI_PARM_TYPE_QOS_ENDPOINT,
    CLI_PARM_TYPE_DSCP_LIST,
    CLI_PARM_TYPE_OFFSET_VALUE,
    CLI_PARM_TYPE_PATTERN_VALUE,
    CLI_PARM_TYPE_CLASS_VALUE,
    CLI_PARM_TYPE_TAG_PRIO,
    CLI_PARM_TYPE_MPLS_EXP,
    CLI_PARM_TYPE_MASK_VALUE,
    CLI_PARM_TYPE_RED_VALUE,
    CLI_PARM_TYPE_DMAC,
    CLI_PARM_TYPE_DMAC_MASK,
    CLI_PARM_TYPE_ETYPE,
    CLI_PARM_TYPE_VLAN,
    CLI_PARM_TYPE_IP_PROTO,
    CLI_PARM_TYPE_QOS_BIT_RATE,
    CLI_PARM_TYPE_QOS_LEVEL,
    CLI_PARM_TYPE_RED_PROB_1,
    CLI_PARM_TYPE_RED_PROB_2,
    CLI_PARM_TYPE_RED_PROB_3,
    CLI_PARM_TYPE_RED_WEIGHT,
    CLI_PARM_TYPE_RED_MIN,
    CLI_PARM_TYPE_RED_MAX,
    CLI_PARM_TYPE_PCT

} cli_parm_type_t;

#define CLI_PARM_FLAG_NONE   0x00000000 /* No flags */
#define CLI_PARM_FLAG_NO_TXT 0x00000001 /* Suppress identification text */
#define CLI_PARM_FLAG_SET    0x00000002 /* Set operation parameter */
#define CLI_PARM_FLAG_DUAL   0x00000004 /* Dual parameter */

/* CLI parameter entry */
typedef struct {
    const char            *txt;  /* Identification text */
    const char            *help; /* Help text */
    const cli_parm_type_t type;  /* Type */
    const cli_cmd_id_t    id;    /* Optional command ID */
    const ulong           flags; /* Miscellaneous flags */
} cli_parm_t;

static cli_cmd_t cli_cmd_table[] = {
    /* General commands */
    {
        "Help",
        "Show CLI general help text",
        CLI_CMD_ID_HELP
    },
    {
        "?",
        "Show CLI general help text",
        CLI_CMD_ID_HELP
    },
    {
        "System Configuration [<port_list>]",
        "Show system configuration",
        CLI_CMD_ID_SYSTEM_CONF
    },
#if defined(VTSS_ARCH_B2)
    {
        "System Initialization",
        "Show initialization setup",
        CLI_CMD_ID_SYSTEM_INIT,
    },
#endif /* VTSS_ARCH_B2 */
    {
        "Port Configuration [<port_list>]",
        "Show port configuration",
        CLI_CMD_ID_PORT_CONF
    },
    {
        "Port State [<port_list>] [enable|disable]",
        "Set or show the port administrative state",
        CLI_CMD_ID_PORT_STATE
    },
    {
        "Port Mode [<port_list>] [10hdx|10fdx|100hdx|100fdx|1000fdx|auto]",
        "Set or show the port speed and duplex mode",
        CLI_CMD_ID_PORT_MODE
    },
    {
        "Port Flow Control [<port_list>] [enable|disable]",
        "Set or show the port flow control mode",
        CLI_CMD_ID_PORT_FLOW_CONTROL
    },
    {
        "Port MaxFrame [<port_list>] [<max_frame>]",
        "Set or show the port maximum frame size",
        CLI_CMD_ID_PORT_MAX_FRAME
    },
    {
        "Port Statistics [<port_list>] [clear|packets|bytes|errors|discards]",
        "Show port statistics",
        CLI_CMD_ID_PORT_STATS
    },
#if defined(VTSS_ARCH_B2)
    {
        "Port Filter [<port_list>]\n"
        "            [mac_ctrl|mac_zero|dmac_bc|smac_mc|untag|prio_tag|c_tag|s_tag|tags]\n" 
        "            [allow|deny] [any_tag|1_tag|2_tags]",
        "Set or show the filter configuration",
        CLI_CMD_ID_PORT_FILTER
    },
    {
        "Port Forward [<port_list>] [enable|disable|ingress|egress]",
        "Set or show the port forwarding state",
        CLI_CMD_ID_PORT_FORWARD
    },
    {
        "Port PSI <psi_clock>",
        "Setup Port Status Interface",
        CLI_CMD_ID_PORT_PSI
    },
    {
        "QoS Global DSCP [<table_id>] [<dscp_list>] [enable|disable] [<class>] [<red>]",
        "Set or show the global DSCP settings",
        CLI_CMD_ID_QOS_GLOBAL_DSCP
    },
    {
        "QoS Global Filter Trigger [<table_index>] [<trig_index>] [l2|l3|l4]\n" 
        "                          [<offset>] [<pattern>] [<mask>]",
        "Set or show the 8 global filters",
        CLI_CMD_ID_QOS_GLOBAL_FILTTRIG,
    },
    {
        "QoS Global Filter Action [<table_index>] [drop|forward] [<class>] [<red>]",
        "Classify the 8 global filters",
        CLI_CMD_ID_QOS_GLOBAL_FILTACTION,
    },
    {
        "QoS Global Filter Port [<port_list>] [<table_index>] [enable|disable]",
        "Port enable / disable one of the 8 global filters",
        CLI_CMD_ID_QOS_GLOBAL_FILTENABLE,
    },
    {
        "QoS Global ip_port table [<table_index>] [range|specific] [<tcp_udp_port>]\n" 
        "                         [<class>] [<red>]",
        "Set or show the 8 global TCP/UDP ports",
        CLI_CMD_ID_QOS_GLOBAL_TCPUDP
    },
    {
        "QoS Global ip_port port [<port_list>] [<table_index>] [enable|disable]",
        "Port enable / disable one of the 8 global TCP/UDP ports",
        CLI_CMD_ID_QOS_GLOBAL_TCPUDP_ENABLE
    },

    {
        "QoS Filter Action [<port_list>] [drop|forward] [<class>] [<red>]",
        "Classify the local filters",
        CLI_CMD_ID_QOS_FILTACTION,
    },
    {
        "QoS Filter Trigger [<port_list>] [<trig_index>] [l2|l3|l4]\n"
        "                   [<offset>] [<pattern>] [<mask>]",
        "Set or show the local filter",
        CLI_CMD_ID_QOS_FILTTRIG,
    },
    {
        "QoS Priorder [<port_list>] [<order_rank>] [<endpoint_id>]",
        "Set or show the order of the 17 classification endpoints",
        CLI_CMD_ID_QOS_PRIORDER,
    },
    {
        "QoS Class misc [<port_list>] [default|l2_ctrl|l3_ctrl|cfi|ipv4|ipv6|llc]\n" 
        "               [<class>] [<red>]",
        "Set or show the order of the 17 classification endpoints",
        CLI_CMD_ID_QOS_CLASS_MISC,
    },
    {
        "QoS Class ip_port [<port_list>] [<table_id>] [range|specific] [<tcp_udp_port>]\n"
        "                  [<class>] [<red>]",
        "Set or show the TCP/UDP class status",
        CLI_CMD_ID_QOS_CLASS_TCPUDP,
    },
    {
        "QoS Class ip_proto [<port_list>] [<ip_proto>] [<class>] [<red>]",
        "Set or show the IP protocol class status",
        CLI_CMD_ID_QOS_CLASS_IP_PROTO,
    },
    {
        "QoS Class etype [<port_list>] [<etype>] [<class>] [<red>]",
        "Set or show the Ethernet type class status",
        CLI_CMD_ID_QOS_CLASS_ETYPE,
    },
    {
        "QoS Class vid [<port_list>] [<table_id>] [<vid>] [<class>] [<red>]",
        "Set or show the VLAN id class status",
        CLI_CMD_ID_QOS_CLASS_VID,
    },
    {
        "QoS Class tag_prio [<port_list>] [<uprio>] [<class>] [<red>]",
        "Set or show Tag Priority class status",
        CLI_CMD_ID_QOS_CLASS_TAG_PRIO,
    },
    {
        "QoS Class mpls_exp [<port_list>] [<mpls_exp>] [<class>] [<red>]",
        "Set or show MPLS EXP class status",
        CLI_CMD_ID_QOS_CLASS_MPLS,
    },
    {
        "QoS Police Port [<port_list>] [<table_id>] [mc|bc|uc|all] [<bit_rate>] [<level>]",
        "Set or show the port policers, 2 policers per port",
        CLI_CMD_ID_QOS_PORT_POLICE,
    },
    {
        "QoS Police Queue [<port_list>] [<q_index>] [mc|bc|uc|all] [<bit_rate>] [<level>]",
        "Set or show the queue policers, 8 policers per queue",
        CLI_CMD_ID_QOS_QUEUE_POLICE,
    },
    {
        "QoS Shaper [<port_list>] [<bit_rate>] [<level>]",
        "Set or show the port shapers",
        CLI_CMD_ID_QOS_PORT_SHAPER,
    },
    {
        "QoS Tag [<port_list>] [ctag|cfi|vlan_aware|tag_inner] [enable|disable]",
        "Set or show the order of the 17 classification endpoints",
        CLI_CMD_ID_QOS_TAG,
    },
    {
        "QoS L2_filter altorder [<port_list>] [<order_rank>] [<endpoint_id>]",
        "Set or show the alternate order of the 17 classification endpoints",
        CLI_CMD_ID_QOS_L2_FILTER_ALTORDER,
    },
    {
        "QoS L2_filter dmac [<port_list>] [<table_id>] [<dmac>] [<dmac_mask>]",
        "Set or show the L2 filter dmac",
        CLI_CMD_ID_QOS_L2_FILTER_DMAC,
    },
    {
        "QoS L2_filter vid [<port_list>] [<table_id>] [<vid>] [<mask>]",
        "Set or show the L2 filter vid",
        CLI_CMD_ID_QOS_L2_FILTER_VID,
    },
    {
        "QoS L2_filter etype [<port_list>] [<table_id>] [<etype>] [<mask>]",
        "Set or show the L2 filter etype",
        CLI_CMD_ID_QOS_L2_FILTER_ETYPE,
    },
    {
        "QoS L2_filter port [<port_list>] [<table_id>] [enable|disable] [prim|alt]",
        "Set or show the L2 filter port enable status",
        CLI_CMD_ID_QOS_L2_FILTER_PORT,
    },
    {
        "QoS L2_filter conf [<port_list>]",
        "show the L2 filter confs",
        CLI_CMD_ID_QOS_L2_FILTER_CONF,
    },

    {
        "QoS Red Threshold [<port_list>] [<q_index>] [<red_min>] [<red_max>] [<red_weight>]",
        "Set or show the Red min/max/weight config",
        CLI_CMD_ID_QOS_RED_THRESHOLD,
    },
    {
        "QoS Red Probability [<port_list>] [<q_index>] [<prob_1>] [<prob_2>] [<prob_3>]",
        "Set or show the Red probablity profile",
        CLI_CMD_ID_QOS_RED_PROBABILITY,
    },
    {
        "QoS Red Profile [<port_list>] [<q_index>] [enable|disable]",
        "Set or show the red profile status",
        CLI_CMD_ID_QOS_RED_PROFILE,
    },
    {
        "QoS Scheduler queue [<port_list>] [<q_index>] [<pct>]",
        "Set or show the queue scheduler for queues 1-6. 7-8 are strict.",
        CLI_CMD_ID_QOS_QUEUE_SCHEDULER,
    },
    {
        "QoS Scheduler port [<port_list>] [<bit_rate>]",
        "Set or show the port scheduler",
        CLI_CMD_ID_QOS_PORT_SCHEDULER,
    },
    {
        "QoS Scheduler lport [<lport_list>] [rx|tx] [<bit_rate>]",
        "Set or show the logical port scheduler as seen from the SPI4 interface\n"
        "(rx:SPI4  tx:XAUI0/XAUI1)",
        CLI_CMD_ID_QOS_LPORT_SCHEDULER,
    },
    {
        "QoS DSCP table [<port_list>] [<table_id>]",
        "Set or show the DSCP table used",        
        CLI_CMD_ID_QOS_DSCP_TABLE,
    },
  

#endif /* VTSS_ARCH_B2 */
    {
#if defined(VTSS_ARCH_HEATHROW)
        "Debug Register Read <blk_list> <sub_list> <addr_list> [binary|decimal]",
#endif /* VTSS_ARCH_HEATHROW */
#if defined(VTSS_ARCH_B2)
        "Debug Register Read <tgt_list> <addr_list> [binary|decimal]",
#endif /* VTSS_ARCH_B2 */
        "Read chip register",
        CLI_CMD_ID_DEBUG_REG_READ    
    },
    {
#if defined(VTSS_ARCH_HEATHROW)
        "Debug Register Write <blk_list> <sub_list> <addr_list> <value>",
#endif /* VTSS_ARCH_HEATHROW */
#if defined(VTSS_ARCH_B2)
        "Debug Register Write <tgt_list> <addr_list> <value>",
#endif /* VTSS_ARCH_B2 */
        "Write chip register",
        CLI_CMD_ID_DEBUG_REG_WRITE,
    },
#if defined(VTSS_ARCH_B2)
    {
        "Debug Register Check [<chip_port_list>] [clear]",
        "Read, check and optionally clear sticky bits",
        CLI_CMD_ID_DEBUG_REG_CHECK,
    },
#endif /* VTSS_ARCH_B2 */
    {
        "Debug PHY Read <port_list> <addr_list> [<page>] [binary|decimal]",
        "Read PHY register",
        CLI_CMD_ID_DEBUG_PHY_READ,
    },
    {
        "Debug PHY Write <port_list> <addr_list> <value> [<page>]",
        "Write PHY register",
        CLI_CMD_ID_DEBUG_PHY_WRITE,
    },
#if defined(VTSS_ARCH_B2)
    {
        "Debug MMD Read <port_list> <mmd_list> <mmd_address> [binary|decimal]",
        "Read MMD register",
        CLI_CMD_ID_DEBUG_MMD_READ,
    },
    {
        "Debug MMD Write <port_list> <mmd_list> <mmd_address> <value>",
        "Write MMD register",
        CLI_CMD_ID_DEBUG_MMD_WRITE,
    },
#endif /* VTSS_ARCH_B2 */
    {
        "Debug Chip ID",
        "Read chip ID",
        CLI_CMD_ID_DEBUG_CHIP_ID,
    },
    {
        "Debug Suspend",
        "Suspend application",
        CLI_CMD_ID_DEBUG_SUSPEND,
    },
    {
        "Debug Resume",
        "Resume application",
        CLI_CMD_ID_DEBUG_RESUME,
    },
#if defined(BOARD_B2_EVAL)
    {
        "Debug fpga status",
        "Show FPGA status",
        CLI_CMD_ID_DEBUG_FPGA_STATUS,
    },
#endif /* BOARD_B2_EVAL */
#if defined(VTSS_GPIOS)
    {
        "Debug GPIO Output [<gpio_list>] [enable|disable]",
        "Setup GPIO direction",
        CLI_CMD_ID_DEBUG_GPIO_OUTPUT,
    },
    {
        "Debug GPIO Read [<gpio_list>]",
        "Read value from GPIO input pin",
        CLI_CMD_ID_DEBUG_GPIO_READ,
    },
    {
        "Debug GPIO Write [<gpio_list>] <value>",
        "Write value to GPIO output pin",
        CLI_CMD_ID_DEBUG_GPIO_WRITE,
    },
#endif /* VTSS_GPIOS */
#if defined(VTSS_FEATURE_INTERRUPTS)
    {
        "Debug Interrupt [<port_list>] [enable|disable]",
        "Set interrupt mode or show interrupt status",
        CLI_CMD_ID_DEBUG_INTERRUPT,
    },
#endif /* VTSS_FEATURE_INTERRUPTS */
#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    {
        "Debug Trace Level [<module>] [<group>] [none|error|warning|info|debug|noise]",
        "Set or show the trace level for module/group",
        CLI_CMD_ID_DEBUG_TRACE_MODULE_LEVEL,
    },
    {
        "Debug Trace Timestamp [<module>] [<group>] [enable|disable]",
        "Set or show wall clock time stamp in trace for module/group",
        CLI_CMD_ID_DEBUG_TRACE_MODULE_TIMESTAMP,
    },
    {
        "Debug Trace Usec [<module>] [<group>] [enable|disable]",
        "Set or show wall usec time stamp in trace for module/group",
        CLI_CMD_ID_DEBUG_TRACE_MODULE_USEC,
    },
    {
        "Debug Trace Reverse",
        "Reverse previous trace level change",
        CLI_CMD_ID_DEBUG_REVERSE,
    },
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */
#if defined(VTSS_ARCH_B2)
    {
        "Debug QSS",
        "Debug Queue Sub System",
        CLI_CMD_ID_DEBUG_QSS,
    },
    {
        "Debug BufCnt <port_list>",
        "Show QSS buffer usage",
        CLI_CMD_ID_DEBUG_BUF,
    },
    {
        "Debug Red <port_list>",
        "Debug Red drop counters",
        CLI_CMD_ID_DEBUG_RED_CNT,
    },
    {
        "Debug XAUI [clear]",
        "Debug XAUI interfaces",
        CLI_CMD_ID_DEBUG_XAUI,
    },
    {
        "Debug SPI4 [clear]",
        "Debug SPI4 interface",
        CLI_CMD_ID_DEBUG_SPI4,
    },
#endif /* VTSS_ARCH_B2 */
#if defined(VTSS_OPT_RSTP) && VTSS_OPT_RSTP
    {
        "rstp status",
        "Display RSTP status",
        CLI_CMD_ID_RSTP_STATUS,
    },
    {
        "rstp statistics",
        "Display RSTP statistics",
        CLI_CMD_ID_RSTP_STATISTICS,
    },
#endif /* VTSS_OPT_RSTP */
}; /* cli_cmd_table */

static cli_parm_t cli_parm_table[] = {
    {
        "<port_list>",
        "Port list, default: All ports",
        CLI_PARM_TYPE_PORT_LIST,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<chip_port_list>",
        "Chip port list, default: All chip ports",
        CLI_PARM_TYPE_CHIP_PORT_LIST,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
#if defined(VTSS_GPIOS)
    {
        "<gpio_list>",
        "GPIO list, default: All GPIOs",
        CLI_PARM_TYPE_GPIO_LIST,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
#endif /* VTSS_GPIOS */
    {
        "<max_frame>",
        "Port maximum frame size (1518-9600), default: Show maximum frame size",
        CLI_PARM_TYPE_MAX_FRAME,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE | CLI_PARM_FLAG_SET
    },
#if defined(VTSS_ARCH_B2)
    {
        "<lport_list>",
        "Lport list, default: All ports (0-47)",
        CLI_PARM_TYPE_LPORT_LIST,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "enable|disable|ingress|egress",
        "enable     : Enable forwarding\n"
        "disable    : Disable forwarding\n"
        "ingress    : Enable ingress forwarding only\n"
        "egress     : Enable egress forwarding only",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NO_TXT | CLI_PARM_FLAG_SET
    },
#endif /* VTSS_ARCH_B2 */
#if defined(VTSS_GPIOS)
    {
        "enable|disable",
        "enable     : Use output mode\n"
        "disable    : Use input mode\n"
        "(default: Enable output mode)",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_DEBUG_GPIO_OUTPUT,
        CLI_PARM_FLAG_NO_TXT | CLI_PARM_FLAG_SET
    },
#endif /* VTSS_GPIOS */
    {
        "enable|disable",
        "enable     : Enable trusted DSCP\n"
        "disable    : Disable trusted DSCP",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_QOS_GLOBAL_DSCP,
        CLI_PARM_FLAG_NO_TXT | CLI_PARM_FLAG_SET
    },
    {
        "enable|disable",
        "enable     : Enable\n"
        "disable    : Disable\n"
        "(default: Show mode)",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NO_TXT | CLI_PARM_FLAG_SET
    },
    {
        "allow|deny",
        "allow   : Allow\n"
        "deny    : Deny\n"
        "(default: Show mode)",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NO_TXT | CLI_PARM_FLAG_SET
    },
    {
        "10hdx|10fdx|100hdx|100fdx|1000fdx|auto",
        "10hdx      : 10 Mbps, half duplex\n"
        "10fdx      : 10 Mbps, full duplex\n"
        "100hdx     : 100 Mbps, half duplex\n"
        "100fdx     : 100 Mbps, full duplex\n"
        "1000fdx    : 1 Gbps, full duplex\n"
        "auto       : Auto negotiation of speed and duplex\n"
        "(default: Show configured and current mode)",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NO_TXT | CLI_PARM_FLAG_SET
    },
    {
        "clear",
        "Clear sticky bits",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_DEBUG_REG_CHECK,
        CLI_PARM_FLAG_NONE
    },
    {
        "clear",
        "Clear counters",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "clear|packets|bytes|errors|discards",
        "clear      : Clear port statistics\n"
        "packets    : Show packet statistics\n"
        "bytes      : Show byte statistics\n"
        "errors     : Show error statistics\n"
        "discards   : Show discard statistics\n"
        "(default: Show all port statistics)",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NO_TXT
    },
    {
        "binary|decimal",
        "binary     : Show value in binary format\n"
        "decimal    : Show value in decimal format\n"
        "(default: Show value in hexadecimal format)",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NO_TXT
    },
    {
#if defined(VTSS_ARCH_B2)
        "<tgt_list>",
        "Target list (0-63)",
#else
        "<blk_list>",
        "Block list (0-7)",
#endif /* VTSS_ARCH_B2 */
        CLI_PARM_TYPE_BLK_LIST,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<sub_list>",
        "Sub block list (0-15)",
        CLI_PARM_TYPE_SUB_LIST,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<addr_list>",
        "Register address list (0-31)",
        CLI_PARM_TYPE_PHY_ADDR_LIST,
        CLI_CMD_ID_DEBUG_PHY_READ,
        CLI_PARM_FLAG_NONE
    },
#if defined(VTSS_ARCH_B2)
    {
        "<psi_clock>",
        "PSI clock, 38000-9765000 Hz or zero (disabled)",
        CLI_PARM_TYPE_PSI_CLOCK,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<table_id>",
        "Table 1 or 2",
        CLI_PARM_TYPE_TABLE_ID,
        CLI_CMD_ID_QOS_DSCP_TABLE,
        CLI_PARM_FLAG_SET
    },
    {
        "<table_id>",
        "Table 1 or 2",
        CLI_PARM_TYPE_TABLE_ID,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<dscp_list>",
        "DSCP list, 0-63",
        CLI_PARM_TYPE_DSCP_LIST,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<table_index>",
        "Index in table 1-8",
        CLI_PARM_TYPE_TABLE_INDEX,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<q_index>",
        "queue 1-8",
        CLI_PARM_TYPE_TABLE_INDEX,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<pct>",
        "Percentage 0-100%",
        CLI_PARM_TYPE_PCT,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<ip_proto>",
        "IP protocol number 0-255",
        CLI_PARM_TYPE_IP_PROTO,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<trig_index>",
        "Trigger id 0-6",
        CLI_PARM_TYPE_TRIG_INDEX,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<tcp_udp_port>",
        "TCP/UDP port id 0-0xFFFF",
        CLI_PARM_TYPE_TCP_UDP_PORT,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<uprio>",
        "User priority / Tag priority 0-7",
        CLI_PARM_TYPE_TAG_PRIO,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<mpls_exp>",
        "MPLS experimental 0-7",
        CLI_PARM_TYPE_MPLS_EXP,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "mc|bc|uc|all",
        "mc|bc|uc|all: Traffic type to police",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NO_TXT | CLI_PARM_FLAG_SET
    },
    {
        "<order_rank>",
        "Class order rank (0-16)",
        CLI_PARM_TYPE_QOS_ORDER,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<endpoint_id>",
        "Endpoint ID (0-16)\n"
        "0:  Default\n"
        "1:  L2 control frames\n"
        "2:  L3 control frames\n"
        "3:  Tag CFI\n"
        "4:  Trusted DSCP values\n"
        "5:  IPv4/IPv6 TCP/UDP port\n"
        "6:  IPv4 prot or IPv6 next header\n"
        "7:  All DSCP values\n"
        "8:  IPv4 and ARP frames\n"
        "9:  IPv6 frames\n"
        "10: Ethernet Type\n"
        "11: MPLS exp bits\n"
        "12: VLAN ID\n"
        "13: VLAN User Priority\n"
        "14: LLC SNAP\n"
        "15: Global custom filter\n"
        "16: Local custom filter\n",
        CLI_PARM_TYPE_QOS_ENDPOINT,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "default|l2_ctrl|l3_ctrl|cfi|ipv4|ipv6|llc",
        "\ndefault    : Default endpoint\n"
        "l2_ctrl      : L2 Ctrl endpoint\n"
        "l3_ctrl      : L3 Ctrl endpoint\n"
        "cfi          : TAG CFI endpoint\n"
        "ipv4         : IPv4 and ARP endpoint\n"
        "ipv6         : IPv6 endpoint\n"
        "llc          : LLC SNAP endpoint",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "ctag|cfi|vlan_aware|tag_inner",
        "\nctag           : Stop analyses if C-tag is found\n"
        "cfi              : Stop analyses if C-tag CFI is found\n"
        "vlan-aware       : Enable VLAN awareness\n"
        "tag_inner        : Use inner tag if present\n",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },

    {
        "range|specific",
        "Range of ports / Specific port\n",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "l2|l3|l4",
        "Layer2 / Layer3 / Layer4 position\n",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<offset>",
        "Offset in bytes the given Layer, must be even, within the first 104 bytes in the frame.",
        CLI_PARM_TYPE_OFFSET_VALUE,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<pattern>",
        "Pattern to match, 2 bytes",
        CLI_PARM_TYPE_PATTERN_VALUE,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<mask>",
        "Mask, 0-0xFFFF",
        CLI_PARM_TYPE_MASK_VALUE,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },        
    {
        "drop|forward",
        "\ndrop        : Drop the frame if matched\n"
        "forward     : Forward the frame if matched\n",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<dmac>",
        "Destination MAC address (xx-xx-xx-xx-xx-xx)",
        CLI_PARM_TYPE_DMAC,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<dmac_mask>",
        "Mask for MAC address (xx-xx-xx-xx-xx-xx)",
        CLI_PARM_TYPE_DMAC_MASK,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<etype>",
        "Etype value",
        CLI_PARM_TYPE_ETYPE,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<red_min>",
        "Red min queue fill level in bytes, 0-32640",
        CLI_PARM_TYPE_RED_MIN,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<red_max>",
        "Red max queue fill level in bytes, 0-65280",
        CLI_PARM_TYPE_RED_MAX,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<red_weight>",
        "Red weight level (0-31) for avg queue level calc, 9 is typically used.",
        CLI_PARM_TYPE_RED_WEIGHT,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<prob_1>",
        "Red probability profile 1 value, 0-100%",
        CLI_PARM_TYPE_RED_PROB_1,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<prob_2>",
        "Red probability profile 2 value, 0-100%",
        CLI_PARM_TYPE_RED_PROB_2,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<prob_3>",
        "Red probability profile 3 value, 0-100%",
        CLI_PARM_TYPE_RED_PROB_3,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<vid>",
        "VID value",
        CLI_PARM_TYPE_VLAN,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<class>",
        "Class 1-8",
        CLI_PARM_TYPE_CLASS_VALUE,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "prim|alt",
        "Primary / Alternate endpoint table\n",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "rx|tx",
        "Receive / Transmit direction, as seen from the SPI4 interface\n",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<bit_rate>",
        "Rate in 1000 bits per second. 0 to disable",
        CLI_PARM_TYPE_QOS_BIT_RATE,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<level>",
        "Max bucket depth in bytes, 1-256KB",
        CLI_PARM_TYPE_QOS_LEVEL,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<red>",
        "Random Early Drop 0-3, 0=disable",
        CLI_PARM_TYPE_RED_VALUE,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "mac_ctrl|mac_zero|dmac_bc|smac_mc|untag|prio_tag|c_tag|s_tag|tags",
        "mac_ctrl   : Filter mac ctrl frames\n"
        "mac_zero   : Filter frames with zero mac address\n"
        "dmac_bc    : Filter frames with BC DMAC\n"
        "smac_mc    : Filter frames with MC SMAC\n"
        "untag      : Filter untagged frames\n"
        "prio_tag   : Filter priority tagged frames\n"
        "c_tag      : Filter C-tagged frames\n"
        "s_tag      : Filter S-tagged frames\n"
        "(default: Show configured and current mode)",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NO_TXT | CLI_PARM_FLAG_SET
    },
    {
        "any_tag|1_tag|2_tags",
        "any_tag : Any number of tags allowed\n"
        "1_tag   : Max 1 tag allowed\n"
        "2_tags  : Max 2 tags allowed\n"
        "(default: Show configured and current mode)",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NO_TXT | CLI_PARM_FLAG_SET
    },
    {
        "<mmd_list>",
        "MMD address list (0-31)",
        CLI_PARM_TYPE_MMD_LIST,
        CLI_CMD_ID_DEBUG_MMD_WRITE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<mmd_list>",
        "MMD address list (0-31)",
        CLI_PARM_TYPE_MMD_LIST,
        CLI_CMD_ID_DEBUG_MMD_READ,
        CLI_PARM_FLAG_NONE
    },
    {
        "<mmd_address>",
        "MMD register address (0-0xffff)",
        CLI_PARM_TYPE_MMD_ADDR,
        CLI_CMD_ID_DEBUG_MMD_WRITE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<mmd_address>",
        "MMD register address (0-0xffff)",
        CLI_PARM_TYPE_MMD_ADDR,
        CLI_CMD_ID_DEBUG_MMD_READ,
        CLI_PARM_FLAG_NONE
    },

#endif /* VTSS_ARCH_B2 */
    {
        "<addr_list>",
        "Register address list (0-31)",
        CLI_PARM_TYPE_PHY_ADDR_LIST,
        CLI_CMD_ID_DEBUG_PHY_WRITE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<addr_list>",
#if defined(VTSS_ARCH_B2)
        "Register address list (0-0xffff)",
#else
        "Register address list (0-255)",
#endif /* VTSS_ARCH_B2 */
        CLI_PARM_TYPE_ADDR_LIST,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<value>",
        "Register value (0-0xffff)",
        CLI_PARM_TYPE_PHY_VALUE,
        CLI_CMD_ID_DEBUG_PHY_WRITE,
        CLI_PARM_FLAG_SET
    },
#if defined(VTSS_ARCH_B2)
    {
        "<value>",
        "Register value (0-0xffff)",
        CLI_PARM_TYPE_PHY_VALUE,
        CLI_CMD_ID_DEBUG_MMD_WRITE,
        CLI_PARM_FLAG_SET
    },
#endif /* VTSS_ARCH_B2 */
#if defined(VTSS_GPIOS)
    {
        "<value>",
        "GPIO value (0 or 1)",
        CLI_PARM_TYPE_GPIO_VALUE,
        CLI_CMD_ID_DEBUG_GPIO_WRITE,
        CLI_PARM_FLAG_NONE
    },
#endif /* GPIOS */
    {
        "<value>",
        "Register value (0-0xffffffff)",
        CLI_PARM_TYPE_VALUE,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_SET
    },
    {
        "<page>",
        "Register page (0-0xffff), default: page 0",
        CLI_PARM_TYPE_PAGE,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    {
        "<module>",
        "Trace module name, default: All modules",
        CLI_PARM_TYPE_TRACE_MODULE,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "<group>",
        "Trace group name, default: All groups",
        CLI_PARM_TYPE_TRACE_GROUP,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NONE
    },
    {
        "none|error|warning|info|debug|noise",
        "none    : No trace\n"
        "error   : Error trace level\n"
        "warning : Warning trace level\n"
        "info    : Information trace level\n"
        "debug   : Debug trace level\n"
        "noise   : Noise trace level\n"
        "(default: Show trace level)",
        CLI_PARM_TYPE_KEYWORD,
        CLI_CMD_ID_NONE,
        CLI_PARM_FLAG_NO_TXT | CLI_PARM_FLAG_SET
    },
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */
};  /* cli_parm_table */

#if defined(VTSS_ARCH_B2)
#define CLI_BLK_MAX  64    /* Switch blocks */
#define CLI_ADDR_MAX 65536 /* Switch register addresses */
#else
#define CLI_BLK_MAX  8   /* Switch blocks */
#define CLI_ADDR_MAX 256 /* Switch register addresses */
#endif /* VTSS_ARCH_B2 */

#define CLI_SUB_MAX  16  /* Switch sub blocks */
#define CLI_PHY_MAX  32  /* PHY register addresses */

#define CLI_PORT_MAX 26  /* Chip ports */

/* CLI request block */
typedef struct {
    int          parm_parsed;
    BOOL         set;
  
    BOOL         port_list[VTSS_PORT_ARRAY_SIZE];
    BOOL         chip_port_list[CLI_PORT_MAX];
#if defined(VTSS_ARCH_B2)
    BOOL         lport_list[VTSS_LPORTS];
#endif
#if defined(VTSS_GPIOS)
    BOOL         gpio_list[VTSS_GPIO_NO_END];
#endif /* VTSS_GPIOS */
    vtss_speed_t speed;
    BOOL         fdx;
    ulong        max_length;

    /* Keywords */
    BOOL auto_keyword;
    BOOL binary;
    BOOL bytes;
    BOOL clear;
    BOOL discards;
    BOOL decimal;
    BOOL disable;
    BOOL enable;
    BOOL errors;
    BOOL egress;
    BOOL ingress;
    BOOL packets;
    
    BOOL  blk_list[CLI_BLK_MAX];
    BOOL  sub_list[CLI_SUB_MAX];
    BOOL  addr_list[CLI_ADDR_MAX];
    BOOL  mmd_list[CLI_ADDR_MAX];
    
    ulong value;
    ulong addr;
    ulong etype;
    ulong vlan;
    ulong page;
    ulong mmd_address;
    ulong class;
    ulong red;
    ulong table_id;
    ulong table_index;
    ulong trig_index;
    BOOL  dscp_list[64];
    ulong offset;
    ulong pattern;
    ulong mask;
    ulong tcp_udp_port;
    ulong order;
    ulong endpoint;
    ulong ip_proto;
    ulong tag_prio;
    ulong mpls_exp;
    ulong red_min;
    ulong red_max;
    ulong red_weight;
    ulong red_prob1;
    ulong red_prob2;
    ulong red_prob3;
    ulong rate;
    
    int trace_module_id; 
    int trace_grp_idx;   
    int trace_lvl;  
#if defined(VTSS_ARCH_B2)     
    vtss_port_filter_t filter;
    vtss_qos_policer_t policer;
#endif
    BOOL max_tags;
    BOOL allow;
    BOOL range;
    BOOL forward;
    BOOL def;
    BOOL cfi;
    BOOL ipv4;
    BOOL ipv6;
    BOOL llc;
    BOOL l2_ctrl;
    BOOL l3_ctrl;
    BOOL ctag;
    BOOL vlan_aware;
    BOOL tag_inner;
    BOOL alt;
    BOOL transmit;
    int layer;

    uchar dmac[6];
    uchar dmac_mask[6];
    

} cli_req_t;

static cli_req_t cli_req;

static char *cli_parse_find(char *cmd, char *stx)
{
    char *p, *found = NULL;
    BOOL parm = 0, start = 1;

    for (p = stx; *p != '\0'; p++) {
        if (parm) {
            /* Look for parameter end character */
            if (*p == '>')
                parm = 0;
        } else if (*p == '<') {
            /* Parameter start character */
            parm = 1;
        } else if (*p == '|' || *p == '[' || *p == '(') {
            /* Next argument character */
            start = 1;
        } else if (start) {
            start = 0;
            if (strstr(p, cmd) == p) {
                if (found != NULL)
                    return NULL;
                found = p;
            }
        }
    }
    return found;
}

/* Parse keyword string, for example 'disable' */
static int cli_parse_keyword(char *cmd, cli_req_t *req, char *stx)
{
    char *found;

 
    if ((found = cli_parse_find(cmd, stx)) == NULL)
        return 1;

   
    if (!strncmp(found, "auto", 4))
        req->auto_keyword = 1;
    else if (!strncmp(found, "binary", 6))
        req->binary = 1;
    else if (!strncmp(found, "bytes", 5))
        req->bytes = 1;
    else if (!strncmp(found, "clear", 5))
        req->clear = 1;
    else if (!strncmp(found, "discards", 8))
        req->discards = 1;
    else if (!strncmp(found, "disable", 7))
        req->disable = 1;
    else if (!strncmp(found, "decimal", 7))
        req->decimal = 1;
#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    else if (!strncmp(found, "debug", 5))
        req->trace_lvl = VTSS_TRACE_LVL_DEBUG;
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */
    else if (!strncmp(found, "enable", 6))
        req->enable = 1;
    else if (!strncmp(found, "errors", 6))
        req->errors = 1;
    else if (!strncmp(found, "egress", 6))
        req->egress = 1;
    else if (!strncmp(found, "ingress", 7))
        req->ingress = 1;
#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    else if (!strncmp(found, "error", 5))
        req->trace_lvl = VTSS_TRACE_LVL_ERROR;
    else if (!strncmp(found, "info", 4))
        req->trace_lvl = VTSS_TRACE_LVL_INFO;
    else if (!strncmp(found, "noise", 5))
        req->trace_lvl = VTSS_TRACE_LVL_NOISE;
    else if (!strncmp(found, "none", 4))
        req->trace_lvl = VTSS_TRACE_LVL_NONE;
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */
    else if (!strncmp(found, "packets", 7))
        req->packets = 1;
#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    else if (!strncmp(found, "warning", 7))
        req->trace_lvl = VTSS_TRACE_LVL_WARNING;
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */
    else if (!strncmp(found, "10hdx", 5))
        req->speed = VTSS_SPEED_10M;
    else if (!strncmp(found, "10fdx", 5)) {
        req->speed = VTSS_SPEED_10M;
        req->fdx = 1;
    } else if (!strncmp(found, "100hdx", 6))
        req->speed = VTSS_SPEED_100M;
    else if (!strncmp(found, "100fdx", 6)) { 
        req->speed = VTSS_SPEED_100M;
        req->fdx = 1;
    } else if (!strncmp(found, "1000fdx", 7)) {
        req->speed = VTSS_SPEED_1G;
        req->fdx = 1;    
#if defined(VTSS_ARCH_B2)
    } else if (!strncmp(found, "allow", 5)) {
        req->allow = 1;
    } else if (!strncmp(found, "deny", 4)) {
        req->allow = 0;
    } else if (!strncmp(found, "mac_ctrl", 8)) {
        req->filter.mac_ctrl_enable = 1;
    } else if (!strncmp(found, "mac_zero", 8)) {
        req->filter.mac_zero_enable = 1;
    } else if (!strncmp(found, "dmac_bc", 7)) {
        req->filter.dmac_bc_enable = 1;
    } else if (!strncmp(found, "smac_mc", 7)) {
        req->filter.smac_mc_enable = 1;
    } else if (!strncmp(found, "untag", 5)) {
        req->filter.untag_enable = 1;
    } else if (!strncmp(found, "prio_tag", 8)) {
        req->filter.prio_tag_enable = 1;
    } else if (!strncmp(found, "c_tag", 5)) {
        req->filter.ctag_enable = 1;
    } else if (!strncmp(found, "s_tag", 5)) {
        req->filter.stag_enable = 1;
    } else if (!strncmp(found, "tags", 4)) {
        req->max_tags = 1;
    } else if (!strncmp(found, "any_tag", 4)) {
        req->filter.max_tags = VTSS_TAG_ANY;
    } else if (!strncmp(found, "1_tag", 5)) {
        req->filter.max_tags = VTSS_TAG_ONE;
    } else if (!strncmp(found, "2_tags", 6)) {
        req->filter.max_tags = VTSS_TAG_TWO;
    } else if (!strncmp(found, "range", 5)) {
        req->range = 1;
    } else if (!strncmp(found, "specific", 8)) {
        req->range = 0;
    } else if (!strncmp(found, "drop", 4)) {
        req->forward = 0;
    } else if (!strncmp(found, "forward", 7)) {
        req->forward = 1;
    } else if (!strncmp(found, "l2_ctrl", 7)) {
        req->l2_ctrl = 1;
    } else if (!strncmp(found, "l3_ctrl", 7)) {
        req->l3_ctrl = 1;
    } else if (!strncmp(found, "l2", 2)) {
        req->layer = VTSS_HEADER_L2;
    } else if (!strncmp(found, "l3", 2)) {
        req->layer = VTSS_HEADER_L3;
    } else if (!strncmp(found, "l4", 2)) {
        req->layer = VTSS_HEADER_L4;
    } else if (!strncmp(found, "default", 7)) {
        req->def = 1;
    } else if (!strncmp(found, "cfi", 3)) {
        req->cfi = 1;
    } else if (!strncmp(found, "ipv4", 4)) {
        req->ipv4 = 1;
    } else if (!strncmp(found, "ipv6", 4)) {
        req->ipv6 = 1;
    } else if (!strncmp(found, "llc", 3)) {
        req->llc = 1;
    } else if (!strncmp(found, "ctag", 4)) {
        req->ctag = 1;
    } else if (!strncmp(found, "tag_inner", 9)) {
        req->tag_inner = 1;
    } else if (!strncmp(found, "vlan_aware", 10)) {
        req->vlan_aware = 1;
    } else if (!strncmp(found, "prim", 4)) {
        req->alt = 0;
    } else if (!strncmp(found, "alt", 3)) {
        req->alt = 1;
    } else if (!strncmp(found, "tx", 2)) {
        req->transmit = 1;
    } else if (!strncmp(found, "rx", 2)) {
        req->transmit = 0;
    } else if (!strncmp(found, "uc", 2)) {
        req->policer.unicast = 1;
    } else if (!strncmp(found, "mc", 2)) {
        req->policer.multicast = 1;
    } else if (!strncmp(found, "bc", 2)) {
        req->policer.broadcast = 1;
    } else if (!strncmp(found, "all", 3)) {
        req->policer.broadcast = 1;
        req->policer.unicast = 1;
        req->policer.multicast = 1;
#endif
    } else {
        printf("no match:%s\n",found);
    }
    
    return 0;
}

/* Convert text to list */
static int cli_parse_list(char *buf, BOOL *list, ulong min, ulong max, BOOL def)
{
    ulong i, start = 0, n;
    char  *p, *end;
    BOOL  error, range = 0, comma = 0;
    
    /* Clear list by default */
    for (i = min; i <= max; i++)
        list[i] = 0;

    p = buf;
    error = (p == NULL);
    while (p != NULL && *p != '\0') {
        /* Read integer */
        n = strtoul(p, &end, 0);
        if (end == p) {
            error = 1;
            break;
        }
        p = end;
        
        /* Check legal range */
        if (n < min || n > max) {
            error = 1;
            break;
        }
        
        if (range) {
            /* End of range has been read */
            if (n < start) {
                error = 1;
                break;
            }
            for (i = start ; i <= n; i++)
                list[i] = 1;
            range = 0;
        } else if (*p == '-') {
            /* Start of range has been read */
            start = n;
            range = 1;
            p++;
        } else {
            /* Single value has been read */
            list[n] = 1;
        }
        comma = 0;
        if (!range && *p == ',') {
            comma = 1;
            p++;
        }
    }
    
    /* Check for trailing comma/dash */
    if (comma || range)
        error = 1;
    
    /* Restore defaults if error */
    for (i = min; error && i <= max; i++)
        list[i] = def;

    return error;
}


/* MAC address, e.g. 00-11-22-33-44-55 */
static int cli_parse_mac(char *cmd, uchar *mac_addr) __VTSS_ATTRIB_UNUSED_FUNCTION__;
static int cli_parse_mac(char *cmd, uchar *mac_addr)
{
    uint i, mac[6];
    int error = 1;
    
    if (sscanf(cmd, "%2x-%2x-%2x-%2x-%2x-%2x", 
               &mac[0], &mac[1], &mac[2], &mac[3], &mac[4], &mac[5]) == 6) {
        for (i = 0; i < 6; i++)
            mac_addr[i] = (mac[i] & 0xff);

        error = 0;
    } 
    return error;
}

static int cli_parse_ulong(char *buf, ulong *val, ulong min, ulong max)
{
    ulong n;
    char  *end;

    n = strtoul(buf, &end, 0);
    if (*end != '\0' || n < min || n > max)
        return 1;

    *val = n;
    return 0;
}

/* Remove unused ports from the list */
static void cli_remove_unused_ports(cli_req_t *req)
{
    vtss_port_no_t          port_no;
    vtss_appl_port_status_t status;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        if (req->port_list[port_no] && 
            vtss_appl_port_status_get(port_no, &status) != VTSS_OK)
            req->port_list[port_no] = 0;
}

static void cli_req_default_set(cli_req_t *req)
{
    memset(req, 0, sizeof(*req));
    cli_parse_list(NULL, req->port_list, 0, VTSS_PORT_NO_END - 1, 1);
    cli_remove_unused_ports(req);
    cli_parse_list(NULL, req->chip_port_list, 0, CLI_PORT_MAX, 1);
#if defined(VTSS_ARCH_B2)
    cli_parse_list(NULL, req->lport_list, 0, VTSS_LPORTS-1, 1);
#endif
    cli_parse_list(NULL, req->dscp_list, 0, 63, 1);
#if defined(VTSS_GPIOS)
    cli_parse_list(NULL, req->gpio_list, 0, VTSS_GPIO_NO_END - 1, 1);
#endif /* VTSS_GPIOS */
    req->table_id = 1;
    req->table_index = 1;

#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    req->trace_module_id = TRACE_MODULE_ID_ALL;
    req->trace_grp_idx = TRACE_GRP_IDX_ALL;
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */
}

static const char *cli_bool_txt(BOOL enabled)
{
    return (enabled ? "Enabled " : "Disabled");
}

static const char *port_mgmt_mode_txt(vtss_speed_t speed, BOOL fdx)
{
    switch (speed) {
    case VTSS_SPEED_10M:
        return (fdx ? "10fdx" : "10hdx");
    case VTSS_SPEED_100M:
        return (fdx ? "100fdx" : "100hdx");
    case VTSS_SPEED_1G:
        return (fdx ? "1Gfdx" : "1Ghdx");
    case VTSS_SPEED_2500M:
        return (fdx ? "2.5Gfdx" : "2.5Ghdx");
    case VTSS_SPEED_5G:
        return (fdx ? "5Gfdx" : "5Ghdx");
    case VTSS_SPEED_10G:
        return (fdx ? "10Gfdx" : "10Ghdx");
    default:
        return "?";
    }
}

static const char *misc_mac_txt(const uchar *mac, char *buf) __VTSS_ATTRIB_UNUSED_FUNCTION__;
static const char *misc_mac_txt(const uchar *mac, char *buf)
{
    sprintf(buf, "%02x-%02x-%02x-%02x-%02x-%02x",
            mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    return buf;
}

static void cli_table_header(const char *txt)
{
    int         i, j, len, count = 0;
    BOOL        parm = 0;
    
    len = strlen(txt);
    printf("%s\n", txt);
    for (i = 0; i < len; i++) {
        if (txt[i] == ' ') {
            count++;
        } else {
            for (j = 0; j < count; j++) {
                printf("%c", count > 1 && (parm || j >= (count - 2)) ? ' ' : '-'); 
            }
            printf("-");
            count = 0;
        }
    }
    for (j = 0; j < count; j++) {
        printf("%c", count > 1 && (parm || j >= (count - 2)) ? ' ' : '-'); 
    }
    printf("\n");
}

static void cli_cmd_help(void) 
{
    printf("Type '<group> ?' to get list of group commands, e.g. 'port ?'.\n");
    printf("Type '<command> ?' to get help on a command, e.g. 'port mode ?'.\n");
    printf("Commands may be abbreviated, e.g. 'po co' instead of 'port configuration'.\n");
}

/* Header with optional new line before and after */
static void cli_header_nl_char(const char *txt, BOOL pre, BOOL post, char c)
{
    int i, len;
    
    if (pre)
        printf("\n");
    printf("%s:\n", txt);
    len = (strlen(txt) + 1);
    for (i = 0; i < len; i++)
        printf("%c", c);
    printf("\n");
    if (post)
        printf("\n");
}

/* Underlined header with optional new line before and after */
static void cli_header_nl(const char *txt, BOOL pre, BOOL post)
{
    cli_header_nl_char(txt, pre, post, '-');
}

/* Port configuration */
static void cli_cmd_port_conf(cli_req_t *req, BOOL state, BOOL mode, 
                              BOOL flow_control, BOOL max_length) 
{
    vtss_port_no_t          port_no;
    vtss_appl_port_conf_t   conf;
    vtss_appl_port_status_t status;
    BOOL                    first = 1;
    char                    buf[80], *p;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0 || 
            vtss_appl_port_conf_get(port_no, &conf) != VTSS_OK ||
            vtss_appl_port_status_get(port_no, &status) != VTSS_OK)            
            continue;

        if (req->set) {
            if (mode) {
                conf.autoneg = req->auto_keyword;
                if (!conf.autoneg) {
                    conf.speed = req->speed;
                    conf.fdx = req->fdx;
                }
            } 
            if (state)
                conf.enable = req->enable;
            if (flow_control)
                conf.flow_control = req->enable;
            if (max_length)
                conf.max_length = req->value;
            vtss_appl_port_conf_set(port_no, &conf);
        } else {
            if (first) {
                p = &buf[0];
                p += sprintf(p, "Port  ");
                if (state)
                    p += sprintf(p, "State     ");
                if (mode)
                    p += sprintf(p, "Mode    ");
                if (flow_control) {
                    p += sprintf(p, "Flow Control  ");
                    if (!state)
                        p += sprintf(p, "Rx Pause  Tx Pause  ");
                }
                if (max_length)
                    p += sprintf(p, "MaxFrame  ");
                if (mode)
                    p += sprintf(p, "Link  ");
                cli_table_header(buf);
                first = 0;
            }
            printf("%-6d", port_no);
            if (state)
                printf("%-10s", cli_bool_txt(conf.enable));
            if (mode)
                printf("%-8s", 
                        conf.autoneg ? "Auto" : port_mgmt_mode_txt(conf.speed, conf.fdx));
            if (flow_control) {
                BOOL rx = (conf.autoneg ? (status.link ? status.aneg.obey_pause : 0) :
                           conf.flow_control);
                BOOL tx = (conf.autoneg ? (status.link ? status.aneg.generate_pause : 0) :
                           conf.flow_control);
                printf("%-14s", cli_bool_txt(conf.flow_control));
                if (!state)
                    printf("%s  %s  ", cli_bool_txt(rx), cli_bool_txt(tx));
            }
            if (max_length)
                printf("%-10u", conf.max_length);
            if (mode) {
                printf("%s", 
                       status.link ? port_mgmt_mode_txt(status.speed, status.fdx) : "Down");
            }
            printf("\n");
        }
    }
}

/* Print counters in two columns with header */
static void cli_cmd_stat_port(vtss_port_no_t port_no, BOOL *first, const char *name, 
                              ulonglong c1, ulonglong c2)
{
    char buf[80], *p;

    if (*first) {
        *first = 0;
        p = &buf[0];
        p += sprintf(p, "Port  Rx %-17sTx %-17s", name, name);
        cli_table_header(buf);
    }
    printf("%-2d    %-20llu%-20llu\n", port_no, c1, c2);
}

/* Print two counters in columns */
static void cli_cmd_stats(const char *col1, const char *col2, ulonglong c1, ulonglong c2)
{
    char buf[80];
    
    sprintf(buf, "Rx %s:", col1);
    printf("%-19s%19llu   ", buf, c1);
    if (col2 != NULL) {
        sprintf(buf, "Tx %s:", strlen(col2) ? col2 : col1);
        printf("%-19s%19llu", buf, c2);
    }
    printf("\n");
}

#if defined(VTSS_ARCH_SPARX)
#define RMON_FRAME_MAX 1526
#else
#define RMON_FRAME_MAX 1518
#endif /* VTSS_ARCH_SPARX */

/* Port statistics */
static void cli_cmd_port_stats(cli_req_t *req)
{
    vtss_port_no_t       port_no;
    vtss_poag_counters_t counters;
    BOOL                 first = 1;
    char                 buf[32];

    buf[0] = 0;
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
            
        /* Handle 'clear' command */
        if (req->clear) {
            vtss_poag_counters_clear(port_no);
            continue;
        }
            
        /* Get counters */
        if (vtss_poag_counters_get(port_no, &counters) != VTSS_OK)
            continue;
        
        /* Handle 'packet' command */
        if (req->packets) {
            cli_cmd_stat_port(port_no, &first, "Packets", 
                              counters.rmon.rx_etherStatsPkts, 
                              counters.rmon.tx_etherStatsPkts);
            continue;
        } 
        
        /* Handle 'bytes' command */
        if (req->bytes) {
            cli_cmd_stat_port(port_no, &first, "Octets", 
                              counters.rmon.rx_etherStatsOctets,
                              counters.rmon.tx_etherStatsOctets);
            continue;
        } 
        
        /* Handle 'errors' command */
        if (req->errors) {
            cli_cmd_stat_port(port_no, &first, "Errors", 
                              counters.if_group.ifInErrors, 
                              counters.if_group.ifOutErrors);
            continue;
        } 
        
        /* Handle 'discards' command */
        if (req->discards) {
            cli_cmd_stat_port(port_no, &first, "Discards", 
                              counters.if_group.ifInDiscards, 
                              counters.if_group.ifOutDiscards);
            continue;
        }
        
        /* Handle default command */
        printf("%sPort %d Statistics:\n\n", first ? "" : "\n", port_no);
        first = 0;
        cli_cmd_stats("Packets", "",
                      counters.rmon.rx_etherStatsPkts, 
                      counters.rmon.tx_etherStatsPkts);
        cli_cmd_stats("Octets", "",
                      counters.rmon.rx_etherStatsOctets, 
                      counters.rmon.tx_etherStatsOctets);
#if defined(VTSS_FEATURE_PORT_CNT_PKT_CAST)
        cli_cmd_stats("Unicast", "",
                      counters.if_group.ifInUcastPkts,
                      counters.if_group.ifOutUcastPkts);
        cli_cmd_stats("Multicast", "", 
                      counters.rmon.rx_etherStatsMulticastPkts,
                      counters.rmon.tx_etherStatsMulticastPkts);
        cli_cmd_stats("Broadcast", "", 
                      counters.rmon.rx_etherStatsBroadcastPkts,
                      counters.rmon.tx_etherStatsBroadcastPkts);
#endif /* VTSS_FEATURE_PORT_CNT_PKT_CAST */
#if defined(VTSS_FEATURE_PORT_CNT_PAUSE)
        cli_cmd_stats("Pause", "", 
                      counters.ethernet_like.dot3InPauseFrames,
                      counters.ethernet_like.dot3OutPauseFrames);
#endif /* VTSS_FEATURE_PORT_CNT_PAUSE */
        printf("\n");
#if defined(VTSS_FEATURE_PORT_CNT_RMON_ADV)
        cli_cmd_stats("64", "",
                      counters.rmon.rx_etherStatsPkts64Octets,
                      counters.rmon.tx_etherStatsPkts64Octets);
        cli_cmd_stats("65-127", "",
                      counters.rmon.rx_etherStatsPkts65to127Octets,
                      counters.rmon.tx_etherStatsPkts65to127Octets);
        cli_cmd_stats("128-255", "",
                      counters.rmon.rx_etherStatsPkts128to255Octets,
                      counters.rmon.tx_etherStatsPkts128to255Octets);
        cli_cmd_stats("256-511", "",
                      counters.rmon.rx_etherStatsPkts256to511Octets,
                      counters.rmon.tx_etherStatsPkts256to511Octets);
        cli_cmd_stats("512-1023", "",
                      counters.rmon.rx_etherStatsPkts512to1023Octets,
                      counters.rmon.tx_etherStatsPkts512to1023Octets);
        sprintf(buf, "1024-%u", RMON_FRAME_MAX);
        cli_cmd_stats(buf, "",
                      counters.rmon.rx_etherStatsPkts1024to1518Octets,
                      counters.rmon.tx_etherStatsPkts1024to1518Octets);
#if defined(VTSS_FEATURE_PORT_CNT_JUMBO)
        sprintf(buf, "%u-    ", RMON_FRAME_MAX + 1);
        cli_cmd_stats(buf, "",
                      counters.rmon.rx_etherStatsPkts1519toMaxOctets,
                      counters.rmon.tx_etherStatsPkts1519toMaxOctets);
#endif /* VTSS_FEATURE_PORT_CNT_JUMBO */
        printf("\n");
#endif /* VTSS_FEATURE_PORT_CNT_RMON_ADV */

#if defined(VTSS_ARCH_B2)
        {
            int  i;
            
            for (i = 0; i < VTSS_PRIOS; i++) {
                sprintf(buf, "Packets_%u", i);
                cli_cmd_stats(buf, NULL, counters.prop.rx_prio[i], 0);
            }
            printf("\n");
        }
#endif /* VTSS_ARCH_B2 */
        
        cli_cmd_stats("Drops", "",
                      counters.rmon.rx_etherStatsDropEvents,
                      counters.rmon.tx_etherStatsDropEvents);
#if defined(VTSS_FEATURE_PORT_CNT_ETHER_LIKE)
        cli_cmd_stats("CRC/Alignment", "Late Collisions",
                      counters.rmon.rx_etherStatsCRCAlignErrors,
                      counters.ethernet_like.dot3StatsLateCollisions);
        cli_cmd_stats("Symbol", "Excessive Coll.",
                      counters.ethernet_like.dot3StatsSymbolErrors,
                      counters.ethernet_like.dot3StatsExcessiveCollisions);
        cli_cmd_stats("Undersize", "Carrier Sense",
                      counters.rmon.rx_etherStatsUndersizePkts,
                      counters.ethernet_like.dot3StatsCarrierSenseErrors);
#else
#if defined(VTSS_FEATURE_PORT_CNT_RMON_ADV)
        cli_cmd_stats("CRC/Alignment", "Late/Exc. Coll.",
                      counters.rmon.rx_etherStatsCRCAlignErrors,
                      counters.if_group.ifOutErrors);
        cli_cmd_stats("Undersize", NULL, counters.rmon.rx_etherStatsUndersizePkts, 0);
#else
        cli_cmd_stats("Errors", "",
                      counters.if_group.ifInErrors,
                      counters.if_group.ifOutErrors);
#endif /* VTSS_FEATURE_PORT_CNT_RMON_ADV */
#endif /* VTSS_FEATURE_PORT_CNT_ETHER_LIKE */
#if defined(VTSS_FEATURE_PORT_CNT_RMON_ADV)
        cli_cmd_stats("Oversize", NULL, counters.rmon.rx_etherStatsOversizePkts, 0);
        cli_cmd_stats("Fragments", NULL, counters.rmon.rx_etherStatsFragments, 0);
        cli_cmd_stats("Jabbers", NULL, counters.rmon.rx_etherStatsJabbers, 0);
#endif /* VTSS_FEATURE_PORT_CNT_RMON_ADV */
#if defined(VTSS_ARCH_B2)
        printf("\n");
        cli_cmd_stats("Filtered", NULL, counters.prop.rx_filter_drops, 0);
        cli_cmd_stats("Policed", NULL, counters.prop.rx_policer_drops, 0);
        {
            int  i;

            for (i = 0; i < VTSS_PRIOS; i++) {
                sprintf(buf, "Drops_%u", i);
                cli_cmd_stats(buf, NULL, counters.prop.rx_prio_drops[i], 0);
            }                
        }
#endif /* VTSS_ARCH_B2 */
    } /* Port loop */
}

#if defined(VTSS_ARCH_B2)
/* Setup the global DSCP tables, 2 tables, 64 entries in each */
static void cli_cmd_qos_global_dscp(cli_req_t *req)
{
    uint              dscp, first = 1;
    vtss_dscp_entry_t *entry;

    for (dscp = 0; dscp < 64; dscp++) {
        if (req->dscp_list[dscp] == 0)
            continue;

        if (req->set) {
            entry = &cli_state.dscp_table[req->table_id - 1][dscp];
            entry->enable = req->enable;
            entry->qos.prio = req->class;
            entry->qos.red = req->red;
            entry = &cli_state.dscp_table[req->table_id - 1][0];
            if (vtss_dscp_table_set(req->table_id, entry) != VTSS_OK)
                printf("Could not compute\n");
        } else {
            if (first)
                cli_table_header("DSCP  Trusted   Class  Red"); 
            first = 0;
            entry = &cli_state.dscp_table[req->table_id - 1][dscp];
            printf("%-4u  %s  %-5u  %u\n", 
                   dscp, cli_bool_txt(entry->enable), entry->qos.prio, entry->qos.red);
        }
    }
}

/* The DSCP table (1 or 2) used by each port         */
static void cli_cmd_qos_dscp_table(cli_req_t *req)
{
    int              first=1, port_no;
    vtss_port_qos_setup_t qos;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {        
            qos.dscp_table_no = req->table_id;
            
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {            
            if (first)
                cli_table_header("Port  Table ID");
            first = 0;
            printf("%-4u  %u\n", port_no, qos.dscp_table_no);
        }
    }            
}

/* Setup the global tcp/udp ports, 8 entries, range/specific */
static void cli_cmd_qos_global_tcpudp(cli_req_t *req)
{
    int              first=1, table_index;
    vtss_qos_setup_t qos;

    if (vtss_qos_setup_get(&qos) != VTSS_OK) {
        printf("Could not get QoS conf\n");
        return;
    }

    if (req->set) {        
        req->table_index = req->table_index - 1; /* 1-8 changes to 0-7  */
        qos.udp_tcp[req->table_index/2].pair[req->table_index%2].port = req->tcp_udp_port;
        if (req->range) {
            qos.udp_tcp[req->table_index/2].pair[0].qos.prio = req->class;
            qos.udp_tcp[req->table_index/2].pair[1].qos.prio = req->class;
            qos.udp_tcp[req->table_index/2].pair[0].qos.red = req->red;
            qos.udp_tcp[req->table_index/2].pair[1].qos.red = req->red;
        } else {
            qos.udp_tcp[req->table_index/2].pair[req->table_index%2].qos.prio = req->class;
            qos.udp_tcp[req->table_index/2].pair[req->table_index%2].qos.red = req->red;            
        }
        qos.udp_tcp[req->table_index/2].range = req->range;         

        if (vtss_qos_setup_set(&qos) != VTSS_OK) {
            printf("Could not set QoS conf\n");
            return;
        }        
    } else {
        if (first) {        
            printf("Index     Port     Range|Specific     Class         Red                 \n");            
            first = 0;
        }
        
        for (table_index=0; table_index<8; table_index++) {
            printf("%d %#12x %12s %12d %12d\n",table_index+1,
                   qos.udp_tcp[table_index/2].pair[table_index%2].port,
                   qos.udp_tcp[table_index/2].range?"Range":"Specific",
                   qos.udp_tcp[table_index/2].pair[table_index%2].qos.prio,
                   qos.udp_tcp[table_index/2].pair[table_index%2].qos.red);
        }        
    }
}

/* Include / exclude the global tcp/udp ports per port  */
static void cli_cmd_qos_tcpudp_enable(cli_req_t *req)
{
    int              first=1, pair_no, port_no, i;
    vtss_port_qos_setup_t qos;
    vtss_qos_setup_t glb_qos;
    char             buf[200];

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK || vtss_qos_setup_get(&glb_qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {        
            if (req->table_index == 0) {
                /* Enable / Disable all tables  */
                for(i = 0; i<8; i++) {
                    qos.udp_tcp.global_enable[i/2][i%2] = req->enable;
                }                
            } else {                
                req->table_index = req->table_index - 1; /* 1-8 changes to 0-7  */
                if (glb_qos.udp_tcp[req->table_index/2].range) {
                    /* Enable both ports if they are in a range */
                    qos.udp_tcp.global_enable[req->table_index/2][0] = req->enable;
                    qos.udp_tcp.global_enable[req->table_index/2][1] = req->enable;
                } else {                
                    qos.udp_tcp.global_enable[req->table_index/2][req->table_index%2] = req->enable;
                }
            }
            
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
            
        } else {
            if (first) {        
                memset(&buf, 0, sizeof(buf));
                printf("              Port enable/disable status for global TCP/UDP port settings\n");
                sprintf(buf,"     ");
                for (i=1; i<9; i++) {
                    sprintf(buf, "%s %8d",buf,i);
                }
                first = 0;
                printf("%s\n",buf);            
            }
            memset(&buf, 0, sizeof(buf));
            sprintf(buf, "%-8d",port_no);
            
            for (pair_no = 0; pair_no < VTSS_UDP_TCP_PAIR_COUNT; pair_no++) {        
                sprintf(buf, "%s %8s %8s",buf,qos.udp_tcp.global_enable[pair_no][0]?"Enabled":"Disabled",
                        qos.udp_tcp.global_enable[pair_no][1]?"Enabled":"Disabled");
            }                
            printf("%s\n",buf);            
        }
    }        
}

/* Include / exclude the global filters (8) per port   */
static void cli_cmd_qos_global_filter_enable(cli_req_t *req)
{
    int                   a, port_no;
    BOOL                  first=1;
    vtss_port_qos_setup_t qos;
    char                  buf[80], *p;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
    
        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {
            if (req->table_index != 0) {
                qos.custom_filter.global_enable[req->table_index-1] = req->enable;
            } else {            
                for(a=0; a<VTSS_CUSTOM_FILTER_COUNT; a++) 
                    qos.custom_filter.global_enable[a] = req->enable;                
            }
            
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            if (first) {        
                first = 0;
                printf("                          Port membership status for global filter\n");
                p = buf;
                p +=sprintf(p, "Port  ");
                for(a=0; a<VTSS_CUSTOM_FILTER_COUNT; a++)
                    p += sprintf(p, "%-10d", a + 1);
                cli_table_header(buf);
            }
            
            printf("%-6d",port_no);
            for(a=0; a<VTSS_CUSTOM_FILTER_COUNT; a++) 
                printf("%s  ",cli_bool_txt(qos.custom_filter.global_enable[a]));
            printf("\n");
        }        
    }
}

/* 1 local Filter for port  */
static void cli_cmd_qos_filter(cli_req_t *req, BOOL trig)
{
    int                   i, port_no;
    vtss_port_qos_setup_t qos;
    char                  pos[3];
    BOOL                  first=1;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
        
    
        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }

        if (req->set) {
            if (trig) {                           
                if (req->offset%2) {
                    printf("The offset must be in even bytes\n");
                    return;
                }                
                qos.custom_filter.local.filter[req->trig_index].header = req->layer;
                qos.custom_filter.local.filter[req->trig_index].offset = req->offset/2;
                qos.custom_filter.local.filter[req->trig_index].val = req->pattern;
                qos.custom_filter.local.filter[req->trig_index].mask = req->mask;
            } else {
                qos.custom_filter.local.forward = req->forward;
                qos.custom_filter.local.qos.prio = req->class;
                qos.custom_filter.local.qos.red = req->red;
            }
            
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
            
        } else {
            if (trig) {                                     
                printf("Port no: %d\n",port_no);                
                printf("-----------\n");
                printf("Trig-id  Pos      Offset   Pattern  Mask   Drop/Fwd Class    Red\n");
                
                for(i=0; i<7; i++) {
                    if (qos.custom_filter.local.filter[i].header == VTSS_HEADER_L2) {
                        strcpy(pos,"L2");
                    } else if (qos.custom_filter.local.filter[i].header == VTSS_HEADER_L3) {
                        strcpy(pos,"L3");
                    } else if (qos.custom_filter.local.filter[i].header == VTSS_HEADER_L4) {
                        strcpy(pos,"L4");
                    } else {
                        strcpy(pos,"-");
                    }
                    printf("%-8d %-8s %-8d %#-8x %#-8x",i,
                           pos,
                           qos.custom_filter.local.filter[i].offset*2,
                           qos.custom_filter.local.filter[i].val,
                           qos.custom_filter.local.filter[i].mask);
                    
                    if (i==0) {
                        printf("%-8s", qos.custom_filter.local.forward?"Forward":"Drop");
                        if (qos.custom_filter.local.forward) {
                            printf(" %-8d %-8d\n", qos.custom_filter.local.qos.prio,
                                   qos.custom_filter.local.qos.red); 
                        } else {
                            printf("%-8s %-8s\n","-","-"); 
                        }
                    } else {
                        printf("\n");                        
                    }                        
                }                
            } else {
                if (first) {        
                    printf("Port   Drop/Fwd Class    Red\n");
                    first = 0;
                }
                
                printf("%-8d %-8s %-8d %-8d\n",
                       port_no,
                       qos.custom_filter.local.forward?"Forward":"Drop",
                       qos.custom_filter.local.qos.prio,
                       qos.custom_filter.local.qos.red);                                                    
            }
        }
    }
}

/* Setup the global filters (8) */
static void cli_cmd_qos_global_filter(cli_req_t *req, BOOL trig)
{
    int a,i,table_index;
    vtss_qos_setup_t qos_glb;
    char             pos[3];
    
    if (vtss_qos_setup_get(&qos_glb) != VTSS_OK) {
        printf("Could not get QoS conf\n");
        return;
    }
    
    if (req->set) {
        if (trig) {                           
            if (req->offset%2) {
                printf("The offset must be in even bytes\n");
                return;
            }

            qos_glb.custom_filter[req->table_index-1].filter[req->trig_index].header = req->layer;
            qos_glb.custom_filter[req->table_index-1].filter[req->trig_index].offset = req->offset/2;
            qos_glb.custom_filter[req->table_index-1].filter[req->trig_index].val = req->pattern;
            qos_glb.custom_filter[req->table_index-1].filter[req->trig_index].mask = req->mask;
        } else {
            qos_glb.custom_filter[req->table_index-1].forward = req->forward;
            qos_glb.custom_filter[req->table_index-1].qos.prio = req->class;
            qos_glb.custom_filter[req->table_index-1].qos.red = req->red;
        }

        if (vtss_qos_setup_set(&qos_glb) != VTSS_OK) {
            printf("Could not set QoS conf\n");
            return;
        }
        
    } else {

        if (trig) {
            for(a=0; a<VTSS_CUSTOM_FILTER_COUNT; a++) {                
                if (req->table_index != 0)
                    table_index = req->table_index-1;
                else
                    table_index = a;
                                       
                printf("Table id: %d\n",table_index+1);
                printf("-----------\n");
                printf("Trig-id  Pos      Offset   Pattern  Mask   Drop/Fwd Class    Red\n");
                    
                for(i=0; i<7; i++) {
                    if (qos_glb.custom_filter[a].filter[i].header == VTSS_HEADER_L2) {
                        strcpy(pos,"L2");
                    } else if (qos_glb.custom_filter[table_index].filter[i].header == VTSS_HEADER_L3) {
                        strcpy(pos,"L3");
                    } else if (qos_glb.custom_filter[table_index].filter[i].header == VTSS_HEADER_L4) {
                        strcpy(pos,"L4");
                    } else {
                        strcpy(pos,"-");
                    }
                    printf("%-8d %-8s %-8d %#-8x %#-8x",i,
                           pos,
                           qos_glb.custom_filter[table_index].filter[i].offset*2,
                           qos_glb.custom_filter[table_index].filter[i].val,
                           qos_glb.custom_filter[table_index].filter[i].mask);
                    
                    if (i==0) {
                        printf("%-8s",qos_glb.custom_filter[table_index].forward?"Forward":"Drop");
                        if (qos_glb.custom_filter[table_index].forward) {
                            printf(" %-8d %-8d\n", qos_glb.custom_filter[table_index].qos.prio,
                                                   qos_glb.custom_filter[table_index].qos.red); 
                        } else {
                            printf("%-8s %-8s\n","-","-"); 
                        }
                    } else {
                        printf("\n");                        
                    }                        
                }

                if (req->table_index != 0)
                    break;
            }
        } else {
            printf("Table-id   Drop/Fwd Class    Red\n");
            for(a=0; a<VTSS_CUSTOM_FILTER_COUNT; a++) {                
                if (req->table_index != 0)
                    table_index = req->table_index-1;
                else
                    table_index = a;                   
                   
                printf("%-11d %-8s %-8d %-8d\n",                               
                       table_index+1,
                       qos_glb.custom_filter[table_index].forward?"Fwd":"Drop",
                       qos_glb.custom_filter[table_index].qos.prio,
                       qos_glb.custom_filter[table_index].qos.red);                    

                if (req->table_index != 0)
                    break;
            }
        }
    }
}

/* The primary order where the endpoints are ranked and included/excluded */
static void cli_cmd_qos_priorder(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    BOOL                  first = 1;
    int                   i, port_no;


    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
    
        if (req->set) {
            qos.order[req->order] = req->endpoint;                        
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }            
        } else {
            if (first) {
                printf("Endpoint:   0  1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16\n");
                first = 0;
            }
            printf("%-10d",port_no);                            
            for (i = 0; i < VTSS_QOS_ORDER_COUNT; i++) 
                printf("  %d",qos.order[i]);    
            
            printf("\n");                
        }
    }
}

/* Setup VLAN tag releated functions */
static void cli_cmd_qos_tag(cli_req_t *req)
{
    int port_no;
    BOOL first=1;
    vtss_port_qos_setup_t qos;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {

        if (req->port_list[port_no] == 0)
            continue;
        
        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
    
        if (req->set) {
            if (req->cfi) {
                qos.ctag_cfi_stop = req->enable;
            } else if (req->ctag) {
                qos.ctag_stop = req->enable;
            } else if (req->vlan_aware) {
                qos.vlan_aware = req->enable;
            } else if (req->tag_inner) {
                qos.tag_inner = req->enable;
            } else {
                printf("No match\n");
            }

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {            
            if (first) {
                printf("Port       ctag        cfi      vlan_aware  tag_inner\n");
                first = 0;
            }
            printf("%-8d %-11s %-11s %-11s %-11s\n",
                   port_no, 
                   qos.ctag_stop?"Enabled":"Disabled", 
                   qos.ctag_cfi_stop?"Enabled":"Disabled", 
                   qos.vlan_aware?"Enabled":"Disabled", 
                   qos.tag_inner?"Enabled":"Disabled");
        }
    }
}

/* The alternate order where the endpoints are ranked and included/excluded */
static void cli_cmd_qos_l2_filter_altorder(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    BOOL                  first = 1;
    int                   i, port_no;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
   
        if (req->set) {           
            qos.dmac_vid_etype.order[req->order] = req->endpoint;
                        
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }            
        } else {
            if (first) {
                printf("Endpoint:   0  1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16\n");
                first = 0;
            }            
            printf("%-10d",port_no);                
            for (i = 0; i < VTSS_QOS_ORDER_COUNT; i++)
                printf("  %d",qos.dmac_vid_etype.order[i]);

            printf("\n");                
        }
    }
}

static void cli_cmd_qos_l2_filter_dmac(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   i, port_no, table_id;
    char                  buf1[32];
    char                  buf2[32];

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }

  
        if (req->set) {           
            for (i=0; i<6; i++) {
                qos.dmac_vid_etype.filter[req->table_id-1].dmac.value[i] = req->dmac[i];
                qos.dmac_vid_etype.filter[req->table_id-1].dmac.mask[i] = req->dmac_mask[i];
            }
                        
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }            
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");
            printf("%-10s %-8s\n","Table","Dmac/Mask");

            for (table_id=0; table_id < 2; table_id++) {                
                printf("%-8d%s\n%25s\n",table_id+1, 
                       misc_mac_txt(qos.dmac_vid_etype.filter[table_id].dmac.value, buf1),
                       misc_mac_txt(qos.dmac_vid_etype.filter[table_id].dmac.mask, buf2));
            }
        }
    }
}


static void cli_cmd_qos_l2_filter_etype(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no, table_id;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
   
        if (req->set) {           
            qos.dmac_vid_etype.filter[req->table_id-1].etype.value = req->etype;
            qos.dmac_vid_etype.filter[req->table_id-1].etype.mask = req->mask;
                        
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }            
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");
            printf("%-8s %-8s\n","Table","Etype/Mask");

            for (table_id=0; table_id < 2; table_id++) {                
                printf("%-8d%#8x\n%#16x\n",table_id+1, 
                       qos.dmac_vid_etype.filter[table_id].etype.value,
                       qos.dmac_vid_etype.filter[table_id].etype.mask);
            }
        }
    }
}

static void cli_cmd_qos_l2_filter_vid(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no, table_id;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
   
        if (req->set) {           
            qos.dmac_vid_etype.filter[req->table_id-1].vid.value = req->vlan;
            qos.dmac_vid_etype.filter[req->table_id-1].vid.mask = req->mask;
                        
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }            
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");
            printf("%-8s %-8s\n","Table","VID/Mask");

            for (table_id=0; table_id < 2; table_id++) {                
                printf("%-8d%8d\n%#16x\n",table_id+1, 
                       qos.dmac_vid_etype.filter[table_id].vid.value,
                       qos.dmac_vid_etype.filter[table_id].vid.mask);
            }
        }
    }
}
static void cli_cmd_qos_l2_filter_port(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no, table_id;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
   
        if (req->set) {
            qos.dmac_vid_etype.filter[req->table_id-1].enable = req->enable;
            qos.dmac_vid_etype.order_enable = req->alt;                
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }            
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");
            printf("%-10s %-10s %-10s\n","Table","Enabled","Class table");

            for (table_id=0; table_id < 2; table_id++) {
                       printf("%-10d %-10s %10s\n",table_id+1, 
                       qos.dmac_vid_etype.filter[table_id].enable?"Yes":"No",
                       qos.dmac_vid_etype.order_enable?"Alternate":"Primary");
            }
        }
    }
}

static void cli_cmd_qos_l2_filter_conf(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no, table_id;
    char                  buf1[32];
    char                  buf2[32];


    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        printf("Port: %d\n",port_no);
        printf("--------\n");
        printf("%-5s %-8s %-10s %-36s %-10s %-10s\n",
               "Table","Enabled","Table","             Dmac/Mask","Etype/Mask","  Vid/Mask");
        
        for (table_id=0; table_id < 2; table_id++) {
            printf("%-5d %-8s %-10s %-17s/%-17s %#6x/%#-6x %4d/%#-6x\n",table_id+1, 
                   qos.dmac_vid_etype.filter[table_id].enable?"  Yes":"  No",
                   qos.dmac_vid_etype.order_enable?"Alternate":"Primary",
                   misc_mac_txt(qos.dmac_vid_etype.filter[table_id].dmac.value, buf1),
                   misc_mac_txt(qos.dmac_vid_etype.filter[table_id].dmac.mask, buf2),
                   qos.dmac_vid_etype.filter[table_id].etype.value,
                   qos.dmac_vid_etype.filter[table_id].etype.mask,
                   qos.dmac_vid_etype.filter[table_id].vid.value,
                   qos.dmac_vid_etype.filter[table_id].vid.mask);
        }
    }
}



/* Setup priority and red profiles for endpoints     */
static void cli_cmd_qos_class_misc(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    BOOL                  first = 1;
    char                  buf[200];
    int                   port_no;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
    
        if (req->set) {
            if (req->def) {
                qos.default_qos.prio = req->class;
                qos.default_qos.red = req->red;
            } else if (req->l2_ctrl) {
                qos.l2_control_qos.prio = req->class;
                qos.l2_control_qos.red = req->red;
            } else if (req->l3_ctrl) {
                qos.l3_control_qos.prio = req->class;
                qos.l3_control_qos.red = req->red;
            } else if (req->cfi) {
                qos.cfi_qos.prio = req->class;
                qos.cfi_qos.red = req->red;
            } else if (req->ipv4) {
                qos.ipv4_arp_qos.prio = req->class;
                qos.ipv4_arp_qos.red = req->red;
            } else if (req->ipv6) {
                qos.ipv6_qos.prio = req->class;
                qos.ipv6_qos.red = req->red;
            } else if (req->llc) {
                qos.llc_qos.prio = req->class;
                qos.llc_qos.red = req->red;
            } else {
                printf("No endpoint selected\n");
                return;
            }
                                
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
            
        } else {
            memset(&buf, 0, sizeof(buf));

            if (first) {
                printf("                 Class | Red              \n");
                printf("Port    Def   L2    L3    CFI   IPv4  IPv6  LLC\n");
                first = 0;
            }
            printf("%-8d", port_no);
            printf("%d|%-4d",qos.default_qos.prio, qos.default_qos.red);
            printf("%d|%-4d",qos.l2_control_qos.prio, qos.l2_control_qos.red);
            printf("%d|%-4d",qos.l3_control_qos.prio, qos.l3_control_qos.red);
            printf("%d|%-4d",qos.cfi_qos.prio, qos.cfi_qos.red);
            printf("%d|%-4d",qos.ipv4_arp_qos.prio, qos.ipv4_arp_qos.red);
            printf("%d|%-4d",qos.ipv6_qos.prio, qos.ipv6_qos.red);
            printf("%d|%-4d",qos.llc_qos.prio, qos.llc_qos.red);
            printf("\n");                
        }
    }
}

/* Setup range/specific and classification   */
static void cli_cmd_qos_class_tcpudp(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no,i;
    BOOL                  first = 1;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
    
        if (req->set) {
            qos.udp_tcp.local.pair[req->table_id-1].port = req->tcp_udp_port;
            qos.udp_tcp.local.range = req->range;         
            if (req->range) {
                qos.udp_tcp.local.pair[0].qos.prio = req->class;
                qos.udp_tcp.local.pair[0].qos.red = req->red;            
                qos.udp_tcp.local.pair[1].qos.prio = req->class;
                qos.udp_tcp.local.pair[1].qos.red = req->red;            
            } else {
                qos.udp_tcp.local.pair[req->table_id-1].qos.prio = req->class;
                qos.udp_tcp.local.pair[req->table_id-1].qos.red = req->red;            
            }

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");
            if (first) {
                printf("%-8s %-14s %-8s %-8s %-8s\n","Index","Range|Specific","IP-port","Class","Red");
                first = 0;
            }
            for (i = 0; i<2; i++) {
                printf("%-8d %-14s %#-8x %-8d %-8d\n",i+1,
                                            qos.udp_tcp.local.range?"Range":"Specific",
                                            qos.udp_tcp.local.pair[i].port,
                                            qos.udp_tcp.local.pair[i].qos.prio,
                                            qos.udp_tcp.local.pair[i].qos.red);
            }       
        }
    }
}

/* Setup priority and red profile IP protocol    */
static void cli_cmd_qos_class_ipproto(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no;
    BOOL                  first = 1;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
    
        if (req->set) {
            qos.ip_proto.proto = req->ip_proto;
            qos.ip_proto.qos.prio = req->class;
            qos.ip_proto.qos.red = req->red;

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
      
            if (first) {
                printf("%-8s %-10s %-8s %-8s\n","Port","IP-proto","Class","Red");
                first = 0;
            }
            printf("%-8d %-10d %-8d %-8d\n",port_no,
                   qos.ip_proto.proto,
                   qos.ip_proto.qos.prio,
                   qos.ip_proto.qos.red);       
        }
    }
}

/* Setup priority and red profile for Ethernet Type   */
static void cli_cmd_qos_class_etype(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no;
    BOOL                  first = 1;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
    
        if (req->set) {
            qos.etype.etype = req->etype;
            qos.etype.qos.prio = req->class;
            qos.etype.qos.red = req->red;

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
      
            if (first) {
                printf("%-8s %-10s %-8s %-8s\n","Port","Etype","Class","Red");
                first = 0;
            }
            printf("%-8d %#-10x %-8d %-8d\n",port_no,
                   qos.etype.etype,
                   qos.etype.qos.prio,
                   qos.etype.qos.red);       
        }
    }
}

/* Setup priority and red profile for VID   */
static void cli_cmd_qos_class_vid(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no,i;
    BOOL                  first = 1;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
    
        if (req->set) {
            qos.vlan[req->table_id-1].vid = req->vlan;
            qos.vlan[req->table_id-1].qos.prio = req->class;
            qos.vlan[req->table_id-1].qos.red = req->red;

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");
            if (first) {
                printf("%-8s %-8s %-8s %-8s\n","Index","VID","Class","Red");
                first = 0;
            }
            for (i = 0; i<2; i++) {
                printf("%-8d %-8d %-8d %-8d\n",i+1,qos.vlan[i].vid,
                                                   qos.vlan[i].qos.prio,
                                                   qos.vlan[i].qos.red);
            }
        }
    }
}

/* Setup priority and red profile for User Prio  */
static void cli_cmd_qos_class_tagprio(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no,i;
    BOOL                  first = 1;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
    
        if (req->set) {
            qos.vlan_tag_qos[req->tag_prio].prio = req->class;
            qos.vlan_tag_qos[req->tag_prio].red = req->red;

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");
            if (first) {
                printf("%-8s %-8s %-8s\n","Tag Prio","Class","Red");
                first = 0;
            }
            for (i = 0; i<8; i++) {
                printf("%-8d %-8d %-8d\n",i,
                       qos.vlan_tag_qos[i].prio,
                       qos.vlan_tag_qos[i].red);
            }
        }
    }
}

/* Setup priority and red profile for MPLS   */
static void cli_cmd_qos_class_mpls(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no,i;
    BOOL                  first = 1;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
        
        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {
            qos.mpls_exp_qos[req->mpls_exp].prio = req->class;
            qos.mpls_exp_qos[req->mpls_exp].red = req->red;
            
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");
            if (first) {
                printf("%-10s %-8s %-8s\n","MPLS exp","Class","Red");
                first = 0;
            }
            for (i = 0; i<8; i++) {
                printf("%-10d %-8d %-8d\n",i,
                       qos.mpls_exp_qos[i].prio,
                       qos.mpls_exp_qos[i].red);
            }
        }
    }
}

/* Setup the port policer   */
static void cli_cmd_qos_port_police(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no,i;
    BOOL                  first = 1;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
        
        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {
            if (req->rate == 0) {
                qos.policer_port[req->table_id-1].broadcast = 0;
                qos.policer_port[req->table_id-1].multicast = 0;
                qos.policer_port[req->table_id-1].unicast = 0;
                qos.policer_port[req->table_id-1].rate = VTSS_BITRATE_FEATURE_DISABLED;
                qos.policer_port[req->table_id-1].level = 0;
            } else {
                if (req->policer.unicast)
                    qos.policer_port[req->table_id-1].unicast = 1;
                if (req->policer.multicast)
                    qos.policer_port[req->table_id-1].multicast = 1;
                if (req->policer.broadcast)
                    qos.policer_port[req->table_id-1].broadcast = 1;
                
                qos.policer_port[req->table_id-1].level = req->policer.level;
                qos.policer_port[req->table_id-1].rate = req->rate;
            }

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");
            if (first) {
                printf("%-10s %-10s %-10s %-10s %-10s %-10s\n","Policer-id","  UC","  BC","  MC","Rate/Kb","Level/KB");
                first = 0;
            }
            for (i = 0; i<2; i++) {
                if (qos.policer_port[i].rate == VTSS_BITRATE_FEATURE_DISABLED) {
                    printf("%-10d %-10s %-10s %-10s %-10s %-10s\n",i+1,"  -","  -","  -","-","-"); 
                } else {
                    printf("%-10d %-10s %-10s %-10s %-10lu %-10lu\n",i+1,
                           qos.policer_port[i].unicast?"Enabled":"Disabled",
                           qos.policer_port[i].broadcast?"Enabled":"Disabled",
                           qos.policer_port[i].multicast?"Enabled":"Disabled",
                           qos.policer_port[i].rate,
                           qos.policer_port[i].level/1024);
                }
            }
        }
    }
}


/* Setup the queue policers   */
static void cli_cmd_qos_queue_police(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no,i;
    BOOL                  first = 1;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
        
        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {
            if (req->rate == 0) {
                qos.policer_queue[req->table_index].broadcast = 0;
                qos.policer_queue[req->table_index].multicast = 0;
                qos.policer_queue[req->table_index].unicast = 0;
                qos.policer_queue[req->table_index].rate = VTSS_BITRATE_FEATURE_DISABLED;
                qos.policer_queue[req->table_index].level = 0;
            } else {
                if (req->policer.unicast)
                    qos.policer_queue[req->table_index].unicast = 1;
                if (req->policer.multicast)
                    qos.policer_queue[req->table_index].multicast = 1;
                if (req->policer.broadcast)
                    qos.policer_queue[req->table_index].broadcast = 1;
                
                qos.policer_queue[req->table_index].level = req->policer.level;
                qos.policer_queue[req->table_index].rate = req->rate;
            }
            
            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");
            if (first) {
                printf("%-10s %-10s %-10s %-10s %-10s %-10s\n","Queue","  UC","  BC","  MC","Rate/Kb","Level/KB");
                first = 0;
            }
            for (i = VTSS_QUEUE_START; i<VTSS_QUEUE_END; i++) {
                if (qos.policer_queue[i].rate == VTSS_BITRATE_FEATURE_DISABLED) {
                    printf("%-10d %-10s %-10s %-10s %-10s %-10s\n",i,"  -","  -","  -","-","-"); 
                } else {
                    printf("%-10d %-10s %-10s %-10s %-10lu %-10lu\n",i,
                           qos.policer_queue[i].unicast?"Enabled":"Disabled",
                           qos.policer_queue[i].broadcast?"Enabled":"Disabled",
                           qos.policer_queue[i].multicast?"Enabled":"Disabled",
                           qos.policer_queue[i].rate,
                           qos.policer_queue[i].level/1024);
                }
            }
        }
    }
}

/* Setup the port shapers   */
static void cli_cmd_qos_port_shaper(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no;
    BOOL                  first = 1;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
        
        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {
            if (req->rate == 0) {
                qos.shaper_port.level = 0;
                qos.shaper_port.rate = VTSS_BITRATE_FEATURE_DISABLED;
            } else {
                qos.shaper_port.level = req->policer.level;
                qos.shaper_port.rate = req->rate;
            }

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            if (first) {
                printf("%-10s %-10s %-10s\n","Port","Rate/Kb","Level/KB");
                first = 0;
            }
            if (qos.shaper_port.rate == VTSS_BITRATE_FEATURE_DISABLED) {
                printf("%-10d %-10s %-10s\n",port_no,"-","-");
            } else {
                printf("%-10d %-10lu %-10lu\n",port_no,
                       qos.shaper_port.rate,
                       qos.shaper_port.level/1024);            
            }
        }
    }
}

/* Setup the RED threshold and weight  */
static void cli_cmd_qos_red_threshold(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no,q;
    BOOL                  first = 1;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
        
        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {
            qos.red[req->table_index].min = req->red_min;
            qos.red[req->table_index].max = req->red_max;
            qos.red[req->table_index].weight = req->red_weight;

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");

            if (first) {
                printf("%-10s %-10s %-10s %-10s\n","Queue","Min","Max","Weight");
                first = 0;
            }

            for (q = VTSS_QUEUE_START; q<VTSS_QUEUE_END; q++) {
                printf("%-10d %-10d %-10d %-10d\n",q,
                       qos.red[q].min, qos.red[q].max, qos.red[q].weight);
            }            
        }
    }
}

/* Setup the RED probability profiles  */
static void cli_cmd_qos_red_probability(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no,q;
    BOOL                  first = 1;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
        
        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {
            qos.red[req->table_index].max_prob_1 = req->red_prob1;
            qos.red[req->table_index].max_prob_2 = req->red_prob2;
            qos.red[req->table_index].max_prob_3 = req->red_prob3;

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");

            if (first) {
                printf("%-10s %-10s %-10s %-10s\n","Queue","Prob_1 %","Prob_2 %","Prob_3 %");
                first = 0;
            }

            for (q = VTSS_QUEUE_START; q<VTSS_QUEUE_END; q++) {
                printf("%-10d %-10d %-10d %-10d\n",q,
                       qos.red[q].max_prob_1, qos.red[q].max_prob_2, qos.red[q].max_prob_3);
            }            
        }
    }
}

/* Enable / Disable the Red profile */
static void cli_cmd_qos_red_profile(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no,q;
    BOOL                  first = 1;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
        
        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {
            qos.red[req->table_index].enable = req->enable;

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");

            if (first) {
                printf("%-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s\n",
                       "Queue","Enabled","Min","Max","Weight","Prob_1 %","Prob_2 %","Prob_3 %");
                first = 0;
            }

            for (q = VTSS_QUEUE_START; q<VTSS_QUEUE_END; q++) {
                printf("%-10d %-10s %-10d %-10d %-10d %-10d %-10d %-10d\n",q,
                       qos.red[q].enable?"Yes":"No", 
                       qos.red[q].min, 
                       qos.red[q].max, 
                       qos.red[q].weight, 
                       qos.red[q].max_prob_1, 
                       qos.red[q].max_prob_2, 
                       qos.red[q].max_prob_3);
            }
        }
    }
}

/* Setup the queue (1-6) scheduler (weight) */
static void cli_cmd_qos_queue_schedule(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no,q;
    BOOL                  first = 1;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
        
        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {
            if (req->table_index > 6) {
                printf("Illegal queue no %lu  (1-6) \n",req->table_index);
                return;                    
            }
            qos.scheduler.queue_pct[req->table_index] = req->value;

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            printf("Port: %d\n",port_no);
            printf("--------\n");

            if (first) {
                printf("%-10s %-10s\n","Queue","Pct");
                first = 0;
            }

            for (q = VTSS_QUEUE_START; q<VTSS_QUEUE_END-2; q++) {
                printf("%-10d %-10d\n",q,qos.scheduler.queue_pct[q]);

            }
        }
    }
}

/* Setup the port scheduler (weight) */
static void cli_cmd_qos_port_schedule(cli_req_t *req)
{
    vtss_port_qos_setup_t qos;
    int                   port_no;
    BOOL                  first = 1;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
        
        if (vtss_port_qos_get(port_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {
            if (req->rate == 0)
                qos.scheduler.rate = VTSS_BITRATE_FEATURE_DISABLED;
            else
                qos.scheduler.rate = req->rate;

            if (vtss_port_qos_set(port_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            if (first) {
                printf("%-10s %-10s\n","Port","Min-Rate/Kb");
                first = 0;
            }
            if (qos.scheduler.rate == VTSS_BITRATE_FEATURE_DISABLED)
                printf("%-10d %-10s\n",port_no,"Disabled");                            
            else
                printf("%-10d %-10lu\n",port_no, qos.scheduler.rate);       
        }
    }
}

/* Setup the logical port scheduler (weight) */
/* Tx:ports 1-48:   Spi4 transmit               */
/* Rx ports 1-24:   XAUI 1 transmit */
/* Rx ports 24-48:  XAUI 2 transmit */
static void cli_cmd_qos_lport_schedule(cli_req_t *req)
{
    vtss_lport_qos_setup_t qos;
    int                    lport_no;
    char                   txbuf[20],rxbuf[20];
    BOOL                   first = 1;
    
    for (lport_no = 0; lport_no < VTSS_LPORTS; lport_no++) {
        if (req->lport_list[lport_no] == 0)
            continue;
        
        if (vtss_lport_qos_get(lport_no, &qos) != VTSS_OK) {
            printf("Could not get QoS conf\n");
            return;
        }
        
        if (req->set) {
            if (req->transmit) 
                qos.scheduler.tx_rate = req->rate;
            else 
                qos.scheduler.rx_rate = req->rate;
            

            if (vtss_lport_qos_set(lport_no, &qos) != VTSS_OK) {
                printf("Could not set QoS conf\n");
                return;
            }
        } else {
            if (first) {
                printf("%-10s %-10s %-10s\n","Lport","Rx Rate","Tx Rate");
                first = 0;
            }           
            if (qos.scheduler.rx_rate != VTSS_BITRATE_FEATURE_DISABLED)
                sprintf(rxbuf,"%lu",qos.scheduler.rx_rate);
            else 
                sprintf(rxbuf,"%s","-");


            if (qos.scheduler.tx_rate != VTSS_BITRATE_FEATURE_DISABLED)
                sprintf(txbuf,"%lu",qos.scheduler.tx_rate);
            else 
                sprintf(txbuf,"%s","-");


            printf("%-10d %-10s %-10s\n",lport_no, rxbuf, txbuf);
        }
    }
}


/* Port filter */
static void cli_cmd_port_filter(cli_req_t *req)
{
    vtss_port_no_t          port_no;
    vtss_port_filter_t      filter;
    BOOL                    first = 1;
    char                    tags[5];

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        if (vtss_port_filter_get(port_no, &filter) != VTSS_OK) {
            printf("Could not get filter\n");
            return;
        }
        
        if (req->set) {
            if (req->filter.mac_ctrl_enable)
                filter.mac_ctrl_enable = req->allow;
            else if (req->filter.mac_zero_enable)
                filter.mac_zero_enable = req->allow;
            else if (req->filter.dmac_bc_enable)
                filter.dmac_bc_enable = req->allow;
            else if (req->filter.smac_mc_enable)
                filter.smac_mc_enable = req->allow;
            else if (req->filter.untag_enable)
                filter.untag_enable = req->allow;
            else if (req->filter.prio_tag_enable)
                filter.prio_tag_enable = req->allow;
            else if (req->filter.ctag_enable)
                filter.ctag_enable = req->allow;
            else if (req->filter.stag_enable)
                filter.stag_enable = req->allow;
            else if (req->max_tags) 
                filter.max_tags = req->filter.max_tags;
         
            if (vtss_port_filter_set(port_no, &filter) != VTSS_OK) {
                printf("Could not set filter\n");
            }
        } else {
            if (first) {
                printf("Port mac_ctrl mac_zero dmac_bc smac_mc untag  prio_tag  c_tag  s_tag   tags\n");
                first = 0;
            }
            if (filter.max_tags == VTSS_TAG_ONE) {
                strcpy(tags,"1");
            } else if (filter.max_tags == VTSS_TAG_TWO) {
                strcpy(tags,"2");
            } else {
                strcpy(tags,"Any");
            }
            printf("%-8d", port_no);
            printf("%-8s",filter.mac_ctrl_enable?"Allow":"Deny");
            printf("%-8s",filter.mac_zero_enable?"Allow":"Deny");
            printf("%-8s",filter.dmac_bc_enable?"Allow":"Deny");
            printf("%-8s",filter.smac_mc_enable?"Allow":"Deny");
            printf("%-8s",filter.untag_enable?"Allow":"Deny");
            printf("%-8s",filter.prio_tag_enable?"Allow":"Deny");
            printf("%-8s",filter.ctag_enable?"Allow":"Deny");
            printf("%-8s",filter.stag_enable?"Allow":"Deny");
            printf("%-8s",tags);
            printf("\n");

        }
    }
}

static void cli_cmd_port_forward(cli_req_t *req)
{
    vtss_port_no_t      port_no;
    vtss_port_forward_t fwd;
    int                 first = 1;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
        if (req->set) {
            fwd = (req->enable ? VTSS_PORT_FORWARD_ENABLED :
                   req->disable ? VTSS_PORT_FORWARD_DISABLED :
                   req->ingress ? VTSS_PORT_FORWARD_INGRESS :
                   VTSS_PORT_FORWARD_EGRESS);
            vtss_port_forward_state_set(port_no, fwd);
            cli_state.port_forward[port_no] = fwd;
        } else {
            if (first) {
                cli_table_header("Port  Forwarding");
                first = 0;
            }
            fwd = cli_state.port_forward[port_no];
            printf("%-4u  %s\n", port_no, 
                   fwd == VTSS_PORT_FORWARD_ENABLED ? "Enabled" :
                   fwd == VTSS_PORT_FORWARD_DISABLED ? "Disabled" :
                   fwd == VTSS_PORT_FORWARD_INGRESS ? "Ingress" : "Egress");
        }
    }
}
#endif /* VTSS_ARCH_B2 */

static void cli_cmd_system_conf(cli_req_t *req)
{
    printf("Software Version: %s\n", vtss_version_string);
    printf("Software Date   : %s\n", vtss_compile_time);
}

/* Debug register read/write */
static void cli_cmd_debug_reg(cli_req_t *req, BOOL write)
{
    int         i, j, blk, addr, addr_count = 0, first = 1;
#if defined(VTSS_ARCH_HEATHROW)
    int         sub, sub_count = 0 ;
#endif /* VTSS_ARCH_HEATHROW */
    ulong       reg, value;
    
    for (i = 0; i < (write ? 1 : 2); i++) {
        for (blk = 0; blk < CLI_BLK_MAX; blk++) {
            if (req->blk_list[blk] == 0)
                continue;
            
#if defined(VTSS_ARCH_HEATHROW)
            for (sub = 0; sub < CLI_SUB_MAX; sub++) {
                if (req->sub_list[sub] == 0)
                    continue;
                
                if (i == 0)
                    sub_count++;
#endif /* VTSS_ARCH_HEATHROW */
                
                for (addr = 0; addr < CLI_ADDR_MAX; addr++) {
                    if (req->addr_list[addr] == 0)
                        continue;
#if defined(VTSS_ARCH_HEATHROW)
                    reg = ((blk << 12) | (sub << 8) | addr);
#else
                    reg = ((blk << 16) | addr);
#endif /* VTSS_ARCH_HEATHROW */
                    
                    if (write) {
                        /* Write */
                        vtss_register_write(reg, req->value);
                    } else if (i == 0) {
#if defined(VTSS_ARCH_HEATHROW)
                        /* Count number of addresses to read */
                        if (sub_count == 1)
#endif /* VTSS_ARCH_HEATHROW */
                            addr_count++;
                    } else {
                        /* Read */
                        vtss_register_read(reg, &value);
                        if (first && req->binary) {
#if defined(VTSS_ARCH_HEATHROW)
                            if (sub_count > 1)
                                printf("%-20s","");
                            if (sub_count > 1 || addr_count > 1)
                                printf("%-6s","");
#else
                            if (addr_count > 1)
                                printf("%-23s","");
#endif /* VTSS_ARCH_HEATHROW */
                            printf("31     24 23     16 15      8 7       0\n");
                            first = 0;
                        }
#if defined(VTSS_ARCH_HEATHROW)
                        if (sub_count > 1)
                            printf("Blk %d, Sub %2d, Addr ", blk, sub);
                        if (sub_count > 1 || addr_count > 1)
                            printf("0x%02x: ", addr);
#else
                        if (addr_count > 1)
                            printf("Tgt 0x%02x, Addr 0x%04x: ", blk, addr);
#endif /* VTSS_ARCH_HEATHROW */
                        if (req->binary)
                            for (j = 31; j >= 0; j--)
                                printf("%d%s", 
                                       value & (1<<j) ? 1 : 0, (j % 4) || j==0 ? "" : ".");
                        else if (req->decimal)
                            printf("%10lu", value);
                        else 
                            printf("0x%08lx", value);
                        printf("\n");
                    }
                } /* addr loop */
#if defined(VTSS_ARCH_HEATHROW)
            } /* sub loop */
#endif /* VTSS_ARCH_HEATHROW */
        } /* blk loop */
    }
}

/* Debug PHY read/write */
static void cli_cmd_debug_phy(cli_req_t *req, BOOL write)
{
    vtss_port_no_t port_no;
    int            i, j, addr, port_count = 0, addr_count = 0, first = 1;
    uint           reg;
    ushort         value;
    
    for (i = 0; i < (write ? 1 : 2); i++) {
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (req->port_list[port_no] == 0)
                continue;

            if (i == 0)
                port_count++;

            for (addr = 0; addr < CLI_PHY_MAX; addr++) {
                if (req->addr_list[addr] == 0)
                    continue;
                
                reg = ((req->page << 5) | addr);
                if (write) {
                    /* Write */
                    vtss_phy_write(port_no, reg, req->value);
                } else if (i == 0) {
                    /* Count number of addresses to read */
                    if (port_count == 1)
                        addr_count++;
                } else {
                    /* Read */
                    vtss_phy_read(port_no, reg, &value);
                    if (first && req->binary) {
                        if (port_count > 1)
                            printf("%-14s","");
                        if (port_count > 1 || addr_count > 1)
                            printf("%-6s","");
                        printf("15      8 7       0\n");
                        first = 0;
                    }

                    if (port_count > 1)
                        printf("Port %2d, Addr ", port_no);
                    if (port_count > 1 || addr_count > 1)
                        printf("0x%02x: ", addr);
                    if (req->binary)
                        for (j = 15; j >= 0; j--)
                            printf("%d%s", 
                                    value & (1<<j) ? 1 : 0, (j % 4) || j==0 ? "" : ".");
                    else if (req->decimal)
                        printf("%6d", value);
                    else 
                        printf("0x%04x", value);
                    printf("\n");
                }
            }
        }
    }
} 

#if defined(VTSS_ARCH_B2)
/* MMD (MDIO Management Devices) read/write */
static void cli_cmd_debug_mmd(cli_req_t *req, BOOL write)
{
    vtss_port_no_t port_no;
    int            i, j, mmd, port_count = 0, addr_count = 0, first = 1;
    ushort         value;

    
    for (i = 0; i < (write ? 1 : 2); i++) {
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (req->port_list[port_no] == 0)
                continue;

            if (i == 0)
                port_count++;

            for (mmd = 0; mmd < CLI_PHY_MAX; mmd++) {
                if (req->mmd_list[mmd] == 0)
                    continue;
                
                if (write) {
                    /* Write */
                    vtss_mmd_write(port_no, mmd, req->mmd_address, req->value);
                } else if (i == 0) {
                    /* Count number of addresses to read */
                    if (port_count == 1)
                        addr_count++;
                } else {

                   /* Read */
                    vtss_mmd_read(port_no, mmd, req->mmd_address, &value);
                    if (first && req->binary) {
                        if (port_count > 1)
                            printf("%-14s","");
                        if (port_count > 1 || addr_count > 1)
                            printf("%-6s","");
                        printf("15      8 7       0\n");
                        first = 0;
                    }

                    if (port_count > 1)
                        printf("Port %2d, Addr ", port_no);
                    if (port_count > 1 || addr_count > 1)
                        printf("0x%02x: ", mmd);
                    if (req->binary)
                        for (j = 15; j >= 0; j--)
                            printf("%d%s", 
                                    value & (1<<j) ? 1 : 0, (j % 4) || j==0 ? "" : ".");
                    else if (req->decimal)
                        printf("%6d", value);
                    else 
                        printf("0x%04x", value);
                    printf("\n");
                }
            }
        }
    }
} 

static const char *cli_rate_txt(vtss_bitrate_t rate, char *buf)
{
    if (rate == VTSS_BITRATE_FEATURE_DISABLED)
        return cli_bool_txt(0);
    sprintf(buf, "%lu kbps", rate);
    return buf;
}

static void cli_cmd_system_init(void)
{
    vtss_init_setup_t setup;
    vtss_qs_setup_t   *qs;
    vtss_spi4_setup_t *spi4;
    vtss_xaui_setup_t *xaui;
    char              buf[32];

    if (vtss_appl_init_setup_get(&setup) != VTSS_OK)
        return;

    cli_table_header("General");
    printf("Host Mode           : %u\n", setup.host_mode);
    printf("S-tag Ethernet Type : 0x%04x\n", setup.stag_etype); 
    qs = &setup.qs;
    printf("Rx Queue Share      : "); 
    if (qs->rx_share)
        printf("%u %%\n", qs->rx_share);
    else
        printf("Automatic\n");
    printf("Queue System MTU    : %u\n", qs->mtu);
    printf("Queue 6 Reserve     : %s\n", cli_bool_txt(qs->resv_q6));
    printf("Queue 7 Reserve     : %s\n", cli_bool_txt(qs->resv_q7));
    printf("Rx Queue Mode       : %s\n", 
           qs->rx_mode == VTSS_RX_MODE_SHARED_LOSSLESS ? "Shared Lossless" :
           qs->rx_mode == VTSS_RX_MODE_PORT_FIFO ? "Port FIFO" :
           qs->rx_mode == VTSS_RX_MODE_SHARED_DROP ? "Shared Drop" : "?");
    printf("Tx Queue Mode       : %s\n", 
           qs->tx_mode == VTSS_TX_MODE_SHARED_LOSSLESS ? "Shared Lossless" :
           qs->tx_mode == VTSS_TX_MODE_PORT_FIFO ? "Port FIFO" : "?");
    printf("Scheduler Max Rate  : %lu kbps\n\n", setup.sch_max_rate); 

    cli_table_header("SPI4");
    spi4 = &setup.spi4;
    printf("Flow Control        : %s\n", cli_bool_txt(spi4->fc.enable));
    printf("Three Level         : %s\n", cli_bool_txt(spi4->fc.three_level_enable));
    printf("Shaper              : %s\n", cli_rate_txt(spi4->qos.shaper.rate, buf));
    printf("IB FCS Mode         : %s\n", 
           spi4->ib.fcs == VTSS_SPI4_FCS_DISABLED ? cli_bool_txt(0) :
           spi4->ib.fcs == VTSS_SPI4_FCS_CHECK ? "Check" :
           spi4->ib.fcs == VTSS_SPI4_FCS_ADD ? "Add" : "?");
    printf("IB Clock Range      : %s MHz\n",
           spi4->ib.clock == VTSS_SPI4_CLOCK_250_TO_290 ? "250-290" :
           spi4->ib.clock == VTSS_SPI4_CLOCK_290_TO_360 ? "290-360" :
           spi4->ib.clock == VTSS_SPI4_CLOCK_360_TO_450 ? "360-450" :
           spi4->ib.clock == VTSS_SPI4_CLOCK_450_TO_500 ? "450-500" : "?");
    printf("IB Data Swap        : %s\n", cli_bool_txt(spi4->ib.data_swap));
    printf("IB Data Invert      : %s\n", cli_bool_txt(spi4->ib.data_invert));
    printf("IB Clock Shift      : %s\n", cli_bool_txt(spi4->ib.clock_shift));
    printf("OB Frame Interleave : %s\n", cli_bool_txt(spi4->ob.frame_interleave));
    printf("OB HIH              : %s\n", cli_bool_txt(spi4->ob.hih_enable));
    printf("OB Clock            : %s MHz\n", 
           spi4->ob.clock == VTSS_SPI4_CLOCK_250_0 ? "250.0" :
           spi4->ob.clock == VTSS_SPI4_CLOCK_312_5 ? "312.5" :
           spi4->ob.clock == VTSS_SPI4_CLOCK_375_0 ? "375.0" :
           spi4->ob.clock == VTSS_SPI4_CLOCK_437_5 ? "437.5" :
           spi4->ob.clock == VTSS_SPI4_CLOCK_500_0 ? "500.0" : "?");
    printf("OB Clock Phase      : %s Degrees\n",
           spi4->ob.clock_phase == VTSS_SPI4_CLOCK_PHASE_0 ? "0" :
           spi4->ob.clock_phase == VTSS_SPI4_CLOCK_PHASE_90 ? "90" :
           spi4->ob.clock_phase == VTSS_SPI4_CLOCK_PHASE_180 ? "180" :
           spi4->ob.clock_phase == VTSS_SPI4_CLOCK_PHASE_270 ? "270" : "?");
    printf("OB Data Swap        : %s\n", cli_bool_txt(spi4->ob.data_swap));
    printf("OB Data Invert      : %s\n", cli_bool_txt(spi4->ob.data_invert));
    printf("OB Clock Shift      : %s\n", cli_bool_txt(spi4->ob.clock_shift));
    printf("OB Burst Size       : %s Bytes\n",
           spi4->ob.burst_size == VTSS_SPI4_BURST_64 ? "64" :
           spi4->ob.burst_size == VTSS_SPI4_BURST_96 ? "96" :
           spi4->ob.burst_size == VTSS_SPI4_BURST_128 ? "128" :
           spi4->ob.burst_size == VTSS_SPI4_BURST_160 ? "160" :
           spi4->ob.burst_size == VTSS_SPI4_BURST_192 ? "192" :
           spi4->ob.burst_size == VTSS_SPI4_BURST_224 ? "224" :
           spi4->ob.burst_size == VTSS_SPI4_BURST_256 ? "256" : "?");
    printf("OB MaxBurst1        : %u x 16 Bytes\n", spi4->ob.max_burst_1);
    printf("OB MaxBurst2        : %u x 16 Bytes\n", spi4->ob.max_burst_2);
    printf("OB Link Up Limit    : %u\n", spi4->ob.link_up_limit);
    printf("OB Link Down Limit  : %u\n", spi4->ob.link_down_limit);
    printf("OB Training Mode    : %s\n",
           spi4->ob.training_mode == VTSS_SPI4_TRAINING_DISABLED ? cli_bool_txt(0) :
           spi4->ob.training_mode == VTSS_SPI4_TRAINING_AUTO ? "Auto" :
           spi4->ob.training_mode == VTSS_SPI4_TRAINING_FORCED ? "Forced" :
           spi4->ob.training_mode == VTSS_SPI4_TRAINING_NORMAL ? "Normal" : "?");
    printf("OB ALPHA Value      : %u\n", spi4->ob.alpha);
    printf("OB DATA_MAX_T Value : %u Cycles\n\n", spi4->ob.data_max_t);
    
    cli_table_header("XAUI");
    xaui = &setup.xaui;
    printf("Channel Flow Control: %s\n", cli_bool_txt(xaui->fc.channel_enable));
    printf("Three Level         : %s\n", cli_bool_txt(xaui->fc.three_level_enable));
    printf("Obey Pause          : %s\n", cli_bool_txt(xaui->fc.obey_pause));
    printf("Shaper              : %s\n", cli_rate_txt(xaui->qos.shaper.rate, buf));
    printf("HIH Format          : %s\n", 
           xaui->hih.format == VTSS_HIH_POST_SFD ? "After SFD" :
           xaui->hih.format == VTSS_HIH_PRE_SFD ? "Before SFD" : "?");
    printf("HIH Checksum        : %s\n", cli_bool_txt(xaui->hih.cksum_enable));
    printf("IB Clock Shift      : %s\n", cli_bool_txt(xaui->ib.clock_shift));
    printf("OB Clock Shift      : %s\n", cli_bool_txt(xaui->ob.clock_shift));
}
#endif /* VTSS_ARCH_B2 */

#if defined(BOARD_B2_EVAL)
/* FPGA status */
static void cli_cmd_debug_fpga_status(cli_req_t *req)
{
    
    long          val;
    int           j;
 
    /* Get interrupt status             */
    vtss_rabbit_rd_wr_fpga(0x14, &val, 1);
    printf("External Interrupt pin (INTR_N) status:%s\n",(val & (1<<2))?"Low":"High");

    /* Read GPIO In status  */
    vtss_rabbit_rd_wr_fpga(0x50, &val, 1);
    printf("External GPIO pins status:\n");
    printf("15      8 7       0\n");
    for (j = 15; j >= 0; j--) 
        printf("%d%s", val & (1<<j) ? 1 : 0, (j % 4) || j==0 ? "" : ".");    
    printf("\n");
    
} 
#endif /* BOARD_B2_EVAL */

#if defined(VTSS_GPIOS)
static void cli_cmd_debug_gpio(cli_req_t *req, cli_cmd_id_t cmd)
{
    vtss_gpio_no_t gpio;
    BOOL           first = 1, value;
    
    for (gpio = VTSS_GPIO_NO_START; gpio < VTSS_GPIO_NO_END; gpio++) {
        if (req->gpio_list[gpio] == 0)
            continue;
        if (cmd == CLI_CMD_ID_DEBUG_GPIO_OUTPUT)
            vtss_gpio_direction_set(gpio, req->set ? req->enable : 1);
        else if (cmd == CLI_CMD_ID_DEBUG_GPIO_WRITE)
            vtss_gpio_output_write(gpio, req->value);
        else if (vtss_gpio_input_read(gpio, &value) == VTSS_OK) {
            if (first)
                cli_table_header("GPIO  Value");
            first = 0;
            printf("%-4u  %u\n", gpio, value);
        }
    }
}
#endif /* VTSS_GPIOS */

#if defined(VTSS_FEATURE_INTERRUPTS)
static void cli_cmd_debug_interrupt(cli_req_t *req)
{
    vtss_intr_t    intr;
    vtss_port_no_t port_no;
    BOOL           first = 1;
    
    if (req->set) {
        /* Set interrupt mask */
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
            intr.link_change[port_no] = (req->port_list[port_no] && req->enable ? 1 : 0);
        vtss_intr_mask_set(&intr);
    } else {
        /* Get interrupt status */
        if (vtss_intr_status_get(&intr) == VTSS_OK) {
            for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
                if (req->port_list[port_no] == 0)
                    continue;
                if (first)
                    cli_table_header("Port  Status");
                first = 0;
                printf("%-4u  %shanged\n", port_no, intr.link_change[port_no] ? "C" : "Unc");
            } 
        } 
    }
}
#endif /* VTSS_FEATURE_INTERRUPTS */

#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
static void cli_cmd_debug_trace(cli_req_t *req, BOOL level, BOOL timestamp, BOOL usec)
{
    int  mid, gidx;
    char *module, *group;
    BOOL first;

    mid = req->trace_module_id;
    if (req->set) {
        /* Set parameter */
        if (level)
            vtss_trace_module_lvl_set(mid, req->trace_grp_idx, req->trace_lvl);
        if (timestamp)
            vtss_trace_module_parm_set(VTSS_TRACE_MODULE_PARM_TIMESTAMP,
                                       mid, req->trace_grp_idx, req->enable);
        if (usec)
            vtss_trace_module_parm_set(VTSS_TRACE_MODULE_PARM_USEC,
                                       mid, req->trace_grp_idx, req->enable);
        return;
    } 

    /* Show current values */
    cli_table_header("Module    Group     Level     Timestamp  Description");
    
    /* Modules */
    if (mid != TRACE_MODULE_ID_ALL)
        mid--;
    while ((module = vtss_trace_module_name_get_nxt(&mid))) {
        first = 1;
        
        /* Groups */
        gidx = req->trace_grp_idx;
        if (gidx != TRACE_GRP_IDX_ALL)
            gidx--;
        while ((group = vtss_trace_grp_name_get_nxt(mid, &gidx))) {
            printf("%-10s%-10s%-10s%-11s%s\n", 
                   first ? module : "",
                   group, 
                   vtss_trace_lvl_to_str(vtss_trace_module_lvl_get(mid, gidx)),
                   vtss_trace_grp_get_parm(VTSS_TRACE_MODULE_PARM_TIMESTAMP, mid, gidx) ? 
                   vtss_trace_grp_get_parm(VTSS_TRACE_MODULE_PARM_USEC, mid, gidx) ? 
                   "usec" : "sec" : "disabled",
                   first ? vtss_trace_module_get_descr(mid) :
                   vtss_trace_grp_get_descr(mid, gidx));
            first = 0;
            if (gidx == req->trace_grp_idx) break;
        }
        if (mid == req->trace_module_id) break;
    }
}
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */

#if defined(VTSS_ARCH_B2)
static ulong cli_reg_base(ulong tgt, ulong port)
{
    ulong reg;
    
    if (tgt == 0x20)
        reg = (tgt + port);
    else if (tgt == 0x38 || tgt == 0x39)
        reg = (tgt + (port - 24)*2);
    else
        reg = tgt;
    return (reg << 16);
}

static void cli_sticky_check(cli_req_t *req, ulong offset, const char *name)
{
    if (req->value & (1<<offset))
        printf("Error at target 0x%02lx, address 0x%04lx: %s_sticky set\n", 
               (req->addr >> 16) & 0xff, req->addr & 0xffff, name);
}

static void cli_sticky_check_tgt(cli_req_t *req, ulong offset, const char *name)
{
    if (req->value & (1<<offset))
        printf("Error at target 0x%02lx, address 0x%04lx: %s_sticky set, target: %lu (0x%02lx)\n", 
               (req->addr >> 16) & 0xff, req->addr & 0xffff, name, 
               req->value & 0xff, req->value & 0xff);
}

/* Read and optionally clear sticky register */
static int cli_reg_read_clear(cli_req_t *req, ulong addr)
{
    ulong value;
    
    if (vtss_register_read(addr, &value) != VTSS_OK)
        return 0;
    if (req->clear)
        vtss_register_write(addr, value);
    req->addr = addr;
    req->value = value;
    return 1;
}

/* Read, check and optionally clear sticky bits */
static void cli_cmd_debug_reg_check(cli_req_t *req)
{
    ulong port, base;
    int   i;
    char  name[80];
    
    for (port = 0; port <= CLI_PORT_MAX; port++) {
        if (!req->chip_port_list[port])
            continue;

        printf("Checking port: %lu %s\n", port, port == 26 ? "(SPI4)" : "");
        if (port < 24) {
            /* 1G port */
            base = cli_reg_base(0x20, port);
            
            /* DEV1G::DEV_STICKY */
            if (cli_reg_read_clear(req, base + 0x01)) {
                cli_sticky_check(req, 10, "rx_oflw");
                cli_sticky_check(req, 1, "tx_oflw");
                cli_sticky_check(req, 0, "tx_uflw");
            }

            /* DEV1G::PCS1G_STICKY */
            if (cli_reg_read_clear(req, base + 0x24))
                cli_sticky_check(req, 0, "out_of_sync");
            
#if 0
            /* DEV1G::FX100_RX_STAT */
            if (cli_reg_read_clear(req, base + 0x07)) {
                cli_sticky_check(req, 9, "esd_err");
                cli_sticky_check(req, 8, "ssd_err");
                cli_sticky_check(req, 7, "rcv_err");
                cli_sticky_check(req, 6, "remote_xmit_err");
                cli_sticky_check(req, 2, "lock_err");
            }

            /* DEV1G::FX100_EYE_LOGIC_STATUS */
            if (cli_reg_read_clear(req, base + 0x10)) {
                cli_sticky_check(req, 20, "transitions_crossed");
                cli_sticky_check(req, 19, "transitions_too_close");
                cli_sticky_check(req, 18, "lower_transition_too_high");
                cli_sticky_check(req, 10, "lower_bounds_exceeded");
                cli_sticky_check(req, 8, "upper_transition_too_low");
                cli_sticky_check(req, 1, "upper_bounds_exceeded");
            }
#endif
        } else if (port < 26) {
            /* 10G port */
            base = cli_reg_base(0x38, port);

#if 0
            /* DEV10G::MAC_TX_MONITOR_STICKY */
            if (cli_reg_read_clear(req, base + 0x18)) {
                cli_sticky_check(req, 4, "local_err_state");
                cli_sticky_check(req, 3, "remote_err_state");
            }
#endif
            /* DEV10G::MAC_STICKY */
            if (cli_reg_read_clear(req, base + 0x19)) {
                cli_sticky_check(req, 1, "tx_uflw");
                cli_sticky_check(req, 0, "tx_abort");
            }

            /* DEV10G::DEV_STICKY */
            if (cli_reg_read_clear(req, base + 0x6b)) {
                cli_sticky_check(req, 10, "rx_resync_fifo_oflw");
                cli_sticky_check(req, 9, "rx_taxi_fifo_oflw");
                cli_sticky_check(req, 1, "tx_fifo_oflw");
                cli_sticky_check(req, 0, "tx_fifo_uflw");
            }
            
            /* XAUI_PHY_STAT::XAUI_OBS_STICKY */
            base = cli_reg_base(0x39, port);
            if (cli_reg_read_clear(req, base + 0xb5))
                cli_sticky_check(req, 1, "obs_dip2_err");
            
        } else if (port == 26) {
            /* SPI4 */
            base = cli_reg_base(0x0c, 0);

            /* DEVSPI::SPI4_IB_STICKY */
            if (cli_reg_read_clear(req, base + 0x08)) {
                cli_sticky_check(req, 25, "ib_invalid_port_num");
                cli_sticky_check(req, 23, "ib_usize_pkt");
                cli_sticky_check(req, 21, "ib_dip4_err");
                cli_sticky_check(req, 20, "ib_ram_error");
                cli_sticky_check(req, 19, "ib_buf_ovfl");
                cli_sticky_check(req, 9, "ib_eopa_word");
                cli_sticky_check(req, 5, "ib_unkn_data_word");
                cli_sticky_check(req, 3, "ib_unkn_ctrl_word");
                cli_sticky_check(req, 2, "ib_ext_ctrl_word");
            }

            /* DEVSPI::SPI4_OB_STICKY */
            if (cli_reg_read_clear(req, base + 0x0f)) {
                cli_sticky_check(req, 20, "ob_ram_error");
                cli_sticky_check(req, 19, "ob_buf_ovfl");
                cli_sticky_check(req, 9, "ob_eopa_word");
                cli_sticky_check(req, 5, "ob_unkn_data_word");
                cli_sticky_check(req, 3, "ob_unkn_ctrl_word");
                cli_sticky_check(req, 2, "ob_ext_ctrl_word");
            }

            /* DEVSPI::SPI4_OBS_STICKY */
            if (cli_reg_read_clear(req, base + 0x98)) {
                cli_sticky_check(req, 1, "obs_dip2_err");
                cli_sticky_check(req, 0, "obs_idle_mode");
            }

            /* DEVSPI::SPI4_IB_TC_STICKY */
            if (cli_reg_read_clear(req, base + 0xa7)) {
                for (i = 0; i < 17; i++) {
                    sprintf(name, "ib_tc_lane%u_err", i);
                    cli_sticky_check(req, i, name);
                }
            }
        }
    }
    
    printf("Checking ASM\n");
    base = cli_reg_base(0x02, 0);

    /* ASM::SPI_ERR_STICKY */
    if (cli_reg_read_clear(req, base + 0x169f)) {
        cli_sticky_check(req, 11, "fc_oflw");
        cli_sticky_check(req, 8, "cc_oflw");
        cli_sticky_check(req, 0, "main_sm_oflw");
    }
    
    /* ASM::NON_SPI_ERR_STICKY */
    if (cli_reg_read_clear(req, base + 0x16a0)) {
        cli_sticky_check(req, 16, "hih");
        for (i = 0; i < 4; i++) {
            sprintf(name, "fifo_oflw_%u", i);
            cli_sticky_check(req, i, name);
        }
    }

    /* ASM::CSC_STICKY */
    if (cli_reg_read_clear(req, base + 0x16a7))
        cli_sticky_check(req, 2, "csc_soft");

    printf("Checking DEVCPU_ORG\n");
    base = cli_reg_base(0x00, 0);

    /* DEVCPU_ORG::ERR_ACCESS_DROP_1 */
    if (cli_reg_read_clear(req, base + 0x00))
        cli_sticky_check_tgt(req, 8, "utm");
    
    /* DEVCPU_ORG::ERR_ACCESS_DROP_2 */
    if (cli_reg_read_clear(req, base + 0x01))
        cli_sticky_check_tgt(req, 9, "no_action");
    
    /* DEVCPU_ORG::ERR_TGT_MSB */
    if (cli_reg_read_clear(req, base + 0x03))
        cli_sticky_check_tgt(req, 8, "bsy");
    
    /* DEVCPU_ORG::ERR_TGT_LSB */
    if (cli_reg_read_clear(req, base + 0x04))
        cli_sticky_check_tgt(req, 9, "wd");
    
    /* DEVCPU_ORG::CFG_STATUS */
    if (cli_reg_read_clear(req, base + 0x0d))
        cli_sticky_check(req, 1, "rd_err");

    printf("Checking DSM\n");
    base = cli_reg_base(0x03, 0);

    /* DSM::FCS_STATUS */
    if (cli_reg_read_clear(req, base + 0x0168))
        cli_sticky_check(req, 0, "fcs_err");
    
    /* DSM::FCS_STATUS */
    if (cli_reg_read_clear(req, base + 0x0168))
        cli_sticky_check(req, 0, "fcs_err");
    
    /* DSM::IFH_STATUS */
    if (cli_reg_read_clear(req, base + 0x0169))
        cli_sticky_check(req, 0, "ifh_bip8_err");
    
    /* DSM::CELL_BUS_STICKY */
    if (cli_reg_read_clear(req, base + 0x01b7)) {
        cli_sticky_check(req, 3, "cell_bus_illegal_port_num");
        cli_sticky_check(req, 2, "cons_cell_for_same_taxi");
        cli_sticky_check(req, 1, "cell_bus_missing_sof");
        cli_sticky_check(req, 0, "cell_bus_missing_eof");
    }

    /* DSM::BUF_OFLW_STICKY */
    if (cli_reg_read_clear(req, base + 0x01ba)) {
        for (i = 0; i < 26; i++) {
            sprintf(name, "buf_oflw_%u", i);
            cli_sticky_check(req, i, name);
        }
    }
    
    /* DSM::BUF_UFLW_STICKY */
    if (cli_reg_read_clear(req, base + 0x01bb)) {
        for (i = 0; i < 26; i++) {
            sprintf(name, "buf_uflw_%u", i);
            cli_sticky_check(req, i, name);
        }
    }
    
    /* DSM::SPI4_LO_CH_BUF_OFLW_STICKY */
    if (cli_reg_read_clear(req, base + 0x01bc)) {
        for (i = 0; i < 24; i++) {
            sprintf(name, "spi4_ch_buf_oflw_%u", i + 48);
            cli_sticky_check(req, i, name);
        }
    }
    
    /* DSM::SPI4_HI_CH_BUF_OFLW_STICKY */
    if (cli_reg_read_clear(req, base + 0x01bd)) {
        for (i = 0; i < 24; i++) {
            sprintf(name, "spi4_ch_buf_oflw_%u", i + 72);
            cli_sticky_check(req, i, name);
        }
    }
    
    /* DSM::SPI4_LO_CTXT_BUF_OFLW_STICKY */
    if (cli_reg_read_clear(req, base + 0x01c0)) {
        for (i = 0; i < 24; i++) {
            sprintf(name, "spi4_ctxt_buf_oflw_%u", i + 48);
            cli_sticky_check(req, i, name);
        }
    }
    
    /* DSM::SPI4_HI_CTXT_BUF_OFLW_STICKY */
    if (cli_reg_read_clear(req, base + 0x01c1)) {
        for (i = 0; i < 24; i++) {
            sprintf(name, "spi4_ctxt_buf_oflw_%u", i + 72);
            cli_sticky_check(req, i, name);
        }
    }

    /* DSM::RAM_PARITY_ERR_STICKY */
    if (cli_reg_read_clear(req, base + 0x01c2)) {
        for (i = 0; i < 7; i++) {
            sprintf(name, "ram_parity_err_%u", i);
            cli_sticky_check(req, i, name);
        }
    }

    printf("Checking ANA_CL\n");
    base = cli_reg_base(0x04, 0);

    /* ANA_CL::SOFT_STICKY */
    if (cli_reg_read_clear(req, base + 0x133c)) {
        cli_sticky_check(req, 1, "port_cfg_soft");
        cli_sticky_check(req, 0, "endpt_cfg_soft");
    }

    /* ANA_CL::TAG_AND_LBL_STICKY */
    if (cli_reg_read_clear(req, base + 0x1340)) {
        cli_sticky_check(req, 10, "filter_max_tag");
        cli_sticky_check(req, 9, "filter_single_service");
        cli_sticky_check(req, 8, "filter_prio_tagged");
        cli_sticky_check(req, 7, "filter_tagged");
        cli_sticky_check(req, 6, "filter_untagged");
    }

    /* ANA_CL::DETECTION_STICKY */
    if (cli_reg_read_clear(req, base + 0x1341)) {
        cli_sticky_check(req, 6, "filter_global_custom");
        cli_sticky_check(req, 5, "mac_ctrl");
        cli_sticky_check(req, 4, "filter_l2_bc");
        cli_sticky_check(req, 3, "filter_etype_or_mac");
        cli_sticky_check(req, 2, "bad_macs");
        cli_sticky_check(req, 1, "smac_mc");
        cli_sticky_check(req, 0, "filter_local_custom");
    }

    printf("Checking ANA_AC\n");
    base = cli_reg_base(0x05, 0);
    
    /* ANA_AC::SOFT_STICKY */
    if (cli_reg_read_clear(req, base + 0x0501)) {
        cli_sticky_check(req, 8, "lb_cfg_soft");
        cli_sticky_check(req, 7, "prio_stat_info_soft");
        cli_sticky_check(req, 6, "port_stat_info_soft");
        cli_sticky_check(req, 5, "prio_stat_cnt_soft");
        cli_sticky_check(req, 4, "port_stat_cnt_soft");
        cli_sticky_check(req, 3, "port_lb_cnt_soft");
        cli_sticky_check(req, 2, "port_lb_cfg_soft");
        cli_sticky_check(req, 1, "prio_lb_cnt_soft");
        cli_sticky_check(req, 0, "prio_lb_cfg_soft");
    }

    printf("Checking QSS\n");
    base = cli_reg_base(0x07, 0);

    /* QSS::QSS_STICKY */
    if (cli_reg_read_clear(req, base + 0x02)) {
        cli_sticky_check(req, 11, "ariv_disabled_brm");
        cli_sticky_check(req, 10, "rx_discard_class_1");
        cli_sticky_check(req, 9, "rx_discard_class_0");
        cli_sticky_check(req, 8, "tx_discard_class_1");
        cli_sticky_check(req, 7, "tx_discard_class_0");
        cli_sticky_check(req, 6, "flist_uflw");
        cli_sticky_check(req, 5, "flist_empty");
        cli_sticky_check(req, 4, "sch_req_err");
        cli_sticky_check(req, 3, "frm_trunc");
        cli_sticky_check(req, 2, "ariv_max_frm_len");
        cli_sticky_check(req, 1, "ariv_cell_seq_err");
        cli_sticky_check(req, 0, "aport_disabled");
    }    

    /* QSS::FRM_UFLW_PORTS_0_31_STICKY */
    if (cli_reg_read_clear(req, base + 0x03)) {
        for (i = 0; i < 32; i++) {
            sprintf(name, "frm_uflw_port_%u", i);
            cli_sticky_check(req, i, name);
        }
    }    

    /* QSS::FRM_UFLW_PORTS_32_63_STICKY */
    if (cli_reg_read_clear(req, base + 0x04)) {
        for (i = 0; i < 32; i++) {
            sprintf(name, "frm_uflw_port_%u", i + 32);
            cli_sticky_check(req, i, name);
        }
    }    

    /* QSS::FRM_UFLW_PORTS_64_95_STICKY */
    if (cli_reg_read_clear(req, base + 0x05)) {
        for (i = 0; i < 32; i++) {
            sprintf(name, "frm_uflw_port_%u", i + 64);
            cli_sticky_check(req, i, name);
        }
    }    

    /* QSS::RAM_PTY_ERR_STICKY */
    if (cli_reg_read_clear(req, base + 0x05)) {
        for (i = 0; i < 16; i++) {
            sprintf(name, "ram_pty_err_%u", i);
            cli_sticky_check(req, i, name);
        }
    }    
} 

static void cli_cmd_host_stats(cli_req_t *req, const char *col1, const char *col2, 
                               ulong reg1, ulong reg2)
{
    ulonglong c1, c2;
    ulong     val;

    if (req->clear) {
        /* Clear counters */
        if (col1 != NULL)
            vtss_register_write(reg1, 0);
        if (col2 != NULL)
            vtss_register_write(reg2, 0);
    } else {
        /* Show counters */
        c1 = ((col1 != NULL && vtss_register_read(reg1, &val)) == VTSS_OK ? val : 0);
        c2 = ((col2 != NULL && vtss_register_read(reg2, &val)) == VTSS_OK ? val : 0);
        cli_cmd_stats(col1, col2, c1, c2);
    }
}

static void cli_cmd_xaui_stats(cli_req_t *req, uint port, const char *col1, const char *col2, 
                               ulong reg1, ulong reg2)
{
    ulong base;

    base = cli_reg_base(0x38, port);
    if (reg1 < 0x10000)
        reg1 += base;
    if (reg2 < 0x10000)
        reg2 += base;
    cli_cmd_host_stats(req, col1, col2, reg1, reg2);
}

static void cli_cmd_debug_xaui(cli_req_t *req)
{
    uint port;

    for (port = 24; port < 26; port++) {
        if (!req->clear)
            printf("\nChip Port %u Statistics:\n\n", port);
        cli_cmd_xaui_stats(req, port, "Unicast", "", 0x23, 0x36);
        cli_cmd_xaui_stats(req, port, "Multicast", "", 0x24, 0x37);
        cli_cmd_xaui_stats(req, port, "Broadcast", "", 0x25, 0x38);
        cli_cmd_xaui_stats(req, port, "Pause", "", 0x20, (3<<16) + 0x16a + port - 24); /* DSM */
        cli_cmd_xaui_stats(req, port, "Octets", "", 0x42, 0x46);
        cli_cmd_xaui_stats(req, port, "64", "", 0x2d, 0x39);
        cli_cmd_xaui_stats(req, port, "65-127", "", 0x2e, 0x3a);
        cli_cmd_xaui_stats(req, port, "128-255", "", 0x2f, 0x3b);
        cli_cmd_xaui_stats(req, port, "256-511", "", 0x30, 0x3c);
        cli_cmd_xaui_stats(req, port, "512-1023", "", 0x31, 0x3d);
        cli_cmd_xaui_stats(req, port, "1024-1518", "", 0x32, 0x3e);
        cli_cmd_xaui_stats(req, port, "1519-", "", 0x33, 0x3f);
        cli_cmd_xaui_stats(req, port, "Symbol", NULL, 0x1f, 0);
        cli_cmd_xaui_stats(req, port, "Opcode", NULL, 0x21, 0);
        cli_cmd_xaui_stats(req, port, "CRC", NULL, 0x26, 0);
        cli_cmd_xaui_stats(req, port, "Undersize", NULL, 0x27, 0);
        cli_cmd_xaui_stats(req, port, "Fragment", NULL, 0x28, 0);
        cli_cmd_xaui_stats(req, port, "Oversize", NULL, 0x2b, 0);
        cli_cmd_xaui_stats(req, port, "Jabbers", NULL, 0x2c, 0);
        cli_cmd_xaui_stats(req, port, "Shrink", NULL, 0x34, 0);
    }
}

static void cli_cmd_spi4_stats(cli_req_t *req, const char *col1, const char *col2, 
                               ulong reg1, ulong reg2)
{
    ulong base;

    base = cli_reg_base(0x0c, 0);
    cli_cmd_host_stats(req, col1, col2, reg1 + base, reg2 + base);
}

static void cli_cmd_debug_spi4(cli_req_t *req)
{
    cli_cmd_spi4_stats(req, "Packets", "", 0x04, 0x0c);
    cli_cmd_spi4_stats(req, "Bytes", "", 0x06, 0x0e);
    cli_cmd_spi4_stats(req, "EOPAs", "", 0x05, 0x0d);
    cli_cmd_spi4_stats(req, "DIP-4 Errors", "DIP-2 Errors", 0x03, 0x97);
}

/* Show B2 register */
static void cli_b2_reg_show(ulong tgt, ulong addr, ulong addr_count, ulong addr_offset,
                            const char *name)
{
    ulong base, reg, value, i;
    char  tgt_name[32];
    
    if (tgt >= 0x20 && tgt <= 0x37)
        sprintf(tgt_name, "%s_%lu", "DEV1G", tgt - 0x20);
    else
        strcpy(tgt_name, 
               tgt == 0x00 ? "DEVCPU_ORG" :
               tgt == 0x01 ? "DEVCPU_GCB" :
               tgt == 0x02 ? "ASM" :
               tgt == 0x03 ? "DSM" :
               tgt == 0x04 ? "ANA_CL" :
               tgt == 0x05 ? "ANA_AC" :
               tgt == 0x06 ? "SCH" :
               tgt == 0x07 ? "QSS" :
               tgt == 0x0c ? "DEVSPI" :
               tgt == 0x38 ? "DEV10G_0" :
               tgt == 0x39 ? "SPAUI_STAT_0" :
               tgt == 0x3a ? "DEV10G_1" :
               tgt == 0x3b ? "SPAUI_STAT_1" :
               tgt == 0x3f ? "FAST_REGS" : "?");
    base = cli_reg_base(tgt, 0);
    for (i = 0; i < addr_count; i++) {
        reg = (addr + i*addr_offset);
        if (vtss_register_read(base + reg, &value) != VTSS_OK)
            continue;
        printf("0x%02lx-0x%04lx: 0x%08lx  %s", tgt, reg, value, tgt_name);
        if (name != NULL) {
            printf("-%s", name);
            if (addr_count > 1)
                printf("[%lu]", i);
        }
        printf("\n");
    }
}

/* Show QSS registers */
static void cli_reg_qss_show(ulong addr, ulong addr_count, const char *name)
{
    cli_b2_reg_show(0x07, addr, addr_count, 1, name);
}

static void cli_cmd_debug_qss(cli_req_t *req)
{
    cli_reg_qss_show(0x100, 96, "APORT_ENA_CLASS_MAP");
    cli_reg_qss_show(0x300, 1, "RX_TOTAL_SIZE");
    cli_reg_qss_show(0x301, 1, "TX_TOTAL_SIZE");
    cli_reg_qss_show(0x400, 2, "RX_GBL_ENA");
    cli_reg_qss_show(0x402, 2, "RX_GBL_SHMAX");
    cli_reg_qss_show(0x404, 2, "RX_GBL_DROP_HLTH");
    cli_reg_qss_show(0x406, 2, "RX_GBL_FC_HLTH");
    cli_reg_qss_show(0x500, 2, "TX_GBL_ENA");
    cli_reg_qss_show(0x502, 2, "TX_GBL_SHMAX");
    cli_reg_qss_show(0x504, 2, "TX_GBL_DROP_HLTH");
    cli_reg_qss_show(0x506, 2, "TX_GBL_FC_HLTH");
    cli_reg_qss_show(0x600, 96, "PORT_ENA");
    cli_reg_qss_show(0x660, 96, "PORT_RSVD_GFC_LTH");
    cli_reg_qss_show(0x6c0, 96, "PORT_SHMAX");
    cli_reg_qss_show(0x720, 96, "PORT_DROP_HLTH");
    cli_reg_qss_show(0x780, 96, "PORT_FC_HLTH");
    cli_reg_qss_show(0x7e0, 96, "PORT_PRE_ALLOC");
    cli_reg_qss_show(0xef0, 240, "Q_RSVD");
}

static void cli_cmd_debug_qss_bufcnt(cli_req_t *req)
{

    int port_no, addr;

    printf("Global Rx buffer:\n");
    cli_reg_qss_show(0x303, 1, "RX_SHCNT");
    printf("Global Tx buffer:\n");
    cli_reg_qss_show(0x305, 1, "TX_SHCNT");
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;
        addr = (0x8a0 + (port_no-1));
        printf("Tx port %d buffer:\n",port_no);
        cli_reg_qss_show(addr, 1, "PORT_CNT");
        
        printf("Rx port %d queues:\n",port_no);
        addr = (0x11c0 + (port_no-1)*8);
        cli_reg_qss_show(addr, 8, "Q_CNT");
    }
}

static void cli_cmd_debug_red_cnt(cli_req_t *req)
{
    int i,indx,port_no;

    req->blk_list[7] = 1; /* QSS target */

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (req->port_list[port_no] == 0)
            continue;

        indx = 0x1670 + (VTSS_QUEUES * (port_no-1));            
        for (i = 0; i < CLI_ADDR_MAX; i++) {
            if (i >= indx && i <= indx+8) 
                req->addr_list[i] = 1;
        }        
        printf ("Port %d queues red drop cnt 1-8:\n",port_no);
        cli_cmd_debug_reg(req, 0);
    }

}

#endif /* VTSS_ARCH_B2 */

#if defined(VTSS_OPT_RSTP) && VTSS_OPT_RSTP
static const char *
rstp_role2str(vtss_rstp_port_role_t rstp_role)
{
    static const char *rstprolemap[] = { "Disabled", "Alternate", "Backup", "Root", "Designated", "Non-STP" };
    VTSS_ASSERT(rstp_role < (sizeof(rstprolemap)/sizeof(char*)));
    return rstprolemap[rstp_role];
}

static const char *
rstp_portstate2str(vtss_common_stpstate_t port_state)
{
    static const char *strportstate[] = { "Disabled", "Blocking", "Listening", "Learning", "Forwarding", "Non-STP" };
    VTSS_ASSERT(port_state < (sizeof(strportstate)/sizeof(char*)));
    return strportstate[port_state];
}

static const char *
rstp_bridgeid2str(char *buf, size_t size, const vtss_rstp_bridge_id_t *bridge)
{
    char macbuf[32];
    misc_mac_txt(bridge->id.macaddr, macbuf);
    snprintf(buf, size, "%u:%s", bridge->prio, macbuf);
    return buf;
}

static const char *
rstp_rootport2str(char *buf, size_t size, vtss_port_no_t root_port)
{
    if(root_port)
        snprintf(buf, size, "%d", root_port);
    else
        strncpy(buf, "-", size);
    return buf;
}

static void rstp_display_port(cli_req_t *req,
                              vtss_port_no_t poag_no,
                              vtss_rstp_bridge_status_t *bs,
                              BOOL *first,
                              BOOL *bridge)
{
    vtss_rstp_portstatus_t    ps;
    char                      buf[64];
    vtss_rstp_get_port_status(poag_no, &ps);
    if ((!ps.stp_viewable && !ps.part_of_aggr) ||
        (bs != NULL && ps.vlan_id != bs->vlan_id))
        return;
        
    /* Bridge header */
    if (*bridge && bs != NULL) {
        *bridge = 0;
        printf("=================================================================\n");
        /* printf("VLAN ID      : %d\n", bs->vlan_id); */
        printf("Bridge ID    : %s\n", 
               rstp_bridgeid2str(buf, sizeof(buf), &bs->this_bridge));
        printf("Root ID      : %s\n", 
               rstp_bridgeid2str(buf, sizeof(buf), &bs->designated_root));
        printf("Root Port    : %s\n", rstp_rootport2str(buf, sizeof(buf), bs->root_port));
        printf("Root Cost    : %ld\n", bs->root_cost);
        printf("Topology Flag: %s\n", bs->in_tc ? "Changing" : "Steady");
    }
    
    /* Table header */
    if (*first) {
        *first = 0;
        if (bs == NULL)
            cli_table_header("Port   Rx RSTP   Tx RSTP   Rx STP   Tx STP   Rx TCN   Tx TCN   Rx Ill.  Rx Unk.");
        else
            cli_table_header("Port   Port Role   State       Path Cost   Edge  P2P  Neigb");
    }

    /* Entry data */
    if (bs == NULL)
        printf("%-6d %-8lu  %-8lu  %-7lu  %-7lu  %-7lu  %-7lu  %-7lu  %-7lu\n",
               poag_no,
               ps.port_stats.rstp_frame_recvs,
               ps.port_stats.rstp_frame_xmits,
               ps.port_stats.stp_frame_recvs,
               ps.port_stats.stp_frame_xmits,
               ps.port_stats.tcn_frame_recvs,
               ps.port_stats.tcn_frame_xmits,
               ps.port_stats.illegal_frame_recvs,
               ps.port_stats.unknown_frame_recvs);
    else
        printf("%-6d %-10s  %-10s  %-10lu  %-4s  %-3s  %-5s\n",
               poag_no,
               rstp_role2str(ps.rstp_role),
               rstp_portstate2str(ps.port_state),
               ps.oper_pathcost,
               ps.is_edge ? "Yes" : "No",
               ps.is_p2p ? "Yes" : "No",
               ps.stp_neigb ? "STP" : "RSTP");
}

static void rstp_display_status(cli_req_t *req)
{
    vtss_rstp_bridge_status_t bs;
    int                       bno;
    vtss_poag_no_t            poag_no;
    BOOL                      first, bridge;

    for (bno = 0; bno < VTSS_RSTP_MAX_VLANS; bno++) {
        vtss_rstp_get_bridge_status(bno, &bs);
        if (!bs.admin_enabled ||
            (bs.vlan_id == VTSS_RSTP_DEFAULT_VLAN_ID && bs.num_active_ports == 0))
            continue;
        
        bridge = 1;
        first = 1;
        for (poag_no = VTSS_PORT_NO_START; VTSS_RSTP_IS_PORT(poag_no); poag_no++) 
            rstp_display_port(req, poag_no, &bs, &first, &bridge);
    }
}

static void rstp_display_statistics(cli_req_t *req)
{
    vtss_poag_no_t            poag_no;
    BOOL                      first, bridge;
    bridge = 1;
    first = 1;
    for (poag_no = VTSS_PORT_NO_START; VTSS_RSTP_IS_PORT(poag_no); poag_no++) 
        rstp_display_port(req, poag_no, NULL, &first, &bridge);
}
#endif /* VTSS_OPT_RSTP */

static void cli_command(cli_cmd_id_t id, cli_req_t *req)
{
    switch (id) {
    case CLI_CMD_ID_HELP:
        cli_cmd_help();
        break;
    case CLI_CMD_ID_SYSTEM_CONF:
        cli_cmd_system_conf(req);
        break;
#if defined(VTSS_ARCH_B2)
    case CLI_CMD_ID_SYSTEM_INIT:
        cli_cmd_system_init();
        break;
#endif /* VTSS_ARCH_B2 */
    case CLI_CMD_ID_PORT_CONF:
        cli_cmd_port_conf(req, 1, 1, 1, 1);
        break;
    case CLI_CMD_ID_PORT_STATE:
        cli_cmd_port_conf(req, 1, 0, 0, 0);
        break;
    case CLI_CMD_ID_PORT_MODE:
        cli_cmd_port_conf(req, 0, 1, 0, 0);
        break;
    case CLI_CMD_ID_PORT_FLOW_CONTROL:
        cli_cmd_port_conf(req, 0, 0, 1, 0);
        break;
    case CLI_CMD_ID_PORT_MAX_FRAME:
        cli_cmd_port_conf(req, 0, 0, 0, 1);
        break;
    case CLI_CMD_ID_PORT_STATS:
        cli_cmd_port_stats(req);
        break;
#if defined(VTSS_ARCH_B2)
    case CLI_CMD_ID_PORT_FILTER:
        cli_cmd_port_filter(req);
        break;
    case CLI_CMD_ID_PORT_FORWARD:
        cli_cmd_port_forward(req);
        break;
    case CLI_CMD_ID_PORT_PSI:
        vtss_psi_set(req->value);
        break;
    case CLI_CMD_ID_QOS_GLOBAL_DSCP:
        cli_cmd_qos_global_dscp(req);
        break;
    case CLI_CMD_ID_QOS_DSCP_TABLE:
        cli_cmd_qos_dscp_table(req);
        break;
    case CLI_CMD_ID_QOS_GLOBAL_TCPUDP:
        cli_cmd_qos_global_tcpudp(req);
        break;
    case CLI_CMD_ID_QOS_GLOBAL_TCPUDP_ENABLE:
        cli_cmd_qos_tcpudp_enable(req);
        break;
    case CLI_CMD_ID_QOS_GLOBAL_FILTTRIG:
        cli_cmd_qos_global_filter(req,1);
        break;
    case CLI_CMD_ID_QOS_GLOBAL_FILTACTION:
        cli_cmd_qos_global_filter(req,0);
        break;
    case CLI_CMD_ID_QOS_FILTTRIG:
        cli_cmd_qos_filter(req,1);
        break;
    case CLI_CMD_ID_QOS_FILTACTION:
        cli_cmd_qos_filter(req,0);
        break;
    case CLI_CMD_ID_QOS_GLOBAL_FILTENABLE:
        cli_cmd_qos_global_filter_enable(req);
        break;
    case CLI_CMD_ID_QOS_PRIORDER:
        cli_cmd_qos_priorder(req);
        break;
    case CLI_CMD_ID_QOS_CLASS_MISC:
        cli_cmd_qos_class_misc(req);
        break;

    case CLI_CMD_ID_QOS_CLASS_TCPUDP:
        cli_cmd_qos_class_tcpudp(req);
        break;
    case CLI_CMD_ID_QOS_CLASS_IP_PROTO:
        cli_cmd_qos_class_ipproto(req);
        break;
    case CLI_CMD_ID_QOS_CLASS_ETYPE:
        cli_cmd_qos_class_etype(req);
        break;
    case CLI_CMD_ID_QOS_CLASS_VID:
        cli_cmd_qos_class_vid(req);
        break;
    case CLI_CMD_ID_QOS_CLASS_TAG_PRIO:
        cli_cmd_qos_class_tagprio(req);
        break;
    case CLI_CMD_ID_QOS_CLASS_MPLS:
        cli_cmd_qos_class_mpls(req);
        break;
    case CLI_CMD_ID_QOS_PORT_POLICE:
        cli_cmd_qos_port_police(req);
        break;
    case CLI_CMD_ID_QOS_PORT_SHAPER:
        cli_cmd_qos_port_shaper(req);
        break;
    case CLI_CMD_ID_QOS_QUEUE_POLICE:
        cli_cmd_qos_queue_police(req);
        break;
    case CLI_CMD_ID_QOS_L2_FILTER_ALTORDER:
        cli_cmd_qos_l2_filter_altorder(req);
        break;
    case CLI_CMD_ID_QOS_L2_FILTER_DMAC:
        cli_cmd_qos_l2_filter_dmac(req);
        break;
    case CLI_CMD_ID_QOS_L2_FILTER_VID:
        cli_cmd_qos_l2_filter_vid(req);
        break;
    case CLI_CMD_ID_QOS_L2_FILTER_ETYPE:
        cli_cmd_qos_l2_filter_etype(req);
        break;
    case CLI_CMD_ID_QOS_L2_FILTER_PORT:
        cli_cmd_qos_l2_filter_port(req);
        break;
    case CLI_CMD_ID_QOS_L2_FILTER_CONF:
        cli_cmd_qos_l2_filter_conf(req);
        break;
    case CLI_CMD_ID_QOS_RED_THRESHOLD:
        cli_cmd_qos_red_threshold(req);
        break;
    case CLI_CMD_ID_QOS_RED_PROBABILITY:
        cli_cmd_qos_red_probability(req);
        break;
    case CLI_CMD_ID_QOS_RED_PROFILE:
        cli_cmd_qos_red_profile(req);
        break;
    case CLI_CMD_ID_QOS_TAG:
        cli_cmd_qos_tag(req);
        break;
    case CLI_CMD_ID_QOS_QUEUE_SCHEDULER:
        cli_cmd_qos_queue_schedule(req);
        break;
    case CLI_CMD_ID_QOS_PORT_SCHEDULER:
        cli_cmd_qos_port_schedule(req);
        break;
    case CLI_CMD_ID_QOS_LPORT_SCHEDULER:
        cli_cmd_qos_lport_schedule(req);
        break;
#endif /* VTSS_ARCH_B2 */
    case CLI_CMD_ID_DEBUG_REG_READ:
        cli_cmd_debug_reg(req, 0);
        break;
    case CLI_CMD_ID_DEBUG_REG_WRITE:
        cli_cmd_debug_reg(req, 1);
        break;
#if defined(VTSS_ARCH_B2)
    case CLI_CMD_ID_DEBUG_REG_CHECK:
        cli_cmd_debug_reg_check(req);
        break;
#endif /* VTSS_ARCH_B2 */
    case CLI_CMD_ID_DEBUG_PHY_READ:
        cli_cmd_debug_phy(req, 0);
        break;
    case CLI_CMD_ID_DEBUG_PHY_WRITE:
        cli_cmd_debug_phy(req, 1);
        break;
#if defined(VTSS_ARCH_B2)
    case CLI_CMD_ID_DEBUG_MMD_READ:
        cli_cmd_debug_mmd(req, 0);
        break;

    case CLI_CMD_ID_DEBUG_MMD_WRITE:
        cli_cmd_debug_mmd(req, 1);
        break;
#if defined(BOARD_B2_EVAL) 
    case CLI_CMD_ID_DEBUG_FPGA_STATUS:
        cli_cmd_debug_fpga_status(req);
        break;
#endif /* BOARD_B2_EVAL */
#endif /* VTSS_ARCH_B2 */
#if defined(VTSS_GPIOS)
    case CLI_CMD_ID_DEBUG_GPIO_OUTPUT:
    case CLI_CMD_ID_DEBUG_GPIO_READ:
    case CLI_CMD_ID_DEBUG_GPIO_WRITE:
        cli_cmd_debug_gpio(req, id);
        break;
#endif /* VTSS_GPIOS */
#if defined(VTSS_FEATURE_INTERRUPTS)
    case CLI_CMD_ID_DEBUG_INTERRUPT:
        cli_cmd_debug_interrupt(req);
        break;
#endif /* VTSS_FEATURE_INTERRUPTS */
    case CLI_CMD_ID_DEBUG_CHIP_ID:
    {
        vtss_chipid_t id;
        if (vtss_chipid_get(&id) == VTSS_OK) {
            printf("Part Number: 0x%04x\n", id.part_number);
            printf("Revision   : %u\n", id.revision);
        }
        break;
    }
    case CLI_CMD_ID_DEBUG_SUSPEND:
        if (!suspended) {
            suspended = 1;
            printf("Application suspended\n");
        }
        break;
    case CLI_CMD_ID_DEBUG_RESUME:
        if (suspended) {
            suspended = 0;
            printf("Application resumed\n");
        }
        break;
#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    case CLI_CMD_ID_DEBUG_TRACE_MODULE_LEVEL:
        cli_cmd_debug_trace(req, 1, 0, 0);
        break;
    case CLI_CMD_ID_DEBUG_TRACE_MODULE_TIMESTAMP:
        cli_cmd_debug_trace(req, 0, 1, 0);
        break;
    case CLI_CMD_ID_DEBUG_TRACE_MODULE_USEC:
        cli_cmd_debug_trace(req, 0, 0, 1);
        break;
    case CLI_CMD_ID_DEBUG_REVERSE:
        vtss_trace_lvl_reverse();
        break;
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */
#if defined(VTSS_ARCH_B2)
    case CLI_CMD_ID_DEBUG_XAUI:
        cli_cmd_debug_xaui(req);
        break;
    case CLI_CMD_ID_DEBUG_SPI4:
        cli_cmd_debug_spi4(req);
        break;
    case CLI_CMD_ID_DEBUG_QSS:
        cli_cmd_debug_qss(req);
        break;
    case CLI_CMD_ID_DEBUG_BUF:
        cli_cmd_debug_qss_bufcnt(req);
        break;
    case CLI_CMD_ID_DEBUG_RED_CNT:
        cli_cmd_debug_red_cnt(req);
        break;
#endif /* VTSS_ARCH_B2 */
#if defined(VTSS_OPT_RSTP) && VTSS_OPT_RSTP
    case CLI_CMD_ID_RSTP_STATUS:
        rstp_display_status(req);
        break;
    case CLI_CMD_ID_RSTP_STATISTICS:
        rstp_display_statistics(req);
        break;
#endif /* VTSS_OPT_RSTP */
    default:
        printf("command id: %d not implemented\n", id);
        break;
    }
}

/* Parse parameter */
static int cli_parse_parm(cli_parm_type_t type, cli_cmd_t *cli_cmd,
                          char *cmd, char *cmd2, char *stx, char *cmd_org, cli_req_t *req)
{
    int error;

    req->parm_parsed = 1;
    switch (type) {
    case CLI_PARM_TYPE_PORT_LIST:
        error = cli_parse_list(cmd, req->port_list, 
                               VTSS_PORT_NO_START, VTSS_PORT_NO_END - 1, 1);
        cli_remove_unused_ports(req);
        break;
    case CLI_PARM_TYPE_CHIP_PORT_LIST:
        error = cli_parse_list(cmd, req->chip_port_list, 0, CLI_PORT_MAX, 1);
        break;
#if defined(VTSS_ARCH_B2)
    case CLI_PARM_TYPE_LPORT_LIST:
        error = cli_parse_list(cmd, req->lport_list, 0, VTSS_LPORTS-1, 1);
        break;
#endif
#if defined(VTSS_GPIOS)
    case CLI_PARM_TYPE_GPIO_LIST:
        error = cli_parse_list(cmd, req->gpio_list, 
                               VTSS_GPIO_NO_START, VTSS_GPIO_NO_END - 1, 1);
        break;
#endif /* VTSS_GPIOS */
    case CLI_PARM_TYPE_MAX_FRAME:
        error = cli_parse_ulong(cmd, &req->value, 
                                VTSS_MAXFRAMELENGTH_STANDARD, VTSS_MAXFRAMELENGTH_MAX);
        break;
    case CLI_PARM_TYPE_KEYWORD:
        error = cli_parse_keyword(cmd, req, stx);
        break;
    case CLI_PARM_TYPE_BLK_LIST:
        error = cli_parse_list(cmd, req->blk_list, 0, CLI_BLK_MAX - 1, 0);
        break;
    case CLI_PARM_TYPE_SUB_LIST:
        error = cli_parse_list(cmd, req->sub_list, 0, CLI_SUB_MAX - 1, 0);
        break;
    case CLI_PARM_TYPE_ADDR_LIST:
        error = cli_parse_list(cmd, req->addr_list, 0, CLI_ADDR_MAX - 1, 0);
        break;
    case CLI_PARM_TYPE_PSI_CLOCK:
        error = cli_parse_ulong(cmd, &req->value, 0, 9765000);
        break;
    case CLI_PARM_TYPE_TABLE_ID:
        error = cli_parse_ulong(cmd, &req->table_id, 1, 2);
        break;
    case CLI_PARM_TYPE_TABLE_INDEX:
        error = cli_parse_ulong(cmd, &req->table_index, 1, 8);
        break;
    case CLI_PARM_TYPE_PCT:
        error = cli_parse_ulong(cmd, &req->value, 0, 100);
        break;
    case CLI_PARM_TYPE_DSCP_LIST:
        error = cli_parse_list(cmd, req->dscp_list, 0, 63, 1);
        break;
    case CLI_PARM_TYPE_TRIG_INDEX:
        error = cli_parse_ulong(cmd, &req->trig_index, 0, 6);
        break;
    case CLI_PARM_TYPE_OFFSET_VALUE:
        error = cli_parse_ulong(cmd, &req->offset, 0, 127);
        break;
    case CLI_PARM_TYPE_PATTERN_VALUE:
        error = cli_parse_ulong(cmd, &req->pattern, 0, 0xFFFF);
        break;
    case CLI_PARM_TYPE_MASK_VALUE:
        error = cli_parse_ulong(cmd, &req->mask, 0, 0xFFFF);
        break;
    case CLI_PARM_TYPE_TCP_UDP_PORT:
        error = cli_parse_ulong(cmd, &req->tcp_udp_port, 0, 0xffff);
        break;
    case CLI_PARM_TYPE_QOS_ORDER:
        error = cli_parse_ulong(cmd, &req->order, 0, 16);
        break;
    case CLI_PARM_TYPE_QOS_ENDPOINT:
        error = cli_parse_ulong(cmd, &req->endpoint, 0, 16);
        break;
    case CLI_PARM_TYPE_ETYPE:
        error = cli_parse_ulong(cmd, &req->etype, 0, 0xffff);
        break;
    case CLI_PARM_TYPE_TAG_PRIO:
        error = cli_parse_ulong(cmd, &req->tag_prio, 0, 7);
        break;
    case CLI_PARM_TYPE_MPLS_EXP:
        error = cli_parse_ulong(cmd, &req->mpls_exp, 0, 7);
        break;
    case CLI_PARM_TYPE_VLAN:
        error = cli_parse_ulong(cmd, &req->vlan, 0, 4096);
        break;
    case CLI_PARM_TYPE_IP_PROTO:
        error = cli_parse_ulong(cmd, &req->ip_proto, 0, 255);
        break;
#if defined(VTSS_ARCH_B2)
    case CLI_PARM_TYPE_DMAC:
        error = cli_parse_mac(cmd, req->dmac); 
        break;
    case CLI_PARM_TYPE_DMAC_MASK:
        error = cli_parse_mac(cmd, req->dmac_mask); 
        break;
#endif
    case CLI_PARM_TYPE_CLASS_VALUE:
        error = cli_parse_ulong(cmd, &req->class, 1, 8);
        break;
    case CLI_PARM_TYPE_RED_VALUE:
        error = cli_parse_ulong(cmd, &req->red, 0, 3);
        break;
    case CLI_PARM_TYPE_PHY_ADDR_LIST:
        error = cli_parse_list(cmd, req->addr_list, 0, 31, 0);
        break;
    case CLI_PARM_TYPE_PHY_VALUE:
        error = cli_parse_ulong(cmd, &req->value, 0, 0xffff);
        break;
    case CLI_PARM_TYPE_GPIO_VALUE:
        error = cli_parse_ulong(cmd, &req->value, 0, 1);
        break;
    case CLI_PARM_TYPE_VALUE:
        error = cli_parse_ulong(cmd, &req->value, 0, 0xffffffff);
        break;
    case CLI_PARM_TYPE_PAGE:
        error = cli_parse_ulong(cmd, &req->page, 0, 0xffff);
        break;
    case CLI_PARM_TYPE_QOS_BIT_RATE:
        error = cli_parse_ulong(cmd, &req->rate, 0, 10000000);
        break;
#if defined(VTSS_ARCH_B2)
    case CLI_PARM_TYPE_QOS_LEVEL:
        error = cli_parse_ulong(cmd, &req->policer.level, 0, 10000000);
        break;
#endif
    case CLI_PARM_TYPE_RED_MIN:
        error = cli_parse_ulong(cmd, &req->red_min, 0, 32640);
        break;
    case CLI_PARM_TYPE_RED_MAX:
        error = cli_parse_ulong(cmd, &req->red_max, 0, 65280);
        break;
    case CLI_PARM_TYPE_RED_WEIGHT:
        error = cli_parse_ulong(cmd, &req->red_weight, 0, 31);
        break;
    case CLI_PARM_TYPE_RED_PROB_1:
        error = cli_parse_ulong(cmd, &req->red_prob1, 0, 100);
        break;
    case CLI_PARM_TYPE_RED_PROB_2:
        error = cli_parse_ulong(cmd, &req->red_prob2, 0, 100);
        break;
    case CLI_PARM_TYPE_RED_PROB_3:
        error = cli_parse_ulong(cmd, &req->red_prob3, 0, 100);
        break;
#if defined(VTSS_ARCH_B2)
    case CLI_PARM_TYPE_MMD_LIST:
        error = cli_parse_list(cmd, req->mmd_list, 0, 31, 0);
        break;
    case CLI_PARM_TYPE_MMD_ADDR:
        error = cli_parse_ulong(cmd, &req->mmd_address, 0, 0xffff);
        break;
#endif /* VTSS_ARCH_B2 */
#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    case CLI_PARM_TYPE_TRACE_MODULE:
        error = (vtss_trace_module_to_val(cmd, &req->trace_module_id) ? 0 : 1);
        break;
    case CLI_PARM_TYPE_TRACE_GROUP:
        error = (vtss_trace_grp_to_val(cmd, req->trace_module_id, &req->trace_grp_idx) ? 
                 0 : 1);
        break;
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */
    default:
        printf("Unknown parameter type: %d\n", type); 
        error = 1;
        break;
    }
    return error;
}

static cli_parm_t *cli_parm_lookup(char *stx, cli_cmd_id_t cmd_id, int *idx)
{
    int        i;
    cli_parm_t *parm;
    
    for (i = 0; i < sizeof(cli_parm_table)/sizeof(*parm); i++) {
        parm = &cli_parm_table[i];
        if (strstr(stx, parm->txt) != NULL && 
            (parm->id == CLI_CMD_ID_NONE || parm->id == cmd_id)) {
            *idx = i;
            return parm;
        }
    }

    return NULL;
}

static char *cli_lower_word(char *in, char *out)
{
    int i, len;

    len = strlen(in);
    for (i = 0; i <= len; i++)
        out[i] = tolower(in[i]);
    return out;
}

/* Build array of command/syntax words */
static void cli_build_words(char *str, int *count, char **words, BOOL lower)
{
    int  i, j, len;
    char *p;
    
    len = strlen(str);
    j = 0;
    *count = 0;
    for (i = 0; i < len; i++) {
        p = &str[i];
        if (isspace(*p)) {
            j = 0;
            *p = '\0';
        } else {
            if (j == 0) {
                words[*count] = p;
                (*count)++;
            }
            if (lower)
                *p = tolower(*p);
            j++;
        }
    }
}

/* Parse command */
static void cli_parse_command(void)
{
    char       *cmd, *stx, *cmd2;
    char       cmd_buf[MAX_CMD_LEN], stx_buf[MAX_CMD_LEN], *cmd_words[64], *stx_words[64];
    char       cmd1_buf[MAX_WORD_LEN], cmd2_buf[MAX_WORD_LEN];
    int        i, i_cmd, i_stx, i_parm = 0, cmd_count, stx_count, max, len, j, error, idx;
    int        match_cmds[sizeof(cli_cmd_table)/sizeof(cli_cmd_t)], match_count = 0;
    cli_cmd_t  *cli_cmd;
    BOOL       match, help = 0;
    cli_req_t  *req;
    cli_parm_t *parm;

    /* Read command and skip leading spaces */
    cmd = cmd_get();

    /* Remove CR */
    i = strlen(cmd);
    if (i)
        cmd[i-1] = '\0';

    /* Build array of command words */
    strcpy(cmd_buf, cmd);
    cli_build_words(cmd_buf, &cmd_count, cmd_words, 0);

    /* Remove trailing 'help' or '?' command */
    if (cmd_count > 1) {
        cmd = cli_lower_word(cmd_words[cmd_count-1], cmd1_buf);
        if (strcmp(cmd, "?") == 0 || strcmp(cmd, "help") == 0) {
            cmd_count--;
            help = 1;
        }
    }
    
    /* Compare entered command with each entry in CLI command table */
    for (i = 0; i < sizeof(cli_cmd_table)/sizeof(cli_cmd_t); i++) {
        cli_cmd = &cli_cmd_table[i];
        
        /* Build array of syntax words */
        strcpy(stx_buf, cli_cmd->syntax);
        cli_build_words(stx_buf, &stx_count, stx_words, 1);

        match = 1; 
        for (i_cmd = 0, i_stx = 0; i_stx < stx_count; i_cmd++, i_stx++) {
            stx = stx_words[i_stx];
            if (*stx == '<' || *stx == '[') {
                /* Parameters start here */
                i_parm = i_stx;
                break;
            }

            if (i_cmd >= cmd_count)
                continue;
            
            cmd = cli_lower_word(cmd_words[i_cmd], cmd1_buf);
            if (strstr(stx, cmd) != stx) {
                /* Command word mismatch */
                match = 0;
                break;
            }
        }
        
        if (match) {
            match_cmds[match_count++] = i;
        }
    }
    
    if (match_count == 0) {
        /* No matching commands */
        printf("Invalid command\n");
    } else if (match_count == 1) {
        /* One matching command */
        cli_cmd = &cli_cmd_table[match_cmds[0]];
        
        /* Rebuild array of syntax words */
        strcpy(stx_buf, cli_cmd->syntax);
        cli_build_words(stx_buf, &stx_count, stx_words, 1);

        if (help) {
            uchar done[sizeof(cli_parm_table)/sizeof(*parm)];
            
            memset(done, 0, sizeof(done));
            cli_header_nl("Description", 0, 0);
            printf("%s.\n\n", cli_cmd->descr);
            cli_header_nl("Syntax", 0, 0);
            printf("%s\n\n", cli_cmd->syntax);
            for (max = 0, i = 0; i_parm && i < 2; i++) {
                for (i_stx = i_parm; i_stx < stx_count; i_stx++) {
                    if ((parm = cli_parm_lookup(stx_words[i_stx], cli_cmd->id, &idx)) == NULL)
                        continue;
                    len = strlen(parm->txt);
                    if (i == 0) {
                        if (!(parm->flags & CLI_PARM_FLAG_NO_TXT)) {
                            if (len > max)
                                max = len;
                        }
                    } else if (!done[idx]) {
                        done[idx] = 1;
                        if (i_stx == i_parm)
                            cli_header_nl("Parameters", 0, 0);
                        if (!(parm->flags & CLI_PARM_FLAG_NO_TXT)) {
                            printf("%s", parm->txt);
                            for (j = len; j < max; j++)
                                printf(" ");
                            printf(": ");
                        }
                        printf("%s\n", parm->help);
                    }
                }
            }
        } else {
            enum {
                CLI_STATE_IDLE,
                CLI_STATE_PARSING,
                CLI_STATE_DONE,
                CLI_STATE_ERROR
            } state;
            BOOL end = 0, separator, skip_parm;
            
            /* Create default parameters */
            req = &cli_req;
            cli_req_default_set(req);
            
            /* Parse arguments */
            state = CLI_STATE_IDLE;
            for (i_cmd = i_parm, i_stx = i_parm; i_parm && i_stx < stx_count; i_stx++) {
                stx = stx_words[i_stx];

                separator = (strcmp(stx, "|") == 0);
                skip_parm = 0;
                switch (state) {
                case CLI_STATE_IDLE:
                    if (stx[0] == '(' || stx[1] == '(') {
                        i = i_cmd;
                        state = CLI_STATE_PARSING;
                    }
                    break;
                case CLI_STATE_PARSING:
                    break;
                case CLI_STATE_ERROR:
                    if (end && separator) {
                        /* Parse next group */
                        i_cmd = i;
                        state = CLI_STATE_PARSING;
                    } else if (strstr(stx, ")]") != NULL) {
                        i_cmd = i;
                        state = CLI_STATE_IDLE;
                    }
                    skip_parm = 1;
                    break;
                case CLI_STATE_DONE:
                    if (end && !separator)
                        state = CLI_STATE_IDLE;
                    else
                        skip_parm = 1;
                    break;
                default:
                    printf("Illegal state: %d\n", state);
                    return;
                }
                end = (strstr(stx, ")") != NULL);
                
#if 0
                printf("stx: %s, cmd: %s, state: %s->%s\n",
                        stx, i_cmd < cmd_count ? cmd_words[i_cmd] : NULL,
                        state == CLI_STATE_IDLE ? "IDLE" :
                        state == CLI_STATE_PARSING ? "PARSING" :
                        state == CLI_STATE_ERROR ? "ERROR" : "DONE");
#endif                
                /* Skip if separator or not in parsing state */
                if (separator || skip_parm)
                    continue;

                /* Lookup parameter */
                if ((parm = cli_parm_lookup(stx, cli_cmd->id, &idx)) == NULL) {
                    printf("Unknown parameter: %s\n", stx);
                    return;
                } 
                
                if (i_cmd >= cmd_count) {
                    /* No more command words */
                    cmd = NULL;
                    error = 1;
                } else {
                    /* Parse command parameter */
                    do {
                        cmd = cli_lower_word(cmd_words[i_cmd], cmd1_buf);
                        cmd2 = ((i_cmd + 1) < cmd_count ? 
                                cli_lower_word(cmd_words[i_cmd + 1], cmd2_buf) : NULL);
                        error = cli_parse_parm(parm->type, cli_cmd, cmd, cmd2, 
                                               stx, cmd_words[i_cmd], req); 
#if 0
                        printf("stx: %s, cmd: %s, error: %d\n", stx, cmd, error);
#endif
                        if (error)
                            break;
                        if (parm->flags & CLI_PARM_FLAG_SET)
                            req->set = 1;
                        i_cmd += req->parm_parsed;
                    } while (i_cmd < cmd_count && (parm->flags & CLI_PARM_FLAG_DUAL));
                }
                
                /* No error or error in optional parameter */
                if (!error ||
                    (stx[0] == '[' && (stx[1] != '(' || stx[2] == '['))) {
                    if (state == CLI_STATE_PARSING && end)
                        state = CLI_STATE_DONE;
                    continue;
                }

                /* Error in mandatory parameter of group */
                if (state == CLI_STATE_PARSING) {
                    state = CLI_STATE_ERROR;
                    continue;
                }

                /* Error in mandatory parameter */
                if (cmd == NULL)
                    printf("Missing %s parameter\n\n", parm->txt);
                else
                    printf("Invalid %s parameter: %s\n\n", parm->txt, cmd);
                printf("Syntax:\n%s\n", cli_cmd->syntax);
                return;
            } /* for loop */
            if (i_parm) { 
                if (i_cmd < cmd_count) {
                    printf("Invalid parameter: %s\n\n", cmd_words[i_cmd]);
                    printf("Syntax:\n%s\n", cli_cmd->syntax);
                    return;
                }
                if (state == CLI_STATE_ERROR) {
                    printf("Invalid parameter\n\n");
                    printf("Syntax:\n%s\n", cli_cmd->syntax);
                    return;
                }
            } /* Parameter handling */

            /* Handle CLI command */
            cli_command(cli_cmd->id, req);
        }
    } else {
        printf("Available Commands:\n\n");
        for (i = 0; i < match_count ; i++)
            printf("%s\n", cli_cmd_table[match_cmds[i]].syntax);
    }
} /* cli_parse_command */

void cli_tsk(void)
{
    do {
        if(cmd_ready()) {
            cli_parse_command();
            prompt();
        }
    } while(suspended);
}
   
#endif /* VTSS_OPT_CLI */
/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
