/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_switch.c,v 1.202 2008/09/09 09:40:31 cpj Exp $
 $Revision: 1.202 $

*/

#define VTSS_TRACE_LAYER 3
#define VTSS_TRACE_FILE "hl"

/* Standard headers */
#include <stdarg.h>
#include <string.h>

/* API public headers */
#include "vtss_switch_api.h"
#include "vtss_basic_trace.h"

/* API private headers */
#include "vtss_state.h"
#include "vtss_cil.h"

#if defined(VTSS_FEATURE_LAYER2)
static vtss_rc vtss_update_masks(BOOL src_update, BOOL dest_update, BOOL aggr_update);
#endif /* VTSS_FEATURE_LAYER2 */

/* Global variables for API state information */
vtss_state_info_t *vtss_api_state; /* API high level state information */
static vtss_state_info_t *vs;      /* Short hand for above */

vtss_state_t *vtss_state;          /* Full API state */

/* ================================================================= *
 *  Supplemental
 * ================================================================= */

/* Return code interpretation */
const char *vtss_error_txt(vtss_rc rc)
{
    const char *txt;
    switch (rc) {
    case VTSS_OK:
        txt = "VTSS_OK";
        break;
    case VTSS_WARNING:
        txt = "VTSS_WARNING";
        break;
    case VTSS_INCOMPLETE:
        txt = "VTSS_INCOMPLETE";
        break;
    case VTSS_UNSPECIFIED_ERROR:
        txt = "VTSS_UNSPECIFIED_ERROR";
        break;
    case VTSS_NOT_IMPLEMENTED:
        txt = "VTSS_NOT_IMPLEMENTED";
        break;
    case VTSS_INVALID_PARAMETER:
        txt = "VTSS_INVALID_PARAMETER";
        break;
    case VTSS_DATA_NOT_READY:
        txt = "VTSS_DATA_NOT_READY";
        break;
    case VTSS_ENTRY_NOT_FOUND:
        txt = "VTSS_ENTRY_NOT_FOUND";
        break;
    case VTSS_TIMEOUT_RETRYLATER:
        txt = "VTSS_TIMEOUT_RETRYLATER";
        break;
    case VTSS_FATAL_ERROR:
        txt = "VTSS_FATAL_ERROR";
        break;
    case VTSS_PHY_NOT_MAPPED:
        txt = "VTSS_PHY_NOT_MAPPED";
        break;
    case VTSS_PHY_READ_ERROR:
        txt = "VTSS_PHY_READ_ERROR";
        break;
    case VTSS_PHY_TIMEOUT:
        txt = "VTSS_PHY_TIMEOUT";
        break;
    case VTSS_TBI_DISABLED:
        txt = "VTSS_TBI_DISABLED";
        break;
    case VTSS_PACKET_BUF_SMALL:
        txt = "VTSS_PACKET_BUF_SMALL";
        break;
    case VTSS_IO_READ_ERROR:
        txt = "VTSS_IO_READ_ERROR";
        break;
    case VTSS_IO_WRITE_ERROR:
        txt = "VTSS_IO_WRITE_ERROR";
        break;
    case VTSS_SYNCE_RE_NOM:
        txt = "VTSS_SYNCE_RE_NOM";
        break;
    case VTSS_SYNCE_NOM_PORT:
        txt = "VTSS_SYNCE_NOM_PORT";
        break;
    case VTSS_SYNCE_PRIORITY:
        txt = "VTSS_SYNCE_PRIORITY";
        break;
    case VTSS_SYNCE_SELECTION:
        txt = "VTSS_SYNCE_SELECTION";
        break;
    case VTSS_EPS_W_ENABLED:
        txt = "VTSS_EPS_W_ENABLED";
        break;
    case VTSS_EPS_W_DISABLED:
        txt = "VTSS_EPS_W_DISABLED";
        break;
    case VTSS_EPS_P_ENABLED:
        txt = "VTSS_EPS_P_ENABLED";
        break;
    default:
        txt = "VTSS_?";
        break;
    }
    return txt;
}

#if defined(VTSS_FEATURE_LAYER2)
/* - PGID functions -------------------------------------------------------- */

/* Determine whether a port number is PGID member considering aggregations */
static BOOL vtss_pgid_member(vtss_pgid_no_t pgid_no, vtss_port_no_t port)
{
    vtss_pgid_entry_t *pgid_entry;
    vtss_poag_no_t    poag_no;
    vtss_port_no_t    port_no;
    BOOL              member;

    /* Ensure that unmapped ports are not included */
    if (vs->port_map.vtss_port_unused[port])
        return 0;
    
    pgid_entry = &vs->pgid_table[pgid_no];
    member = pgid_entry->member[port];

#if defined(VTSS_FEATURE_AGGR_GLAG)
    if (pgid_no >= VTSS_PGID_GLAG_START && pgid_no < VTSS_PGID_GLAG_END) {
        /* Special GLAG masks are used unchanged */
        return member;
    } else {
        vtss_glag_no_t glag_no;

        if ((glag_no = vs->port_glag_no[port]) != 0) {
            /* Port is part of GLAG, check aggregated ports */
            for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
                if (vs->port_glag_no[port_no] == glag_no && pgid_entry->member[port_no])
                    member = 1;
            }
        }
    }
#endif /* VTSS_FEATURE_AGGR_GLAG */

    if ((poag_no = vs->port_poag_no[port]) != port) {
        /* Port is aggregated, check aggregated ports */
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (vs->port_poag_no[port_no] == poag_no && pgid_entry->member[port_no])
                member = 1;
        }
    }

    /* Check if protected port is member */
    if ((port_no = vs->port_protect[port]) != 0 && pgid_entry->member[port_no])
        member = 1;
    
    return member;
}

/* Write PGID member to chip */
vtss_rc vtss_pgid_table_write(const vtss_pgid_no_t pgid_no)
{
    vtss_port_no_t    port_no;
    BOOL              member[VTSS_PORT_ARRAY_SIZE];
    
    VTSS_D(("pgid_no: %d",pgid_no));
    
    /* Avoid updating unicast entries for unmapped ports */
    if (pgid_no<VTSS_PGID_UNICAST_END && vs->port_map.vtss_port_unused[pgid_no]) {
        VTSS_D(("Skipping unmapped pgid_no: %d",pgid_no));
        return VTSS_OK;
    }

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        member[port_no] = vtss_pgid_member(pgid_no, port_no);

    /* Update PGID table */
    return vtss_ll_pgid_table_write(pgid_no, member);
}

/* Allocate PGID */
vtss_rc vtss_pgid_alloc(vtss_pgid_no_t *pgid_no, BOOL resv,
                        const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_pgid_no_t    pgid, pgid_start, pgid_free;
    vtss_pgid_entry_t *pgid_entry;
    vtss_port_no_t    port_no;

    VTSS_D(("enter"));
    
    /* Search for matching or unused entry in PGID table */
    pgid_free = vs->pgid_end;
#if defined(VTSS_CHIPS)
    /* For multi chip targets, the unicast PGIDs are not reused */
    pgid_start = VTSS_PGID_UNICAST_END;
#else
    pgid_start = VTSS_PGID_START;
#endif /* VTSS_CHIPS */
    for (pgid = pgid_start; pgid < vs->pgid_end; pgid++)  {
        pgid_entry = &vs->pgid_table[pgid];
        
        if (pgid_entry->references == 0) {
            /* Check if the first unused entry is found */
            if (pgid_free == vs->pgid_end)
                pgid_free = pgid;
        } else if (!resv && !pgid_entry->resv) {
            /* Check if an existing entry matches */
            for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
                if (member[port_no] != pgid_entry->member[port_no])
                    break;
            if (port_no == VTSS_PORT_NO_END) {
                pgid_entry->references++;
                VTSS_D(("reusing pgid: %d",pgid));
                *pgid_no = pgid;
                return VTSS_OK;
            }
        }
    }
    
    /* No pgid found */
    if (pgid_free == vs->pgid_end)
        return VTSS_ENTRY_NOT_FOUND;

    /* Unused PGID found */
    *pgid_no = pgid_free;
    VTSS_D(("using pgid_no: %d",*pgid_no));
    pgid_entry = &vs->pgid_table[*pgid_no];
    pgid_entry->resv = resv;
    pgid_entry->references = 1;
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        pgid_entry->member[port_no] = member[port_no];
    return vtss_pgid_table_write(*pgid_no);
}

/* Free PGID */
vtss_rc vtss_pgid_free(const vtss_pgid_no_t pgid_no)
{
    vtss_pgid_entry_t *pgid_entry;

    VTSS_D(("pgid_no: %d",pgid_no));

    /* Do not free reserved PGIDs */
    if (
#if defined(VTSS_FEATURE_AGGR_GLAG)
        pgid_no == VTSS_PGID_GLAG_DEST || pgid_no == (VTSS_PGID_GLAG_DEST + 1) ||
#endif /* VTSS_FEATURE_AGGR_GLAG */
        pgid_no == VTSS_PGID_NONE)
        return VTSS_OK;

    pgid_entry = &vs->pgid_table[pgid_no];
    if (pgid_entry->references == 0) {
        VTSS_E(("pgid_no: %d already free",pgid_no));
        return VTSS_INVALID_PARAMETER;
    }
    pgid_entry->resv = 0;
    pgid_entry->references--;
    return VTSS_OK;
}
#endif /* VTSS_FEATURE_LAYER2 */

/* - Reset --------------------------------------------------------- */

static void vtss_init_state(const vtss_init_setup_t * setup)
{
    vtss_port_no_t    port_no, port_end;
#if defined(VTSS_FEATURE_LAYER2)
    vtss_pgid_no_t    pgid_no;
    vtss_msti_t       msti;
    vtss_vid_t        vid;
    vtss_pgid_entry_t *pgid_entry;
#endif /* VTSS_FEATURE_LAYER2 */
    uint              chip_port;
    int               i;

    VTSS_D(("enter"));

    memset(vs, 0, sizeof(*vs));

    /* Initialize port map table */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
#if defined(VTSS_ARCH_GATWICK)
#if defined(VTSS_CHIPS)
        vtss_chip_no_t chip_no;

        chip_no = (port_no < 25 ? 0 : 1);
        vs->port_map.chip_no[port_no] = chip_no;
        chip_port = ((port_no - chip_no*24) - VTSS_PORT_NO_START + 8);
        vs->port_map.chip_port[port_no] = chip_port;
        vs->port_map.vtss_port[chip_no][chip_port] = port_no;
#else
        chip_port = (port_no == 25 ? 0 : port_no == 26 ? 4 : (port_no - VTSS_PORT_NO_START + 8));
        vs->port_map.chip_port[port_no] = chip_port;
        vs->port_map.vtss_port[chip_port] = port_no;
#endif /* VTSS_CHIPS */
#endif /* VTSS_ARCH_GATWICK */
#if defined(VTSS_ARCH_HEATHROW) || defined(VTSS_ARCH_B2)
        chip_port = port_no-VTSS_PORT_NO_START;
#if defined(HEATHROW3)
        chip_port += 4;
#endif /* HEATHROW3 */
#if defined(SPARX_II_16)
        chip_port += 8;
#endif /* SPARX_II_16 */
#if VTSS_OPT_INT_AGGR
        /* Map the last two ports to aggregated ports */
        if (port_no == (VTSS_PORTS - 1))
            chip_port = VTSS_CHIP_PORT_AGGR_0;
        if (port_no == VTSS_PORTS)
            chip_port = VTSS_CHIP_PORT_AGGR_1;
#endif /* VTSS_OPT_INT_AGGR */
#if defined(SPARX_G5)
        if (port_no == 6)
            chip_port = 6;
#endif /* SPARX_G5 */
        vs->port_map.chip_port[port_no] = chip_port;
        vs->port_map.vtss_port[chip_port] = port_no;
#endif /* VTSS_ARCH_HEATHROW/B2 */
        vs->port_map.chip_ports_all[port_no] = chip_port;
    }

#if VTSS_OPT_INT_AGGR
    /* Map port 27/28 to chip port 25/27 */
    vs->port_map.chip_port[VTSS_PORT_NO_AGGR_0] = (VTSS_CHIP_PORT_AGGR_0+1);
    vs->port_map.chip_port[VTSS_PORT_NO_AGGR_1] = (VTSS_CHIP_PORT_AGGR_1+1);
#endif /* VTSS_OPT_INT_AGGR */    

#if defined(VTSS_FEATURE_VSTAX)
    vs->vstax_setup.uid = VTSS_VSTAX_UID_START;
#endif /* VTSS_FEATURE_VSTAX */

#if defined(VTSS_FEATURE_LAYER2)
    /* Initialize aggregations */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        vs->port_poag_no[port_no] = port_no;
    }

    /* Initialize MSTP to VLAN mapping */
    for (vid = 0; vid < VTSS_VIDS; vid++) {
        vs->vlan_table[vid].msti = VTSS_MSTI_START;
    }
    vs->msti_end = VTSS_MSTI_END;

    /* Initialize MSTP table */
    for (msti = VTSS_MSTI_START; msti < VTSS_MSTI_END; msti++) {
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            vs->mstp_table[msti].state[port_no] = (msti==VTSS_MSTI_START ? 
                                                   VTSS_MSTP_STATE_FORWARDING : 
                                                   VTSS_MSTP_STATE_DISCARDING);
        }
    }

    /* Initialize number of MAC addresses */
    vs->mac_addrs = VTSS_MAC_ADDRS;
        
    /* Initialize PGID table */
    vs->pgid_end = VTSS_PGID_END;
    for (pgid_no = VTSS_PGID_START; pgid_no < vs->pgid_end; pgid_no++) {
        pgid_entry = &vs->pgid_table[pgid_no];
        switch (pgid_no) {
        case VTSS_PGID_KILL:
            /* Kill entry */
            pgid_entry->references = 1;
            break;
        case VTSS_PGID_BC:
            /* Broadcast entry */
            for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
                pgid_entry->member[port_no] = MAKEBOOL01(1);
            }
            pgid_entry->references = 1;
            break;
        default:
            if (pgid_no<VTSS_PGID_UNICAST_END) {
                /* Unicast entries */
                pgid_entry->member[pgid_no] = MAKEBOOL01(1);
                pgid_entry->references = 1;
            } else {
#if defined(VTSS_FEATURE_AGGR_GLAG)
                /* Reserve entries for GLAG support */
                if (pgid_no >= VTSS_PGID_GLAG_START && pgid_no < VTSS_PGID_GLAG_END) {
                    pgid_entry->resv = 1;
                    pgid_entry->references = 1;
                }
#endif /* VTSS_FEATURE_AGGR_GLAG */                

                /* Multicast entries */
            }
            break;
        }
    }
    
    /* Initialize STP, Authentication and forwarding state */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        vs->stp_state[port_no] = VTSS_STP_STATE_DISABLED;
        vs->auth_state[port_no] = VTSS_AUTH_STATE_BOTH;
        vs->port_forward[port_no] = VTSS_PORT_FORWARD_ENABLED;
    }

    /* Initialize PVLAN table */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        vs->pvlan_table[VTSS_PVLAN_NO_DEFAULT].member[port_no] = 1;
    }

    /* Initialize mirror port */
    vs->mirror_port = 0; /* Mirror port disabled */
#endif /* VTSS_FEATURE_LAYER2 */

    /* Initialize QoS, all queues used */
    vs->prios = VTSS_PRIOS;
#if VTSS_OPT_INT_AGGR
    port_end = (VTSS_PORT_NO_AGGR_1 + 1);
#else
    port_end = VTSS_PORT_NO_END;
#endif /* VTSS_OPT_INT_AGGR */

    for (port_no = VTSS_PORT_NO_START; port_no < port_end; port_no++) {
        vtss_port_qos_setup_t *qos;
#if defined(VTSS_ARCH_B2)
        vtss_port_filter_t *filter;
#endif /* VTSS_ARCH_B2 */        
        
        qos = &vs->qos[port_no];
#if defined(VTSS_ARCH_B2)
        qos->vlan_aware = 1; /* Enable VLAN awareness for QoS and filtering */
        qos->default_qos.prio = VTSS_PRIO_START;
        qos->l2_control_qos.prio = VTSS_PRIO_START;
        qos->l3_control_qos.prio = VTSS_PRIO_START;
        qos->cfi_qos.prio = VTSS_PRIO_START;
        qos->ipv4_arp_qos.prio = VTSS_PRIO_START;
        qos->ipv6_qos.prio = VTSS_PRIO_START;
        for (i = 0; i < 8; i++) {
            qos->mpls_exp_qos[i].prio = VTSS_PRIO_START;
            qos->vlan_tag_qos[i].prio = VTSS_PRIO_START;
        }
        qos->llc_qos.prio = VTSS_PRIO_START;
        qos->dscp_table_no = VTSS_DSCP_TABLE_NO_START;
        for (i = 0; i < 2; i++)
            qos->udp_tcp.local.pair[i].qos.prio = VTSS_PRIO_START;
        qos->ip_proto.qos.prio = VTSS_PRIO_START;
        qos->etype.qos.prio = VTSS_PRIO_START;
        for (i = 0; i < 2; i++)
            qos->vlan[i].qos.prio = VTSS_PRIO_START;
        qos->custom_filter.local.forward = 1;
        qos->custom_filter.local.qos.prio = VTSS_PRIO_START;
        for (i = 0; i < VTSS_PORT_POLICER_COUNT; i++)
            qos->policer_port[i].rate = VTSS_BITRATE_FEATURE_DISABLED;
        for (i = VTSS_QUEUE_START; i < VTSS_QUEUE_END; i++)
            qos->policer_queue[i].rate = VTSS_BITRATE_FEATURE_DISABLED;
        qos->shaper_port.rate = VTSS_BITRATE_FEATURE_DISABLED;
        qos->scheduler.rate = VTSS_BITRATE_FEATURE_DISABLED;
        qos->scheduler.queue_pct[1] = 0;  /* Q0 */
        qos->scheduler.queue_pct[2] = 10; /* Q1 */
        qos->scheduler.queue_pct[3] = 15; /* Q2 */
        qos->scheduler.queue_pct[4] = 20; /* Q3 */
        qos->scheduler.queue_pct[5] = 25; /* Q4 */
        qos->scheduler.queue_pct[6] = 30; /* Q5 */

        filter = &vs->filter[port_no];
        filter->mac_ctrl_enable = 1;
        filter->mac_zero_enable = 1;
        filter->dmac_bc_enable = 1;
        filter->smac_mc_enable = 1;
        filter->untag_enable = 1;
        filter->prio_tag_enable = 1;
        filter->ctag_enable = 1;
        filter->stag_enable = 1;
        filter->max_tags = VTSS_TAG_ANY;
#else /* VTSS_ARCH_B2 */

#if defined(VTSS_FEATURE_QCL_PORT)
        qos->qcl_id = VTSS_QCL_ID_NONE;
#endif /* VTSS_FEAURE_QCL_PORT */
#if defined(VTSS_FEATURE_QOS_L4_PORT) || defined(VTSS_FEATURE_QOS_L4_SWITCH)
        qos->udp_tcp_enable = 0;
#endif /* VTSS_FEATURE_QOS_L4_PORT/VTSS_FEATURE_QOS_L4_SWITCH */
        qos->dscp_enable = 0;
#if defined(VTSS_FEATURE_QOS_IP_PROTO_PORT)
        qos->ip_proto_enable = 0;
#endif /* VTSS_FEATURE_QOS_IP_PROTO_PORT */
        qos->tag_enable = 0;
#if defined(VTSS_FEATURE_QOS_MPLS_PORT)
        qos->mpls_enable = 0;
#endif /* VTSS_FEATURE_QOS_MPLS_PORT */
#if defined(VTSS_FEATURE_QOS_DSAP_PORT)
        qos->dsap_enable = 0;
#endif /* VTSS_FEATURE_QOS_DSAP_PORT */
#if defined(VTSS_FEATURE_QOS_ETYPE_PORT)
        qos->etype_enable = 0;
#endif /* VTSS_FEATURE_QOS_ETYPE_PORT */
#if defined(VTSS_FEATURE_QOS_L4_PORT)
        for (i=0; i<10; i++) {
            qos->udp_tcp_val[i] = 0;
#if defined(VTSS_ARCH_HAWX)
            qos->udp_tcp_prio[i] = VTSS_PRIO_START;
#endif /* VTSS_ARCH_HAWX */
        }
#endif /* VTSS_FEATURE_QOS_L4_PORT */
        for (i=0; i<64; i++) {
            qos->dscp_prio[i] = VTSS_PRIO_START;
        }
#if defined(VTSS_FEATURE_QOS_IP_PROTO_PORT)
        qos->ip_proto_val = 255; /* Protocol reserved according to IANA */
#if defined(VTSS_ARCH_GATWICK) || defined(VTSS_ARCH_HAWX)
        qos->ip_proto_prio = VTSS_PRIO_START;
#endif /* VTSS_ARCH_GATWICK/VTSS_ARCH_HAWX */
#endif /* VTSS_FEATURE_QOS_IP_PROTO_PORT */
        for (i=0; i<8; i++) {
            /* Use IEEE user priority mapping adjusted for number of priorities */
            qos->tag_prio[i] = (
                ((i == 0 ? 2 : i == 1 ? 0 : i == 2 ? 1 : i)*VTSS_PRIOS/8) + VTSS_PRIO_START);
        }
#if defined(VTSS_FEATURE_QOS_MPLS_PORT)
        for (i=0; i<8; i++) {
            qos->mpls_prio[i] = VTSS_PRIO_START;
        }
#endif /* VTSS_FEATURE_QOS_MPLS_PORT */
#if defined(VTSS_FEATURE_QOS_DSAP_PORT)
        qos->dsap_val = 0x00;
        qos->dsap_prio = VTSS_PRIO_START;
#endif /* VTSS_FEATURE_QOS_DSAP_PORT */
#if defined(VTSS_FEATURE_QOS_ETYPE_PORT)
#if defined(VTSS_ARCH_HAWX)
        for (i=0; i<2; i++) {
            qos->etype_val[i] = 0xFFFF;
            qos->etype_prio[i] = VTSS_PRIO_START;
        }
#else
        qos->etype_val = 0xFFFF;
        qos->etype_prio = VTSS_PRIO_START;
#endif /* VTSS_ARCH_HAWX */
#endif /* VTSS_FEATURE_QOS_ETYPE_PORT */
        qos->default_prio = VTSS_PRIO_START;
#if defined(VTSS_ARCH_HEATHROW)
        qos->usr_prio = 0 /*VTSS_TAGPRIO_DEFAULT*/;
#endif /* VTSS_ARCH_HEATHROW */
#if defined(VTSS_ARCH_GATWICK)
        for (i=VTSS_PRIO_START; i<VTSS_PRIO_END; i++) {
            qos->usr_prio[i] = 0 /*VTSS_TAGPRIO_DEFAULT*/;
        }
        qos->tag_map_enable = 0;
        for (i=0; i<8; i++) {
            qos->remap_prio[i] = i;
        }
#endif /* VTSS_ARCH_GATWICK */
#if defined(VTSS_FEATURE_QOS_POLICER_PORT)
        qos->policer_port = VTSS_BITRATE_FEATURE_DISABLED;
#endif /* VTSS_FEATURE_QOS_POLICER_PORT */
#if defined(VTSS_FEATURE_QOS_BURST_LEVEL_PORT)
        qos->policer_level = 4096;
#endif /* VTSS_FEATURE_QOS_BURST_LEVEL_PORT */
#if defined(VTSS_FEATURE_QOS_POLICER_MC_PORT)
        qos->mc_policer_port = VTSS_BITRATE_FEATURE_DISABLED;
#if defined(VTSS_ARCH_GATWICK)
        qos->mc_policer_port_bc_only = 0;
#endif /* VTSS_ARCH_GATWICK */
#endif /* VTSS_FEATURE_QOS_POLICER_MC_PORT */
#if defined(VTSS_FEATURE_QOS_POLICER_BC_PORT)
        qos->bc_policer_port = VTSS_BITRATE_FEATURE_DISABLED;
#endif /* VTSS_FEATURE_QOS_POLICER_BC_PORT */
#if defined(VTSS_FEATURE_QOS_POLICER_CIR_PORT)
        qos->policer_cir_port = VTSS_BITRATE_FEATURE_DISABLED;
#endif /* VTSS_FEATURE_QOS_POLICER_CIR_PORT */
#if defined(VTSS_FEATURE_QOS_POLICER_CIR_PIR_QUEUE)
        for (i=VTSS_QUEUE_START; i<VTSS_QUEUE_END; i++) {
            qos->policer_cir_queue[i] = VTSS_BITRATE_FEATURE_DISABLED;
            qos->policer_pir_queue[i] = VTSS_BITRATE_FEATURE_DISABLED;
        }
#endif /* VTSS_FEATURE_QOS_POLICER_CIR_PIR_QUEUE */
#if defined(VTSS_FEATURE_QOS_SHAPER_PORT)
        qos->shaper_port = VTSS_BITRATE_FEATURE_DISABLED;
#endif /* VTSS_FEATURE_QOS_SHAPER_PORT */
#if defined(VTSS_FEATURE_QOS_BURST_LEVEL_PORT)
        qos->shaper_level = 4096;
#endif /* VTSS_FEATURE_QOS_BURST_LEVEL_PORT */
#if defined(VTSS_FEATURE_QOS_SHAPER_QUEUE)
        for (i=VTSS_QUEUE_START; i<VTSS_QUEUE_END; i++) {
            qos->shaper_queue[i] = VTSS_BITRATE_FEATURE_DISABLED;
            qos->shaper_queue_excss_enable[i] = 0;
        }
#endif /* VTSS_FEATURE_QOS_SHAPER_QUEUE */

#endif /* VTSS_ARCH_B2 */
    } /* Port loop */

#if defined(VTSS_ARCH_B2)
    for (i = 0; i < VTSS_LPORTS; i++) {
        vtss_lport_qos_setup_t *lport_qos = &vs->lport_qos[i];
        
        lport_qos->scheduler.rx_rate = VTSS_BITRATE_FEATURE_DISABLED;
        lport_qos->scheduler.tx_rate = VTSS_BITRATE_FEATURE_DISABLED;
    }
#endif /* VTSS_ARCH_B2 */
    
    /* Global QoS setup */
    {
        vtss_qos_setup_t *qos = &vs->qos_setup;
#if defined(VTSS_FEATURE_QOS_L4_SWITCH)
        for (i=0; i<10; i++) {
            qos->udp_tcp_val[i] = 0;
            qos->udp_tcp_prio[i] = VTSS_PRIO_START;
        }
        qos->udp_tcp_prio_def = VTSS_PRIO_START;
#endif /* VTSS_FEATURE_QOS_L4_SWITCH */
        
#if defined(VTSS_FEATURE_QOS_POLICER_CPU_SWITCH)
        qos->policer_mac = VTSS_PACKET_RATE_DISABLED;
        qos->policer_cat = VTSS_PACKET_RATE_DISABLED;
        qos->policer_learn = VTSS_PACKET_RATE_DISABLED;
#endif /* VTSS_FEATURE_QOS_POLICER_CPU_SWITCH */
        
#if defined(VTSS_FEATURE_QOS_POLICER_UC_SWITCH)
        qos->policer_uc = VTSS_PACKET_RATE_DISABLED;
#endif /* VTSS_FEATURE_QOS_POLICER_UC_SWITCH */
        
#if defined(VTSS_FEATURE_QOS_POLICER_MC_SWITCH)
        qos->policer_mc = VTSS_PACKET_RATE_DISABLED;
#endif /* VTSS_FEATURE_QOS_POLICER_MC_SWITCH */
        
#if defined(VTSS_FEATURE_QOS_POLICER_BC_SWITCH)
        qos->policer_bc = VTSS_PACKET_RATE_DISABLED;
#endif /* VTSS_FEATURE_QOS_POLICER_BC_SWITCH */
        
#if defined(VTSS_ARCH_HAWX)
        qos->weighted_fairness_queueing = 0;
#endif /* VTSS_ARCH_HAWX */
        
#if defined(VTSS_ARCH_B2)
        for (i = 0; i < VTSS_UDP_TCP_PAIR_COUNT; i++) {
            qos->udp_tcp[i].pair[0].qos.prio = VTSS_PRIO_START;
            qos->udp_tcp[i].pair[1].qos.prio = VTSS_PRIO_START;
        }
        for (i = 0; i < VTSS_CUSTOM_FILTER_COUNT; i++) {
            qos->custom_filter[i].forward = 1;
            qos->custom_filter[i].qos.prio = VTSS_PRIO_START;
        }
#endif /* VTSS_ARCH_B2   */
#if defined(VTSS_ARCH_HEATHROW)
        qos->dummy = 0;
#endif /* VTSS_ARCH_HEATHROW */
    }

#if defined(VTSS_FEATURE_ACL)
    /* Add ACL entries to free list */
    vs->acl_list = NULL;
    vs->acl_free = NULL;
    for (i = 0; i < VTSS_ACES; i++) {
        vtss_acl_entry_t *acl_entry;

        acl_entry = &vs->acl[i];
        acl_entry->next = vs->acl_free;
        vs->acl_free = acl_entry;
    }
#endif /* VTSS_FEATURE_ACL */
    
    /* Port forwarding state */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        vs->port_forward[port_no] = VTSS_PORT_FORWARD_ENABLED;
        
#if defined(VTSS_FEATURE_LAYER3)
    {
        uint mc_size;

        /* Initialize ARP table size */
        mc_size = (setup->ipmc_size > VTSS_IPMC_SIZE_6144 ? VTSS_IPMC_SIZE_6144 : 
                   setup->ipmc_size);
        vs->mc_size = mc_size;
        vs->arp_size = (VTSS_ARPIDS - 4 * (mc_size ? (1 << mc_size) : 0));
        
        /* Initialize VRRP base address */
        vs->vrrp_base.addr[0] = 0x00;
        vs->vrrp_base.addr[1] = 0x00;
        vs->vrrp_base.addr[2] = 0x5E;
        vs->vrrp_base.addr[3] = 0x00;
        vs->vrrp_base.addr[4] = 0x01;
        vs->vrrp_base.addr[5] = 0x00;
    }
    vs->rlid_end = VTSS_RLID_END;
#endif /* VTSS_FEATURE_LAYER3 */
    vs->init_setup = *setup; 

#if defined(VTSS_FEATURE_LAYER2)
#if (VTSS_OPT_MAC_NEXT_MAX != 0)
    /* Initialize MAC address table */
    for (i = 0; i < VTSS_MAC_ADDRS; i++) {
        /* Insert first in free list */
        vs->mac_table[i].next = vs->mac_list_free;
        vs->mac_list_free = &vs->mac_table[i];
    }
#endif /* VTSS_OPT_MAC_NEXT_MAX */
#endif /* VTSS_FEATURE_LAYER2 */

#if defined(VTSS_FEATURE_QCL_PORT)
    {
        vtss_qcl_id_t    qcl_id;
        vtss_qcl_t       *qcl;
        vtss_qcl_entry_t *qcl_entry;

        /* Initialize QCL free/used lists */
        for (qcl_id = VTSS_QCL_ID_START; qcl_id < VTSS_QCL_ID_END; qcl_id++) {
            qcl = &vs->qcl[qcl_id];
            for (i = 0; i < VTSS_QCL_LIST_SIZE; i++) {
                qcl_entry = &qcl->qcl_list[i];
                /* Insert in free list */
                qcl_entry->next = qcl->qcl_list_free;
                qcl->qcl_list_free = qcl_entry;
            }
        }
    }
#endif /* VTSS_FEATURE_QCL_PORT */
}

uint vtss_sizeof_al(void) 
{
#if defined(VTSS_BASIC_TRACE_USE_ADVANCED)
    vtss_basic_trace_register();
#endif

    return sizeof(*vtss_api_state);
}

vtss_rc vtss_select_chip(vtss_state_t * const state)
{
    vtss_api_state = state->al;
    vs = vtss_api_state;
    vtss_state = state;
#if !defined(VTSS_CHIPS)
    vtss_io_select_chip(&state->io);
#endif
#if (defined(VTSS_FORCE_CPLD_MIIM) || !defined(VTSS_API)) && defined(VTSS_VITGENIO)
    VTSS_D(("vtss_select_chip: fd set for phy_io"));
    ((vtss_phy_state_t *) (state->phy))->io.fd = state->io.fd;
#endif
    vtss_phy_select_context(state->phy);
    return VTSS_OK;
}

vtss_rc vtss_init_get(vtss_init_setup_t * const setup)
{
    memset(setup, 0, sizeof(*setup));
    
    setup->reset_chip = 1;
#if defined(VTSS_FEATURE_PI_WIDTH)
    setup->pi_width = VTSS_PI_WIDTH_16;
#endif /* VTSS_FEATURE_PI_WIDTH */
#if defined(VTSS_ARCH_B2)
    {
        vtss_spi4_setup_t *spi4;
        vtss_xaui_setup_t *xaui;
        vtss_qs_setup_t   *qs;

        /* General parameters */
        setup->host_mode = 4;
        setup->stag_etype = 0x88a8;
        setup->sch_max_rate = 1000000; /* 1 Gbps */

        /* Queue system */
        qs = &setup->qs;
        qs->rx_share = 0;
        qs->mtu = VTSS_MAXFRAMELENGTH_STANDARD;

        /* SPI-4 */
        spi4 = &setup->spi4;
        spi4->fc.enable = 1;
        spi4->qos.shaper.rate = VTSS_BITRATE_FEATURE_DISABLED;
        spi4->ib.fcs = VTSS_SPI4_FCS_CHECK;
        spi4->ib.clock = VTSS_SPI4_CLOCK_450_TO_500;
        spi4->ob.clock = VTSS_SPI4_CLOCK_500_0;
        spi4->ob.burst_size = VTSS_SPI4_BURST_128;
        spi4->ob.max_burst_1 = 64;
        spi4->ob.max_burst_2 = 32;
        spi4->ob.link_up_limit = 2;
        spi4->ob.link_down_limit = 2;
        spi4->ob.training_mode = VTSS_SPI4_TRAINING_AUTO;
        spi4->ob.alpha = 1;
        spi4->ob.data_max_t = 10240;

        /* XAUI */
        xaui = &setup->xaui;
        xaui->qos.shaper.rate = VTSS_BITRATE_FEATURE_DISABLED;
    }
#endif /* VTSS_ARCH_B2 */

    return VTSS_OK;
}

vtss_rc vtss_init(const vtss_init_setup_t * const setup)
{
#if defined(VTSS_FEATURE_LAYER2)
    vtss_port_no_t             port_no;
    vtss_vlan_port_mode_t      vlan_mode;
    BOOL                       member[VTSS_PORT_ARRAY_SIZE];
#endif /* VTSS_FEATURE_LAYER2 */

    VTSS_D(("enter"));

    /* Initialize API state information */
    vtss_init_state(setup);

    /* Initialize Low Level Layer */
    VTSS_RC(vtss_ll_init(setup));
    
#if VTSS_OPT_ICPU_LOAD
    return VTSS_OK;
#endif /* VTSS_OPT_ICPU_LOAD */

    if (setup->reset_chip) {
#if defined(VTSS_FEATURE_LAYER2)
        /* Setup in VLAN unaware mode including all ports in VLAN 1 with PVID 1 */
        vlan_mode.aware = 0;
        vlan_mode.pvid = VTSS_VID_DEFAULT;
        vlan_mode.frame_type = VTSS_VLAN_FRAME_ALL;
        vlan_mode.untagged_vid = VTSS_VID_DEFAULT;
#if defined(VTSS_FEATURE_VLAN_INGR_FILTER_PORT)
        vlan_mode.ingress_filter = 0;
#endif /* VTSS_FEATURE_VLAN_INGR_FILTER_PORT */
#if defined(VTSS_FEATURE_VLAN_TYPE_STAG)
        vlan_mode.stag = 0;
#endif /* VTSS_FEATURE_VLAN_TYPE_STAG */
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            VTSS_RC(vtss_vlan_port_mode_set(port_no, &vlan_mode));
            member[port_no] = 1;
        }
        VTSS_RC(vtss_vlan_port_members_set(VTSS_VID_DEFAULT, member));
        
        /* Setup the broadcast entry in the PGID table */
        VTSS_RC(vtss_pgid_table_write(VTSS_PGID_BC));
#endif /* VTSS_FEATURE_LAYER2 */

#if defined(VTSS_FEATURE_CPU_RX_TX)
        {
            vtss_cpu_rx_registration_t reg;
#if defined(VTSS_FEATURE_CPU_RX_REG_BPDU_ADV)
            int                        i;
#endif /* VTSS_FEATURE_CPU_RX_REG_BPDU_ADV */

            /* Initialize CPU frame registration, enable BPDUs */
            memset(&reg, 0, sizeof(reg));
#if defined(VTSS_FEATURE_CPU_RX_REG_BPDU_ADV)
            for (i=0; i<16; i++) {
                reg.bpdu_cpu_only[i] = 1;
            }
#else
            reg.bpdu_cpu_only = 1;
#endif /* VTSS_FEATURE_CPU_RX_REG_BPDU_ADV */
            
#if defined(VTSS_FEATURE_LAYER3)
            /* Copy broadcasts matching Router Legs */
            reg.bcast_rl_match_all = 1;
#endif /* VTSS_FEATURE_LAYER3 */
            VTSS_RC(vtss_cpu_rx_registration_set(&reg));
        }
#endif /* VTSS_FEATURE_CPU_RX_TX */

#if defined(VTSS_ARCH_GATWICK)
        {
            vtss_msti_t msti;
            
            /* Initialize MSTP table */
            for (msti = VTSS_MSTI_START; msti < vs->msti_end; msti++) {
                for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
                    VTSS_RC(vtss_port_mstp_state_set(port_no, msti, 
                                                     vs->mstp_table[msti].state[port_no]));
                }
            }
        }
#endif /* VTSS_ARCH_GATWICK */
    }

    /* Initialize PHY API */
    {
        vtss_phy_init_setup_t phy_setup;

        phy_setup.ports = VTSS_PORTS;

        VTSS_RC(vtss_phy_init(&phy_setup));
    }
    return VTSS_OK;
}

/* - Chip ID and revision ------------------------------------------ */

vtss_rc vtss_chipid_get(vtss_chipid_t * const chipid)
{
    VTSS_D(("enter"));

    return vtss_ll_chipid_get(chipid);
}

#if defined(VTSS_FEATURE_LAYER2)
#if (VTSS_OPT_MAC_NEXT_MAX != 0)
static vtss_mac_entry_t *vtss_mac_table_get(ulong mach, ulong macl, BOOL next)
{
    uint             first,last,mid;
    vtss_mac_entry_t *cur,*old;
    
    /* Check if table is empty */
    if (vs->mac_ptr_count == 0)
        return NULL;

    /* Locate page using binary search */
    for (first = 0, last = vs->mac_ptr_count-1; first != last; ) {
        mid = (first + last)/2;
        cur = vs->mac_list_ptr[mid];
        if (cur->mach > mach || (cur->mach == mach && cur->macl >= macl)) {
            /* Entry greater or equal, search lower half */
            last = mid; 
        } else {
            /* Entry is smaller, search upper half */
            first = mid + 1;
        }
    }

    cur = vs->mac_list_ptr[first];
    /* Go back one page if entry greater */
    if (first != 0 && (cur->mach > mach || (cur->mach == mach && cur->macl > macl)))
        cur = vs->mac_list_ptr[first-1]; 
    
    /* Look for greater entry using linear search */
    for (old = NULL; cur != NULL; old = cur, cur = cur->next)
        if (cur->mach > mach || (cur->mach == mach && cur->macl > macl))
            break;

    return (next ? cur : old);
}

/* Update MAC table page pointers */
static void vtss_mac_pages_update(void)
{
    uint             i,count;
    vtss_mac_entry_t *cur;

    for (i = 0, cur = vs->mac_list_used; i < VTSS_MAC_PTR_SIZE && cur!=NULL ; i++) {
        vs->mac_list_ptr[i] = cur;

        /* Move one page forward */
        for (count = 0; count != VTSS_MAC_PAGE_SIZE && cur != NULL ; cur = cur->next, count++)
            ;
    }
    vs->mac_ptr_count = i;
}

static void vtss_mach_macl_get(const vtss_vid_mac_t *vid_mac, ulong *mach, ulong *macl)
{
    *mach = ((vid_mac->vid<<16) | (vid_mac->mac.addr[0]<<8) | vid_mac->mac.addr[1]);
    *macl = ((vid_mac->mac.addr[2]<<24) | (vid_mac->mac.addr[3]<<16) | 
             (vid_mac->mac.addr[4]<<8) | vid_mac->mac.addr[5]);
}

/* Add MAC table entry */
static vtss_mac_entry_t *vtss_mac_table_add(const vtss_vid_mac_t *vid_mac, BOOL update)
{
    ulong            mach, macl;
    vtss_mac_entry_t *cur, *tmp;

    /* Calculate MACH and MACL */
    vtss_mach_macl_get(vid_mac, &mach, &macl);
    
    /* Look for previous or existing entry in used list */
    if ((tmp = vtss_mac_table_get(mach, macl, 0)) != NULL && 
        tmp->mach == mach && tmp->macl == macl)
        return tmp;
    
    /* Allocate entry from free list */
    if ((cur = vs->mac_list_free) == NULL) {
        VTSS_E(("no free MAC entries"));
        return NULL;
    }
    vs->mac_list_free = cur->next;
    cur->mach = mach;
    cur->macl = macl;
    
    if (tmp == NULL) {
        /* Insert first */
        cur->next = vs->mac_list_used;
        vs->mac_list_used = cur;
        vs->mac_list_ptr[0] = cur; /* Update first page pointer */ 
        if (vs->mac_ptr_count == 0)
            vs->mac_ptr_count = 1;
    } else {
        /* Insert after previous entry */
        cur->next = tmp->next;
        tmp->next = cur;
    }
    
    /* Update page pointers */
    if (update)
        vtss_mac_pages_update();
        
    return cur;
}

#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
/* Delete MAC table entry */
static vtss_rc vtss_mac_table_del(const vtss_vid_mac_t *vid_mac)
{
    ulong            mach, macl;
    vtss_mac_entry_t *cur, *old;

    /* Calculate MACH and MACL */
    vtss_mach_macl_get(vid_mac, &mach, &macl);
    
    /* Look for entry */
    for (old = NULL, cur = vs->mac_list_used; cur != NULL; old = cur, cur = cur->next) {
        if (cur->mach == mach && cur->macl == macl) {
            /* Remove from used list */
            if (old == NULL)
                vs->mac_list_used = cur->next;
            else
                old->next = cur->next;
            
            /* Insert in free list */
            cur->next = vs->mac_list_free;
            vs->mac_list_free = cur;
            break;
        }
    }
    
    vtss_mac_pages_update();

    return VTSS_OK;
}

/* Update IPv4 and IPv6 multicast entries on aggregation changes */
static vtss_rc vtss_mac_table_update(void) 
{
    vtss_pgid_no_t         pgid_no;
    vtss_mac_entry_t       *cur;
    vtss_port_no_t         port_no;
    vtss_pgid_entry_t      *pgid_entry;
    vtss_mac_table_entry_t mac_entry;
    vtss_vid_mac_t         *vid_mac;

    pgid_no = VTSS_PGID_NONE;
    pgid_entry = &vs->pgid_table[pgid_no];
    mac_entry.copy_to_cpu = 0;
    mac_entry.locked = 1;
    mac_entry.aged = 0;
    vid_mac = &mac_entry.vid_mac;
    for (cur = vs->mac_list_used; cur != NULL; cur = cur->next) {
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
            pgid_entry->member[port_no] = VTSS_PORT_BF_GET(cur->member, port_no);
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
            pgid_entry->member[port_no] = vtss_pgid_member(pgid_no, port_no);
        vid_mac->vid = ((cur->mach>>16) & 0xfff);
        vid_mac->mac.addr[0] = ((cur->mach>>8) & 0xff);
        vid_mac->mac.addr[1] = ((cur->mach>>0) & 0xff);
        vid_mac->mac.addr[2] = ((cur->macl>>24) & 0xff);
        vid_mac->mac.addr[3] = ((cur->macl>>16) & 0xff);
        vid_mac->mac.addr[4] = ((cur->macl>>8) & 0xff);
        vid_mac->mac.addr[5] = ((cur->macl>>0) & 0xff);
        vtss_ll_mac_table_learn(&mac_entry, pgid_no);
    }
    
    return VTSS_OK;
}

#else

/* - Optimization functions ---------------------------------------- */

static vtss_rc vtss_mac_table_optimize(void)
{
    uint                   i,block;
    vtss_mac_table_entry_t entry;
    vtss_pgid_no_t         pgid_no;
    vtss_mac_entry_t       *cur,*old,*tmp;

    /* If update is not in progress, check if MAC address table has changed */
    if (vs->mac_index_next == 0) {
        VTSS_RC(vtss_mac_table_status_read());
        if (vs->mac_status_next.learned || 
            vs->mac_status_next.replaced || 
            vs->mac_status_next.aged) {
            vs->mac_status_next.learned = 0;
            vs->mac_status_next.replaced = 0;
            vs->mac_status_next.aged = 0;
        } else {
            return VTSS_OK;
        }
    }
    
    VTSS_D(("update start, index: %d",vs->mac_index_next));

    /* Delete entries from current block */
    block = vs->mac_index_next/VTSS_OPT_MAC_NEXT_MAX;
    for (cur = vs->mac_list_used, old = NULL; cur != NULL; ) {
        if (cur->block == block) {
            /* Remove from used list */
            if (old == NULL)
                vs->mac_list_used = cur->next;
            else
                old->next = cur->next;
            
            /* Insert in free list */
            tmp = cur;
            cur = cur->next;
            tmp->next = vs->mac_list_free;
            vs->mac_list_free = tmp;
        } else {
            old = cur;
            cur = cur->next;
        }
    }

    /* Update page pointers */
    vtss_mac_pages_update();
    
    /* Insert entries from current block */
    for (i = vs->mac_index_next; (i/VTSS_OPT_MAC_NEXT_MAX) == block ; i++) {
        /* Read and add MAC address entry */
        if (vtss_ll_mac_table_read(i + VTSS_MAC_ADDR_START, &entry, &pgid_no) == VTSS_OK &&
            (cur = vtss_mac_table_add(&entry.vid_mac, 0)) != NULL)
            cur->block = block;
    }
    vs->mac_index_next = (i==vs->mac_addrs ? 0 : i);
    
    /* Update page pointers */
    vtss_mac_pages_update();
    VTSS_D(("update done, index: %d",vs->mac_index_next));

    return VTSS_OK;
}
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
#endif /* VTSS_OPT_MAC_NEXT_MAX */
#endif /* VTSS_FEATURE_LAYER2 */

vtss_rc vtss_optimize_1sec(void)
{
    VTSS_RC(vtss_ll_optimize_1sec());

#if defined(VTSS_FEATURE_LAYER2)
#if (VTSS_OPT_MAC_NEXT_MAX != 0)
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    /* No update required for targets supporting GET_NEXT */
#else
    VTSS_RC(vtss_mac_table_optimize());
#endif
#endif /* VTSS_OPT_MAC_NEXT_MAX */
#endif /* VTSS_FEATURE_LAYER2 */
    return VTSS_OK;
}

vtss_rc vtss_optimize_100msec(void)
{
#if defined(VTSS_ARCH_HEATHROW)
    return vtss_ll_optimize_100msec();
#endif /* VTSS_ARCH_HEATHROW */
    
    return VTSS_OK;
}

/* - GPIOs --------------------------------------------------------- */
#if defined(VTSS_GPIOS)

#ifdef VTSS_CHIPS
vtss_rc vtss_gpio_direction_set(vtss_chip_no_t chip_no, vtss_gpio_no_t gpio_no, BOOL output)
#else
vtss_rc vtss_gpio_direction_set(vtss_gpio_no_t gpio_no, BOOL output)
#endif /* VTSS_CHIPS */
{
    VTSS_D(("gpio_no: %d, output: %d",gpio_no,output));

    if (gpio_no<VTSS_GPIO_NO_START || gpio_no>=VTSS_GPIO_NO_END) {
        VTSS_E(("illegal gpio_no: %d",gpio_no));
        return VTSS_INVALID_PARAMETER;
    }

#ifdef VTSS_CHIPS
    vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

    return vtss_ll_gpio_direction_set(gpio_no,output);
}

#ifdef VTSS_CHIPS
vtss_rc vtss_gpio_input_read(vtss_chip_no_t chip_no, vtss_gpio_no_t gpio_no, BOOL * const value)
#else
vtss_rc vtss_gpio_input_read(vtss_gpio_no_t gpio_no, BOOL * const value)
#endif /* VTSS_CHIPS */
{
    VTSS_D(("gpio_no: %d",gpio_no));

#ifdef VTSS_CHIPS
    vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

    return vtss_ll_gpio_input_read(gpio_no,value);
}

#ifdef VTSS_CHIPS
vtss_rc vtss_gpio_output_write(vtss_chip_no_t chip_no, vtss_gpio_no_t gpio_no, BOOL value)
#else
vtss_rc vtss_gpio_output_write(vtss_gpio_no_t gpio_no, BOOL value)
#endif /* VTSS_CHIPS */
{
    VTSS_D(("gpio_no: %d, value: %d",gpio_no,value));

#ifdef VTSS_CHIPS
    vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

    return vtss_ll_gpio_output_write(gpio_no,value);
}

#endif /* VTSS_GPIOS */

/* - Serial LED ---------------------------------------------------- */

#if defined(VTSS_FEATURE_SERIAL_LED)
vtss_rc vtss_serial_led_set(const vtss_led_port_t port, 
                            const vtss_led_mode_t mode[3])
{
    return vtss_ll_serial_led_set(port, mode);
}
#endif /* VTSS_FEATURE_SERIAL_LED */

#if defined(VTSS_ARCH_B2)
vtss_rc vtss_psi_set(const uint clock)
{
    return vtss_ll_psi_set(clock);
}
#endif /* VTSS_ARCH_B2 */

/* - Direct register access (for debugging only) ------------------- */

#ifdef VTSS_CHIPS
vtss_rc vtss_register_read(vtss_chip_no_t chip_no, const ulong reg, ulong *value)
#else
vtss_rc vtss_register_read(const ulong reg, ulong *value)
#endif /* VTSS_CHIPS */
{
    VTSS_D(("reg: 0x%08lx",reg));

#ifdef VTSS_CHIPS
    vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

    return vtss_ll_register_read(reg,value);
}

#ifdef VTSS_CHIPS
vtss_rc vtss_register_write(vtss_chip_no_t chip_no, const ulong reg, const ulong value)
#else
vtss_rc vtss_register_write(const ulong reg, const ulong value)
#endif /* VTSS_CHIPS */
{
    VTSS_D(("reg: 0x%08lx, value: 0x%08lx",reg,value));

#ifdef VTSS_CHIPS
    vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

    return vtss_ll_register_write(reg, value);
}

#ifdef VTSS_CHIPS
vtss_rc vtss_register_writemasked(vtss_chip_no_t chip_no, const ulong reg, 
                                  const ulong value, const ulong mask)
#else
vtss_rc vtss_register_writemasked(const ulong reg, const ulong value, const ulong mask)
#endif /* VTSS_CHIPS */
{
    ulong   val;

    VTSS_D(("reg: 0x%08lx, value: 0x%08lx, mask: 0x%08lx",reg,value,mask));
#ifdef VTSS_CHIPS
    VTSS_RC(vtss_register_read(chip_no, reg, &val));
    VTSS_RC(vtss_register_write(chip_no, reg, (val & ~mask) | (value & mask)));
#else
    VTSS_RC(vtss_register_read(reg, &val));
    VTSS_RC(vtss_register_write(reg, (val & ~mask) | (value & mask)));
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

#if defined(VTSS_FEATURE_INTERRUPTS)
vtss_rc vtss_intr_mask_set(vtss_intr_t *mask) {
    VTSS_RC(vtss_ll_intr_mask_set(mask));
    return VTSS_OK;
}

vtss_rc vtss_intr_status_get(vtss_intr_t *status) {
    VTSS_RC(vtss_ll_intr_status_get(status));
    return VTSS_OK;
}
#endif /* VTSS_FEATURE_INTERRUPTS  */

/* ================================================================= *
 *  Port and PHY
 * ================================================================= */

/* - Port mapping -------------------------------------------------- */

vtss_rc vtss_port_map_set(const vtss_mapped_port_t mapped_ports[VTSS_PORT_ARRAY_SIZE])
{
    vtss_port_no_t port_no;
    int            chip_port;
    int            chip_port_count[VTSS_CHIP_PORTS];
    
    /* Clear chip port count array */
    memset(chip_port_count,0,sizeof(chip_port_count));
    
    VTSS_D(("enter"));

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        chip_port = mapped_ports[port_no].chip_port;
        vs->port_map.chip_port[port_no] = chip_port;
        vs->port_map.vtss_port_unused[port_no] = MAKEBOOL01(chip_port < 0);
        if (chip_port >= 0) {
#if defined(VTSS_CHIPS)
            vs->port_map.vtss_port[mapped_ports[port_no].chip_no][chip_port] = port_no;
#else
            vs->port_map.vtss_port[chip_port] = port_no;
#endif /* VTSS_CHIPS */
            chip_port_count[chip_port]++;
        }

#if VTSS_OPT_INT_AGGR
        /* Map chip port 25/27 to the same port as chip port 24/26 */
        if (chip_port == VTSS_CHIP_PORT_AGGR_0 || chip_port == VTSS_CHIP_PORT_AGGR_1)
            vs->port_map.vtss_port[chip_port+1] = port_no;
#endif /* VTSS_OPT_INT_AGGR */        
        
        /* MII mapping */
        vs->port_map.phy_addr[port_no] = mapped_ports[port_no].phy_addr;
        vs->port_map.miim_controller[port_no] = mapped_ports[port_no].miim_controller;
        vtss_phy_map_port( port_no,
#if defined(VTSS_CHIPS)
                           VTSS_PHY_BUS(mapped_ports[port_no].chip_no,mapped_ports[port_no].miim_controller),
#else
                           VTSS_PHY_BUS(mapped_ports[port_no].miim_controller),
#endif
                           mapped_ports[port_no].phy_addr );

#if defined(VTSS_CHIPS)
        /* Chip port number */
        vs->port_map.chip_no[port_no] = mapped_ports[port_no].chip_no;
#endif /* VTSS_CHIPS */
    }

    /* Make sure all ports are mapped */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (vs->port_map.chip_port[port_no] < 0) {
#if defined(VTSS_CHIPS)
            /* All ports must be mapped for 48-port solutions */
            VTSS_E(("port_no: %d not mapped",port_no));
            return VTSS_UNSPECIFIED_ERROR;
#else
            vtss_port_no_t port;

            /* Port is unmapped, look for the first unused chip port */
            for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
                chip_port = vs->port_map.chip_ports_all[port];
                if (chip_port_count[chip_port] == 0) {
                    VTSS_D(("Mapping unused port_no: %d to chip_port: %d",port_no,chip_port));
                    vs->port_map.chip_port[port_no] = chip_port;
                    vs->port_map.vtss_port[chip_port] = port_no;
                    chip_port_count[chip_port]++;
                    break;
                }
            }
#endif /* VTSS_CHIPS */
        }
    }
    
#if defined(VTSS_CHIPS)
#if defined(VTSS_ARCH_GATWICK)
    if (vs->gw1e) {
        /* Update source and destination masks */
        VTSS_RC(vtss_update_masks(1, 1, 0));
    } else
#endif /* VTSS_ARCH_GATWICK */
    {
        /* Update source masks */
        VTSS_RC(vtss_update_masks(1, 0, 0));
    }
#endif /* VTSS_CHIPS */

#if VTSS_OPT_INT_AGGR    
    /* Update destination masks */
    VTSS_RC(vtss_update_masks(0, 1, 0));
#endif /* VTSS_OPT_INT_AGGR */

#if defined(VTSS_ARCH_B2)
    VTSS_RC(vtss_ll_port_map_set(mapped_ports));
#endif /* VTSS_ARCH_B2 */    

    return VTSS_OK;
}

/* - IEEE 802.3 clause 22 PHY access functions --------------------- */

vtss_rc vtss_register_phy_read(
#if defined(VTSS_CHIPS)
                               const vtss_chip_no_t         chip_no,
#endif
                               const vtss_miim_controller_t miim_controller,
                               const uint                   phy_addr,
                               const uint                   phy_reg,
                               ushort *const                value)
{
#if defined(VTSS_CHIPS)
    vtss_phy_map_port(0,VTSS_PHY_BUS(chip_no,miim_controller),phy_addr);
#else
    vtss_phy_map_port(0,VTSS_PHY_BUS(miim_controller),phy_addr);
#endif
    return vtss_phy_read(0,phy_reg,value);
}

vtss_rc vtss_register_phy_write(
#if defined(VTSS_CHIPS)
                                const vtss_chip_no_t         chip_no,
#endif
                                const vtss_miim_controller_t miim_controller,
                                const uint                   phy_addr,
                                const uint                   phy_reg,
                                const ushort                 value)
{
#if defined(VTSS_CHIPS)
    vtss_phy_map_port(0,VTSS_PHY_BUS(chip_no,miim_controller),phy_addr);
#else
    vtss_phy_map_port(0,VTSS_PHY_BUS(miim_controller),phy_addr);
#endif
    return vtss_phy_write(0,phy_reg,value);
}

vtss_rc vtss_register_phy_writemasked(
#if defined(VTSS_CHIPS)
                                      const vtss_chip_no_t         chip_no,
#endif
                                      const vtss_miim_controller_t miim_controller,
                                      const uint                   phy_addr,
                                      const uint                   phy_reg,
                                      const ushort                 value,
                                      const ushort                 mask)
{
#if defined(VTSS_CHIPS)
    vtss_phy_map_port(0,VTSS_PHY_BUS(chip_no,miim_controller),phy_addr);
#else
    vtss_phy_map_port(0,VTSS_PHY_BUS(miim_controller),phy_addr);
#endif
    return vtss_phy_writemasked(0,phy_reg,value,mask);
}

vtss_rc vtss_miim_phy_read(
#if defined(VTSS_CHIPS)
                            const vtss_chip_no_t            chip_no,
#endif
                            const vtss_miim_controller_t    miim_controller,
                            const uint                      addr,
                            const uint                      reg,
                            ushort *const                   value )
{
    /* Validate parameters */
    if (miim_controller >= VTSS_MIIM_CONTROLLERS) {
        VTSS_E(("MII controller %d not valid",miim_controller));
        return VTSS_INVALID_PARAMETER;
    }
    if (addr >= 0x20) {
        VTSS_E(("addr %d not valid",addr));
        return VTSS_INVALID_PARAMETER;
    }
    if (reg >= 0x20) {
        VTSS_E(("reg %d not valid",reg));
        return VTSS_INVALID_PARAMETER;
    }

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

    return vtss_ll_phy_read(miim_controller, addr, reg, value);
}

vtss_rc vtss_miim_phy_write(
#if defined(VTSS_CHIPS)
                            const vtss_chip_no_t            chip_no,
#endif
                            const vtss_miim_controller_t    miim_controller,
                            const uint                      addr,
                            const uint                      reg,
                            const ushort                    value )
{
    /* Validate parameters */
    if (miim_controller >= VTSS_MIIM_CONTROLLERS) {
        VTSS_E(("MII controller not valid (miim=%d addr=%d reg=%d value=0x%x)",miim_controller, addr, reg, value));
        return VTSS_INVALID_PARAMETER;
    }
    if (addr >= 0x20) {
        VTSS_E(("addr not valid (miim=%d addr=%d reg=%d value=0x%x)",miim_controller, addr, reg, value));
        return VTSS_INVALID_PARAMETER;
    }
    if (reg >= 0x20) {
        VTSS_E(("reg not valid (miim=%d addr=%d reg=%d value=0x%x)",miim_controller, addr, reg, value));
        return VTSS_INVALID_PARAMETER;
    }

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

    return vtss_ll_phy_write(miim_controller, addr, reg, value);
}

vtss_rc vtss_miim_phy_writemasked(
#if defined(VTSS_CHIPS)
                                    const vtss_chip_no_t            chip_no,
#endif
                                    const vtss_miim_controller_t    miim_controller,
                                    const uint                      addr,
                                    const uint                      reg,
                                    const ushort                    value,
                                    const ushort                    mask )
{
    ushort val;

    /* Validate parameters */
    if (miim_controller >= VTSS_MIIM_CONTROLLERS) {
        VTSS_E(("MII controller %d not valid",miim_controller));
        return VTSS_INVALID_PARAMETER;
    }
    if (addr >= 0x20) {
        VTSS_E(("addr %d not valid",addr));
        return VTSS_INVALID_PARAMETER;
    }
    if (reg >= 0x20) {
        VTSS_E(("reg %d not valid",reg));
        return VTSS_INVALID_PARAMETER;
    }

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */    

    VTSS_RC(vtss_ll_phy_read(miim_controller, addr, reg, &val));
    return vtss_ll_phy_write(miim_controller, addr, reg, (val & ~mask) | (value & mask));
}


/* - TBI Auto-Negotiation and Status ------------------------------- */

#if defined(VTSS_FEATURE_TBI)
static vtss_rc vtss_tbi_enabled(const vtss_port_no_t port_no, BOOL *enabled)
{
    VTSS_N(("port_no: %d",port_no));

    return vtss_ll_port_tbi_enabled(port_no, enabled);
}

vtss_rc vtss_tbi_autoneg_control_get(const vtss_port_no_t port_no,
                                     vtss_tbi_autoneg_control_t * const control)
{
    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_ll_port_tbi_autoneg_enabled(port_no, &control->enable));
    return (control->enable ? 
            vtss_ll_port_tbi_get_aneg_advertisement(port_no, &control->advertisement) : 
            VTSS_OK);
}

vtss_rc vtss_tbi_autoneg_control_set(const vtss_port_no_t port_no,
                                     const vtss_tbi_autoneg_control_t * const control)
{
    VTSS_N(("port_no: %d",port_no));

    if (control->enable && control->advertisement.hdx)
        return VTSS_INVALID_PARAMETER;        /* Not supported, so don't advertise it. */

#if defined(VTSS_ARCH_GATWICK)
    return vtss_ll_port_tbi_aneg_enable(port_no, &control->advertisement);
#endif
#if defined(VTSS_ARCH_HEATHROW) || defined(VTSS_ARCH_B2)
    return vtss_ll_port_tbi_aneg_control(port_no,control);
#endif /* VTSS_ARCH_HEATHROW/B2 */
}

vtss_rc vtss_tbi_autoneg_restart(const vtss_port_no_t port_no)
{
    VTSS_N(("port_no: %d",port_no));

    return vtss_ll_port_tbi_aneg_restart(port_no);
}

vtss_rc vtss_tbi_status_get(const vtss_port_no_t port_no,
                            vtss_tbi_status_t * const status)
{
    BOOL enabled;
    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_tbi_enabled(port_no, &enabled));
    if (!enabled)
        return VTSS_TBI_DISABLED;

    return vtss_ll_port_tbi_status_get(port_no, status);
}

#endif /* VTSS_FEATURE_TBI */

/* - IEEE 802.3 clause 45 PHY access functions --------------------- */

#if defined(VTSS_FEATURE_10G)

BOOL vtss_port_no_is_10g(vtss_port_no_t port_no) 
{
    return VTSS_PORT_IS_10G(vtss_api_state->port_map.chip_port[port_no]);
}

vtss_rc vtss_mmd_read(const vtss_port_no_t port_no,
                      const uint           mmd, 
                      const uint           phy_reg,
                      ushort *const        value)
{
    uint mii_controller; 

    VTSS_N(("port_no: %d, mmd: 0x%02x, phy_reg: 0x%02x",port_no,mmd,phy_reg));

    /* Check that the port number is valid */
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }

    /* Check that the MII controller is mapped */
    mii_controller = vs->port_map.miim_controller[port_no];
    if (mii_controller == VTSS_MIIM_CONTROLLER_NONE) {
        VTSS_E(("MII controller not mapped for port_no: %d",port_no));
        return VTSS_PHY_NOT_MAPPED;
    }
    
#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */    
    
    return vtss_ll_mmd_read(mii_controller, vs->port_map.phy_addr[port_no], mmd, phy_reg, value);
}

vtss_rc vtss_mmd_write(const vtss_port_no_t port_no,
                       const uint mmd,
                       const uint phy_reg, 
                       const ushort value)
{
    uint mii_controller;

    VTSS_N(("port_no: %d, mmd: 0x%02x, phy_reg: 0x%02x, value: 0x%04x",port_no,mmd,phy_reg,value));

    /* Check that the port number is valid */
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    /* Check that the MII controller is mapped */
    mii_controller = vs->port_map.miim_controller[port_no];
    if (mii_controller == VTSS_MIIM_CONTROLLER_NONE) {
        VTSS_E(("MII controller not mapped for port_no: %d",port_no));
        return VTSS_PHY_NOT_MAPPED;
    }
    
#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */    
    
    return vtss_ll_mmd_write(mii_controller, vs->port_map.phy_addr[port_no], mmd, phy_reg, value);
}

vtss_rc vtss_mmd_writemasked(const vtss_port_no_t port_no,
                             const uint mmd,
                             const uint phy_reg,
                             const ushort value, 
                             const ushort mask)
{
    ushort data;

    VTSS_N(("port_no: %d, mmd: 0x%02x, phy_reg: 0x%02x, value: 0x%04x, mask: 0x%04x",
            port_no,mmd,phy_reg,value,mask));
    
    /* Check that the port number is valid */
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    /* Check that the MII controller is mapped */
    if (vs->port_map.miim_controller[port_no] == VTSS_MIIM_CONTROLLER_NONE) {
        VTSS_E(("MII controller not mapped for port_no: %d",port_no));
        return VTSS_PHY_NOT_MAPPED;
    }
    
    VTSS_RC(vtss_mmd_read(port_no, mmd, phy_reg, &data));
    return vtss_mmd_write(port_no, mmd, phy_reg, (data & ~mask) | (value & mask));
}

vtss_rc vtss_mmd_reset(const vtss_port_no_t port_no)
{
    ushort data;
    uint   mmd;

    VTSS_N(("port_no: %d",port_no));

    /* Try to reset the first 5 MMDs */
    for (mmd = VTSS_MMD_PMA_PMD; mmd <= VTSS_MMD_DTE_XS; mmd++) {
        
        if (vtss_mmd_writemasked(port_no, mmd, MMD_CTRL_1, MMD_CTRL_1_RESET, MMD_CTRL_1_RESET)>=0) {
            while (vtss_mmd_read(port_no, mmd, MMD_CTRL_1, &data) >= 0 &&
                   (data & MMD_CTRL_1_RESET))
                ;
        }
    }
    return VTSS_OK;
}

vtss_rc vtss_mmd_devices_get(const uint port_no, uint mmd, vtss_mmd_devices_t *devices)
{
    ushort data;

    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_DEV_1, &data));

    devices->dte_xs  = MAKEBOOL01(data & MMD_DEV_1_DTE_XS);
    devices->phy_xs  = MAKEBOOL01(data & MMD_DEV_1_PHY_XS);
    devices->pcs     = MAKEBOOL01(data & MMD_DEV_1_PCS);
    devices->wis     = MAKEBOOL01(data & MMD_DEV_1_WIS);
    devices->pma_pmd = MAKEBOOL01(data & MMD_DEV_1_PMD_PMA);
    devices->cl_22   = MAKEBOOL01(data & MMD_DEV_1_CL_22);
    
    return VTSS_OK;
}

vtss_rc vtss_mmd_pma_pmd_capability_get(const uint port_no,
                                         vtss_mmd_pma_pmd_capability_t *capability)
{
    ushort data;
    uint   mmd = VTSS_MMD_PMA_PMD;

    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_SPEED_AB, &data));
    capability->ability_10g = MAKEBOOL01(data & MMD_SPEED_AB_10G);

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_1, &data));
    capability->lowpower = MAKEBOOL01(data & MMD_STAT_1_LOWPOW_AB);

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_2, &data));
    capability->transmit_fault      = MAKEBOOL01(data & (1 << 13));
    capability->receive_fault       = MAKEBOOL01(data & (1 << 12));
    capability->tx_disable          = MAKEBOOL01(data & (1 << 8));
    capability->ability_10gbase_sr  = MAKEBOOL01(data & (1 << 7));
    capability->ability_10gbase_lr  = MAKEBOOL01(data & (1 << 6));
    capability->ability_10gbase_er  = MAKEBOOL01(data & (1 << 5));
    capability->ability_10gbase_lx4 = MAKEBOOL01(data & (1 << 4));
    capability->ability_10gbase_sw  = MAKEBOOL01(data & (1 << 3));
    capability->ability_10gbase_lw  = MAKEBOOL01(data & (1 << 2));
    capability->ability_10gbase_ew  = MAKEBOOL01(data & (1 << 1));
    capability->loopback            = MAKEBOOL01(data & (1 << 0));
    
    return VTSS_OK;
}

vtss_rc vtss_mmd_pma_pmd_status_get(const uint port_no,
                                     vtss_mmd_pma_pmd_status_t *status)
{
    ushort data;
    uint   mmd = VTSS_MMD_PMA_PMD;

    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_1, &data));
    status->fault_detected = MAKEBOOL01(data & MMD_STAT_1_FAULT);
    status->link_up        = MAKEBOOL01(data & MMD_STAT_1_LINK_UP);

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_2, &data));
    status->transmit_fault = MAKEBOOL01(data & (1 << 11));
    status->receive_fault  = MAKEBOOL01(data & (1 << 10));
    
    VTSS_RC(vtss_mmd_read(port_no, mmd, 10, &data));
    status->receive_signal_0 = MAKEBOOL01(data & (1 << 1));
    status->receive_signal_1 = MAKEBOOL01(data & (1 << 2));
    status->receive_signal_2 = MAKEBOOL01(data & (1 << 3));
    status->receive_signal_3 = MAKEBOOL01(data & (1 << 4));
    
    return VTSS_OK;
}

vtss_rc vtss_mmd_wis_capability_get(const uint port_no, 
                                     vtss_mmd_wis_capability_t *capability)
{
    ushort data;
    uint   mmd = VTSS_MMD_WIS;

    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_SPEED_AB, &data));
    capability->ability_10g = MAKEBOOL01(data & MMD_SPEED_AB_10G);

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_1, &data));
    capability->lowpower = MAKEBOOL01(data & MMD_STAT_1_LOWPOW_AB);

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_2, &data));
    capability->test_pattern      = MAKEBOOL01(data & (1 << 1));
    capability->ability_10gbase_r = MAKEBOOL01(data & (1 << 0));
    
    return VTSS_OK;
}

vtss_rc vtss_mmd_wis_status_get(const uint port_no, vtss_mmd_wis_status_t *status)
{
    ushort data;
    uint   mmd = VTSS_MMD_WIS;

    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_1, &data));
    status->fault_detected = MAKEBOOL01(data & MMD_STAT_1_FAULT);
    status->link_up        = MAKEBOOL01(data & MMD_STAT_1_LINK_UP);
    
    return VTSS_OK;
}

vtss_rc vtss_mmd_pcs_capability_get(const uint port_no,
                                     vtss_mmd_pcs_capability_t *capability)
{
    ushort data;
    uint   mmd = VTSS_MMD_PCS;

    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_SPEED_AB, &data));
    capability->ability_10g = MAKEBOOL01(data & MMD_SPEED_AB_10G);

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_1, &data));
    capability->lowpower = MAKEBOOL01(data & MMD_STAT_1_LOWPOW_AB);

    VTSS_RC(vtss_mmd_read(port_no, mmd, 24, &data));
    capability->test_pattern = MAKEBOOL01(data & (1 << 11));
    
    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_2, &data));
    capability->ability_10gbase_w = MAKEBOOL01(data & (1 << 2));
    capability->ability_10gbase_x = MAKEBOOL01(data & (1 << 1));
    capability->ability_10gbase_r = MAKEBOOL01(data & (1 << 0));
    
    return VTSS_OK;
}

vtss_rc vtss_mmd_pcs_status_get(const uint port_no,
                                 vtss_mmd_pcs_status_t *status)
{
    ushort data;
    uint   mmd = VTSS_MMD_PCS;

    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_1, &data));
    status->fault_detected = MAKEBOOL01(data & MMD_STAT_1_FAULT);
    status->link_up        = MAKEBOOL01(data & MMD_STAT_1_LINK_UP);

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_2, &data));
    status->transmit_fault = MAKEBOOL01(data & (1 << 11));
    status->receive_fault  = MAKEBOOL01(data & (1 << 10));

    VTSS_RC(vtss_mmd_read(port_no, mmd, 24, &data));
    status->lanes_10gbase_x_aligned = MAKEBOOL01(data & (1 << 12));
    status->lane_0_sync             = MAKEBOOL01(data & (1 << 0));
    status->lane_1_sync             = MAKEBOOL01(data & (1 << 1));
    status->lane_2_sync             = MAKEBOOL01(data & (1 << 2));
    status->lane_3_sync             = MAKEBOOL01(data & (1 << 3));

    VTSS_RC(vtss_mmd_read(port_no, mmd, 32, &data));
    status->receive_up_10gbase_r = MAKEBOOL01(data & (1 << 12));

    VTSS_RC(vtss_mmd_read(port_no, mmd, 33, &data));
    status->block_lock_10gbase_r = MAKEBOOL01(data & (1 << 15));
    status->high_ber_10gbase_r   = MAKEBOOL01(data & (1 << 14));
    status->errored_blocks       = (data) & 0xFF;
    status->ber                  = (data >> 8) & 0x3F;

    return VTSS_OK;
}

vtss_rc vtss_mmd_phy_xs_capability_get(const uint port_no,
                                        vtss_mmd_phy_xs_capability_t *capability)
{
    ushort data;
    uint   mmd = VTSS_MMD_PHY_XS;

    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_SPEED_AB, &data));
    capability->ability_10g = MAKEBOOL01(data & MMD_SPEED_AB_10G);

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_1, &data));
    capability->lowpower = MAKEBOOL01(data & MMD_STAT_1_LOWPOW_AB);

    VTSS_RC(vtss_mmd_read(port_no, mmd, 24, &data));
    capability->test_pattern = MAKEBOOL01(data & (1 << 11));
    capability->loopback     = MAKEBOOL01(data & (1 << 10));

    return VTSS_OK;
}

vtss_rc vtss_mmd_phy_xs_status_get(const uint port_no,
                                    vtss_mmd_phy_xs_status_t *status)
{
    ushort data;
    uint   mmd = VTSS_MMD_PHY_XS;

    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_1, &data));
    status->fault_detected = MAKEBOOL01(data & MMD_STAT_1_FAULT);
    status->link_up        = MAKEBOOL01(data & MMD_STAT_1_LINK_UP);

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_2, &data));
    status->transmit_fault = MAKEBOOL01(data & (1 << 11));
    status->receive_fault  = MAKEBOOL01(data & (1 << 10));

    VTSS_RC(vtss_mmd_read(port_no, mmd, 24, &data));
    status->phy_xgxs_aligned = MAKEBOOL01(data & (1 << 12));
    status->lane_0_sync      = MAKEBOOL01(data & (1 << 0));
    status->lane_1_sync      = MAKEBOOL01(data & (1 << 1));
    status->lane_2_sync      = MAKEBOOL01(data & (1 << 2));
    status->lane_3_sync      = MAKEBOOL01(data & (1 << 3));
    
    return VTSS_OK;
}

vtss_rc vtss_mmd_dte_xs_capability_get(const uint port_no,
                                        vtss_mmd_dte_xs_capability_t *capability)
{
    ushort data;
    uint   mmd = VTSS_MMD_DTE_XS;

    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_SPEED_AB, &data));
    capability->ability_10g = MAKEBOOL01(data & MMD_SPEED_AB_10G);

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_1, &data));
    capability->lowpower = MAKEBOOL01(data & MMD_STAT_1_LOWPOW_AB);

    VTSS_RC(vtss_mmd_read(port_no, mmd, 24, &data));
    capability->test_pattern = MAKEBOOL01(data & (1 << 11));

    return VTSS_OK;
}

vtss_rc vtss_mmd_dte_xs_status_get(const uint port_no,
                                    vtss_mmd_dte_xs_status_t *status)
{
    ushort data;
    uint   mmd = VTSS_MMD_DTE_XS;

    VTSS_N(("port_no: %d",port_no));

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_1, &data));
    status->fault_detected = MAKEBOOL01(data & MMD_STAT_1_FAULT);
    status->link_up        = MAKEBOOL01(data & MMD_STAT_1_LINK_UP);

    VTSS_RC(vtss_mmd_read(port_no, mmd, MMD_STAT_2, &data));
    status->transmit_fault = MAKEBOOL01(data & (1 << 11));
    status->receive_fault  = MAKEBOOL01(data & (1 << 10));

    VTSS_RC(vtss_mmd_read(port_no, mmd, 24, &data));
    status->dte_xgxs_aligned = MAKEBOOL01(data & (1 << 12));
    status->lane_0_sync      = MAKEBOOL01(data & (1 << 0));
    status->lane_1_sync      = MAKEBOOL01(data & (1 << 1));
    status->lane_2_sync      = MAKEBOOL01(data & (1 << 2));
    status->lane_3_sync      = MAKEBOOL01(data & (1 << 3));
    
    return VTSS_OK;
}
#endif /* VTSS_FEATURE_10G */

/* - Port configuration and reset ---------------------------------- */

vtss_rc vtss_port_setup(const vtss_port_no_t port_no,
                        const vtss_port_setup_t * const setup)
{
    vtss_port_no_t        port;
    vtss_port_interface_t type;
    vtss_speed_t          speed;
    BOOL                  jumbo_old;

    type = setup->interface_mode.interface_type;
    speed = setup->interface_mode.speed;

#if defined(VTSS_FEATURE_SGMII)
#define VTSS_PREPROCESSOR_HACK_SGMII_DC_COUPLED_TEXT type==VTSS_PORT_INTERFACE_SGMII ? (setup->sgmii_dc_coupled?"(DC-Coupled)":"") :
#else
#define VTSS_PREPROCESSOR_HACK_SGMII_DC_COUPLED_TEXT /* nothing */
#endif
#if defined(VTSS_FEATURE_SERDES)
#define VTSS_PREPROCESSOR_HACK_SERDES_LOW_DRIVE_TEXT type==VTSS_PORT_INTERFACE_SERDES ? (setup->serdes_low_drive?"(Low-Drive)":"") :
#else
#define VTSS_PREPROCESSOR_HACK_SERDES_LOW_DRIVE_TEXT /* nothing */
#endif
    VTSS_D(("port_no: %d, %stype: %s%s, speed: %s, fdx: %d",port_no,
            setup->powerdown ? "POWERDOWN, " : "",
            type==VTSS_PORT_INTERFACE_NO_CONNECTION ? "NO_CONNECTION" :
            type==VTSS_PORT_INTERFACE_LOOPBACK ? "LOOPBACK" :
            type==VTSS_PORT_INTERFACE_INTERNAL ? "INTERNAL" :
            type==VTSS_PORT_INTERFACE_MII ? "MII" :
            type==VTSS_PORT_INTERFACE_GMII ? "GMII" :
            type==VTSS_PORT_INTERFACE_RGMII ? "RGMII" :
            type==VTSS_PORT_INTERFACE_TBI ? "TBI" :
            type==VTSS_PORT_INTERFACE_RTBI ? "RTBI" :
            type==VTSS_PORT_INTERFACE_SGMII ? "SGMII" :
            type==VTSS_PORT_INTERFACE_SERDES ? "SERDES" :
            type==VTSS_PORT_INTERFACE_VAUI ? "VAUI" :
            type==VTSS_PORT_INTERFACE_XAUI ? "XAUI" :
            type==VTSS_PORT_INTERFACE_100FX ? "100FX" :
            type==VTSS_PORT_INTERFACE_XGMII ? "XGMII" :
            "????",
            VTSS_PREPROCESSOR_HACK_SGMII_DC_COUPLED_TEXT
            VTSS_PREPROCESSOR_HACK_SERDES_LOW_DRIVE_TEXT
            "",
            speed==VTSS_SPEED_UNDEFINED ? "UNDEFINED" :
            speed==VTSS_SPEED_10M ? "10M" :
            speed==VTSS_SPEED_100M ? "100M" :
            speed==VTSS_SPEED_1G ? "1G" :
            speed==VTSS_SPEED_2500M ? "2.5G" :
            speed==VTSS_SPEED_5G ? "5G" :
            speed==VTSS_SPEED_10G ? "10G" :
            "???",
            setup->fdx));
#undef VTSS_PREPROCESSOR_HACK_SGMII_DC_COUPLED_TEXT
#undef VTSS_PREPROCESSOR_HACK_SERDES_LOW_DRIVE_TEXT
    VTSS_D(("pause_obey: %d, pause_generate: %d, max_frame: %d",
            setup->flowcontrol.obey,setup->flowcontrol.generate,setup->maxframelength));

#if defined(VTSS_ARCH_GATWICK)
    if (type==VTSS_PORT_INTERFACE_LOOPBACK)
        return VTSS_NOT_IMPLEMENTED; /* Not implemented yet. */
#endif /* VTSS_ARCH_GATWICK */

    if (setup->maxframelength > VTSS_MAXFRAMELENGTH_MAX)
        return VTSS_INVALID_PARAMETER;

    /* Store the setup and determine if we are in jumbo mode */
    vs->setup[port_no] = *setup;
    vs->port_fc_rx[port_no] = MAKEBOOL01(setup->flowcontrol.obey);
    vs->port_fc_tx[port_no] = MAKEBOOL01(setup->flowcontrol.generate);
    jumbo_old = vs->jumbo;
    vs->jumbo = 0;
    for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
        if (!vs->port_map.vtss_port_unused[port] &&
            vs->setup[port].maxframelength > VTSS_MAXFRAMELENGTH_TAGGED) {
            /* Go to jumbo mode if any active port is above the tagged max length (VMAN) */
            vs->jumbo = 1;
            break;
        }
    }

#if defined(VTSS_FEATURE_10G)
    if (vtss_port_no_is_10g(port_no)) {
        VTSS_RC(vtss_ll_port_speed_mode_xgmii(port_no, setup));
    } else 
#endif /* VTSS_FEATURE_10G */
    {
#if defined(VTSS_ARCH_HEATHROW) || defined(VTSS_ARCH_GATWICK)
        vtss_chip_counters_t counters;
        
        VTSS_RC(vtss_port_counters_update(port_no));
#endif /* VTSS_ARCH_HEATHROW/GATWICK */

        VTSS_RC(vtss_ll_port_speed_mode_tbi_gmii(port_no, setup));

#if defined(VTSS_ARCH_HEATHROW) || defined(VTSS_ARCH_GATWICK)
        /* If CRC errors are generated by MAC configuration, all counter changes are ignored */
        vtss_ll_port_counters_get(port_no, &counters);
#endif /* VTSS_ARCH_HEATHROW/GATWICK */
#if defined(VTSS_ARCH_GATWICK)
        if (counters.rx_crc_err != vs->port_last_counters[port_no].rx_crc_err)
            vs->port_last_counters[port_no] = counters;
#endif /* VTSS_ARCH_GATWICK */
#if defined(VTSS_ARCH_HEATHROW)
#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
        if (counters.rx_errors != vs->port_last_counters[port_no].rx_errors)
            vs->port_last_counters[port_no] = counters;
#else
        if (counters.rx_crc_align_errors != vs->port_last_counters[port_no].rx_crc_align_errors)
            vs->port_last_counters[port_no] = counters;
#endif /* VTSS_ARCH_SPARX */
#endif /* VTSS_ARCH_HEATHROW */
    }
    
    /* Update all other active ports if jumbo mode changed */
    if (vs->jumbo != jumbo_old) {
        for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
            if (!vs->port_map.vtss_port_unused[port] && port != port_no) {
                VTSS_RC(vtss_ll_port_queue_setup(port));
            }
        }
    }
   
    return VTSS_OK;
}

#if defined(VTSS_FEATURE_LAYER2)
static const char *vtss_stp_state_str(vtss_stp_state_t stp_state)
{
    return (stp_state==VTSS_STP_STATE_DISABLED ? "DISABLED" :
            stp_state==VTSS_STP_STATE_BLOCKING ? "BLOCKING" :
            stp_state==VTSS_STP_STATE_LISTENING ? "LISTENING" :
            stp_state==VTSS_STP_STATE_LEARNING ? "LEARNING" :
            stp_state==VTSS_STP_STATE_FORWARDING ? "FORWARDING" :
            stp_state==VTSS_STP_STATE_ENABLED ? "ENABLED" : "???");
}

/* Update source, destination and aggregation masks */
static vtss_rc vtss_update_masks(BOOL src_update, BOOL dest_update, BOOL aggr_update)
{
    vtss_port_no_t   i_port_no, e_port_no;
    vtss_poag_no_t   poag_no;
    vtss_pvlan_no_t  pvlan_no;
    BOOL             member[VTSS_PORT_ARRAY_SIZE];
    vtss_pgid_no_t   pgid_no;
    vtss_ac_no_t     ac_no;
    uint             aggr_count[VTSS_PORT_ARRAY_SIZE], aggr_index[VTSS_PORT_ARRAY_SIZE], n;
#if defined(VTSS_FEATURE_AGGR_GLAG)
    vtss_glag_no_t   glag_no;
#endif /* VTSS_FEATURE_AGGR_GLAG */

    VTSS_D(("src_update: %d, dest_update: %d, aggr_update: %d",
            src_update, dest_update, aggr_update));

    /* Update source masks */
    for (i_port_no = VTSS_PORT_NO_START; src_update && i_port_no < VTSS_PORT_NO_END; i_port_no++) {
        /* Avoid setting up unmapped ports */
        if (vs->port_map.vtss_port_unused[i_port_no])
            continue;

        /* Exclude all ports by default */
        memset(member, 0, sizeof(member));

        if (VTSS_PORT_RX_FORWARDING(vs->port_forward[i_port_no]) &&
            VTSS_STP_FORWARDING(vs->stp_state[i_port_no]) &&
            vs->auth_state[i_port_no] == VTSS_AUTH_STATE_BOTH) {
            /* STP and Authentication state allow forwarding from port */
        
            /* PVLANs: Include members of the same PVLAN */
            for (pvlan_no = VTSS_PVLAN_NO_START; pvlan_no < VTSS_PVLAN_NO_END; pvlan_no++) {
                if (vs->pvlan_table[pvlan_no].member[i_port_no]) {
                    /* The ingress port is a member of this PVLAN */
                    for (e_port_no = VTSS_PORT_NO_START; e_port_no < VTSS_PORT_NO_END; e_port_no++) {
                        if (vs->pvlan_table[pvlan_no].member[e_port_no]) {
                            /* This port is also a member of the PVLAN */
                            member[e_port_no] = MAKEBOOL01(1);
                        }
                    }
                }
            }

            /* Aggregations: Exclude members of the same aggregation */
            poag_no = vs->port_poag_no[i_port_no];
            for (e_port_no = VTSS_PORT_NO_START; e_port_no < VTSS_PORT_NO_END; e_port_no++) {
                if (vs->port_map.vtss_port_unused[e_port_no] || 
                    vs->port_poag_no[e_port_no] == poag_no) {
                    /* Exclude unmapped ports and members of the same aggregation */
                    member[e_port_no] = MAKEBOOL01(0);
                }
            }
        }

        VTSS_RC(vtss_ll_src_table_write(i_port_no, member));
    } /* src_update */

    /* Update PGID table (destination masks) */
#if defined(VTSS_FEATURE_AGGR_GLAG)
    /* Setup GLAG source and destination masks */
    for (glag_no = VTSS_GLAG_NO_START; 
         glag_no < VTSS_GLAG_NO_END && (dest_update || aggr_update); 
         glag_no++) {
        vtss_port_no_t port_no;
        uint           glag_idx, gport, gcount, index;
        uint           pgid_dest, pgid_src, pgid_aggr_a, pgid_aggr_b;

        glag_idx = (glag_no - VTSS_GLAG_NO_START);
        pgid_dest = (VTSS_PGID_GLAG_DEST + glag_idx);
        pgid_src = (VTSS_PGID_GLAG_SRC + glag_idx);
        pgid_aggr_a = (VTSS_PGID_GLAG_AGGR_A + glag_idx);
        pgid_aggr_b = (VTSS_PGID_GLAG_AGGR_B + glag_idx);
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            vs->pgid_table[pgid_dest].member[port_no] = 0;
            vs->pgid_table[pgid_src].member[port_no] = 1;
            vs->pgid_table[pgid_aggr_a].member[port_no] = 0;
            vs->pgid_table[pgid_aggr_b].member[port_no] = 0;
        }   

        /* Setup GLAG source and destination masks */
        gcount = 0;
        for (gport = VTSS_GLAG_PORT_START; gport < VTSS_GLAG_PORT_END; gport++) {
            if ((port_no = vs->glag_members[glag_idx][gport]) == 0)
                break;
        
            /* Include local ports and stack ports in destination mask */
            vs->pgid_table[pgid_dest].member[port_no] = 1;

            /* Include locally aggregated stack ports in destination mask */
            if ((poag_no = vs->port_poag_no[port_no]) != port_no &&
                vs->vstax_port_setup[port_no].enable) {
                for (i_port_no = VTSS_PORT_NO_START; i_port_no < VTSS_PORT_NO_END; i_port_no++)
                    if (vs->port_poag_no[i_port_no] == poag_no)
                        vs->pgid_table[pgid_dest].member[i_port_no] = 1;
            }
            
            /* Exclude local ports from source mask */
            if (!vs->vstax_port_setup[port_no].enable)
                vs->pgid_table[pgid_src].member[port_no] = 0;

            /* Count number of forwarding ports and assign index */
            if (VTSS_STP_FORWARDING(vs->stp_state[port_no]) &&
                vs->auth_state[port_no] != VTSS_AUTH_STATE_NONE) {
                VTSS_D(("glag_no: %d, index: %d, port_no: %d", glag_no, gcount, port_no));
                vs->port_glag_index[port_no] = gcount;
                gcount++;
            }
        }
        vs->glag_port_count[glag_idx] = gcount;

        /* Setup GLAG aggregation masks */
        for (ac_no = VTSS_AC_START; gcount && ac_no < VTSS_AC_END; ac_no++) {
            index = 0;
            for (gport = VTSS_GLAG_PORT_START; gport < VTSS_GLAG_PORT_END; gport++) {
                if ((port_no = vs->glag_members[glag_idx][gport]) == 0)
                    break;
        
                if (VTSS_STP_FORWARDING(vs->stp_state[port_no]) &&
                    vs->auth_state[port_no] != VTSS_AUTH_STATE_NONE) {
                    /* Enable stack port if AC owner */
                    if (vs->vstax_port_setup[port_no].enable &&
                        ((index + ac_no - VTSS_AC_START) % gcount) == 0) {
                        uint pgid = (((1 << vs->port_map.chip_port[port_no]) & 
                                      VTSS_OPT_STACK_A_MASK) ? pgid_aggr_a : pgid_aggr_b);
                        vs->pgid_table[pgid].member[ac_no] = 1;

                        /* If stack ports are aggregated, enable AC in both masks */
                        if (vs->port_poag_no[port_no] != port_no) {
                            pgid = (pgid == pgid_aggr_a ? pgid_aggr_b : pgid_aggr_a);
                            vs->pgid_table[pgid].member[ac_no] = 1;
                        }
                    }
                    index++;
                }
            }
        }
    } /* GLAG loop */
#endif /* VTSS_FEATURE_AGGR_GLAG */
    for (pgid_no = VTSS_PGID_START; dest_update && pgid_no < vs->pgid_end; pgid_no++) {
        if (vs->pgid_table[pgid_no].references > 0) {
            VTSS_RC(vtss_pgid_table_write(pgid_no));
        }
    } /* dest_update */
    
    /* Update aggregation masks */
    if (aggr_update) {

        /* Count number of operational ports and index of each port */
        for (i_port_no = VTSS_PORT_NO_START; i_port_no < VTSS_PORT_NO_END; i_port_no++) {
            aggr_count[i_port_no] = 0;
            aggr_index[i_port_no] = 0;
            
            /* If port is not forwarding, continue */
            if (!VTSS_STP_FORWARDING(vs->stp_state[i_port_no]) ||
                !VTSS_PORT_TX_FORWARDING(vs->port_forward[i_port_no]) ||
                vs->auth_state[i_port_no] == VTSS_AUTH_STATE_NONE)
                continue;
            
            poag_no = vs->port_poag_no[i_port_no];
            VTSS_D(("port_no: %d, poag_no: %d is forwarding", i_port_no, poag_no));
            for (e_port_no = VTSS_PORT_NO_START; e_port_no < VTSS_PORT_NO_END; e_port_no++) {
                if (vs->port_poag_no[e_port_no] == poag_no &&
                    VTSS_STP_FORWARDING(vs->stp_state[e_port_no]) &&
                    VTSS_PORT_TX_FORWARDING(vs->port_forward[e_port_no]) &&
                    vs->auth_state[e_port_no] != VTSS_AUTH_STATE_NONE) {
                    /* Port is forwarding and member of the same aggregation */
                    aggr_count[i_port_no]++;
                    if (e_port_no < i_port_no)
                        aggr_index[i_port_no]++;
                }
            }
        }
        
        for (ac_no = VTSS_AC_START; ac_no < VTSS_AC_END; ac_no++) {

            /* Include one forwarding port from each aggregation */
            for (i_port_no = VTSS_PORT_NO_START; i_port_no < VTSS_PORT_NO_END; i_port_no++) {
                n = (aggr_index[i_port_no] + ac_no - VTSS_AC_START);
                member[i_port_no] = MAKEBOOL01(aggr_count[i_port_no] != 0 &&
                                               (n % aggr_count[i_port_no]) == 0);

#if defined(VTSS_FEATURE_AGGR_GLAG)
                /* Exclude GLAG member port if not AC owner */
                glag_no = vs->port_glag_no[i_port_no];
                if (member[i_port_no] && 
                    glag_no != 0 &&
                    ((vs->port_glag_index[i_port_no] + ac_no - VTSS_AC_START) % 
                     vs->glag_port_count[glag_no - VTSS_GLAG_NO_START]) != 0)
                    member[i_port_no] = 0;
#endif /* VTSS_FEATURE_AGGR_GLAG */
                /* Save the first aggregation member list as API state for frame Tx */
                if (ac_no == VTSS_AC_START)
                    vs->aggr_member[i_port_no] = member[i_port_no];
            }

            /* Write to aggregation table */
            VTSS_RC(vtss_ll_aggr_table_write(ac_no, member));
        }

#if defined(VTSS_ARCH_GATWICK) || defined(VTSS_ARCH_SPARX_28)
        /* Update port map table on aggregation changes */
        for (i_port_no = VTSS_PORT_NO_START; i_port_no < VTSS_PORT_NO_END; i_port_no++) {
            vtss_port_no_t l_port_no = 0;
            
#if defined(VTSS_CHIPS)
            vs->port_aggr_multi[i_port_no] = 0;
#endif /* VTSS_CHIPS */                    

            for (e_port_no = VTSS_PORT_NO_START; e_port_no < VTSS_PORT_NO_END; e_port_no++) {
                if (vs->port_poag_no[i_port_no] == vs->port_poag_no[e_port_no]) {

                    /* The logical port is the first operational port in the aggregation */
                    if (l_port_no == 0 
#if defined(VTSS_ARCH_GATWICK)
                        && VTSS_STP_FORWARDING(vs->stp_state[e_port_no])
#endif /* VTSS_ARCH_GATWICK */
                        )
                        l_port_no = e_port_no;
                    
#if defined(VTSS_CHIPS)
                    /* Check if first port in an aggregation spanning multiple chips */
                    if (vs->gw1e &&
                        l_port_no == i_port_no && 
                        vs->port_map.chip_no[i_port_no] != vs->port_map.chip_no[e_port_no])
                        vs->port_aggr_multi[i_port_no] = 1;
#endif /* VTSS_CHIPS */                    
                }
            }
            /* If port down or no ports in aggregation are up, map to port itself */
            if (l_port_no == 0)
                l_port_no = i_port_no;
            VTSS_RC(vtss_ll_pmap_table_write(i_port_no, l_port_no));
        }
#endif /* VTSS_ARCH_GATWICK/SPARX_28 */
    } /* aggr_update */

    return VTSS_OK;
}
#endif /* VTSS_FEATURE_LAYER2 */

/* - Port Link Status ---------------------------------------------- */

/* Gather current status of a port within a generic status structure */
vtss_rc vtss_port_status_get(const vtss_port_no_t port_no,
                             vtss_port_status_t * const status)
{
    uint               port_on_chip;
    
    port_on_chip = vs->port_map.chip_port[port_no];
    status->link_down = 0;
    status->link = 0;
    status->speed = VTSS_SPEED_UNDEFINED;
    status->fdx = 0;
    status->remote_fault = 0;
    
    VTSS_N(("port_no: %d",port_no));

    if (VTSS_PORT_IS_10G(port_on_chip)) {
#if defined(VTSS_FEATURE_10G)
        /* 10G port */
        VTSS_RC(vtss_ll_10g_status_get(port_no, status));
        if (status->link) {
            status->link = 1;
            status->speed = VTSS_SPEED_10G;
            status->fdx = MAKEBOOL01(1);
        }
#endif /* VTSS_FEATURE_10G */
    } else {
        BOOL tbi_enabled = 0;
#if defined(VTSS_FEATURE_TBI)
        VTSS_RC(vtss_tbi_enabled(port_no, &tbi_enabled));
        if (tbi_enabled) {
            /* 1G port with TBI */
            vtss_tbi_status_t          tbi_status;
            vtss_tbi_autoneg_control_t tbi_autoneg_control;
            
            VTSS_RC(vtss_tbi_status_get(port_no, &tbi_status));
            status->link_down = (tbi_status.link_status ? 0 : 1);
            
            if (status->link_down) {
                /* Link has been down, so get the current status */
                VTSS_RC(vtss_tbi_status_get(port_no, &tbi_status));
                status->link = tbi_status.link_status;
            } else {
                /* Link is still up */
                status->link = 1;
            }
            
            VTSS_RC(vtss_tbi_autoneg_control_get(port_no, &tbi_autoneg_control));
            if (status->link) { 
                if (tbi_autoneg_control.enable) {
                    vtss_autoneg_1000base_x_advertisement_t *adv, *lp_adv;

                    adv = &tbi_autoneg_control.advertisement;
                    lp_adv = &tbi_status.autoneg.partner_advertisement;
                    if (tbi_status.autoneg.complete) {
                        /* Speed and duplex mode auto negotiation result */
                        if (adv->fdx && lp_adv->fdx) {
                            status->speed = VTSS_SPEED_1G;
                            status->fdx = 1;
                        } else if (adv->hdx && lp_adv->hdx) {
                            status->speed = VTSS_SPEED_1G;
                            status->fdx = 0;
                        } 

                        /* Flow control auto negotiation result */
                        status->aneg.obey_pause =
                            (adv->symmetric_pause &&
                             (lp_adv->symmetric_pause || 
                              (adv->asymmetric_pause && lp_adv->asymmetric_pause)) ? 1 : 0);
                        status->aneg.generate_pause =
                            (lp_adv->symmetric_pause &&
                             (adv->symmetric_pause || 
                              (adv->asymmetric_pause && lp_adv->asymmetric_pause)) ? 1 : 0);
                        
                        /* Remote fault */
                        if (lp_adv->remote_fault != VTSS_1000BASEX_LINK_OK)
                            status->remote_fault = 1;
                    } else {
                        /* Autoneg says that the link partner is not OK */
                        status->link = 0;
                    }
                } else {
                    /* Forced speed */
                    status->speed = VTSS_SPEED_1G;
                    status->fdx = 1;
                } 
            } /* TBI link up */
        } /* tbi_enabled */
#endif /* VTSS_FEATURE_TBI */
        if (!tbi_enabled) {
            /* 1G port without TBI */
#if defined(VTSS_FEATURE_VAUI)
            if (vs->port_map.miim_controller[port_no] == VTSS_MIIM_CONTROLLER_NONE) {
                VTSS_RC(vtss_ll_vaui_status_get(port_no, status));
            } else
#endif /* VTSS_FEATURE_VAUI */
                VTSS_RC(vtss_phy_status_get(port_no, status));
        } /* 1G port without TBI */
    }
    
    return VTSS_OK;
}

#if !defined(VTSS_ARCH_SPARX_28)
/* - Counters ------------------------------------------------------ */
static vtss_chip_counters_t vtss_port_counters_significantbits = {
#if defined(VTSS_ARCH_HEATHROW)
    32,        /* rx_octets */
    32,        /* tx_octets */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    16,        /* rx_drops */
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
    24,        /* rx_drops */
#endif /* VTSS_ARCH_HAWX/VTSS_ARCH_SPARX */
    24,        /* rx_packets */
    24,        /* rx_broadcasts */
    24,        /* rx_multicasts */
#if defined(VTSS_ARCH_SPARX)
    24,        /* rx_errors */
#else
    24,        /* rx_crc_align_errors */
    24,        /* rx_shorts */
    24,        /* rx_longs */
    24,        /* rx_fragments */
    24,        /* rx_jabbers */
    24,        /* rx_64 */
    24,        /* rx_65_127 */
    24,        /* rx_128_255 */
    24,        /* rx_256_511 */
    24,        /* rx_512_1023 */
#endif /* VTSS_ARCH_SPARX */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    24,        /* rx_1024_max */
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX)
    24,        /* rx_1024_1526 */
    24,        /* rx_1527_max */
#endif /* VTSS_ARCH_HAWX */

    24,        /* tx_drops */
    24,        /* tx_packets */
    24,        /* tx_broadcasts */
    24,        /* tx_multicasts */
#if defined(VTSS_ARCH_SPARX)
    24         /* tx_errors */
#else
    24,        /* tx_collisions */
    24,        /* tx_64 */
    24,        /* tx_65_127 */
    24,        /* tx_128_255 */
    24,        /* tx_256_511 */
    24,        /* tx_512_1023 */
#endif /* VTSS_ARCH_SPARX */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    24,        /* tx_1024_max */
    16         /* tx_fifo_drops */
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX)
    24,        /* tx_1024_1526 */
    24,        /* tx_1527_max */
    24         /* tx_fifo_drops */
#endif /* VTSS_ARCH_HAWX */

#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    ,24        /* rx_low_priority */
    ,24        /* rx_high_priority */
    ,24        /* tx_low_priority */
    ,24        /* tx_high_priority */
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_HAWX)
    ,24        /* rx_pauses */
    ,24        /* tx_pauses */
    ,24        /* rx_classified_drops */
#endif /* VTSS_ARCH_STANSTED/VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_HAWX)
    ,24        /* rx_backward_drops */
    , { 24,24,24,24,24,24,24,24 } /* rx_class[VTSS_PRIOS] */
    , { 24,24,24,24,24,24,24,24 } /* tx_class[VTSS_PRIOS] */
#endif /* VTSS_ARCH_HAWX */
#endif /* VTSS_ARCH_HEATHROW */
#if defined(VTSS_ARCH_GATWICK) || defined(VTSS_ARCH_B2)
    32,        /* rx_in_bytes; */
    32,        /* symbol_carrier_err; */
    32,        /* rx_drops */
    32,        /* rx_pause; */
    32,        /* rx_unsup_opcode; */
    32,        /* rx_ok_bytes; */
    32,        /* rx_bad_bytes; */
    32,        /* rx_unicast; */
    32,        /* rx_multicast; */
    32,        /* rx_broadcast; */
    32,        /* rx_crc_err; */
    32,        /* rx_undersize; */
    32,        /* rx_fragments; */
    32,        /* rx_in_range_length_err; */
    32,        /* rx_out_of_range_length_err; */
    32,        /* rx_oversize; */
    32,        /* rx_jabbers; */
    32,        /* rx_size64; */
    32,        /* rx_size65_127; */
    32,        /* rx_size128_255; */
    32,        /* rx_size256_511; */
    32,        /* rx_size512_1023; */
    32,        /* rx_size1024_1518; */
    32,        /* rx_size1519_max; */
    32,        /* tx_out_bytes; */
    32,        /* tx_pause; */
    32,        /* tx_ok_bytes; */
    32,        /* tx_unicast; */
    32,        /* tx_multicast; */
    32,        /* tx_broadcast; */
    32,        /* tx_size64; */
    32,        /* tx_size65_127; */
    32,        /* tx_size128_255; */
    32,        /* tx_size256_511; */
    32,        /* tx_size512_1023; */
    32,        /* tx_size1024_1518; */
    32,        /* tx_size1519_max; */
    32,        /* tx_underrun; */
    32,        /* rx_ipg_shrink; */
    32,        /* tx_queue_system_drops */
    32,        /* tx_mac_drop */

/* These fields are only relevant fo D4, for D10 these fields remain 0 */
    32,        /* rx_alignment_err; */
    32,        /* tx_multi_coll; */
    32,        /* tx_late_coll; */
    32,        /* tx_xcoll; */
    32,        /* tx_defer; */
    32,        /* tx_xdefer; */
    32,        /* tx_csense; */
    32,        /* tx_backoff1; */
#if defined(VTSS_ARCH_B2)
    32,        /* rx_ana_drops */
    { 32,32 }, /* rx_pol_drops[VTSS_PORT_POLICER_COUNT] */
    { 32,32,32,32,32,32,32,32 }, /* rx_class[VTSS_PRIOS] */
    { 32,32,32,32,32,32,32,32 }, /* rx_queue_drops[VTSS_PRIOS] */
    { 32,32,32,32,32,32,32,32 }, /* rx_red_drops[VTSS_PRIOS] */
    { 32,32,32,32,32,32,32,32 }, /* rx_error_drops[VTSS_PRIOS] */
    32,        /* tx_queue_drops */
    32,        /* tx_red_drops */
    32         /* tx_error_drops */
#else
    32,        /* tx_backoff2; */
    32,        /* tx_backoff3; */
    32,        /* tx_backoff4; */
    32,        /* tx_backoff5; */
    32,        /* tx_backoff6; */
    32,        /* tx_backoff7; */
    32,        /* tx_backoff8; */
    32,        /* tx_backoff9; */
    32,        /* tx_backoff10; */
    32,        /* tx_backoff11; */
    32,        /* tx_backoff12; */
    32,        /* tx_backoff13; */
    32,        /* tx_backoff14; */
    32         /* tx_backoff15; */
#endif /* VTSS_ARCH_B2 */
#endif /* VTSS_ARCH_GATWICK/B2 */
};
#endif /* VTSS_ARCH_SPARX_28 */

/* - Big Counters -------------------------------------------------- */

/* This is called regularly to update the big counters */
vtss_rc vtss_port_counters_update(const vtss_port_no_t port_no)
{
    vtss_port_no_t       port;
    int                  i;
    vtss_chip_counters_t counters;
    vtss_counter_t       *big, incr;
#if !defined(VTSS_ARCH_SPARX_28)
    vtss_chip_counter_t  *sig_bits;
#endif /* VTSS_ARCH_SPARX_28 */
    vtss_chip_counter_t  *new, *old, n;
    uint                 ctr;

    VTSS_N(("port_no: %d",port_no));

    /* Check that the port number is valid */
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }

    port = port_no;
    for (i = 0; i < 2; i++) {

        /* Get updated chip counters */
        VTSS_RC(vtss_ll_port_counters_get(port, &counters));
        
        new = (vtss_chip_counter_t *)&counters;
        old = (vtss_chip_counter_t *)&vs->port_last_counters[port];
#if !defined(VTSS_ARCH_SPARX_28)
        sig_bits = (vtss_chip_counter_t *)&vtss_port_counters_significantbits;
#endif /* VTSS_ARCH_SPARX_28 */
        for (ctr = 0; ctr < sizeof(vtss_chip_counters_t) / sizeof(vtss_chip_counter_t); ctr++) {

            /* Calculate increment taking wrapping into account */
#if defined(VTSS_ARCH_SPARX_28)
            n = 32;
#else
            n = sig_bits[ctr];
#endif /* VTSS_ARCH_SPARX_28 */
            incr = (new[ctr] + (new[ctr] >= old[ctr] ? 0 : ((1 << n) - 1)) - old[ctr]);
            
            /* Store latest chip counter */
            old[ctr] = new[ctr];
            
            /* Update port counter */
            big = (vtss_counter_t *)&vs->poag_big_counters[port_no];
            big[ctr] += incr;
            
#if defined(VTSS_FEATURE_LAYER2)
            /* If port is aggregated, update aggregation counter */
            if (VTSS_POAG_IS_AGGR(vs->port_poag_no[port_no])) {
                big = (vtss_counter_t *)&vs->poag_big_counters[vs->port_poag_no[port_no]];
                big[ctr] += incr;
            }
#endif /* VTSS_FEATURE_LAYER2 */
        }

#if VTSS_OPT_INT_AGGR
        /* For internally aggregated ports, counters for the second port are included */
        switch (vs->port_map.chip_port[port_no]) {
        case VTSS_CHIP_PORT_AGGR_0:
            port = VTSS_PORT_NO_AGGR_0;
            break;
        case VTSS_CHIP_PORT_AGGR_1:
            port = VTSS_PORT_NO_AGGR_1;
            break;
        default:
            return VTSS_OK;
        }
#else
        break;
#endif /* VTSS_OPT_INT_AGGR */
    }
    return VTSS_OK;
}

vtss_rc vtss_poag_counters_clear(const vtss_poag_no_t poag_no)
{
    vtss_port_no_t port_no;
    uint           ctr;

    VTSS_D(("poag_no: %d",poag_no));

    /* Check that the poag number is valid */
    if (!(VTSS_POAG_IS_POAG(poag_no))) {
        VTSS_E(("illegal poag_no: %d",poag_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    /* Update counters for poag and clear counter variables */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (port_no == poag_no 
#if defined(VTSS_FEATURE_LAYER2)
            || vs->port_poag_no[port_no] == poag_no
#endif /* VTSS_FEATURE_LAYER2 */
            ) {
            VTSS_RC(vtss_port_counters_update(port_no));
            for (ctr = 0; ctr < sizeof(vtss_port_big_counters_t) / sizeof(vtss_counter_t); ctr++) {
                ((vtss_counter_t *) (&(vs->poag_big_counters[poag_no])))[ctr] = 0;
            }
        }
    }
    
    return VTSS_OK;
}

#if defined(VTSS_ARCH_HEATHROW) && !defined(VTSS_ARCH_SPARX_28)
/* Calculate a-b, where the result may not become negative */
static vtss_counter_t subtract_floor0(const vtss_counter_t a, const vtss_counter_t b) __VTSS_ATTRIB_CONST_FUNCTION__;
static vtss_counter_t subtract_floor0(const vtss_counter_t a, const vtss_counter_t b)
{
    return a>b ? a-b : 0;
}
#endif /* VTSS_ARCH_HEATHROW && !VTSS_ARCH_SPARX_28 */

/* This is used to retrieve the counters. */
vtss_rc vtss_poag_counters_get(const vtss_poag_no_t poag_no,
                               vtss_poag_counters_t *const big_counters)
{
    vtss_port_no_t           port_no;
    vtss_port_big_counters_t *counters;

    VTSS_N(("poag_no: %d",poag_no));

    /* Check that the poag number is valid */
    if (!(VTSS_POAG_IS_POAG(poag_no))) {
        VTSS_E(("illegal poag_no: %d",poag_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    /* Update counters for poag first */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (port_no == poag_no 
#if defined(VTSS_FEATURE_LAYER2)
            || vs->port_poag_no[port_no] == poag_no
#endif /* VTSS_FEATURE_LAYER2 */
            ) {
            VTSS_RC(vtss_port_counters_update(port_no));
        }
    }
    
    counters = &vs->poag_big_counters[poag_no];

    /* Convert from chip specific counters to standard counters */
#if defined(VTSS_FEATURE_PORT_CNT_QOS)
    /* Prioprietary counters */
    {
        uint i;

#if defined(VTSS_ARCH_B2)
        big_counters->prop.rx_filter_drops = counters->rx_filter_drops;
        big_counters->prop.rx_policer_drops = (counters->rx_policer_drops[0] + 
                                               counters->rx_policer_drops[1]);
        counters->rx_drops = (big_counters->prop.rx_filter_drops +
                              big_counters->prop.rx_policer_drops);
        counters->tx_queue_system_drops = (counters->tx_queue_drops +
                                           counters->tx_red_drops +
                                           counters->tx_error_drops);
#endif /* VTSS_ARCH_B2 */
        for (i = 0; i < VTSS_PRIOS; i++) {
            big_counters->prop.rx_prio[i] = counters->rx_class[i];
#if defined(VTSS_ARCH_B2)
            big_counters->prop.rx_prio_drops[i] = (counters->rx_queue_drops[i] +
                                                   counters->rx_red_drops[i] +
                                                   counters->rx_error_drops[i]);
            counters->rx_drops += big_counters->prop.rx_prio_drops[i];
#else
            big_counters->prop.tx_prio[i] = counters->tx_class[i];
#endif /* VTSS_ARCH_B2 */
        }
    }
#endif /* VTSS_FEATURE_PORT_CNT_QOS */

#if defined(VTSS_ARCH_GATWICK) || defined(VTSS_ARCH_B2)
    /* RMON Rx counters */
    big_counters->rmon.rx_etherStatsDropEvents = counters->rx_drops;
    big_counters->rmon.rx_etherStatsOctets = (counters->rx_ok_bytes + 
                                              counters->rx_bad_bytes); 
    big_counters->rmon.rx_etherStatsPkts = (counters->rx_unicast + counters->rx_multicast +
                                            counters->rx_broadcast + counters->rx_crc_err +
                                            counters->rx_alignment_err + counters->rx_undersize +
                                            counters->rx_oversize + counters->rx_fragments +
#if defined(VTSS_ARCH_GATWICK)
                                            counters->rx_in_range_length_err +
#endif /* VTSS_ARCH_GATWICK */
                                            counters->rx_out_of_range_length_err +
                                            counters->rx_jabbers);
    big_counters->rmon.rx_etherStatsBroadcastPkts = counters->rx_broadcast;
    big_counters->rmon.rx_etherStatsMulticastPkts = counters->rx_multicast;
    big_counters->rmon.rx_etherStatsCRCAlignErrors = (counters->rx_crc_err +
                                                      counters->rx_alignment_err);
    big_counters->rmon.rx_etherStatsUndersizePkts = counters->rx_undersize;
    big_counters->rmon.rx_etherStatsOversizePkts = counters->rx_oversize;
    big_counters->rmon.rx_etherStatsFragments = counters->rx_fragments;
    big_counters->rmon.rx_etherStatsJabbers = counters->rx_jabbers;
    big_counters->rmon.rx_etherStatsPkts64Octets = counters->rx_size64;
    big_counters->rmon.rx_etherStatsPkts65to127Octets = counters->rx_size65_127;
    big_counters->rmon.rx_etherStatsPkts128to255Octets = counters->rx_size128_255;
    big_counters->rmon.rx_etherStatsPkts256to511Octets = counters->rx_size256_511;
    big_counters->rmon.rx_etherStatsPkts512to1023Octets = counters->rx_size512_1023;
    big_counters->rmon.rx_etherStatsPkts1024to1518Octets = counters->rx_size1024_1518;
    big_counters->rmon.rx_etherStatsPkts1519toMaxOctets = counters->rx_size1519_max;

    /* RMON Tx counters */
    big_counters->rmon.tx_etherStatsDropEvents = (counters->tx_queue_system_drops +
                                                  counters->tx_mac_drop);
    big_counters->rmon.tx_etherStatsOctets = counters->tx_ok_bytes;
    big_counters->rmon.tx_etherStatsPkts = (counters->tx_unicast + counters->tx_multicast +
                                            counters->tx_broadcast + counters->tx_late_coll);
    big_counters->rmon.tx_etherStatsBroadcastPkts = counters->tx_broadcast;
    big_counters->rmon.tx_etherStatsMulticastPkts = counters->tx_multicast;
    big_counters->rmon.tx_etherStatsCollisions = (counters->tx_multi_coll + counters->tx_backoff1 + counters->tx_late_coll + counters->tx_xcoll);
    big_counters->rmon.tx_etherStatsPkts64Octets = counters->tx_size64;
    big_counters->rmon.tx_etherStatsPkts65to127Octets = counters->tx_size65_127;
    big_counters->rmon.tx_etherStatsPkts128to255Octets = counters->tx_size128_255;
    big_counters->rmon.tx_etherStatsPkts256to511Octets = counters->tx_size256_511;
    big_counters->rmon.tx_etherStatsPkts512to1023Octets = counters->tx_size512_1023;
    big_counters->rmon.tx_etherStatsPkts1024to1518Octets = counters->tx_size1024_1518;
    big_counters->rmon.tx_etherStatsPkts1519toMaxOctets = counters->tx_size1519_max;
    
    /* Interfaces Group Rx counters */
    big_counters->if_group.ifInOctets = counters->rx_in_bytes;
    big_counters->if_group.ifInUcastPkts = counters->rx_unicast;
    big_counters->if_group.ifInMulticastPkts = counters->rx_multicast;
    big_counters->if_group.ifInBroadcastPkts = counters->rx_broadcast;
    big_counters->if_group.ifInNUcastPkts = (counters->rx_multicast + counters->rx_broadcast);
    big_counters->if_group.ifInDiscards = counters->rx_drops;
    big_counters->if_group.ifInErrors = (counters->rx_crc_err + counters->rx_alignment_err + 
                                         counters->rx_undersize + counters->rx_oversize + 
                                         counters->rx_in_range_length_err +
                                         counters->rx_out_of_range_length_err +
                                         counters->rx_symbol_carrier_err +
                                         counters->rx_jabbers +
                                         counters->rx_fragments);
    
    /* Interfaces Group Tx counters */
    big_counters->if_group.ifOutOctets = counters->tx_out_bytes;
    big_counters->if_group.ifOutUcastPkts = counters->tx_unicast;
    big_counters->if_group.ifOutMulticastPkts = counters->tx_multicast;
    big_counters->if_group.ifOutBroadcastPkts = counters->tx_broadcast;
    big_counters->if_group.ifOutNUcastPkts = (counters->tx_multicast + counters->tx_broadcast);
    big_counters->if_group.ifOutDiscards = (counters->tx_queue_system_drops + 
                                            counters->tx_mac_drop);
    big_counters->if_group.ifOutErrors = (counters->tx_late_coll + counters->tx_csense +
                                          counters->tx_xcoll + counters->tx_underrun);

    /* Ethernet-like Rx counters */
    big_counters->ethernet_like.dot3StatsAlignmentErrors = counters->rx_alignment_err;
    big_counters->ethernet_like.dot3StatsFCSErrors = counters->rx_crc_err;
    big_counters->ethernet_like.dot3StatsFrameTooLongs = counters->rx_oversize;
    big_counters->ethernet_like.dot3StatsSymbolErrors = counters->rx_symbol_carrier_err;
    big_counters->ethernet_like.dot3ControlInUnknownOpcodes = counters->rx_unsup_opcode;
    big_counters->ethernet_like.dot3InPauseFrames = counters->rx_pause;
    
    /* Ethernet-like Tx counters */
    big_counters->ethernet_like.dot3StatsSingleCollisionFrames = counters->tx_backoff1;
    big_counters->ethernet_like.dot3StatsMultipleCollisionFrames = counters->tx_multi_coll;
    big_counters->ethernet_like.dot3StatsDeferredTransmissions = counters->tx_defer;
    big_counters->ethernet_like.dot3StatsLateCollisions = counters->tx_late_coll;
    big_counters->ethernet_like.dot3StatsExcessiveCollisions = counters->tx_xcoll;
    big_counters->ethernet_like.dot3StatsCarrierSenseErrors = counters->tx_csense;
    big_counters->ethernet_like.dot3OutPauseFrames = counters->tx_pause;
#endif /* VTSS_ARCH_GATWICK/B2 */

#ifdef VTSS_ARCH_HEATHROW
    /* RMON Rx counters */
    big_counters->rmon.rx_etherStatsDropEvents = counters->rx_drops;
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    big_counters->rmon.rx_etherStatsDropEvents += counters->rx_classified_drops;
#endif /* VTSS_ARCH_STANSTED/HAWX/SPARX_28 */
    big_counters->rmon.rx_etherStatsOctets = counters->rx_octets;
    big_counters->rmon.rx_etherStatsPkts = counters->rx_packets;
#if defined(VTSS_FEATURE_PORT_CNT_PKT_CAST)
    big_counters->rmon.rx_etherStatsBroadcastPkts = counters->rx_broadcasts;
    big_counters->rmon.rx_etherStatsMulticastPkts = counters->rx_multicasts;
#endif /* VTSS_FEATURE_PORT_CNT_PKT_CAST */
#if defined(VTSS_FEATURE_PORT_CNT_RMON_ADV)
    big_counters->rmon.rx_etherStatsCRCAlignErrors = counters->rx_crc_align_errors;
    big_counters->rmon.rx_etherStatsUndersizePkts = counters->rx_shorts;
    big_counters->rmon.rx_etherStatsOversizePkts = counters->rx_longs;
    big_counters->rmon.rx_etherStatsFragments = counters->rx_fragments;
    big_counters->rmon.rx_etherStatsJabbers = counters->rx_jabbers;
    big_counters->rmon.rx_etherStatsPkts64Octets = counters->rx_64;
    big_counters->rmon.rx_etherStatsPkts65to127Octets = counters->rx_65_127;
    big_counters->rmon.rx_etherStatsPkts128to255Octets = counters->rx_128_255;
    big_counters->rmon.rx_etherStatsPkts256to511Octets = counters->rx_256_511;
    big_counters->rmon.rx_etherStatsPkts512to1023Octets = counters->rx_512_1023;
#endif /* VTSS_FEATURE_PORT_CNT_RMON_ADV */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    /* rx_etherStatsPkts1024to1518Octets includes frames longer than 1518 bytes */
    big_counters->rmon.rx_etherStatsPkts1024to1518Octets = counters->rx_1024_max;
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    big_counters->rmon.rx_etherStatsPkts1024to1518Octets = counters->rx_1024_1526;
    big_counters->rmon.rx_etherStatsPkts1519toMaxOctets = counters->rx_1527_max;
#endif /* VTSS_ARCH_HAWX/SPARX_28 */

    /* RMON Tx counters */
#if defined(VTSS_ARCH_SPARX)
#if defined(VTSS_ARCH_SPARX_28)
    big_counters->rmon.tx_etherStatsDropEvents = (counters->tx_fifo_drops + counters->tx_aging);
#else
    big_counters->rmon.tx_etherStatsDropEvents = counters->tx_drops;
#endif /* VTSS_ARCH_SPARX_28 */
#else
    big_counters->rmon.tx_etherStatsDropEvents = counters->tx_fifo_drops;
#endif /* VTSS_ARCH_SPARX */
    big_counters->rmon.tx_etherStatsOctets = counters->tx_octets;
    big_counters->rmon.tx_etherStatsPkts = counters->tx_packets ;
#if defined(VTSS_FEATURE_PORT_CNT_PKT_CAST)
    big_counters->rmon.tx_etherStatsBroadcastPkts = counters->tx_broadcasts;
    big_counters->rmon.tx_etherStatsMulticastPkts = counters->tx_multicasts;
#endif /* VTSS_FEATURE_PORT_CNT_PKT_CAST */
#if defined(VTSS_FEATURE_PORT_CNT_RMON_ADV)
    big_counters->rmon.tx_etherStatsCollisions = counters->tx_collisions;
    big_counters->rmon.tx_etherStatsPkts64Octets = counters->tx_64;
    big_counters->rmon.tx_etherStatsPkts65to127Octets = counters->tx_65_127;
    big_counters->rmon.tx_etherStatsPkts128to255Octets = counters->tx_128_255;
    big_counters->rmon.tx_etherStatsPkts256to511Octets = counters->tx_256_511;
    big_counters->rmon.tx_etherStatsPkts512to1023Octets = counters->tx_512_1023;
#endif /* VTSS_FEATURE_PORT_CNT_RMON_ADV */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    /* tx_etherStatsPkts1024to1518Octets includes frames longer than 1518 bytes */
    big_counters->rmon.tx_etherStatsPkts1024to1518Octets = counters->tx_1024_max;
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    big_counters->rmon.tx_etherStatsPkts1024to1518Octets = counters->tx_1024_1526;
    big_counters->rmon.tx_etherStatsPkts1519toMaxOctets = counters->tx_1527_max;
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
    
    /* Interfaces Group Rx counters */
    /* ifInOctets includes bytes in bad frames */
    big_counters->if_group.ifInOctets = counters->rx_octets;
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    big_counters->if_group.ifInUcastPkts = subtract_floor0(
                                           (counters->rx_low_priority + 
                                            counters->rx_high_priority), /*-*/
                                           (counters->rx_multicasts +
                                            counters->rx_broadcasts) );
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX)
    big_counters->if_group.ifInUcastPkts = subtract_floor0(
                                           (counters->rx_class[0]+
                                            counters->rx_class[1]+
                                            counters->rx_class[2]+
                                            counters->rx_class[3]+
                                            counters->rx_class[4]+
                                            counters->rx_class[5]+
                                            counters->rx_class[6]+
                                            counters->rx_class[7]), /*-*/
                                           (counters->rx_multicasts +
                                            counters->rx_broadcasts) );
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_FEATURE_PORT_CNT_PKT_CAST)
#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    big_counters->if_group.ifInUcastPkts = subtract_floor0(
        counters->rx_packets + counters->rx_drops, 
        counters->rx_multicasts + counters->rx_broadcasts + counters->rx_errors);
#endif /* VTSS_ARCH_SPARX_G8/G24 */
#if defined(VTSS_ARCH_SPARX_28)
    big_counters->if_group.ifInUcastPkts = counters->rx_unicast;
#endif /* VTSS_ARCH_SPARX_28 */
    big_counters->if_group.ifInMulticastPkts = counters->rx_multicasts;
    big_counters->if_group.ifInBroadcastPkts = counters->rx_broadcasts;
    big_counters->if_group.ifInNUcastPkts = (counters->rx_multicasts + 
                                             counters->rx_broadcasts);
#endif /* VTSS_FEATURE_PORT_CNT_PKT_CAST */
    big_counters->if_group.ifInDiscards = big_counters->rmon.rx_etherStatsDropEvents;
#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    big_counters->if_group.ifInErrors = subtract_floor0(counters->rx_errors,
                                                        counters->rx_drops);
#else
    big_counters->if_group.ifInErrors = (counters->rx_crc_align_errors + 
                                         counters->rx_shorts + 
                                         counters->rx_longs +
                                         counters->rx_fragments +
                                         counters->rx_jabbers);
#endif /* VTSS_ARCH_SPARX_G8/G24 */
    
    /* Interfaces Group Tx counters */
    big_counters->if_group.ifOutOctets = counters->tx_octets;
#if defined(VTSS_FEATURE_PORT_CNT_PKT_CAST)
#if defined(VTSS_ARCH_SPARX_28)
    big_counters->if_group.ifOutUcastPkts = counters->tx_unicast;
#else
    big_counters->if_group.ifOutUcastPkts = subtract_floor0(
                                             counters->tx_packets, /*-*/
                                            (counters->tx_multicasts +
                                             counters->tx_broadcasts) );
#endif /* VTSS_ARCH_SPARX_28 */
    big_counters->if_group.ifOutMulticastPkts = counters->tx_multicasts;
    big_counters->if_group.ifOutBroadcastPkts = counters->tx_broadcasts;
    big_counters->if_group.ifOutNUcastPkts = (counters->tx_multicasts + 
                                              counters->tx_broadcasts);
#endif /* VTSS_FEATURE_PORT_CNT_PKT_CAST */
    big_counters->if_group.ifOutDiscards = big_counters->rmon.tx_etherStatsDropEvents;
#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    big_counters->if_group.ifOutErrors = counters->tx_errors; 
#else
    /* Late/excessive collisions and aged frames */
    big_counters->if_group.ifOutErrors = counters->tx_drops; 
#endif /* VTSS_ARCH_SPARX_G8/G24 */

    /* Ethernet-like Rx counters */
#if defined(VTSS_FEATURE_PORT_CNT_PAUSE)
    big_counters->ethernet_like.dot3InPauseFrames = counters->rx_pauses;
    
    /* Ethernet-like Tx counters */
    big_counters->ethernet_like.dot3OutPauseFrames = counters->tx_pauses;
#endif /* VTSS_FEATURE_PORT_CNT_PAUSE */

#endif /* VTSS_ARCH_HEATHROW */

#if defined(VTSS_FEATURE_PORT_CNT_BRIDGE)
    /* Bridge counters */
    big_counters->bridge.dot1dTpPortInDiscards = counters->rx_local_drops;
#endif /* VTSS_FEATURE_PORT_CNT_BRIDGE */  

    return VTSS_OK;
}

#if defined(VTSS_FEATURE_VSTAX)

/* - Stacking ------------------------------------------------------ */

vtss_rc vtss_vstax_setup_set(const vtss_vstax_setup_t * const setup)
{
    VTSS_D(("uid: %d", setup->uid));
    
    if (setup->uid < VTSS_VSTAX_UID_START || setup->uid >= VTSS_VSTAX_UID_END) {
        VTSS_E(("illegal uid: %d", setup->uid));
        return VTSS_INVALID_PARAMETER;
    }

    return vtss_ll_vstax_setup_set(setup);
}

vtss_rc vtss_vstax_port_setup_set(const vtss_port_no_t                  port_no,
                                  const vtss_vstax_port_setup_t * const setup)
{
    VTSS_D(("port_no: %d, enabled: %d, ttl: %d, mirror: %d", 
            port_no, setup->enable, setup->ttl, setup->mirror));
    
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }

    return vtss_ll_vstax_port_setup_set(port_no, setup);
}
#endif /* VTSS_FEATURE_VSTAX */


/* - Quality of Service -------------------------------------------- */

vtss_rc vtss_qos_prios_set(vtss_prio_t prios)
{
    vtss_rc        rc = VTSS_OK;
    BOOL           warning = 0;
    vtss_port_no_t port_no;

    VTSS_D(("prios: %d",prios));

    if (prios<VTSS_PRIO_START || prios>=VTSS_PRIO_END || prios==3 || (prios>=5 && prios<=7)) {
        VTSS_E(("illegal prios: %d",prios));
        return VTSS_UNSPECIFIED_ERROR;
    }

    if (prios != vs->prios) {
        vs->prios = prios;

        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (!vs->port_map.vtss_port_unused[port_no]) {
                if ((rc = vtss_ll_port_qos_setup_set(port_no, &vs->qos[port_no]))<VTSS_WARNING)
                    return rc;
                if (rc<0) warning = 1;

                if ((rc = vtss_ll_port_queue_setup(port_no))<VTSS_WARNING)
                    return rc;
                if (rc<0) warning = 1;
                
                if ((rc = vtss_ll_port_queue_enable(port_no, 1))<VTSS_WARNING)
                    return rc;
                if (rc<0) warning = 1;
            }
        }
        VTSS_RC(vtss_ll_qos_setup_set(&vs->qos_setup));
    }
    if (warning)
        rc = VTSS_WARNING;

    return rc;
}

vtss_rc vtss_port_qos_get(const vtss_port_no_t port_no,
                          vtss_port_qos_setup_t * const qos)
{
    VTSS_D(("port_no: %d",port_no));

    /* Check that the port number is valid */
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    *qos = vs->qos[port_no];

    return VTSS_OK;
}

vtss_rc vtss_port_qos_set(const vtss_port_no_t port_no,
                          const vtss_port_qos_setup_t * const qos)
{
    VTSS_D(("port_no: %d",port_no));

    /* Check that the port number is valid */
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    vs->qos[port_no] = *qos;
#if defined(VTSS_FEATURE_QOS_WFQ_PORT)
    /* Use WFQ water marks on all ports if any port has WFQ enabled */
    {
        vtss_port_no_t port;
        BOOL           wfq_old;

        wfq_old = vs->wfq;
        vs->wfq = 0;
        for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
            if (!vs->port_map.vtss_port_unused[port] && vs->qos[port].wfq_enable)
                vs->wfq = 1;
        }
        if (vs->wfq != wfq_old) {
            for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
                if (!vs->port_map.vtss_port_unused[port]) {
                    VTSS_RC(vtss_ll_port_queue_setup(port));
                }
            }
        }
    }
#endif /* VTSS_FEATURE_QOS_WFQ_PORT */

    return vtss_ll_port_qos_setup_set(port_no, qos);
}

/* Get QoS setup for switch */
vtss_rc vtss_qos_setup_get(vtss_qos_setup_t * const qos)
{
    VTSS_D(("enter"));

    *qos = vs->qos_setup;

    return VTSS_OK;
}

/* Set QoS setup for switch */
vtss_rc vtss_qos_setup_set(const vtss_qos_setup_t * const qos)
{
    VTSS_D(("enter"));

    vs->qos_setup = *qos;

    return vtss_ll_qos_setup_set(qos);
}

#if defined(VTSS_ARCH_B2)
/* Get QoS setup for logical port */
vtss_rc vtss_lport_qos_get(const vtss_lport_no_t          lport_no,
                           vtss_lport_qos_setup_t * const qos)
{
    VTSS_D(("enter, lport_no: %u", lport_no));
    
    if (lport_no >= VTSS_LPORTS) {
        VTSS_E(("illegal lport_no: %u", lport_no));
        return VTSS_INVALID_PARAMETER;
    }

    *qos = vs->lport_qos[lport_no];

    return VTSS_OK;
}

/* Set QoS setup for logical port */
vtss_rc vtss_lport_qos_set(const vtss_lport_no_t                lport_no,
                           const vtss_lport_qos_setup_t * const qos)
{
    VTSS_D(("enter, lport_no: %u", lport_no));
    
    return vtss_ll_lport_qos_set(lport_no, qos);
}
#endif /* VTSS_ARCH_B2 */

/* - QoS Control Lists --------------------------------------------- */
#if defined(VTSS_FEATURE_QCL_PORT)
vtss_rc vtss_qce_add(const vtss_qcl_id_t         qcl_id,
                     const vtss_qce_id_t         qce_id,
                     const vtss_qce_t    * const qce)
{
    VTSS_D(("enter, qcl_id: %d, qce_id: %ld", qcl_id, qce_id));
    
    return vtss_ll_qce_add(qcl_id, qce_id, qce);
}

vtss_rc vtss_qce_del(const vtss_qcl_id_t  qcl_id,
                     const vtss_qce_id_t  qce_id)
{
    VTSS_D(("enter, qcl_id: %d, qce_id: %ld", qcl_id, qce_id));

    return vtss_ll_qce_del(qcl_id, qce_id);
}
#endif /* VTSS_FEATURE_QCL_PORT */

/* ================================================================= *
 *  Security
 * ================================================================= */

#if defined(VTSS_FEATURE_LAYER2)
/* - Port Based Network Access Control, 802.1X --------------------- */
vtss_rc vtss_port_auth_state_set(const vtss_port_no_t    port_no,
                                 const vtss_auth_state_t auth_state)
{
    BOOL dest_update = 0;
    
    VTSS_D(("port_no: %d, auth_state: %s",
            port_no,
            auth_state==VTSS_AUTH_STATE_NONE ? "VTSS_AUTH_STATE_NONE" :
            auth_state==VTSS_AUTH_STATE_EGRESS ? "VTSS_AUTH_STATE_EGRESS" : 
            "VTSS_AUTH_STATE_BOTH"));

    /* Check that the port number is valid */
    if (!(VTSS_PORT_IS_PORT(port_no))) {
        VTSS_E(("illegal port_no: %d", port_no));
        return VTSS_INVALID_PARAMETER;
    }

    /* Check that the Authentication state is valid */
    switch (auth_state) {
    case VTSS_AUTH_STATE_NONE:
    case VTSS_AUTH_STATE_EGRESS:
    case VTSS_AUTH_STATE_BOTH:
        break;
    default:
        VTSS_E(("Illegal auth state: %d", auth_state));
        return VTSS_INVALID_PARAMETER;
        break;
    }

    vs->auth_state[port_no] = auth_state; 
#if defined(VTSS_FEATURE_AGGR_GLAG)
    dest_update = (vs->port_glag_no[port_no] != 0);
#endif /* VTSS_FEATURE_AGGR_GLAG */
    return vtss_update_masks(1, dest_update, 1);
}
#endif /* VTSS_FEATURE_LAYER2 */

/* - SIP filters --------------------------------------------------- */

#if defined(VTSS_FEATURE_FILTER_SIP)
vtss_rc vtss_filter_sip_set(const vtss_port_no_t port_no,
                            const vtss_ip_t      sip,
                            const vtss_ip_t      mask)
{
    VTSS_D(("port_no: %d, sip: 0x%08lx, mask: 0x%08lx", port_no, sip, mask));

    /* Check that the port number is valid */
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }

    return vtss_ll_filter_sip_set(port_no, sip, mask);
}
#endif /* VTSS_FEATURE_FILTER_SIP */

/* - UDP/TCP filters ----------------------------------------------- */

#if defined(VTSS_FEATURE_FILTER_UDP_TCP)
vtss_rc vtss_filter_udp_tcp_set(const vtss_filter_action_t * const action,
                                const vtss_udp_tcp_t               port_1,
                                const vtss_udp_tcp_t               port_2)
{
    VTSS_D(("fwd: %d, cpu: %d, port_1: %d, port_2: %d",
            action->forward, action->cpu, port_1, port_2));

    return vtss_ll_filter_udp_tcp_set(action, port_1, port_2);
}
#endif /* VTSS_FEATURE_FILTER_UDP_TCP */

#if defined(VTSS_ARCH_B2)
vtss_rc vtss_port_filter_set(const vtss_port_no_t             port_no,
                             const vtss_port_filter_t * const filter)
{    
    vs->filter[port_no] = *filter;
    return vtss_ll_port_filter_set(port_no, filter);
}

vtss_rc vtss_port_filter_get(vtss_port_no_t       port_no,
                             vtss_port_filter_t * filter)
{    
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    *filter = vs->filter[port_no];

    return VTSS_OK;
}
#endif /* VTSS_ARCH_B2 */



/* - Access Control Lists ------------------------------------------ */

#if defined(VTSS_FEATURE_ACL)
vtss_rc vtss_acl_policer_rate_set(const vtss_acl_policer_no_t policer_no,
                                  const vtss_packet_rate_t    rate)
{
    VTSS_D(("policer_no: %d, rate: %ld", policer_no, rate));
    
    return vtss_ll_acl_policer_rate_set(policer_no, rate);
}

vtss_rc vtss_acl_port_action_set(const vtss_port_no_t            port_no,
                                 const vtss_acl_action_t * const action)
{
    VTSS_D(("port_no: %d", port_no));

    return vtss_ll_acl_port_action_set(port_no, action);
}

vtss_rc vtss_acl_port_counter_get(const vtss_port_no_t            port_no,
                                  vtss_acl_port_counter_t * const counter)
{
    return vtss_ll_acl_port_counter_get(port_no, counter);
}

vtss_rc vtss_acl_port_counter_clear(const vtss_port_no_t port_no)
{
    return vtss_ll_acl_port_counter_clear(port_no);
}

vtss_rc vtss_acl_policy_no_set(const vtss_port_no_t       port_no,
                               const vtss_acl_policy_no_t policy_no)
{
    VTSS_D(("port_no: %d, policy: %d", port_no, policy_no));
    
    return vtss_ll_acl_policy_no_set(port_no, policy_no);
}

vtss_rc vtss_ace_init(const vtss_ace_type_t type,
                      vtss_ace_t * const    ace)
{
    VTSS_D(("type: %d", type));

    memset(ace, 0, sizeof(*ace));
    ace->type = type;
    ace->action.forward = 1;
    ace->action.learn = 1;
    ace->dmac_bc = VTSS_ACE_BIT_ANY;
    ace->dmac_mc = VTSS_ACE_BIT_ANY;
    ace->vlan.cfi = VTSS_ACE_BIT_ANY;

    switch (type) {
    case VTSS_ACE_TYPE_ANY:
    case VTSS_ACE_TYPE_ETYPE:
    case VTSS_ACE_TYPE_LLC:
    case VTSS_ACE_TYPE_SNAP:
    case VTSS_ACE_TYPE_IPV6:
        break;
    case VTSS_ACE_TYPE_ARP:
        ace->frame.arp.arp = VTSS_ACE_BIT_ANY;
        ace->frame.arp.req = VTSS_ACE_BIT_ANY;
        ace->frame.arp.unknown = VTSS_ACE_BIT_ANY;
        ace->frame.arp.smac_match = VTSS_ACE_BIT_ANY;
        ace->frame.arp.dmac_match = VTSS_ACE_BIT_ANY;
        ace->frame.arp.length = VTSS_ACE_BIT_ANY;
        ace->frame.arp.ip = VTSS_ACE_BIT_ANY;
        ace->frame.arp.ethernet = VTSS_ACE_BIT_ANY;
        break;
    case VTSS_ACE_TYPE_IPV4:
        ace->frame.ipv4.ttl = VTSS_ACE_BIT_ANY;
        ace->frame.ipv4.fragment = VTSS_ACE_BIT_ANY;
        ace->frame.ipv4.options = VTSS_ACE_BIT_ANY;
        ace->frame.ipv4.sport.high = 0xffff;
        ace->frame.ipv4.sport.in_range = 1;
        ace->frame.ipv4.dport.high = 0xffff;
        ace->frame.ipv4.dport.in_range = 1;
        ace->frame.ipv4.tcp_fin = VTSS_ACE_BIT_ANY;
        ace->frame.ipv4.tcp_syn = VTSS_ACE_BIT_ANY;
        ace->frame.ipv4.tcp_rst = VTSS_ACE_BIT_ANY;
        ace->frame.ipv4.tcp_psh = VTSS_ACE_BIT_ANY;
        ace->frame.ipv4.tcp_ack = VTSS_ACE_BIT_ANY;
        ace->frame.ipv4.tcp_urg = VTSS_ACE_BIT_ANY;
        break;
    default:
        VTSS_E(("unknown type: %d", type));
        return VTSS_INVALID_PARAMETER;
    }

    return VTSS_OK;
}

vtss_rc vtss_ace_add(const vtss_ace_id_t      ace_id,
                     const vtss_ace_t * const ace)
{
    VTSS_D(("ace_id: %ld before %ld %s", 
            ace->id, ace_id, ace_id == VTSS_ACE_ID_LAST ? "(last)" : ""));

    return vtss_ll_ace_add(ace_id, ace);
}

vtss_rc vtss_ace_del(const vtss_ace_id_t ace_id)
{
    VTSS_D(("ace_id: %ld", ace_id));

    return vtss_ll_ace_del(ace_id);
}

vtss_rc vtss_ace_counter_get(const vtss_ace_id_t        ace_id,
                             vtss_ace_counter_t * const counter)
{
    VTSS_D(("ace_id: %ld", ace_id));

    return vtss_ll_ace_counter_get(ace_id, counter);
}

vtss_rc vtss_ace_counter_clear(const vtss_ace_id_t ace_id)
{
    return vtss_ll_ace_counter_clear(ace_id);
}
#endif /* VTSS_FEATURE_ACL */


/* ================================================================= *
 *  Packet RX/TX
 * ================================================================= */

#if defined(VTSS_FEATURE_CPU_RX_TX)
/* - RX frame registration ----------------------------------------- */

#if (VTSS_CPU_RX_QUEUES>1)
vtss_rc vtss_cpu_rx_queue_map_set(vtss_cpu_rx_queue_map_t * const map)
{
    vtss_cpu_rx_queue_t queue_no;
    int             i;
    
    /* Check queues */
    for (i=0; i<(sizeof(*map)/sizeof(queue_no)); i++) {
        queue_no = *((vtss_cpu_rx_queue_t *)map+i);
        if (queue_no<VTSS_CPU_RX_QUEUE_START || queue_no>=VTSS_CPU_RX_QUEUE_END) {
            VTSS_E(("illegal queue: %d, index: %d",queue_no,i));
            return VTSS_INVALID_PARAMETER;
        }
        VTSS_D(("legal queue: %d, index: %d",queue_no,i));
    }
    
    return vtss_ll_cpu_rx_queue_map_set(map);
}

#if defined(VTSS_ARCH_GATWICK) || defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
vtss_rc vtss_cpu_rx_queue_size_set(const vtss_cpu_rx_queue_t queue_no, 
                                   const vtss_cpu_rx_queue_size_t size)
{
    if (queue_no<VTSS_CPU_RX_QUEUE_START || queue_no>=VTSS_CPU_RX_QUEUE_END) {
        VTSS_E(("illegal queue: %d",queue_no));
        return VTSS_INVALID_PARAMETER;
    }

    return vtss_ll_cpu_rx_queue_size_set(queue_no, size);
}
#endif /* VTSS_ARCH_GATWICK/HAWX/SPARX_28 */    
#endif /* VTSS_CPU_RX_QUEUES>1 */

vtss_rc vtss_cpu_rx_registration_get(vtss_cpu_rx_registration_t *const registration)
{
    VTSS_D(("enter"));

    *registration = vtss_api_state->rx_registration;
    return VTSS_OK;
}

vtss_rc vtss_cpu_rx_registration_set(const vtss_cpu_rx_registration_t *const registration)
{
    VTSS_D(("enter"));

    vtss_api_state->rx_registration = *registration;
    
    return vtss_ll_frame_reg_set(registration);
}

/* - RX frames ----------------------------------------------------- */

vtss_rc vtss_cpu_rx_frameready_int_enable(const vtss_cpu_rx_queue_t queue_no,
                                          const BOOL enable)
{
    VTSS_D(("queue_no: %d, enable: %d",queue_no,enable));

    return vtss_ll_frame_rx_ready_int(queue_no, enable);
}

vtss_rc vtss_cpu_rx_frameready(const vtss_cpu_rx_queue_t queue_no)
{
    vtss_rc rc;

#if VTSS_OPT_DMA
    rc = vtss_ll_frame_dma_rx_ready();
#else
    rc = vtss_ll_frame_rx_ready(queue_no);
#endif /* VTSS_OPT_DMA */

    VTSS_N(("queue_no: %d rc: %d",queue_no,rc));
    
    return rc;
}

vtss_rc vtss_cpu_rx_frame(const vtss_cpu_rx_queue_t queue_no,
                          vtss_system_frame_header_t * const sys_header,
                          uchar * const frame, 
                          const uint maxlength)
{
    VTSS_N(("queue_no: %d",queue_no));
    
#if VTSS_OPT_DMA
    return vtss_ll_frame_dma_rx(sys_header, frame, maxlength);
#else
    return vtss_ll_frame_rx(queue_no, sys_header, frame, maxlength);
#endif /* VTSS_OPT_DMA */
}

vtss_rc vtss_cpu_rx_discard_frame(const vtss_cpu_rx_queue_t queue_no)
{
    VTSS_N(("queue_no: %d",queue_no));

#if VTSS_OPT_DMA
    return vtss_ll_frame_dma_rx_discard();
#else
    return vtss_ll_frame_rx_discard(queue_no);
#endif
}

/* - TX frames ----------------------------------------------------- */

vtss_rc vtss_cpu_tx_raw_frame(const vtss_poag_no_t poag_no,
                              const uchar * const  frame,
                              const uint           length)
{
    vtss_port_no_t         port_no;
#if defined(VTSS_FEATURE_VSTAX)
    vtss_vstax_tx_header_t vstax;

    vstax.fwd_mode = VTSS_VSTAX_FWD_MODE_CPU_ALL;
    vstax.ttl = 1;
    vstax.prio = VTSS_PRIO_SUPER;
    vstax.tci.vid = VTSS_VID_NULL;
    vstax.tci.cfi = 0;
    vstax.tci.tagprio = 0;
    vstax.port_no = 0;
    vstax.glag_no = 0;
    vstax.queue_no = VTSS_CPU_RX_QUEUE_START;
#endif /* VTSS_FEATURE_VSTAX */
    
    VTSS_N(("length: %d",length));

    if (VTSS_PORT_IS_PORT(poag_no)) {
        port_no = poag_no;
        if (vs->stp_state[port_no]==VTSS_STP_STATE_DISABLED) {
            VTSS_E(("port_no STP disabled: %d", port_no));
            return VTSS_UNSPECIFIED_ERROR;
        }
    } else {
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (vs->port_poag_no[port_no] == poag_no && 
                VTSS_STP_FORWARDING(vs->stp_state[port_no])) {
                break;
            }
        }
        if (port_no == VTSS_PORT_NO_END) {
            VTSS_E(("no ports up for poag_no: %d", poag_no));
            return VTSS_UNSPECIFIED_ERROR;
        }
    }


    /* If egress mirroring is enabled, send on mirror port */
    if (vs->mirror_egress[port_no] && port_no != vs->mirror_port && 
        vs->mirror_port != 0 && VTSS_STP_FORWARDING(vs->stp_state[vs->mirror_port])) {
        vtss_rc rc;

        if ((rc = vtss_ll_frame_tx(vs->mirror_port, frame, length, VTSS_VID_NULL
#if defined(VTSS_FEATURE_VSTAX)
                                 , NULL
#endif /* VTSS_FEATURE_VSTAX */
                 )) < 0)
            return rc;
    }
    
    return vtss_ll_frame_tx(port_no, frame, length, VTSS_VID_NULL
#if defined(VTSS_FEATURE_VSTAX)
                            , vs->vstax_port_setup[port_no].enable ? &vstax : NULL
#endif /* VTSS_FEATURE_VSTAX */
        );
}

/* Transmit frame filtered on VLAN or aggregation */
static vtss_rc vtss_cpu_tx_frame(const vtss_poag_no_t poag_no,
                                 const vtss_vid_t     vid,
                                 const uchar * const  frame,
                                 const uint           length,
                                 BOOL                 vlan)
{
    vtss_rc                rc;
    vtss_port_no_t         port_no;
    vtss_pgid_entry_t      *pgid_entry;
    vtss_mac_table_entry_t entry;
    vtss_pgid_no_t         pgid_no;
    int                    i;
    BOOL                   mirror, mirror_done;
    vtss_cpu_frame_info_t  info;
    vtss_cpu_filter_t      filter;
#if defined(VTSS_FEATURE_VSTAX)
    vtss_vstax_tx_header_t vstax;

    vstax.fwd_mode = VTSS_VSTAX_FWD_MODE_LOOKUP;
    vstax.ttl = VTSS_VSTAX_TTL_PORT;
    vstax.prio = VTSS_PRIO_START;
    vstax.tci.vid = vid;
    vstax.tci.cfi = 0;
    vstax.tci.tagprio = 0;
#endif /* VTSS_FEATURE_VSTAX */

    pgid_entry = NULL;
    if (vlan) {
        /* Lookup (VID, DMAC) */
        entry.vid_mac.vid = vid;
        for (i = 0; i < sizeof(entry.vid_mac.mac); i++)
            entry.vid_mac.mac.addr[i] = frame[i];
        rc = vtss_ll_mac_table_lookup(&entry, &pgid_no);
        if (rc >= 0) {
            pgid_entry = &vs->pgid_table[pgid_no];
        } else if (rc != VTSS_ENTRY_NOT_FOUND) {
            return rc;
        }
    }

    mirror = 0;
    mirror_done = 0;
    info.port_no = 0;
#if defined(VTSS_FEATURE_AGGR_GLAG)
    info.glag_no = 0;
#endif /* VTSS_FEATURE_AGGR_GLAG */
    info.vid = vid;
    /* Transmit on ports */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {    

        /* Aggregation member check */
        if (!vlan && vs->port_poag_no[port_no] != poag_no) {
            VTSS_N(("port_no: %d not member of poag_no: %d", port_no, poag_no));
            continue;
        }

        /* Destination port check */
        if (vlan && pgid_entry != NULL && !pgid_entry->member[port_no]) {
            BOOL           found_agg_member = 0;
            vtss_port_no_t i_port_no;
            vtss_poag_no_t poag;

            /* If the port is aggregated and any of the member ports are included in 
               the destination member set, the port is considered a destination member */
            if ((poag = vs->port_poag_no[port_no]) != port_no) {
                for (i_port_no = VTSS_PORT_NO_START; i_port_no < VTSS_PORT_NO_END; 
                     i_port_no++) {    
                    if (vs->port_poag_no[i_port_no] == poag && 
                        pgid_entry->member[i_port_no]) {
                        found_agg_member = 1;
                    }
                }
            }
            if (!found_agg_member) {
                VTSS_N(("port_no: %d not a destination member", port_no));
                continue;
            }
        }

        /* Egress filtering */
        info.port_tx = port_no;
        if (vtss_cpu_filter(&info, &filter) != VTSS_OK || filter == VTSS_CPU_FILTER_DISCARD)
            continue;
        
        /* All checks successful, transmit on port */
        VTSS_N(("Tx on port_no: %d", port_no));
        if ((rc = vtss_ll_frame_tx(port_no, frame, length,
                                   filter == VTSS_CPU_FILTER_TAGGED ? vid : VTSS_VID_NULL
#if defined(VTSS_FEATURE_VSTAX)
                                   , vs->vstax_port_setup[port_no].enable ? &vstax : NULL
#endif /* VTSS_FEATURE_VSTAX */
                 )) < 0)
            return rc;

        /* Check if egress mirroring must be done */
        if (vs->mirror_egress[port_no])
            mirror = 1;
        
        /* Check if egress mirroring has been done */
        if (port_no == vs->mirror_port)
            mirror_done = 1;
        
    }

    port_no = vs->mirror_port;
    if (mirror && !mirror_done && port_no != 0 &&
        VTSS_STP_FORWARDING(vs->stp_state[port_no])) {
        if ((rc = vtss_ll_frame_tx(port_no, frame, length,
                                   vs->vlan_port_table[port_no].untagged_vid != VTSS_VID_ALL &&
                                   vs->vlan_port_table[port_no].untagged_vid != vid ? 
                                   vid : VTSS_VID_NULL
#if defined(VTSS_FEATURE_VSTAX)
                                 , NULL
#endif /* VTSS_FEATURE_VSTAX */
                 )) < 0)
            return rc;
    }
    return VTSS_OK;
}

vtss_rc vtss_cpu_tx_poag_frame(const vtss_poag_no_t poag_no,
                               const vtss_vid_t     vid,
                               const uchar * const  frame,
                               const uint           length)
{
    return vtss_cpu_tx_frame(poag_no, vid, frame, length, 0);
}

vtss_rc vtss_cpu_tx_vlan_frame(const vtss_vid_t    vid,
                               const uchar * const frame,
                               const uint          length)
{
    return vtss_cpu_tx_frame(0, vid, frame, length, 1);
}

vtss_rc vtss_cpu_filter(const vtss_cpu_frame_info_t * const info,
                        vtss_cpu_filter_t * const           filter)
{
    vtss_port_no_t    port_rx, port_tx;
    vtss_vlan_entry_t *vlan_entry;
    vtss_vid_t        uvid;

    /* Discard by default */
    *filter = VTSS_CPU_FILTER_DISCARD; 
    port_rx = info->port_no;
    port_tx = info->port_tx;
    vlan_entry = (info->vid == VTSS_VID_NULL ? NULL : &vs->vlan_table[info->vid]);

    if (port_rx) {
        if (port_tx && vs->port_poag_no[port_rx] == vs->port_poag_no[port_tx]) {
            /* Ingress LLAG filter */
            VTSS_N(("port_rx %d and port_tx %d are members of same LLAG %d", 
                    port_rx, port_tx, vs->port_poag_no[port_tx]));
            return VTSS_OK;
        } 

        if (!VTSS_PORT_RX_FORWARDING(vs->port_forward[port_rx])) {
            /* Ingress port forward filtering */
            VTSS_N(("port_rx %d not ingress forwarding", port_rx));
            return VTSS_OK;
        }

        if (!VTSS_STP_FORWARDING(vs->stp_state[port_rx])) {
            /* Ingress STP filtering */
            VTSS_N(("port_rx %d not STP forwarding", port_rx));
            return VTSS_OK;
        }

        if (vs->auth_state[port_rx] == VTSS_AUTH_STATE_NONE) {
            /* Ingress authentication filter */
            VTSS_N(("port_rx %d not authenticated", port_rx));
            return VTSS_OK;
        }
        
        if (vlan_entry != NULL && !vlan_entry->member[port_rx] && 
            vs->vlan_port_table[port_rx].ingress_filter) {
            /* VLAN ingress filtering */
            VTSS_N(("port_rx %d not member of VLAN %d", port_rx, info->vid));
            return VTSS_OK;
        }
    }

#if defined(VTSS_FEATURE_AGGR_GLAG)    
    if (port_tx && info->glag_no && info->glag_no == vs->port_glag_no[port_tx]) {
        /* Ingress GLAG filter */
        VTSS_N(("port_tx %d is member of GLAG %d", port_tx, info->glag_no));
        return VTSS_OK;
    } 
#endif /* VTSS_FEATURE_AGGR_GLAG */

    if (port_tx) {
        if (vlan_entry != NULL) {
            if (!vlan_entry->member[port_tx]) {
                /* Egress VLAN filter */
                VTSS_N(("port_tx %d not member of VLAN %d", port_tx, info->vid));
                return VTSS_OK;
            }
            
            if (vs->mstp_table[vlan_entry->msti].state[port_tx] != VTSS_MSTP_STATE_FORWARDING) {
                /* Egress MSTP filter */
                VTSS_N(("port_tx: %d, VLAN %d not MSTP forwarding", port_tx, info->vid));
                return VTSS_OK;
            }
        }
    
        if (!vs->aggr_member[port_tx]) {
            /* Egress LAG/STP check */
            VTSS_N(("port_tx: %d not LAG/STP forwarding", port_tx));
            return VTSS_OK;
        }

        /* Determine whether to send tagged or untagged */
        uvid = vs->vlan_port_table[port_tx].untagged_vid;
        *filter = (uvid != VTSS_VID_ALL && uvid != info->vid ? 
                   VTSS_CPU_FILTER_TAGGED : VTSS_CPU_FILTER_UNTAGGED);
    } else {
        /* No egress filtering */
        *filter = VTSS_CPU_FILTER_UNTAGGED;
    }
    return VTSS_OK;
}


#if defined(VTSS_FEATURE_VSTAX)
vtss_rc vtss_tx_vstax_frame(const vtss_port_no_t                 port_no,
                            const vtss_vstax_tx_header_t * const vstax_header,
                            const uchar * const                  frame,
                            const uint                           length)
{
    return vtss_ll_frame_tx(port_no, frame, length, VTSS_VID_NULL, vstax_header);
}

vtss_rc vtss_vstax_header_get(const vtss_port_no_t                 port_no,
                              const vtss_vstax_tx_header_t * const vstax_header,
                              uchar * const                        frame)
{
    return vtss_ll_vstax_header_get(port_no, vstax_header, frame);
}

vtss_rc vtss_vstax_header_put(const uchar * const            frame,
                              vtss_vstax_rx_header_t * const vstax_header)
{
    return vtss_ll_vstax_header_put(frame, vstax_header);
}

#endif /* VTSS_FEATURE_VSTAX */

#endif /* VTSS_FEATURE_CPU_RX_TX */


/* ================================================================= *
 *  Layer 2
 * ================================================================= */

#if defined(VTSS_FEATURE_LAYER2)
#if defined(VTSS_ARCH_GATWICK)
/* Determine combined STP and MSTP state */
static vtss_mstp_state_t vtss_mstp_state(vtss_stp_state_t stp_state,
                                         vtss_mstp_state_t mstp_state)
{
    if (VTSS_STP_FORWARDING(stp_state) && mstp_state==VTSS_MSTP_STATE_FORWARDING) {
        /* STP and MSTP forwarding */
        mstp_state = VTSS_MSTP_STATE_FORWARDING;
    } else if (stp_state==VTSS_STP_STATE_DISABLED ||
               stp_state==VTSS_STP_STATE_BLOCKING ||
               stp_state==VTSS_STP_STATE_LISTENING ||
               mstp_state==VTSS_MSTP_STATE_DISCARDING) {
        /* STP or MSTP discarding */
        mstp_state = VTSS_MSTP_STATE_DISCARDING;
    } else {
        /* STP or MSTP learning */
#if defined(VTSS_CHIPS)
        /* 48-port solution can not support learning state */
        mstp_state = VTSS_MSTP_STATE_DISCARDING;
#else
        mstp_state = VTSS_MSTP_STATE_LEARNING;            
#endif /* VTSS_CHIPS */
    }
    return mstp_state;
}
#endif /* VTSS_ARCH_GATWICK */

/* - Port STP State ------------------------------------------------ */

vtss_rc vtss_port_stp_state_get(const vtss_port_no_t     port_no,
                                vtss_stp_state_t * const stp_state)
{
    /* Check that the port number is valid */
    if (!(VTSS_PORT_IS_PORT(port_no))) {
        VTSS_E(("illegal port_no: %d", port_no));
        return VTSS_INVALID_PARAMETER;
    }

    *stp_state = vs->stp_state[port_no];
    VTSS_D(("port_no: %d, stp_state: %s",port_no,vtss_stp_state_str(*stp_state)));
    return VTSS_OK;
}

vtss_rc vtss_port_stp_state_set(const vtss_port_no_t port_no,
                                const vtss_stp_state_t stp_state)
{
    BOOL dest_update = 0;

    VTSS_D(("port_no: %d, stp_state: %s",port_no,vtss_stp_state_str(stp_state)));

    /* Check that the port number is valid */
    if (!(VTSS_PORT_IS_PORT(port_no))) {
        VTSS_E(("illegal port_no: %d", port_no));
        return VTSS_INVALID_PARAMETER;
    }

    /* Check that the STP state is valid */
    switch (stp_state) {
    case VTSS_STP_STATE_DISABLED:
    case VTSS_STP_STATE_BLOCKING:
    case VTSS_STP_STATE_LISTENING:
    case VTSS_STP_STATE_LEARNING:
    case VTSS_STP_STATE_FORWARDING:
    case VTSS_STP_STATE_ENABLED:
        break;
    default:
        VTSS_E(("Illegal stp_state: %d", stp_state));
        return VTSS_INVALID_PARAMETER;
        break;
    }

    vs->stp_state[port_no] = stp_state; 
#if defined(VTSS_ARCH_GATWICK)
    /* Single STP uses the first entry in the MSTP table */
    VTSS_RC(vtss_ll_mstp_table_write(port_no, VTSS_MSTI_START, 
                                     vtss_mstp_state(
                                         stp_state,
                                         vs->mstp_table[VTSS_MSTI_START].state[port_no])));
#endif /* VTSS_ARCH_GATWICK */

    VTSS_RC(vtss_ll_port_queue_enable(port_no, 1));
#if defined(VTSS_FEATURE_AGGR_GLAG)
    dest_update = (vs->port_glag_no[port_no] != 0);
#endif /* VTSS_FEATURE_AGGR_GLAG */
    return vtss_update_masks(1, dest_update, 1);
}

vtss_rc vtss_port_mstp_state_set(vtss_port_no_t port_no, 
                                 vtss_msti_t msti,
                                 vtss_mstp_state_t mstp_state)
{
    VTSS_D(("port_no: %d",port_no));

    /* Check that the poag number is valid */
    if (!(VTSS_PORT_IS_PORT(port_no))) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }

    /* Check that the MSTP instance is valid */
    if (msti < VTSS_MSTI_START || msti >= vs->msti_end) {
        VTSS_E(("illegal msti: %d", msti));
        return VTSS_INVALID_PARAMETER;
    }

    /* Check that the MSTP state is valid */
    if (mstp_state!=VTSS_MSTP_STATE_DISCARDING && 
        mstp_state!=VTSS_MSTP_STATE_LEARNING && 
        mstp_state!=VTSS_MSTP_STATE_FORWARDING) {
        VTSS_E(("illegal state: %d", mstp_state));
        return VTSS_INVALID_PARAMETER;
    }

    vs->mstp_table[msti].state[port_no] = mstp_state;

#if defined(VTSS_ARCH_GATWICK)
    if (msti==VTSS_MSTI_START) {
        mstp_state = vtss_mstp_state(vs->stp_state[port_no], mstp_state);
    }
#endif /* VTSS_ARCH_GATWICK */

    return vtss_ll_mstp_table_write(port_no, msti, mstp_state);
}

vtss_rc vtss_mstp_vlan_set(vtss_vid_t vid, vtss_msti_t msti)
{
    VTSS_D(("vid: %d, msti: %d", vid, msti));

    /* Check that the MSTP instance is valid */
    if (msti < VTSS_MSTI_START || msti >= vs->msti_end) {
        VTSS_E(("illegal msti: %d", msti));
        return VTSS_INVALID_PARAMETER;
    }

    vs->vlan_table[vid].msti = msti;
    return vtss_ll_vlan_table_mstp_set(vid, msti);
}

/* - Learning options ---------------------------------------------- */

#if defined(VTSS_FEATURE_LEARN_PORT)
vtss_rc vtss_learn_port_mode_set(const vtss_port_no_t      port_no,
                                 vtss_learn_mode_t * const learn_mode)
{
    VTSS_D(("port_no: %d",port_no));

    /* Check that the poag number is valid */
    if (!(VTSS_POAG_IS_PORT(port_no))) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }

    return vtss_ll_learn_port_mode_set(port_no, learn_mode);
}
#endif /* VTSS_FEATURE_LEARN_PORT */ 

#if defined(VTSS_FEATURE_LEARN_SWITCH)
vtss_rc vtss_learn_mode_set(vtss_learn_mode_t * const learn_mode)
{
    return vtss_ll_learn_mode_set(learn_mode);
}
#endif /* VTSS_FEATURE_LEARN_SWITCH */ 

/* - VLAN Port Mode ------------------------------------------------ */

/* Get VLAN mode for port or aggregation */
vtss_rc vtss_vlan_port_mode_get(const vtss_port_no_t port_no,
                                vtss_vlan_port_mode_t * const vlan_mode)
{
    VTSS_D(("port_no: %d",port_no));

    /* Check that the poag number is valid */
    if (!(VTSS_POAG_IS_PORT(port_no))) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }

    *vlan_mode = vs->vlan_port_table[port_no];
    return VTSS_OK;
}

vtss_rc vtss_vlan_port_mode_set(const vtss_port_no_t port_no,
                                const vtss_vlan_port_mode_t * const vlan_mode)
{
    VTSS_D(("port_no: %d",port_no));

    /* Check that the poag number is valid */
    if (!(VTSS_PORT_IS_PORT(port_no))) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }

    vs->vlan_port_table[port_no] = *vlan_mode;
    return vtss_ll_vlan_port_mode_set(port_no, vlan_mode);
}

/* - VLAN Table ---------------------------------------------------- */

vtss_rc vtss_vlan_port_members_get(const vtss_vid_t vid,
                                   BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    VTSS_D(("vid: %d",vid));

    /* Return internal state information */
    memcpy(member, vs->vlan_table[vid].member, sizeof(vs->vlan_table[vid].member));
    return VTSS_OK;
}

vtss_rc vtss_vlan_port_members_set(const vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_port_no_t port_no;

    VTSS_D(("vid: %d", vid));

    VTSS_RC(vtss_ll_vlan_table_write(vid, member));
    
    memcpy(vs->vlan_table[vid].member, member, VTSS_PORT_ARRAY_SIZE*sizeof(BOOL)); 
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (member[port_no])
            break;
    }
    vs->vlan_table[vid].enabled = (port_no != VTSS_PORT_NO_END);

    return VTSS_OK;
}

#if defined(VTSS_FEATURE_ISOLATED_PORT)

/* - Port Isolation------------------------------------------------- */

vtss_rc vtss_isolated_vlan_set(const vtss_vid_t vid,
                               const BOOL       isolated)
{
    vtss_vlan_entry_t *vlan_entry;

    VTSS_D(("vid: %d, isolated: %d", vid, isolated));

    vlan_entry = &vs->vlan_table[vid];
    vlan_entry->isolated = isolated;
    return vtss_ll_vlan_table_write(vid, vlan_entry->member);
}

vtss_rc vtss_isolated_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    VTSS_D(("enter"));
    
    return vtss_ll_isolated_ports_set(member);
}
#endif /* VTSS_FEATURE_ISOLATED_PORT */


/* - Private VLAN (PVLAN) ------------------------------------------ */

vtss_rc vtss_pvlan_port_members_get(const vtss_pvlan_no_t pvlan_no,
                                    BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    VTSS_D(("pvlan_no: %d",pvlan_no));

    /* Check PVLAN number */
    if (pvlan_no < VTSS_PVLAN_NO_START || pvlan_no >= VTSS_PVLAN_NO_END) {
        VTSS_E(("illegal pvlan_no: %d", pvlan_no));
        return VTSS_INVALID_PARAMETER;
    }

    /* Return internal state information */
    memcpy(member, vs->pvlan_table[pvlan_no].member, sizeof(vs->pvlan_table[pvlan_no].member));
    return VTSS_OK;
}

vtss_rc vtss_pvlan_port_members_set(const vtss_pvlan_no_t pvlan_no, 
                                     const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    VTSS_D(("pvlan_no: %d",pvlan_no));

    /* Check PVLAN number */
    if (pvlan_no < VTSS_PVLAN_NO_START || pvlan_no >= VTSS_PVLAN_NO_END) {
        VTSS_E(("illegal pvlan_no: %d", pvlan_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    memcpy(vs->pvlan_table[pvlan_no].member, member, VTSS_PORT_ARRAY_SIZE*sizeof(BOOL));

#if defined(VTSS_CHIPS) 
#if defined(VTSS_ARCH_GATWICK)
    if (!vs->gw1e)
#endif /* VTSS_ARCH_GATWICK */
    {
        vtss_pvlan_no_t pvlan;
        vtss_port_no_t  port_no;
        vtss_chip_no_t  chip_no;
        
        /* Determine if one or more PVLANs include ports on both chips */
        vs->pvlan_isolate = 1;
        for (pvlan = VTSS_PVLAN_NO_START; 
             pvlan < VTSS_PVLAN_NO_END && vs->pvlan_isolate; 
             pvlan++) {
            chip_no = VTSS_CHIP_NO_END;
            for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
                if (vs->pvlan_table[pvlan].member[port_no]) {
                    if (chip_no == VTSS_CHIP_NO_END) {
                        /* First member found, save chip number */
                        chip_no = vs->port_map.chip_no[port_no];
                    } else if (vs->port_map.chip_no[port_no] != chip_no) {
                        /* Member on other chip found, no isolation */
                        vs->pvlan_isolate = 0;
                        break;
                    }
                }
            }
        }
    }
#endif /* VTSS_CHIPS */
    return vtss_update_masks(1, 0, 0);
}


/* - Aggregation --------------------------------------------------- */

vtss_rc vtss_aggr_port_members_get(const vtss_poag_no_t poag_no,
                                   BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_port_no_t port_no;

    VTSS_D(("poag_no: %d",poag_no));

    /* Check that the poag number is valid */
    if (!(VTSS_POAG_IS_POAG(poag_no))) {
        VTSS_E(("illegal poag_no: %d",poag_no));
        return VTSS_INVALID_PARAMETER;
    }

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        member[port_no] = MAKEBOOL01(vs->port_poag_no[port_no] == poag_no);
    }
    return VTSS_OK;
}

vtss_rc vtss_aggr_port_members_set(const vtss_poag_no_t poag_no,
                                   const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_port_no_t port_no;

    VTSS_D(("poag_no: %d",poag_no));

    /* Check that the poag number is valid */
    if (!(VTSS_POAG_IS_POAG(poag_no))) {
        VTSS_E(("illegal poag_no: %d",poag_no));
        return VTSS_INVALID_PARAMETER;
    }

    if (VTSS_POAG_IS_PORT(poag_no)) {
        /* When the PoAg is a Port, the Aggregation must be itself only. */
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (port_no == poag_no) {
                if (!member[port_no]) {
                    VTSS_E(("poag_no: %d is port, but not enabled in member set",poag_no));
                    return VTSS_AGGR_INVALID;
                }
            } else {
                if (member[port_no]) {
                    VTSS_E(("poag_no: %d is port, but port_no: %d is enabled in member set",poag_no,port_no));
                    return VTSS_AGGR_INVALID;
                }
            }
        }
    }

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (member[port_no]) {
	    if (vs->port_poag_no[port_no] != poag_no)  {
                /* The port is now member of this aggregation */
                vs->port_poag_no[port_no] = poag_no;
                /* Note that a port can be moved directly from one aggregation to another */
	    }
        } else {
            if (vs->port_poag_no[port_no] == poag_no) {
                /* The port is no longer a member of this aggregation */
                vs->port_poag_no[port_no] = port_no;
            }
        }
    }
#if (VTSS_OPT_MAC_NEXT_MAX != 0)
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    vtss_mac_table_update();
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
#endif /* VTSS_OPT_MAC_NEXT_MAX */

    return vtss_update_masks(1, 1, 1);
}

vtss_poag_no_t vtss_aggr_port_member_get(const vtss_port_no_t port_no)
{
    VTSS_D(("port_no: %d",port_no));

    /* Check that the port number is valid */
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }

    return vs->port_poag_no[port_no];
}

vtss_rc vtss_aggr_port_member_set(const vtss_port_no_t port_no,
                                  const vtss_poag_no_t poag_no)
{

    VTSS_D(("port_no: %d, poag_no: %d",port_no,poag_no));
    
    /* Check that the port number is valid */
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }

    /* Check that the poag number is valid */
    if (!VTSS_POAG_IS_POAG(poag_no)) {
        VTSS_E(("illegal poag_no: %d",poag_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    /* If the poag number is a port number, it must be itself */
    if (VTSS_POAG_IS_PORT(poag_no) && poag_no != port_no) {
        VTSS_E(("port_no: %d is port and poag_no: %d is different",port_no,poag_no));
        return VTSS_INVALID_PARAMETER;
    }

    if (vs->port_poag_no[port_no] == poag_no) 
        return VTSS_OK; /* No change */

    /* Note that a port can be moved directly from one aggregation to another */
    vs->port_poag_no[port_no] = poag_no;
#if (VTSS_OPT_MAC_NEXT_MAX != 0)
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    vtss_mac_table_update();
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
#endif /* VTSS_OPT_MAC_NEXT_MAX */
    return vtss_update_masks(1, 1, 1);
}

vtss_rc vtss_aggr_mode_set(const vtss_aggr_mode_t * const mode)
{
    VTSS_D(("enter"));

    return vtss_ll_aggr_mode_set(mode);
}

#if defined(VTSS_FEATURE_AGGR_GLAG)
vtss_rc vtss_aggr_glag_members_get(const vtss_glag_no_t glag_no,
                                   BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_port_no_t port_no;

    VTSS_D(("glag_no: %d", glag_no));

    /* Check GLAG number */
    if (glag_no < VTSS_GLAG_NO_START || glag_no >= VTSS_GLAG_NO_END) {
        VTSS_E(("illegal glag_no: %d", glag_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        member[port_no] = MAKEBOOL01(vs->port_glag_no[port_no] == glag_no);
    }
    return VTSS_OK;
}

vtss_rc vtss_aggr_glag_set(vtss_glag_no_t glag_no,
                           vtss_port_no_t member[VTSS_GLAG_PORT_ARRAY_SIZE])
{
    vtss_port_no_t port_no;
    uint           gport;
    
    VTSS_D(("glag_no: %d", glag_no));

    /* Check GLAG number */
    if (glag_no < VTSS_GLAG_NO_START || glag_no >= VTSS_GLAG_NO_END) {
        VTSS_E(("illegal glag_no: %d", glag_no));
        return VTSS_INVALID_PARAMETER;
    }

    /* Delete old GLAG members */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (vs->port_glag_no[port_no] == glag_no)
            vs->port_glag_no[port_no] = 0;
    }
    
    /* Add new GLAG member state */
    for (gport = VTSS_GLAG_PORT_START; gport < VTSS_GLAG_PORT_END; gport++) {
        port_no = member[gport];
        vs->glag_members[glag_no-VTSS_GLAG_NO_START][gport] = port_no;
        if (port_no == 0) {
            /* End of list */
            if (gport == VTSS_GLAG_PORT_START) /* Deleting GLAG, flush MAC table */
                vtss_mac_table_forget_glag(glag_no);
            break;
        }

        if (!VTSS_PORT_IS_PORT(port_no)) {
            VTSS_E(("illegal port_no: %d. gport=%d", port_no, gport));
            return VTSS_INVALID_PARAMETER;
        }

        if (!vs->vstax_port_setup[port_no].enable)
            vs->port_glag_no[port_no] = glag_no;
    }

    /* Update masks */
#if (VTSS_OPT_MAC_NEXT_MAX != 0)
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    vtss_mac_table_update();
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
#endif /* VTSS_OPT_MAC_NEXT_MAX */
    return vtss_update_masks(0, 1, 1);
}
#endif /* VTSS_FEATURE_AGGR_GLAG */


/* - MAC Table ----------------------------------------------------- */

vtss_rc vtss_mac_table_flush(void)
{
    VTSS_D(("enter"));

    return vtss_ll_mac_table_flush(0, 0, 0, 0);
}

vtss_rc vtss_mac_table_learn(const vtss_mac_table_entry_t * const entry)
{
    vtss_rc                rc;
    vtss_pgid_no_t         pgid_no;
    vtss_mac_table_entry_t old_entry;
    vtss_port_no_t         port_no;
    BOOL                   member[VTSS_PORT_ARRAY_SIZE];
    vtss_vid_mac_t         vid_mac;
    
    vid_mac = entry->vid_mac;
    VTSS_D(("vid: %d, mac: %02x-%02x-%02x-%02x-%02x-%02x",
            vid_mac.vid, 
            vid_mac.mac.addr[0], vid_mac.mac.addr[1], vid_mac.mac.addr[2],
            vid_mac.mac.addr[3], vid_mac.mac.addr[4], vid_mac.mac.addr[5]));
    
    /* Free old PGID if the address exists */
    old_entry.vid_mac = vid_mac;
    if (vtss_ll_mac_table_lookup(&old_entry, &pgid_no) == VTSS_OK && old_entry.locked)
        vtss_pgid_free(pgid_no);

    /* Allocate new PGID */
#if defined(VTSS_ARCH_SPARX) || defined(VTSS_ARCH_HAWX)
    if (
#if defined(VTSS_ARCH_HAWX)
        vs->hawx_b &&
#endif /* VTSS_ARCH_HAWX */
        VTSS_MAC_IPV4_MC(entry->vid_mac.mac.addr)) {
        /* IPv4 multicast address, use pseudo PGID */
        pgid_no = VTSS_PGID_NONE;
    } else 
#if defined(SPARX_G5) || defined(VTSS_ARCH_SPARX_28)
    if (
#if defined(SPARX_G5)
        vtss_api_state->g58_type == VTSS_LUTON_TYPE_R2 &&
#endif /* SPARX_G5 */
        VTSS_MAC_IPV6_MC(entry->vid_mac.mac.addr)) {
        /* IPv6 multicast address, use pseudo PGID */
        pgid_no = VTSS_PGID_NONE;
    } else
#endif /* SPARX_G5/VTSS_ARCH_SPARX_28 */
#endif /* VTSS_ARCH_SPARX/VTSS_ARCH_HAWX */
    {
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
            member[port_no] = MAKEBOOL01(entry->destination[port_no]);
        if (vtss_pgid_alloc(&pgid_no, 0, member)<0) {
            VTSS_E(("pgid allocation failed"));
            return VTSS_UNSPECIFIED_ERROR;
        }
    }

    vs->mac_status_appl.learned = 1;
    vs->mac_status_next.learned = 1;
    vs->mac_status_sync.learned = 1;

    if (pgid_no == VTSS_PGID_NONE) {
        /* IPv4/IPv6 multicast address */
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
            vs->pgid_table[pgid_no].member[port_no] = MAKEBOOL01(entry->destination[port_no]);
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
            vs->pgid_table[pgid_no].member[port_no] = vtss_pgid_member(pgid_no, port_no);
    }

    rc = vtss_ll_mac_table_learn(entry, pgid_no);
    
#if (VTSS_OPT_MAC_NEXT_MAX != 0)
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    if (entry->locked && rc == VTSS_OK && pgid_no == VTSS_PGID_NONE) {
        vtss_mac_entry_t *mac_entry;

        /* Learn IPv4/IPv6 multicast entry for GET_NEXT operations */
        if ((mac_entry = vtss_mac_table_add(&entry->vid_mac, 1)) != NULL)
            for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
                VTSS_PORT_BF_SET(mac_entry->member, port_no, entry->destination[port_no]);
    }
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
#endif /* VTSS_OPT_MAC_NEXT_MAX */
    return rc;
}
#if defined(VTSS_FEATURE_MAC_AGE_AUTO)
vtss_rc vtss_mac_table_age_time_set(const vtss_mac_age_time_t age_time)
{
    VTSS_D(("age_time: %ld", age_time));
    return vtss_ll_mac_table_age_time_set(age_time);
}
#endif /* VTSS_FEATURE_MAC_AGE_AUTO */

vtss_rc vtss_mac_table_age(void)
{
    VTSS_D(("enter"));

    return vtss_ll_mac_table_age(0, 0, 0, 0);
}

vtss_rc vtss_mac_table_age_vlan(const vtss_vid_t vid)
{
    VTSS_D(("vid: %d",vid));

    return vtss_ll_mac_table_age(0, 0, 1, vid);
}

vtss_rc vtss_mac_table_forget_vid_mac(const vtss_vid_mac_t * const vid_mac)
{
    vtss_mac_table_entry_t entry;
    vtss_pgid_no_t         pgid_no;

    VTSS_D(("enter"));
    
    entry.vid_mac = *vid_mac;
    VTSS_RC(vtss_ll_mac_table_lookup(&entry, &pgid_no));

    if (entry.locked) 
        vtss_pgid_free(pgid_no);

    vs->mac_status_appl.aged = 1;
    vs->mac_status_next.aged = 1;
    vs->mac_status_sync.aged = 1;
    
#if (VTSS_OPT_MAC_NEXT_MAX != 0)
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    if (entry.locked && pgid_no == VTSS_PGID_NONE) {
        /* Unlearn IPv4/IPv6 multicast entry for GET_NEXT operations */
        vtss_mac_table_del(vid_mac);
    }
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
#endif /* VTSS_OPT_MAC_NEXT_MAX */

    return vtss_ll_mac_table_unlearn(vid_mac);
}

vtss_rc vtss_mac_table_forget_port(const vtss_port_no_t port_no)
{
    VTSS_D(("port_no: %d",port_no));

    return vtss_ll_mac_table_flush(1, port_no, 0, 0);
}

#if defined(VTSS_FEATURE_AGGR_GLAG)
vtss_rc vtss_mac_table_learn_glag(const vtss_mac_table_entry_t * const entry,
                                  const vtss_glag_no_t                 glag_no)
{
    vtss_rc rc;
    
    VTSS_D(("glag_no: %d", glag_no));

    if (glag_no < VTSS_GLAG_NO_START || glag_no >= VTSS_GLAG_NO_END) {
        VTSS_E(("illegal glag_no: %d", glag_no));
        return VTSS_INVALID_PARAMETER;
    }

    rc = vtss_mac_table_forget_vid_mac(&entry->vid_mac);
    if (rc<0 && rc!=VTSS_ENTRY_NOT_FOUND)
        return rc;
    
    vs->mac_status_appl.learned = 1;
    vs->mac_status_next.learned = 1;
    vs->mac_status_sync.learned = 1;

    return vtss_ll_mac_table_learn(entry, glag_no - VTSS_GLAG_NO_START + VTSS_PGID_GLAG_DEST);
}

vtss_rc vtss_mac_table_forget_glag(const vtss_glag_no_t glag_no)
{
    VTSS_D(("glag_no: %d", glag_no));

    if (glag_no < VTSS_GLAG_NO_START || glag_no >= VTSS_GLAG_NO_END) {
        VTSS_E(("illegal glag_no: %d", glag_no));
        return VTSS_INVALID_PARAMETER;
    }

    return vtss_ll_mac_table_flush(1, glag_no - VTSS_GLAG_NO_START + VTSS_PGID_GLAG_DEST, 
                                   0, 0);
}
#endif /* VTSS_FEATURE_AGGR_GLAG */


vtss_rc vtss_mac_table_forget_vlan(const vtss_vid_t vid)
{
    VTSS_D(("vid: %d",vid));

    return vtss_ll_mac_table_flush(0, 0, 1, vid);
}

vtss_rc vtss_mac_table_forget_port_in_vlan(const vtss_port_no_t port_no,
                                           const vtss_vid_t vid)
{
    VTSS_D(("port_no: %d, vid: %d",port_no,vid));

    return vtss_ll_mac_table_flush(1, port_no, 1, vid);
}

/* Set the destination list for a MAC address entry given a PGID */
static void vtss_mac_entry_destination_set(vtss_mac_table_entry_t * const entry, 
                                           vtss_pgid_no_t pgid_no) 
{
    vtss_poag_no_t poag_no;
    
    for (poag_no = VTSS_POAG_NO_START; poag_no < VTSS_POAG_NO_END; poag_no++) {
        if (VTSS_POAG_IS_PORT(poag_no)) {
            entry->destination[poag_no] = vtss_pgid_member(pgid_no, poag_no);
        } else {
            entry->destination[poag_no] = 0;
        }
    }
}

vtss_rc vtss_mac_table_read(const uint idx,
                            vtss_mac_table_entry_t * const entry)
{
    vtss_pgid_no_t pgid_no;

    VTSS_D(("idx: %d",idx));

    if (idx < VTSS_MAC_ADDR_START || idx > vs->mac_addrs) {
        VTSS_E(("illegal idx: %d",idx));
        return VTSS_INVALID_PARAMETER;
    }

    VTSS_RC(vtss_ll_mac_table_read(idx, entry, &pgid_no));

    /* Update entry->destination list based on pgid_no. */
    vtss_mac_entry_destination_set(entry, pgid_no);

    return VTSS_OK;
}

vtss_rc vtss_mac_table_lookup(const vtss_vid_mac_t * const vid_mac,
                              vtss_mac_table_entry_t * const entry)
{
    vtss_pgid_no_t pgid_no;

    VTSS_D(("enter"));

    entry->vid_mac = *vid_mac;
    VTSS_RC(vtss_ll_mac_table_lookup(entry, &pgid_no));

    vtss_mac_entry_destination_set(entry, pgid_no);

    return VTSS_OK;
}

vtss_rc vtss_mac_table_status_read(void) 
{
    vtss_mac_table_status_t stat;

    /* Read and clear sticky bits */
    VTSS_RC(vtss_ll_mac_table_status_get(&stat));

    /* Save API state */
    if (stat.learned) {
        vs->mac_status_appl.learned = 1;
        vs->mac_status_next.learned = 1;
        vs->mac_status_sync.learned = 1;
    }
    if (stat.replaced) {
        vs->mac_status_appl.replaced = 1;
        vs->mac_status_next.replaced = 1;
        vs->mac_status_sync.replaced = 1;
    }
    if (stat.moved) {
        vs->mac_status_appl.moved = 1;
        vs->mac_status_next.moved = 1;
        vs->mac_status_sync.moved = 1;
    }
    if (stat.aged) {
        vs->mac_status_appl.aged = 1;
        vs->mac_status_next.aged = 1;
        vs->mac_status_sync.aged = 1;
    }
    return VTSS_OK;
}

vtss_rc vtss_mac_table_status_get(vtss_mac_table_status_t * const status) 
{
    VTSS_RC(vtss_mac_table_status_read());

    /* Use API event state */
    if (vs->mac_status_appl.learned) {
        vs->mac_status_appl.learned = 0;
        status->learned = 1;
    }
    if (vs->mac_status_appl.replaced) {
        vs->mac_status_appl.replaced = 0;
        status->replaced = 1;
    }
    if (vs->mac_status_appl.moved) {
        vs->mac_status_appl.moved = 0;
        status->moved = 1;
    }
    if (vs->mac_status_appl.aged) {
        vs->mac_status_appl.aged = 0;
        status->aged = 1;
    }
    return VTSS_OK;
}

vtss_rc vtss_mac_table_get_next(const vtss_vid_mac_t * const   vid_mac,
                                vtss_mac_table_entry_t * const entry)
{
    vtss_rc          rc = VTSS_ENTRY_NOT_FOUND;
#if (VTSS_OPT_MAC_NEXT_MAX != 0)
    ulong            mach, macl;
    vtss_mac_entry_t *cur;
    vtss_vid_mac_t   vid_mac_next;
#endif /* VTSS_OPT_MAC_NEXT_MAX */

    VTSS_D(("vid: %d, mac: %02x-%02x-%02x-%02x-%02x-%02x",
            vid_mac->vid, 
            vid_mac->mac.addr[0], vid_mac->mac.addr[1], vid_mac->mac.addr[2],
            vid_mac->mac.addr[3], vid_mac->mac.addr[4], vid_mac->mac.addr[5]));
           
#if (VTSS_OPT_MAC_NEXT_MAX != 0)
    vtss_mach_macl_get(vid_mac, &mach, &macl);
    VTSS_D(("enter: %04lx-%04lx%08lx",mach>>16,mach & 0xFFFF,macl));
    
    for (cur = vtss_mac_table_get(mach, macl, 1); cur != NULL; cur = cur->next) {
        /* Lookup in chip */
        VTSS_D(("next: %04lx-%04lx%08lx",cur->mach>>16,cur->mach & 0xFFFF,cur->macl));
        vid_mac_next.vid = ((cur->mach >> 16) & 0xFFFF);
        vid_mac_next.mac.addr[0] = ((cur->mach >> 8) & 0xFF);
        vid_mac_next.mac.addr[1] = (cur->mach & 0xFF);
        vid_mac_next.mac.addr[2] = ((cur->macl >> 24) & 0xFF);
        vid_mac_next.mac.addr[3] = ((cur->macl >> 16) & 0xFF);
        vid_mac_next.mac.addr[4] = ((cur->macl >> 8) & 0xFF);
        vid_mac_next.mac.addr[5] = (cur->macl & 0xFF);
        if ((rc = vtss_mac_table_lookup(&vid_mac_next, entry)) == VTSS_OK)
            break;
    }
#endif /* VTSS_OPT_MAC_NEXT_MAX */

#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
#if defined(VTSS_ARCH_HAWX)
    if (vs->hawx_b) 
#endif /* VTSS_ARCH_HAWX */
    {
        vtss_pgid_no_t         pgid_no;
        vtss_mac_table_entry_t mac_entry;

        /* Do get next operation in chip */
        if (vtss_ll_mac_table_get_next(vid_mac, &mac_entry, &pgid_no) == VTSS_OK) {
            vtss_mac_entry_destination_set(&mac_entry, pgid_no);
#if (VTSS_OPT_MAC_NEXT_MAX != 0)
            vtss_mach_macl_get(&mac_entry.vid_mac, &mach, &macl);
            if (rc != VTSS_OK || (mach < cur->mach || (mach == cur->mach && macl < cur->macl)))
#endif /* VTSS_OPT_MAC_NEXT_MAX */
                *entry = mac_entry;
            rc = VTSS_OK;
        }
    }
#endif /* VTSS_ARCH_HAWX/SPARX_28 */    

    return rc;
}

/* - Mirroring ----------------------------------------------------- */

#if defined(VTSS_ARCH_HEATHROW) && !defined(VTSS_ARCH_SPARX_28)
static vtss_rc vtss_mirror_egress_update(void)
{
    vtss_vid_t vid;

    /* Update VLAN masks */
    for (vid = VTSS_VID_DEFAULT; vid < VTSS_VIDS; vid++) {
        if (vs->vlan_table[vid].enabled)
            VTSS_RC(vtss_ll_vlan_table_write(vid, vs->vlan_table[vid].member));
    }
    
    /* Update source and destination masks */
    return vtss_update_masks(1, 1, 0);
}
#endif /* VTSS_ARCH_HEATHROW && !VTSS_ARCH_SPARX_28 */

vtss_rc vtss_mirror_monitor_port_set(const vtss_port_no_t port_no)
{
    VTSS_D(("port_no: %d",port_no));

    /* Check that the port number is valid */
    if (port_no != 0 && !VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    vs->mirror_port = port_no;

#if defined(VTSS_ARCH_HEATHROW) && !defined(VTSS_ARCH_SPARX_28)
    VTSS_RC(vtss_mirror_egress_update());
#endif /* VTSS_ARCH_HEATHROW && !VTSS_ARCH_SPARX_28 */
    
    return vtss_ll_mirror_port_set(port_no);
}

vtss_rc vtss_mirror_ingress_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_port_no_t port_no;

    VTSS_D(("enter"));

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        VTSS_RC(vtss_ll_src_mirror_set(port_no, member[port_no]));
        vs->mirror_ingress[port_no] = member[port_no];
    }

#if defined(VTSS_ARCH_HEATHROW) && !defined(VTSS_ARCH_SPARX_28)
    VTSS_RC(vtss_mirror_egress_update());
#endif /* VTSS_ARCH_HEATHROW && !VTSS_ARCH_SPARX_28 */

    return VTSS_OK;
}

vtss_rc vtss_mirror_egress_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_port_no_t port_no;
#if defined(VTSS_ARCH_HEATHROW) && !defined(VTSS_ARCH_SPARX_28)
    uint           count;
#endif /* VTSS_ARCH_HEATHROW && !VTSS_ARCH_SPARX_28 */

    VTSS_D(("enter"));

#if defined(VTSS_ARCH_HEATHROW) && !defined(VTSS_ARCH_SPARX_28)
    count = 0;
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (member[port_no] && !vs->mirror_ingress[port_no])
            count++;
    }
    if (count > 1) {
        VTSS_E(("egress mirroring enabled on %d ports, maximum 1 allowed",count));
        return VTSS_INVALID_PARAMETER;
    }
#endif /* VTSS_ARCH_HEATHROW && !VTSS_ARCH_SPARX_28 */

    /* Enable mirroring in egress mirror mask */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
#if defined(VTSS_ARCH_GATWICK) || defined(VTSS_ARCH_SPARX_28)
        VTSS_RC(vtss_ll_dst_mirror_set(port_no, member[port_no]));
#endif /* VTSS_ARCH_GATWICK/SPARX_28 */
        vs->mirror_egress[port_no] = member[port_no];
    }

#if defined(VTSS_ARCH_HEATHROW) && !defined(VTSS_ARCH_SPARX_28)
    VTSS_RC(vtss_mirror_egress_update());
#endif /* VTSS_ARCH_HEATHROW && !VTSS_ARCH_SPARX_28 */

    return VTSS_OK;
}

#if !defined(HEATHROW2)
vtss_rc vtss_ipv4_mc_flood_mask_set(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    VTSS_D(("enter"));

    return vtss_ll_ipmc_flood_mask_set(member);
}
#endif /* !HEATHROW2 */

#if defined(VTSS_FEATURE_CPU_RX_REG_MLD_ADV)
vtss_rc vtss_ipv6_mc_flood_mask_set(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    return vtss_ll_ipv6_mc_flood_mask_set(member);
}

vtss_rc vtss_ipv6_mc_ctrl_flood_set(const BOOL scope)
{
    return vtss_ll_ipv6_mc_ctrl_flood_set(scope);
}
#endif /* VTSS_FEATURE_CPU_RX_REG_MLD_ADV */

vtss_rc vtss_protect_port_egress_pair_set(vtss_port_no_t port_a, 
                                          vtss_port_no_t port_b,
                                          BOOL           enabled)
{
    VTSS_D(("port_a: %d, port_b: %d, enabled: %d", port_a, port_b, enabled));
    
    /* Check that the port numbers are valid */
    if (!VTSS_PORT_IS_PORT(port_a) || !VTSS_PORT_IS_PORT(port_b)) {
        VTSS_E(("illegal port, port_a: %d, port_b: %d", port_a, port_b));
        return VTSS_INVALID_PARAMETER;
    }

    /* Remove previous protection on these ports */
    vs->port_protect[vs->port_protect[port_a]] = 0;
    vs->port_protect[vs->port_protect[port_b]] = 0;
    
    /* Setup protection pair */
    vs->port_protect[port_a] = (enabled ? port_b : 0);
    vs->port_protect[port_b] = (enabled ? port_a : 0);

    /* Update destination masks */
    return vtss_update_masks(0, 1, 0);
}
#endif /* VTSS_FEATURE_LAYER2 */

vtss_rc vtss_port_forward_state_set(vtss_port_no_t      port_no, 
                                    vtss_port_forward_t forward)
{
    VTSS_D(("port_no: %d, forward: %d", port_no, forward));

    /* Check that the port number is valid */
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d", port_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    /* Update learning state */
    vs->port_forward[port_no] = forward;

#if defined(VTSS_ARCH_B2)
    return vtss_ll_port_forward_state_set(port_no, forward);
#else
    VTSS_RC(vtss_ll_port_queue_enable(port_no, 1));

    /* Update source and aggregation masks */
    return vtss_update_masks(1, 0, 1);
#endif /* VTSS_ARCH_B2 */
}

#if defined(VTSS_FEATURE_LAYER3)
/* ================================================================= *
 *  Layer 3     
 * ================================================================= */

vtss_rc vtss_ip_forwarding_set(const BOOL enable)
{
    VTSS_D(("enable: %d",enable));

    return vtss_ll_ip_forwarding_set(enable);
}

vtss_rc vtss_rl_add(const vtss_rlid_t new_rlid, const vtss_rl_t * const rl)
{
    VTSS_D(("new_rlid: %d, vid: %d", new_rlid, rl->vid_mac.vid));

    /* Check that the RLID is valid */
    if (new_rlid<VTSS_RLID_START || new_rlid>=vs->rlid_end) {
        VTSS_E(("illegal rlid: %d",new_rlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    return vtss_ll_rl_add(new_rlid, rl);
}

vtss_rc vtss_rl_del(vtss_rlid_t rlid)
{
    VTSS_D(("rlid: %d", rlid));

    /* Check that the RLID is valid */
    if (rlid<VTSS_RLID_START || rlid>=vs->rlid_end) {
        VTSS_E(("illegal rlid: %d",rlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    return vtss_ll_rl_del(rlid);
}

vtss_rc vtss_vrrp_addr_set(const vtss_mac_t mac)
{
    VTSS_D(("mac: %02x-%02x-%02x-%02x-%02x-%02x",
            mac.addr[0],mac.addr[1],mac.addr[2],mac.addr[3],mac.addr[4],mac.addr[5]));

    /* Check that the last byte is zero */
    if (mac.addr[5] != 0) {
        VTSS_E(("illegal mac[5]: 0x%02x",mac.addr[5]));
        return VTSS_INVALID_PARAMETER;
    }
    
    /* Set VRRP base address */
    vs->vrrp_base = mac;
    
    return vtss_ll_vrrp_addr_set(mac);
}

vtss_rc vtss_vrrp_vrid_add(const vtss_vrid_t vrid, const vtss_rlid_t rlid)
{
    VTSS_D(("vrid: %d, rlid: %d", vrid, rlid));

    /* Check that the VRID is valid */
    if (vrid == 0 || vrid > 255) {
        VTSS_E(("illegal vrid: %d",vrid));
        return VTSS_INVALID_PARAMETER;
    }

    /* Check that the RLID is valid */
    if (rlid<VTSS_RLID_START || rlid>=vs->rlid_end) {
        VTSS_E(("illegal rlid: %d",rlid));
        return VTSS_INVALID_PARAMETER;
    }
    
    return vtss_ll_vrrp_vrid_add(vrid, rlid);
}

vtss_rc vtss_vrrp_vrid_del(const vtss_vrid_t vrid, const vtss_rlid_t rlid)
{
    VTSS_D(("vrid: %d, rlid: %d", vrid, rlid));

    /* Check that the VRID is valid */
    if (vrid == 0 || vrid > 255) {
        VTSS_E(("illegal vrid: %d",vrid));
        return VTSS_INVALID_PARAMETER;
    }

    /* Check that the RLID is valid */
    if (rlid<VTSS_RLID_START || rlid>=vs->rlid_end) {
        VTSS_E(("illegal rlid: %d",rlid));
        return VTSS_INVALID_PARAMETER;
    }
    
    return vtss_ll_vrrp_vrid_del(vrid, rlid);
}

vtss_rc vtss_ipuc_add(vtss_ip_t net, vtss_ip_t mask, vtss_ip_t next_hop)
{
    VTSS_D(("net/mask: 0x%08lx/0x%08lx, next_hop: 0x%08lx", net, mask, next_hop));
    
    return vtss_ll_ipuc_add(net, mask, next_hop);
}

vtss_rc vtss_ipuc_del(vtss_ip_t net, vtss_ip_t mask)
{
    VTSS_D(("net/mask: 0x%08lx/0x%08lx", net, mask));

    return vtss_ll_ipuc_del(net, mask);
}

vtss_rc vtss_arp_add(const vtss_ip_t dip, const vtss_arp_t * const arp)
{
    vtss_rl_entry_t *rl_entry;
    
    VTSS_D(("dip: 0x%08lx", dip));

    /* Check that the Router Leg is valid */
    rl_entry = &vs->rl_table[arp->rlid];
    if (!rl_entry->enabled) {
        VTSS_E(("rlid %d does not exist", arp->rlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    return vtss_ll_arp_add(dip, arp);
}

vtss_rc vtss_arp_del(vtss_ip_t dip)
{
    VTSS_D(("dip: 0x%08lx", dip));

    return vtss_ll_arp_del(dip);
}

vtss_rc vtss_ipuc_security_set(BOOL enable)
{
    VTSS_D(("enable: %d", enable));

    return vtss_ll_sec_set(enable);
}

vtss_rc vtss_ipuc_secur_rl_set(vtss_rlid_t irlid, vtss_rlid_t erlid,
                               BOOL enable)
{
    VTSS_D(("irlid: %d, erlid: %d, enable: %d", irlid, erlid, enable));

    /* Check that the IRLID is valid */
    if (irlid<VTSS_RLID_START || irlid>=vs->rlid_end) {
        VTSS_E(("illegal irlid: %d",irlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* Check that the ERLID is valid */
    if (erlid<VTSS_RLID_START || erlid>=vs->rlid_end) {
        VTSS_E(("illegal erlid: %d",erlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    return vtss_ll_sec_table_write(irlid, erlid, enable);
}

vtss_rc vtss_ipmc_add(const vtss_ip_t sip, const vtss_ip_t dip, const vtss_ipmc_t *ipmc)
{
    VTSS_D(("sip: 0x%08lx, dip: 0x%08lx",sip,dip));
    
    /* Check that the DIP is an IP multicast address */
    if ((dip & 0xf0000000) != 0xe0000000) {
        VTSS_E(("illegal dip: %08lx",dip));
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* Check that the IRLID is valid */
    if (ipmc->irlid<VTSS_RLID_START || ipmc->irlid>=vs->rlid_end) {
        VTSS_E(("illegal irlid: %d",ipmc->irlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* Check that the IRLID is not used as ERLID */
    if (ipmc->erlid[ipmc->irlid]) {
        VTSS_E(("irlid used as erlid: %d",ipmc->irlid));
        return VTSS_UNSPECIFIED_ERROR;
    }
    
    return vtss_ll_ipmc_add(sip, dip, ipmc);
}

vtss_rc vtss_ipmc_del(vtss_ip_t sip, vtss_ip_t dip)
{
    VTSS_D(("sip: 0x%08lx, dip: 0x%08lx",sip,dip));

    return vtss_ll_ipmc_del(sip, dip);
}

vtss_rc vtss_ip_counters_update(void)
{
    uint               ctr;
    vtss_ip_counters_t counters;
    vtss_counter_t new, old, incr;

    VTSS_N(("enter"));

    /* Read Gatwick IP counters */
    VTSS_RC(vtss_ll_ip_counters_get(&counters));

    for (ctr = 0; ctr < sizeof(vtss_ip_counters_t) / sizeof(vtss_counter_t); ctr++) {
        /* Calculate increment taking wrapping into account */
        new = ((vtss_counter_t *) & counters)[ctr];
        old = ((vtss_counter_t *) & vs->ip_counters_last)[ctr];
        if (new >= old) {
            incr = (new - old);
        } else {
            incr = (new + ((vtss_counter_t)(-1)-old+1));
        }
        
        /* Update last and current counter */
        ((vtss_counter_t *) & vs->ip_counters_last)[ctr] = new;
        ((vtss_counter_t *) & vs->ip_counters)[ctr] += incr;
    }

    return VTSS_OK;
}

vtss_rc vtss_ip_counters_get(vtss_ip_counters_t * const counters)
{
    VTSS_D(("enter"));

    /* Update current counters */
    VTSS_RC(vtss_ip_counters_update());

    /* Return current counters */
    *counters = vs->ip_counters;

#if defined(VTSS_CHIPS)
    if (vs->gw1e) {
        /* IP multicast packets are forwarded by both chips, so we adjust */
        counters->tx_mc_packets /= 2;
        counters->rx_packets = (counters->tx_uc_packets + counters->tx_mc_packets);
    }
#endif /* VTSS_CHIPS */

    return VTSS_OK;
}

vtss_rc vtss_ip_counters_clear(void)
{
    uint ctr;

    VTSS_D(("enter"));

    /* Update current counters */
    VTSS_RC(vtss_ip_counters_update());

    /* Clear current counters */
    for (ctr = 0; ctr < sizeof(vtss_ip_counters_t) / sizeof(vtss_counter_t); ctr++) {
        ((vtss_counter_t *) & vs->ip_counters)[ctr] = 0;
    }

    return VTSS_OK;
}

vtss_rc vtss_rl_counters_update(vtss_rlid_t rlid)
{
    uint ctr;
    vtss_rl_counters_t counters;

    VTSS_N(("rlid: %d",rlid));
    
    /* Check that the RLID is valid */
    if (rlid<VTSS_RLID_START || rlid>=vs->rlid_end) {
        VTSS_E(("illegal rlid: %d",rlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* Read and clear Gatwick Router Leg counters */
    VTSS_RC(vtss_ll_rl_counters_get(rlid, &counters));

    /* Update current counters */
    for (ctr = 0; ctr < sizeof(vtss_rl_counters_t) / sizeof(vtss_counter_t); ctr++) {
        ((vtss_counter_t *) & vs->rl_counters[rlid])[ctr] +=
            ((vtss_counter_t *) & counters)[ctr];
    }
    
    return VTSS_OK;
}

vtss_rc vtss_rl_counters_get(const vtss_rlid_t rlid,
                             vtss_rl_counters_t * const counters)
{
    VTSS_D(("rlid: %d",rlid));

    /* Check that the RLID is valid */
    if (rlid<VTSS_RLID_START || rlid>=vs->rlid_end) {
        VTSS_E(("illegal rlid: %d",rlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* Update current counters */
    VTSS_RC(vtss_rl_counters_update(rlid));

    /* Return current counters */
    *counters = vs->rl_counters[rlid];

#if defined(VTSS_CHIPS)
    if (vs->gw1e)
        /* IP multicast packets are forwarded by both chip, so we adjust */
        counters->rx_mc_packets /= 2;
#endif /* VTSS_CHIPS */

    return VTSS_OK;
}

vtss_rc vtss_rl_counters_clear(vtss_rlid_t rlid)
{
    uint ctr;

    VTSS_D(("rlid: %d",rlid));

    /* Check that the RLID is valid */
    if (rlid<VTSS_RLID_START || rlid>=vs->rlid_end) {
        VTSS_E(("illegal rlid: %d",rlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* Clear Gatwick Router Leg counters */
    VTSS_RC(vtss_ll_rl_counters_clear(rlid));

    /* Clear current counters */
    for (ctr = 0; ctr < sizeof(vtss_rl_counters_t) / sizeof(vtss_counter_t); ctr++) {
        ((vtss_counter_t *) & vs->rl_counters[rlid])[ctr] = 0;
    }

    return VTSS_OK;
}
#endif /* VTSS_FEATURE_LAYER3 */

