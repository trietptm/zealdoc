/*

 Vitesse Switch/PHY API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_errors.h,v 1.12 2008/04/29 08:15:22 henrikb Exp $
 $Revision: 1.12 $

*/

#ifndef _VTSS_ERRORS_H_
#define _VTSS_ERRORS_H_

/* ================================================================= *
 *  Return Codes
 * ================================================================= */

/* - Return Code type ---------------------------------------------- */

typedef int vtss_rc;

/* - Return Code values -------------------------------------------- */

#define VTSS_OK                  0     /* rc>=0 means OK */

/* General warnings */
#define VTSS_WARNING            -0x01  /* Error, but fixed by API. */
#define VTSS_INCOMPLETE         -0x02  /* Operation incomplete */

/* General errors */
#define VTSS_UNSPECIFIED_ERROR  -0x03
#define VTSS_NOT_IMPLEMENTED    -0x04
#define VTSS_INVALID_PARAMETER  -0x05
#define VTSS_DATA_NOT_READY     -0x06
#define VTSS_ENTRY_NOT_FOUND    -0x07
#define VTSS_TIMEOUT_RETRYLATER -0x08  /* Timeout, retry later. */
#define VTSS_FATAL_ERROR        -0x09  /* Fatal error. Chip reset required. */

/* PHY errors */
#define VTSS_PHY_NOT_MAPPED     -0x10
#define VTSS_PHY_READ_ERROR     -0x11  /* No PHY read reply. */
#define VTSS_PHY_TIMEOUT        -0x12  /* The PHY did not react within spec'ed time */

/* Port errors */
#define VTSS_TBI_DISABLED       -0x20

/* Packet errors */
#define VTSS_PACKET_BUF_SMALL    -0x30 
#define VTSS_PACKET_PROTOCOL_ERROR -0x31
 
/* Layer 2 errors */
#define VTSS_AGGR_INVALID       -0x40

/* I/O errors for Vitesse implementation */
#define VTSS_IO_READ_ERROR      -0x60  /* I/O Layer read error */
#define VTSS_IO_WRITE_ERROR     -0x61  /* I/O Layer write error */
#define VTSS_IO_DMA             -0x62  /* I/O Layer DMA error */

#define VTSS_IO_NIC_READ_ERROR  -0x63  /* I/O NIC Layer read error */
#define VTSS_IO_NIC_WRITE_ERROR -0x64  /* I/O NIC Layer write error */
#define VTSS_IO_NIC_ERROR       -0x65  /* I/O NIC Layer error */

#define VTSS_SYNCE_RE_NOM       -0x66  /* Illegal to renominate a source to another port */
#define VTSS_SYNCE_NOM_PORT     -0x67  /* port is allready nominated to other clock source */
#define VTSS_SYNCE_PRIORITY     -0x68  /* warning about more clock sources with same priority */
#define VTSS_SYNCE_SELECTION    -0x69  /* NOT possible to make Manuel To Selected if not in locked mode */

#define VTSS_EPS_W_ENABLED      -0x6A  /* Working instance is already in an enabled protection */
#define VTSS_EPS_W_DISABLED     -0x6B  /* Working instance is NOT in an enabled protection */
#define VTSS_EPS_P_ENABLED      -0x6C  /* Protecting instance is already in an enabled protection */
/* Customer specific errors, use range: -0x1000 to -0x1FFF */


#endif /* _VTSS_ERRORS_H_ */

