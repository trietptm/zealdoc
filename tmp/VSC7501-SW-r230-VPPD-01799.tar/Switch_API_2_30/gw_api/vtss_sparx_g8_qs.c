/*
 
 Vitesse Switch Software.
 
 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_sparx_g8_qs.c,v 1.6 2008/02/20 15:04:55 cpj Exp $
 $Revision: 1.6 $

*/

/****************************************************************************/
/*                                                                          */
/*  Converting watermarks into a structure                                  */
/*                                                                          */
/****************************************************************************/

#if defined(SPARX_G5) || defined(SPARX_G8)
#include "vtss_sparx_g5_g8_qs.h"

#include "heathrow_qs.h"

const vtss_sparx_g5_g8_qs_t vtss_sparx_g5_g8_qs = {
    {   /* norm_4s_drop */
        VTSS_NORM_4S_DROP_EARLY_TX,
        VTSS_NORM_4S_DROP_FWDP_START,
        VTSS_NORM_4S_DROP_FWDP_STOP,
        {
            VTSS_NORM_4S_DROP_EMIN0,
            VTSS_NORM_4S_DROP_EMIN1,
            VTSS_NORM_4S_DROP_EMIN2,
            VTSS_NORM_4S_DROP_EMIN3
        },
        {
            VTSS_NORM_4S_DROP_EMAX0,
            VTSS_NORM_4S_DROP_EMAX1,
            VTSS_NORM_4S_DROP_EMAX2,
            VTSS_NORM_4S_DROP_EMAX3
        },
        {
            VTSS_NORM_4S_DROP_IMIN0,
            VTSS_NORM_4S_DROP_IMIN1,
            VTSS_NORM_4S_DROP_IMIN2,
            VTSS_NORM_4S_DROP_IMIN3
        },
        {
            VTSS_NORM_4S_DROP_IMAX0,
            VTSS_NORM_4S_DROP_IMAX1,
            VTSS_NORM_4S_DROP_IMAX2,
            VTSS_NORM_4S_DROP_IMAX3
        },
        VTSS_NORM_4S_DROP_ZEROPAUSE,
        VTSS_NORM_4S_DROP_PAUSEVALUE
    },
    {   /* norm_4w_drop */
        VTSS_NORM_4W_DROP_EARLY_TX,
        VTSS_NORM_4W_DROP_FWDP_START,
        VTSS_NORM_4W_DROP_FWDP_STOP,
        {
            VTSS_NORM_4W_DROP_EMIN0,
            VTSS_NORM_4W_DROP_EMIN1,
            VTSS_NORM_4W_DROP_EMIN2,
            VTSS_NORM_4W_DROP_EMIN3
        },
        {
            VTSS_NORM_4W_DROP_EMAX0,
            VTSS_NORM_4W_DROP_EMAX1,
            VTSS_NORM_4W_DROP_EMAX2,
            VTSS_NORM_4W_DROP_EMAX3
        },
        {
            VTSS_NORM_4W_DROP_IMIN0,
            VTSS_NORM_4W_DROP_IMIN1,
            VTSS_NORM_4W_DROP_IMIN2,
            VTSS_NORM_4W_DROP_IMIN3
        },
        {
            VTSS_NORM_4W_DROP_IMAX0,
            VTSS_NORM_4W_DROP_IMAX1,
            VTSS_NORM_4W_DROP_IMAX2,
            VTSS_NORM_4W_DROP_IMAX3
        },
        VTSS_NORM_4W_DROP_ZEROPAUSE,
        VTSS_NORM_4W_DROP_PAUSEVALUE
    },
    {   /* norm_4s_fc */
        VTSS_NORM_4S_FC_EARLY_TX,
        VTSS_NORM_4S_FC_FWDP_START,
        VTSS_NORM_4S_FC_FWDP_STOP,
        {
            VTSS_NORM_4S_FC_EMIN0,
            VTSS_NORM_4S_FC_EMIN1,
            VTSS_NORM_4S_FC_EMIN2,
            VTSS_NORM_4S_FC_EMIN3
        },
        {
            VTSS_NORM_4S_FC_EMAX0,
            VTSS_NORM_4S_FC_EMAX1,
            VTSS_NORM_4S_FC_EMAX2,
            VTSS_NORM_4S_FC_EMAX3
        },
        {
            VTSS_NORM_4S_FC_IMIN0,
            VTSS_NORM_4S_FC_IMIN1,
            VTSS_NORM_4S_FC_IMIN2,
            VTSS_NORM_4S_FC_IMIN3
        },
        {
            VTSS_NORM_4S_FC_IMAX0,
            VTSS_NORM_4S_FC_IMAX1,
            VTSS_NORM_4S_FC_IMAX2,
            VTSS_NORM_4S_FC_IMAX3
        },
        VTSS_NORM_4S_FC_ZEROPAUSE,
        VTSS_NORM_4S_FC_PAUSEVALUE
    },
    {   /* norm_4w_fc */
        VTSS_NORM_4W_FC_EARLY_TX,
        VTSS_NORM_4W_FC_FWDP_START,
        VTSS_NORM_4W_FC_FWDP_STOP,
        {
            VTSS_NORM_4W_FC_EMIN0,
            VTSS_NORM_4W_FC_EMIN1,
            VTSS_NORM_4W_FC_EMIN2,
            VTSS_NORM_4W_FC_EMIN3
        },
        {
            VTSS_NORM_4W_FC_EMAX0,
            VTSS_NORM_4W_FC_EMAX1,
            VTSS_NORM_4W_FC_EMAX2,
            VTSS_NORM_4W_FC_EMAX3
        },
        {
            VTSS_NORM_4W_FC_IMIN0,
            VTSS_NORM_4W_FC_IMIN1,
            VTSS_NORM_4W_FC_IMIN2,
            VTSS_NORM_4W_FC_IMIN3
        },
        {
            VTSS_NORM_4W_FC_IMAX0,
            VTSS_NORM_4W_FC_IMAX1,
            VTSS_NORM_4W_FC_IMAX2,
            VTSS_NORM_4W_FC_IMAX3
        },
        VTSS_NORM_4W_FC_ZEROPAUSE,
        VTSS_NORM_4W_FC_PAUSEVALUE
    },
    {   /* jumbo_4s_drop */
        VTSS_9600_4S_DROP_EARLY_TX,
        VTSS_9600_4S_DROP_FWDP_START,
        VTSS_9600_4S_DROP_FWDP_STOP,
        {
            VTSS_9600_4S_DROP_EMIN0,
            VTSS_9600_4S_DROP_EMIN1,
            VTSS_9600_4S_DROP_EMIN2,
            VTSS_9600_4S_DROP_EMIN3
        },
        {
            VTSS_9600_4S_DROP_EMAX0,
            VTSS_9600_4S_DROP_EMAX1,
            VTSS_9600_4S_DROP_EMAX2,
            VTSS_9600_4S_DROP_EMAX3
        },
        {
            VTSS_9600_4S_DROP_IMIN0,
            VTSS_9600_4S_DROP_IMIN1,
            VTSS_9600_4S_DROP_IMIN2,
            VTSS_9600_4S_DROP_IMIN3
        },
        {
            VTSS_9600_4S_DROP_IMAX0,
            VTSS_9600_4S_DROP_IMAX1,
            VTSS_9600_4S_DROP_IMAX2,
            VTSS_9600_4S_DROP_IMAX3
        },
        VTSS_9600_4S_DROP_ZEROPAUSE,
        VTSS_9600_4S_DROP_PAUSEVALUE
    },
    {   /* jumbo_4w_drop */
        VTSS_9600_4W_DROP_EARLY_TX,
        VTSS_9600_4W_DROP_FWDP_START,
        VTSS_9600_4W_DROP_FWDP_STOP,
        {
            VTSS_9600_4W_DROP_EMIN0,
            VTSS_9600_4W_DROP_EMIN1,
            VTSS_9600_4W_DROP_EMIN2,
            VTSS_9600_4W_DROP_EMIN3
        },
        {
            VTSS_9600_4W_DROP_EMAX0,
            VTSS_9600_4W_DROP_EMAX1,
            VTSS_9600_4W_DROP_EMAX2,
            VTSS_9600_4W_DROP_EMAX3
        },
        {
            VTSS_9600_4W_DROP_IMIN0,
            VTSS_9600_4W_DROP_IMIN1,
            VTSS_9600_4W_DROP_IMIN2,
            VTSS_9600_4W_DROP_IMIN3
        },
        {
            VTSS_9600_4W_DROP_IMAX0,
            VTSS_9600_4W_DROP_IMAX1,
            VTSS_9600_4W_DROP_IMAX2,
            VTSS_9600_4W_DROP_IMAX3
        },
        VTSS_9600_4W_DROP_ZEROPAUSE,
        VTSS_9600_4W_DROP_PAUSEVALUE
    },
    {   /* jumbo_4s_fc */
        VTSS_9600_4S_FC_EARLY_TX,
        VTSS_9600_4S_FC_FWDP_START,
        VTSS_9600_4S_FC_FWDP_STOP,
        {
            VTSS_9600_4S_FC_EMIN0,
            VTSS_9600_4S_FC_EMIN1,
            VTSS_9600_4S_FC_EMIN2,
            VTSS_9600_4S_FC_EMIN3
        },
        {
            VTSS_9600_4S_FC_EMAX0,
            VTSS_9600_4S_FC_EMAX1,
            VTSS_9600_4S_FC_EMAX2,
            VTSS_9600_4S_FC_EMAX3
        },
        {
            VTSS_9600_4S_FC_IMIN0,
            VTSS_9600_4S_FC_IMIN1,
            VTSS_9600_4S_FC_IMIN2,
            VTSS_9600_4S_FC_IMIN3
        },
        {
            VTSS_9600_4S_FC_IMAX0,
            VTSS_9600_4S_FC_IMAX1,
            VTSS_9600_4S_FC_IMAX2,
            VTSS_9600_4S_FC_IMAX3
        },
        VTSS_9600_4S_FC_ZEROPAUSE,
        VTSS_9600_4S_FC_PAUSEVALUE
    },
    {   /* jumbo_4w_fc */
        VTSS_9600_4W_FC_EARLY_TX,
        VTSS_9600_4W_FC_FWDP_START,
        VTSS_9600_4W_FC_FWDP_STOP,
        {
            VTSS_9600_4W_FC_EMIN0,
            VTSS_9600_4W_FC_EMIN1,
            VTSS_9600_4W_FC_EMIN2,
            VTSS_9600_4W_FC_EMIN3
        },
        {
            VTSS_9600_4W_FC_EMAX0,
            VTSS_9600_4W_FC_EMAX1,
            VTSS_9600_4W_FC_EMAX2,
            VTSS_9600_4W_FC_EMAX3
        },
        {
            VTSS_9600_4W_FC_IMIN0,
            VTSS_9600_4W_FC_IMIN1,
            VTSS_9600_4W_FC_IMIN2,
            VTSS_9600_4W_FC_IMIN3
        },
        {
            VTSS_9600_4W_FC_IMAX0,
            VTSS_9600_4W_FC_IMAX1,
            VTSS_9600_4W_FC_IMAX2,
            VTSS_9600_4W_FC_IMAX3
        },
        VTSS_9600_4W_FC_ZEROPAUSE,
        VTSS_9600_4W_FC_PAUSEVALUE
    }
};

#endif /* SPARX_G5 || SPARX_G8 */
