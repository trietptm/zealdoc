/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_appl.c,v 1.122 2008/09/09 09:19:43 cpj Exp $
 $Revision: 1.122 $
*/

/* Standard headers */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#define VTSS_SWITCH_APP	1       /* Declare static data */

#if defined(VTSS_TRACE)
#define VTSS_TRACE_MODULE_ID   VTSS_MODULE_ID_MAIN
#define VTSS_TRACE_GRP_DEFAULT 0
#define TRACE_GRP_CNT          1
#define VTSS_TRACE_LAYER       4
#else
#define VTSS_TRACE_FILE        "ap"
#define VTSS_TRACE_LAYER       3
#endif /* VTSS_TRACE */

/* API public headers */
#include "vtss_switch_api.h"
#include "vtss_basic_trace.h"
#if VTSS_OPT_CLI
#include <vtss_cli.h>
#endif /* VTSS_OPT_CLI */
#if defined(VTSS_OPT_RAPI) && VTSS_OPT_RAPI
#include "vtss_rapi.h"
#endif /* VTSS_OPT_RAPI */
#include "vtss_appl.h"
#include "vtss_appl_api.h"
#include "vtss_appl_plugins.h"
#include "vtss_version.h"

#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
static vtss_trace_reg_t trace_reg =
{ 
    .module_id = VTSS_TRACE_MODULE_ID,
    .name      = "main",
    .descr     = "Main appl"
};


static vtss_trace_grp_t trace_grps[TRACE_GRP_CNT] =
{
    [VTSS_TRACE_GRP_DEFAULT] = { 
        .name      = "default",
        .descr     = "Default",
        .lvl       = VTSS_TRACE_LVL_ERROR,
        .timestamp = 0,
    },
};
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */

/* Board control */
static vtss_board_t board;

/* Port status */
static vtss_appl_port_status_t port_status[VTSS_PORT_ARRAY_SIZE];

/* Port configuration */
static vtss_appl_port_conf_t port_conf[VTSS_PORT_ARRAY_SIZE];

/* Options */
static BOOL opt_dump_rx, opt_no_cli;

/* ================================================================= *
 *  Board specific functions
 * ================================================================= */

#if VTSS_OPT_ROUTER
/* Determine if port is router port */
static BOOL board_router_port(vtss_port_no_t port_no)
{
    if(board.router_port)
        return board.router_port(port_no);
    return 0;
}
#endif /* VTSS_OPT_ROUTER */

static BOOL board_port_vaui(vtss_port_no_t port_no)
{
#if defined(VTSS_FEATURE_VAUI)
    return (port_no > 24 ? 1 : 0);
#else
    return 0;
#endif /* VTSS_FEATURE_VAUI */
}

/* Determine if port is connected to 1G PHY */
static BOOL board_port_phy(vtss_port_no_t port_no)
{
#if defined(VTSS_FEATURE_10G)
    if (vtss_port_no_is_10g(port_no))
        return 0;
#endif /* VTSS_FEATURE_10G */
    
    return (board.port_map[port_no].miim_controller == VTSS_MIIM_CONTROLLER_NONE ? 0 : 1);
}

/* Determine port MAC interface */
static vtss_port_interface_t board_port_mac_interface(vtss_port_no_t port_no)
{
    vtss_port_interface_t if_type = VTSS_PORT_INTERFACE_INTERNAL;

    /* Determine interface type */
#if defined(VTSS_FEATURE_VAUI)
    if_type = (board_port_vaui(port_no) ? VTSS_PORT_INTERFACE_VAUI : 
               VTSS_PORT_INTERFACE_SGMII);
#endif /* VTSS_FEATURE_VAUI */

    if(board.port_mac_interface)
        if_type = board.port_mac_interface(port_no);
    
    return if_type;
}

#define MAC_AGE_TIME_DEFAULT 300 /* 300 seconds MAC age timer by default */

/* ================================================================= *
 *  Main functions
 * ================================================================= */

/* Setup port based on configuration and auto negotiation result */
static void port_setup(vtss_port_no_t port_no, BOOL conf)
{
    vtss_appl_port_status_t *ps;
    vtss_appl_port_conf_t   *pc;
    vtss_port_setup_t       setup;
    vtss_phy_setup_t        phy;
    
    pc = &port_conf[port_no];
    memset(&setup, 0, sizeof(setup));
    setup.interface_mode.interface_type = board_port_mac_interface(port_no);
    setup.powerdown = (pc->enable ? 0 : 1);
    setup.flowcontrol.smac.addr[5] = port_no;
    setup.maxframelength = pc->max_length;
    setup.frame_gaps.hdx_gap_1 = VTSS_FRAME_GAP_DEFAULT;
    setup.frame_gaps.hdx_gap_2 = VTSS_FRAME_GAP_DEFAULT;
    setup.frame_gaps.fdx_gap = VTSS_FRAME_GAP_DEFAULT;
#if defined(VTSS_FEATURE_SGMII)
    setup.sgmii_dc_coupled = 0;
#endif /* VTSS_FEATURE_SGMII */
    
    if (conf) {
        /* Configure port */
        if (board_port_phy(port_no)) {
            /* Setup PHY */
            phy.mode = (pc->enable ? 
                        (pc->autoneg || pc->speed == VTSS_SPEED_1G ? 
                         VTSS_PHY_MODE_ANEG : VTSS_PHY_MODE_FORCED) : 
                        VTSS_PHY_MODE_POWER_DOWN);
            phy.aneg.speed_10m_hdx = 1;
            phy.aneg.speed_10m_fdx = 1;
            phy.aneg.speed_100m_hdx = 1;
            phy.aneg.speed_100m_fdx = 1;
            phy.aneg.speed_1g_fdx = 1;
            phy.aneg.symmetric_pause = pc->flow_control;
            phy.aneg.asymmetric_pause = pc->flow_control;
            phy.forced.speed = pc->speed;
            phy.forced.fdx = pc->fdx;
            vtss_phy_setup(port_no, &phy);
#if defined(VTSS_FEATURE_TBI)
        } else if (setup.interface_mode.interface_type == VTSS_PORT_INTERFACE_SERDES) {
            /* PCS auto negotiation */
            vtss_tbi_autoneg_control_t              control;
            vtss_autoneg_1000base_x_advertisement_t *adv;

            control.enable = pc->autoneg;
            adv = &control.advertisement;
            adv->fdx = 1;
            adv->hdx = 0;
            adv->symmetric_pause = pc->flow_control;
            adv->asymmetric_pause = pc->flow_control;
            adv->remote_fault = (pc->enable ? VTSS_1000BASEX_LINK_OK : VTSS_1000BASEX_OFFLINE);
            adv->acknowledge = 0;
            adv->next_page = 0;
            vtss_tbi_autoneg_control_set(port_no, &control);
#endif /* VTSS_FEATURE_TBI */
        }
        /* Use configured values */
        setup.interface_mode.speed = pc->speed;
        setup.fdx = pc->fdx;
        setup.flowcontrol.obey = pc->flow_control;
        setup.flowcontrol.generate = pc->flow_control;
    } else {
        /* Setup port based on auto negotiation status */
        ps = &port_status[port_no];
        setup.interface_mode.speed = ps->speed;
        setup.fdx = ps->fdx;
        setup.flowcontrol.obey = ps->aneg.obey_pause;
        setup.flowcontrol.generate = ps->aneg.generate_pause;
    }
    
    if (board_port_phy(port_no)) {
        vtss_phy_power_setup (port_no, pc->power_mode);
    }
    
    if(board.port_setup)
        board.port_setup(port_no, &setup); /* Use board override */
    else
        vtss_port_setup(port_no, &setup); /* Default */
}

/* Rx frames to CPU */
static void cpu_frame_rx(void) 
{
#if defined(VTSS_FEATURE_CPU_RX_TX)
    vtss_system_frame_header_t header;
    uchar                      frame[VTSS_MAXFRAMELENGTH_STANDARD];
    vtss_cpu_rx_queue_t        queue_no;
    int			       i;

    for (queue_no=VTSS_CPU_RX_QUEUE_START; queue_no<VTSS_CPU_RX_QUEUE_END; queue_no++) {
        /* Check if frame is ready in Rx queue */
        if (vtss_cpu_rx_frameready(queue_no) <= 0)
            continue;
    
        /* Get frame */
        if (vtss_cpu_rx_frame(queue_no, &header, frame, 
                              VTSS_MAXFRAMELENGTH_STANDARD) != VTSS_OK)
            continue;
        
        VTSS_D(("received frame on port_no: %d, queue_no: %d, length: %d",
                header.source_port_no, queue_no, header.length));

        /* Process frame */
        if(opt_dump_rx) {
            int  i;
            char buf[100], *p;

            for (i = 0, p = &buf[0]; i < header.length; i++) {
                if ((i % 16) == 0) {
                    p = &buf[0];
                    p += sprintf(p, "%04x: ", i);
                }
                p += sprintf(p,"%02x%c", frame[i], ((i+9)%16)==0 ? '-' : ' ');
                if (((i+1) % 16) == 0 || (i+1) == header.length) {
                    VTSS_D(("%s", buf));
                }
            }
        }

        /* Plugin frame reception */
        for(i = 0; i < NR_PLUGINS; i++)
            if(plugins[i].recv)
                if(plugins[i].recv(&header, frame) == VTSS_OK) {
                    VTSS_N(("Frame claimed by %s", plugins[i].name));
                    break;
                }
    }
#endif
}

int main(int argc, const char **argv)
{
    vtss_state_t            *api_state;
    vtss_init_setup_t       init_setup;
    vtss_port_no_t          port_no;
    vtss_phy_reset_setup_t  phy_reset;
    vtss_mtimer_t           mac_timer;
    BOOL                    mac_timer_started, link_old, port_poll[VTSS_PORT_ARRAY_SIZE];
    BOOL		    layer2_plugin;

    vtss_port_status_t      status;
    vtss_appl_port_status_t *ps;
    int i;
    
#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    VTSS_TRACE_REG_INIT(&trace_reg, trace_grps, TRACE_GRP_CNT);
    VTSS_TRACE_REGISTER(&trace_reg);
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */
#if defined(VTSS_BASIC_TRACE_USE_ADVANCED)
    vtss_basic_trace_register();
#endif

    /* Set up board funcstions and get port map */
    vtss_board_hookup(&board, argc, argv);

    /* Plugin init - detect if L2 present */
    for(i = 0, layer2_plugin = 0; i < NR_PLUGINS; i++) {
        VTSS_D(("Initialize plugin: %s", plugins[i].name));
        plugins[i].init(&plugins[i]);
        if(plugins[i].flags & VTSS_PLUGIN_FLAG_LAYER2) {
            layer2_plugin++; /* We have a l2 control protocol */
            VTSS_I(("Layer 2 plugin present: %s", plugins[i].name));
        }
    }

    while(argc > 1 && argv[1] && argv[1][0] == '-') {
        switch(argv[1][1]) {
        case 'h':           /* Help */
            printf("vtss_appl [-v] [-R] [-C] <board-specific args>\n");
            printf("-v: Print version\n");
            printf("-R: Dump RX frames\n");
            printf("-C: No CLI\n");
#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
            printf("-T: Trace with timestamps\n");
            printf("-U: Trace with usec precision\n");
            printf("-Dxxx: Trace level, xxx = [<module>:<group>:<level>|<module>:<level>|<level>]\n");
            printf("       level = [e|w|i|d|n|r] - default 'd'\n");
            printf("       module 0 - io, 1 - chip if, 2 - api\n");
#endif /* defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED) */
            return 1;
        case 'v':           /* Version */
            printf("Version: %s\n", vtss_version_string);
            printf("Date   : %s\n", vtss_compile_time);
            printf("Board  : %s\n", board.name);
            printf("Layer2 : %s (by plugin)\n", layer2_plugin ? "yes" : "no");
            return 0;
        case 'R':               /* Dump RX frames */
            opt_dump_rx++;
            break;
        case 'C':               /* Disable CLI */
            opt_no_cli++;
            break;
#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
        case 'T':
            vtss_trace_module_parm_set(VTSS_TRACE_MODULE_PARM_TIMESTAMP, -1, -1, 1);
            break;
        case 'U':
            vtss_trace_module_parm_set(VTSS_TRACE_MODULE_PARM_USEC, -1, -1, 1);
            break;
        case 'D':
        {
            const char *opt = argv[1] + 2;
            int mid, gid, lvl;
            char clvl;
            if(sscanf(opt, "%d:%d:%c", &mid, &gid, &clvl) != 3) {
                if(sscanf(opt, "%d:%c", &mid, &clvl) == 2) {
                    gid = -1;   /* Wildcard */
                } else {
                    clvl = tolower(*opt);
                    mid = gid = -1;   /* Wildcard */
                }
            }
            if(clvl == 'e')
                lvl = VTSS_TRACE_LVL_ERROR;
            else if(clvl == 'w')
                lvl = VTSS_TRACE_LVL_WARNING;
            else if(clvl == 'i')
                lvl = VTSS_TRACE_LVL_INFO;
            else if(clvl == 'n')
                lvl = VTSS_TRACE_LVL_NOISE;
            else if(clvl == 'r')
                lvl = VTSS_TRACE_LVL_RACKET;
            else
                lvl = VTSS_TRACE_LVL_DEBUG; /* Default */
            vtss_trace_module_lvl_set(mid, gid, lvl);
        }
        break;
#endif
        default:                /* Break from while() loop */
            goto last;
        }
        argc--, argv++;
    }
last:

#if defined(VTSS_OPT_RAPI) && VTSS_OPT_RAPI
    if (vtss_rapi_init()) {
        VTSS_E(("Socket interface initialization failed"));
        exit(-1);
    }
#endif /* VTSS_OPT_RAPI */

    /* Allocate API state memory */
    if ((api_state = malloc(sizeof(vtss_state_t)))==NULL ||
        (api_state->al = malloc(vtss_sizeof_al()))==NULL) {
        VTSS_E(("malloc api_state failed"));
        return 0;
    }

    /* Allocate PHY API state memory */
    if ((api_state->phy = malloc(sizeof(vtss_phy_state_t)))==NULL ||
        (((vtss_phy_state_t*)(api_state->phy))->al = 
         malloc(vtss_phy_sizeof_al(VTSS_PORTS)))==NULL) {
        VTSS_E(("malloc phy_api_state failed"));
        return 0;
    }
    
    /* Setup API state */
    vtss_select_chip(api_state);

    /* Initialize CPU interface */
    board.connect(argc, argv, &api_state->io);

    /* Initialize switch chip */
    vtss_init_get(&init_setup);
#if defined(VTSS_OPT_USE_CPU_SI)
    init_setup.use_cpu_si = 1;
#endif /* VTSS_OPT_USE_CPU_SI */
    if(board.init_setup_hook)
        board.init_setup_hook(argc, argv, &init_setup);
    if (vtss_init(&init_setup) != VTSS_OK)
        return 0;
#if VTSS_OPT_ICPU_LOAD
    VTSS_D(("vtss_init done, exiting"));
    return 0;
#endif /* VTSS_OPT_ICPU_LOAD */
    
    /* Setup port map for board */
    if (vtss_port_map_set(board.port_map) != VTSS_OK)
        return 0;
    
    /* Board system init - Setup router VLANs */
    if(board.init)
        board.init(argc, argv);

    /* Reset all ports */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        vtss_appl_port_conf_t *pc = &port_conf[port_no];

        port_status[port_no].link = 0;

        /* Default port configuration */
        pc->enable = 1;
        pc->autoneg = 0;
        pc->speed = VTSS_SPEED_1G;
        pc->fdx = 1;
        pc->flow_control = 0;
        pc->max_length = VTSS_MAXFRAMELENGTH_STANDARD;
        port_poll[port_no] = (board.port_map[port_no].chip_port < 0 ? 0 : 1);
        if (!port_poll[port_no]) /* Ignore unused ports */
            continue;
        
        if (!board_port_phy(port_no)) {
            /* No PHY */
#if defined(VTSS_FEATURE_10G)
            if (vtss_port_no_is_10g(port_no)) {
                /* Setup for 10G, full duplex, flow control disabled */
                pc->speed = VTSS_SPEED_10G;
            } else
#endif /* VTSS_FEATURE_10G */            
                if (board_port_vaui(port_no)) {
                    /* Setup for 5G, full duplex, flow control disabled */
                    pc->speed = VTSS_SPEED_5G;
                } else if (board_port_mac_interface(port_no) != VTSS_PORT_INTERFACE_SERDES) {
                    /* Setup for 1G, full duplex, flow control disabled */
#if defined(VTSS_FEATURE_LAYER2)
                    if(!layer2_plugin) /* ??? */
                        vtss_port_stp_state_set(port_no, VTSS_STP_STATE_ENABLED);
#endif /* VTSS_FEATURE_LAYER2 */
                    port_poll[port_no] = 0;
                }
        } else {
            /* Reset PHY */
            pc->autoneg = 1;
            pc->flow_control = 1;
            phy_reset.mac_if = board_port_mac_interface(port_no);
            phy_reset.rgmii.rx_clk_skew_ps = 1800;
            phy_reset.rgmii.tx_clk_skew_ps = 1800;
            phy_reset.media_if = VTSS_PHY_MEDIA_INTERFACE_COPPER;
            vtss_phy_reset(port_no, &phy_reset);
            if(board.phy_reset)
                board.phy_reset(port_no);
        }

#if VTSS_OPT_ROUTER
        if (board_router_port(port_no)) {
            /* Setup for 1G, full duplex, always up */
#if VTSS_OPT_ROUTER_PORT_FLOW_CONTROL
            pc->flow_control = 1;
#endif /* VTSS_OPT_ROUTER_PORT_FLOW_CONTROL */
            if(board.router_port_setup)
                board.router_port_setup(port_no, pc);
            vtss_port_stp_state_set(port_no, VTSS_STP_STATE_ENABLED);
            port_poll[port_no] = 0;
#if defined(VTSS_FEATURE_ACL)
            /* Disable ACL on router port */
            vtss_acl_policy_no_set(port_no, VTSS_ACL_POLICY_NO_NONE);
#endif /* VTSS_FEATURE_ACL */
#if defined(VTSS_FEATURE_QOS_TAG_REMARK)
            if(board_router_port(port_no)) {
                vtss_port_qos_setup_t   qos_port_conf;
                vtss_port_qos_get(port_no, &qos_port_conf);
                qos_port_conf.qcl_id = 6;
                qos_port_conf.tag_remark = 1;
                qos_port_conf.tag_map[1] = 0x1;
                qos_port_conf.tag_map[2] = 0x3;
                qos_port_conf.tag_map[3] = 0x5;
                qos_port_conf.tag_map[4] = 0x7;
                vtss_port_qos_set(port_no, &qos_port_conf);
            }
#endif /* VTSS_FEATURE_QOS_TAG_REMARK */
        }
#endif /* VTSS_OPT_ROUTER */
        port_setup(port_no, 1);
    }

#if defined(VTSS_FEATURE_QOS_TAG_REMARK)
    {
        vtss_qce_t  qce;
        qce.id = 1;
        qce.type = VTSS_QCE_TYPE_TAG;
        qce.frame.tag_prio[0]= 1;
        qce.frame.tag_prio[1]= 1;
        qce.frame.tag_prio[2]= 2;
        qce.frame.tag_prio[3]= 2;
        qce.frame.tag_prio[4]= 3;
        qce.frame.tag_prio[5]= 3;
        qce.frame.tag_prio[6]= 4;
        qce.frame.tag_prio[7]= 4;
        vtss_qce_add(6,0,&qce);
    }
#endif /* VTSS_FEATURE_QOS_TAG_REMARK */

#if defined(VTSS_FEATURE_MAC_AGE_AUTO)
    /* Automatic aging used */
    vtss_mac_table_age_time_set(MAC_AGE_TIME_DEFAULT);
    mac_timer_started = 0;
#else
    /* Manual aging used */
    VTSS_MTIMER_START(&mac_timer, 5000);
    mac_timer_started = 1;
#endif /* VTSS_FEATURE_MAC_AGE_AUTO */

    /* Plugin Start Up */
    for(i = 0; i < NR_PLUGINS; i++)
        if(plugins[i].startup)
            plugins[i].startup(argc, argv);

#if VTSS_OPT_CLI
    if(!opt_no_cli)
        cli_init();
#endif /* VTSS_OPT_CLI */

    /* Start up Board */
    if(board.startup)
        board.startup();

    /* Detect link up/down and do MAC address ageing */
    for (;;) {
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
           
            /* Receive frame to CPU */
            cpu_frame_rx();
            
            /* Check MAC address age timer */
            if (mac_timer_started && VTSS_MTIMER_TIMEOUT(&mac_timer)) {
#if defined(VTSS_FEATURE_LAYER2)
                if(!layer2_plugin) /* ??? */
                    vtss_mac_table_age();
#endif /* VTSS_FEATURE_LAYER2 */
                VTSS_MTIMER_START(&mac_timer, MAC_AGE_TIME_DEFAULT*1000/2);
            }

            /* Plugin Run */
            for(i = 0; i < NR_PLUGINS; i++)
                if(plugins[i].run)
                    plugins[i].run();

            if (!port_poll[port_no])
                continue; /* Skip port status polling */

            if(board.run)
                board.run();

            /* Get current status */
            vtss_port_status_get(port_no, &status);
            ps = &port_status[port_no];
            link_old = ps->link;
            ps->link = status.link;
            ps->speed = status.speed;
            ps->fdx = status.fdx;
            ps->aneg.obey_pause = status.aneg.obey_pause;
            ps->aneg.generate_pause = status.aneg.generate_pause;
            
            if (board_port_vaui(port_no)) {
                /* VAUI port LED control */
                vtss_phy_write(port_no == 25 ? 9 : 17, 16 | VTSS_PHY_REG_GPIO,
                               (1<<1) | ((status.link ? 0 : 1)<<0));
            }
                
            /* Detect link down and disable port */
            if ((!status.link || status.link_down) && link_old) {
                VTSS_D(("link down event on port_no: %d", port_no));
                link_old = 0;

#if defined(VTSS_FEATURE_LAYER2)
                if(!layer2_plugin) { /* ??? */
                    vtss_port_stp_state_set(port_no, VTSS_STP_STATE_DISABLED);
                    vtss_mac_table_forget_port(port_no);
                }
#endif /* VTSS_FEATURE_LAYER2 */

                /* Plugin Link Event */
                for(i = 0; i < NR_PLUGINS; i++)
                    if(plugins[i].linkevent)
                        plugins[i].linkevent(VTSS_LINKEVENT_DOWN, port_no);

                /* Board event ? */
                if(board.linkevent)
                    board.linkevent(VTSS_LINKEVENT_DOWN, port_no);

                /* Board LED handler? */
                if(board.port_led_update)
                    board.port_led_update(port_no, &status, 0);
            }
            
            /* Detect link up and setup port */
            if (status.link && !link_old) { 
                VTSS_D(("link up event on port_no: %d", port_no));

#if defined(VTSS_FEATURE_LAYER2)
                if(!layer2_plugin)
                    vtss_port_stp_state_set(port_no, VTSS_STP_STATE_ENABLED);
#endif /* VTSS_FEATURE_LAYER2 */

                /* Plugin Link Event */
                for(i = 0; i < NR_PLUGINS; i++)
                    if(plugins[i].linkevent)
                        plugins[i].linkevent(VTSS_LINKEVENT_UP, port_no);

                if (port_conf[port_no].autoneg)
                    port_setup(port_no, 0);

                /* Board event ? */
                if(board.linkevent)
                    board.linkevent(VTSS_LINKEVENT_UP, port_no);

                /* Board LED handler? */
                if(board.port_led_update)
                    board.port_led_update(port_no, &status, 0);
            }
            
            /* Detect traffic when link is up */
            if (status.link && board.port_led_update)
                board.port_led_update(port_no, &status, 1);
#if VTSS_OPT_CLI
            if(!opt_no_cli)
                cli_tsk();
#endif /* VTSS_OPT_CLI */
        } /* Port loop */
#if defined(VTSS_OPT_RAPI) && VTSS_OPT_RAPI
        /* Poll RAPI */
        vtss_rapi_poll();
#endif /* VTSS_OPT_RAPI */
    } /* Forever loop */
    
    return 0;
}

/* ================================================================= *
 *  API functions
 * ================================================================= */

vtss_rc vtss_appl_port_status_get(const vtss_port_no_t            port_no,
                                  vtss_appl_port_status_t * const status)
{
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }

    /* Silently ignore unused ports */
    if (board.port_map[port_no].chip_port < 0)
        return VTSS_UNSPECIFIED_ERROR;
        
    *status = port_status[port_no];
    return VTSS_OK;
}

/* Get port configuration */
vtss_rc vtss_appl_port_conf_get(const vtss_port_no_t          port_no,
                                vtss_appl_port_conf_t * const conf)
{
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }
    *conf = port_conf[port_no];
    return VTSS_OK;
}

/* Set port configuration */
vtss_rc vtss_appl_port_conf_set(const vtss_port_no_t                port_no,
                                const vtss_appl_port_conf_t * const conf)
{
    BOOL error = 0;
    
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }

    /* PHY ports must run auto negotiation or 1G/100M/10M */
    if (board_port_phy(port_no) && conf->autoneg == 0 && 
        (conf->speed < VTSS_SPEED_10M || conf->speed > VTSS_SPEED_1G))
        error = 1;
    
    /* SerDes ports must run auto negotiation or 1G fdx */
    if (board_port_mac_interface(port_no) == VTSS_PORT_INTERFACE_SERDES &&
        conf->autoneg == 0 && (conf->speed != VTSS_SPEED_1G || conf->fdx == 0))
        error = 1;
    
#if defined(VTSS_FEATURE_10G)
    /* 10G ports must run 10G fdx */
    if (vtss_port_no_is_10g(port_no) && 
        (conf->autoneg || conf->speed != VTSS_SPEED_10G || conf->fdx == 0))
         error = 1;
 #endif /* VTSS_FEATURE_10G */            

     if (error) {
        VTSS_D(("illegal mode on port_no: %d", port_no));
        return VTSS_INVALID_PARAMETER;
    }    

    port_conf[port_no] = *conf;
    port_setup(port_no, 1);
    return VTSS_OK;
}

/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
