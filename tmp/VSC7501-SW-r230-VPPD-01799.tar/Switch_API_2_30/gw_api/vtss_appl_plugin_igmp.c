/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/

#include <vtss_switch_api.h>
#include <vtss_appl_plugins.h>
#include "vtss_grocx_igmp_api.h"

static int vtss_grocx_config_mode;   /* config mode: A(1)/B(2)/C(3)/D(4) */
static vtss_mtimer_t igmp_timer;

/*
 * Module Frame Receive
 */
static vtss_rc plugin_recv(const vtss_system_frame_header_t *header, const unsigned char *frame)
{
    /* IGMP frame handling */
    if (vtss_igmp_frame_is_igmp(header, frame) == VTSS_OK ) {
        VTSS_D(("GOT IGMP control message"));
        /* for config B */
        if((vtss_grocx_config_mode ==2) && (header->source_port_no == 6)){
            VTSS_D(("GOT IGMP control message for WAN!!! just forward it!!!"));
            vtss_cpu_tx_raw_frame(1, frame, header->length);
            return VTSS_OK;
        }
        if((vtss_grocx_config_mode ==2) && (header->source_port_no == 1)){
            VTSS_D(("GOT IGMP control message from WAN!!! just forward it!!!"));
            vtss_cpu_tx_raw_frame(6, frame, header->length);
            return VTSS_OK;
        }
        /* end of for config B */
        /* for config A */
        if((vtss_grocx_config_mode ==1) && (header->tag.vid == 2) && (header->source_port_no == 7)){
            VTSS_D(("GOT IGMP control message for WAN!!! just forward it!!!"));
            vtss_cpu_tx_raw_frame(1, frame, header->length);
            return VTSS_OK;
        }            
        if((vtss_grocx_config_mode ==1) && (header->tag.vid == 2) && (header->source_port_no == 1)){
            VTSS_D(("GOT IGMP control message from WAN!!! just forward it!!!"));
            vtss_cpu_tx_raw_frame(7, frame, header->length);
            return VTSS_OK;
        } 
        /* end of for config A */
        vtss_igmp_receive(header->source_port_no, header->tag.vid, frame, header->length);
        return VTSS_OK;
    }
    return VTSS_PACKET_PROTOCOL_ERROR;
}

/*
 * Module Startup
 */
static void plugin_startup(int argc, const char **argv)
{
    int port_config_type;       
    vtss_grocx_router_port_config_type_get(&port_config_type);

    vtss_grocx_config_mode = port_config_type + 1; /* Map 0 -> 1, 1 -> 2, etc */

    vtss_igmps_init(vtss_grocx_config_mode);
    
    VTSS_MTIMER_START(&igmp_timer, VTSS_OPT_IGMP_CHECK_TIMER);
}

/*
 * Module Run
 */
static void plugin_run(void)
{
    /* Check MLD timer */
    if (VTSS_MTIMER_TIMEOUT(&igmp_timer)) {
        vtss_igmps_timer();
        VTSS_MTIMER_START(&igmp_timer, VTSS_OPT_IGMP_CHECK_TIMER);
    }
}

/*
 * Module Link Events
 */
static void plugin_linkevent(vtss_linkevent_t event, vtss_port_no_t port_no)
{
    if(event == VTSS_LINKEVENT_DOWN) {
        vtss_igmp_del_group_member_port(port_no);
    }
}

/*
 * Module Initialisation
 */
vtss_rc vtss_plugin_igmp_init(vtss_plugin_t *plugin)
{
    /* Install plugin hooks */
    plugin->startup = plugin_startup;
    plugin->run = plugin_run;
    plugin->recv = plugin_recv;
    plugin->linkevent = plugin_linkevent;

    return VTSS_OK;
}
