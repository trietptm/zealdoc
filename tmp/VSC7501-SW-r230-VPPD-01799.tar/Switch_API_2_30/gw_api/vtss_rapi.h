/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/

#ifndef _VTSS_VTSS_RAPI_H_
#define _VTSS_VTSS_RAPI_H_

#include "vtss_grocx_switch_api.h"
#include "vtss_appl_api.h"
#include "vtss_grocx_igmp_api.h"


#define PORT 3344

typedef enum {
    RAPI_MSG_APPL_PORT_STATUS_GET = 1,  /* vtss_appl_port_status_get */
    RAPI_MSG_APPL_PORT_CONF_GET,        /* vtss_appl_port_conf_get */
    RAPI_MSG_APPL_PORT_CONF_SET,        /* vtss_appl_port_conf_set */
    RAPI_MSG_PORT_STATUS_GET,           /* OBSOLETE: vtss_port_status_get */
    RAPI_MSG_PORT_SETUP,                /* OBSOLETE: vtss_port_setup */
    RAPI_MSG_POAG_COUNTERS_GET,         /* vtss_poag_counters_get */
    RAPI_MSG_POAG_COUNTERS_CLEAR,       /* vtss_poag_counters_clear */
    RAPI_MSG_PHY_SETUP,                 /* OBSOLETE: vtss_phy_setup */
    RAPI_MSG_ACL_POLICY_NO_SET,         /* vtss_acl_policy_no_set */
    RAPI_MSG_ACL_PORT_ACTION_SET,       /* vtss_acl_port_action_set */
    RAPI_MSG_ACL_POLICER_RATE_SET,      /* vtss_acl_policer_rate_set */
    RAPI_MSG_ACL_PORT_COUNTER_GET,      /* vtss_acl_port_counter_get */
    RAPI_MSG_ACL_PORT_COUNTER_CLEAR,    /* vtss_acl_port_counter_clear */
    RAPI_MSG_ACE_INIT,                  /* vtss_ace_init */
    RAPI_MSG_ACE_ADD,                   /* vtss_ace_add */
    RAPI_MSG_ACE_DEL,                   /* vtss_ace_del */
    RAPI_MSG_ACE_GET,                   /* vtss_ace_get */
    RAPI_MSG_ACE_COUNTER_GET,           /* vtss_ace_counter_get */
    RAPI_MSG_ACE_COUNTER_CLEAR,         /* vtss_ace_counter_clear */
    RAPI_MSG_QCE_ADD,                   /* vtss_qce_add */
    RAPI_MSG_QCE_DEL,                   /* vtss_qce_del */
    RAPI_MSG_QOS_SETUP_GET,             /* vtss_qos_setup_get */
    RAPI_MSG_QOS_SETUP_SET,             /* vtss_qos_setup_set */
    RAPI_MSG_QOS_PRIOS_SET,             /* vtss_qos_prios_set */
    RAPI_MSG_PORT_QOS_GET,              /* vtss_port_qos_get */
    RAPI_MSG_PORT_QOS_SET,              /* vtss_port_qos_set */
    RAPI_MSG_VLAN_PORT_MODE_GET,        /* vtss_vlan_port_mode_get */
    RAPI_MSG_VLAN_PORT_MODE_SET,        /* vtss_vlan_port_mode_set */
    RAPI_MSG_VLAN_PORT_MEMBERS_GET,     /* vtss_vlan_port_members_get */
    RAPI_MSG_VLAN_PORT_MEMBERS_SET,     /* vtss_vlan_port_members_set */
    RAPI_MSG_PVLAN_PORT_MEMBERS_GET,    /* vtss_pvlan_port_members_get */
    RAPI_MSG_PVLAN_PORT_MEMBERS_SET,    /* vtss_pvlan_port_members_set */
    RAPI_MSG_ISOLATED_VLAN_SET,         /* vtss_isolated_vlan_set */
    RAPI_MSG_ISOLATED_PORTS_SET,        /* vtss_isolated_ports_set */
    RAPI_MSG_MAC_TABLE_AGE_TIME_SET,    /* vtss_mac_table_age_time_set */
    RAPI_MSG_MAC_TABLE_LEARN,           /* vtss_mac_table_learn */
    RAPI_MSG_MAC_TABLE_FORGET_VID_MAC,  /* vtss_mac_table_forget_vid_mac */
    RAPI_MSG_MAC_TABLE_GET_NEXT,        /* vtss_mac_table_get_next */
    RAPI_MSG_MAC_TABLE_LOOKUP,          /* vtss_mac_table_lookup */
    RAPI_MSG_MAC_TABLE_FLUSH,           /* vtss_mac_table_flush */
    RAPI_MSG_APPL_GROCX_PORT_MAP_GET,   /* vtss_appl_grocx_port_map_get */
    RAPI_MSG_IGMP_MODE_SET,             /* vtss_igmp_set_mode */
    RAPI_MSG_IGMP_MODE_GET,             /* vtss_igmp_get_mode */
    RAPI_MSG_IGMP_UNREG_FLOOD_SET,      /* vtss_igmp_set_unreg_flood */
    RAPI_MSG_IGMP_UNREG_FLOOD_GET,      /* vtss_igmp_get_unreg_flood */
    RAPI_MSG_IGMP_FAST_LEAVE_PORT_SET,  /* vtss_igmp_set_fast_leave_port */
    RAPI_MSG_IGMP_FAST_LEAVE_PORT_GET,  /* vtss_igmp_get_fast_leave_port */
    RAPI_MSG_IGMP_VLAN_INFO_GET,        /* vtss_igmp_get_vlan_info */
    RAPI_MSG_IGMP_CLEAR_STAT_COUNTER,   /* vtss_igmp_clear_stat_counter */
    RAPI_MSG_MAX
} vtss_rapi_req_t;

typedef struct {
    vtss_rapi_req_t	req;
    vtss_rc		rc;     /* For response */
    union vtss_rapi_msg_var {
        struct {
            vtss_port_no_t          port_no;
            vtss_appl_port_status_t status;
        } appl_port_status_get;
        struct {
            vtss_port_no_t          port_no;
            vtss_appl_port_conf_t   conf;
        } appl_port_conf_get;
        struct {
            vtss_port_no_t          port_no;
            vtss_appl_port_conf_t   conf;
        } appl_port_conf_set;
        struct {                        /* vtss_port_status_get */
            vtss_port_no_t          port_no;
            vtss_port_status_t      status;
        } port_status_get;
        struct {                        /* vtss_port_setup */
            vtss_port_no_t          port_no;
            vtss_port_setup_t       setup;
        } port_setup;
        struct {                        /* vtss_poag_counters_get */
            vtss_poag_no_t          poag_no;
            vtss_poag_counters_t    counters;
        } poag_counters_get;
        struct {                        /* vtss_poag_counters_clear */
            vtss_poag_no_t          poag_no;
        } poag_counters_clear;
        struct {
            vtss_port_no_t          port_no;
            vtss_phy_setup_t        setup;
        } phy_setup;
        struct {
            vtss_port_no_t          port_no;
            vtss_appl_grocx_port_map_t map;
        } appl_grocx_port_map_get;
#if defined(VTSS_FEATURE_ACL)
        struct {                        /* vtss_acl_policy_no_set */
            vtss_port_no_t          port_no;
            vtss_acl_policy_no_t    policy_no;
        } acl_policy_no_set;
        struct {                        /* vtss_acl_port_action_set */
            vtss_port_no_t          port_no;
            vtss_acl_action_t       action;
        } acl_port_action_set;
        struct {                        /* vtss_acl_policer_rate_set */
            vtss_acl_policer_no_t   policer_no;
            vtss_packet_rate_t      rate;
        } acl_policer_rate_set;
        struct {                        /* vtss_acl_port_counter_get */
            vtss_port_no_t          port_no;
            vtss_acl_port_counter_t counter;
        } acl_port_counter_get;
        struct {                        /* vtss_acl_port_counter_clear */
            vtss_port_no_t          port_no;
        } acl_port_counter_clear;
        struct {                        /* vtss_ace_init */
            vtss_ace_type_t         type;
            vtss_ace_t              ace;
        } ace_init;
        struct {                        /* vtss_ace_add */
            vtss_ace_id_t           ace_id;
            vtss_ace_t              ace;
        } ace_add;
        struct {                        /* vtss_ace_del */
            vtss_ace_id_t           ace_id;
        } ace_del;
        struct {                        /* vtss_ace_get */
            vtss_ace_id_t           ace_id;
            vtss_ace_counter_t      counter;
        } ace_get;
        struct {
            vtss_ace_id_t        ace_id;
            vtss_ace_counter_t   counter;
        } ace_counter_get;
        struct {
            vtss_ace_id_t           ace_id;
        } ace_counter_clear;
#endif /* VTSS_FEATURE_ACL */
#if defined(VTSS_FEATURE_QCL_PORT)
        struct {                        /* vtss_qce_add */
            vtss_qcl_id_t           qcl_id;
            vtss_qce_id_t           qce_id;
            vtss_qce_t              qce;
        } qce_add;
        struct {                        /* vtss_qce_del */
            vtss_qcl_id_t           qcl_id;
            vtss_qce_id_t           qce_id;
        } qce_del;
#endif /* VTSS_FEATURE_QCL_PORT */
        struct {                        /* vtss_qos_setup_get */
            vtss_qos_setup_t        qos;
        } qos_setup_get;
        struct {                        /* vtss_qos_setup_set */
            vtss_qos_setup_t        qos;
        } qos_setup_set;
        struct {                        /* vtss_qos_prios_set */
            vtss_prio_t             prios;
        } qos_prios_set;
        struct {                        /* vtss_port_qos_get */
            vtss_port_no_t          port_no;
            vtss_port_qos_setup_t   qos;
        } port_qos_get;
        struct {                        /* vtss_port_qos_set */
            vtss_port_no_t          port_no;
            vtss_port_qos_setup_t   qos;
        } port_qos_set;
        struct {                        /* vtss_vlan_port_mode_get */
            vtss_port_no_t          port_no;
            vtss_vlan_port_mode_t   vlan_mode;
        } vlan_port_mode_get;
        struct {                        /* vtss_vlan_port_mode_set */
            vtss_port_no_t          port_no;
            vtss_vlan_port_mode_t   vlan_mode;
        } vlan_port_mode_set;
        struct {                        /* vtss_vlan_port_members_get */
            vtss_vid_t              vid;
            BOOL                    member[VTSS_PORT_ARRAY_SIZE];
        } vlan_port_members_get;
        struct {                        /* vtss_vlan_port_members_set */
            vtss_vid_t              vid;
            BOOL                    member[VTSS_PORT_ARRAY_SIZE];
        } vlan_port_members_set;
        struct {                        /* vtss_pvlan_port_members_get */
            vtss_pvlan_no_t         pvlan_no;
            BOOL                    member[VTSS_PORT_ARRAY_SIZE];
        } pvlan_port_members_get;
        struct {                        /* vtss_pvlan_port_members_set */
            vtss_pvlan_no_t         pvlan_no;
            BOOL                    member[VTSS_PORT_ARRAY_SIZE];
        } pvlan_port_members_set;
        struct {                        /* vtss_isolated_ports_set */
            BOOL                    member[VTSS_PORT_ARRAY_SIZE];
        } isolated_ports_set;

#if defined(VTSS_FEATURE_ISOLATED_PORT)
        struct {                        /* vtss_isolated_vlan_set */
            vtss_vid_t              vid;
            BOOL                          isolated;
        } isolated_vlan_set;
#endif /* VTSS_FEATURE_ISOLATED_PORT */
#if defined(VTSS_FEATURE_MAC_AGE_AUTO)
        struct {                        /* vtss_mac_table_age_time_set */
            vtss_mac_age_time_t     age_time;
        } mac_table_age_time_set;
#endif /* VTSS_FEATURE_MAC_AGE_AUTO */
        struct {                        /* vtss_mac_table_learn */
            vtss_mac_table_entry_t  entry;
        } mac_table_learn;
        struct {                        /* vtss_mac_table_forget_vid_mac */
            vtss_vid_mac_t          vid_mac;
        } mac_table_forget_vid_mac;
        struct {                        /* vtss_mac_table_get_next */
            vtss_vid_mac_t          vid_mac;
            vtss_mac_table_entry_t  entry;
        } mac_table_get_next;
        struct {                        /* vtss_mac_table_lookup */
            vtss_vid_mac_t          vid_mac;
            vtss_mac_table_entry_t  entry;
        } mac_table_lookup;
        struct {                        /* vtss_igmp_set_mode */
            BOOL   mode;
        } igmp_mode_set;
        struct {                        /* vtss_igmp_get_mode */
            BOOL   mode;
        } igmp_mode_get;
        struct {                        /* vtss_igmp_set_unreg_flood */
            BOOL   mode;
        } igmp_unreg_flood_set;
        struct {                        /* vtss_igmp_get_unreg_flood */
            BOOL   mode;
        } igmp_unreg_flood_get;
        struct {                        /* vtss_igmp_set_fast_leave_port */
            vtss_igmp_fast_leave_port_t fast_leave_port;
        } igmp_fast_leave_port_set;
        struct {                        /* vtss_igmp_set_fast_leave_port */
            vtss_igmp_fast_leave_port_t fast_leave_port;
        } igmp_fast_leave_port_get;
        struct {                        /* vtss_igmp_get_vlan_info */
            ushort vid;
            vtss_igmp_vid_stat_entry_t vid_entry;
        } igmp_vlan_info_get;        
#if 0
        struct {                        /* vtss_mac_table_flush */
        } mac_table_flush;
#endif
    } var;
} vtss_rapi_msg;

int vtss_rapi_init(void);

void vtss_rapi_poll(void);

#define __F(x) sizeof(((vtss_rapi_msg*)NULL)->var.x);
static __inline__ size_t vtss_rapi_msgsize(vtss_rapi_req_t req)
{
    size_t size = sizeof(vtss_rapi_msg) - sizeof(union vtss_rapi_msg_var);

    switch(req) {
    case RAPI_MSG_APPL_PORT_STATUS_GET:
        size += __F(appl_port_status_get);
        break;
    case RAPI_MSG_APPL_PORT_CONF_GET:
        size += __F(appl_port_conf_get);
        break;
    case RAPI_MSG_APPL_PORT_CONF_SET:
        size += __F(appl_port_conf_set);
        break;
    case RAPI_MSG_PORT_STATUS_GET:
        size += __F(port_status_get);
        break;
    case RAPI_MSG_APPL_GROCX_PORT_MAP_GET:
        size += __F(appl_grocx_port_map_get);
        break;
    case RAPI_MSG_PORT_SETUP:
        size += __F(port_setup);
        break;
    case RAPI_MSG_POAG_COUNTERS_GET:
        size += __F(poag_counters_get);
        break;
    case RAPI_MSG_POAG_COUNTERS_CLEAR:
        size += __F(poag_counters_clear);
        break;
    case RAPI_MSG_PHY_SETUP:
        size += __F(phy_setup);
        break;
#if defined(VTSS_FEATURE_ACL)
    case RAPI_MSG_ACL_POLICY_NO_SET:
        size += __F(acl_policy_no_set);
        break;
    case RAPI_MSG_ACL_PORT_ACTION_SET:
        size += __F(acl_port_action_set);
        break;
    case RAPI_MSG_ACL_POLICER_RATE_SET:
        size += __F(acl_policer_rate_set);
        break;
    case RAPI_MSG_ACL_PORT_COUNTER_GET:
        size += __F(acl_port_counter_get);
        break;
    case RAPI_MSG_ACL_PORT_COUNTER_CLEAR:
        size += __F(acl_port_counter_clear);
        break;
    case RAPI_MSG_ACE_INIT:
        size += __F(ace_init);
        break;
    case RAPI_MSG_ACE_ADD:
        size += __F(ace_add);
        break;
    case RAPI_MSG_ACE_DEL:
        size += __F(ace_del);
        break;
    case RAPI_MSG_ACE_GET:
        size += __F(ace_get);
        break;
    case RAPI_MSG_ACE_COUNTER_GET:
        size += __F(ace_counter_get);
        break;
    case RAPI_MSG_ACE_COUNTER_CLEAR:
        size += __F(ace_counter_clear);
        break;
#endif /* VTSS_FEATURE_ACL */
#if defined(VTSS_FEATURE_QCL_PORT)
    case RAPI_MSG_QCE_ADD:
        size += __F(qce_add);
        break;
    case RAPI_MSG_QCE_DEL:
        size += __F(qce_del);
        break;
#endif /* VTSS_FEATURE_QCL_PORT */
    case RAPI_MSG_QOS_SETUP_GET:
        size += __F(qos_setup_get);
        break;
    case RAPI_MSG_QOS_SETUP_SET:
        size += __F(qos_setup_set);
        break;
    case RAPI_MSG_QOS_PRIOS_SET:
        size += __F(qos_prios_set);
        break;
    case RAPI_MSG_PORT_QOS_GET:
        size += __F(port_qos_get);
        break;
    case RAPI_MSG_PORT_QOS_SET:
        size += __F(port_qos_set);
        break;
    case RAPI_MSG_VLAN_PORT_MODE_GET:
        size += __F(vlan_port_mode_get);
        break;    
    case RAPI_MSG_VLAN_PORT_MODE_SET:
        size += __F(vlan_port_mode_set);
        break;
    case RAPI_MSG_VLAN_PORT_MEMBERS_GET:
        size += __F(vlan_port_members_get);
        break;
    case RAPI_MSG_VLAN_PORT_MEMBERS_SET:
        size += __F(vlan_port_members_set);
        break;
    case RAPI_MSG_PVLAN_PORT_MEMBERS_GET:
        size += __F(pvlan_port_members_get);
        break;
    case RAPI_MSG_PVLAN_PORT_MEMBERS_SET:
        size += __F(pvlan_port_members_set);
        break;
    case RAPI_MSG_ISOLATED_PORTS_SET:
        size += __F(isolated_ports_set);
        break;
#if defined(VTSS_FEATURE_ISOLATED_PORT)
    case RAPI_MSG_ISOLATED_VLAN_SET:
        size += __F(isolated_vlan_set);
        break;
#endif /* VTSS_FEATURE_ISOLATED_PORT */
#if defined(VTSS_FEATURE_MAC_AGE_AUTO)
    case RAPI_MSG_MAC_TABLE_AGE_TIME_SET:
        size += __F(mac_table_age_time_set);
        break;
#endif /* VTSS_FEATURE_MAC_AGE_AUTO */
    case RAPI_MSG_MAC_TABLE_LEARN:
        size += __F(mac_table_learn);
        break;
    case RAPI_MSG_MAC_TABLE_FORGET_VID_MAC:
        size += __F(mac_table_forget_vid_mac);
        break;
    case RAPI_MSG_MAC_TABLE_GET_NEXT:
        size += __F(mac_table_get_next);
        break;
    case RAPI_MSG_MAC_TABLE_LOOKUP:
        size += __F(mac_table_lookup);
        break;
    case RAPI_MSG_IGMP_MODE_SET:
        size += __F(igmp_mode_set);
        break;
    case RAPI_MSG_IGMP_MODE_GET:
        size += __F(igmp_mode_get);
        break;
    case RAPI_MSG_IGMP_UNREG_FLOOD_SET:
        size += __F(igmp_unreg_flood_set);
        break;
    case RAPI_MSG_IGMP_UNREG_FLOOD_GET:
        size += __F(igmp_unreg_flood_get);
        break;
    case RAPI_MSG_IGMP_FAST_LEAVE_PORT_SET:
        size += __F(igmp_fast_leave_port_set);
        break;
    case RAPI_MSG_IGMP_FAST_LEAVE_PORT_GET:
        size += __F(igmp_fast_leave_port_get);
        break;
    case RAPI_MSG_IGMP_VLAN_INFO_GET:
        size += __F(igmp_vlan_info_get);
        break;   
    case RAPI_MSG_MAC_TABLE_FLUSH:
        /* size += __F(mac_table_flush); */
        break;
    case RAPI_MSG_IGMP_CLEAR_STAT_COUNTER:

        break;        
    default:
        size = -1;
    }

    return size;
}
#undef __F

#endif /* _VTSS_VTSS_RAPI_H_ */

/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
