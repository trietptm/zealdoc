/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/

#include <stdlib.h>
#include <string.h>
#include <linux/vitgenio.h>
#include <sys/ioctl.h>
#include <fcntl.h>

/* API public headers */
#include "vtss_switch_api.h"
#include "vtss_appl.h"

/* Board port map */
static vtss_mapped_port_t board_port_map[VTSS_PORT_ARRAY_SIZE] = { 
    { -1,-1, -1 } /*unused*/,
    {  0, VTSS_MIIM_CONTROLLER_0,  0 },
    {  1, VTSS_MIIM_CONTROLLER_0,  1 },
    {  2, VTSS_MIIM_CONTROLLER_0,  2 },
    {  3, VTSS_MIIM_CONTROLLER_0,  3 },
    {  4, VTSS_MIIM_CONTROLLER_0,  4 },
    {  5, VTSS_MIIM_CONTROLLER_0,  5 },
    {  6, VTSS_MIIM_CONTROLLER_0,  6 },
    {  7, VTSS_MIIM_CONTROLLER_0,  7 },
    {  8, VTSS_MIIM_CONTROLLER_1,  8 },
    {  9, VTSS_MIIM_CONTROLLER_1,  9 },
    { 10, VTSS_MIIM_CONTROLLER_1, 10 },
    { 11, VTSS_MIIM_CONTROLLER_1, 11 },
    { 12, VTSS_MIIM_CONTROLLER_1, 12 },
    { 13, VTSS_MIIM_CONTROLLER_1, 13 },
    { 14, VTSS_MIIM_CONTROLLER_1, 14 },
    { 15, VTSS_MIIM_CONTROLLER_1, 15 },
    { 16, VTSS_MIIM_CONTROLLER_1, 16 },
    { 17, VTSS_MIIM_CONTROLLER_1, 17 },
    { 18, VTSS_MIIM_CONTROLLER_1, 18 },
    { 19, VTSS_MIIM_CONTROLLER_1, 19 },
    { 20, VTSS_MIIM_CONTROLLER_1, 20 },
    { 21, VTSS_MIIM_CONTROLLER_1, 21 },
    { 22, VTSS_MIIM_CONTROLLER_1, 22 },
    { 23, VTSS_MIIM_CONTROLLER_1, 23 },
    { 24, VTSS_MIIM_CONTROLLER_NONE, -1 },
    { 26, VTSS_MIIM_CONTROLLER_NONE, -1 }
};

static void
board_startup(void)
{
    /* Release PHYs from reset (Switch GPIO9) */
    vtss_gpio_direction_set(9, 1);
    vtss_gpio_output_write(9, 0);
    vtss_gpio_output_write(9, 1);
    VTSS_MSLEEP(500);
}

static void
phy_reset(vtss_port_no_t port_no)
{
    /* LED control */
    vtss_phy_write(port_no, 29, 0xee64);
        
    /* Make PHY GPIO0 and GPIO1 output for VAUI port LED control */
    vtss_phy_write(port_no, 13 | VTSS_PHY_REG_GPIO, 0xffff);
    vtss_phy_write(port_no, 17 | VTSS_PHY_REG_GPIO, 0x0003);
}

static void
board_connect(int argc, const char **argv, vtss_io_state_t *io) 
{
    int fd;
    struct vitgenio_cs_setup_timing timing;

    /* Open driver */
    if ((fd = open("/dev/vitgenio", 0)) < 0) {
        VTSS_E(("open(\"/dev/vitgenio\"): %s",strerror(errno)));
        return;
    }

    VTSS_D(("Using CS%d", timing.cs));
    ioctl(fd, VITGENIO_CS_SELECT, timing.cs );
    io->fd = fd;
}

void
vtss_board_hookup(struct vtss_board *board, int argc, const char **argv)
{
    board->name = "E-stax 34";
    board->port_map = board_port_map;
    board->connect = board_connect;
    board->startup = board_startup;
    board->phy_reset = phy_reset;
}

