/*

 Vitesse PHY API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_phy_io.h,v 1.9 2008/02/20 15:04:54 cpj Exp $
 $Revision: 1.9 $

*/

#ifndef _VTSS_PHY_IO_H_
#define _VTSS_PHY_IO_H_

/* Get common definitions, types and macros */
#include "vtss_os.h"
#include "vtss_basic_trace.h"


typedef int vtss_phy_io_bus_t;


#ifdef VTSS_API
/* Conversion from phy_bus <-> chip_no,miim_controller */
#if defined(VTSS_CHIPS)
#define VTSS_PHY_CHIPMIIM(phy_bus) (phy_bus>>4),(phy_bus&0xF)
#define VTSS_PHY_BUS(chip_no,miim_controller) ((chip_no<<4)|(miim_controller&0xF))
#else
#define VTSS_PHY_CHIPMIIM(phy_bus) (phy_bus&0xF)
#define VTSS_PHY_BUS(miim_controller) (miim_controller&0xF)
#endif
#endif /* VTSS_API */


/* PHY I/O Layer state information */
typedef struct _vtss_phy_io_state_t {
#ifdef VTSS_API
    int unused; /* Dummy to avoid empty struct */
#endif /* VTSS_API */
#if (defined(VTSS_FORCE_CPLD_MIIM) || !defined(VTSS_API)) && defined(VTSS_VITGENIO)
    int fd; /* File descriptor */
#endif /* !VTSS_API && VTSS_VITGENIO */
#ifdef VTSS_MYIO
    /* Insert your PHY I/O handle here */
#endif /* VTSS_MYIO */
} vtss_phy_io_state_t;


/* Select PHY I/O Context */
void vtss_phy_io_select_context( vtss_phy_io_state_t * io );

/* Initialize PHY I/O Layer, must be called before any other function */
void vtss_phy_io_init(void);

/* Read PHY register */
vtss_rc vtss_phy_io_read(   const vtss_phy_io_bus_t bus,
                            const uint              addr,
                            const uint              reg,
                            ushort *const           value );

/* Write PHY register */
vtss_rc vtss_phy_io_write(  const vtss_phy_io_bus_t bus,
                            const uint              addr,
                            const uint              reg,
                            const ushort            value );


#endif /* _VTSS_PHY_IO_H_ */
