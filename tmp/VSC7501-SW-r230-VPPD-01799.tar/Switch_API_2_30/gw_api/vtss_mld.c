/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_mld.c,v 1.6 2008/02/20 15:04:53 cpj Exp $
 $Revision: 1.6 $

*/

#define VTSS_TRACE_FILE "mlds" /* MLD Snooping */

#include "vtss_mld_api.h"

#if VTSS_OPT_MLD

/* ================================================================= *
 *  Linked list structures
 * ================================================================= */

typedef struct _linkedlist_node_t {
    struct _linkedlist_node_t * prev;
    struct _linkedlist_node_t * next;
    void * value;
} linkedlist_node_t;
#define LINKEDLIST_NODE_INIT(ptr) do { (ptr)->next = (ptr); (ptr)->prev = (ptr); } while (0)

/* The type of a linked list is the same as that of an entry in the linked list. */
#define linkedlist_t linkedlist_node_t
#define LINKEDLIST_INIT(ptr) LINKEDLIST_NODE_INIT(ptr)

/* ================================================================= *
 *  Global variables
 * ================================================================= */

static vtss_mldsnooping_init_setup_t mldsnooping_config;

typedef struct _vtss_mldsnooping_entry_t {
    uchar               addr[4]; /* Low 4 bytes of multicast address */
    BOOL                member[VTSS_PORT_ARRAY_SIZE];
    BOOL                aged[VTSS_PORT_ARRAY_SIZE];
    linkedlist_node_t   allocation; /* The value is a pointer to self. */
    linkedlist_node_t   hash; /* The value is a pointer to self. */ /* Node pointers only valid when self is allocated. */
} vtss_mldsnooping_entry_t;

vtss_mldsnooping_entry_t    mld_table[VTSS_OPT_MLD_MAXGROUPS];

linkedlist_t                mld_freepool;
linkedlist_t                mld_allocated;

linkedlist_t                mld_hashtable[256];

/* ================================================================= *
 *  Linked list library
 * ================================================================= */

/*
 * Insert a new entry between two known consecutive entries.
 *
 * This is only for internal list manipulation where we know
 * the prev/next entries already!
 */
static void __linkedlist_add( linkedlist_node_t * const entry,
                              linkedlist_node_t * const prev,
                              linkedlist_node_t * const next )
{
    next->prev = entry;
    entry->next = next;
    entry->prev = prev;
    prev->next = entry;
}

/**
 * Add a new entry at the head of the list.
 * @new: new entry to be added
 * @head: list head to add it after
 *
 * Insert a new entry after the specified head.
 * This is good for implementing stacks.
 */
static void linkedlist_add( linkedlist_node_t * const entry,
                            linkedlist_t * const head )
{
    __linkedlist_add( entry, head, head->next );
}

/*
 * Delete a list entry by making the prev/next entries
 * point to each other.
 *
 * This is only for internal list manipulation where we know
 * the prev/next entries already!
 */
static void __linkedlist_del( linkedlist_node_t * const prev,
                              linkedlist_node_t * const next )
{
    next->prev = prev;
    prev->next = next;
}

/**
 * Delete entry from list.
 * @entry: the element to delete from the list.
 * Note: linkedlist_empty on entry does not return true after this,
 * the entry is in an undefined state.
 */
static void linkedlist_del( linkedlist_node_t * const entry )
{
    __linkedlist_del( entry->prev, entry->next );
}

/**
 * Test whether a list is empty.
 * @head: the list to test.
 */
static int linkedlist_empty( const linkedlist_t * const head )
{
    return head->next == head;
}

/**
 * Iterate over a list.
 * @pos:        the &linkedlist_node_t to use as a loop counter.
 * @head:       the head for your list.
 */
#define LINKEDLIST_FOR_EACH( pos, head ) for (pos=(head)->next; pos!=(head); pos=pos->next)

/**
 * Iterate over a list. Safe against removal of list entry.
 * @pos:        the &linkedlist_node_t to use as a loop counter.
 * @temp:       another &linkedlist_node_t to use as temporary storage.
 * @head:       the head for your list.
 */
#define LINKEDLIST_FOR_EACH_SAFE( pos, temp, head ) for (pos=(head)->next, temp=pos->next; pos!=(head); pos=temp, temp=pos->next)

/* ================================================================= *
 *  MLD
 * ================================================================= */

static void mld_table_clear(void)
{
    int i;

    LINKEDLIST_INIT(&mld_freepool);
    LINKEDLIST_INIT(&mld_allocated);
    for ( i=0; i<256; i++ ) {
        LINKEDLIST_INIT(&mld_hashtable[i]);
    }

    for ( i=0; i<VTSS_OPT_MLD_MAXGROUPS; i++ ) {
        vtss_port_no_t port_no;
        vtss_mldsnooping_entry_t * const mld_entry = &mld_table[i];

        mld_entry->addr[0] = 0;
        mld_entry->addr[1] = 0;
        mld_entry->addr[2] = 0;
        mld_entry->addr[3] = 0;
        for (port_no = VTSS_PORT_NO_START;
             port_no < VTSS_PORT_NO_END;
             port_no++) {
            mld_entry->member[port_no] = 0;
            mld_entry->aged[port_no] = 0;
        }

        LINKEDLIST_NODE_INIT(&(mld_entry->allocation));
        mld_entry->allocation.value = mld_entry;
        mld_entry->hash.value = mld_entry;

        linkedlist_add(&(mld_entry->allocation),&mld_freepool);
    }
}

static vtss_rc mld_update_mactable( const vtss_mldsnooping_entry_t * const mld_entry )
{
    vtss_port_no_t port_no;
    vtss_mac_table_entry_t mac_entry;

    mac_entry.vid_mac.vid = mldsnooping_config.lan_vid;
    mac_entry.vid_mac.mac.addr[0] = 0x33;
    mac_entry.vid_mac.mac.addr[1] = 0x33;
    mac_entry.vid_mac.mac.addr[2] = mld_entry->addr[0];
    mac_entry.vid_mac.mac.addr[3] = mld_entry->addr[1];
    mac_entry.vid_mac.mac.addr[4] = mld_entry->addr[2];
    mac_entry.vid_mac.mac.addr[5] = mld_entry->addr[3];
    for (port_no = VTSS_PORT_NO_START;
         port_no < VTSS_PORT_NO_END;
         port_no++) {
        mac_entry.destination[port_no] = mld_entry->member[port_no];
    }
    mac_entry.copy_to_cpu = 0;
    mac_entry.locked = 1;
    mac_entry.aged = 0;
    return vtss_mac_table_learn( &mac_entry );
}

static vtss_rc mld_remove_mactable( const vtss_mldsnooping_entry_t * const mld_entry )
{
    vtss_vid_mac_t vid_mac;

    vid_mac.vid = mldsnooping_config.lan_vid;
    vid_mac.mac.addr[0] = 0x33;
    vid_mac.mac.addr[1] = 0x33;
    vid_mac.mac.addr[2] = mld_entry->addr[0];
    vid_mac.mac.addr[3] = mld_entry->addr[1];
    vid_mac.mac.addr[4] = mld_entry->addr[2];
    vid_mac.mac.addr[5] = mld_entry->addr[3];
    return vtss_mac_table_forget_vid_mac( &vid_mac );
}

static vtss_rc mld_table_update(
    const vtss_port_no_t    port_no,
    const uchar * const     ipv6addr )
{
    linkedlist_node_t * hashpos;
    vtss_mldsnooping_entry_t * mld_entry;
    const uchar hashkey = ipv6addr[12] ^ ipv6addr[13] ^ ipv6addr[14] ^ ipv6addr[15];

    LINKEDLIST_FOR_EACH(hashpos,&mld_hashtable[hashkey]) {
        mld_entry = hashpos->value;
        if ( mld_entry->addr[0] == ipv6addr[12] &&
             mld_entry->addr[1] == ipv6addr[13] &&
             mld_entry->addr[2] == ipv6addr[14] &&
             mld_entry->addr[3] == ipv6addr[15]) {
            if ( mld_entry->member[port_no] ) {
                VTSS_N(("Port already member. Clear age flag."));
                mld_entry->aged[port_no] = 0;
                return VTSS_OK;
            }
            break;
        }
    }
    if (hashpos==&mld_hashtable[hashkey]) {
        VTSS_D(("Add new multicast group FF??:?:?:?:?:?:%02X%02X:%02X%02X to MLD Table.",ipv6addr[12],ipv6addr[13],ipv6addr[14],ipv6addr[15]));
        if (linkedlist_empty(&mld_freepool)) {
            VTSS_D(("MLD Table Full."));
            return VTSS_UNSPECIFIED_ERROR;
        } else {
            vtss_port_no_t port_no;
            linkedlist_node_t * pos = mld_freepool.next;
            /* Delete from free pool, and put in allocated pool */
            linkedlist_del( pos );
            linkedlist_add( pos, &mld_allocated );
            mld_entry = pos->value;
            /* Add to hash table */
            linkedlist_add( &(mld_entry->hash), &mld_hashtable[hashkey] );

            mld_entry->addr[0] = ipv6addr[12];
            mld_entry->addr[1] = ipv6addr[13];
            mld_entry->addr[2] = ipv6addr[14];
            mld_entry->addr[3] = ipv6addr[15];
            for (port_no = VTSS_PORT_NO_START;
                 port_no < VTSS_PORT_NO_END;
                 port_no++) {
                mld_entry->member[port_no] = 0;
                mld_entry->aged[port_no] = 0;
            }
        }
    }

    VTSS_D(("Add port %d to multicast group FF??:?:?:?:?:?:%02X%02X:%02X%02X and update MAC table.", port_no, mld_entry->addr[0], mld_entry->addr[1], mld_entry->addr[2], mld_entry->addr[3]));

    mld_entry->member[port_no] = 1;
    mld_entry->aged[port_no] = 0;

    return mld_update_mactable( mld_entry );
}

static vtss_rc mld_forward_to_all(
    const vtss_system_frame_header_t * const    sys_header,
	const uchar * const                         frame )
{
    vtss_port_no_t port_no;
    vtss_rc rc = VTSS_OK;

    for (port_no = VTSS_PORT_NO_START;
         port_no < VTSS_PORT_NO_END;
         port_no++) {
        if (port_no==sys_header->source_port_no) continue; /* Don't send on ingress port. */
        rc = vtss_cpu_tx_poag_frame( port_no, sys_header->tag.vid, frame, sys_header->length );
        if (rc<VTSS_WARNING) return rc;
    }
    return rc;
}

static vtss_rc mld_forward_to_routers(
    const vtss_system_frame_header_t * const    sys_header,
	const uchar * const                         frame )
{
    vtss_port_no_t port_no;
    vtss_rc rc = VTSS_OK;

    for (port_no = VTSS_PORT_NO_START;
         port_no < VTSS_PORT_NO_END;
         port_no++) {
        if (port_no==sys_header->source_port_no) continue; /* Don't send on ingress port. */
        if (!mldsnooping_config.router_port[port_no]) continue; /* Don't send on non-router ports. */
        rc = vtss_cpu_tx_poag_frame( port_no, sys_header->tag.vid, frame, sys_header->length );
        if (rc<VTSS_WARNING) return rc;
    }
    return rc;
}

vtss_rc vtss_mldsnooping_init(
    const vtss_mldsnooping_init_setup_t * const setup )
{
    VTSS_D(("enter"));

    mldsnooping_config = *setup;

    VTSS_D(("Clear MLD Table."));
    mld_table_clear();

    {
        vtss_port_no_t port_no;
        vtss_mac_table_entry_t mac_entry;

        /* AN0099-00-04 chapter 5.2.1 */
        VTSS_D(("Insert special IPv6 multicast addresses in MAC table to forward to all ports"));
        mac_entry.vid_mac.vid = mldsnooping_config.lan_vid;
        for (port_no = VTSS_PORT_NO_START;
             port_no < VTSS_PORT_NO_END;
             port_no++) {
            mac_entry.destination[port_no] = 1;
        }
        mac_entry.copy_to_cpu = 0;
        mac_entry.locked = 1;
        mac_entry.aged = 0;
        mac_entry.vid_mac.mac.addr[0] = 0x33;
        mac_entry.vid_mac.mac.addr[1] = 0x33;
        mac_entry.vid_mac.mac.addr[2] = 0x00;
        mac_entry.vid_mac.mac.addr[3] = 0x00;
        mac_entry.vid_mac.mac.addr[4] = 0x00;
        mac_entry.vid_mac.mac.addr[5] = 0x01; /* All-Nodes */
        vtss_mac_table_learn( &mac_entry );
        mac_entry.vid_mac.mac.addr[5] = 0x02; /* All-Routers */
        vtss_mac_table_learn( &mac_entry );
        mac_entry.vid_mac.mac.addr[5] = 0x6A; /* All-Snoopers */
        vtss_mac_table_learn( &mac_entry );
        mac_entry.vid_mac.mac.addr[5] = 0x16; /* All-MLDv2-Routers */
        vtss_mac_table_learn( &mac_entry );
    }
    {
        /* AN0099-00-04 chapter 5.2.2 */
        VTSS_D(("Setup IPv6 multicast flooding to Router ports only"));
        vtss_ipv6_mc_flood_mask_set( mldsnooping_config.router_port );
    }    

    {
        vtss_cpu_rx_registration_t reg;

        /* AN0099-00-04 chapter 5.2.3 */
        VTSS_D(("Register for MLD messages"));
        vtss_cpu_rx_registration_get(&reg);
        reg.mcast_mld_cpu_only = 1;
        vtss_cpu_rx_registration_set(&reg);
    }

    /* AN0099-00-04 says that this should be disabled for the Bronze solution. This is wrong, because:
       General Queries are sent to this address, so it must be enabled for General Queries to be captured.
       (Refer to the VSC7396 datasheet's description of the CAPENAB register's bit 22.) */
    VTSS_D(("Setup IPv6 Link-Local multicast flooding to all ports"));
    vtss_ipv6_mc_ctrl_flood_set( 1 );

    VTSS_N(("leave"));
    return VTSS_OK;
}

#define MLD_MSG_TYPE_QUERY  130
#define MLD_MSG_TYPE_REPORT 131
#define MLD_MSG_TYPE_DONE   132

#define IPV6HDR     (6/*dmac*/+6/*smac*/+2/*ethertype*/)
#define IPV6OPTIONS (IPV6HDR+4+2+1+1+16+16)
#define MLDHDR      (IPV6OPTIONS+1+1+4+2)
#define MLDADDR     (MLDHDR+1/*type*/+1/*code*/+2/*checksum*/+2/*maxresponsedelay*/+2/*reserved*/)

#define GET8(frame,pos)     (frame[pos])
#define GET16(frame,pos)    ((frame[pos]<<8)+frame[pos+1])
#define GET32(frame,pos)    ((frame[pos]<<24)+(frame[pos+1]<<16)+(frame[pos+2]<<8)+frame[pos+3])

vtss_rc vtss_mldsnooping_frame_is_mld(
    const vtss_system_frame_header_t * const    sys_header,
	const uchar * const                         frame )
{
    if ( GET16(frame,6+6) != 0x86DD ) {
        VTSS_N(("Ethertype!=0x86DD (IPv6)."));
        return VTSS_PACKET_PROTOCOL_ERROR;
    }
    if ( GET8(frame,IPV6HDR)>>4 != 6 ) {
        VTSS_N(("IPv6 Version!=6."));
        return VTSS_PACKET_PROTOCOL_ERROR;
    }
    if ( GET16(frame,IPV6HDR+4)<0x20 ) {
        VTSS_N(("Payload length<0x20 (too small)."));
        return VTSS_PACKET_PROTOCOL_ERROR;
    }
    if ( GET8(frame,IPV6HDR+4+2) != 0 ) {
        VTSS_N(("IPv6 header NextHeader!=0 (Hop-by-hop)."));
        return VTSS_PACKET_PROTOCOL_ERROR;
    }
    if ( GET8(frame,IPV6HDR+4+2+1) != 1 ) {
        VTSS_N(("Hop Limit!=1."));
        return VTSS_PACKET_PROTOCOL_ERROR;
    }
    if ( GET8(frame,IPV6OPTIONS) != 58 ) {
        VTSS_N(("Hop-by-hop NextHeader!=58 (ICMPv6)."));
        return VTSS_PACKET_PROTOCOL_ERROR;
    }
    if ( GET8(frame,IPV6OPTIONS+1) != 0 ) {
        VTSS_N(("Hop-by-hop length!=0."));
        return VTSS_PACKET_PROTOCOL_ERROR;
    }
    /* Padding normally comes after the MLD Router Alert, but in very rare cases it comes before. */
    if ( !((GET32(frame,IPV6OPTIONS+1+1)==0x05020000 /*MLD*/ &&
            (GET16(frame,IPV6OPTIONS+1+1+4)==0x0000 /*Pad1*/ ||
             GET16(frame,IPV6OPTIONS+1+1+4)==0x0100 /*PadN*/ )) ||
           ((GET16(frame,IPV6OPTIONS+1+1)==0x0000 /*Pad1*/ ||
             GET16(frame,IPV6OPTIONS+1+1)==0x0100 /*PadN*/ ) &&
            GET32(frame,IPV6OPTIONS+1+1+2)==0x05020000 /*MLD*/ ))) {
        VTSS_N(("Hop-by-hop not MLD Router Alert with Padding appended/prepended."));
        return VTSS_PACKET_PROTOCOL_ERROR;
    }
    return VTSS_OK;
}

vtss_rc vtss_mldsnooping_frame(
    const vtss_system_frame_header_t * const    sys_header,
	const uchar * const                         frame )
{
    if ( sys_header->tag.vid != mldsnooping_config.lan_vid ) {
        VTSS_D(("MLD ingressing on different VLAN. Forward to all ports in that VLAN."));
        return mld_forward_to_all( sys_header, frame );
    }

    switch ( GET8(frame,MLDHDR) /* Message Type */ ) {

    case MLD_MSG_TYPE_QUERY:
        {
            if ( !mldsnooping_config.router_port[sys_header->source_port_no] ) {
                VTSS_D(("MLD Query ingressing on non-router port. Discard."));
                return VTSS_OK;
            } else {
                VTSS_D(("MLD Query ingressing on router port. Forward to all ports."));
                return mld_forward_to_all( sys_header, frame );
            }
        }

    case MLD_MSG_TYPE_REPORT:
        {
            vtss_rc rc;

            VTSS_D(("MLD Report ingressing on any port."));
            VTSS_D(("Snoop MLD Report."));
            if ( GET8(frame,MLDADDR+12)==0x00 &&
                 GET8(frame,MLDADDR+13)==0x00 &&
                 GET8(frame,MLDADDR+14)==0x00 &&
                 (GET8(frame,MLDADDR+15)==0x01 /* All-Nodes */ ||
                  GET8(frame,MLDADDR+15)==0x02 /* All-Routers */ ||
                  GET8(frame,MLDADDR+15)==0x6A /* All-Snoopers */ ||
                  GET8(frame,MLDADDR+15)==0x16 /* All-MLDv2-Routers */)) {
                VTSS_D(("Do not update MLD Table or MAC table because Multicast Address is a special multicast address."));
            } else {
                VTSS_D(("Update MLD Table."));
                rc = mld_table_update( sys_header->source_port_no, &frame[MLDADDR] );
                if (rc<VTSS_WARNING) {
                    VTSS_D(("MLD Table update failed. Discard MLD Report."));
                    return rc;
                }
            }
            VTSS_D(("Forward MLD Report to router ports."));
            return mld_forward_to_routers( sys_header, frame );
        }

    case MLD_MSG_TYPE_DONE:
        {
            VTSS_D(("MLD Done ingressing on any port. Forward to all ports."));
            return mld_forward_to_all( sys_header, frame );
        }

    default:
        {
            VTSS_D(("Other MLD ingressing on any port. Forward to all ports."));
            return mld_forward_to_all( sys_header, frame );
        }
    }
}

vtss_rc vtss_mldsnooping_aging( void )
{
    linkedlist_node_t * pos;
    linkedlist_node_t * temp;

    VTSS_D(("enter"));

    LINKEDLIST_FOR_EACH_SAFE(pos,temp,&mld_allocated) {
        vtss_port_no_t port_no;
        BOOL modify = 0;
        BOOL keep = 0;
        vtss_mldsnooping_entry_t * const mld_entry = pos->value;

        for (port_no = VTSS_PORT_NO_START;
             port_no < VTSS_PORT_NO_END;
             port_no++) {
            if ( mld_entry->member[port_no] ) {
                if ( !mld_entry->aged[port_no] ) {
                    mld_entry->aged[port_no] = 1;
                    keep = 1;
                } else {
                    VTSS_D(("Remove port %d from multicast group FF??:?:?:?:?:?:%02X%02X:%02X%02X.", port_no, mld_entry->addr[0], mld_entry->addr[1], mld_entry->addr[2], mld_entry->addr[3]));
                    mld_entry->member[port_no] = 0;
                    mld_entry->aged[port_no] = 0;
                    modify = 1;
                }
            }
        }

        if (modify) {
            if (keep) {
                VTSS_D(("Update MAC table."));
                mld_update_mactable( mld_entry );
            } else {
                VTSS_D(("No more members in multicast group. Delete from MAC table and MLD Table."));
                /* Delete from MAC table */
                mld_remove_mactable( mld_entry );
                /* Delete from hash table */
                linkedlist_del( &(mld_entry->hash) );
                /* Delete from allocated pool, and put in free pool */
                linkedlist_del( pos );
                linkedlist_add( pos, &mld_freepool );
            }
        }
    }

    VTSS_N(("leave"));
    return VTSS_OK;
}

#endif /* VTSS_OPT_MLD */
