/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_io.h,v 1.22 2008/06/25 07:50:57 cpj Exp $
 $Revision: 1.22 $

*/

#ifndef _VTSS_IO_H_
#define _VTSS_IO_H_

/* I/O architecture */
#if defined(VTSS_ARCH_HEATHROW)
#define VTSS_IO_HEATHROW    /* Heathrow chip i/o architecture */
#endif /* VTSS_ARCH_HEATHROW */

#if defined(VTSS_ARCH_GATWICK)
#define VTSS_IO_GATWICK     /* Gatwick chip i/o architecture */
#endif /* VTSS_ARCH_GATWICK */

/* I/O layer state information */
typedef struct _vtss_io_state_t {
#ifdef VTSS_VITGENIO
    int   fd; /* File descriptor */
#if VTSS_OPT_DMA
    int   dma_ch;   /* DMA channel number */
    uchar *dma_mem; /* DMA memory start pointer */
    uint  dma_size; /* DMA memory size */
    int   dma_offs; /* DMA memory offset to next byte to read */
#endif /* VTSS_OPT_DMA */
#endif /* VTSS_VITGENIO */
#ifdef VTSS_MEMORYMAPPEDIO
    volatile ulong *baseaddr; /* Base address of the chip */
#endif /* VTSS_MEMORYMAPPEDIO */
#if VTSS_OPT_NICIO
#ifdef VTSS_LINUX_RAWSOCK_IO
    int nic_fd;     /* RAW NIC socket on Linux */
#endif
#endif
#ifdef VTSS_IO_RABBIT
    int s;          /* Socket descriptor */
#endif /* VTSS_IO_RABBIT */
} vtss_io_state_t;

/* Select I/O */
void vtss_io_select_chip(vtss_io_state_t *io);

/* Initialize I/O Layer, must be called before any other function */
void vtss_io_init(void);

#if defined(VTSS_IO_HEATHROW)

vtss_rc vtss_io_si_rd(uint block, uint subblock, const uint reg, ulong * const value);
vtss_rc vtss_io_si_wr(uint block, uint subblock, const uint reg, const ulong value);

vtss_rc vtss_io_pi_rd(uint block, uint subblock, const uint reg, ulong * const value);
vtss_rc vtss_io_pi_wr(uint block, uint subblock, const uint reg, const ulong value);

#endif /* VTSS_IO_HEATHROW */

#if defined(VTSS_IO_GATWICK)

/* Setup DMA driver */
vtss_rc vtss_io_dma_init(void);

/* Read DMA buffer */
vtss_rc vtss_io_dma_read(int len, uchar *data, int skip);

/* Read SI register */
vtss_rc vtss_io_si_rd(uint target, uint address, ulong *value);

/* Write SI register */
vtss_rc vtss_io_si_wr(uint target, uint address, ulong value);

/* Read PI register */
vtss_rc vtss_io_pi_rd(uint block, uint address, ulong *value);

/* Write PI register */
vtss_rc vtss_io_pi_wr(uint block, uint address, ulong value);

/* Read target register using PI */
vtss_rc vtss_io_pi_tgt_rd(uint target, uint address, ulong *value);

/* Write target register using PI */
vtss_rc vtss_io_pi_tgt_wr(uint target, uint address, ulong value);

#endif /* VTSS_IO_GATWICK */

#if VTSS_OPT_NICIO
/* Copy raw frame to OS driver's tx frame buffer and enqueue OS buffer for transmission */
vtss_rc vtss_io_nic_tx(const uchar * const frame,
                       const uint          length);

/* Is an OS rx frame buffer ready for reading */
/* Returns: 0: no frame ready, <0: error, >0: frame ready */
vtss_rc vtss_io_nic_rx_ready(void);

/* Copy raw frame from OS driver's rx frame buffer and release OS driver's rx frame buffer */
vtss_rc vtss_io_nic_rx(uchar * const frame,
                       const uint maxlength);
#endif

#if defined(VTSS_ARCH_B2)
#if defined(VTSS_IO_RABBIT)
/* Execute rabbit command */
vtss_rc vtss_rabbit_cmd(const char *cmd, ulong *value);
#endif /* VTSS_IO_RABBIT */    

/* Read or write target register via PI */
vtss_rc vtss_io_pi_rd_wr(uint tgt, uint addr, ulong *value, BOOL read);
#endif /* VTSS_ARCH_B2 */

#endif /* _VTSS_IO_H_ */
