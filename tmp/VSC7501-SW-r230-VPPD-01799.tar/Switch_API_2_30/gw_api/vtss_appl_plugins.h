/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/

/*
 * This file describe the (protocol) modules pluggable for the switch application
 */

#ifndef _VTSS_APPL_PLUGINS_H_
#define _VTSS_APPL_PLUGINS_H_

#include <vtss_appl.h>

#define VTSS_PLUGIN_FLAG_LAYER2		0x01 /* Layer2 control protocol */

typedef struct vtss_plugin {
    const char		*name;
    vtss_rc 		(*init)(struct vtss_plugin *plugin);
    void 		(*startup)(int argc, const char **argv);
    void 		(*run)(void);
#if defined(VTSS_FEATURE_CPU_RX_TX)
    vtss_rc 		(*recv)(const vtss_system_frame_header_t *header, const unsigned char *frame);
#endif /* defined(VTSS_FEATURE_CPU_RX_TX) */
    void		(*linkevent)(vtss_linkevent_t event, vtss_port_no_t port_no);
    ulong		flags;
} vtss_plugin_t;

#if VTSS_OPT_IGMP
extern vtss_rc vtss_plugin_igmp_init(struct vtss_plugin *plugin);
#endif /* VTSS_OPT_IGMP */
#if VTSS_OPT_RSTP
extern vtss_rc vtss_plugin_rstp_init(struct vtss_plugin *plugin);
#endif /* VTSS_OPT_RSTP */
#if VTSS_OPT_MLD
extern vtss_rc vtss_plugin_mld_init(struct vtss_plugin *plugin);
#endif /* VTSS_OPT_MLD */

#if defined(VTSS_SWITCH_APP)
vtss_plugin_t plugins[] = {
#if VTSS_OPT_IGMP
    { 
        .name = "igmps", 
        .init = vtss_plugin_igmp_init,
    },
#endif /* VTSS_OPT_IGMP */
#if VTSS_OPT_RSTP
    { 
        .name = "rstp", 
        .init = vtss_plugin_rstp_init,
    },
#endif /* VTSS_OPT_RSTP */
#if VTSS_OPT_MLD
    { 
        .name = "mld", 
        .init = vtss_plugin_mld_init,
    },
#endif /* VTSS_OPT_MLD */
};

#define NR_PLUGINS	ARR_SZ(plugins)
#endif /* defined(VTSS_SWITCH_APP) */

#endif /* _VTSS_APPL_PLUGINS_H_ */
