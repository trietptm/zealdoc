/*

 Vitesse PHY API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_phy_state.h,v 1.21 2008/04/16 20:49:50 jkrishna Exp $
 $Revision: 1.21 $

*/

#ifndef _VTSS_PHY_STATE_H_
#define _VTSS_PHY_STATE_H_

#include "vtss_types.h"
#include "vtss_phy_io.h"

#if VTSS_PHY_OPT_VERIPHY
#include "vtss_phy_veriphy.h"
#endif

/* PHY type */
typedef enum _vtss_phy_type_t {
    VTSS_PHY_TYPE_NONE = 0,    /* Unknown */
    VTSS_PHY_TYPE_8201 = 8201, /* VSC8201 (Mustang) */
    VTSS_PHY_TYPE_8204 = 8204, /* VSC8204 (Blazer) */
    VTSS_PHY_TYPE_8211 = 8211, /* VSC8211 (Cobra) */
    VTSS_PHY_TYPE_8221 = 8221, /* VSC8221 (Cobra) */
    VTSS_PHY_TYPE_8224 = 8224, /* VSC8224 (Quattro) */
    VTSS_PHY_TYPE_8234 = 8234, /* VSC8234 (Quattro) */
    VTSS_PHY_TYPE_8244 = 8244, /* VSC8244 (Quattro) */
    VTSS_PHY_TYPE_8538 = 8538, /* VSC8538 (Spyder) */
    VTSS_PHY_TYPE_8558 = 8558, /* VSC8558 (Spyder) */
    VTSS_PHY_TYPE_8658 = 8658, /* VSC8658 (GTO) */
    VTSS_PHY_TYPE_8601 = 8601, /* VSC8601 (Cooper) */
    VTSS_PHY_TYPE_8641 = 8641, /* VSC8641 (Cooper) */
    VTSS_PHY_TYPE_7385 = 7385, /* VSC7385 (Northolt) */
    VTSS_PHY_TYPE_7388 = 7388, /* VSC7388 (Luton) */
    VTSS_PHY_TYPE_7389 = 7389, /* VSC7389, VSC7391 (Luton16/16r) */
    VTSS_PHY_TYPE_7390 = 7390, /* VSC7390 (Luton24) */
    VTSS_PHY_TYPE_7395 = 7395, /* VSC7395, VSC7396 (Luton5e/5m) */
    VTSS_PHY_TYPE_7398 = 7398,  /* VSC7398, (Luton8) */
    VTSS_PHY_TYPE_7500 = 7500,  /* VSC7500 (Intrigue) */
    VTSS_PHY_TYPE_7501 = 7501,  /* VSC7501 (Intrigue) */
    VTSS_PHY_TYPE_7502 = 7502,  /* VSC7502 (Intrigue) */
    VTSS_PHY_TYPE_7503 = 7503,  /* VSC7503 (Intrigue) */
    VTSS_PHY_TYPE_7504 = 7504,  /* VSC7504 (Intrigue) */
    VTSS_PHY_TYPE_7505 = 7505,  /* VSC7505 (Intrigue) */
    VTSS_PHY_TYPE_7506 = 7506,  /* VSC7506 (Intrigue) */
    VTSS_PHY_TYPE_7507 = 7507,  /* VSC7507 (Intrigue) */
    VTSS_PHY_TYPE_8634 = 8634,  /* VSC8634 (Enzo) */
    VTSS_PHY_TYPE_8664 = 8664   /* VSC8664 (Enzo) */  
} vtss_phy_type_t; 

/* PHY family */
typedef enum _vtss_phy_family_t {
    VTSS_PHY_FAMILY_NONE,     /* Unknown */
    VTSS_PHY_FAMILY_MUSTANG,  /* VSC8201 */
    VTSS_PHY_FAMILY_BLAZER,   /* VSC8204 */
    VTSS_PHY_FAMILY_COBRA,    /* VSC8211/21 */
    VTSS_PHY_FAMILY_QUATTRO,  /* VSC8224/34/44 */
    VTSS_PHY_FAMILY_SPYDER,   /* VSC8538/58/8658 */
    VTSS_PHY_FAMILY_COOPER,   /* VSC8601/41 */
    VTSS_PHY_FAMILY_LUTON,    /* VSC7385/88 */
    VTSS_PHY_FAMILY_LUTON24,  /* VSC7389/90/91 */
    VTSS_PHY_FAMILY_LUTON_E,  /* VSC7395/96/98 */
    VTSS_PHY_FAMILY_INTRIGUE, /* VSC7500-7507 */
    VTSS_PHY_FAMILY_ENZO      /* VSC8634/64 */
} vtss_phy_family_t;

typedef struct _vtss_phy_mapped_port_t {
    vtss_phy_io_bus_t   bus;
    int                 addr;
} vtss_phy_mapped_port_t;

/* PHY State information handle allocated by application */
typedef struct _vtss_phy_state_t {
    vtss_phy_io_state_t io;     /* PHY I/O Layer state information */
    void                *al;    /* Pointer to PHY API state memory,
                                   size: vtss_phy_sizeof_al() */
} vtss_phy_state_t;

vtss_phy_state_t *vtss_phy_state;   /* Full PHY API state */

/* Initialization setup */
typedef struct _vtss_phy_init_setup_t {
    uint                ports;
} vtss_phy_init_setup_t;

/* PHY setup */
typedef struct _vtss_phy_setup_t {
    /* PHY mode */
    enum {
        VTSS_PHY_MODE_ANEG,             /* Auto negoatiation */
        VTSS_PHY_MODE_FORCED,           /* Forced mode */
        VTSS_PHY_MODE_POWER_DOWN        /* Power down (disabled) */
    } mode;
    
    /* Forced mode */
    struct {
        vtss_speed_t speed; /* Speed */
        BOOL         fdx;   /* Full duplex */
    } forced;
    
    /* Auto negotiation advertisement */
    struct {
        BOOL speed_10m_hdx;    /* 10Mbps, half duplex */
        BOOL speed_10m_fdx;    /* 10Mbps, full duplex */
        BOOL speed_100m_hdx;   /* 100Mbps, half duplex */
        BOOL speed_100m_fdx;   /* 100Mbps, full duplex */
        BOOL speed_1g_fdx;     /* 1000Mpbs, full duplex */
        BOOL symmetric_pause;  /* Symmetric pause */
        BOOL asymmetric_pause; /* Asymmetric pause */
    } aneg;
} vtss_phy_setup_t;

/* 1000-BT Control */
typedef struct _vtss_phy_setup_1g_t {
    enum {
        VTSS_PHY_TX_TMOD_NORMAL,                /* Normal */
        VTSS_PHY_TX_TMOD_WAVE_FORM_TEST,        /* Xmit Waveform Test */
        VTSS_PHY_TX_TMOD_JTR_TST_MSTR,          /* Xmit Jitter test as Master */
        VTSS_PHY_TX_TMOD_JTR_TST_SLV,           /* Xmit Jitter test as Slave */
        VTSS_PHY_TX_TMOD_XMIT_DSTN_TEST         /* Xmitter Distortion test */
    } txmtr_test_mode;                          /* Transmitter Test Mode */
    
    struct {
        BOOL cfg;                               /* Manual Master/Slave Config. 1=enabled */
        BOOL val;                               /* Master/Slave Config value, 1=Master */
    } master_slave;    
} vtss_phy_setup_1g_t;

/* PHY power savings constants */
#define VTSS_PHY_ACTIPHY_PWR        100   
#define VTSS_PHY_LINK_DOWN_PWR      200   
#define VTSS_PHY_LINK_UP_FULL_PWR   400    

/* Power Save/Reduction modes */
typedef enum _vtss_phy_power_mode_t {
    VTSS_PHY_POWER_NOMINAL,    /* Default power settings */
    VTSS_PHY_POWER_ACTIPHY,    /* ActiPHY - Link down power savings enabled */
    VTSS_PHY_POWER_DYNAMIC,    /* SimpliGreen - Link up power savings enabled */
    VTSS_PHY_POWER_ENABLED    /* ActiPHY + SimpliGreen enabled */
} vtss_phy_power_mode_t;
    
typedef struct _vtss_phy_power_setup_t {
    BOOL vtss_phy_power_dynamic;
    BOOL vtss_phy_actiphy_on;
    uint pwrusage;
} vtss_phy_power_setup_t;

/* Media interface type */
typedef enum _vtss_phy_media_interface_t {
    VTSS_PHY_MEDIA_INTERFACE_COPPER,      /* Copper interface */
    VTSS_PHY_MEDIA_INTERFACE_FIBER,       /* SerDes/Fiber interface */
    VTSS_PHY_MEDIA_INTERFACE_AMS_COPPER,  /* Automatic selection, copper preferred */
    VTSS_PHY_MEDIA_INTERFACE_AMS_FIBER    /* Automatic selection, fiber preferred */
} vtss_phy_media_interface_t;

typedef struct _vtss_phy_reset_t {
    vtss_port_interface_t      mac_if;   /* MAC interface */
    vtss_phy_media_interface_t media_if; /* Media inteface */

    /* RGMII setup */
    struct {
        uint rx_clk_skew_ps; /* Rx clock skew in pico seconds */
        uint tx_clk_skew_ps; /* Tx clock skew in pico seconds */
    } rgmii;

    /* TBI setup */
    struct {
        BOOL aneg_enable; /* Enable auto negotiation */
    } tbi;
} vtss_phy_reset_setup_t;

/* State per PHY */
typedef struct _vtss_phy_port_state_info_t {
    vtss_phy_mapped_port_t map;      /* PHY map */
    vtss_phy_reset_setup_t reset;    /* Reset setup */
    vtss_phy_family_t      family;   /* Family */
    vtss_phy_type_t        type;     /* Type */
    uint                   revision; /* Revision number */
    vtss_phy_setup_t       setup;    /* Setup */
    vtss_phy_setup_1g_t    setup_1g; /* 1g setup */
    vtss_phy_power_setup_t power;    /* Power Reduction Setup */
    vtss_port_status_t     status;   /* Status */
    vtss_port_status_1g_t  status_1g; /* 1G Status */
#if VTSS_PHY_OPT_VERIPHY
    vtss_veriphy_task_t    veriphy;  /* VeriPHY task */
#endif /* VTSS_PHY_OPT_VERIPHY */
} vtss_phy_port_state_info_t;

/* This struct is followed by a vtss_phy_port_state_info_t[port_array_size] array. */
typedef struct _vtss_phy_state_info_t {
    uint                        port_array_size;
    vtss_phy_port_state_info_t *port;
} vtss_phy_state_info_t;

#endif /* _VTSS_PHY_STATE_H_ */
