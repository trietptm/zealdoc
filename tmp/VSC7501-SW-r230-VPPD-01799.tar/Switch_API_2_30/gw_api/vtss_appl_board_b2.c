/*

 Vitesse Switch API software.

 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#if defined(VTSS_VITGENIO)
#include <linux/vitgenio.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#endif /* VTSS_VITGENIO */

#if defined(VTSS_IO_RABBIT)
#undef __USE_EXTERN_INLINES /* Avoid warning */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#endif /* VTSS_IO_RABBIT */

#if defined(VTSS_TRACE)
/* Advanced trace system used */
#include <vtss_trace_lvl_api.h>
#include <vtss_trace_api.h>

#define VTSS_TRACE_MODULE_ID   VTSS_MODULE_ID_UNMGD
#define VTSS_TRACE_GRP_DEFAULT 0
#define TRACE_GRP_CNT          1
#define VTSS_TRACE_LAYER       4
#else
#define VTSS_TRACE_FILE        "ap"
#define VTSS_TRACE_LAYER       3
#endif /* VTSS_TRACE */

/* API public headers */
#include "vtss_switch_api.h"
#include "vtss_appl.h"

static vtss_init_setup_t b2_init_setup;

/* Board port map */
static vtss_mapped_port_t board_port_map[VTSS_PORT_ARRAY_SIZE] = { 
    { -1,-1, -1 } /*unused*/,
    {  0, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0,  0 },
    {  1, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0,  1 },
#if (VTSS_PORTS > 2) /* EXEC_1 */
    {  2, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0,  2 },
    {  3, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0,  3 },
    {  4, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0,  4 },
    {  5, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0,  5 },
    {  6, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0,  6 },
    {  7, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0,  7 },
    {  8, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0,  8 },
    {  9, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0,  9 },
    { 10, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 10 },
    { 11, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 11 },
    { 12, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 12 },
#endif /* VTSS_PORTS > 2 */
#if (VTSS_PORTS > 13) /* SCHAUMBURG_II */
    { 13, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 13 },
    { 14, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 14 },
    { 15, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 15 },
    { 16, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 16 },
    { 17, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 17 },
    { 18, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 18 },
    { 19, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 19 },
    { 20, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 20 },
    { 21, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 21 },
    { 22, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 22 },
    { 23, VTSS_LPORT_MAP_DEFAULT, VTSS_MIIM_CONTROLLER_0, 23 },
#endif /* VTSS_PORTS > 13 */
};

static vtss_port_interface_t
board_port_mac_interface(vtss_port_no_t port_no)
{
    return (vtss_port_no_is_10g(port_no) ? VTSS_PORT_INTERFACE_XAUI : 
            board_port_map[port_no].miim_controller == VTSS_MIIM_CONTROLLER_NONE ? 
            VTSS_PORT_INTERFACE_SERDES : VTSS_PORT_INTERFACE_SGMII);
}

/* Initialize CPU/switch interface */
static void board_cpu_if_init(vtss_io_state_t *io) 
{
#if defined(VTSS_MEMORYMAPPEDIO)
    /* Setup base address for memory mapped I/O */
    io->baseaddr = (ulong *) VTSS_MEMORYMAPPEDIO_BASE;
#endif

#if defined(VTSS_VITGENIO)
    int                             fd;

    /* Open driver */
    if ((fd = open("/dev/vitgenio", 0)) < 0) {
        VTSS_E(("open(\"/dev/vitgenio\"): %s",strerror(errno)));
        return;
    }

#if defined(VTSS_OPT_USE_CPU_SI)
    {   /* Setup SI interface */
        struct vitgenio_cpld_spi_setup timing = {
            /* char ss_select; Which of the GPIOs is used for Slave Select */
            VITGENIO_SPI_SS_CPLD_GPIO0,
            VITGENIO_SPI_SS_ACTIVE_LOW, /* char ss_activelow; Slave Select (Chip Select) active low: true, active high: false */
            VITGENIO_SPI_CPOL_0, /* char sck_activelow; CPOL=0: false, CPOL=1: true */
            VITGENIO_SPI_CPHA_0, /* char sck_phase_early; CPHA=0: false, CPHA=1: true */
            VITGENIO_SPI_MSBIT_FIRST, /* char bitorder_msbfirst; */
            0, /* char reserved1; currently unused, only here for alignment purposes */
            0, /* char reserved2; currently unused, only here for alignment purposes */
            0, /* char reserved3; currently unused, only here for alignment purposes */
            500 /* unsigned int ndelay; minimum delay in nanoseconds, two of these delays are used per clock cycle */
        };
        
        VTSS_D(("Setting up SPI timing"));
        /* Setup the SPI timing of the I/O Layer driver */
        ioctl(fd, VITGENIO_ENABLE_CPLD_SPI);
        ioctl(fd, VITGENIO_CPLD_SPI_SETUP, &timing);
    }
#endif /* VTSS_OPT_USE_CPU_SI */

    VTSS_D(("Using CS%d", timing.cs));
    ioctl(fd, VITGENIO_CS_SELECT, timing.cs );
    io->fd = fd;
#endif /* VTSS_VITGENIO */

#if defined(VTSS_IO_RABBIT)
    vtss_rabbit_cmd("reset_val_board 1", NULL);
    vtss_rabbit_cmd("reset_val_board 0", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8000006403", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x800000640000000502", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8800000303", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x880000030000004002", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x880000030000006002", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8800000303", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8800000003", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x880000010000004c02", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x880000030000004002", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8800000303", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8800000003", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x88000001000000c802", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x880000030000004002", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8800000303", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8800000003", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x880000010000008f02", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x880000030000004002", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8800000303", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8800000003", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x880000030000005002", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8800000303", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8800000303", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8800000003", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8000004403", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x80000044000001f702", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8000004403", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x80000044000001e702", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8000004403", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x80000044000001c702", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8000002403", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x80000024000008aa02", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8000002403", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x80000024000000aa02", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8000002403", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x80000024000001aa02", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8000002403", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x80000024000005aa02", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x800000200000000002", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8000003803", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x800000380000001f02", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8000005403", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x800000540000000002", NULL);
    vtss_rabbit_cmd("WPRP 0x2018 0x8000005403", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x800000540000000202", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x84fc00060000000002", NULL);
    vtss_rabbit_cmd("WP 0x2000 0x84fc00060000000002", NULL);
#endif /* VTSS_IO_RABBIT */
}

static int vtss_b2_connect(int argc, const char **argv, vtss_io_state_t *io)
{
#if defined(VTSS_IO_RABBIT)
    struct sockaddr_in saddr;
#endif /* VTSS_IO_RABBIT */
    
    if ((argc > 1 && *argv[1] == '?')
#if defined(VTSS_IO_RABBIT)
        || argc < 2 || inet_aton(argv[1], &saddr.sin_addr) == 0
#endif /* VTSS_IO_RABBIT */
        ) {
#if defined(VTSS_IO_RABBIT)
        printf("Usage: %s <rabbit_ip> [<parm>[:<value>]]\n\n", argv[0]);
#else
        printf("Usage: %s [<parm>[:<value>]]\n\n", argv[0]);
#endif /* VTSS_IO_RABBIT */
        printf("Example (host mode 5): %s 1.2.3.4 h:5\n\n", argv[0]);
#if defined(VTSS_IO_RABBIT)
        printf("Mandatory parameter:\n");
        printf("--------------------\n");
        printf("rabbit_ip: Rabbit board IP address\n\n");
#endif /* VTSS_IO_RABBIT */
        printf("Optional parameters:\n");
        printf("--------------------\n");
        printf("Each optional parameter may consist of two elements:\n");
        printf("<parm> : Keyword identifying the parameter. This may be abbreviated.\n");
        printf("<value>: Value required for some <parm> values.\n\n");
        printf("host_mode    : Host mode, value: 0,1,3,4,5,6,8,9 (default: 4)\n");
        printf("               If host_mode > 4, port 1-2 are 10G ports\n");
        printf("               If host_mode > 5, port 3-24 are unused\n");
        printf("sfp          : SFP module used for port 17-20 (port 21-24 are unused)\n");
        printf("port_max     : Maximum number of ports, value: 1-24 (default: %u)\n", VTSS_PORTS);
        printf("stag_etype   : S-Tag type, value: Ethernet Type (default: 0x88a8)\n");
        printf("rx_share     : Rx queue system share, value in percent (default: auto)\n");
        printf("rx_mode      : Rx mode, value: port_fifo/shared_drop (default: shared_lossless)\n");
        printf("tx_mode      : Tx mode port_fifo enable (default: shared_lossless)\n");
        printf("mtu          : Queue system MTU, value: 1518-10240 (default: 1518)\n");
        printf("q6_resv      : Q6 reservation enable (default: disabled)\n");
        printf("q7_resv      : Q7 reservation enable (default: disabled)\n");
        printf("sch_max_rate : Scheduler maximum rate, value in kbps\n");
        printf("spi4_flow    : SPI4 flow control disabled (default: enabled)\n");
        printf("spi4_3lvl    : SPI4 three level flow ctrl. enabled (default: disabled)\n");
        printf("spi4_rate    : SPI4 shaper rate, value in kbps (default: disabled)\n");
        printf("spi4_ib_fcs  : SPI4 FCS action, value: disabled/add (default: check)\n");
        printf("spi4_ib_clock: SPI4 inbound maximum clock, value: 290/360/450 (default: 500)\n");
        printf("spi4_ib_swap : SPI4 inbound swap enable (default: disabled)\n");
        printf("spi4_ib_inv  : SPI4 inbound invert enable (default: disabled)\n");
        printf("spi4_ib_shift: SPI4 inbound clock shift enable (default: disabled)\n");
        printf("spi4_ob_frame: SPI4 frame interleave mode (default: burst interleave)\n");
        printf("spi4_ob_hih  : SPI4 HIH enable (default: disabled)\n");
        printf("spi4_ob_clock: SPI4 outbound clock, value: 250/312/375/437 (default: 500)\n");
        printf("spi4_ob_phase: SPI4 outbound clock phase, value: 90/180/270 (default: 0)\n");
        printf("spi4_ob_swap : SPI4 outbound swap enable (default: disabled)\n");
        printf("spi4_ob_inv  : SPI4 outbound invert enable (default: disabled)\n");
        printf("spi4_ob_shift: SPI4 outbound clock shift enable (default: disabled)\n");
        printf("spi4_ob_burst: SPI4 burst size, value: 64/96/160/192/224/256 (default: 128)\n");
        printf("spi4_ob_max_1: SPI4 MaxBurst1, value: 0-255 (default: 64)\n");
        printf("spi4_ob_max_2: SPI4 MaxBurst2, value: 0-255 (default: 32)\n");
        printf("spi4_ob_up   : SPI4 link up limit, value: 1-16 (default: 2)\n");
        printf("spi4_ob_down : SPI4 link down limit, value: 1-16 (default: 2)\n");
        printf("spi4_ob_train: SPI4 training mode, value: disabled/forced/normal (default: auto)\n");
        printf("spi4_ob_alpha: SPI4 ALPHA, value: 1-255 (default: 1)\n");
        printf("spi4_ob_data : SPI4 DATA_MAX_T, value: 1-131000 (default: 10240)\n");
        printf("xaui_flow    : XAUI channel flow control enable (default: disabled)\n");
        printf("xaui_3lvl    : XAUI three level flow ctrl. enabled (default: disabled)\n");
        printf("xaui_rate    : XAUI shaper rate, value in kbps (default: disabled)\n");
        printf("xaui_pause   : XAUI pause frame obey enable (default: disabled)\n");
        printf("xaui_hih_pre : XAUI HIH before SFD enable (default: disabled)\n");
        printf("xaui_hih_chk : XAUI HIH checksum enable (default: disabled)\n");
        printf("xaui_ib_shift: XAUI inbound clock shift enable (default: disabled)\n");
        printf("xaui_ob_shift: XAUI outbound clock shift enable (default: disabled)\n");
        return 0;
    }
#if defined(VTSS_IO_RABBIT)
    saddr.sin_family = AF_INET;
    saddr.sin_port = htons(26);
    if ((io->s = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
        VTSS_E(("socket create failed"));
        return 0;
    }
    if (connect(io->s, (struct sockaddr *)&saddr, sizeof(saddr)) < 0) {
        VTSS_E(("connect to rabbit failed"));
        return 0;
    }
#endif /* VTSS_IO_RABBIT */
    return 1;
}

/* Parse options for B2 */
static int vtss_b2_parse_options(int argc, const char **argv, vtss_init_setup_t *setup)
{
    vtss_port_no_t     port_no;
    BOOL               sfp = 0, error, val_error;
    ulong              value = 0, i, port_max = VTSS_PORTS;
    char               *s, *end;
    const char         *opt, *p;
    vtss_spi4_setup_t  *spi4;
    vtss_xaui_setup_t  *xaui;
    vtss_mapped_port_t *map;
    
    spi4 = &setup->spi4;
    xaui = &setup->xaui;
    
    /* Parse options */
    for (i = 2 ; i < argc; i++) {
        p = argv[i];
        opt = p;
        s = strstr(p, ":");
        val_error = 1;
        if (s != NULL) {
            s++;
            value = strtoul(s, &end, 0);
            val_error = (end == s);
        }
        error = 0;
        if (p[0] == 'h' && s != NULL) { /* host_mode */
            if (val_error || value > 9 || value == 2 || value == 7) {
                printf("Illegal host_mode: %s\n", s);
                return 0;
            }
            setup->host_mode = value;
        } else if (strstr(p, "sf") == p) /* sfp */
            sfp = 1;
        else if (p[0] == 'p' && val_error == 0 && value <= VTSS_PORTS) /* port_max */
            port_max = value;
        else if (strstr(p, "rx_") == p) {
            p += 3;
            if (p[0] == 's' && val_error == 0 && value <= 100) /* rx_share */
                setup->qs.rx_share = value;
            else if (p[0] == 'm' && s != NULL) /* rx_mode */
                setup->qs.rx_mode = (s[0] == 'p' ? VTSS_RX_MODE_PORT_FIFO :
                                     s[0] == 's' ? VTSS_RX_MODE_SHARED_DROP : 
                                     VTSS_RX_MODE_SHARED_LOSSLESS);
            else
                error = 1;
        } else if (strstr(p, "tx") == p) /* tx_mode */
            setup->qs.tx_mode = VTSS_TX_MODE_PORT_FIFO;
        else if (p[0] == 'q') {
            if (p[1] == '6')      /* q6_resv */
                setup->qs.resv_q6 = 1;
            else if (p[1] == '7') /* q7_resv */
                setup->qs.resv_q7 = 1;
            else
                error = 1;
        } else if (p[0] == 'm' && val_error == 0 && 
                   value >= VTSS_MAXFRAMELENGTH_STANDARD && value <= VTSS_MAXFRAMELENGTH_MAX)
            setup->qs.mtu = value; /* mtu */
        else if (strstr(p, "st") == p && val_error == 0 && value < 0xffff) /* stag_etype */
            setup->stag_etype = value;
        else if (strstr(p, "sc") == p && val_error == 0) /* sch_max_rate */
            setup->sch_max_rate = value;
        else if (strstr(p, "spi4_") == p) {
            p += 5;
            if (p[0] == 'f') /* spi4_flow */
                spi4->fc.enable = 0;
            else if (p[0] == '3') /* spi4_3lvl */
                spi4->fc.three_level_enable = 1;
            else if (p[0] == 'r' && val_error == 0) /* spi4_rate */
                spi4->qos.shaper.rate = value;
            else if (strstr(p, "ib_") == p) {
                p += 3;
                if (p[0] == 'f' && s != NULL && (s[0] == 'd' || s[0] == 'a')) /* spi4_ib_fcs */
                    spi4->ib.fcs = (s[0] == 'd' ? VTSS_SPI4_FCS_DISABLED : VTSS_SPI4_FCS_ADD);
                else if (p[0] == 'c' && val_error == 0) /* spi4_ib_clock */
                    spi4->ib.clock = (value == 290 ? VTSS_SPI4_CLOCK_250_TO_290 :
                                      value == 360 ? VTSS_SPI4_CLOCK_290_TO_360 :
                                      value == 450 ? VTSS_SPI4_CLOCK_360_TO_450 :
                                      VTSS_SPI4_CLOCK_450_TO_500);
                else if (p[0] == 's' && p[1] == 'w') /* spi4_ib_swap */
                    spi4->ib.data_swap = 1;
                else if (p[0] == 's' && p[1] == 'h') /* spi4_ib_shift */
                    spi4->ib.clock_shift = 1;
                else if (p[0] == 'i') /* spi4_ib_inv */
                    spi4->ib.data_invert = 1;
                else
                    error = 1;
            } else if (strstr(p, "ob_") == p) {
                p += 3;
                if (p[0] == 'f') /* spi4_ob_frame */
                    spi4->ob.frame_interleave = 1;
                else if (p[0] == 'h') /* spi4_ob_hih */
                    spi4->ob.hih_enable = 1;
                else if (p[0] == 'c' && val_error == 0) /* spi4_ob_clock */
                    spi4->ob.clock = (value == 250 ? VTSS_SPI4_CLOCK_250_0 :
                                      value == 312 ? VTSS_SPI4_CLOCK_312_5 :
                                      value == 375  ? VTSS_SPI4_CLOCK_375_0 :
                                      value == 437 ? VTSS_SPI4_CLOCK_437_5 :
                                      VTSS_SPI4_CLOCK_500_0);
                else if (p[0] == 'p' && val_error == 0) /* spi4_ob_phase */
                    spi4->ob.clock_phase = (value == 90 ? VTSS_SPI4_CLOCK_PHASE_90 :
                                            value == 180 ? VTSS_SPI4_CLOCK_PHASE_180 :
                                            value == 270 ? VTSS_SPI4_CLOCK_PHASE_270 :
                                            VTSS_SPI4_CLOCK_PHASE_0);
                else if (p[0] == 's' && p[1] == 'w') /* spi4_ob_swap */
                    spi4->ob.data_swap = 1;
                else if (p[0] == 's' && p[1] == 'h') /* spi4_ob_shift */
                    spi4->ob.clock_shift = 1;
                else if (p[0] == 'i') /* spi4_ob_inv */
                    spi4->ob.data_invert = 1;
                else if (p[0] == 'b' && val_error == 0) /* spi4_ob_burst */
                    spi4->ob.burst_size = (value == 64 ? VTSS_SPI4_BURST_64 :
                                           value == 96 ? VTSS_SPI4_BURST_96 :
                                           value == 160 ? VTSS_SPI4_BURST_160 :
                                           value == 192 ? VTSS_SPI4_BURST_192 :
                                           value == 224 ? VTSS_SPI4_BURST_224 :
                                           value == 256 ? VTSS_SPI4_BURST_256 :
                                           VTSS_SPI4_BURST_128);
                else if (strstr(p, "max_") == p && val_error == 0 && value < 256) {
                    if (p[4] == '1') /* spi4_ob_max_1 */
                        spi4->ob.max_burst_1 = value;
                    else if (p[4] == '2') /* spi4_ob_max_2 */
                        spi4->ob.max_burst_2 = value;
                    else
                        error = 1;
                } else if (p[0] == 'u' && val_error == 0 && value != 0 && value < 17) /* spi4_ob_up */
                    spi4->ob.link_up_limit = value;
                else if (p[0] == 'd' && val_error == 0 && value != 0 && value < 17) /* spi4_ob_down */
                    spi4->ob.link_down_limit = value;
                else if (p[0] == 't' && s != NULL) /* spi4_ob_train */
                    spi4->ob.training_mode = (s[0] == 'd' ? VTSS_SPI4_TRAINING_DISABLED :
                                              s[0] == 'f' ? VTSS_SPI4_TRAINING_FORCED :
                                              s[0] == 'n' ? VTSS_SPI4_TRAINING_NORMAL :
                                              VTSS_SPI4_TRAINING_AUTO);
                else if (p[0] == 'a' && val_error == 0 && value < 256) /* spi4_ob_alpha */
                    spi4->ob.alpha = value;
                else if (p[0] == 'd' && val_error == 0 && value <= 131000) /* spi4_ob_data */
                    spi4->ob.data_max_t = value;
                else
                    error = 1;
            } else
                error = 1;
        } else if (strstr(p, "xaui_") == p) {
            p += 5;
            if (p[0] == 'f') /* xaui_flow */
                xaui->fc.channel_enable = 1;
            else if (p[0] == '3') /* xaui_3lvl */
                xaui->fc.three_level_enable = 1;
            else if (p[0] == 'r' && val_error == 0) /* xaui_rate */
                xaui->qos.shaper.rate = value;
            else if (p[0] == 'p') /* xaui_pause */
                xaui->fc.obey_pause = 1;
            else if (strstr(p, "hih_") == p) {
                p += 4;
                if (p[0] == 'p') /* xaui_hih_pre */
                    xaui->hih.format = VTSS_HIH_PRE_SFD;
                else if (p[0] == 'c') /* xaui_hih_chk */
                    xaui->hih.cksum_enable = 1;
                else
                    error = 1;
            } else if (p[0] == 'i') /* xaui_ib_shift */
                xaui->ib.clock_shift = 1;
            else if (p[0] == 'o') /* xaui_ob_shift */
                xaui->ob.clock_shift = 1;
            else
                error = 1;
        } else
            error = 1;
        if (error) {
            printf("Illegal parameter or missing/illegal value: %s\n", opt);
            return 0;
        }
    }
    
    /* Apply options */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        map = &board_port_map[port_no];
        if (port_no < 3 && setup->host_mode > 4) {
            /* Port 1 and 2 are XAUI line ports */
            map->chip_port = (24 + port_no - VTSS_PORT_NO_START);
            map->miim_controller = VTSS_MIIM_CONTROLLER_1;
            map->phy_addr = map->chip_port;
        }
        if (port_no > 2 && setup->host_mode > 5) {
            /* Port 3-24 are unused */
            map->chip_port = -1;
            map->miim_controller = VTSS_MIIM_CONTROLLER_NONE;
        }
        if (port_no > 16 && sfp) {                
            /* Port 17-20 are SFP and port 21-24 are unused */
            if (port_no > 20)
                map->chip_port = -1;
            map->miim_controller = VTSS_MIIM_CONTROLLER_NONE;
        }
        if (port_no > port_max) 
            map->chip_port = -1;
    }
    b2_init_setup = *setup;
    printf("Initializing chip, host mode: %u\n", setup->host_mode);
    return 1;
}

static void
board_init_setup_hook(int argc, const char **argv, vtss_init_setup_t *setup)
{
    if (vtss_b2_parse_options(argc, argv, setup) == 0)
        exit(1);
}

static void
board_connect(int argc, const char **argv, vtss_io_state_t *io)
{
    if (vtss_b2_connect(argc, argv, io) == 0)
        exit(1);
    board_cpu_if_init(io);
}

void vtss_board_hookup(struct vtss_board *board, int argc, const char **argv)
{
    board->name = "Barrington-II";
    board->port_map = board_port_map;
    board->connect = board_connect;
    board->init_setup_hook = board_init_setup_hook;
    board->port_mac_interface = board_port_mac_interface;
}

/* Misc Board-specific API's */

vtss_rc vtss_appl_init_setup_get(vtss_init_setup_t * const setup)
{
    *setup = b2_init_setup;
    return VTSS_OK;
}

#if defined(BOARD_B2_EVAL)
/* Execute Rabbit direct read/write command */
vtss_rc vtss_rabbit_rd_wr_fpga(ulong addr, ulong *value, BOOL read)
{
    char  cmd[64], data[9];
    
    if (read)
        data[0] = '\0';
    else
        sprintf(data, "%08lx", *value);
    sprintf(cmd, "%s%08lx%s%s", 
            read ? "WPRP 0x2018 0x" : "WP 0x2000 0x", 
            0x80000000 + addr, 
            data, 
            read ? "03" : "02");

    return vtss_rabbit_cmd(cmd, value);
}
#endif /* BOARD_B2_EVAL */
