/*
 
 Vitesse Switch Software.
 
 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/
#ifndef VTSS_FDMA_VAL_H
#define VTSS_FDMA_VAL_H

#include <luton28_vcore2_regs.h> /* For VTSS_* registers */
#include <mmu_cache.h> /* For MMU and DCache operations */

typedef unsigned char u8;
typedef unsigned long u32;

#define VTSS_FDMA_IRQ 6
#define VTSS_FDMA_KEEP_STATISTICS

// This file defines support functions for the FDMA when run under validation.
#define vtss_fdma_raw_readl(a)     ((u32)(a))
#define vtss_fdma_raw_writel(a, v) ((a)=(v))

extern int dbg_msk;

#ifndef VTSS_FDMA_DBG
  #error VTSS_FDMA_DBG must be defined for validation testcases!
#endif

// Assert and debug print functions
#ifdef VTSS_FDMA_DBG
  #define VTSS_FDMA_DBG_MSG(lvl, format, args...) /* We don't support debug messages in validation (the UART is not enabled) */
  #define VTSS_FDMA_ASSERT(expr) {\
    if (!(expr))\
      vtss_exit(__LINE__);\
  }
  #define VTSS_FDMA_ASSERT_MSG(expr, format, args...) {if(!(expr)) VTSS_FDMA_ASSERT(expr)}
#else
  #define VTSS_FDMA_DBG_MSG(lvl, format, args...)
  #define VTSS_FDMA_ASSERT(expr)
  #define VTSS_FDMA_DBG_MSG(lvl, format, args...)
#endif

#define VTSS_FDMA_VIRT_TO_PHYS(addr) ((u32)(addr))

#ifdef VTSS_FDMA_USING_MMU
  #define VTSS_FDMA_INVALIDATE_DCACHE_DCB(virt_addr, size)  dcache_invalidate_range((void *)(virt_addr), (size))
  #define VTSS_FDMA_INVALIDATE_DCACHE_DATA(virt_addr, size) dcache_invalidate_range((void *)(virt_addr), (size))
  #define VTSS_FDMA_FLUSH_DCACHE_DCB(virt_addr, size)       dcache_clean_range((void *)(virt_addr), (size))
  #define VTSS_FDMA_FLUSH_DCACHE_DATA(virt_addr, size)      dcache_clean_range((void *)(virt_addr), (size))
#else
  #define VTSS_FDMA_INVALIDATE_DCACHE_DCB(virt_addr, size)
  #define VTSS_FDMA_INVALIDATE_DCACHE_DATA(virt_addr, size)
  #define VTSS_FDMA_FLUSH_DCACHE_DCB(virt_addr, size)
  #define VTSS_FDMA_FLUSH_DCACHE_DATA(virt_addr, size)
#endif

#define VTSS_FDMA_INTERRUPT_FLAGS unsigned long
#define VTSS_FDMA_DISABLE_INTERRUPTS(flags) {(flags)=intr_dis(itIRQ);}
#define VTSS_FDMA_RESTORE_INTERRUPTS(flags) {intr_restore_flags((flags));}
#define VTSS_FDMA_BARRIER()
#define VTSS_FDMA_MEMSET(s, c, n) vtss_memset((s),(c),(n))

// Return codes needed by FDMA code.
#define VTSS_FDMA_ENOBUFS     -2
#define VTSS_FDMA_NOERR        0
#define VTSS_FDMA_GNRL_ERR    -3

#endif // VTSS_FDMA_VAL_H
/*****************************************************************************/
//
// End of file
//
//****************************************************************************/
