Q: What's in here?
A: Source code for the OS-independent FDMA driver for SparX-G28 (fdma.c) and OS-specific front-ends (fdma_<OS>.c)

Q: What OSs are supported?
A: Linux, eCos, and 'val' ('val' stands for 'validation'. During validation of the chip, no OS is used, so one could
   see 'val' as an OS-dependent extension to the driver, where DCBs and data is statically allocated).

Q: How does this work with Linux?
A: The linux .config file must have CONFIG_VTSS_FDMA defined in order to incorporate the driver into the kernel.
   The file $(LINUX)/drivers/net/vtss_fdma_placeholder.c includes the fdma_linux.c file from this folder.

Q: How does this work with eCos?
A: 


Q: How does this work with 'val'?
A:
