/*
 
 Vitesse Switch Software.
 
 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/
/*****************************************************************************/
// This file holds the API for the Frame DMA driver kit.
/*****************************************************************************/
#ifndef VTSS_FDMA_API_H
#define VTSS_FDMA_API_H

/*****************************************************************************/
// FDMA Driver Kit API.
//
// ###########################################################################
// #                    FREQUENTLY ASKED QUESTIONS                           #
// ###########################################################################
//
// Q: Is the FDMA Driver Kit OS-dependent?
// A: The FDMA Driver Kit is not 100% OS-independent, but you don't need to
//    modify the driver code itself in order to get it to work under a certain
//    OS. vtss_fdma.c includes a file, vtss_fdma_os.h, which branches on the
//    various OSs and includes the correct OS-specific file, which is assumed
//    to implement the macros needed by the FDMA driver code.
//    The required macros are described further down in this file.
//
// ------------------------------------oOo------------------------------------
//
// Q: What CPUs does the FDMA work with?
// A: The FDMA Driver Kit *must* execute on the embedded ARM processor, since
//    an external CPU doesn't have access to the FDMA silicon.
//
// ------------------------------------oOo------------------------------------
//
// Q: Can the FDMA be used in parallel with "manual" frame transmission or
//    reception?
// A: It is not recommended to use the FDMA together with "manual" frame
//    transmission or reception (manual refers to the fact that the CPU spends
//    clock cycles to read or write every single byte to the relevant registers
//    within the switch core). However, for frame transmission, it is possible
//    to have the FDMA working on one set of front ports and the manual
//    transmission working on another set. For frame reception, it is possible
//    to have the FDMA extract from one set of the extraction queues, and have
//    the manual reception working on another set. The sets must be disjunct.
//
// ------------------------------------oOo------------------------------------
// 
// Q: Are any of the API functions blocking?
// A: No, none of the functions are blocking. When an API function needs
//    exclusive access to a global variable, it uses a macro,
//    VTSS_FDMA_DISABLE_INTERRUPTS(), to ask for OS-specific support to
//    globally disable interrupts. On many OSs it is, however, not needed to
//    globally disable interrupts, as we shall see later. Please refer to the
//    relevant macro descriptions below.
//
// ------------------------------------oOo------------------------------------
//
// Q: Why don't most of the API functions return error/success codes?
// A: Because most of the API functions rely on the correct behavior by the
//    caller of the API functions. Once all bugs are removed from the code,
//    there is no need for the upper layers to check for success/failure and
//    waste CPU time on that. All parameters passed to the API functions are
//    instead checked by using assertions, which means that it is very
//    important - at least in pre-production - to enable the VTSS_FDMA_ASSERT()
//    macro in the OS-specific header file to do something useful, like
//    printing an error message on the console and halt the CPU if the
//    assertion fails. In production the VTSS_FDMA_ASSERT() macro may be mapped
//    to doing nothing
//
// ------------------------------------oOo------------------------------------
//
// Q: Who allocates memory?
// A: The API is built in such a way that it is up to the caller to allocate
//    and free memory. Some may wish to allocate all the buffers needed by the
//    FDMA statically, while others may want to allocate it dynamically. If
//    the FDMA code was to implement code for all possible scenaria, it would
//    not be as flexible as it is as of today.
//
// ###########################################################################
// #                        TERMS AND ABBREVIATIONS                          #
// ###########################################################################
//
// Extraction:
//   This term is used by the FDMA silicon and driver kit and is equivalent to
//   what higher levels of software would call Rx, i.e. packet reception.
//   Extraction is abbreviated XTR.
//
// Injection:
//   This term is used by the FDMA silicon and driver kit and is equivalent to
//   what higher levels of software would call Tx, i.e. packet transmission.
//   Injection is abbreviated INJ.
//
// Packet Module:
//   The software module that implements all the calls to the FDMA API.
// 
// Call context:
//   The context that a function must be called in. In a multithreaded
//   environment this could be "thread" or "DSR".
//
// Re-entrancy:
//   Some of the functions are allowed to be called simultaneously from
//   several threads.
//
// DSR:
//   Deferred Service Routine. This is the term that eCos uses for the
//   context that is scheduled by an IRQ handler. The context is assumed
//   to be interruptible only by another hardware interrupt, i.e.
//   the scheduler cannot schedule other DSRs or threads while a DSR
//   is running. In Linux, this is known as the "bottom half". A DSR can
//   never wait for critical sections or semaphores or the like.
//
// DCB:
//   In the FDMA driver context, a DCB is normally a software DCB, i.e.
//   an instance of the vtss_fdma_list_head_t structure. Each software DCB
//   embeds a hardware DCB, which is filled by the FDMA driver code and
//   passed to the FDMA silicon, i.e. the higher levels of software need
//   not be concerned about hardware DCBs, but they need to allocate room
//   for them, which is therefore done in the software DCB. The same software
//   DCB type is used for injection and extraction, but some of the fields'
//   meaning differ for the two. Please refer to the vtss_fdma_list_head_t
//   structure for the exact interpretation and Packet Module requirements
//   for the DCBs.
//
// SOF DCB:
//   Start-Of-Frame DCB. The first (software or hardware) DCB in a list of
//   DCBs making up one frame. The list is at least 1 item long.
//
// EOF DCB:
//   End-Of-Frame DCB. The last (software or hardware) DCB in a list of DCBs
//   making up one frame. The list is at least 1 item long, so the EOF DCB
//   may be identical to the SOF DCB.
//
// Non-SOF DCBs:
//   All but the first DCB in a list of (software or hardware) DCBs making up
//   one frame.
//
// Extraction Queue:
//   The chip contains a number of queues for temporarily storing frames destined
//   for the CPU. These so-called extraction queues are of configurable length
//   and are located in the CPU Port Module. They share memory with the CPU
//   Port Module's injection queue. The splitting of memory between the queues
//   is not handled by the FDMA driver code. Likewise, the assignment of a
//   particular type of frames to an extraction queue (which typically takes
//   place in the chip's analyzer (ANA) is not done by the FDMA driver code.
//   The valid range of extraction queue numbers is [0; VTSS_FDMA_XTR_QU_CNT[.
//
// DMA Channel:
//   A DMA channel is used per flow. For extraction each extraction queue
//   is statically mapped to a DMA channel through the call to vtss_fdma_xtr_cfg().
//   For injection, there is no static mapping between a channel number and a
//   front port number, but a channel must still be assigned for injection.
//   Valid channel numbers are in the range [0; VTSS_FDMA_CH_CNT[.
//   An intrinsic priority exists among the channels, in that higher-numbered
//   channels have higher priority. Thus, if two channels serve two different
//   extraction queues, and both report frames present, then the higher numbered
//   channel (which is not necessarily the higher numbered extraction queue!)
//   will get serviced first.
//
// ###########################################################################
// #              LAYOUT OF INJECTED AND EXTRACTED FRAMES.                   #
// ###########################################################################
// Injection:
//   When injecting a frame, the SOF DCB's data pointer must point to an
//   area of 12 bytes (VTSS_FDMA_IFH_SIZE_BYTES + VTSS_FDMA_CMD_SIZE_BYTES),
//   which is reserved by the FDMA. Byte number 13 is therefore the first
//   byte of the frame's DMAC.
//
// Extraction:
//   When an extracted frame is delivered to the callback function, the first
//   8 bytes (VTSS_FDMA_IFH_SIZE_BYTES) of the SOF DCB's data area contain
//   the frame's IFH. Byte number 9 (if the channel's gap is configured to 0)
//   contains the first byte of the DMAC.
//
// ###########################################################################
// #    OS- OR IMPLEMENTATION-SPECIFIC MACROS IMPLEMENTED BY USER OF FDMA    #
// ###########################################################################
// As described in the FAQ above, a number of macros, typedefs, and defines
// must be implemented in an OS-specific header file.
// These are described in details below:
// 
// VTSS_FDMA_STACK_PORT_A_MASK 
// VTSS_FDMA_STACK_PORT_B_MASK:
//   These are implementation specific defines, in that two different imple-
//   mentations don't need to aggregate the same two stack ports to form an
//   aggregation in the same direction, or even aggregate ports in the first
//   place to create a stack link. The VTSS_FDMA_STACK_PORT_x_MASK is a 32-bit
//   number with a 1 placed in those positions that form a stack for direction
//   x. The bit-positions correspond to physical port numbers.
//   If e.g. physcal ports 24 and 25 form stack link A, then
//   VTSS_FDMA_STACK_PORT_A_MASK should be 0x03000000.
//
// vtss_fdma_raw_writel(a, v):
//   Implements the actual write to the absolute address, a, of 32-bit value
//   v. The value is corrected for endianness already. The function allows for
//   an OS-specific layout of memory, so that the absolute address, a, can be
//   converted to a virtual before being written. In systems with flat memory
//   layout, this could simply be defined as ((a) = (v)).
//
// vtss_fdma_raw_readl(a):
//   This function should return the 32-bit value as read from physical
//   address a. The value should not be corrected for endianness, since this
//   is done at a later stage if needed. The function allows for an OS-
//   specific layout of memory, so that the absolute address, a, can be
//   converted to a virtual before it is read. In system with flat memory
//   layout, this could simply be defined as (a).
//
// VTSS_FDMA_DBG:
//   If defined, more run-time checks are added to the FDMA driver code.
//   Specifically these are:
//     a) when vtss_fdma_inj() is called, it is checked that the sum of
//        all S/W DCB lengths match the total frame size as passed to the
//        function.
//     b) After a frame has been injected, it is tested that the FDMA engine
//        has set the H/W DCB's DONE bit.
//     c) On extraction, it is tested that the frame size indicated in the
//        frame's IFH matches the total frame size as reported by the FDMA
//        engine.
//   All these checks result in a call to VTSS_FDMA_ASSERT(), which therefore
//   should be defined as non-empty if VTSS_FDMA_DBG is defined. If not,
//   there's no point in defining VTSS_FDMA_DBG.
//
// VTSS_FDMA_ASSERT(expr):
//   Define this macro to non-empty if you want to enable FDMA run-time checks.
//   It should work as follows: If expr evaluates to FALSE, an error has
//   occurred within the driver code, and the OS-specific part can take proper
//   action like printing an error message to the console and halt the CPU.
//   It is highly recommended to enable this in a pre-production environment,
//   and since it poses some overhead to the final executable (both in size and
//   runtime time consumption), it can be defined as empty in a production
//   environment.
//
// VTSS_FDMA_DBG_MSG(lvl, format, args...):
//   Allows for run-time debug messages, which could end up on the console.
//   The first argument, lvl, is either of the VTSS_FDMA_DBG_xxx masks defined
//   below. This allows the user to mask out printing of messages related to
//   certain parts of the FDMA driver code. The remaining arguments follow the
//   normal printf() syntax.
//   In a production environment this macro can be empty.
//
// VTSS_FDMA_ASSERT_MSG(expr, format, args...):
//   This is an extension to the VTSS_FDMA_ASSERT() macro. Besides the expr
//   argument, it allows the FDMA driver code to output additional information
//   of why an assertion failed. The format and args arguments follow the
//   normal printf() syntax.
//
// VTSS_FDMA_VIRT_TO_PHYS(a):
//   Macro that implements the conversion from a virtual to a physical address.
//   In OSs with a flat memory layout, this could be as simple as (u32)(addr).
//
// u8, u16, u32:
//   Typedefs of unsigned 8, 16, and 32-bit integers, respectively.
//
// VTSS_FDMA_INVALIDATE_DCACHE_DCB(virt_addr, size)
// VTSS_FDMA_INVALIDATE_DCACHE_DATA(virt_addr, size):
//   If the data cache is enabled, it is crucial that the FDMA driver code has
//   access to cache invalidation functions, so that higher layers of S/W
//   correctly reads the frames extracted by the FDMA. For debugging purposes
//   the driver code uses two cache invalidation macros, one for DCB and one
//   for data invalidation. In reality, these two should map to the same
//   cache invalidation function, which is normally supplied by the relevant
//   OS.
//
// VTSS_FDMA_FLUSH_DCACHE_DCB(virt_addr, size)
// VTSS_FDMA_FLUSH_DCACHE_DATA(virt_addr, size):
//   If the data cache is enabled, it is crucial the the FDMA driver code has
//   accdess to cache flush functions so that the frame data written by higher
//   layers of S/W is indeed flushed to external DDR SDRAM before enabling
//   the FDMA engine. For debugging purposes the driver code uses two cache
//   flush macros, one for DCB and one for data flushing. In reality, these
//   two should map to the same cache flush function, which is normally
//   supplied by the relevant OS.
//
// VTSS_FDMA_INTERRUPT_FLAGS
// VTSS_FDMA_DISABLE_INTERRUPTS(flags)
// VTSS_FDMA_RESTORE_INTERRUPTS(flags)
//   These three macros implement the functions that ensure mutual exclusion
//   when accessing certain FDMA registers and software structures. They are
//   only called from functions called from thread context, i.e. none of them
//   are used in the vtss_fdma_irq_handler(). 
//   The VTSS_FDMA_INTERRUPT_FLAGS macro define the type used to hold the
//   flags that are passed in the calls to VTSS_FDMA_DISABLE_INTERRUPTS()
//   and VTSS_FDMA_RESTORE_INTERRUPTS(). On most OSs these are just an 
//   unsigned int. The FDMA driver code calls VTSS_FDMA_DISABLE_INTERRUPTS()
//   when no other FDMA API functions or the vtss_fdma_irq_handler() may
//   be invoked and VTSS_FDMA_RESTORE_INTERRUPTS() when these functions are
//   allowed to be called again. The actual implementation is OS-specific and
//   depends on how the vtss_fdma_irq_handler() is called. If e.g. that handler
//   is called in DSR context, then VTSS_FDMA_DISABLE_INTERRUPTS() may be
//   implemented by a call to a scheduler lock function, because that ensures
//   that neither the vtss_fdma_irq_handler() nor any other API functions
//   may be called. If, instead, vtss_fdma_irq_handler() is called directly
//   as the result of an FDMA interrupt, then VTSS_FDMA_DISABLE_INTERRUPTS()
//   must actually disable hardware interrupts, at least from the FDMA, and
//   also disable the scheduler, so that task switches cannot take place
//   while executing the mutual exclusive piece of code. The flags parameter
//   can be used to assign the current value of the interrupt flags in the
//   call to VTSS_FDMA_DISABLE_INTERRUPTS(), and restore the old value of
//   the interrupt flags at the call to VTSS_FDMA_RESTORE_INTERRUPTS().
//
// VTSS_FDMA_BARRIER():
//   The compiler may swap instructions to optimize performance of the final
//   code (size- or speed-wise). When configuration of hardware is involved,
//   it may not always be valid to swap two statements. Consider for instance
//   the following two writes to two FDMA registers:
//      Write the source address to the FDMA
//      Enable the FDMA.
//   To the compiler, these two writes can be executed in any order and still
//   semantically yield the correct result, had it been normal RAM they were
//   written to. But since they are written to actual hardware, it is crucial
//   that they are executed in the correct order.
//   The VTSS_FDMA_BARRIER() macro should implement code that ensures that the
//   compiler doesn't optimize across the barrier. Normally a single function
//   call to a dummy function ensures this. In most OSs a similar function
//   exists. On eCos, for example, the HAL_REORDER_BARRIER() macro does the
//   exact same thing.
//
// VTSS_FDMA_MEMSET(s, c, n):
//   This function should normally just map to the OS's memset() function.
//   If no such function exist on the particular OS, it can be assumed that
//   the s is always 32-bit aligned, and that n is always a multiple of 4
//   bytes.
//
// VTSS_FDMA_BIG_ENDIAN:
//   The driver code is made such that it supports the ARM CPU to be executing
//   in both little and big endian. Default is little endian. Big endian is
//   enabled by defining VTSS_FDMA_BIG_ENDIAN. It is only used by the functions
//   that read or write actual hardware registers. These functions are defined
//   in vtss_fdma.h, which performs the required swapping of data before
//   calling the aforementioned vtss_fdma_raw_writel() and after calling the
//   aforementioned vtss_fdma_raw_readl() functions.
//
// VTSS_FDMA_KEEP_STATISTICS:
//   Define this if you want the FDMA to count frames and bytes at run-time.
//   When defined, the vtss_fdma_get_stats() returns meaningful counts.
/*****************************************************************************/

/*****************************************************************************/
// Debug masks. 
// Used as first argument in calls to the VTSS_FDMA_DBG_MSG() macro.
// The masks allow for masking in and out certain messages.
/*****************************************************************************/
#define VTSS_FDMA_DBG_XTR_SPARSE   0x0001
#define VTSS_FDMA_DBG_INJ_SPARSE   0x0002
#define VTSS_FDMA_DBG_GNRL_SPARSE  0x0004
#define VTSS_FDMA_DBG_XTR_VERBOSE  0x0008
#define VTSS_FDMA_DBG_INJ_VERBOSE  0x0010
#define VTSS_FDMA_DBG_GNRL_VERBOSE 0x0020

/*****************************************************************************/
// Fundamental constants, pertinent to EStaX34.
/*****************************************************************************/
#define VTSS_FDMA_XTR_QU_CNT       4 /* Number of CPU Port Module Extraction Queues                                 */
#define VTSS_FDMA_CH_CNT           8 /* Number of DMA Channels                                                      */
#define VTSS_PHYS_PORT_CNT        28 /* Number of Port Modules, excluding CPU Port Module                           */
#define VTSS_TOTAL_PORT_CNT       29 /* Number of Port Modules, including CPU Port Module                           */
#define VTSS_CPU_PM_NUMBER        28 /* The physical port number of the CPU Port Module                             */
#define VTSS_ALL_PM_NUMBER        31 /* Writes to this phys. port number causes all front ports to receive the data */
#define VTSS_FDMA_DCB_SIZE_BYTES  28 /* Number of bytes in a DCB                                                    */
#define VTSS_FDMA_IFH_SIZE_BYTES   8 /* Number of bytes in the Internal Frame Header                                */
#define VTSS_FDMA_CMD_SIZE_BYTES   4 /* Number of bytes in the Command field, used when injecting frames.           */

/*****************************************************************************/
// Unfortunately, there are a few bugs in the FDMA silicon. These are cir-
// cumvented in S/W, unless the relevant VTSS_FDMA_IGNORE_GNATS_xxxx
// are defined (The xxxx refers to a number in Vitesse's internal bug-tracking
// system, GNATS).
// The main-purpose for having these in the code is to be able to ignore the
// GNATS to provoke the error during testing. Normally these should *not* be
// defined when compiling vtss_fdma.c.
//
// VTSS_FDMA_IGNORE_GNATS_5299:
//   When receiving a frame and the frame uses one single DCB, and the DCB's
//   data area is X bytes, and the frame size is in the interval [X-3; X],
//   then the DCB's SOF flag is not set by the FDMA silicon. By defining
//   this, the FDMA driver code will check for the SOF flag and assert that
//   it is set when expecting a SOF.
// 
// VTSS_FDMA_IGNORE_GNATS_5355:
//   This GNATS states that the sizeof(non-EOFs' data area) must be a multiple
//   of 4. This is relevant to injection only, and means that if a frame is
//   split across several DCBs, then all but the last DCB's data area must have
//   a size that is a multiple of 4. Define this if you want to allow user-
//   code to inject invalid-sized DCBs.
// 
// VTSS_FDMA_IGNORE_GNATS_5376:
//   This GNATS states that the minimum size of the SOF DCB's data area must
//   be sizeof(IFH+CMD)+1 byte. This is relevant to injection only, and means
//   that if a frame is split across several DCBs, then the first DCB's data
//   area's size must be at least IFH+CMD+1 byte large. Define this if you
//   want to allow user-code to inject invalid-sized SOF DCB data areas.
//
// VTSS_FDMA_IGNORE_GNATS_5418
//   When transmitting a frame from the CPU port module using the DO_ANALYZE
//   flag, then the frame is looped back to the CPU, even if the ANA::SRCMASKS[CPU_PM]
//   doesn't include the CPU Port Module itself. So to avoid frames from being
//   looped back to the application, this should *not* be defined. In that
//   case, the FDMA driver code will check if the frame was transmitted from
//   the CPU itself (it checks the IFH's source port field), and count and
//   discard it if so. Define this, if you don't want the driver code to do
//   this check.
/*****************************************************************************/

/*****************************************************************************/
// That being said, we can now define the minimum sizes of the data area
// associated with a SOF and non-SOF DCBs for extraction and injection.
//
// VTSS_FDMA_MIN_DATA_PER_INJ_SOF_DCB_BYTES:
//   Defines the minimum size in bytes of an injection SOF-DCB's associated
//   data area.
//
// VTSS_FDMA_MIN_DATA_PER_XTR_SOF_DCB_BYTES:
//   Defines the minimum size in bytes of an extraction SOF-DCB's associated
//   data area. Since every DCB can become a SOF DCB, this value also defines
//   the minimum size that the user must allocate per DCB.
//
// VTSS_FDMA_MIN_DATA_PER_NON_SOF_DCB_BYTES:
//   Defines the minimum size in bytes of an injection/extraction non-SOF-
//   DCB's associated data area.
//
// VTSS_FDMA_MAX_DATA_PER_DCB_BYTES:
//   For both injection and extraction, the maximum number of bytes that
//   one single DCB's associated data area can refer to. If you need to
//   inject or extract larger frames, use multiple DCBs.
//
// VTSS_FDMA_MIN_FRAME_SIZE_BYTES:
//   The minimum allowed frame size (excluding IFH and CMD fields) in bytes.
//
// VTSS_FDMA_MAX_FRAME_SIZE_BYTES:
//   The maximum allowed total frame size (excluding IFH and CMD fields) in
//   bytes.
/*****************************************************************************/
#if defined(VTSS_FDMA_IGNORE_GNATS_5376)
  #define VTSS_FDMA_MIN_DATA_PER_INJ_SOF_DCB_BYTES (VTSS_FDMA_IFH_SIZE_BYTES + VTSS_FDMA_CMD_SIZE_BYTES)
#elif defined(VTSS_FDMA_IGNORE_GNATS_5355)
  #define VTSS_FDMA_MIN_DATA_PER_INJ_SOF_DCB_BYTES (VTSS_FDMA_IFH_SIZE_BYTES + VTSS_FDMA_CMD_SIZE_BYTES + 1)
#else
  #define VTSS_FDMA_MIN_DATA_PER_INJ_SOF_DCB_BYTES (VTSS_FDMA_IFH_SIZE_BYTES + VTSS_FDMA_CMD_SIZE_BYTES + 4) /* This is the working case with EStax34 */
#endif
#define VTSS_FDMA_MIN_DATA_PER_XTR_SOF_DCB_BYTES  VTSS_FDMA_IFH_SIZE_BYTES
#define VTSS_FDMA_MIN_DATA_PER_NON_SOF_DCB_BYTES    1
#define VTSS_FDMA_MAX_DATA_PER_DCB_BYTES         4092
#define VTSS_FDMA_MIN_FRAME_SIZE_BYTES             64
#define VTSS_FDMA_MAX_FRAME_SIZE_BYTES          10000

/*****************************************************************************/
// The following define the stack port numbers used to identify whether
// the IFH's stack_info.stack_link_a or stack_info.stack_link_b bit
// should be set on injection to a front port.
// The #ifndefs are added if an application aggregates or dubs
// the port numbers differently from how the FDMA dubs them by default.
// They are only used if vtss_fdma_inj() is called with the
// VTSS_FDMA_INJ_OPT_STACK_HDR option.
/*****************************************************************************/
#ifndef VTSS_FDMA_STACK_PORT_A_MASK
  // Physical ports 24 and 25
  #define VTSS_FDMA_STACK_PORT_A_MASK (0x03000000)
#endif
#ifndef VTSS_FDMA_STACK_PORT_B_MASK
  // Physical ports 26 and 27
  #define VTSS_FDMA_STACK_PORT_B_MASK (0x0c000000)
#endif

/*****************************************************************************/
// When injecting frames directly to a front port (i.e. not using the CPU Port
// Module), the FDMA silicon must insert waits between data writes to the queue.
// These waits are defined by VTSS_FDMA_INJ_WR_DELAY_1G_PORTS, which is
// the time to wait for 1Gbps front ports, and VTSS_FDMA_INJ_WR_DELAY_2_5G_PORTS,
// which is the time to wait for 2.5Gbps front ports. These values are written
// to the CFG.FDMA_INJ_CFG[ch].INJ_WR_DELAY register prior to each frame
// injection (if the destination port changes).
//
// The default values assigned below allows for full traffic on the 1Gbps front
// ports without injection failing (unless the front port is in flow control
// mode and the super priority queue is full). Unfortunately there is a bug
// in the FDMA silicon that causes frame injection to fail on the 2.5Gbps
// ports if the port is fully loaded with other traffic while the FDMA is
// injecting frames to it. The highest possible value to write to the
// INJ_WR_DELAY register is not high enough to accommodate the value that should
// have been written. This means that injection to the 2.5Gbps front ports may
// have to be done manually (see also vtss_fdma_set_tx_flow_ctrl_cfg()).
// 
// The following #ifndefs allows user-code to override these constants before
// compiling vtss_fdma.c.
/*****************************************************************************/
#ifndef VTSS_FDMA_INJ_WR_DELAY_1G_PORTS
  #define VTSS_FDMA_INJ_WR_DELAY_1G_PORTS 24
#endif
#ifndef VTSS_FDMA_INJ_WR_DELAY_2_5G_PORTS
  #define VTSS_FDMA_INJ_WR_DELAY_2_5G_PORTS 31
#endif

/*****************************************************************************/
// Position of various fields in the IFH.
/*****************************************************************************/
#define VTSS_FDMA_IFH_F_STACK_HDR_FPOS    63
#define VTSS_FDMA_IFH_F_LEN_FPOS          48
#define VTSS_FDMA_IFH_F_SRC_PORT_FPOS     42
#define VTSS_FDMA_IFH_F_UPRIO_FPOS        29
#define VTSS_FDMA_IFH_F_CFI_FPOS          28
#define VTSS_FDMA_IFH_F_VID_FPOS          16
#define VTSS_FDMA_IFH_F_STACK_LINK_B_FPOS 14
#define VTSS_FDMA_IFH_F_STACK_LINK_A_FPOS 13
#define VTSS_FDMA_IFH_F_AGGR_CODE_FPOS    10 /* Can only be used if sending frame via CPU PM and switching it */
#define VTSS_FDMA_IFH_F_FRM_TYPE_FPOS      6
#define VTSS_FDMA_IFH_F_LEARN_FPOS         4
#define VTSS_FDMA_IFH_F_XTR_QU_FPOS        2
#define VTSS_FDMA_IFH_F_QOS_FPOS           0

/*****************************************************************************/
// Length of various fields in the IFH
/*****************************************************************************/
#define VTSS_FDMA_IFH_F_SRC_PORT_FLEN      5
#define VTSS_FDMA_IFH_F_UPRIO_FLEN         3
#define VTSS_FDMA_IFH_F_CFI_FLEN           1
#define VTSS_FDMA_IFH_F_VID_FLEN          12
#define VTSS_FDMA_IFH_F_FRM_TYPE_FLEN      3
#define VTSS_FDMA_IFH_F_LEARN_FLEN         1
#define VTSS_FDMA_IFH_F_XTR_QU_FLEN        2

/*****************************************************************************/
// Register definitions exposed to the public, so that they can use them for
// manual injection, if needed.
/*****************************************************************************/
// First a few macros needed to be able to define the real register addresses.
// Offset of SwC register space
#define VTSS_TB_SWC 0xA0000000
#define BLK_SUBBLK_ADDR(b,s,a) ((b<<14) | (s<<10) | (a<<2))
#define DEV_TO_B(dev) ((dev)<16?1:6)
#define DEV_TO_S(dev) ((dev)<16?(dev):((dev)-16))

// Register addresses that can be used when performing manual frame injection.
#define VTSS_DEV_CPUTXDAT(dev) VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0xC0))
#define VTSS_DEV_MISCFIFO(dev) VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0xC4))
#define VTSS_DEV_MISCSTAT(dev) VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0xC8))

// DEV::MISCSSTAT fields
#define VTSS_F_MISCSTAT_CPU_TX_QUEUE_FULL    VTSS_BIT(9)
#define VTSS_F_MISCSTAT_CPU_TX_DATA_PENDING  VTSS_BIT(8)
#define VTSS_F_MISCSTAT_CPU_TX_DATA_OVERFLOW VTSS_BIT(7)

// DEV::MISCFIFO fields
#define VTSS_F_MISCFIFO_CLEAR_STICKY_BITS VTSS_BIT(2)
#define VTSS_F_MISCFIFO_REWIND_CPU_TX     VTSS_BIT(1)
#define VTSS_F_MISCFIFO_CPU_TX            VTSS_BIT(0)

// Registers for reading out CPU Port Module counters.
#define VTSS_DEV_C_CNTDATA(dev)           VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0xDC)) /* a.k.a. Q_DBGDATA */
#define VTSS_DEV_C_CNTADDR(dev)           VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0xDD)) /* a.k.a. Q_DBGADDR */

/*****************************************************************************/
// The following structure defines a software DCB. Software DCBs can be linked
// together to form a list of software DCBs. This is the fundamental data
// structure used to transfer information between a user-level application and
// the FDMA driver code.
// 
// The structure holds the actual hardware DCB needed by the FDMA silicon,
// a pointer to the associated data area, and other properties such as frame
// length and allocation length.
//
// The structure is used for both injection and extraction, but some of its
// members' meaning change slightly in the two cases. The exact interpretation
// is shown as comments inside the definition below.
/*****************************************************************************/
typedef struct tag_vtss_fdma_list_head
{
  // XTR/INJ: Reserved by vtss_fdma.c. The FDMA itself only requires this field to be 4-byte aligned, but
  //          if the dcache is enabled, it's safe to have it cache-line aligned, i.e. 32-byte aligned,
  //          especially if you allocate an array of vtss_fdma_list_head_t items, because both the CPU and
  //          the FDMA may update two adjacent items simultaneously, and because the cache invalidate
  //          function typically writes back the start cache line if it's not cache-line aligned.
  //          I know the following alignment is GCC-specific syntax, and if you're not using GCC, you
  //          may need to do other things like defining a union with sizeof(union)==multiple of 32.
  unsigned char dcb[VTSS_FDMA_DCB_SIZE_BYTES] __attribute ((aligned (32)));
  
  // XTR: VIRTUAL ADDRESS. Must point to a pre-allocated area of alloc_len bytes. Must be 32-bit aligned. Set by user.
  // INJ: VIRTUAL ADDRESS. Must point to a pre-allocated area of act_len bytes. For SOF DCB,
  //      it must point to the IFH0. Need only be byte-aligned. Set by user.
  unsigned char *data;

  // XTR: The number of allocated bytes in ->data. Set by user.
  // INJ: The physical port number that this frame is sent to. Need only be set in SOF DCB.
  int alloc_len_or_port;

  // XTR: Holds the number of bytes extracted into ->data. In case of a fragmented frame, the receiver of the frame
  //      must sum up all the act_len in the list of fragments to obtain the full frame size.
  //      For the SOF DCB, act_len includes the size of the IFH and possible start gap, and for EOF DCB, 
  //      also the size of the FCS and possible end gap. Set by vtss_fdma.c.
  // INJ: The number of bytes held in associated data area. For the SOF DCB, it includes the size of the IFH
  //      and CMD fields, and for the EOF DCB, also the size of the FCS. Set by user.
  int act_len;
  
  // XTR/INJ: A pointer to any user data. Set by user.
  void *user;
  
  // XTR: Not used (a per-queue (and thereby per-channel) callback function is configured instead).
  // INJ: Callback function called when a frame has been transmitted. Must be set by user in SOF list item.
  //      Not used for non-SOF items, since the callback is only called once per frame.
  //      @cntxt:   The value of the parameter passed into the OS-specific call to vtss_fdma_irq_handler().
  //      @list:    The list of software-DCBs constituting the frame that has just been injected.
  //      @port:    The port it was injected to.
  //      @dropped: When 0 the frame was successfully transmitted, otherwise an error occurred. Errors can
  //                only occur if injecting to a front port and the INJ_WR_DELAY is not set high
  //                enough, or if the front port is in flow control mode. See also vtss_fdma_set_tx_flow_ctrl_cfg().
  void (*inj_cb)(void *cntxt, struct tag_vtss_fdma_list_head *list, int port, int dropped);

  // XTR: Points to the next entry in the list or NULL if it's the last. Set by user on initialization of list.
  //      Continuously updated by vtss_fdma.c afterwards.
  // INJ: Points to the next fragment of the frame and set by user on a per-frame basis. Last fragment of a frame
  //      must set ->next to NULL. Once handed to vtss_fdma.c, the driver code takes over.
  struct tag_vtss_fdma_list_head *next;
} vtss_fdma_list_head_t;

/*****************************************************************************/
// Properties on how to inject a frame using the vtss_fdma_inj() function.
// All members map or relate to fields in the injected frame's IFH and CMD
// fields.
/*****************************************************************************/
typedef struct {
  // In the following, @list refers to the list argument passed to the
  // vtss_fdma_inj() function.

  // @port_mask: 
  //   Mask that is VTSS_PHYS_PORT_CNT bits wide. The mask is only used
  //   if @list->alloc_len_or_port is set to VTSS_CPU_PM_NUMBER and the
  //   @switch_frm member is non-zero. The mask thus contains a
  //   bit for every front port, where bit 0 in the mask corresponds
  //   to physical front port number 0, etc. This maps to the PORTMASK
  //   field of the CMD field that comes right after the IFH in the
  //   injected frame. The frame will be transmitted on all front ports
  //   that have the corresponding bit set in the mask, and can thus be
  //   used to multicast the same frame on multiple front ports in one go.
  unsigned long  port_mask;

  // @vlan:
  //   The VLAN that the frame is injected on. Maps directly to the
  //   corresponding field in the IFH.
  unsigned short vlan;

  // @aggr_code:
  //   The aggregation code that this frame will use. The 4-bit number
  //   maps directly to the corresponding field in the IFH, but is
  //   only set if the frame is being switched (the @switch_frm member
  //   is non-zero) and the destination port number is VTSS_CPU_PM_NUMBER.
  unsigned char  aggr_code;

  // @switch_frm:
  //   If non-zero, the frame will be switched provided the injection port
  //   (set with @list->alloc_len_or_port) is VTSS_CPU_PM_NUMBER.
  //   If set, the corresponding DO_ANALYZE flag will be set in the
  //   CMD field, which comes right after the IFH in the frame data.
  //   Switching of a frame implies that the frame goes through the
  //   analyzer (ANA) and the DMAC gets looked up in the MAC table
  //   to find the final destination port. The frame may thus also
  //   be flooded.
  unsigned char  switch_frm;

  // @contains_stack_hdr:
  //   If non-zero, the IFH will have the corresponding stack_hdr
  //   bit set, which implies that the actual frame data already 
  //   contains a stack header, so that the stack-enabled front
  //   port doesn't insert one. Only used if @list->alloc_len_or_port
  //   is set to one of the stack ports.
  unsigned char  contains_stack_hdr;

  // @dont_touch_ifh:
  //   As the name implies, if this is non-zero, the FDMA driver
  //   code will not modify the IFH before frame injection. The
  //   @contains_stack_hdr, @aggr_code, and @vlan members of this
  //   structure will therefore not be used.
  unsigned char  dont_touch_ifh;
} vtss_fdma_inj_props_t;

/*****************************************************************************/
// vtss_fdma_init()
//
// Call context:
//   Thread
//
// Re-entrant:
//   No
// 
// Description: 
//   This function must be called before any other FDMA API function.
//   It performs a silicon FDMA version check, disables the FDMA, and
//   initializes the internal FDMA state.
//
// Return Value:
//   1 on success
//   0 on failure (version check fails)
/*****************************************************************************/
int vtss_fdma_init(void);

/*****************************************************************************/
// vtss_fdma_uninit()
// 
// Call context:
//   Thread
//
// Re-entrant:
//   No
//
// Description:
//   Rarely used. Use only if you want to make a controlled shut-down of the
//   FDMA. Disables all FDMA channels and interrupts, and clears pending
//   interrupts.
/*****************************************************************************/
void vtss_fdma_uninit(void);

/*****************************************************************************/
// vtss_fdma_xtr_cfg()
// 
// Call context:
//   Thread
//
// Re-entrant:
//   No
//
// Description:
//   Enables or disables an FDMA channel for extraction.
//   This function is usually called during initialization only, right after
//   vtss_fdma_init(). It connects a CPU Port Module extraction queue to a
//   DMA channel, and hands over an initialized list of software DCBs to the
//   FDMA silicon to fill in with frames received on the extraction queue.
//   Notice: It is not the task of the FDMA driver code to match particular
//   frame types to particular extraction queues.
//   In addition to the list of software DCBs, the address of a a callback
//   function is supplied in the call. The FDMA driver code calls this callback
//   function whenever one frame has been extracted.
//
// @ena      : 0 to disable the channel given by @ch, 1 to enable (0 is
//             rarely used). The remainder of the parameters are described as if
//             the channel is being enabled.
// @ch       : The channel to disable/enable. Valid values are
//             [0; VTSS_FDMA_CH_CNT[.
// @qu       : The extraction queue to associate this channel with. Valid values
//             are [0; VTSS_FDMA_XTR_QU_CNT[.
// @start_gap: Asks the FDMA silicon to insert a gap between the IFH and the first
//             byte of the actual frame (the DMAC). The unit is 32-bit words, and
//             the valid range is [0; 64[. The feature is useful if the module
//             calling the FDMA driver code allows for re-use of software DCBs,
//             since it can then insert a start-gap of four bytes on all extracted
//             frames, and if a frame is going to be re-injected, possibly with
//             small modifications, then there's room for the CMD field, which is
//             required between IFH and actual frame on injection.
// @end_gap  : Asks the FDMA silicon to insert a gap after the last byte of the
//             frame (FCS). This is rarely needed, but allows for pre-reserving
//             space for additional tails if the frame is going to be re-injected.
//             The unit is 32-bit words, and the valid range is [0; 64[.
// @list     : A linked, NULL-terminated list of software DCBs, into which the FDMA
//             extract frames. One frame may take one or more DCBs, depending on the
//             size of the associated data area. The following fields of each list
//             item must be pre-initialized by the Packet Module (see definition of
//             vtss_fdma_list_head_t structure for detais):
//               data, alloc_len_or_port, (user), and next.
// @xtr_cb   : The address of the callback function invoked by the FDMA driver code
//             when a frame arrives. The callback function is invoked once per frame.
//             Call context:
//                DSR (the same as what invokes vtss_fdma_irq_handler().
//             The parameters to the callback function are as follows:
//                @cntxt: The value passed in the Packet Module's call to vtss_fdma_irq_handler().
//                @list : NULL-terminated list of software DCBs making up the frame. Depending
//                        on the frame size one or more DCBs are used. The last is always
//                        NULL-terminated. The FDMA has filled in the following fields (see
//                        definition of vtss_fdma_list_head_t structure for deatils):
//                          (dcb), *data, act_len, (next).
//                        Once delivered to the Packet Module, the FDMA will not use the
//                        list again. The FDMA can, however, be handed back a (new) list of
//                        software DCBs by returning the list when the xtr_cb() returns.
//                        Alternatively, use the vtss_fdma_xtr_add_dcbs() function.
//                @qu   : The extraction queue that this frame was extracted from. This
//                        may be useful if all extraction callback functions map to the
//                        same function.
// Expected return value from xtr_cb():
//             Non-NULL if the Packet Module wishes to give the FDMA new DCBs to extract to.
//             In the case where the Packet Module handles the frame directly, it could as well
//             pass back the list that xtr_cb() was called with right away. In the case where
//             the frame is passed up to higher levels, like an IP stack, the Packet Module
//             will probably return NULL in the call to xtr_cb() and provide a replacement
//             list at a later point in time with a call to vtss_fdma_xtr_add_dcbs().
/*****************************************************************************/
void vtss_fdma_xtr_cfg(int ena, int ch, int qu, int start_gap, int end_gap, vtss_fdma_list_head_t *list, vtss_fdma_list_head_t *(*xtr_cb)(void *cntxt, vtss_fdma_list_head_t *list, int qu));

/*****************************************************************************/
// vtss_fdma_xtr_cfg()
// 
// Call context:
//   Thread
//
// Re-entrant:
//   No
//
// Description:
//   Reserved or frees an FDMA channel for injection. Actual injection
//   is performed on a per-frame basis with subsequent calls to
//   vtss_fdma_inj().
//
// @ena: Set to 0 to disable the channel (rarely used), and 1 to enable it.
// @ch : The channel to disable/enable. Valid values are [0; VTSS_FDMA_CH_CNT[.
/*****************************************************************************/
void vtss_fdma_inj_cfg(int ena, int ch);

/*****************************************************************************/
// vtss_fdma_xtr_add_dcbs()
//
// Call context:
//   Thread
//
// Re-entrant:
//   Yes
//
// Description:
//   Depending on the Packet Module, it may be desirable to send software DCBs
//   back to the FDMA driver code either right away after the call to the
//   xtr_cb() callback function, or later when higher levels of software
//   has processed the frame, or  - to avoid a DoS attack - to hold back the
//   list until attack is over. In the two latter cases, the DCBs may be given
//   (back) to a specific FDMA channel by calling this function.
//
// @ch  : The channel to store these free DCBs onto.
// @list: The list of DCBs to store onto the channel's free list of DCBs.
/*****************************************************************************/
void vtss_fdma_xtr_add_dcbs(int ch, vtss_fdma_list_head_t *list);

/*****************************************************************************/
// vtss_fdma_inj()
//
// Call context:
//   Thread
//
// Re-entrant:
//   Yes
//
// Description:
//   Inject a frame. The function takes a NULL-terminated list of software
//   DCBs and injects it using the channel number also passed as argument.
//   After the injection has taken place, the inj_cb() callback function,
//   set in the SOF DCB's inj_cb member, is called back with a success
//   indicator and the actual list of DCBs.
//
// @list  : The list of software DCBs making up the frame. The destination
//          front-port is given by the DCBs' alloc_len_or_port member.
//          This is the physical port number and thus ranges from
//          [0; VTSS_TOTAL_PORT_CNT[, where VTSS_CPU_PM_NUMBER is used if the
//          frame uses the CPU Port Module, and any other number if the frame
//          should go to a front port. Any DMA channel can inject to any
//          port.
// @ch    : The channel to use for the injection.
// @len   : The length of the whole frame in bytes, excluding IFH and CMD,
//          but including the FCS.
// @props : Pointer to a structure that contains properties on how to inject
//          the frame. All the structure's members are used to set the
//          IFH and CMD fields appropriately. For future extensions, it is
//          recommended that you memset() the structure to all-zeros before
//          assigning it. The structure may be allocated on the stack,
//          since vtss_fdma_inj() doesn't keep a pointer to it after the
//          call returns.
/*****************************************************************************/
void vtss_fdma_inj(vtss_fdma_list_head_t *list, int ch, int len, vtss_fdma_inj_props_t *props);

/*****************************************************************************/
// vtss_fdma_irq_handler()
//
// Call context:
//   OS-Specific. See description below.
//
// Re-entrant:
//   NO!!!
//
// Description:
//   This function is the heart-beat of all FDMA silicon communication.
//   The driver code enables interrupts on the FDMA silicon and expects this
//   function to be called whenver the FDMA generates interrupts.
//   The function is not re-entrant, and it must *not* be interrupted by
//   other non-interrupt code. The function does not call the
//   VTSS_FDMA_DISABLE_INTERRUPTS() macro.
//
//   The function first checks for extraction channels interrupting and
//   calls back the relevant xtr_cb() functions with one frame at a time.
//   The function calls back for all frames that the FDMA has extxracted
//   since last call.
//   Then it checks for injection completion, takes care of retransmission
//   if that is needed, and calls back the relevant inj_cb() functions
//   for every frame that has been injected.
//  
//   This means that both xtr_cb() and inj_cb() callback functions are called
//   from the same context as the vtss_fdma_irq_handler() is called. BEWARE!!
// 
//   To better understand what is required by the caller of this function,
//   let's branch on the two basic options:
//
//   Interrupt Driven Operation:
//     If interrupts are supported, it is important that the FDMA interrupt
//     is disabled by the "top half" or ISR if it finds out that the
//     interrupt is for the FDMA. If the OS supports top and bottom halves
//     like Linux (a.k.a. ISRs and DSRs in eCos), it is recommended to call
//     vtss_fdma_irq_handler() in the bottom half/DSR rather than in the
//     top half/ISR. In the bottom half/DSR case, it is ensured that no other
//     bottom halves/DSRs or threads can preempt the handler. Once the handler
//     returns, the caller should clear and re-enable FDMA interrupts. 
//     If the OS doesn't support top/bottom halves, but still supports
//     interrupt handling, vtss_fdma_irq_handler() may be called directly
//     from the ISR, which should still start by disabling FDMA interrupts,
//     then call the handler, and finally clear and re-enable them.
//
//   Polled Operation:
//     Since the FDMA driver code reads registers directly in the FDMA silicon
//     to figure out which channels are interrupting, and since it allows for
//     "no channels want the CPU's attention", it is possible to use
//     a polled approach rather than an interrupt driven approach. In a single-
//     threaded application you can call it once in the round-robin trip,
//     because it cannot be interrupted by any other code. In a multi-threaded
//     application you will have to disable the scheduler before calling it,
//     and re-enable it afterwards. This ensures that no other functions
//     can call e.g. vtss_fdma_inj() while servicing the "interrupt". It is
//     not good enough to disable interrupts, because the code calls macros
//     like "output this debug message to the console", which may end up in
//     the OS kernel, which in turn may schedule the vtss_fdma_irq_handler()
//     function out in favor of another thread.
//
// @contxt:
//     A user-defined argument, which is passed to the inj_cb()
//     and xtr_cb() callback functions. Rarely needed.
/*****************************************************************************/
void  vtss_fdma_irq_handler(void *cntxt);

/*****************************************************************************/
// vtss_fdma_set_tx_flow_ctrl_cfg()
//
// Call context:
//   Thread
//
// Re-entrant:
//   No
//
// Description:
//   Under certain circumstances, injections to front ports may fail. This
//   happens in two cases:
//   1) The FDMA writes to the super priority front port queue to fast for
//      it to cope with. The INJ_WR_DELAY should've taken care of reducing
//      the speed, but due to a design flaw, the maximum setting of this
//      register is not high enough. Only the 2.5Gbps stack links exhibit
//      this behavior.
//   2) The super priority front port queue gets overflowed due to flow
//      control against the port. This can happen for all front ports, if
//      they are configured to obey flow control.
//   To remedy these problems, this function allows for the CPU controlling
//   the final injection. The normal injection case is that the FDMA starts
//   by injecting all data, followed by a write to a special register that
//   tells the front port that all of the frame has been injected. If the
//   FDMA is in "flow control mode", the FDMA still writes all the data, but
//   upon the interrupt (call to vtss_fdma_irq_handler()), the CPU checks
//   if all the data was written successfully, and if so, writes the "go"
//   to the front port. If the data was not written successfully, the
//   vtss_fdma_irq_handler() sets up the FDMA to retransmit the frame. This
//   is attempted at most @retransmit_cnt times, after which the inj_cb()
//   function is called back with the @dropped argument set to 1. The
//   called back function can then take proper action. Typically, it will
//   attempt a manual injection if it is for the stack links (case 1, above),
//   which are never in flow control mode, or it will simply drop the frame
//   if it's a 1Gbps front port that is in flow control mode (case 2, above).
//   If attempting a manual injection, the delay between consecutive writes
//   can be arbitrarily large, thereby assuring that the super priority
//   queue can take off the data. See  vtss_fdma_inj_suspend_port() and
//   vtss_fdma_inj_port_active() for a description of how to suspend the FDMA
//   from injecting to a certain port.
//   Notice, that there is hardware flow control between the CPU Port Module
//   and the FDMA, which means that the FDMA cannot overflow the CPU Port
//   Module's injection queue, whereby this is not a problem for that one.
//
// @port           : The front port for which to enable or disable the CPU-
//                   assisted injection control and retransmission count.
// @in_tx_flow_ctrl: 0 to disable CPU-assisted injection control, non-zero
//                   to enable it.
// @retransmit_cnt : Only used if @in_tx_flow_ctrl is non-zero. Determines
//                   the number of times the frame will be scheduled for
//                   retransmission by the FDMA driver code. A value of 0
//                   thus means that the frame only will be attempted
//                   injected once.
/*****************************************************************************/
void vtss_fdma_set_tx_flow_ctrl_cfg(int port, unsigned char in_tx_flow_ctrl, unsigned char retransmit_cnt);

/*****************************************************************************/
// vtss_fdma_get_tx_flow_ctrl_cfg()
//
// Call context:
//   Thread
//
// Re-entrant:
//   No
//
// Description:
//   This is the counter-function to vtss_fdma_set_tx_flow_ctrl_cfg(). It
//   returns the current settings of the @in_tx_flow_ctrl and @retransmit_cnt
//   for a given @port.
//   See vtss_fdma_set_tx_flow_ctrl_cfg() for details.
//
// @port           : The front port to get the settings for. Valid values are
// @in_tx_flow_ctrl: Pointer to an uchar that receives the current value of
//                   the FDMA's perception of whether the port is in CPU-
//                   assisted injection.
// @retransmit_cnt : Pointer to an uchar that receives the current value of
//                   the FDMA's perception of the ports retransmission count.
/*****************************************************************************/
void vtss_fdma_get_tx_flow_ctrl_cfg(int port, unsigned char *in_tx_flow_ctrl, unsigned char *retransmit_cnt);

/*****************************************************************************/
// vtss_fdma_xtr_ch_from_list()
//
// Call context:
//   Thread
//
// Re-entrant:
//   Yes
//
// Description:
//   This function takes a pointer to a software DCB and investigates the
//   hardware DCB to figure out which channel originally extracted the
//   corresponding frame.
//   This is useful if the Packet Module needs to feed a list of software
//   DCBs back to the FDMA after it has been handled by higher layers. At
//   that point in time, the Packet Module itself has no idea as to which
//   channel the frame was extracted through, and therefore doesn't know
//   to which channel to feed the free list back (provided the Packet Module
//   wishes to feed the same DCBs back to where they were originally
//   assigned).
/*****************************************************************************/
int vtss_fdma_xtr_ch_from_list(vtss_fdma_list_head_t *list); // Can be used to get the channel number that the frame pointed to by list was extracted from.

/*****************************************************************************/
// vtss_fdma_inj_suspend_port(int port, int suspend)
//
// Call context:
//   Thread
//
// Re-entrant:
//   Yes
//
// Description:
//   This can be used to resume or gracefully suspend the FDMA from injecting
//   frames to a certain port. A call to vtss_fdma_inj_suspend_port() with
//   @suspend == 1 will normally have to be followed by a call to the same
//   function with @suspend == 0.
//   Suspending a port doesn't mean that the port gets suspended immediately.
//   The next time the FDMA has injected a frame, and needs to be fed with
//   the next, the channel stops if the destination port is suspended.
//   This means that all frames that use the corresponding channel will be
//   put on hold even if they're destined for other ports than the suspended.
//   Since the FDMA doesn't stop immediately, but waits until a possibly
//   current frame has been injected, a suspension should be used in
//   conjunction with the vtss_fdma_inj_port_active(), which could be called
//   repeatedly to figure out when the port is ready to perform e.g. manual
//   frame injection into.
/*****************************************************************************/
void vtss_fdma_inj_suspend_port(int port, int suspend);

/*****************************************************************************/
// vtss_fdma_inj_port_active()
//
// Call context:
//   Thread
//
// Re-entrant:
//   Yes
//
// Description:
//   Returns whether the FDMA is currently injecting frames to a given port.
//   This can be used to gracefully wait for a DMA channel having injected a
//   frame to a port, so that the port becomes available for e.g. manual
//   frame injection. You would then have to suspend the port by first calling
//   vtss_fdma_inj_suspend_port(), and then repeatedly poll for the status
//   with a call to vtss_fdma_inj_port_active() until it retuns "not active".
//
// @port: The port to check for status on. Valid values are in the range
//        [0; VTSS_TOTAL_PORT_CNT[.
//
// Return Value:
//   0: The FDMA is not injecting frames to @port.
//   1: The FDMA is injecting frames to @port.
/*****************************************************************************/
int  vtss_fdma_inj_port_active(int port);

/*****************************************************************************/
// Statistics are only gathered if VTSS_FDMA_KEEP_STATISTICS is defined when
// compiling vtss_fdma.c.
// The structure below is defined always for code compatibility, though.
// Use vtss_fdma_get_stats() to retrieve current statistics.
/*****************************************************************************/
typedef struct tag_vtss_fdma_stats
{
  unsigned long      rx_packets[VTSS_FDMA_XTR_QU_CNT];
  unsigned long long rx_bytes[VTSS_FDMA_XTR_QU_CNT];
  unsigned long      rx_bufs_used[VTSS_FDMA_XTR_QU_CNT];
  unsigned long      rx_bufs_added[VTSS_FDMA_XTR_QU_CNT];
  unsigned long      rx_dropped; // It can only drop if receiving frames that were originally sent from CPU PM.
 
  unsigned long      tx_packets[VTSS_FDMA_CH_CNT];
  unsigned long long tx_bytes[VTSS_FDMA_CH_CNT];
  unsigned long      tx_bufs_used[VTSS_FDMA_CH_CNT];
  unsigned long      tx_dropped[VTSS_TOTAL_PORT_CNT];

  unsigned long      intr_cnt;
} vtss_fdma_stats_t;

/*****************************************************************************/
// vtss_fdma_get_stats()
//
// Call context:
//   Thread
//
// Re-entrant:
//   Yes
//
// Description:
//   If statistics are being gathered (VTSS_FDMA_KEEP_STATISTICS is defined
//   in OS-specific header file), then the FDMA driver code continuously
//   updates the current number of injected and extracted packets and bytes,
//   together with the number of DCBs added to the buffer pool and actually
//   used, and the number of times vtss_fdma_irq_handler() is called,
//   corresponding to the interrupt count (intr_cnt).
//   If statistics are not being gathered, all members of the returned
//   structure are 0.
//   Note that the returned value is simply a pointer to the structure that
//   the FDMA is also updating, so don't change its values, and you should
//   protect using the values by disabling interrupts/scheduler.
//
// Return Value:
//   Pointer to FDMA statistics. Don't modify members, protect reading members.
/*****************************************************************************/
vtss_fdma_stats_t *vtss_fdma_get_stats(void);

/*****************************************************************************/
// vtss_fdma_clear_stats()
//
// Call context:
//   Thread
//
// Re-entrant:
//   Yes
//
// Description:
//   Clear statistics.
/*****************************************************************************/
void vtss_fdma_clear_stats(void);

#endif /* VTSS_FDMA_API_H */
/*****************************************************************************/
//
// End of file
//
//****************************************************************************/
