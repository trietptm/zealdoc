/*
 
 Vitesse Switch Software.
 
 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/
#ifndef VTSS_FDMA_LINUX_H
#define VTSS_FDMA_LINUX_H

#include <asm/io.h>
#include <asm/hardware.h> /* For VTSS_* registers */
#include <linux/dma-mapping.h>

// This file defines support functions for the FDMA when run under Linux.
#define vtss_fdma_raw_readl(a)     __raw_readl(a)
#define vtss_fdma_raw_writel(a, v) __raw_writel((v), (a))

extern int dbg_msk;

// Assert and debug print functions
#ifdef VTSS_FDMA_DBG
  #define VTSS_FDMA_DBG_MSG(lvl, format, args...) if (dbg_msk&(lvl)) printk("VTSS_FDMA: " format, ##args );
  #define VTSS_FDMA_ASSERT(expr) {\
    if (!(expr))\
      printk(KERN_ERR "Assertion %s failed: File %s, function %s(), line %d\n", #expr, __FILE__, __FUNCTION__, __LINE__);\
  }
  #define VTSS_FDMA_ASSERT_MSG(expr, format, args...) {if(!(expr)) {printk(KERN_ERR "VTSS_FDMA: " format, ##args);  printk(KERN_ERR "Assertion %s failed: File %s, function %s(), line %d\n", #expr, __FILE__, __FUNCTION__, __LINE__);}}
#else
  #define VTSS_FDMA_DBG_MSG(lvl, format, args...)
  #define VTSS_FDMA_ASSERT(expr)
  #define VTSS_FDMA_ASSERT_MSG(expr, format, args...) {if(!(expr)) {printk(KERN_ERR "VTSS_FDMA: " format, ##args);  printk(KERN_ERR "Assertion %s failed: File %s, function %s(), line %d\n", #expr, __FILE__, __FUNCTION__, __LINE__);}}
#endif

// #define VTSS_FDMA_INIT_PORTS_LOOPBACK

// Define the following if you want the first byte following the type/length field to be located
// on a 32-bit boundary before passing a received frame up the protocol stack.
// This may potentially speed up the handling of the packet, in the upper layers, but it will
// cause a copy of the frame in the FDMA driver.
// #define VTSS_FDMA_XTR_ALIGN_PROTOCOL_HDR_ON_32BIT_BOUNDARY

// Define the following if you want the first byte of the IFH to be located on a 32-bit boundary
// for injected frames. In Linux, it ends up on a 16-bit boundary because Linux forces the
// first byte after the type/length field to be located on a 32-bit boundary, causing the first
// byte of the DMAC - and thereby the first byte of the IFH - to be located on a 16-bit boundary.
// #define VTSS_FDMA_INJ_ALIGN_IFH_ON_32BIT_BOUNDARY

// Define the following if you want to re-inject extracted frames as fast as possible.
// The extracted frames will not be sent to higher levels of software. This cannot be defined together
// with other VTSS_FDMA_xxx_TEST defines.
// #define VTSS_FDMA_LOOPBACK_TEST

// Define the following if you want to perform an extraction test. In this mode packets received
// from the interface are disacarded. This cannot be defined together with other VTSS_FDMA_xxx_TEST defines.
// Run "test_progs 0" on target, then start SMB, wait 30 seconds, then Ctrl-C "test_progs", then
// stop SMB, and write down the cnt/s from "test_progs".
// #define VTSS_FDMA_XTR_TEST

// Define the following if you want to perform an injection test.
// Connect two smartbit ports to two frontports and transmit one single frame on one of the ports.
// The frame will get extracted by the FDMA and re-injected over and over again to VTSS_FDMA_TEST_PORT_MASK.
// #define VTSS_FDMA_INJ_TEST

// This is the port mask that extracted frames (in case VTSS_FDMA_LOOPBACK_TEST is set) are looped
// back to or injected frames (in case VTSS_FDMA_INJ_TEST is set) are transmitted to.
#define VTSS_FDMA_TEST_PORT_MASK 0x04 

#if (defined(VTSS_FDMA_LOOPBACK_TEST) && (defined(VTSS_FDMA_XTR_TEST) || defined(VTSS_FDMA_INJ_TEST))) || (defined(VTSS_FDMA_XTR_TEST) && defined(VTSS_FDMA_INJ_TEST))
  #error "Only one of VTSS_FDMA_LOOPBACK_TEST, VTSS_FDMA_XTR_TEST, and VTSS_FDMA_INJ_TEST may be defined at a time"
#endif

#define VTSS_FDMA_VIRT_TO_PHYS(addr) virt_to_phys((void *)(addr))
#define VTSS_FDMA_INVALIDATE_DCACHE_DCB(virt_addr, size)  consistent_sync((void *)(virt_addr), (size), DMA_FROM_DEVICE)
#define VTSS_FDMA_INVALIDATE_DCACHE_DATA(virt_addr, size) consistent_sync((void *)(virt_addr), (size), DMA_FROM_DEVICE)
#define VTSS_FDMA_FLUSH_DCACHE_DCB(virt_addr, size)       consistent_sync((void *)(virt_addr), (size), DMA_TO_DEVICE)
#define VTSS_FDMA_FLUSH_DCACHE_DATA(virt_addr, size)      consistent_sync((void *)(virt_addr), (size), DMA_TO_DEVICE)
#define VTSS_FDMA_INTERRUPT_FLAGS unsigned long
#define VTSS_FDMA_DISABLE_INTERRUPTS(flags) local_irq_save(flags)
#define VTSS_FDMA_RESTORE_INTERRUPTS(flags) local_irq_restore(flags)
#define VTSS_FDMA_BARRIER() barrier()
#define VTSS_FDMA_MEMSET(s, c, n) memset((s),(c),(n))

#endif // VTSS_FDMA_LINUX_H
/*****************************************************************************/
//
// End of file
//
//****************************************************************************/
