/*
 
 Vitesse Switch Software.
 
 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/
/*****************************************************************************/
// fdma_val.c
//*****************************************************************************/
// Include the internal FDMA implementation.
#define VTSS_FDMA_VAL
#include "vtss_fdma.c"

#define FCS_SIZE_BYTES 4

// Since we don't have malloc()/free(), we need to statically allocate these.
static vtss_fdma_list_head_t ch_list     [VTSS_FDMA_CH_CNT][MAX_CH_BUF_CNT];
       unsigned char         ch_data_list[VTSS_FDMA_CH_CNT][MAX_CH_BUF_CNT][CH_BUF_SIZE_BYTES]  __attribute ((aligned (4)));

// Which channel is associated with a given queue?
static int xtr_qu2ch[VTSS_FDMA_XTR_QU_CNT];

/*****************************************************************************/
/*****************************************************************************/
typedef struct
{
  int start_gap; // XTR only, measured in 32-bit words
  int end_gap;   // XTR only, measured in 32-bit words
  int qu;        // XTR only. The queue that this channel serves.
  void (*xtr_cb)(vtss_fdma_list_head_t *list, int qu); // XTR only.
  int buf_cnt;
  int ena;
  int usage;
  int bufs_left; /* INJ only. Tx buffers left */
  int ring_head; /* INJ only. Index into list to enqueue the next packet */
} val_fdma_ch_cfg_t;

/*****************************************************************************/
/*****************************************************************************/
typedef struct
{
  val_fdma_ch_cfg_t ch_cfg[VTSS_FDMA_CH_CNT];
} val_fdma_priv_t;

// Statically allocate it, since we don't have malloc()/free() in validation.
static val_fdma_priv_t val_fdma_priv;

/*****************************************************************************/
/*****************************************************************************/
inline void atomic_add(int *what, int amount)
{
  VTSS_FDMA_INTERRUPT_FLAGS flags;
  VTSS_FDMA_DISABLE_INTERRUPTS(flags);
  (*what) += amount;
  VTSS_FDMA_RESTORE_INTERRUPTS(flags)
}

/*****************************************************************************/
/*****************************************************************************/
inline void atomic_sub(int *what, int amount)
{
  VTSS_FDMA_INTERRUPT_FLAGS flags;
  VTSS_FDMA_DISABLE_INTERRUPTS(flags);
  (*what) -= amount;
  VTSS_FDMA_RESTORE_INTERRUPTS(flags)
}

/*****************************************************************************/
/*****************************************************************************/
inline int atomic_read(int *what)
{
  int result;
  VTSS_FDMA_INTERRUPT_FLAGS flags;
  VTSS_FDMA_DISABLE_INTERRUPTS(flags);
  result=*what;
  VTSS_FDMA_RESTORE_INTERRUPTS(flags)
  return result;
}

/*****************************************************************************/
/*****************************************************************************/
static inline int next_tx(int tx, int buf_cnt)
{ 
  return ((tx+1)%buf_cnt);
}

/*****************************************************************************/
// Called back by fdma.c
// @list: Contains a pointer to the vtss_fdma_list_head containing one single
//        packet. In case of a jumbo frame whose size is bigger than ->len,
//        the next pointer is a pointer to the next part of the frame.
// We are expected to return a new valid list that can be inserted in place
// of the one we just got.
/*****************************************************************************/
static vtss_fdma_list_head_t *val_fdma_on_rx_packet(void *cntxt, vtss_fdma_list_head_t *list, int qu)
{
  val_fdma_ch_cfg_t *ch_cfg=&val_fdma_priv.ch_cfg[xtr_qu2ch[qu]];
  VTSS_FDMA_ASSERT(ch_cfg->usage==VTSS_FDMA_CH_USAGE_XTR);

  // Call back the configured callback function
  if(ch_cfg->xtr_cb)
    ch_cfg->xtr_cb(list, qu);
    
  // Re-use the list (this requires the ch_cfg->xtr_cb() function not to release
  // it, and not to think that it is valid after it has returned)
  return list;
}

/*****************************************************************************/
// Called back by fdma.c when a packet has been transmitted.
/*****************************************************************************/
static void val_fdma_on_tx_packet(void *cntxt, vtss_fdma_list_head_t *list, int ch, int dropped)
{
  vtss_fdma_list_head_t *l=list;
  int act_frm_len=0, buf_used_cnt=0;
  val_fdma_ch_cfg_t *ch_cfg; 

  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);
  VTSS_FDMA_ASSERT(list);

  VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_INJ_VERBOSE, "val_fdma_on_tx_packet()\n");
  while(l) {
    buf_used_cnt++;
    act_frm_len += l->act_len;
    l=l->next;
  }
  act_frm_len -= (VTSS_FDMA_IFH_SIZE_BYTES + VTSS_FDMA_CMD_SIZE_BYTES);
  VTSS_FDMA_ASSERT(act_frm_len>=VTSS_FDMA_MIN_FRAME_SIZE_BYTES);

  ch_cfg = &val_fdma_priv.ch_cfg[ch];
  VTSS_FDMA_ASSERT(ch_cfg->usage==VTSS_FDMA_CH_USAGE_INJ);
  atomic_add(&ch_cfg->bufs_left, buf_used_cnt);
}

/*****************************************************************************/
/*****************************************************************************/
void val_fdma_inj(vtss_fdma_list_head_t *l, int ch, int len, vtss_fdma_inj_props_t *props)
{
  VTSS_FDMA_ASSERT(l);
  // Set the SOF DCB's inj_cb handler
  l->inj_cb = val_fdma_on_tx_packet;
  vtss_fdma_inj(l, ch, len, props);
}

/*****************************************************************************/
/*****************************************************************************/
static void val_fdma_load_rx_ring(int ch)
{
  int i, buf_cnt;
  val_fdma_ch_cfg_t *ch_cfg=&val_fdma_priv.ch_cfg[ch];
  vtss_fdma_list_head_t *list;

  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);
  VTSS_FDMA_ASSERT(ch_cfg->usage==VTSS_FDMA_CH_USAGE_XTR);
  buf_cnt = ch_cfg->buf_cnt;
  list=ch_list[ch];

  // The length of a DCB's associated data area is the MTU + the IFH size + 
  // the start and end gap sizes, but it cannot exceed VTSS_FDMA_MAX_DATA_PER_DCB_BYTES.
  VTSS_FDMA_ASSERT(CH_BUF_SIZE_BYTES>=VTSS_FDMA_MIN_DATA_PER_XTR_SOF_DCB_BYTES && CH_BUF_SIZE_BYTES<=VTSS_FDMA_MAX_DATA_PER_DCB_BYTES);
  VTSS_FDMA_ASSERT(buf_cnt>0);

  // Chain the pre-allocted buffers together.
  for(i=0; i<buf_cnt; i++)
  {
    list[i].user              = NULL;
    list[i].data              = ch_data_list[ch][i];
    list[i].alloc_len_or_port = CH_BUF_SIZE_BYTES;
    list[i].next              = &ch_list[ch][i+1];
  }

  // The last entry's next pointer must point to NULL
  list[buf_cnt-1].next = NULL;

  // Initialize the FDMA with this list, and tell it to
  // call val_fdma_on_rx_packet() back when a frame has arrived.
  vtss_fdma_xtr_cfg(1, ch, ch_cfg->qu, ch_cfg->start_gap, ch_cfg->end_gap, list, val_fdma_on_rx_packet);
}

/*****************************************************************************/
/*****************************************************************************/
static void val_fdma_flush_rx_ring(int ch)
{
  vtss_fdma_xtr_cfg(0, ch, 0, 0, 0, NULL, NULL); // Disable channel.
}

/*****************************************************************************/
/*****************************************************************************/
static void val_fdma_load_tx_ring(int ch)
{ 
  val_fdma_ch_cfg_t *ch_cfg;
  int buf_cnt, i;

  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);
  ch_cfg = &val_fdma_priv.ch_cfg[ch];
  buf_cnt = ch_cfg->buf_cnt;
  VTSS_FDMA_ASSERT(buf_cnt>0);

  // Initialize it.
  for(i = 0; i < buf_cnt; i++) {
    ch_list[ch][i].data = ch_data_list[ch][i];
    ch_list[ch][i].next = NULL; // These are chained by val_fdma_get_inj_buffers();
  }

  ch_cfg->bufs_left=buf_cnt;
  ch_cfg->ring_head=0;

  vtss_fdma_inj_cfg(1, ch);
} 

/*****************************************************************************/
/*****************************************************************************/
static void val_fdma_flush_tx_ring(int ch)
{
  val_fdma_ch_cfg_t *ch_cfg = &val_fdma_priv.ch_cfg[ch];
  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);
  VTSS_FDMA_ASSERT(ch_cfg->usage==VTSS_FDMA_CH_USAGE_INJ);
  vtss_fdma_inj_cfg(0, ch);
  ch_cfg->bufs_left=0;
  ch_cfg->ring_head=0;
}

/*****************************************************************************/
// val_fdma_port_cfg()
/*****************************************************************************/
static void val_fdma_port_cfg(int mtu, int loopback, int dont_update_crc)
{
  unsigned int qu, val=0;
  vtss_fdma_endian_aware_raw_writel(VTSS_DEV_SGMII_MACRO_CFG(VTSS_ALL_PM_NUMBER), 0x16162155);

  if(loopback) {
    vtss_fdma_endian_aware_raw_writel(VTSS_DEV_ADVPORTM(VTSS_ALL_PM_NUMBER), 1);
    vtss_fdma_endian_aware_raw_writel(VTSS_DEV_PCSCTRL(VTSS_ALL_PM_NUMBER), 0x02044001);
  } else {
    vtss_fdma_endian_aware_raw_writel(VTSS_DEV_ADVPORTM(VTSS_ALL_PM_NUMBER), 0);
    vtss_fdma_endian_aware_raw_writel(VTSS_DEV_PCSCTRL(VTSS_ALL_PM_NUMBER), 0x02004001);
  }
  
  vtss_fdma_endian_aware_raw_writel(VTSS_DEV_MAC_CFG(VTSS_ALL_PM_NUMBER), 0x10070181);
  vtss_fdma_endian_aware_raw_writel(VTSS_DEV_SGMII_MACRO_CMU_TEST_CTRL(VTSS_ALL_PM_NUMBER), 0x201); // IB_A&B_COMMONMODE_VOLTAGE_SEL=1

  // Gotta tell the queue systems to allow frames of size MTU
  vtss_fdma_endian_aware_raw_writel(VTSS_DEV_MAXLEN(VTSS_ALL_PM_NUMBER), mtu);

  // In order to guarantee injection some room in the CPU PM, we need
  // to enable dropping of frames going to the extraction queues, and
  // lower the total amount of RAM that they (the extraction queues
  // can consume).
  // By setting Q_EGRESS_WM_Q[3:0] to 12, the four extraction queues
  // can at most consume 2*12 + one MTU = 24 + MTU Kbytes. Let's call
  // this number 'X'. Since the queue system is 48 KBytes, this will
  // leave 48 - X KBytes for the injection queue.
  vtss_fdma_endian_aware_raw_writel(VTSS_DEV_MISCCFG(VTSS_CPU_PM_NUMBER), vtss_fdma_endian_aware_raw_readl(VTSS_DEV_MISCCFG(VTSS_CPU_PM_NUMBER)) | VTSS_F_EGRESSDROP_ENABLE);
  for(qu=0; qu<VTSS_FDMA_XTR_QU_CNT; qu++)
    val |= VTSS_F_Q_EGRESS_WM(qu,12);
  vtss_fdma_endian_aware_raw_writel(VTSS_DEV_Q_EGRESS_WM(VTSS_CPU_PM_NUMBER), val);

  vtss_fdma_endian_aware_raw_writel(VTSS_DEV_Q_MISC_CONF(VTSS_CPU_PM_NUMBER), vtss_fdma_endian_aware_raw_readl(VTSS_DEV_Q_MISC_CONF(VTSS_CPU_PM_NUMBER)) | VTSS_F_Q_MISC_CONF_IMIN(2));
  
  if(!dont_update_crc)
    // Set the PMs to update the CRC on CPU-injected frames.
    vtss_fdma_endian_aware_raw_writel(VTSS_DEV_TXUPDCFG(VTSS_ALL_PM_NUMBER), 2);
  else
    // Enforce transmission of framew with bad CRC.
    vtss_fdma_endian_aware_raw_writel(VTSS_DEV_CAT_DROP(VTSS_ALL_PM_NUMBER), 0x21);
}

/*****************************************************************************/
/*****************************************************************************/
void val_fdma_ana_cfg(void)
{
  int p=0;

  // Capture everything, and let it go to the default queue (0).
  vtss_fdma_endian_aware_raw_writel(VTSS_ANA_CAPENAB, 0xFFFFFFFF);
  
  // Get all traffic from all ports.
  for(p=0; p<VTSS_PHYS_PORT_CNT; p++)
    vtss_fdma_endian_aware_raw_writel(VTSS_ANA_SRCMASKS(p), vtss_fdma_endian_aware_raw_readl(VTSS_ANA_SRCMASKS(p)) | 0x40000000);
}

/*****************************************************************************/
/*****************************************************************************/
static void val_fdma_irq_hndl(void)
{
  // Clear bit in mask => disabled
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_MASK_CLR, 1<<VTSS_FDMA_IRQ);

  // Call the FDMA IRQ handler
  vtss_fdma_irq_handler(NULL);

  // Clear and re-enable interrupts
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_CLR,      1<<VTSS_FDMA_IRQ);
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_MASK_SET, 1<<VTSS_FDMA_IRQ);
}

/*****************************************************************************/
// Reserve a transmit buffer for the channel.
// This function is NOT re-entrant, but works fine with asynchronous
// release of buffers (in val_fdma_on_tx_packet()).
// We only need to protect the bufs_left from interrupts.
/*****************************************************************************/
vtss_fdma_list_head_t *val_fdma_get_inj_buffers(int ch, int cnt)
{
  int bufs_left;
  val_fdma_ch_cfg_t *ch_cfg;
  int head_idx, idx, next_idx, i, buf_cnt;

  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);

  ch_cfg = &val_fdma_priv.ch_cfg[ch];

  VTSS_FDMA_ASSERT(cnt>0 && cnt<=ch_cfg->buf_cnt); // Must reserve at least one and at most the configured number of buffers
  VTSS_FDMA_ASSERT(ch_cfg->usage==VTSS_FDMA_CH_USAGE_INJ);
  buf_cnt = ch_cfg->buf_cnt;
  bufs_left=atomic_read(&ch_cfg->bufs_left);
  if(bufs_left<cnt)
    return NULL; // Not enough buffers left

  // Get an index to the first free buffer.
  head_idx = idx = ch_cfg->ring_head;

  // Chain the requested buffers.
  for(i=0; i<cnt-1; i++) {
    next_idx=next_tx(idx, buf_cnt);
    ch_list[ch][idx].next = &ch_list[ch][next_idx];
    // Some of the TCs may actually change the data field
    // so that it can be tested that the FDMA can cope with
    // strangely offset data. The only way these TCs may
    // change the data offsets is by adding 1, 2, or 3
    // to the data field's value. And it's only a concern
    // if the buffers are being reused, that is, if the list
    // wraps. Therefore we simply clear out the 2 LSbits of
    // the data field here.
    ch_list[ch][idx].data = (u8 *)((u32)ch_list[ch][idx].data & ~0x3);
    idx=next_idx;
  }
  // Terminate the last.
  ch_list[ch][idx].next=NULL;
  ch_list[ch][idx].data = (u8 *)((u32)ch_list[ch][idx].data & ~0x3);

  // Reduce the number of buffers left
  atomic_sub(&ch_cfg->bufs_left, cnt);

  // And set the new head of ring.
  ch_cfg->ring_head = next_tx(idx, buf_cnt);
  
  return &ch_list[ch][head_idx];
}

/*****************************************************************************/
// val_fdma_xtr_cfg()
/*****************************************************************************/
void val_fdma_xtr_cfg(int ena, int ch, int qu, int buf_cnt, int start_gap, int end_gap, void (*xtr_cb)(vtss_fdma_list_head_t *list, int qu))
{
  val_fdma_ch_cfg_t *ch_cfg;

  // Valid channel?
  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);
  ch_cfg=&val_fdma_priv.ch_cfg[ch];

  if(ena) {
    // Check parameters and the current state
    VTSS_FDMA_ASSERT(buf_cnt>0 && buf_cnt<=MAX_CH_BUF_CNT);
    VTSS_FDMA_ASSERT(qu>=0 && qu<VTSS_FDMA_XTR_QU_CNT);
    VTSS_FDMA_ASSERT(ch_cfg->ena==0);
    VTSS_FDMA_ASSERT(ch_cfg->usage==VTSS_FDMA_CH_USAGE_UNUSED);
    ch_cfg->start_gap = start_gap;
    ch_cfg->end_gap   = end_gap;
    ch_cfg->buf_cnt   = buf_cnt;
    ch_cfg->ena       = 1;
    ch_cfg->usage     = VTSS_FDMA_CH_USAGE_XTR;
    ch_cfg->xtr_cb    = xtr_cb;
    ch_cfg->qu        = qu;
    xtr_qu2ch[qu]     = ch;
    val_fdma_load_rx_ring(ch);
  } else {
    VTSS_FDMA_ASSERT(ch_cfg->ena==1);
    VTSS_FDMA_ASSERT(ch_cfg->usage==VTSS_FDMA_CH_USAGE_XTR);
    val_fdma_flush_rx_ring(ch);
    ch_cfg->ena=0;
    ch_cfg->usage=VTSS_FDMA_CH_USAGE_UNUSED;
 }
}

/*****************************************************************************/
// val_fdma_inj_cfg()
/*****************************************************************************/
void val_fdma_inj_cfg(int ena, int ch, int buf_cnt)
{
  val_fdma_ch_cfg_t *ch_cfg;

  // Valid channel?
  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);
  ch_cfg=&val_fdma_priv.ch_cfg[ch];
  
  if(ena) {
    // Check parameters and the current state
    VTSS_FDMA_ASSERT(buf_cnt>0 && buf_cnt<=MAX_CH_BUF_CNT);
    VTSS_FDMA_ASSERT(ch_cfg->ena==0);
    VTSS_FDMA_ASSERT(ch_cfg->usage==VTSS_FDMA_CH_USAGE_UNUSED);
    ch_cfg->buf_cnt         = buf_cnt;
    ch_cfg->ena             = 1;
    ch_cfg->usage           = VTSS_FDMA_CH_USAGE_INJ;
    val_fdma_load_tx_ring(ch);
  } else {
    VTSS_FDMA_ASSERT(ch_cfg->ena==1);
    VTSS_FDMA_ASSERT(ch_cfg->usage==VTSS_FDMA_CH_USAGE_INJ);
    val_fdma_flush_tx_ring(ch);
    ch_cfg->ena=0;
    ch_cfg->usage=VTSS_FDMA_CH_USAGE_UNUSED;
  }
}

/*****************************************************************************/
// val_fdma_init()
/*****************************************************************************/
int val_fdma_init(void)

{
  VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_GNRL_SPARSE, "val_fdma_init()\n");

  // Set-up interrupt stuff
  // Disable all interrupts
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_MASK,0);
  // Clear any pending interrupts
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_CLR, vtss_fdma_endian_aware_raw_readl(VTSS_INTR_STATUS));
  // Enable global intrs
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_CTRL, vtss_fdma_endian_aware_raw_readl(VTSS_INTR_CTRL) | VTSS_F_GLBL_IRQ_ENA);

  // Hook the IRQ interrupt.
  intr_hook(itIRQ, val_fdma_irq_hndl);

  // Enable the FDMA interrupt
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_MASK_SET, 1<<VTSS_FDMA_IRQ);
  
  // Enable interrupts in CPU
  intr_ena(itIRQ);

  VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_GNRL_VERBOSE, "Interrupt requested\n");
  VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_GNRL_VERBOSE, "FDMA initialized\n");
  VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_GNRL_VERBOSE, "Ports initialized\n");

  if(!vtss_fdma_init())
    return VTSS_FDMA_GNRL_ERR; // Version failure.

  return VTSS_FDMA_NOERR;
}

/*****************************************************************************/
//  val_fdma_uninit()
//  User configuring the FDMA down
/*****************************************************************************/
void val_fdma_uninit(void)
{
  int ch;
  val_fdma_ch_cfg_t *ch_cfg;

  // Disable FDMA
  vtss_fdma_uninit();

  // Disable interrupts
  intr_dis(itIRQ);

  // Let go of the interrupt
  intr_unhook(itIRQ);

  VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_GNRL_VERBOSE, "val_fdma_uninit()\n");

  for(ch=0; ch<VTSS_FDMA_CH_CNT; ch++) {
    ch_cfg=&val_fdma_priv.ch_cfg[ch];
    if(ch_cfg->ena) {
      VTSS_FDMA_ASSERT(ch_cfg->usage==VTSS_FDMA_CH_USAGE_XTR || ch_cfg->usage==VTSS_FDMA_CH_USAGE_INJ);
      if(ch_cfg->usage==VTSS_FDMA_CH_USAGE_XTR) {
        val_fdma_xtr_cfg(0, ch, 0, 0, 0, 0, NULL); // Disable channel and flush rx ring
      } else {
        val_fdma_inj_cfg(0, ch, 0);
      }
    }
  }
}

/*****************************************************************************/
// val_fdma_port_init()
/*****************************************************************************/
void val_fdma_port_init(int mtu, int loopback, int dont_update_crc)
{
  val_fdma_port_cfg(mtu, loopback, dont_update_crc);
  val_fdma_ana_cfg();
}

/*****************************************************************************/
//
// End of file
//
//****************************************************************************/
