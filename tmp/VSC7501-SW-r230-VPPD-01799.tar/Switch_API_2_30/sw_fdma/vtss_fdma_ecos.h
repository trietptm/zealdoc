/*
 
 Vitesse Switch Software.
 
 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/
#ifndef VTSS_FDMA_ECOS_H
#define VTSS_FDMA_ECOS_H

// This file defines support functions for the FDMA when run under eCos.

#include <cyg/infra/cyg_type.h>
#include <cyg/infra/cyg_ass.h>
#include <cyg/infra/diag.h>
#include <cyg/hal/hal_arch.h>
#include <cyg/hal/hal_cache.h>
#include <cyg/hal/hal_io.h>
#include <cyg/hal/hal_intr.h>
#include <cyg/kernel/kapi.h>
#include <string.h>             /* for memset() */
#include "vtss_switch_api.h"

typedef cyg_uint32 u32;
typedef cyg_uint16 u16;
typedef cyg_uint8  u8;

// These come from vtss_options.h:
#define VTSS_FDMA_STACK_PORT_A_MASK VTSS_OPT_STACK_A_MASK
#define VTSS_FDMA_STACK_PORT_B_MASK VTSS_OPT_STACK_B_MASK

#define vtss_fdma_raw_writel(a, v) ((a) = (v))
#define vtss_fdma_raw_readl(a)     (a)

// Assert and debug print functions
#ifdef VTSS_FDMA_DBG
  #define VTSS_FDMA_DBG_MSG(lvl, format, args...)     diag_printf("VTSS_FDMA: " format, ##args)
  #define VTSS_FDMA_ASSERT(expr)                      {if(!(expr)) {diag_printf("VTSS_FDMA assert: " # expr);  VTSS_ASSERT(expr);}}
  #define VTSS_FDMA_ASSERT_MSG(expr, format, args...) {if(!(expr)) {diag_printf("VTSS_FDMA: " format, ##args); VTSS_FDMA_ASSERT(expr);}}
#else
  #define VTSS_FDMA_DBG_MSG(lvl, format, args...)     
  #define VTSS_FDMA_ASSERT(expr)                      VTSS_ASSERT(expr)
  #define VTSS_FDMA_ASSERT_MSG(expr, format, args...) VTSS_ASSERT(expr)
#endif

#define VTSS_FDMA_VIRT_TO_PHYS(addr)                      (u32)(addr)
#define VTSS_FDMA_INVALIDATE_DCACHE_DCB(virt_addr, size)  HAL_DCACHE_INVALIDATE(virt_addr, size)
#define VTSS_FDMA_INVALIDATE_DCACHE_DATA(virt_addr, size) HAL_DCACHE_INVALIDATE(virt_addr, size)
#define VTSS_FDMA_FLUSH_DCACHE_DCB(virt_addr, size)       HAL_DCACHE_STORE(virt_addr, size)
#define VTSS_FDMA_FLUSH_DCACHE_DATA(virt_addr, size)      HAL_DCACHE_STORE(virt_addr, size)
#define VTSS_FDMA_INTERRUPT_FLAGS                         cyg_uint32 CYGBLD_ATTRIB_USED

// vtss_fdma_irq_handler() is called from thread context or DSR context in eCos.
// When this is the case, we should force the scheduler not to change task
// when VTSS_FDMA_DISABLE_INTERRUPTS() is called.
// If vtss_fdma_irq_handler() was called from interrupt context, the
// VTSS_FDMA_DISABLE_INTERRUPTS() should disable interrupts *AND*
// if the code is multi-threaded also disable the scheduler.
#define VTSS_FDMA_DISABLE_INTERRUPTS(flags)               cyg_scheduler_lock()
#define VTSS_FDMA_RESTORE_INTERRUPTS(flags)               cyg_scheduler_unlock()
#define VTSS_FDMA_BARRIER()                               HAL_REORDER_BARRIER()
#define VTSS_FDMA_MEMSET(s, c, n)                         memset((s),(c),(n))

// We want to keep statistics
#define VTSS_FDMA_KEEP_STATISTICS

#endif // VTSS_FDMA_ECOS_H

//############################################################################
//                                                                           #
// End of file.                                                              #
//                                                                           #
//############################################################################

