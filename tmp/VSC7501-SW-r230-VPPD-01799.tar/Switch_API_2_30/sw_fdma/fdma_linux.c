/*
 
 Vitesse Switch Software.
 
 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/
/*****************************************************************************/
// fdma_linux.c
//*****************************************************************************/
#include <linux/module.h>
#include <linux/errno.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/if_ether.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/fcntl.h>
#include <linux/interrupt.h>
#include <linux/ioport.h>
#include <linux/in.h>
#include <linux/skbuff.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/wait.h>
#include <linux/ethtool.h>
#include <linux/completion.h>
#include <linux/bitops.h>
#include <linux/jiffies.h>
#include <asm/io.h>
#include <asm/hardware.h> /* For VTSS_* registers */

// Include the internal FDMA implementation.
// #define FDMA_DBG
#define FDMA_LINUX
#include "fdma.c"

#define DRV_NAME    "vtss_fdma"
#define DRV_VERSION "0.1"
#define DRV_RELDATE "200608xx"

#define FCS_SIZE_BYTES 4 /* For some reason, this isn't defined anywhere (I can't find it at least) in the Linux source */

// Intrinsically, the device doesn't have it's own MAC address, so we assign a bogus one.
static const unsigned char bogus_mac_addr[]={0x02, 0x03, 0x04, 0x05, 0x06, 0x07};

#ifdef FDMA_DBG
  static const char *version = DRV_NAME ".c: v" DRV_VERSION " " DRV_RELDATE " <rbn@vitesse.com>\n";
  // Debugging stuff. Allows for dynamic setting of debugging level.
  // static int dbg_msk = FDMA_DBG_XTR_VERBOSE | FDMA_DBG_XTR_SPARSE | FDMA_DBG_INJ_VERBOSE | FDMA_DBG_INJ_SPARSE | FDMA_DBG_GNRL_VERBOSE | FDMA_DBG_GNRL_SPARSE;
  // static int dbg_msk = FDMA_DBG_XTR_SPARSE | FDMA_DBG_INJ_SPARSE;
  static int dbg_msk = 0;
  module_param(dbg_msk, int, FDMA_DBG_XTR_SPARSE | FDMA_DBG_INJ_SPARSE | FDMA_DBG_GNRL_SPARSE);
  MODULE_PARM_DESC(dbg_msk, "FDMA debug mask");
#endif

static int already_initialized=0;
static inline int next_tx(int tx, int buf_cnt) { return ((tx+1)%buf_cnt); };

// Given a port, which channel should the frame get injected via?
static int inj_port2ch[VTSS_TOTAL_PORT_CNT];

// Which channel is associated with a given queue?
static int xtr_qu2ch[FDMA_XTR_QU_CNT];

/*****************************************************************************/
/*****************************************************************************/
typedef struct
{
  int start_gap; // XTR only
  int end_gap;   // XTR only
  int qu;        // XTR only. The queue that this channel serves.
  int buf_cnt;
  int ena;
  int usage;
  fdma_list_head_t *list;
  atomic_t bufs_left; /* INJ only. Tx buffers left */
  atomic_t ring_head; /* INJ only. Index into list to enqueue the next packet */
} linux_fdma_ch_cfg_t;

/*****************************************************************************/
/*****************************************************************************/
typedef struct
{
  linux_fdma_ch_cfg_t ch_cfg[FDMA_CH_CNT];
  int inj_port;                  // The port number that we inject frames through?
  int inj_switch_frm;            // Only valid if sending packet on CPU port module
  int inj_port_mask;             // Mask to use if not switching packets, but sending to CPU port module
  int inj_vlan;                  // Which VLAN to use?               

#ifdef FDMA_XTR_TEST
  unsigned long first_rx;        // Holds the jiffies of the first received packet.
#endif

  struct net_device *dev;
  struct net_device_stats net_stats;
} linux_fdma_priv_t;

/*****************************************************************************/
/*****************************************************************************/
#if defined(FDMA_LOOPBACK_TEST) || defined(FDMA_INJ_TEST)
// Pre-declare the function we pass the frame back to in loopback mode:
static int linux_fdma_hard_start_xmit(struct sk_buff *skb, struct net_device *dev);
static fdma_list_head_t *linux_fdma_on_rx_packet(void *cntxt, fdma_list_head_t *list, int qu)
{
  struct sk_buff *new_skb, *skb;
  struct net_device *dev;
  int act_frm_len, skip_bytes;
  linux_fdma_priv_t *priv;
  linux_fdma_ch_cfg_t *ch_cfg;

  FDMA_DBG_MSG(FDMA_DBG_XTR_VERBOSE, "linux_fdma_on_rx_packet()\n");

  skb=list->user;
  dev=skb->dev;
  priv=netdev_priv(dev);
  ch_cfg=&priv->ch_cfg[xtr_qu2ch[qu]];

  FDMA_ASSERT(ch_cfg->usage==FDMA_CH_USAGE_XTR);

  // We don't support gaps in the loopback test.
  FDMA_ASSERT(ch_cfg->start_gap==0 && ch_cfg->end_gap==0);

  skip_bytes = FDMA_IFH_SIZE_BYTES;

  if(list->next==NULL)
  {
    // We can allocate a new one and return it in place of the one
    // we loopback to the front-port.
    // When in loopback mode, also allocate room for the CMD field, because this
    // SKB is eventually re-injected.
    new_skb=alloc_skb(list->alloc_len_or_port+FDMA_CMD_SIZE_BYTES, GFP_ATOMIC);
    if(new_skb==NULL) {
      priv->net_stats.rx_dropped++;
      printk(KERN_ERR "%s: XTR: Unable to allocate an SKB for a new frame\n",dev->name);
      // Reset current skb, which is linked to in list.
      skb->len=0;
      skb->tail=skb->data;
      return list;
    }

    // Prepare the new_skb to be inserted back into the list
    new_skb->dev=dev;
    skb_reserve(new_skb, FDMA_CMD_SIZE_BYTES);
    list->data=new_skb->data;
    list->user=new_skb;

    // Prepare the received skb to be sent to the front-port
    FDMA_ASSERT(skb->len==0);
    act_frm_len=list->act_len - skip_bytes;
    FDMA_ASSERT(act_frm_len>=ETH_ZLEN+4); // ETH_ZLEN == 60, i.e. min ethernet frame size without FCS
    // Advance skb->len and skb->tail
    skb_put(skb, act_frm_len);
    // Skip across the IFH and start gap.
    skb_reserve(skb, skip_bytes);
    // The upper layers expect the FCS not to be present, so 
    // remove it. skb_trim(skb, len) sets skb->len to len and adjusts skb->tail accordingly
    skb_trim(skb, skb->len-FCS_SIZE_BYTES);
    // When looping back, don't call eth_type_trans(), since that will
    // subtract ETH_HLEN (14 bytes) from the length and move skb->data ETH_HLEN bytes forward.
    // This is normally needed before passing the packet up to the generic packet received, but
    // in our case (loopback test), we pass it on to linux_fdma_hard_start_xmit(), which
    // expects skb->data to point to the first byte in the DMAC.
    // skb->protocol=eth_type_trans(skb,dev);
  } else {
    printk("No support for fragmented frames in loopback or injection test-mode\n");
    FDMA_ASSERT(0);
    return list;
  }

  dev->last_rx = jiffies;
  priv->net_stats.rx_packets++;
  FDMA_DBG_MSG(FDMA_DBG_XTR_VERBOSE, "OnRxPacket(q=%d, #=%lu)\n", qu, priv->net_stats.rx_packets);
  priv->net_stats.rx_bytes += act_frm_len;
  FDMA_DBG_MSG(FDMA_DBG_XTR_VERBOSE, "  Looping back, hence calling hard_start_xmit()\n");
  // In order not to consume too much memory in cases where the injector overflows, we
  // should release the skb.
  if(linux_fdma_hard_start_xmit(skb, dev))
    kfree_skb(skb); // Error.
  FDMA_DBG_MSG(FDMA_DBG_XTR_VERBOSE, "  Done()\n");
  return list;
}
#endif

/*****************************************************************************/
// Called back by fdma.c
// @list: Contains a pointer to the fdma_list_head containing one single
//        packet. In case of a jumbo frame whose size is bigger than ->len,
//        the next pointer is a pointer to the next part of the frame.
// We are expected to return a new valid list that can be inserted in place
// of the one we just got.
/*****************************************************************************/
#ifdef FDMA_XTR_TEST
static fdma_list_head_t *linux_fdma_on_rx_packet(void *cntxt, fdma_list_head_t *list, int qu)
{
  struct net_device *dev;
  linux_fdma_priv_t *priv;

  FDMA_DBG_MSG(FDMA_DBG_XTR_VERBOSE, "linux_fdma_on_rx_packet()\n");

  if(list->next!=NULL) {
    printk("No support for fragmented frames in extraction testmode\n");
    FDMA_ASSERT(0);
    return list;
  }

  // Update some housekeeping
  dev = ((struct sk_buff *)list->user)->dev;
  priv = netdev_priv(dev);
  dev->last_rx = jiffies;

  // To be able to compute the rate, we need the time that the first packet arrived.
  if(priv->net_stats.rx_packets==0)
    priv->first_rx = jiffies;
    
  priv->net_stats.rx_packets++;
  priv->net_stats.rx_bytes += (list->act_len - FDMA_IFH_SIZE_BYTES);

  // We don't even have to update the SKBs, since them themselves are not touched.
  return list;
}
#endif

/*****************************************************************************/
// Called back by fdma.c
// @list: Contains a pointer to the fdma_list_head containing one single
//        packet. In case of a jumbo frame whose size is bigger than ->len,
//        the next pointer is a pointer to the next part of the frame.
// We are expected to return a new valid list that can be inserted in place
// of the one we just got.
/*****************************************************************************/
#if !defined(FDMA_LOOPBACK_TEST) && !defined(FDMA_XTR_TEST) && !defined(FDMA_INJ_TEST)
static fdma_list_head_t *linux_fdma_on_rx_packet(void *cntxt, fdma_list_head_t *list, int qu)
{
  struct sk_buff *new_skb, *skb;
  struct net_device *dev;
  int    act_frm_len, skip_bytes;
  linux_fdma_priv_t *priv;
  linux_fdma_ch_cfg_t *ch_cfg;
  fdma_list_head_t *l;

  FDMA_DBG_MSG(FDMA_DBG_XTR_VERBOSE, "linux_fdma_on_rx_packet()\n");

  skb=list->user;
  dev=skb->dev;
  priv=netdev_priv(dev);
  ch_cfg=&priv->ch_cfg[xtr_qu2ch[qu]];
  FDMA_ASSERT(ch_cfg->usage==FDMA_CH_USAGE_XTR);

  skip_bytes = FDMA_IFH_SIZE_BYTES + 4*ch_cfg->start_gap;

  if(list->next==NULL)
  {
    // The frame only takes one entry in the list.
#ifdef FDMA_XTR_ALIGN_PROTOCOL_HDR_ON_32BIT_BOUNDARY
    // By default, the protocol header is aligned on a 16-bit boundary, because
    // the DMAC, SMAC and Type/Length fields take up 14 bytes, and because the
    // DMAC starts on a 32-bit boundary. This is not working with Linux, because
    // it puts a structure on top of the beginning of the protocol header, which
    // is 32-bit aligned. This causes all data to be shifted by 2 bytes when accessing
    // the structure members. The FDMA is not capable of putting the data in any other
    // way than it does.
    // Therefore, we must to a copy here, where we allocate a new SKB and copy the
    // data in such a way that the protocol header gets dword-aligned.
    act_frm_len=list->act_len - skip_bytes - FCS_SIZE_BYTES; // Don't copy the FCS
    FDMA_ASSERT(act_frm_len>=ETH_ZLEN); // ETH_ZLEN == 60, i.e. min ethernet frame size without FCS
    new_skb=alloc_skb(act_frm_len+2, GFP_ATOMIC);
    if(new_skb==NULL) {
      priv->net_stats.rx_dropped++;
      printk(KERN_ERR "%s: Unable to allocate an SKB for a new frame\n",dev->name);
      // Reset current skb, which is linked to in list.
      skb->len=0;
      skb->tail=skb->data;
      return list;
    }

    // Prepare the new_skb to be sent to the generic packet receiver.
    new_skb->dev=dev;
    skb_reserve(new_skb, 2); // NET_IP_ALIGN
    // The skb_put() function increases skb->tail and skb->len by act_frm_len and returns the original skb->tail.
    memcpy(skb_put(new_skb, act_frm_len), skb->data+skip_bytes, act_frm_len);
    // Update skb->protocol, skb->pkt_type, and skb->mac.raw
    new_skb->protocol=eth_type_trans(new_skb,dev);

    // Reset the old skb, which is the one we pass back to the caller of us
    // The skb->head is pointing correctly already.
    skb->len=0;
    skb->tail=skb->data;

    // The code below sends the variable "skb" up the food chain, and we
    // have the frame in "new_skb", so we better switch pointer.
    skb = new_skb;
#else
    // We can allocate a new one and return it in place of the one
    // we pass up the food chain.
    new_skb=alloc_skb(list->alloc_len_or_port, GFP_ATOMIC);
    if(new_skb==NULL) {
      priv->net_stats.rx_dropped++;
      printk(KERN_ERR "%s: XTR: Unable to allocate an SKB for a new frame\n",dev->name);
      // Reset current skb, which is linked to in list.
      skb->len=0;
      skb->tail=skb->data;
      return list;
    }

    // Prepare the new_skb to be inserted back into the list
    new_skb->dev=dev;
    list->data=new_skb->data;
    list->user=new_skb;

    // Prepare the received skb to be sent to the generic packet receiver
    FDMA_ASSERT(skb->len==0);
    act_frm_len=list->act_len - skip_bytes;
    FDMA_ASSERT(act_frm_len>=ETH_ZLEN+4); // ETH_ZLEN == 60, i.e. min ethernet frame size without FCS
    // Advance skb->len and skb->tail
    skb_put(skb, act_frm_len);
    // Skip across the IFH and start gap.
    skb_reserve(skb, skip_bytes);
    // The upper layers expect the FCS not to be present, so 
    // remove it. skb_trim(skb, len) sets skb->len to len and adjusts skb->tail accordingly
    skb_trim(skb, skb->len-FCS_SIZE_BYTES);
    // Update skb->protocol, skb->pkt_type, and skb->mac.raw
    skb->protocol=eth_type_trans(skb,dev);
#endif
  } else {
    // Jumbo frame. We need to allocate new SKBs and copy from the existing
    // Find the actual frame length
    l=list;
    act_frm_len=0;
    while(l) {
      act_frm_len+=l->act_len;
      l=l->next;
    }
    
    // Allocate one single SKB holding the whole frame.
    skb=alloc_skb(act_frm_len, GFP_ATOMIC);
    if(skb==NULL) {
      priv->net_stats.rx_dropped++;
      printk(KERN_ERR "%s: XTR: Unable to allocate an SKB for a new jumbo frame\n",dev->name);
      return list;
    } else {
      skb->protocol=eth_type_trans(skb,dev);
      skb->dev=dev;
      l=list;
      while(l) {
        memcpy(skb_put(skb, l->act_len), l->data, l->act_len);
        l=l->next;
      }
      // Skip the IFH and start gap
      skb_reserve(skb, skip_bytes);
    }
  }

  dev->last_rx = jiffies;
  priv->net_stats.rx_packets++;
  FDMA_DBG_MSG(FDMA_DBG_XTR_SPARSE, "OnRxPacket(q=%d, #=%lu)\n",qu, priv->net_stats.rx_packets);
  priv->net_stats.rx_bytes += act_frm_len;
  FDMA_DBG_MSG(FDMA_DBG_XTR_VERBOSE, "  Calling netif_rx()\n");
  netif_rx(skb);
  FDMA_DBG_MSG(FDMA_DBG_XTR_VERBOSE, "  Done()\n");
  return list;
}
#endif

/*****************************************************************************/
// Called back by fdma.c when a packet has been transmitted.
/*****************************************************************************/
#ifdef FDMA_INJ_TEST
void linux_fdma_on_tx_packet(void *cntxt, fdma_list_head_t *list, int ch, int dropped)
{
  struct sk_buff *skb;
  linux_fdma_priv_t *priv;
  linux_fdma_ch_cfg_t *ch_cfg;
  int    act_frm_len;

  FDMA_DBG_MSG(FDMA_DBG_INJ_VERBOSE, "linux_fdma_on_tx_packet()\n");

  FDMA_ASSERT(list)
  act_frm_len = list->act_len - FDMA_IFH_SIZE_BYTES - FDMA_CMD_SIZE_BYTES;
  FDMA_ASSERT(act_frm_len>=FDMA_MIN_FRAME_SIZE_BYTES);
  FDMA_ASSERT(list->user);
  skb=list->user;
  priv=netdev_priv(skb->dev);
  if(dropped) {
    priv->net_stats.tx_dropped++;
  } else {
    priv->net_stats.tx_packets++;
    priv->net_stats.tx_bytes += act_frm_len;
  }
  ch_cfg = &priv->ch_cfg[ch];

  // Tell it which function to callback when done.
  list->inj_cb=linux_fdma_on_tx_packet;

  // Re-initiate the injection. This also initializes the IFH and CMD fields.
  fdma_inj(list, ch, act_frm_len, priv->inj_switch_frm ? FDMA_INJ_OPT_SWITCH_FRM : 0, priv->inj_port_mask, priv->inj_vlan);
}
#endif

/*****************************************************************************/
// Called back by fdma.c when a packet has been transmitted.
/*****************************************************************************/
#ifndef FDMA_INJ_TEST
void linux_fdma_on_tx_packet(void *cntxt, fdma_list_head_t *list, int ch, int dropped)
{
  struct sk_buff *skb;
  linux_fdma_priv_t *priv;
  linux_fdma_ch_cfg_t *ch_cfg;
  int    act_frm_len;

  FDMA_DBG_MSG(FDMA_DBG_INJ_VERBOSE, "linux_fdma_on_tx_packet()\n");

  FDMA_ASSERT(list)
  FDMA_ASSERT(list->user);
  act_frm_len = list->act_len - FDMA_IFH_SIZE_BYTES - FDMA_CMD_SIZE_BYTES;
  FDMA_ASSERT(act_frm_len>=FDMA_MIN_FRAME_SIZE_BYTES);
  FDMA_ASSERT(ch>=0 && ch<FDMA_CH_CNT);

  skb=list->user;
  priv=netdev_priv(skb->dev);

  if(dropped) {
    priv->net_stats.tx_dropped++;
  } else {
    priv->net_stats.tx_packets++;
    priv->net_stats.tx_bytes += act_frm_len;
  }
  ch_cfg = &priv->ch_cfg[ch];
  FDMA_ASSERT(ch_cfg->usage==FDMA_CH_USAGE_INJ);
  atomic_inc(&ch_cfg->bufs_left);
  // This is to avoid a BUG_ON(in_irq()) when kfree_skb() calls skb->destructor()
  // The destructor is protocol-dependant, so it might be that I break someones
  // code. I don't know how to call the destructor from another place than
  // in IRQ context.
  skb->destructor=NULL;
  kfree_skb(skb);
  FDMA_DBG_MSG(FDMA_DBG_INJ_VERBOSE, "OnTxPacket(p=%d, #=%lu)\n", list->alloc_len_or_port, priv->net_stats.tx_packets);
}
#endif

/*****************************************************************************/
/*****************************************************************************/
static int linux_fdma_load_rx_ring(struct net_device *dev, int ch)
{
  int i, buf_cnt;
  unsigned data_len_bytes, alloc_len_bytes;
  struct sk_buff *skb;
  linux_fdma_priv_t *priv = netdev_priv(dev);
  linux_fdma_ch_cfg_t *ch_cfg = &priv->ch_cfg[ch];
  fdma_list_head_t *xtr_list;

  FDMA_ASSERT(ch>=0 && ch<FDMA_CH_CNT);
  FDMA_ASSERT(ch_cfg->usage==FDMA_CH_USAGE_XTR);
  buf_cnt = ch_cfg->buf_cnt;

  // Allocate the ring structures needed by fdma.c
  xtr_list = kmalloc(buf_cnt*sizeof(fdma_list_head_t), GFP_KERNEL);

  // The length of a DCB's associated data area is the MTU + the IFH size + 
  // the start and end gap sizes, but it cannot exceed FDMA_MAX_DATA_PER_DCB_BYTES.
  data_len_bytes = min(dev->mtu + 4*ch_cfg->start_gap + FDMA_IFH_SIZE_BYTES + 4*ch_cfg->end_gap, (unsigned)FDMA_MAX_DATA_PER_DCB_BYTES);
  data_len_bytes = max(data_len_bytes, (unsigned)FDMA_MIN_DATA_PER_XTR_SOF_DCB_BYTES);

  // Besides the associated data, we also allocate room for a pointer to struct net_device *dev and the H/W DCB.
  // When looping back, we need to allocate room for the CMD field as well, because the packet to be looped back
  // is received into such an extraction DCB. When it's being transmitted, there has to be room in front of the
  // packet for both DCB, IFH, and CMD. When not running in this special loopback mode, it's the upper protocol
  // layers that allocate the buffers, and it takes care of reserving dev->hard_header_len bytes in front of the
  // frame.
#if defined(FDMA_LOOPBACK_TEST) || defined(FDMA_INJ_TEST)
  alloc_len_bytes = FDMA_CMD_SIZE_BYTES + data_len_bytes;
#else
  alloc_len_bytes =                       data_len_bytes;
#endif  

  // Chain it together while allocating skbs for the data.
  for(i=0; i<buf_cnt; i++)
  {
    // Allocate an SKB
    xtr_list[i].user = skb = alloc_skb(alloc_len_bytes, GFP_KERNEL);
    if(skb == NULL) {
      // Deallocate it all again
      for(; i>=0; i--)
        kfree_skb(xtr_list[i].user);

      // Also deallocate the list itself
      kfree(xtr_list);
      return -ENOBUFS;
    }

    skb->dev = dev;
#if defined(FDMA_LOOPBACK_TEST) || defined(FDMA_INJ_TEST)
    // See comment above.
    skb_reserve(skb, FDMA_CMD_SIZE_BYTES);
#endif
    xtr_list[i].data              = skb->data;
    xtr_list[i].alloc_len_or_port = data_len_bytes;
    xtr_list[i].next              = &xtr_list[i+1];
  }

  // The last entry's next pointer must point to NULL
  xtr_list[buf_cnt-1].next = NULL;

  // Link it to our private data structure.
  ch_cfg->list=xtr_list;

  // Initialize the FDMA with this list, and tell it to
  // call linux_fdma_on_rx_packet() back when a frame has arrived.
  fdma_xtr_cfg(1, ch, ch_cfg->qu, ch_cfg->start_gap, ch_cfg->end_gap, xtr_list, linux_fdma_on_rx_packet);
  return FDMA_NOERR;
}

/*****************************************************************************/
/*****************************************************************************/
static void linux_fdma_flush_rx_ring(struct net_device *dev, int ch)
{
  linux_fdma_priv_t *priv = netdev_priv(dev);
  linux_fdma_ch_cfg_t *ch_cfg = &priv->ch_cfg[ch];
  fdma_list_head_t *l;

  FDMA_ASSERT(ch_cfg->usage==FDMA_CH_USAGE_XTR);
  l = ch_cfg->list;

  while(l) { 
    // Free the SKB
    kfree_skb(l->user);
    l = l->next;
  }
  kfree(ch_cfg->list);
  ch_cfg->list = NULL;
}

/*****************************************************************************/
/*****************************************************************************/
static int linux_fdma_load_tx_ring(struct net_device *dev, int ch)
{ 
  linux_fdma_priv_t *priv = netdev_priv(dev);
  linux_fdma_ch_cfg_t *ch_cfg = &priv->ch_cfg[ch];
  fdma_list_head_t *l;
  int alloc_sz, buf_cnt;
  
  buf_cnt = ch_cfg->buf_cnt;
  alloc_sz = buf_cnt*sizeof(fdma_list_head_t);

  // Allocate the ring structures needed by fdma.c.
  l = kmalloc(alloc_sz, GFP_KERNEL);
  if(!l)
    return -ENOBUFS;

  // Initialize it.
  memset(l, 0, alloc_sz);
  ch_cfg->list = l;

  /* -1 so that ring_head cannot "lap" tail */
  atomic_set(&ch_cfg->bufs_left, buf_cnt-1); 
  atomic_set(&ch_cfg->ring_head, 0); 

  fdma_inj_cfg(1, ch);
  return FDMA_NOERR;
} 

/*****************************************************************************/
/*****************************************************************************/
static void linux_fdma_flush_tx_ring(struct net_device *dev, int ch)
{
  linux_fdma_priv_t *priv = netdev_priv(dev);
  linux_fdma_ch_cfg_t *ch_cfg = &priv->ch_cfg[ch];
  
  FDMA_ASSERT(ch_cfg->usage==FDMA_CH_USAGE_INJ);
  kfree(ch_cfg->list);
  ch_cfg->list = NULL;
  atomic_set(&ch_cfg->bufs_left, 0); 
  atomic_set(&ch_cfg->ring_head, 0); 
}

/*****************************************************************************/
// linux_fdma_set_multicast_list()
// Queue multicast list update
// @dev: The fdma to use
/*****************************************************************************/
static void linux_fdma_set_multicast_list(struct net_device *dev)
{
  FDMA_DBG_MSG(FDMA_DBG_GNRL_VERBOSE, "linux_fdma_set_multicast_list()\n");
}

/*****************************************************************************/
//  linux_fdma_close()
//  User configuring the FDMA down
//  @dev: Device card to shut down
/*****************************************************************************/
static int linux_fdma_close(struct net_device *dev)
{
  linux_fdma_priv_t *priv = netdev_priv(dev);
  linux_fdma_ch_cfg_t *ch_cfg;
  int ch;

  // Disable FDMA
  fdma_uninit();

  // Let go of the interrupt
  free_irq(VCOREII_IRQ_FDMA, dev);

  FDMA_DBG_MSG(FDMA_DBG_GNRL_VERBOSE, "linux_fdma_close()\n");

  netif_stop_queue(dev);

  for(ch=0; ch<FDMA_CH_CNT; ch++) {
    ch_cfg=&priv->ch_cfg[ch];
    if(ch_cfg->ena) {
      FDMA_ASSERT(ch_cfg->usage==FDMA_CH_USAGE_XTR || ch_cfg->usage==FDMA_CH_USAGE_INJ);
      if(ch_cfg->usage==FDMA_CH_USAGE_XTR) {
        linux_fdma_flush_rx_ring(dev, ch);
      } else {
        linux_fdma_flush_tx_ring(dev, ch);
      }
    }
  }

  return 0;
}

/*****************************************************************************/
/*****************************************************************************/
static irqreturn_t linux_fdma_irq_handler(int irq, void *dev_id, struct pt_regs *regs)
{
  fdma_irq_handler(dev_id);
  return IRQ_HANDLED;
}

/*****************************************************************************/
/*****************************************************************************/
static void linux_fdma_maxlen_cfg(int mtu)
{
  fdma_endian_aware_raw_writel(VTSS_DEV_MAXLEN(VTSS_ALL_PM_NUMBER), mtu);
}

/*****************************************************************************/
// linux_fdma_port_cfg()
// Initializes all ports on the DUT to 1G. If FDMA_INIT_PORTS_LOOPBACK is set
// then they're initialized in loopback mode.
/*****************************************************************************/
static void linux_fdma_port_cfg(int mtu)
{
  unsigned int qu, val=0;

  fdma_endian_aware_raw_writel(VTSS_DEV_SGMII_MACRO_CFG(VTSS_ALL_PM_NUMBER), 0x16162155);

#ifdef FDMA_INIT_PORTS_LOOPBACK
  fdma_endian_aware_raw_writel(VTSS_DEV_ADVPORTM(VTSS_ALL_PM_NUMBER), 1);
  fdma_endian_aware_raw_writel(VTSS_DEV_PCSCTRL(VTSS_ALL_PM_NUMBER), 0x02044001);
#else
  fdma_endian_aware_raw_writel(VTSS_DEV_ADVPORTM(VTSS_ALL_PM_NUMBER), 0);
  fdma_endian_aware_raw_writel(VTSS_DEV_PCSCTRL(VTSS_ALL_PM_NUMBER), 0x02004001);
#endif
  
  fdma_endian_aware_raw_writel(VTSS_DEV_MAC_CFG(VTSS_ALL_PM_NUMBER), 0x10070181);
  fdma_endian_aware_raw_writel(VTSS_DEV_SGMII_MACRO_CMU_TEST_CTRL(VTSS_ALL_PM_NUMBER), 0x201); // IB_A&B_COMMONMODE_VOLTAGE_SEL=1

  linux_fdma_maxlen_cfg(mtu);

  // In order to guarantee injection some room in the CPU PM, we need
  // to enable dropping of frames going to the extraction queues, and
  // lower the total amount of RAM that they (the extraction queues
  // can consume).
  // By setting Q_EGRESS_WM_Q[3:0] to 12, the four extraction queues
  // can at most consume 2*12 + one MTU = 24 + MTU Kbytes. Let's call
  // this number 'X'. Since the queue system is 48 KBytes, this will
  // leave 48 - X KBytes for the injection queue.
  fdma_endian_aware_raw_writel(VTSS_DEV_MISCCFG(VTSS_CPU_PM_NUMBER), fdma_endian_aware_raw_readl(VTSS_DEV_MISCCFG(VTSS_CPU_PM_NUMBER)) | VTSS_F_EGRESSDROP_ENABLE);

  for(qu=0; qu<FDMA_XTR_QU_CNT; qu++)
    val |= VTSS_F_Q_EGRESS_WM(qu,12);
  fdma_endian_aware_raw_writel(VTSS_DEV_Q_EGRESS_WM(VTSS_CPU_PM_NUMBER), val);

  fdma_endian_aware_raw_writel(VTSS_DEV_Q_MISC_CONF(VTSS_CPU_PM_NUMBER), fdma_endian_aware_raw_readl(VTSS_DEV_Q_MISC_CONF(VTSS_CPU_PM_NUMBER)) | VTSS_F_Q_MISC_CONF_IMIN(12));

#ifndef FDMA_LOOPBACK_TEST
  // We need to monitor CRC errors when in loopback mode.
  // Also set the PMs to update the CRC on CPU-injected frames.
  fdma_endian_aware_raw_writel(VTSS_DEV_TXUPDCFG(VTSS_ALL_PM_NUMBER), 2);
#endif
}

/*****************************************************************************/
/*****************************************************************************/
void linux_fdma_ana_cfg(int inj_port, int inj_switch_frm, int inj_port_mask)
{
  int p=0;

  fdma_endian_aware_raw_writel(VTSS_ANA_CAPENAB, 0xFFFFFFFF); // Capture everything, and let it go to the default queue (0).

  // Set-up all srcsmasks to forward frames received on any port to the CPU
#ifdef FDMA_INIT_PORTS_LOOPBACK
  // We get too many frames if looping back all CPU frames when switching
  // frames sent from the CPU to the CPU PM. So we set-up the analyzer
  // depending on the configuration of the injection mechanism.
  if(inj_port==VTSS_CPU_PM_NUMBER) {
    if(inj_switch_frm==0 && inj_port_mask) {
      // Pick the first port that is set in the inj_port_mask.
      // If we're switching frames, we simply pick port 0, which
      // is also the case if the port_mask is all-zeros.
      while((inj_port_mask&0x1)==0) {
        p++;
        inj_port_mask >>= 1;
      }
    }
  } else {
    // We use a direct front port. Use that one to receive the frames from as well.
    p = inj_port;
  }
  fdma_endian_aware_raw_writel(VTSS_ANA_SRCMASKS(p), fdma_endian_aware_raw_readl(VTSS_ANA_SRCMASKS(p)) | 0x40000000);
#else
  // Not looping back. Get all traffic from all ports.
  for(p=0; p<VTSS_PHYS_PORT_CNT; p++)
    fdma_endian_aware_raw_writel(VTSS_ANA_SRCMASKS(p), fdma_endian_aware_raw_readl(VTSS_ANA_SRCMASKS(p)) | 0x40000000);
#endif
}

/*****************************************************************************/
//  linux_fdma_open()
//  Handle 'up' of card
//  @dev: Device to open
/*****************************************************************************/
static int linux_fdma_open(struct net_device *dev)
{
  int ch;
  linux_fdma_priv_t *priv= netdev_priv(dev);

  FDMA_DBG_MSG(FDMA_DBG_GNRL_SPARSE, "linux_fdma_open()\n");

  if (request_irq(VCOREII_IRQ_FDMA, linux_fdma_irq_handler, 0, dev->name, dev)) {
    printk(KERN_ERR "Cannot assign IRQ number %d to FDMA\n",VCOREII_IRQ_FDMA);
    return -EAGAIN;
  }
  FDMA_DBG_MSG(FDMA_DBG_GNRL_VERBOSE, "Interrupt requested\n");

  fdma_init();
  FDMA_DBG_MSG(FDMA_DBG_GNRL_VERBOSE, "FDMA initialized\n");

  // Enable ports on the DUT
  linux_fdma_port_cfg(dev->mtu);
  linux_fdma_ana_cfg(priv->inj_port, priv->inj_switch_frm, priv->inj_port_mask);

  FDMA_DBG_MSG(FDMA_DBG_GNRL_VERBOSE, "Ports initialized\n");

  // Enable those extraction and injection channels that are configured to be enabled
  for(ch=0; ch<FDMA_CH_CNT; ch++) {
    if(priv->ch_cfg[ch].ena) {
      FDMA_ASSERT(priv->ch_cfg[ch].usage==FDMA_CH_USAGE_XTR || priv->ch_cfg[ch].usage==FDMA_CH_USAGE_INJ);
      if(priv->ch_cfg[ch].usage==FDMA_CH_USAGE_XTR) {
        if(linux_fdma_load_rx_ring(dev, ch)) {
          linux_fdma_close(dev);
          return -ENOBUFS;
        }
      } else {
        if(linux_fdma_load_tx_ring(dev, ch)) {
          linux_fdma_close(dev);
          return -ENOBUFS;
        }
      }
    }
  }

  FDMA_DBG_MSG(FDMA_DBG_GNRL_VERBOSE, "Rx and Tx initialized\n");

  // And finally, set the ball rolling...
  netif_start_queue(dev);
  return 0;
}

/*****************************************************************************/
// linux_fdma_timeout()
// Handle a timeout from the network layer.
// @dev: Device that timed out
//
// Handle a timeout on transmit from the dma. This normally means
// bad things.
/*****************************************************************************/
static void linux_fdma_timeout(struct net_device *dev)
{
  printk(KERN_ERR "%s: transmit timed out?\n", dev->name);
  /* Try to restart the adaptor. */
  netif_wake_queue(dev);
}

/*****************************************************************************/
// linux_fdma_hard_start_xmit()
// Queue a frame for transmit.
// @skb: buffer to transmit
// @dev: Device to send it out of
//
// Transmit a buffer. This normally means throwing the buffer onto
// the transmit queue as the queue is quite large. If the queue is
// full then we set tx_busy and return. Once the interrupt handler
// gets messages telling it to reclaim transmit queue entries, we will
// clear tx_busy and the kernel will start calling this again.
//
// We do not disable interrupts or acquire any locks; this can
// run concurrently with mc32_tx_ring(), and the function itself
// is serialized at a higher layer. However, similarly for the
// card itself, we must ensure that we update tx_ring_head only
// after we've established a valid packet on the tx ring (and
// before we let the card "see" it, to prevent it racing with the
// irq handler).

// Currently, we don't support Tx of Jumbo Frames!!
/*****************************************************************************/
static int linux_fdma_hard_start_xmit(struct sk_buff *skb, struct net_device *dev)
{
  linux_fdma_priv_t *priv = netdev_priv(dev);
  linux_fdma_ch_cfg_t *ch_cfg;
  fdma_list_head_t *l;
  int head_idx;
  int raw_frm_sz_bytes; // The size of the frame without IFH and CMD fields, but including FCS.
  int bufs_left, ch;

  // Figure out which channel the default injection port uses.
  ch=inj_port2ch[priv->inj_port];
  FDMA_ASSERT(ch>=0 && ch<FDMA_CH_CNT);

  // And get the configuration for that channel
  ch_cfg=&priv->ch_cfg[ch];
  FDMA_ASSERT(ch_cfg->usage==FDMA_CH_USAGE_INJ);

  // Get a new buffer
  head_idx = next_tx(atomic_read(&ch_cfg->ring_head), ch_cfg->buf_cnt);

  bufs_left = atomic_read(&ch_cfg->bufs_left);
  FDMA_DBG_MSG(FDMA_DBG_INJ_SPARSE, "linux_fdma_hard_start_xmit(bufs_left=%d)\n",bufs_left);
  FDMA_ASSERT(bufs_left);
  if(bufs_left == 0)
  {
    priv->net_stats.tx_dropped++;
    return 1;
  }

#ifdef FDMA_INJ_TEST
  // Stop after the first frame has been transmitted. This frame is re-transmitted over and over again.
  if(priv->net_stats.tx_packets>0) {
    kfree_skb(skb);
    return 0; // Simulate success.
  }
#endif

  // Currently this OS part doesn't support Scatter/Gather, though the non-OS-specific part does.
  FDMA_ASSERT(skb_shinfo(skb)->nr_frags==0);

  // If the frame is smaller than what we allow, pad with zeros.
  // The padding may result in a brandnew SKB if there's not room
  // in the current, hence the assignment.
  skb = skb_padto(skb, ETH_ZLEN);
  FDMA_ASSERT(skb);
  if (skb == NULL) {
    netif_wake_queue(dev);
    return 0;
  }

  atomic_dec(&ch_cfg->bufs_left); 

  // l is the buffer we will be loading
  l = &ch_cfg->list[head_idx];

  // The upper layers don't reserve space for the FCS, and the skb->len doesn't include it, but
  // the FDMA includes it, so to find the full frame size, we need to add it.
  // Since the frame contained in the SKB (excluding the FCS) may end on the last allocated byte, we
  // may inject uninitialized data - or rather - data that belongs to another field within the skb. 
  // But I don't see this as a security risk, since the chip will overwrite the FCS on its way out of it.
  // ETH_ZLEN is defined as 60 bytes.
  raw_frm_sz_bytes = unlikely(skb->len<ETH_ZLEN) ? ETH_ZLEN : skb->len;
  raw_frm_sz_bytes += FCS_SIZE_BYTES;


#ifdef FDMA_INJ_ALIGN_IFH_ON_32BIT_BOUNDARY
  if(((u32)skb->data)&0x3) {
    struct sk_buff *new_skb = alloc_skb(FDMA_IFH_SIZE_BYTES + FDMA_CMD_SIZE_BYTES + raw_frm_sz_bytes, GFP_KERNEL);
    if(new_skb==NULL) {
      priv->net_stats.tx_dropped++;
      printk(KERN_ERR "%s: INJ: Unable to allocate SKB for a new frame\n",dev->name);
      kfree_skb(skb);
      atomic_inc(&ch_cfg->bufs_left);
      return 1;
    }
    
    // We'll need this to free the memory when transmitted, so we save
    // a pointer to the SKB in the FDMA internal list.
    l->user = new_skb;

    // Prepare the new_skb to be inserted back into the list
    new_skb->dev=dev;

    // The FDMA expects a pointer to the first byte of the IFH, so we reserve space in front of the
    // packet for the IFH and the CMD fields.
    // skb_reserve() adds FDMA_IFH_SIZE_BYTES + FDMA_CMD_SIZE_BYTES to skb->data and skb->tail.
    skb_reserve(new_skb, FDMA_IFH_SIZE_BYTES + FDMA_CMD_SIZE_BYTES);
    
    // The skb_put() function increases skb->tail and skb->len by act_frm_len and returns the original skb->tail.
    memcpy(skb_put(new_skb, raw_frm_sz_bytes), skb->data, raw_frm_sz_bytes);

    // Free the old SKB
    kfree_skb(skb);

    // The skb_push(skb, len) function subtracts 'len' from skb->data and adds 'len' to skb->len and returns the new skb->data.
    l->data = skb_push(new_skb, FDMA_IFH_SIZE_BYTES + FDMA_CMD_SIZE_BYTES);
    l->act_len = raw_frm_sz_bytes + FDMA_IFH_SIZE_BYTES + FDMA_CMD_SIZE_BYTES;

    FDMA_ASSERT(((u32)(l->data)&0x3)==0);
  } else {
#endif
    // Either the FDMA_INJ_ALIGN_IFH_ON_32BIT_BOUNDARY is not defined, or
    // the skb->data is already located on a 32-bit boundary.
    
    // We'll need this to free the memory when transmitted, so we save
    // a pointer to the SKB in the FDMA internal list.
    l->user = skb;

    // The FDMA expects a pointer to the first byte of the IFH, so we reserve space in front of the
    // packet for the IFH and the CMD fields.
    // The skb_push(skb, len) function subtracts 'len' from skb->data and adds 'len' to skb->len and returns the new skb->data.
    l->data = skb_push(skb, FDMA_IFH_SIZE_BYTES + FDMA_CMD_SIZE_BYTES);
    l->act_len = raw_frm_sz_bytes + FDMA_IFH_SIZE_BYTES + FDMA_CMD_SIZE_BYTES;
#ifdef FDMA_INJ_ALIGN_IFH_ON_32BIT_BOUNDARY
  }
#endif

  // Only one item is used to describe this frame (currently we don't support jumbo frames or multi-fragment frames).
  l->next = NULL;

  // Tell it which port to inject the frame on.
  l->alloc_len_or_port = priv->inj_port;

  // Tell it which function to callback when done.
  l->inj_cb=linux_fdma_on_tx_packet;

  dev->trans_start = jiffies;

  // Initiate the injection. This also initializes the IFH and CMD fields.
  fdma_inj(l, ch, raw_frm_sz_bytes, priv->inj_switch_frm ? FDMA_INJ_OPT_SWITCH_FRM : 0, priv->inj_port_mask, priv->inj_vlan);

  // The new frame has been setup. We can now let the interrupt handler and card "see" it
  atomic_set(&ch_cfg->ring_head, head_idx);

  return 0;
}

/*****************************************************************************/
// linux_fdma_get_stats()
// Pull off the on board statistics
// @dev: Device to service
//
// Query and reset the on-card stats. There's the small possibility
// of a race here, which would result in an underestimation of
// actual errors. As such, we'd prefer to keep all our stats
// collection in software. As a rule, we do. However it can't be
// used for rx errors and collisions as, by default, the card discards
// bad rx packets. 
//
// Setting the SAV BP in the rx filter command supposedly
// stops this behaviour. However, testing shows that it only seems to
// enable the collation of on-card rx statistics --- the driver
// never sees an RX descriptor with an error status set.
/*****************************************************************************/
static struct net_device_stats *linux_fdma_get_stats(struct net_device *dev)
{
  FDMA_DBG_MSG(FDMA_DBG_GNRL_VERBOSE, "linux_fdma_get_stats()\n");
  linux_fdma_priv_t *priv = netdev_priv(dev);
#ifdef FDMA_XTR_TEST
  // Pass the extraction rate to the caller in the "rx_over_errors" member of the
  // structure and the jiff_diff in "rx_frame_errors", and diff in msecs in 
  // "rx_length_errors", so that they can be monitored with "ifconfig".
  unsigned long jiff_diff=dev->last_rx - priv->first_rx;
  unsigned long msecs = jiffies_to_msecs(jiff_diff);
  priv->net_stats.tx_dropped = msecs;
  priv->net_stats.tx_errors  = jiff_diff;
  priv->net_stats.rx_errors  = msecs==0 ? 0 : priv->net_stats.rx_bytes/(msecs/1000);
#endif
  return &priv->net_stats;
}  

/*****************************************************************************/
// linux_fdma_do_ioctl()
// Configure FDMA through ioctl calls
// @dev: The device
/*****************************************************************************/
static int linux_fdma_do_ioctl(struct net_device *dev, struct ifreq *ifr, int cmd)
{
  FDMA_DBG_MSG(FDMA_DBG_GNRL_VERBOSE, "linux_fdma_do_ioctl()\n");
  int status;

  if (!(dev && dev->flags & IFF_UP))
    return -ENODEV;

  switch(cmd) {
  default:
    status = -EINVAL;
    break;
  }
  return status;
}

/*****************************************************************************/
/*****************************************************************************/
static int linux_fdma_change_mtu(struct net_device *dev, int new_mtu)
{
  FDMA_DBG_MSG(FDMA_DBG_GNRL_VERBOSE, "linux_fdma_change_mtu()\n");
  if(dev->mtu==new_mtu)
    return 0;

  if(new_mtu<68 || new_mtu>FDMA_MAX_FRAME_SIZE_BYTES)
    return -EINVAL;
  dev->mtu=new_mtu;
  linux_fdma_maxlen_cfg(new_mtu);

  // Gotta re-initialize RX rings.
  linux_fdma_close(dev);
  linux_fdma_open(dev);
  return 0;
}

/*****************************************************************************/
// linux_fdma_probe()
// Search for FDMA
// @unit: interface number to use
/*****************************************************************************/
struct net_device *__init linux_fdma_probe(int unit)
{
  struct net_device *dev;
  linux_fdma_priv_t *priv;
  linux_fdma_ch_cfg_t *ch_cfg;
  int err, i;

  // We only support one single instance.
  if(already_initialized)
    return ERR_PTR(-ENODEV);

  // Not only does this allocate a structure of sizeof(struct net_device) + sizeof(linux_fdma_priv_t) + alignment,
  // it also initializes various fields of dev-> by calling ether_setup(). We override many of these
  // fields below (dev->open, dev->stop, dev->hard_start_xmit, etc)
  if((dev=alloc_etherdev(sizeof(linux_fdma_priv_t)))==NULL)
    return ERR_PTR(-ENOMEM);

  priv= netdev_priv(dev);

  if (unit>=0)
    sprintf(dev->name,"eth%d",unit);

  SET_MODULE_OWNER(dev);

#ifdef FDMA_DBG
{
  static unsigned version_printed;
  if(version_printed++==0)
    printk("%s", version);
}
#endif

  // Check to see if the version is correct
  if(fdma_check_version()) {
    memcpy(dev->dev_addr, bogus_mac_addr, 6);  // Set MAC address

    // When setting the defaults, bear in mind that we want to be able to survive a DoS attack. 
    // This means that we wish to give the injection channels higher priority than the extraction
    // channels. The native (and default) priority of the DMA controller is: The higher the channel
    // number, the higher priority. Therefore, we - by default - give the injection channels the
    // higher channel numbers.
    // Especially in the loopback test mode, this is crucial: If we gave the extraction channels
    // higher priority, and we were stormed with packets from an SMB, the injection channels would
    // never get a chance to operate, and we would soon run out of injection channel buffers.
    
    // We allocate FDMA_XTR_QU_CNT channels for extraction and the remaining for injection
    FDMA_ASSERT(FDMA_CH_CNT>FDMA_XTR_QU_CNT);

    // Set extraction defaults
    for(i=0;i<FDMA_XTR_QU_CNT;i++) {
      ch_cfg = &priv->ch_cfg[i];
      ch_cfg->start_gap =  0;
      ch_cfg->end_gap   =  0;
      ch_cfg->buf_cnt   =  5;
      ch_cfg->ena       =  1;
      ch_cfg->usage     = FDMA_CH_USAGE_XTR;
      ch_cfg->list      = NULL;
      ch_cfg->qu        = i;
      xtr_qu2ch[i]      = i;
    }

    // Use remaining channels for injection
    for(i=FDMA_XTR_QU_CNT;i<FDMA_CH_CNT;i++) {
      ch_cfg = &priv->ch_cfg[i];
      ch_cfg->buf_cnt = 200;
      ch_cfg->ena     =   1;
      ch_cfg->usage   = FDMA_CH_USAGE_INJ;
      ch_cfg->list    = NULL;
    }
    // Also set the mapping between a port and a channel.
    for(i=0;i<VTSS_TOTAL_PORT_CNT;i++) {
      inj_port2ch[i] = FDMA_XTR_QU_CNT + (i%(FDMA_CH_CNT-FDMA_XTR_QU_CNT));
    }

    // Set-up injection defaults
    priv->inj_port=VTSS_CPU_PM_NUMBER;
    priv->inj_switch_frm=0;
#if defined(FDMA_LOOPBACK_TEST) || defined(FDMA_INJ_TEST)
    // Just send it to the loopback port
    priv->inj_port_mask=FDMA_TEST_PORT_MASK;
#else
    priv->inj_port_mask=(1<<VTSS_PHYS_PORT_CNT)-1; // When not switching the packet, we use this port mask (all-ones) to tell where the packet should go (defaults to all ports).
#endif
    priv->inj_vlan=0;

    // Tell the upper layers that we support Scatter/Gather I/O (NETIF_F_SG and NETIF_F_FRAGLIST), and can DMA from high addresses.
    // By setting the scatter/gather option, we may receive fragments of a frame from the upper layers, which in turn
    // are mapped to several DCBs (if there's room).
//     dev->features = NETIF_F_SG | NETIF_F_FRAGLIST | NETIF_F_HIGHDMA;
    
    dev->open               = linux_fdma_open;
    dev->stop               = linux_fdma_close;
    dev->hard_start_xmit    = linux_fdma_hard_start_xmit;
    dev->get_stats          = linux_fdma_get_stats;
    dev->set_multicast_list = linux_fdma_set_multicast_list;
    dev->tx_timeout         = linux_fdma_timeout;
    dev->watchdog_timeo     = HZ;
    dev->do_ioctl           = linux_fdma_do_ioctl;
    dev->change_mtu         = linux_fdma_change_mtu; // In order to support jumbo frames
    // The hard_header_len is used to reserve space in the beginning of a packet to be transmitted (controlled by all the protocols
    // running on top of us, like ipv4, arp, etc.). For received packets, we control the allocation of SKBs ourselves.
    // The ETH_HLEN is the DMAC and SMAC + Type/length (14 bytes), which is reserved by default with the ether_setup() function.
    // In addition we save room for the IFH and CMD fields. To that number we add 4 bytes because it may be that the DMAC starts
    // on a non-32-bit-aligned address (that's in fact the case with Linux, which tries to align the protocol header on a 32-bit 
    // byte boundary). A non-32-bit aligned DMAC also causes a non-32-bit aligned IFH, which can be handled by the FDMA by setting
    // the DCB->sar to non-zero (2 in fact). Reserving four more bytes causes the two bytes preceding the first byte of the
    // IFH to be unused.
    // The higher-level protocols use the LL_RESERVED_SPACE with hard_header_len to move the skb->data pointer to the place where
    // the first byte of the protocol specific header starts. The LL_RESERVED_SPACE macro (by default) reserves the next 
    // multiple of 16 of dev->hard_header_len, which in our case results in reserving 32 bytes before the protocol header, since
    // hard_header_len is 30.
    dev->hard_header_len = FDMA_IFH_SIZE_BYTES + FDMA_CMD_SIZE_BYTES + ETH_HLEN + 4;

    if((err=register_netdev(dev))!=0) {
      printk(KERN_ERR "%s: Failed to register net device", DRV_NAME);
      free_netdev(dev);
      return ERR_PTR(err);
    }
    already_initialized=1;
    return dev;
  }

  free_netdev(dev);
  return ERR_PTR(-ENODEV);
}

/*****************************************************************************/
// The following is only relevant if this driver is loaded as a module
// rather than being linked into the kernel.
/*****************************************************************************/
#ifdef MODULE
static struct net_device *this_device;

/*****************************************************************************/
// linux_fdma_module_init()
// Entry point. Probe for existense of VTSS FDMA. 
/*****************************************************************************/
static int __init linux_fdma_module_init(void)
{
  this_device=fdma_probe(-1);
  if(IS_ERR(this_device))
    return PTR_ERR(this_device);
  return 0;
}

/*****************************************************************************/
// linux_fdma_module_exit()
// Free resources for an unload.
/*****************************************************************************/
static void __exit linux_fdma_module_exit(void)
{
  unregister_netdev(this_device);
  free_netdev(this_device);
  already_initialized=0;
}

MODULE_AUTHOR("rbn@vitesse.com");
MODULE_DESCRIPTION("Vitesse Frame DMA ethernet driver.");

module_init(linux_fdma_module_init);
module_exit(linux_fdma_module_exit);

#endif /* MODULE */
/*****************************************************************************/
//
// End of file
//
//****************************************************************************/
