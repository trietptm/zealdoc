/*
 
 Vitesse Switch Software.
 
 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/
/*****************************************************************************/
/*****************************************************************************/
#ifndef VTSS_FDMA_H
#define VTSS_FDMA_H

// Some of the register definition stuff is buried in the public part.
#include "vtss_fdma_api.h"

// Size of a data cache line in bytes on EStaX34:
#define VTSS_FDMA_CACHE_LINE_SIZE_BYTES 32

// Debug register and thus not in the datasheet
#define VTSS_MISC_DMA_COMP_VERSION VTSS_REGISTER(FDMA,0x03FC)
#define DW_DMAC_VER 0x3230372A

// This register is a debug register and thus not defined in luton28_vcore2_regs.h
#define VTSS_INTR_STATUS2 VTSS_REGISTER(ICPU_CFG,0x003C)

// Used System registers
#define VTSS_ICPU_MBOX_VAL  VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(7,0,0x15)) /* 0x1C054 */
#define VTSS_ICPU_MBOX_SET  VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(7,0,0x16)) /* 0x1C058 */
#define VTSS_ICPU_MBOX_CLR  VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(7,0,0x17)) /* 0x1C05C */
#define VTSS_SYSTEM_CAPCTRL VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(7,0,0x31))

// Port Module Registers
#define VTSS_DEV_MAC_CFG(dev)                   VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0x00))
#define VTSS_DEV_MAXLEN(dev)                    VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0x10))
#define VTSS_DEV_PCSCTRL(dev)                   VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0x18))
#define VTSS_DEV_ADVPORTM(dev)                  VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0x19))
#define VTSS_DEV_SGMII_MACRO_CFG(dev)           VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0x1A))
#define VTSS_DEV_SGMII_MACRO_CMU_TEST_CTRL(dev) VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0x1B))
#define VTSS_DEV_TXUPDCFG(dev)                  VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0x24))
#define VTSS_DEV_CAT_QCE(dev, nr)               VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),(0x80+(nr))))
#define VTSS_DEV_MISCCFG(dev)                   VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0xC5))
#define VTSS_DEV_FREEPOOL(dev)                  VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0xD8))
#define VTSS_DEV_Q_MISC_CONF(dev)               VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0xDF))
#define VTSS_DEV_Q_EGRESS_WM(dev)               VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0xE0))

// DEV::MISCCFG bit fields
#define VTSS_F_LEARNTRUNC        VTSS_BIT(5) /* Only available in CPU PM */
#define VTSS_F_AUTOQ_SEL         VTSS_BIT(4) /* Only available in CPU PM */
#define VTSS_F_LACP_ID_ENABLE    VTSS_BIT(3)
#define VTSS_F_ACL_ENABLE        VTSS_BIT(2)
#define VTSS_F_EGRESSDROP_ENABLE VTSS_BIT(1) /* Only available in CPU PM */

// DEV::Q_EGRESS_WM bit fields
#define VTSS_F_Q_EGRESS_WM(qu, x) VTSS_ENCODE_BITFIELD((x), (8*(qu)), 5)

// DEV::Q_MISC_CONF bit fields
#define VTSS_F_Q_MISC_CONF_IMIN(x) VTSS_ENCODE_BITFIELD((x),16, 5)
#define VTSS_F_Q_MISC_CONF_EMIN(x) VTSS_ENCODE_BITFIELD((x), 8, 5)

// Analyzer Registers
#define VTSS_ANA_CAPENAB                        VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(2,0,0xA0))
#define VTSS_ANA_CAPQUEUEGARP                   VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(2,0,0xA8))
#define VTSS_ANA_SRCMASKS(dev)                  VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(2,0,(0x80+dev)))
#define VTSS_ANA_RECVMASK                       VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(2,0,0x10))

// Registers that already are defined in amba_devices.h, but need to be re-defined,
// so that we can iterate over a variable
#define GPDMA_FDMA_CH_CFG_0(ch)                 VTSS_REGISTER(ICPU_CFG,(0x0060+(4*ch)))
#define GPDMA_FDMA_CH_CFG_1(ch)                 VTSS_REGISTER(ICPU_CFG,(0x0080+(4*ch)))
#define GPDMA_FDMA_INJ_CFG(inj_ch)              VTSS_REGISTER(ICPU_CFG,(0x00A0+(4*inj_ch)))
#define GPDMA_FDMA_XTR_CFG(xtr_ch)              VTSS_REGISTER(ICPU_CFG,(0x00C0+(4*xtr_ch)))
#define VTSS_CH_LLP(ch)                         VTSS_REGISTER(FDMA,    (0x0010+(4*22*ch)))
#define VTSS_CH_CTL0(ch)                        VTSS_REGISTER(FDMA,    (0x0018+(4*22*ch)))
#define VTSS_CH_DSTATAR(ch)                     VTSS_REGISTER(FDMA,    (0x0038+(4*22*ch)))
#define VTSS_CH_CFG0(ch)                        VTSS_REGISTER(FDMA,    (0x0040+(4*22*ch)))
#define VTSS_CH_CFG1(ch)                        VTSS_REGISTER(FDMA,    (0x0044+(4*22*ch)))

// Injection Write Delay field definitions
#define VTSS_F_INJ_CFG_WR_DELAY_FPOS 1
#define VTSS_F_INJ_CFG_WR_DELAY_FLEN 5
#define VTSS_F_INJ_CFG_WR_DELAY(x)   VTSS_ENCODE_BITFIELD(x, VTSS_F_INJ_CFG_WR_DELAY_FPOS, VTSS_F_INJ_CFG_WR_DELAY_FLEN)

// This is needed to obtain the physical address of the CFG::XTR_LAST_CHUNK_STAT register
#define VTSS_FDMA_LAST_CHUNK_PHYS_ADDR(ch)     (VTSS_TB_ICPU_CFG + 0x00e0 + 4*(ch))

// Other registers (not necessarily used)
#define VTSS_TWI_COMP_VERSION                   VTSS_REGISTER(TWI,0x00F8)
#define DEV_RXEVENTS(dev)                       VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0x3C))
#define DEV_TXEVENTS(dev)                       VTSS_REGISTER(SWC,BLK_SUBBLK_ADDR(DEV_TO_B(dev),DEV_TO_S(dev),0x48))

// Debug fields not defined in amba_devices.h
// CFG::VTSS_GPDMA_FDMA_COMMON_CFG.DATA_BYTE_SWAP
#define VTSS_F_DATA_BYTE_SWAP VTSS_BIT(0)
// CFG::VTSS_CH_CFG1.PROTCTL
#define VTSS_F_PROTCTL(x)     VTSS_ENCODE_BITFIELD((x),2,3)

// The FDMA overrides the usage of the DCB->dar field in the injection case
#define VTSS_FDMA_DAR_REMOTE(x)     VTSS_ENCODE_BITFIELD((x),21, 1)
#define VTSS_FDMA_DAR_EOF(x)        VTSS_ENCODE_BITFIELD((x),20, 1)
#define VTSS_FDMA_DAR_SOF(x)        VTSS_ENCODE_BITFIELD((x),19, 1)
#define VTSS_FDMA_DAR_CH_ID(x)      VTSS_ENCODE_BITFIELD((x),16, 3)
#define VTSS_FDMA_DAR_CHUNK_SIZE(x) VTSS_ENCODE_BITFIELD((x), 4,12)
#define VTSS_FDMA_DAR_SAR_OFFSET(x) VTSS_ENCODE_BITFIELD((x), 2, 2)

#define VTSS_FDMA_SAR_REMOTE(x)     VTSS_ENCODE_BITFIELD((x),21, 1)
#define VTSS_FDMA_SAR_CH_ID(x)      VTSS_ENCODE_BITFIELD((x),16, 3)
#define VTSS_FDMA_SAR_CHUNK_SIZE(x) VTSS_ENCODE_BITFIELD((x), 4,12)

#define VTSS_FDMA_F_SAR_CH_ID_FPOS 16
#define VTSS_FDMA_F_SAR_CH_ID_FLEN  3

// This structure fits exactly into vtss_fdma_list_head_t->dcb.
typedef struct vtss_fdma_dcb {
  u32 sar;
  u32 dar;
  u32 llp;
  u32 ctl0;
  u32 ctl1;
  u32 sstat;
  u32 dstat;
} volatile vtss_fdma_dcb_t;

// Swap the bytes in v and return the result.
#ifdef VTSS_FDMA_BIG_ENDIAN
static inline u32 vtss_fdma_to_little_endian(u32 v)
{
  // If vtss_fdma_endian_aware_reaw_readl() was called with
  // a register address, the same register address
  // would be read multiple times if this was implemented
  // as a macro rather than an inline function.
  register u32 v1=v;
  v1 = ((v1>>24) & 0x000000FF) | ((v1>>8) & 0x0000FF00) | ((v1<<8) & 0x00FF0000) | ((v1<<24) & 0xFF000000);
  return v1;
}
#else
  // When already in little endian mode, simply return the value
  // we're called with. Use a macro in this case because this
  // results in no additional code - even when not optimizing.
  #define vtss_fdma_to_little_endian(v) (v)
#endif

#define vtss_fdma_endian_aware_raw_readl(a)     vtss_fdma_to_little_endian(vtss_fdma_raw_readl((u32)(a)))
#define vtss_fdma_endian_aware_raw_writel(a, v) vtss_fdma_raw_writel(a , vtss_fdma_to_little_endian(v))

// Position of various field in the CMD field
#define VTSS_FDMA_CMD_F_FRAMEDEST_FPOS     4
#define VTSS_FDMA_CMD_F_DOANALYZE_FPOS     3
#define VTSS_FDMA_CMD_F_REWIND_CPU_TX_FPOS 1
#define VTSS_FDMA_CMD_F_CPU_TX_FPOS        0

#endif /* VTSS_FDMA_H */
/*****************************************************************************/
//
// End of file
//
//****************************************************************************/
