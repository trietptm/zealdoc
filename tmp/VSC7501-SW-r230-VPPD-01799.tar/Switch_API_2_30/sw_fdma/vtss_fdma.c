/*
 
 Vitesse Switch Software.
 
 Copyright (c) 2002-2008 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
*/
/*****************************************************************************/
//
// vtss_fdma.c
//
//*****************************************************************************/
#include "vtss_fdma_os.h" /* For various OS dependent macros (e.g. rd/wr) and inclusion of register definitions */
#include "vtss_fdma_api.h"
#include "vtss_fdma.h"

#define VTSS_FDMA_CH_USAGE_UNUSED    0
#define VTSS_FDMA_CH_USAGE_XTR       1
#define VTSS_FDMA_CH_USAGE_INJ       2

#define VTSS_FDMA_CH_STATE_DISABLED  0
#define VTSS_FDMA_CH_STATE_ENABLED   1
#define VTSS_FDMA_CH_STATE_SUSPENDED 2

typedef struct {
  // Current use of the channel. Can be either of VTSS_FDMA_CH_USAGE_xxx.
  int usage;

  // Current state of the channel. Can be either of VTSS_FDMA_CH_STATE_xxx.
  int state;

  // XTR: List of DCBs and frame data to which data can currently get extracted to, i.e. these are committed to the FDMA.
  // INJ: List of frames that are currently being injected.
  vtss_fdma_list_head_t *cur_head;

  // XTR: List of DCBs and frame data that are not yet committed to the FDMA. When the transfer done interrupt occurs, they do get committed.
  // INJ: Not used.
  vtss_fdma_list_head_t *free_head;

  // XTR: Holds a pointer to the last item in the free_head list, i.e. the one whose next pointer is NULL.
  // INJ: Holds a pointer to the last item in the cur_head list, i.e. the one whose next pointer is NULL.
  vtss_fdma_list_head_t *cur_tail;

  // XTR: In case of jumbo frames (or frames whose size exceed the allocated), the pend_head holds the up-until-now-received fragments of the frame.
  // INJ: Not used.
  vtss_fdma_list_head_t *pend_head;

  // XTR: CPU Port Module queue that this channel serves.
  // INJ: The front port that the channel is currently set-up to inject to.
  int qu_or_port;

  // XTR: Holds the configured start gap in words.
  // INJ: Not used
  int start_gap;

  // XTR: Holds the configured end gap in words.
  // INJ: Not used
  int end_gap;

  // XTR: The per-channel callback function invoked when a new frame is ready.
  // INJ: Not used.
  vtss_fdma_list_head_t *(*xtr_cb)(void *cntxt, vtss_fdma_list_head_t *list, int qu);
} vtss_fdma_ch_state_t;

static vtss_fdma_ch_state_t vtss_fdma_ch_state[VTSS_FDMA_CH_CNT];

typedef struct {
  // XTR: Not used
  // INJ: Configuration. This member is initialized by vtss_fdma_set_tx_flow_ctrl_cfg(). 
  //      It defaults to drop mode. When a port is in Tx flow control
  //      mode (DEV::FCCONF.FLOW_CONTROL_OBEY==1), frame injections
  //      to the port is a bit slower, because S/W has to check for
  //      overflow before writing the DEV::MISCFIFO.CPU_TX bit.
  //      In drop mode, the FDMA performs the writing to this register
  //      automatically. If - in flow control mode - the
  //      DEV::MISCSTAT.CPU_TX_DATA_OVERFLOW bit is set, the latest
  //      frame is rewound, and re-transmitted if configured to (see
  //      cfg_retransmit_cnt member).
  unsigned char cfg_tx_flow_ctrl;

  // XTR: Not used
  // INJ: Configuration. Only used in the case where cfg_tx_flow_ctrl is 1.
  //      Controls the number of times a frame is attempted re-injected
  //      before giving up. Configured with vtss_fdma_set_tx_flow_ctrl_cfg().
  unsigned char cfg_retransmit_cnt;

  // XTR: Not used
  // INJ: State. Holds the number of times to yet retransmit the same frame
  //      in case of 
  unsigned char state_retransmit_cnt;

  // XTR: Not used
  // INJ: Configuration. Set and cleared through a call to vtss_fdma_inj_suspend_port().
  //      Causes the FDMA driver code not to start anymore injections to this port
  //      as long as this bit is set. The user can call vtss_fdma_inj_port_active() to
  //      figure out whether an FDMA transfer to a port is ongoing. 
  unsigned char suspended;

  // XTR: Not used
  // INJ: State. Counts the number of channels that are currently attempting to
  //      inject to a given port. The counter cannot exceed the number of channels.
  unsigned char active_cnt;

} vtss_fdma_port_state_t;

// Even though the state is only pertaining to the front ports
// we allocate for the CPU PM as well, because that simplifies
// the code!
static vtss_fdma_port_state_t vtss_fdma_port_state[VTSS_TOTAL_PORT_CNT];

static vtss_fdma_stats_t vtss_fdma_stats;

/*****************************************************************************/
// Returns: 0 on failure to support the current silicon, 1 on success.
/*****************************************************************************/
static int check_version(void)
{
  return vtss_fdma_endian_aware_raw_readl(VTSS_MISC_DMA_COMP_VERSION)==DW_DMAC_VER;
}

/*****************************************************************************/
/*****************************************************************************/
static inline void enable_ch(int ch)
{
  // Create a memory barrier here, so that the compiler doesn't enable the channel
  // before it's configured properly (needed because this function is inline).
  VTSS_FDMA_BARRIER();
  vtss_fdma_endian_aware_raw_writel(VTSS_MISC_CH_EN_REG, VTSS_F_CH_EN_WE(VTSS_BIT(ch)) | VTSS_F_CH_EN(VTSS_BIT(ch))); // CH_EN_WE=CH_EN=1
}

/*****************************************************************************/
/*****************************************************************************/
static inline void disable_ch(int ch)
{
  vtss_fdma_endian_aware_raw_writel(VTSS_MISC_CH_EN_REG, VTSS_F_CH_EN_WE(VTSS_BIT(ch))); // CH_EN_WE=1, CH_EN=0
}

/*****************************************************************************/
/*****************************************************************************/
static inline void disable_chs(int ch_mask)
{
  vtss_fdma_endian_aware_raw_writel(VTSS_MISC_CH_EN_REG, VTSS_F_CH_EN_WE(ch_mask)); // CH_EN_WE=1, CH_EN=0
}

/*****************************************************************************/
/*****************************************************************************/
static inline void enable_block_done_intr(int ch)
{
  VTSS_FDMA_BARRIER();
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_MASK_BLOCK, VTSS_F_INT_MASK_WE_BLOCK(VTSS_BIT(ch)) | VTSS_F_INT_MASK_BLOCK(VTSS_BIT(ch)));
}

/*****************************************************************************/
/*****************************************************************************/
static inline void enable_tfr_done_intr(int ch)
{
  VTSS_FDMA_BARRIER();
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_MASK_TFR, VTSS_F_INT_MASK_WE_TFR(VTSS_BIT(ch)) | VTSS_F_INT_MASK_TFR(VTSS_BIT(ch)));
}

/*****************************************************************************/
/*****************************************************************************/
static inline void disable_block_done_intr(int ch)
{
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_MASK_BLOCK, VTSS_F_INT_MASK_WE_BLOCK(VTSS_BIT(ch)));
}

/*****************************************************************************/
/*****************************************************************************/
static inline void disable_tfr_done_intr(int ch)
{
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_MASK_TFR, VTSS_F_INT_MASK_WE_TFR(VTSS_BIT(ch)));
}

/*****************************************************************************/
/*****************************************************************************/
static inline void clear_pending_block_done_intr(int mask)
{
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_CLEAR_BLOCK, VTSS_F_CLEAR_BLOCK(mask));
}

/*****************************************************************************/
/*****************************************************************************/
static inline void clear_pending_tfr_done_intr(int mask)
{
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_CLEAR_TFR, VTSS_F_CLEAR_TFR(mask));
}

/*****************************************************************************/
/*****************************************************************************/
int vtss_fdma_init(void)
{
  if(!check_version())
    return 0; // Unsupported silicon

  // Disable all channels (they must be enabled per channel through the calls to vtss_fdma_xtr_cfg() or vtss_fdma_inj_cfg()).
  disable_chs(VTSS_BITMASK(VTSS_FDMA_CH_CNT));
  
  // Globally enable DMA controller
  vtss_fdma_endian_aware_raw_writel(VTSS_MISC_DMA_CFG_REG, VTSS_F_DMA_EN);

  // Clear channel state
  VTSS_FDMA_MEMSET(vtss_fdma_ch_state, 0, sizeof(vtss_fdma_ch_state));

  // And statistics
  VTSS_FDMA_MEMSET(&vtss_fdma_stats, 0, sizeof(vtss_fdma_stats));

  return 1;
}

/*****************************************************************************/
/*****************************************************************************/
void vtss_fdma_uninit(void)
{
  // Globally disable DMA controller
  vtss_fdma_endian_aware_raw_writel(VTSS_MISC_DMA_CFG_REG, 0);

  // Disable all channels
  disable_chs(VTSS_BITMASK(VTSS_FDMA_CH_CNT));
  
  // Disable interrupts from DMA controller
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_MASK_TFR,   VTSS_F_INT_MASK_WE_TFR  (VTSS_BITMASK(VTSS_FDMA_CH_CNT)));
  vtss_fdma_endian_aware_raw_writel(VTSS_INTR_MASK_BLOCK, VTSS_F_INT_MASK_WE_BLOCK(VTSS_BITMASK(VTSS_FDMA_CH_CNT)));

  // Clear pending interrupts
  clear_pending_block_done_intr(VTSS_BITMASK(VTSS_FDMA_CH_CNT));
  clear_pending_tfr_done_intr  (VTSS_BITMASK(VTSS_FDMA_CH_CNT));
}

/*****************************************************************************/
/*****************************************************************************/
#ifdef VTSS_FDMA_KEEP_STATISTICS
static vtss_fdma_list_head_t *xtr_dcb_init(int ch, vtss_fdma_list_head_t *list, u32 *dcb_cnt)
#else
static vtss_fdma_list_head_t *xtr_dcb_init(int ch, vtss_fdma_list_head_t *list)
#endif
{
  vtss_fdma_list_head_t *l = list, *tail = list;
  vtss_fdma_dcb_t *dcb_ptr;

#ifdef VTSS_FDMA_KEEP_STATISTICS
  *dcb_cnt = 0;
#endif  

  while(l) {
    VTSS_FDMA_ASSERT(((u32)l->dcb&(VTSS_FDMA_CACHE_LINE_SIZE_BYTES-1))==0);
    VTSS_FDMA_ASSERT(l->data && ((u32)l->data&0x3)==0);
    VTSS_FDMA_ASSERT(l->alloc_len_or_port>=VTSS_FDMA_MIN_DATA_PER_XTR_SOF_DCB_BYTES && l->alloc_len_or_port<=VTSS_FDMA_MAX_DATA_PER_DCB_BYTES);

    // If the user has modified the buffer, we need to invalidate the cache
    // before the FDMA has actually written data to the buffer because
    // part of the act of invalidating the cache is to drain the write buffer,
    // and if we waited with invalidating the cache until after the FDMA has
    // filled data into it, the FDMA-filled data would be overwritten with
    // the stale data in the write buffer.
    VTSS_FDMA_INVALIDATE_DCACHE_DATA(l->data, l->alloc_len_or_port);

    // Initialize the DCB area
    dcb_ptr = (vtss_fdma_dcb_t *)l->dcb;
    dcb_ptr->sar  = vtss_fdma_to_little_endian(VTSS_FDMA_SAR_CH_ID(ch) | VTSS_FDMA_SAR_CHUNK_SIZE(l->alloc_len_or_port));
    dcb_ptr->dar  = vtss_fdma_to_little_endian(VTSS_FDMA_VIRT_TO_PHYS(l->data));
    dcb_ptr->llp  = vtss_fdma_to_little_endian(l->next ? VTSS_FDMA_VIRT_TO_PHYS(l->next->dcb) : 0); // NULL
    dcb_ptr->ctl0 = vtss_fdma_to_little_endian(VTSS_F_LLP_SRC_EN | VTSS_F_LLP_DST_EN | VTSS_F_SMS(1) | VTSS_F_TT_FC(4) | VTSS_F_SRC_MSIZE(2) | VTSS_F_DEST_MSIZE(3) | VTSS_F_SINC(2) | VTSS_F_SRC_TR_WIDTH(2) | VTSS_F_DST_TR_WIDTH(2) | VTSS_F_INT_EN);
    dcb_ptr->ctl1 = dcb_ptr->sstat = dcb_ptr->dstat = 0;

    VTSS_FDMA_BARRIER();

    // Flush the dcache, so that the DCB gets written to main memory.
    VTSS_FDMA_FLUSH_DCACHE_DCB(dcb_ptr, VTSS_FDMA_DCB_SIZE_BYTES);

#ifdef VTSS_FDMA_DBG
    // Really not needed, but easier to figure out which DCBs are used and which are not during debugging.
    l->act_len = 0;
#endif

#ifdef VTSS_FDMA_KEEP_STATISTICS
    (*dcb_cnt)++;
#endif

    if(l->next)
      tail = l->next;
    l = l->next;
  }
  return tail;
}

/*****************************************************************************/
// This function must be called with interrupts disabled, so that no context
// switches can occur, since it manipulates list pointers that are used in
// IRQ (DSR) context.
/*****************************************************************************/
static inline void xtr_connect(vtss_fdma_ch_state_t *ch_state, vtss_fdma_list_head_t *new_head, vtss_fdma_list_head_t *new_tail)
{
  // Connect the new list to the end of the current free list whose
  // start and end are given by ch_state->free_head and ch_state->cur_tail.
  if(ch_state->free_head) {
    VTSS_FDMA_ASSERT(ch_state->cur_tail && ch_state->cur_tail->next==NULL);
    // The free list already exists. Append to it, list-wise...
    ch_state->cur_tail->next=new_head;
    // ...and DCB-wise:
    ((vtss_fdma_dcb_t *)(ch_state->cur_tail->dcb))->llp = vtss_fdma_to_little_endian(VTSS_FDMA_VIRT_TO_PHYS(new_head->dcb));

    VTSS_FDMA_BARRIER();

    // Flush the dcache, so that the previous tail's DCB's LLP gets written to main memory.
    VTSS_FDMA_FLUSH_DCACHE_DCB(&((vtss_fdma_dcb_t *)ch_state->cur_tail->dcb)->llp, 4);
  } else {
    // The free list doesn't exist. Create it.
    ch_state->free_head = new_head;
  }
  ch_state->cur_tail = new_tail;
}

/*****************************************************************************/
// This function must be called with interrupts disabled, so that no context
// switches can occur, since it manipulates list pointers that are used in
// IRQ (DSR) context.
/*****************************************************************************/
static inline void xtr_restart_ch(vtss_fdma_ch_state_t *ch_state, int ch)
{
  // No list must currently have been committed to the VTSS_FDMA.
  VTSS_FDMA_ASSERT(ch_state->cur_head==NULL);

  // And the channel must be disabled by now
  VTSS_FDMA_ASSERT((vtss_fdma_endian_aware_raw_readl(VTSS_MISC_CH_EN_REG)&VTSS_F_CH_EN(VTSS_BIT(ch)))==0);

  // Update the list pointers
  ch_state->cur_head = ch_state->free_head;
  ch_state->free_head = ch_state->cur_tail = NULL;
  
  // Re-enable the channel
  vtss_fdma_endian_aware_raw_writel(VTSS_CH_LLP(ch), VTSS_FDMA_VIRT_TO_PHYS(ch_state->cur_head->dcb));
  enable_ch(ch);
}

/*****************************************************************************/
/*****************************************************************************/
vtss_fdma_stats_t *vtss_fdma_get_stats(void)
{
  return &vtss_fdma_stats;
}

/*****************************************************************************/
/*****************************************************************************/
void vtss_fdma_clear_stats(void)
{
  VTSS_FDMA_INTERRUPT_FLAGS flags;
  VTSS_FDMA_DISABLE_INTERRUPTS(flags);
  VTSS_FDMA_MEMSET(&vtss_fdma_stats, 0, sizeof(vtss_fdma_stats));
  VTSS_FDMA_RESTORE_INTERRUPTS(flags);
}

/*****************************************************************************/
// To avoid OS-dependent allocation problems on the various OS's we support,
// we require, that the list[] is pre-allocated and that the data areas that
// its members point to are as well.
// Call this function per channel and queue.
// @ena: 
//   If ==0, the channel gets disabled and the remaining parameters (except for ch) are unused.
//   If !=0, the remaining parameters are used and the channel gets enabled.
/*****************************************************************************/
void vtss_fdma_xtr_cfg(int ena, int ch, int qu, int start_gap, int end_gap, vtss_fdma_list_head_t *list, vtss_fdma_list_head_t *(*xtr_cb)(void *cntxt, vtss_fdma_list_head_t *list, int qu))
{
  int i;
  vtss_fdma_ch_state_t *ch_state = &vtss_fdma_ch_state[ch];
#ifdef VTSS_FDMA_KEEP_STATISTICS
  u32 dcb_cnt;
#endif

  // Valid channel?
  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);

  if(ena) {
    // Check parameters and the current state
    VTSS_FDMA_ASSERT(qu>=0 && qu<VTSS_FDMA_XTR_QU_CNT);
    VTSS_FDMA_ASSERT(list);
    VTSS_FDMA_ASSERT(xtr_cb);
    VTSS_FDMA_ASSERT(ch_state->state==VTSS_FDMA_CH_STATE_DISABLED);
    VTSS_FDMA_ASSERT(start_gap>=0 && start_gap<VTSS_BIT(VTSS_F_XTR_START_GAP_FLEN));
    VTSS_FDMA_ASSERT(end_gap  >=0 && end_gap  <VTSS_BIT(VTSS_F_XTR_END_GAP_FLEN));

    // Check that no other non-inactive, extraction channel is managing the qu.
    for(i=0; i<VTSS_FDMA_CH_CNT; i++) {
      VTSS_FDMA_ASSERT(vtss_fdma_ch_state[i].state==VTSS_FDMA_CH_STATE_DISABLED || vtss_fdma_ch_state[i].usage!=VTSS_FDMA_CH_USAGE_XTR || vtss_fdma_ch_state[i].qu_or_port!=qu);
    }

    // Initialize the list's DCB areas.
#ifdef VTSS_FDMA_KEEP_STATISTICS
    xtr_dcb_init(ch, list, &dcb_cnt);
    vtss_fdma_stats.rx_bufs_added[qu] += dcb_cnt;
#else
    xtr_dcb_init(ch, list);
#endif

    ch_state->usage        = VTSS_FDMA_CH_USAGE_XTR;
    ch_state->state        = VTSS_FDMA_CH_STATE_ENABLED;
    ch_state->cur_head     = list;
    ch_state->free_head    = NULL; // No un-committed items.
    ch_state->cur_tail     = NULL;
    ch_state->pend_head    = NULL;
    ch_state->qu_or_port   = qu;
    ch_state->xtr_cb       = xtr_cb;
    ch_state->start_gap    = start_gap;
    ch_state->end_gap      = end_gap;

    vtss_fdma_endian_aware_raw_writel(VTSS_CH_LLP(ch), VTSS_FDMA_VIRT_TO_PHYS(list->dcb));
    vtss_fdma_endian_aware_raw_writel(GPDMA_FDMA_CH_CFG_0(ch), VTSS_F_MODULE(4) | VTSS_F_SUB_MODULE(0) | VTSS_F_DATA_ADDR(0)); // Sub-module must be 0, since the FDMA computes the sub-module itself from the queue number.

    // Whether we're in little or big endian mode we need to swap the data bytes
    // between DDR SDRAM and the SwC, because the SwC has them stored in big
    // endian format and we need them stored as a stream of bytes in the DDR SDRAM.
    // Since there's no endianness awareness between the DMA controller and the
    // DDR SDRAM there is no difference between the storing of data whether the
    // CPU is in little or big endian mode.
    vtss_fdma_endian_aware_raw_writel(VTSS_GPDMA_FDMA_COMMON_CFG, VTSS_F_DATA_BYTE_SWAP);

    // Usage=extraction, queue=xtr_qu,
    vtss_fdma_endian_aware_raw_writel(GPDMA_FDMA_CH_CFG_1(ch), VTSS_F_FC_XTR_ENA(VTSS_BIT(qu))); // USAGE=extraction and FC_XTR_ENA
    vtss_fdma_endian_aware_raw_writel(VTSS_CH_LLP(ch),  VTSS_FDMA_VIRT_TO_PHYS(list->dcb));
    vtss_fdma_endian_aware_raw_writel(VTSS_CH_CTL0(ch), VTSS_F_LLP_SRC_EN | VTSS_F_LLP_DST_EN); // We just need to enable LLP_SRC_EN and LLP_DST_EN here, since a new descriptor is loaded right after.
    vtss_fdma_endian_aware_raw_writel(VTSS_CH_CFG0(ch), VTSS_F_HS_SEL_DST | VTSS_F_CH_PRIOR(ch)); // HS_SEL_SRC=Hardware Initiated, HS_SEL_DST=1=Software Initiated, keep intrinsic priority
    vtss_fdma_endian_aware_raw_writel(VTSS_CH_CFG1(ch), VTSS_F_SRC_PER(ch) | VTSS_F_DS_UPD_EN | VTSS_F_PROTCTL(1) | VTSS_F_FCMODE); // SRC_PER=channel, DS_UPD_EN=1, PROTCTL=1, FCMODE=1

    // Set-up start- and end-gaps
    vtss_fdma_endian_aware_raw_writel(GPDMA_FDMA_XTR_CFG(ch), VTSS_F_XTR_END_GAP(end_gap) | VTSS_F_XTR_START_GAP(start_gap));

    // With the DS_UPD_EN bit set in CFG1, we must also set the address from which the destination update status
    // is fetched by the DMA controller. The CFG::XTR_LAST_CHUNK_STAT provides the needed information (EOF, SOF, and channel ID).
    // Hmm. I don't know how to get hold of the address of the XTR_LAST_CHUNK_STAT, so I hardcode it.
    vtss_fdma_endian_aware_raw_writel(VTSS_CH_DSTATAR(ch), VTSS_FDMA_LAST_CHUNK_PHYS_ADDR(ch));

    // We enable block interrupts for extraction channels, so that we get an interrupt every time a DCB has been filled with
    // data. If we used Transfer Done interrupts, we wouldn't get an interrupt until the list of DCBs was exhausted.
    // We also, on the other hand enable transfer done interrupts. This is needed in order to restart a channel if it happens
    // that the list of DCBs gets exhausted, which may occur if the FDMA transfers packets faster than the operating system
    // can take them off.
    enable_block_done_intr(ch);
    enable_tfr_done_intr(ch);

    // Clear pending interrupts
    clear_pending_block_done_intr(VTSS_BIT(ch));
    clear_pending_tfr_done_intr  (VTSS_BIT(ch));

    // Enable the channel
    enable_ch(ch);
  } else {
    // Suspend the channel
    disable_ch(ch);
    ch_state->usage = VTSS_FDMA_CH_USAGE_UNUSED;
    ch_state->state = VTSS_FDMA_CH_STATE_DISABLED;

    // Disable block and transfer interrupts for the channel. Clearing of the interrupts occur
    // if the channel gets re-enabled.
    disable_block_done_intr(ch);
    disable_tfr_done_intr(ch);
  }
}

/*****************************************************************************/
// vtss_fdma_xtr_add_dcbs()
// Use this function to add more DCBs to the current list of DCBs. This may
// be used if the xtr_cb() function  doesn't return a new list of DCBs whenever
// called, which may be the case if it needs to dispatch the frames to
// slow worker-threads. When those worker-threads are done, the buffers can
// go back to the FDMA.
// This function may be called while the channel is active or inactive, as
// needed. It disables interrupts while manipulating the lists.
/*****************************************************************************/
void vtss_fdma_xtr_add_dcbs(int ch, vtss_fdma_list_head_t *list)
{
  vtss_fdma_ch_state_t *ch_state = &vtss_fdma_ch_state[ch];
  vtss_fdma_list_head_t *new_tail;
  VTSS_FDMA_INTERRUPT_FLAGS flags;
#ifdef VTSS_FDMA_KEEP_STATISTICS
  u32 dcb_cnt;
#endif

  // Valid channel?
  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);

  // Configured for extraction and enabled?
  VTSS_FDMA_ASSERT(ch_state->usage==VTSS_FDMA_CH_USAGE_XTR && ch_state->state==VTSS_FDMA_CH_STATE_ENABLED);

  // Valid list?
  VTSS_FDMA_ASSERT(list);

  // This can safely be done without disabling interrupts:
#ifdef VTSS_FDMA_KEEP_STATISTICS
  new_tail = xtr_dcb_init(ch, list, &dcb_cnt);
#else
  new_tail = xtr_dcb_init(ch, list);
#endif

  // While manipulating the free list, we cannot allow interrupts to occur,
  // since they may also manipulate the list.
  VTSS_FDMA_DISABLE_INTERRUPTS(flags);

#ifdef VTSS_FDMA_KEEP_STATISTICS
  vtss_fdma_stats.rx_bufs_added[ch_state->qu_or_port] += dcb_cnt;
#endif

  // Connect to existing free list or create a new:
  xtr_connect(ch_state, list, new_tail);

  // Check to see if we must manually re-start the channel. This is the case
  // when ch_state->cur_head is NULL, because then the last DCB has been handled
  // by the interrupt handler, and the "extraction transfer done" interrupt
  // has also been called, which found no new DCBs in the free list.
  // The xtr_irq_tfr_done() must be tolerant for this, because it may happen that
  // while we are executing this code, a transfer-done interrupt is already 
  // pending, which would - if not tolerant - cause the xtr_restart_ch() to
  // be called twice.
  if(ch_state->cur_head==NULL)
    xtr_restart_ch(ch_state, ch);
  
  VTSS_FDMA_RESTORE_INTERRUPTS(flags);
}

/*****************************************************************************/
/*****************************************************************************/
int inline vtss_fdma_xtr_ch_from_list(vtss_fdma_list_head_t *list)
{
  vtss_fdma_dcb_t *dcb_ptr;
  VTSS_FDMA_ASSERT(list);
  dcb_ptr=(vtss_fdma_dcb_t *)list->dcb;
  return (dcb_ptr->sar>>VTSS_FDMA_F_SAR_CH_ID_FPOS) & VTSS_BITMASK(VTSS_FDMA_F_SAR_CH_ID_FLEN);
}

/*****************************************************************************/
// vtss_fdma_set_tx_flow_ctrl_cfg()
// @port:           [0; VTSS_PHYS_PORT_CNT[. Conveys the front port number
//                  that the rest of the parameters pertain to.
// @tx_flow_ctrl:   0 or 1. If 1, software will check for super priority
//                  queue overflow prior to asking the queue system to
//                  transmit the frame. If the queue is overflown, S/W
//                  will rewind and possibly attempt a re-transmit (see
//                  next parameter).
// @retransmit_cnt: The number of times a retransmission will be attempted
//                  before dropping it. This is only used if
//                  tx_flow_ctrl parameter is 1.
/*****************************************************************************/
void vtss_fdma_set_tx_flow_ctrl_cfg(int port, unsigned char tx_flow_ctrl, unsigned char retransmit_cnt)
{
  VTSS_FDMA_ASSERT(port>=0 && port<VTSS_PHYS_PORT_CNT);
  VTSS_FDMA_ASSERT(tx_flow_ctrl==0 || tx_flow_ctrl==1);
  vtss_fdma_port_state[port].cfg_tx_flow_ctrl   = tx_flow_ctrl;
  vtss_fdma_port_state[port].cfg_retransmit_cnt = retransmit_cnt;
}

/*****************************************************************************/
// vtss_fdma_get_tx_flow_ctrl_cfg()
// @port:           [0; VTSS_PHYS_PORT_CNT[. Conveys the front port number
//                  that the rest of the parameters pertain to.
// @tx_flow_ctrl:   Returns the current value of whether it's in TX flow
//                  control mode (1) or not (0).
// @retransmit_cnt: Returns the number of times a frame re-transmission will
//                  be attempted.
/*****************************************************************************/
void vtss_fdma_get_tx_flow_ctrl_cfg(int port, unsigned char *tx_flow_ctrl, unsigned char *retransmit_cnt)
{
  VTSS_FDMA_ASSERT(port>=0 && port<VTSS_PHYS_PORT_CNT);
  VTSS_FDMA_ASSERT(tx_flow_ctrl);
  VTSS_FDMA_ASSERT(retransmit_cnt);
  *tx_flow_ctrl   = vtss_fdma_port_state[port].cfg_tx_flow_ctrl;
  *retransmit_cnt = vtss_fdma_port_state[port].cfg_retransmit_cnt;
}

/*****************************************************************************/
/*****************************************************************************/
void vtss_fdma_inj_cfg(int ena, int ch)
{
  // Valid channel?
  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);

  if(ena) {
    // Check parameters and the current state
    VTSS_FDMA_ASSERT(vtss_fdma_ch_state[ch].state==VTSS_FDMA_CH_STATE_DISABLED);

    // Whether we're in little or big endian mode we need to swap the data bytes
    // between DDR SDRAM and the SwC, because the SwC expects them in big endian
    // format, and since the data when stored in DDR SDRAM is a stream of single
    // bytes, there's no difference on their layout in memory in little and big
    // endian mode.
    vtss_fdma_endian_aware_raw_writel(VTSS_GPDMA_FDMA_COMMON_CFG, VTSS_F_DATA_BYTE_SWAP);

    vtss_fdma_ch_state[ch].usage        = VTSS_FDMA_CH_USAGE_INJ;
    vtss_fdma_ch_state[ch].state        = VTSS_FDMA_CH_STATE_ENABLED;
    vtss_fdma_ch_state[ch].cur_head     = NULL;
    vtss_fdma_ch_state[ch].cur_tail     = NULL;
    vtss_fdma_ch_state[ch].pend_head    = NULL;
    vtss_fdma_ch_state[ch].qu_or_port   = -1; // Currently the channel is not configured for any front port

    // Since the same channel can be used to inject to different ports, and since we need to re-configure
    // the DMA controller if the port changes, we must get a new interrupt for every frame that has been
    // injected. Therefore we make sure that the DCB->llp is NULL for the last DCB of every
    // frame, and that the interrupt enable flag in DCB->ctl1 is 1 for the EOF DCB, only.
    // When the DMA controller has injected the EOF DCB, it will then invoke the transfer done interrupt
    // so that we can notify the callback function that the frame has been transmitted, and possibly
    // restart the controller if there're pending frames.
    enable_tfr_done_intr(ch);

  } else {
    // Suspend the channel
    disable_ch(ch);
    vtss_fdma_ch_state[ch].usage = VTSS_FDMA_CH_USAGE_UNUSED;
    vtss_fdma_ch_state[ch].state = VTSS_FDMA_CH_STATE_DISABLED;
    disable_tfr_done_intr(ch);
  }
}

/*****************************************************************************/
// Stores a field in the IFH in the current CPU endianness.
// Had to make this an inline function rather than a macro because fpos is
// always a constant, so if using fpos>31 with fpos as a constant would
// generate compiler warnings. And unfortunately it's not possible to use
// preprocess-definitions within a macro definition. But with the proper
// optimization level, the inline function will expand and the compiler will
// figure out what to do.
/*****************************************************************************/
static inline void ifh_put(u32 *ifh0, u32 *ifh1, u32 fpos, u32 val)
{
  if(fpos>31) 
    *ifh0 |= (val<<(fpos-32));
  else 
    *ifh1 |= (val<<fpos);
}

/*****************************************************************************/
/*****************************************************************************/
static inline void cmd_put(u32 *cmd, u32 fpos, u32 val)
{
  *cmd |= (val<<fpos);
}

/*****************************************************************************/
/*****************************************************************************/
static inline void inj_ifh_and_cmd_init(u32 *data_ptr, int port, int frm_sz_bytes_excl_ifh_cmd, vtss_fdma_inj_props_t *props)
{
  u32 ifh_cmd_cpu_endian[3] = {0, 0, 0};
  u32 ifh_cmd_little_endian[3];
  int i;

  // At least when using the CPU PM to inject the frame, the source_port field of the IFH must be set or the frame will be aged, because we don't set the timestamp in the IFH.
  ifh_put(&ifh_cmd_cpu_endian[0], &ifh_cmd_cpu_endian[1], VTSS_FDMA_IFH_F_LEN_FPOS,      frm_sz_bytes_excl_ifh_cmd);
  ifh_put(&ifh_cmd_cpu_endian[0], &ifh_cmd_cpu_endian[1], VTSS_FDMA_IFH_F_SRC_PORT_FPOS, port);
  ifh_put(&ifh_cmd_cpu_endian[0], &ifh_cmd_cpu_endian[1], VTSS_FDMA_IFH_F_VID_FPOS,      props->vlan);
  ifh_put(&ifh_cmd_cpu_endian[0], &ifh_cmd_cpu_endian[1], VTSS_FDMA_IFH_F_QOS_FPOS,      3); // Highest priority (nice for IP traffic through CPU PM across congested stack links)

  if(props->contains_stack_hdr) {
    u32 port_as_mask = 1UL << (u32)port;
    ifh_put(&ifh_cmd_cpu_endian[0], &ifh_cmd_cpu_endian[1], VTSS_FDMA_IFH_F_STACK_HDR_FPOS, 1);
    if(port_as_mask & VTSS_FDMA_STACK_PORT_A_MASK) {
      ifh_put(&ifh_cmd_cpu_endian[0], &ifh_cmd_cpu_endian[1], VTSS_FDMA_IFH_F_STACK_LINK_A_FPOS, 1);
    } else if(port_as_mask & VTSS_FDMA_STACK_PORT_B_MASK) {
      ifh_put(&ifh_cmd_cpu_endian[0], &ifh_cmd_cpu_endian[1], VTSS_FDMA_IFH_F_STACK_LINK_B_FPOS, 1);
    } else {
      // Cannot inject stack headered frame on non stack-port as we don't
      // know what to set the stack_info.stack_link bits to.
      // Allow these options to be used if this function is not writing the real IFH, though!
      VTSS_FDMA_ASSERT(props->dont_touch_ifh); 
    }
  }

  // Initialize the CMD
  if(port==VTSS_CPU_PM_NUMBER) {
    // We have the option of switching the frame. If so, we set the 'do_analyze' flag and leave the port mask 0.
    // Otherwise, we leave the 'do_analyze' 0 and set the 'frame_dest' to whatever the user wants.
    // In both cases we set the CMD field's 'tx' flag.
    if(props->switch_frm) {
      ifh_put(&ifh_cmd_cpu_endian[0], &ifh_cmd_cpu_endian[1], VTSS_FDMA_IFH_F_AGGR_CODE_FPOS, props->aggr_code);
      cmd_put(&ifh_cmd_cpu_endian[2], VTSS_FDMA_CMD_F_DOANALYZE_FPOS, 1);
    } else {
      cmd_put(&ifh_cmd_cpu_endian[2], VTSS_FDMA_CMD_F_FRAMEDEST_FPOS, props->port_mask);
    }

    cmd_put(&ifh_cmd_cpu_endian[2], VTSS_FDMA_CMD_F_CPU_TX_FPOS, 1);
  } else {
    // Set the TX flag if we're not in Tx flow control mode.
    // In flow control mode we check for overflow after
    // FDMA controlled injection and set the flag in S/W if
    // no overflow occurred.
    if(vtss_fdma_port_state[port].cfg_tx_flow_ctrl==0) {
      cmd_put(&ifh_cmd_cpu_endian[2], VTSS_FDMA_CMD_F_CPU_TX_FPOS, 1);
    }
  }

  // Make endianness aware. ifh_cmd_cpu_endian[] is stored in the current
  // CPU endianness in DDR RAM. We need it stored in little endian
  // for the FDMA to understand it.
  for(i=0; i<3; i++) {
    ifh_cmd_little_endian[i] = vtss_fdma_to_little_endian(ifh_cmd_cpu_endian[i]);
  }

  if((((u32)data_ptr)&0x3)==0) {
    // The IFH and CMD fields are 32-bit aligned. Make 32-bit writes.
    // Only update the IFH if we're allowed to
    if(props->dont_touch_ifh==0) {
      // Initialize the IFH
      data_ptr[0] = ifh_cmd_little_endian[0];
      data_ptr[1] = ifh_cmd_little_endian[1];
    }
    data_ptr[2]=ifh_cmd_little_endian[2];
  } else {
    // The IFH and CMD fields are *not* 32-bit aligned (the FDMA supports this!).
    // Make 8-bit writes.
    unsigned char *dst_ptr=(unsigned char *)data_ptr;
    unsigned char *src_ptr=(unsigned char *)ifh_cmd_little_endian;
    int cnt=sizeof(ifh_cmd_little_endian);
    if(props->dont_touch_ifh) {
      // Skip IFH
      dst_ptr += VTSS_FDMA_IFH_SIZE_BYTES;
      src_ptr += VTSS_FDMA_IFH_SIZE_BYTES;
      cnt     -= VTSS_FDMA_IFH_SIZE_BYTES;
    }

    // Do the byte-by-byte copy
    for(i=0; i<cnt; i++)
      *(dst_ptr++) = *(src_ptr++);
  }
}

/*****************************************************************************/
// @l : NULL-terminated List of DCBs
// @ch: The channel that this one goes through.
// In debug mode, it also takes a pointer to an integer, whl_frm_sz_bytes,
// which is filled with the total frame size, including IFH, CMD, and FCS,
// computed based on each fragment size.
// The function returns a pointer to the last list item used for this frame.
/*****************************************************************************/
#ifdef VTSS_FDMA_DBG
  #ifdef VTSS_FDMA_KEEP_STATISTICS
    static inline vtss_fdma_list_head_t *inj_dcb_init(int ch, vtss_fdma_list_head_t *l, int *whl_frm_sz_bytes, u32 *dcb_cnt)
  #else
    static inline vtss_fdma_list_head_t *inj_dcb_init(int ch, vtss_fdma_list_head_t *l, int *whl_frm_sz_bytes)
  #endif
#else
  #ifdef VTSS_FDMA_KEEP_STATISTICS
    static inline vtss_fdma_list_head_t *inj_dcb_init(int ch, vtss_fdma_list_head_t *l, u32 *dcb_cnt)
  #else
    static inline vtss_fdma_list_head_t *inj_dcb_init(int ch, vtss_fdma_list_head_t *l)
  #endif
#endif
{
  u32 *phys_data_ptr, phys_data_off;
  vtss_fdma_dcb_t *dcb_ptr;
  int frag_sz_bytes;
  int sof=1, eof, port=l->alloc_len_or_port;
  vtss_fdma_list_head_t *tail=l;

#ifdef VTSS_FDMA_DBG
  *whl_frm_sz_bytes=0;
#endif

#ifdef VTSS_FDMA_KEEP_STATISTICS
  *dcb_cnt=0;
#endif

  while(l) {
    VTSS_FDMA_ASSERT(l->data);
    frag_sz_bytes = l->act_len;
    VTSS_FDMA_ASSERT(((frag_sz_bytes >= VTSS_FDMA_MIN_DATA_PER_INJ_SOF_DCB_BYTES && sof==1) || (frag_sz_bytes >= VTSS_FDMA_MIN_DATA_PER_NON_SOF_DCB_BYTES && sof==0)) && frag_sz_bytes <= VTSS_FDMA_MAX_DATA_PER_DCB_BYTES);

    // Due to a bug in the FDMA, all non-EOF DCBs' associated data area cannot have a size that is not a multiple of 4.
    // This is documented in GNATS #5355.
    // For testing, it is possible to turn off this check.
    #ifndef VTSS_FDMA_IGNORE_GNATS_5355
    VTSS_FDMA_ASSERT(l->next==NULL || (frag_sz_bytes&0x3)==0);
    #endif
    
    phys_data_ptr = (u32 *)VTSS_FDMA_VIRT_TO_PHYS(l->data);
    phys_data_off = (u32)phys_data_ptr&0x3;
    dcb_ptr = (vtss_fdma_dcb_t *)l->dcb;
    // The H/W DCB should be cache-line-size aligned
    VTSS_FDMA_ASSERT(((u32)dcb_ptr&(VTSS_FDMA_CACHE_LINE_SIZE_BYTES-1))==0);
#ifdef VTSS_FDMA_DBG
    *whl_frm_sz_bytes += frag_sz_bytes;
#endif
    eof = l->next==NULL;

    dcb_ptr->sar  = vtss_fdma_to_little_endian((u32)phys_data_ptr&~0x3);
    dcb_ptr->dar  = vtss_fdma_to_little_endian((VTSS_FDMA_DAR_EOF(eof) | VTSS_FDMA_DAR_SOF(sof) | VTSS_FDMA_DAR_CH_ID(ch) | VTSS_FDMA_DAR_CHUNK_SIZE(frag_sz_bytes) | VTSS_FDMA_DAR_SAR_OFFSET(phys_data_off)));
    dcb_ptr->llp  = vtss_fdma_to_little_endian(l->next ? VTSS_FDMA_VIRT_TO_PHYS(l->next->dcb) : 0); // NULL
    dcb_ptr->ctl0 = vtss_fdma_to_little_endian(VTSS_F_LLP_SRC_EN | VTSS_F_LLP_DST_EN | VTSS_F_DMS(1) | VTSS_F_SRC_MSIZE(3) | VTSS_F_DEST_MSIZE(3) | VTSS_F_DINC(2) | VTSS_F_SRC_TR_WIDTH(2) | VTSS_F_DST_TR_WIDTH(2) | eof); // We only want interrupts if this is the EOF.
    if(port==VTSS_CPU_PM_NUMBER)
      dcb_ptr->ctl0 |= vtss_fdma_to_little_endian(VTSS_F_TT_FC(1));

    // If the data area is non-32-bit-aligned (as is the case for Linux), then we need to check if we're gonna inject one more 32-bit word.
    dcb_ptr->ctl1  = vtss_fdma_to_little_endian((frag_sz_bytes + phys_data_off + 3)/4); // BLOCK_TS
    dcb_ptr->sstat = vtss_fdma_to_little_endian(dcb_ptr->dstat = 0);

    VTSS_FDMA_BARRIER();

    // Flush the dcache, so that the DCB gets written to main memory.
    VTSS_FDMA_FLUSH_DCACHE_DCB(dcb_ptr, VTSS_FDMA_DCB_SIZE_BYTES);

    VTSS_FDMA_BARRIER();

    // Flush the dcache, so that the frame data gets written to main memory.
    VTSS_FDMA_FLUSH_DCACHE_DATA(l->data, frag_sz_bytes);

#ifdef VTSS_FDMA_KEEP_STATISTICS
    (*dcb_cnt)++;
#endif

    // Prepare for next iteration
    sof = 0;
    if(l->next)
      tail = l->next;
    l = l->next;
  }
  return tail;
}

/*****************************************************************************/
/*****************************************************************************/
static void inj_ch_init(vtss_fdma_ch_state_t *ch_state, vtss_fdma_dcb_t *dcb_ptr, int ch, int port)
{
  u32 port_as_mask = 1UL << (u32)port;
  // Use Egress Device or CPU Port Module for injection.
  // Only re-program the DMA controller if the egress port has changed.
  if(ch_state->qu_or_port != port) {
    // We need to re-configure the DMA channel to inject to another front port.
    if(port<16)
      vtss_fdma_endian_aware_raw_writel(GPDMA_FDMA_CH_CFG_0(ch), VTSS_F_MODULE(1) | VTSS_F_SUB_MODULE(port)      | VTSS_F_DATA_ADDR(0xC0));
    else
      vtss_fdma_endian_aware_raw_writel(GPDMA_FDMA_CH_CFG_0(ch), VTSS_F_MODULE(6) | VTSS_F_SUB_MODULE((port-16)) | VTSS_F_DATA_ADDR(0xC0));

    if(port==VTSS_CPU_PM_NUMBER)
      vtss_fdma_endian_aware_raw_writel(GPDMA_FDMA_INJ_CFG(ch), VTSS_F_INJ_HDR_ENA);
    else if((port_as_mask & VTSS_FDMA_STACK_PORT_A_MASK) || (port_as_mask & VTSS_FDMA_STACK_PORT_B_MASK))
      vtss_fdma_endian_aware_raw_writel(GPDMA_FDMA_INJ_CFG(ch), VTSS_F_INJ_CFG_WR_DELAY(VTSS_FDMA_INJ_WR_DELAY_2_5G_PORTS));
   else
      vtss_fdma_endian_aware_raw_writel(GPDMA_FDMA_INJ_CFG(ch), VTSS_F_INJ_CFG_WR_DELAY(VTSS_FDMA_INJ_WR_DELAY_1G_PORTS));

    // Set-up automated load of DCBs
    vtss_fdma_endian_aware_raw_writel(GPDMA_FDMA_CH_CFG_1(ch), VTSS_F_USAGE | VTSS_F_FC_INJ_ENA); // USAGE=injection and FC_INJ_ENA
    vtss_fdma_endian_aware_raw_writel(VTSS_CH_CTL0(ch), VTSS_F_LLP_SRC_EN | VTSS_F_LLP_DST_EN); // We just need to enable LLP_SRC_EN and LLP_DST_EN here since the first descriptor overwrites the remaining fields anyway.

    if(port<VTSS_CPU_PM_NUMBER) {
      vtss_fdma_endian_aware_raw_writel(VTSS_CH_CFG0(ch), VTSS_F_LOCK_CH | VTSS_F_HS_SEL_SRC | VTSS_F_HS_SEL_DST | VTSS_F_CH_PRIOR(ch)); // HS_SEL_SRC=HS_SEL_DST=1=Software Initiated. Use channel locking, so that no other channels are granted for the whole transfer (in order to avoid interleaving data)
      vtss_fdma_endian_aware_raw_writel(VTSS_CH_CFG1(ch), VTSS_F_PROTCTL(1)); // PROTCTL=1, DST_PER=inj_ch, FCMODE=0; // Well, maybe not when injecting into egress port?
    } else {
      vtss_fdma_endian_aware_raw_writel(VTSS_CH_CFG0(ch), VTSS_F_LOCK_CH | VTSS_F_HS_SEL_SRC | VTSS_F_CH_PRIOR(ch));  // HS_SEL_SRC=1=Software Initiated, HS_SEL_DST=0=H/W Initiated. Use channel locking, so that no other channels are granted for the whole transfer (in order to avoid interleaving data)
      vtss_fdma_endian_aware_raw_writel(VTSS_CH_CFG1(ch), VTSS_F_DST_PER(ch) | VTSS_F_PROTCTL(1) | VTSS_F_FCMODE); // PROTCTL=1, DST_PER=inj_ch, FCMODE=1; // Well, maybe not when injecting into egress port?
    }
    ch_state->qu_or_port = port;
  }

  vtss_fdma_endian_aware_raw_writel(VTSS_CH_LLP(ch), VTSS_FDMA_VIRT_TO_PHYS(dcb_ptr));
}

/*****************************************************************************/
// @len: Length of frame in bytes, excluding IFH and CMD, but including FCS.
/*****************************************************************************/
void vtss_fdma_inj(vtss_fdma_list_head_t *l, int ch, int len, vtss_fdma_inj_props_t *props)
{
  vtss_fdma_ch_state_t *ch_state;
  VTSS_FDMA_INTERRUPT_FLAGS flags;
  int port;
  vtss_fdma_list_head_t *new_tail;
#ifdef VTSS_FDMA_DBG
  int computed_whl_frm_sz_bytes;
#endif
#ifdef VTSS_FDMA_KEEP_STATISTICS
  u32 dcb_cnt;
#endif

  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);
  ch_state=&vtss_fdma_ch_state[ch];
  VTSS_FDMA_ASSERT(ch_state->state != VTSS_FDMA_CH_STATE_DISABLED);
  VTSS_FDMA_ASSERT(ch_state->usage == VTSS_FDMA_CH_USAGE_INJ);
  VTSS_FDMA_ASSERT(l);
  VTSS_FDMA_ASSERT(len >= VTSS_FDMA_MIN_FRAME_SIZE_BYTES && len <= VTSS_FDMA_MAX_FRAME_SIZE_BYTES);
  port = l->alloc_len_or_port;
  VTSS_FDMA_ASSERT(port>=0 && port<VTSS_TOTAL_PORT_CNT);
  VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_INJ_VERBOSE, "vtss_fdma_inj(ch=%d, p=%d, l=%d). ", ch, port, len);

  inj_ifh_and_cmd_init((u32 *)l->data, port, len, props);
#ifdef VTSS_FDMA_DBG
  #ifdef VTSS_FDMA_KEEP_STATISTICS
  new_tail = inj_dcb_init(ch, l, &computed_whl_frm_sz_bytes,&dcb_cnt);
  #else
  new_tail = inj_dcb_init(ch, l, &computed_whl_frm_sz_bytes);
  #endif
  VTSS_FDMA_ASSERT(computed_whl_frm_sz_bytes == len + VTSS_FDMA_IFH_SIZE_BYTES + VTSS_FDMA_CMD_SIZE_BYTES);
#else
  #ifdef VTSS_FDMA_KEEP_STATISTICS
  new_tail = inj_dcb_init(ch, l, &dcb_cnt);
  #else
  new_tail = inj_dcb_init(ch, l);
  #endif
#endif
  
  // Add the frame to the end of the current list. 
  // Since both the interrupt handler and this function can alter the current
  // list, we need to safe-guard it by disabling interrupts while manipulating
  // the pointers.
  // We get one transfer done interrupt for every frame that has been injected,
  // and the channel stops. The interrupt handler is taking care of restarting
  // the channel if there are more frames to go. If - on the other hand - the
  // interrupt handler is not currently active, we should start it.
  VTSS_FDMA_DISABLE_INTERRUPTS(flags);
#ifdef VTSS_FDMA_KEEP_STATISTICS
  // Safe to update now.
  vtss_fdma_stats.tx_bufs_used[ch]++;
  vtss_fdma_stats.tx_bytes[ch] += len; // This should've been counted in the IRQ handler, but in that function we would have to re-compute the total length, which takes time!
#endif
  if(ch_state->cur_tail==NULL) {
    // Since the DMA channel is non-active, we can re-allow interrupts immediately.
    VTSS_FDMA_RESTORE_INTERRUPTS(flags);
    VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_INJ_SPARSE, "vtss_fdma_inj(ch=%d, p=%d, l=%d). Start immediately\n", ch, port, len);

    // The DMA channel is inactive.
    VTSS_FDMA_ASSERT((vtss_fdma_endian_aware_raw_readl(VTSS_MISC_CH_EN_REG)&VTSS_BIT(ch))==0);
    VTSS_FDMA_ASSERT(ch_state->cur_head==NULL);

    ch_state->cur_head = l;
    ch_state->cur_tail = new_tail;

    // Re-initialize the state retransmit count for the new frame.
    vtss_fdma_port_state[port].state_retransmit_cnt = vtss_fdma_port_state[port].cfg_retransmit_cnt;

    // Start the channel if allowed to.
    if(!vtss_fdma_port_state[port].suspended) {
      vtss_fdma_port_state[port].active_cnt++;
      inj_ch_init(ch_state, (vtss_fdma_dcb_t *)l->dcb, ch, port);
      enable_ch(ch);
    }
  } else {
    VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_INJ_SPARSE, "vtss_fdma_inj(ch=%d, p=%d, l=%d). Append to existing\n", ch, port, len);

    // It doesn't matter whether the DMA channel is running right now or not,
    // since we can't get into the interrupt handler, and since the tail's
    // DCB->llp is NULL, which means that the DMA controller will
    // definitely stop before it starts consuming the frame we're trying to add.
    VTSS_FDMA_ASSERT(ch_state->cur_head); // When the tail is non-NULL, so must the head be.
    VTSS_FDMA_ASSERT(ch_state->cur_tail->next==NULL);
    ch_state->cur_tail->next = l;
    ch_state->cur_tail = new_tail;
    
    // Since the tail is non-zero, we know that the interrupt handler will get invoked
    // at some point in time, so if VTSS_MISC_CH_EN_REG(ch)==1, the DMA controller is
    // not yet done with the previous frame. If it's 0, the previous frame is done and
    // we must be having a pending interrupt. Well, if the destination port is suspended
    // it may be that upper layers have added a packet, so that tail is non-zero when
    // they try to add a second packet. So suspended needs to be part of the assertion
    // below.
    VTSS_FDMA_ASSERT(vtss_fdma_port_state[port].suspended || ((vtss_fdma_endian_aware_raw_readl(VTSS_MISC_CH_EN_REG)&VTSS_BIT(ch)) || (vtss_fdma_endian_aware_raw_readl(VTSS_INTR_STATUS_TFR)&VTSS_BIT(ch))));
    VTSS_FDMA_RESTORE_INTERRUPTS(flags);
  }
}

/*****************************************************************************/
// vtss_fdma_inj_suspend_port()
// By calling this function with suspend!=0, the FDMA will not be re-started
// with *new* frames destined for the port. In order to assure that the FDMA
// is currently not injecting frames to the port, the user will have to call
// vtss_fdma_inj_port_active().
// Once suspended, it cannot be resumed until possible current frames to the
// port are complete.
/*****************************************************************************/
void vtss_fdma_inj_suspend_port(int port, int suspend)
{
  VTSS_FDMA_ASSERT(port>=0 && port<VTSS_TOTAL_PORT_CNT);
  if(suspend) {
    // Simply set the suspended bit. This will cause a channel injecting
    // to the port to stall after the current frame has been attempted
    // injected.
    vtss_fdma_port_state[port].suspended=1;
  } else {
    int ch;
    VTSS_FDMA_INTERRUPT_FLAGS flags;
    VTSS_FDMA_ASSERT(vtss_fdma_port_state[port].suspended);
    VTSS_FDMA_ASSERT(vtss_fdma_port_state[port].active_cnt==0);
    // We'll have to restart all the channels whose next frame is destined
    // for the port. And we have to do these tests with interrupts (scheduler)
    // disabled. Otherwise we could end up with testing the cur_head for being
    // non-NULL, then an interrupt could remove it, then this code would check
    // the alloc_len_or_port on a now-NULL cur_head.
    VTSS_FDMA_DISABLE_INTERRUPTS(flags);
    // Restart channels in priority order
    for(ch = VTSS_FDMA_CH_CNT-1; ch >= 0; ch--) {
      vtss_fdma_ch_state_t *ch_state=&vtss_fdma_ch_state[ch];
      if(ch_state->usage==VTSS_FDMA_CH_USAGE_INJ && ch_state->cur_head && ch_state->cur_head->alloc_len_or_port==port) {
        vtss_fdma_port_state[port].active_cnt++;
        inj_ch_init(ch_state, (vtss_fdma_dcb_t *)ch_state->cur_head->dcb, ch, port);
        enable_ch(ch);
      }
    }
    vtss_fdma_port_state[port].suspended=0;
    VTSS_FDMA_RESTORE_INTERRUPTS(flags);
  }
}

/*****************************************************************************/
// vtss_fdma_inj_port_active()
// Returns the number of channels that are currently attempting to inject
// to the given port.
/*****************************************************************************/
int vtss_fdma_inj_port_active(int port)
{
  VTSS_FDMA_ASSERT(port>=0 && port<VTSS_TOTAL_PORT_CNT);
  return vtss_fdma_port_state[port].active_cnt;
}

/****************************************************************************/
// Extract fields from the IFH
// This function is only used if VTSS_FDMA_IGNORE_GNATS_5418 is not defined, so
// to avoid a warning if it *is* defined, encapsulate it in #ifndef (an 
// alternative is to declare it non-static).
/****************************************************************************/
#ifndef VTSS_FDMA_IGNORE_GNATS_5418
static inline u32 ifh_get(u32 ifh0, u32 ifh1, u32 fpos, u32 flen)
{
  if(fpos>31) 
    return (ifh0>>(fpos-32))&VTSS_BITMASK(flen);
  else
    return (ifh1>>fpos)&VTSS_BITMASK(flen);
}
#endif

/*****************************************************************************/
/*****************************************************************************/
static int xtr_irq_block_done(void *cntxt, int ch)
{
  int xtr_cnt_dwords, total_frm_size_bytes_excl_ifh, bytes_valid_in_last_word, drop_it=0;
  vtss_fdma_ch_state_t *ch_state;
  vtss_fdma_dcb_t *dcb_ptr;
  vtss_fdma_list_head_t *new_list, *new_tail, *new_head, *temp_list;
  u32 ctl1, dstat;
#ifdef VTSS_FDMA_KEEP_STATISTICS
  u32 dcb_cnt;
#endif
#ifdef VTSS_FDMA_DBG
  int debug_sum;
#endif

  VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_XTR_VERBOSE, "xtr_irq_block_done(ch=%d)\n", ch);
  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);
  ch_state = &vtss_fdma_ch_state[ch];
  VTSS_FDMA_ASSERT(ch_state->state != VTSS_FDMA_CH_STATE_DISABLED);
  VTSS_FDMA_ASSERT(ch_state->usage == VTSS_FDMA_CH_USAGE_XTR);

  // Iterate over all DCBs and stop when we reach one with the DONE bit cleared.
  while(ch_state->cur_head) {
    dcb_ptr = (vtss_fdma_dcb_t *)ch_state->cur_head->dcb;

    // Before dereferencing the DCB, we must invalidate the cache line(s).
    VTSS_FDMA_INVALIDATE_DCACHE_DCB(dcb_ptr, VTSS_FDMA_DCB_SIZE_BYTES);
    VTSS_FDMA_BARRIER();

    // If the DONE bit is not set, we've consumed all the frames, and we're done.
    ctl1 = vtss_fdma_to_little_endian(dcb_ptr->ctl1);
    if(((ctl1>>12)&0x1)==0)
      break;

#ifdef VTSS_FDMA_KEEP_STATISTICS
    vtss_fdma_stats.rx_bufs_used[ch_state->qu_or_port]++;
#endif

    // Bits 11:0 of dcb->ctl1 indicate the number of 32-bit words
    // extracted to the data area, so that's what we invalidate there.
    xtr_cnt_dwords = ctl1&0xFFF;
    VTSS_FDMA_INVALIDATE_DCACHE_DATA(ch_state->cur_head->data, 4*xtr_cnt_dwords);
    VTSS_FDMA_BARRIER();
 
    // We don't expect zero or more than alloc_len bytes to having been extracted
    // to the data area.
    VTSS_FDMA_ASSERT_MSG(xtr_cnt_dwords>0 && 4*xtr_cnt_dwords<=ch_state->cur_head->alloc_len_or_port, "xtr_cnt_dwords=%d, alloc_len_or_port=%d\n",xtr_cnt_dwords, ch_state->cur_head->alloc_len_or_port);
 
    // Check that the queue that the FDMA thinks it extracted from matches the
    // queue that software thinks it extracts from.
    dstat = vtss_fdma_to_little_endian(dcb_ptr->dstat);
    VTSS_FDMA_ASSERT(((dstat>>4)&(VTSS_FDMA_XTR_QU_CNT-1))==ch_state->qu_or_port);

    // If we're receiving a jumbo frame (or a frame that is larger
    // than what we've reserved of space in the data area), we may
    // not have received it all. If the EOF flag in the DCB is not
    // set, this is the case, and we need to receive the remainder of
    // the frame before passing it on.
    if ((dstat>>1)&0x1) {
      // EOF reached. Pass the frame on to the callback function.
 
      // Terminate the current list item before passing it on, but
      // save a reference to the new head.
      new_head = ch_state->cur_head->next;
      ch_state->cur_head->next=NULL;
 
      if(!ch_state->pend_head) {
        // The frame is not part of a jumbo frame, so we
        // expect the SOF flag to be set in the DCB
        // GNATS #5299: If the frame fills up a DCB, the SOF flag is not set.
        #ifdef VTSS_FDMA_IGNORE_GNATS_5299
        VTSS_FDMA_ASSERT(dstat&0x1);
        #endif
 
        // For further, unified processing, we move the current DCB to the pending list.
        ch_state->pend_head = ch_state->cur_head;
      } else {
        // The frame is part of a jumbo frame.
        // In that case, the SOF flag can't be set, because the SOF is
        // already received and moved to the pending list.
        VTSS_FDMA_ASSERT((dstat&0x1)==0);
 
        // Attach the current list item to the end of the pending list.
        temp_list = ch_state->pend_head;
        while(temp_list->next) {
          temp_list = temp_list->next;
        }
        temp_list->next = ch_state->cur_head;
      }
 
      // Update the current fragment's actual length. For the EOF
      // DCB this need not be a multiple of 4, as is the case for
      // non-EOF DCBs. We use the IFH's total frame length to figure
      // out how many bytes are valid in this last fragment.
      total_frm_size_bytes_excl_ifh = (vtss_fdma_to_little_endian(((u32 *)ch_state->pend_head->data)[0])>>16) & 0x3FFF;
      bytes_valid_in_last_word = total_frm_size_bytes_excl_ifh & 0x3;
      if(!bytes_valid_in_last_word)
        bytes_valid_in_last_word=4;
      ch_state->cur_head->act_len = 4*xtr_cnt_dwords - (4 - bytes_valid_in_last_word);

#ifdef VTSS_FDMA_DBG
      // Before sending off the frame, check that all the fragment
      // sizes sum up to the frame length indicated in the IFH.
      temp_list = ch_state->pend_head;
      debug_sum = 0;
      while(temp_list) {
        debug_sum += temp_list->act_len;
        temp_list = temp_list->next;
      }
      VTSS_FDMA_ASSERT(total_frm_size_bytes_excl_ifh + VTSS_FDMA_IFH_SIZE_BYTES + 4*ch_state->start_gap + 4*ch_state->end_gap == debug_sum);
#endif

#ifndef VTSS_FDMA_IGNORE_GNATS_5418
      // GNATS #5418 says: When transmitting a frame from CPU PM using DO_ANALYZE, then the frame
      // may be looped back to the CPU, even if the ANA::SRCMASKS[CPU_PM] doesn't include the CPU
      // PM itself. The reason is that the SRCMASKS are checked before it is determined whether
      // the frame should be copied to the CPU or not (which is typically the case for BPDUs and
      // broadcast frames).
      // The work-around is to drop all frames with IFH.src_port == VTSS_CPU_PM_NUMBER. But we only
      // do this if VTSS_FDMA_IGNORE_GNATS_5418 is not defined. If it's defined, we also forward that
      // type of frames to xtr_cb().
      {
        u32 *ifh_ptr=(u32 *)ch_state->pend_head->data;
        u32 ifh0=vtss_fdma_to_little_endian(ifh_ptr[0]), ifh1=vtss_fdma_to_little_endian(ifh_ptr[1]);
        u32 src_port = ifh_get(ifh0, ifh1, VTSS_FDMA_IFH_F_SRC_PORT_FPOS, VTSS_FDMA_IFH_F_SRC_PORT_FLEN);
        if(src_port == VTSS_CPU_PM_NUMBER)
          drop_it = 1;
      }
#endif

#ifdef VTSS_FDMA_KEEP_STATISTICS
      // Don't count the frame if it's dropped due to an inadvertent CPU PM loopback.
      if(!drop_it) {
        vtss_fdma_stats.rx_packets[ch_state->qu_or_port]++;
        // Don't include IFH in packet byte counter
        vtss_fdma_stats.rx_bytes[ch_state->qu_or_port] += total_frm_size_bytes_excl_ifh;
      } else {
        vtss_fdma_stats.rx_dropped++;
      }
#endif

      if(drop_it) {
        // Don't send to xtr_cb(), but re-cycle the DCBs.
        new_list = ch_state->pend_head;
      } else {
        new_list = ch_state->xtr_cb(cntxt, ch_state->pend_head, ch_state->qu_or_port);
      }

      // NULLify the pending list, since there're no more pending fragments.
      ch_state->pend_head = NULL;

      // It may be that the callback function must defer calls to subscribers, so that
      // it cannot return a replacement list of DCBs. If so, there's nothing more to do.
      if(new_list) {

        // Initialize the new list's DCB areas
#ifdef VTSS_FDMA_KEEP_STATISTICS
        new_tail = xtr_dcb_init(ch, new_list, &dcb_cnt);
        vtss_fdma_stats.rx_bufs_added[ch_state->qu_or_port] += dcb_cnt;
#else
        new_tail = xtr_dcb_init(ch, new_list);
#endif

        // Connect the new list to the end of the current free list whose
        // start and end are given by ch_state->free_head and ch_state->cur_tail.
        // Luckily we cannot get interrupted in this code, so there're no race problems.
        xtr_connect(ch_state, new_list, new_tail);
      }
    } else {
      // The EOF is not reached yet, so there weren't room for the whole frame
      // in the allocated data area of this DCB. Move the DCB to
      // the pending list.
  
      // Update the current fragment's actual length from the
      // xtr_cnt_dwords. We know that there's always a multiple
      // of 4 bytes extracted to a fragment.
      ch_state->cur_head->act_len = 4*xtr_cnt_dwords;

      // Save a reference to the new head.
      new_head = ch_state->cur_head->next;

      // Clear the next entry, so that we can accommodate the case where the
      // FDMA's DCB list exhausts in the middle of a jumbo frame, causing
      // xtr_irq_tfr_done() to restart the channel with a new list of DCBs.
      // If we didn't always clear the pend_head->next we wouldn't know where
      // to attach the remainder of jumbo frames.
      ch_state->cur_head->next = NULL;

      if(!ch_state->pend_head) {
        // This is the first part of the frame.
        VTSS_FDMA_ASSERT(dstat&0x1); // The SOF flag must be set.
        ch_state->pend_head = ch_state->cur_head;
      } else {
        // This is not the first and not the last part of the frame.
        VTSS_FDMA_ASSERT((dstat&0x1)==0); // The SOF flag must be cleared.

        // We need to attach it to the last item in the pend_head list.
        temp_list = ch_state->pend_head;
        while(temp_list->next) {
          temp_list = temp_list->next;
        }
        temp_list->next = ch_state->cur_head;
      }
    }
    
    // Advance the head of the "in progress" list
    ch_state->cur_head = new_head;
  }

  // Return non-zero if the active head is now NULL.
  return ch_state->cur_head==NULL;
}

/*****************************************************************************/
// We need to restart the channel.
/*****************************************************************************/
static void xtr_irq_tfr_done(int ch)
{
  vtss_fdma_ch_state_t *ch_state;

  ch_state = &vtss_fdma_ch_state[ch];
  VTSS_FDMA_ASSERT(ch_state->state != VTSS_FDMA_CH_STATE_DISABLED);
  VTSS_FDMA_ASSERT(ch_state->usage == VTSS_FDMA_CH_USAGE_XTR);
  VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_XTR_VERBOSE, "xtr_irq_tfr_done(ch=%d). New DCBs available: %s\n", ch, ch_state->free_head?"yes":"no");

  // Before restarting the DMA channel, we need to check that cur_head is NULL,
  // because this may not be the case if the channel was already started by
  // vtss_fdma_xtr_add_dcbs(). Furthermore, if there are no free DCBs (free_head==NULL),
  // we cannot restart the channel.
  if(ch_state->cur_head==NULL && ch_state->free_head)
    xtr_restart_ch(ch_state, ch);
}

/*****************************************************************************/
/*****************************************************************************/
static void inj_irq_tfr_done(void *cntxt, int ch)
{
  vtss_fdma_ch_state_t *ch_state;
  vtss_fdma_port_state_t *port_state;
  int orig_port, port, possible_retransmit=0, dropped, do_retransmit;
  vtss_fdma_list_head_t *sof_l, *eof_l;
  u32 miscstat;
  
  VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_INJ_VERBOSE, "inj_irq_tfr_done(ch=%d)\n", ch);
  VTSS_FDMA_ASSERT(ch>=0 && ch<VTSS_FDMA_CH_CNT);
  ch_state=&vtss_fdma_ch_state[ch];
  VTSS_FDMA_ASSERT(ch_state->state != VTSS_FDMA_CH_STATE_DISABLED);
  VTSS_FDMA_ASSERT(ch_state->usage == VTSS_FDMA_CH_USAGE_INJ);
  VTSS_FDMA_ASSERT(ch_state->cur_head);
  sof_l=eof_l=ch_state->cur_head;

  // We need to traverse the DCBs until we find a DCB with the dcb_ptr->llp
  // location being NULL, which is the latest injected frame's EOF. We get called
  // once per frame that has been injected, so it cannot happen that the DMA
  // controller goes beyond that point in the list.
  while(1) {
    VTSS_FDMA_ASSERT(eof_l);

    // Check that the DMA controller indeed has injected the current block.
    // This is conveyed through the dcb_ptr->ctl1.DONE bit.
    // Since the DMA controller writes this bit, we must invalidate the cache
    // for that position before reading it. It is the only part of the DCB
    // that the DMA controller writes back, so it's the only part that we need
    // to invalidate. Also, since we only use it in an assert, we need only
    // invalidate it in VTSS_FDMA_DBG mode.
#ifdef VTSS_FDMA_DBG
    VTSS_FDMA_INVALIDATE_DCACHE_DCB(&((vtss_fdma_dcb_t *)(eof_l->dcb))->ctl1, 4);
    VTSS_FDMA_BARRIER();
    VTSS_FDMA_ASSERT(vtss_fdma_to_little_endian(((vtss_fdma_dcb_t *)(eof_l->dcb))->ctl1)&0x1000);
#endif
   
    if(((vtss_fdma_dcb_t *)(eof_l->dcb))->llp)
      eof_l = eof_l->next;
    else
      break;
  }

  // Check if the relevant port is in flow control mode. If so, we haven't yet
  // transmitted the frame, because we need to read the queue status prior to
  // setting the CPU_TX flag.
  port = orig_port = sof_l->alloc_len_or_port;
  port_state=&vtss_fdma_port_state[port];

  // The port is one less loaded now, i.e. this channel is currently not injecting
  // to this port anymore (others may, however).
  VTSS_FDMA_ASSERT(port_state->active_cnt>0);
  port_state->active_cnt--;
  
  if(port_state->cfg_tx_flow_ctrl) {
    miscstat = vtss_fdma_endian_aware_raw_readl(VTSS_DEV_MISCSTAT(port));
    if(miscstat & (VTSS_F_MISCSTAT_CPU_TX_QUEUE_FULL | VTSS_F_MISCSTAT_CPU_TX_DATA_PENDING | VTSS_F_MISCSTAT_CPU_TX_DATA_OVERFLOW)) {
      // An overflow occurred, or the last data is not transferred to the RAM, or the RAM is full.
      // Rewind the current frame while clearing sticky bits
      vtss_fdma_endian_aware_raw_writel(VTSS_DEV_MISCFIFO(port), VTSS_F_MISCFIFO_CLEAR_STICKY_BITS | VTSS_F_MISCFIFO_REWIND_CPU_TX);
      possible_retransmit=1;
    } else {
      // No overflow occurred. Transmit the current frame.
      vtss_fdma_endian_aware_raw_writel(VTSS_DEV_MISCFIFO(port), VTSS_F_MISCFIFO_CPU_TX);
    }
  }

  dropped       = possible_retransmit && port_state->state_retransmit_cnt==0;
  do_retransmit = possible_retransmit && port_state->state_retransmit_cnt!=0;

  // If an error occurred, (possible_retransmit==1), then check the retransmit_cnt to
  // see if we need to retransmit the frame or should drop it.
  if (do_retransmit) {
    // Do attempt a retransmit
    port_state->state_retransmit_cnt--;
  } else {
    // If we get here, the previous frame was either dropped or sent
    // successfully, but at least shouldn't be retransmitted.
    // 
    // eof_l points to the EOF list item. 
    // Terminate it before passing it on to the callback function,
    // but keep a pointer to the next in the list, which is the one
    // we need to reactive the channel for if non-NULL.
    ch_state->cur_head = eof_l->next;
    eof_l->next = NULL;
  }

  if(ch_state->cur_head) {
    // More frames to go. Re-start the channel.
    // Find the port number to inject the frame to. If the port is
    // different from the port we just injected frames to, we need to
    // re-configure the DMA controller. This is also the reason why we
    // only send one frame at a time before being interrupted.
    port = ch_state->cur_head->alloc_len_or_port;
    VTSS_FDMA_DBG_MSG(VTSS_FDMA_DBG_INJ_SPARSE, "inj_irq_tfr_done(ch=%d). Re-starting channel\n", ch);

    if(!do_retransmit)
      vtss_fdma_port_state[port].state_retransmit_cnt = vtss_fdma_port_state[port].cfg_retransmit_cnt; // Re-initialize the state retransmit count for the new frame.

    // Restart the channel if allowed to.
    if(!vtss_fdma_port_state[port].suspended) {
      vtss_fdma_port_state[port].active_cnt++;
      // The inj_ch_init() function changes ch_state->qu_or_port, which holds the currently
      // configured port.
      inj_ch_init(ch_state, (vtss_fdma_dcb_t *)ch_state->cur_head->dcb, ch, port);
      enable_ch(ch);
    }
  } else {
    // No more frames. Also reset the tail.
    ch_state->cur_tail = NULL;
  }

  if(!do_retransmit) {
#ifdef VTSS_FDMA_KEEP_STATISTICS
    if(dropped)
      vtss_fdma_stats.tx_dropped[orig_port]++;
    else
      vtss_fdma_stats.tx_packets[ch]++;
#endif
    // Callback the Tx handler unless this is a simple retransmit
    VTSS_FDMA_ASSERT(sof_l->inj_cb);
    sof_l->inj_cb(cntxt, sof_l, ch, dropped);
  }
}

/*****************************************************************************/
/*****************************************************************************/
void vtss_fdma_irq_handler(void *cntxt)
{
  u32 block_done_cause = vtss_fdma_endian_aware_raw_readl(VTSS_INTR_STATUS_BLOCK); // The extraction channels use block done interrupts
  u32 tfr_done_cause   = vtss_fdma_endian_aware_raw_readl(VTSS_INTR_STATUS_TFR);   // Both injection and extraction channels use transfer done interrupts.
  int ch;

#ifdef VTSS_FDMA_KEEP_STATISTICS
  vtss_fdma_stats.intr_cnt++;
#endif

  // The two interrupt status register must be read before continuing.
  // If the compiler decided to read the TFR_DONE after the BLOCK_DONE
  // had been processed below, we might end up not consuming all the
  // extraction buffers before attempting to restart the channel.
  VTSS_FDMA_BARRIER();

  // We first handle all the block interrupts, i.e. the per-DCB extraction interrupts.
  // For the extraction interrupts, we need to clear the interrupts before iterating
  // through the DCBs. If we didn't do so, we might end up in a situation where a
  // frame arrives after we've looped through the DCBs, but before we clear the
  // interrupts, and the frame would be stuck in RAM until the next frame arrives.
  // About the same argumentation holds for injection interrupts.
  clear_pending_block_done_intr(block_done_cause);

  VTSS_FDMA_BARRIER();

  // Process the interrupts from above, since that corresponds to the priority.
  for(ch = VTSS_FDMA_CH_CNT-1; ch >= 0; ch--) {
    if(block_done_cause&VTSS_BIT(ch)) {
      if(xtr_irq_block_done(cntxt, ch)) {
        // xtr_irq_block_done() returns non-zero if the last DCB was consumed by the FDMA.
        // This should cause us to restart the channel (done in xtr_irq_tfr_done() below).
        tfr_done_cause |= (1<<ch);
      }
    }
  }

  VTSS_FDMA_BARRIER();
 
  // The transfer done interrupts occur both when one frame has been injected and
  // in the (rare?) case where the OS cannot take off frames in the rate that the
  // FDMA extracts them to RAM, causing the DCB list to exhaust and the channel
  // to stop.
  clear_pending_tfr_done_intr(tfr_done_cause);

  VTSS_FDMA_BARRIER();

  for(ch = VTSS_FDMA_CH_CNT-1; ch >= 0; ch--) {
    if(tfr_done_cause&VTSS_BIT(ch)) {
      if(vtss_fdma_ch_state[ch].usage==VTSS_FDMA_CH_USAGE_INJ)
        inj_irq_tfr_done(cntxt, ch);
      else
        xtr_irq_tfr_done(ch);
    }
  }
}

/*****************************************************************************/
//
// End of file
//
//****************************************************************************/
