#ifndef __PKCS15_PRIV_H__
#define __PKCS15_PRIV_H__

#include <sysdep.h>
#include <logger.h>
#include <panic.h>
#include <module.h>
#include <strutl.h>
#include <dfastm.h>
#include <eloop.h>
#include <service.h>
#include <list.h>
#include <pkcs15.h>

/*Logging operations*/
#define P15_LOG_CRIT		LOG_EMERG
#define P15_LOG_FAIL		LOG_CRIT
#define P15_LOG_ERR		LOG_ERR
#define P15_LOG_WARN		LOG_WARNING
#define P15_LOG_INFO		LOG_INFO
#define P15_LOG_DEBUG		LOG_DEBUG

void pkcs15_log(int level, const char *format, ...);
#define p15_log	 pkcs15_log

struct pkcs15_handle *pkcs15_hand_new(void);
void pkcs15_handle_free(struct pkcs15_handle *p15_handle);
int pkcs15_free_object(struct pkcs15_object *obj);

struct icc_app_info * pkcs15_find_app(struct pkcs15_handle *hd);
int parse_dir_record(struct pkcs15_handle *card_handle, 
		     uint8_t **rbuf, size_t *rbuf_len, int rec_nr);

int parse_ddo(struct pkcs15_handle *p15_handle, const uint8_t * buf, 
	      size_t buflen);
int parse_odf(const uint8_t * buf, size_t buflen, 
	      struct pkcs15_handle *p15_handle);
int pkcs15_parse_tokeninfo(struct pkcs15_tokeninfo *ti,
			   const uint8_t *buf, size_t blen);

int pkcs15_add_df(struct pkcs15_handle *p15_handle,
		  unsigned int type, const struct icc_path *path,
		  const struct icc_file *filp);
void pkcs15_remove_df(struct pkcs15_handle *p15_handle,
		      struct pkcs15_df *obj);

/*=======================TOOL CMDs===========================================*/
int pkcs15_tool_connect(ui_session_t *sess, ui_entry_t *inst,
			void *ctx, int argc, char **argv);
int pkcs15_tool_disconnect(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);

int pkcs15_tool_bind(ui_session_t *sess, ui_entry_t *inst,
		     void *ctx, int argc, char **argv);
int pkcs15_tool_unbind(ui_session_t *sess, ui_entry_t *inst,
		     void *ctx, int argc, char **argv);
void pkcs15_close_trans(void);
int __init pkcs15_bind_init(void);
void __exit pkcs15_bind_exit(void);


#endif /* __PKCS15_PRIV_H__ */

