#include "../pcsc_priv.h"
#include "muscle_fs.h"

#define MSCFS_CACHE_INCREMENT	128
static uint8_t g_applet_id[] = { 0xA0, 0x00, 0x00, 0x00, 0x01, 0x01 };

struct msc_id root_id = {{0x3F, 0x00, 0x3F, 0x00}};

static const uint8_t *ignored_files[] = {
	(const uint8_t *) "l0\0\0",
	(const uint8_t *) "L0\0\0",
	NULL,
};

static int mscfs_is_ignored(struct mscfs *fs, struct msc_id obj_id);

/* here do not use icc->drv since its not binded with */
static void mscfs_select_app_complete(pcsc_transfer_t *transfer)
{
	pcsc_icc_trans_param *icc_param = transfer->icc_trans;
	struct icc_apdu *apdu = icc_param->apdu;

	if (transfer->ret != ICC_SUCCESS) {
		icc_param->ret = transfer->ret;
	} else {
		pcsc_fetch_sw(transfer);
		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00)
			icc_param->ret = 0;
		else
			icc_param->ret = -1;
	}
	transfer->ret = icc_param->ret;
	icc_param->callback(transfer);

	free(apdu);
	icc_trans_param_free(icc_param);
}

int mscfs_select_applet(pcsc_icc_t *icc, pcsc_appcmd_complete cb,
			void *user_data)
{
	pcsc_transfer_t *transfer = NULL;
	pcsc_icc_trans_param *icc_param = NULL;
	struct icc_apdu *apdu = NULL;
	int r;
	size_t applet_id_len = sizeof(g_applet_id);

	/* do not get slot here */
	transfer = pcsc_lower_need_transfer(pcsc_slot_by_icc(icc, 0),
					    cb, user_data);
	if (!transfer)
		goto fail;

	icc_param = icc_trans_param_new();
	if (!icc_param)
		goto fail;

	icc_param->callback = pcsc_lower_noneed_transfer;

	apdu = malloc(sizeof (struct icc_apdu));
	if (!apdu)
		goto fail;
	memset(apdu, 0, sizeof (struct icc_apdu));
	apdu->cse = ICC_APDU_CASE_3_SHORT;
	apdu->cla = 0x00;
	apdu->ins = ICC_APDU_INS_SELECT_FILE;
	apdu->p1 = 0x04;
	apdu->p2 = 0x00;
	apdu->lc = applet_id_len;
	apdu->tx_buf = g_applet_id;
	apdu->tx_buflen = applet_id_len;

	icc_param->apdu = apdu;
	transfer->icc_trans = icc_param;

	r = pcsc_transmit_from_icc(transfer,
				   mscfs_select_app_complete);	

	if (r != ICC_SUCCESS)
		goto fail;
	return ICC_SUCCESS;
fail:
	if (transfer) pcsc_lower_noneed_transfer(transfer);
	if (icc_param) icc_trans_param_free(icc_param);
	if (apdu) free(apdu);
	return -1;
}

struct mscfs *mscfs_new(void)
{
	struct mscfs *fs;

	fs = malloc(sizeof(struct mscfs));
	if (!fs) return NULL;
	memset(fs, 0, sizeof(struct mscfs));
	memcpy(fs->curr_path, "\x3F\x00", 2);

	list_init(&fs->file_cache_list);

	return fs;
}

void mscfs_free(struct mscfs *fs)
{
	mscfs_clear_cache(fs);
	free(fs);
}

void mscfs_clear_cache(struct mscfs *fs)
{
	struct mscfs_file *pos, *n;

	list_for_each_entry_safe(struct mscfs_file, pos, n,
		&fs->file_cache_list, link) {
		list_delete(&pos->link);
		free(pos);
	}
}

struct mscfs_update_param {
	struct mscfs *fs;
	struct mscfs_file *filp;
	pcsc_ll_cb callback;
	void *user_data;
};

static void mscfs_update_cache_complete(void *user_data, int ret)
{
	struct mscfs_update_param *update_cache_param = 
				(struct mscfs_update_param *)user_data;
	struct mscfs *fs = update_cache_param->fs;
	struct mscfs_file *filp = update_cache_param->filp;
	pcsc_icc_t *card_handle = (pcsc_icc_t *)fs->udata;
	int r;
	
	if (ret == ICC_ERR_SEQUENCE_END) {/* No more data avaliable */
		r = ICC_SUCCESS;
		goto out;
	} else if (ret < 0) {
		r = ret;
	} else {
		if (!mscfs_is_ignored(fs, filp->object_id)) {
			uint8_t *oid = filp->object_id.id;
			if (oid[2] == 0 && oid[3] == 0) {
				oid[2] = oid[0];
				oid[3] = oid[1];
				oid[0] = 0x3F;
				oid[1] = 0x00;
				filp->ef = 0;
			} else {
				filp->ef = 1;
			}
			mscfs_cache_push(fs, filp);
		}
		memset(filp, 0, sizeof(struct mscfs_file));
		r = mscfs_list_file(card_handle, filp, 0, 
			  mscfs_update_cache_complete, update_cache_param);
		if (r == ICC_SUCCESS)
			return;
	}

out:
	update_cache_param->callback(update_cache_param->user_data, r);
	free(filp);
	free(update_cache_param);
}

int mscfs_update_cache(struct mscfs *fs, pcsc_ll_cb cb, void *user_data)
{
	int r;
	struct mscfs_update_param *update_cache_param;
	struct mscfs_file *filp;
	pcsc_icc_t *icc = (pcsc_icc_t *)fs->udata;

	filp = malloc(sizeof(struct mscfs_file));
	if (!filp)
		return ICC_ERR_NO_MEM;
	memset(filp, 0, sizeof(struct mscfs_file));

	update_cache_param = malloc(sizeof(struct mscfs_update_param));
	if (!update_cache_param) {
		free(filp);
		return ICC_ERR_NO_MEM;
	}
	memset(update_cache_param, 0, sizeof(struct mscfs_update_param));
	update_cache_param->fs = fs;
	update_cache_param->filp = filp;
	update_cache_param->callback = cb;
	update_cache_param->user_data = user_data;
	
	mscfs_clear_cache(fs);
	r = mscfs_list_file(icc, filp, 1,
			    mscfs_update_cache_complete, update_cache_param);

	if (r != ICC_SUCCESS) {
		free(filp);
		free(update_cache_param);
	}
	
	return r;
}

int mscfs_cache_push (struct mscfs *fs, const struct mscfs_file *filp)
{
	struct mscfs_file *new_entry;

	BUG_ON(!fs);

	new_entry = malloc(sizeof(struct mscfs_file));
	if (!new_entry)
		return ICC_ERR_NO_MEM;
	*new_entry = *filp;
	
	list_insert_before(&new_entry->link, &fs->file_cache_list);

	return ICC_SUCCESS;
}

void mscfs_cache_pop(struct mscfs_file *filp)
{
	if (!filp)
		return;
	list_delete(&filp->link);
	free(filp);
}


static int mscfs_is_ignored(struct mscfs *fs, struct msc_id obj_id)
{
	int ignored = 0;
	const uint8_t **ptr = ignored_files;

	while (ptr && *ptr && !ignored) {
		if (0 == memcmp(obj_id.id, *ptr, 4))
			ignored = 1;
		ptr++;
	}
	return ignored;
}

static void mscfs_list_objects_complete(pcsc_transfer_t *transfer)
{
	pcsc_icc_trans_param *cmd_param = transfer->icc_trans;
	struct icc_apdu *apdu = cmd_param->apdu;
	struct mscfs_file *filp = (struct mscfs_file *)cmd_param->priv;
	uint8_t *file_data = transfer->rbuf;
	int data_len, rbuf_actual;

	if (transfer->ret < PCSC_S_SUCCESS) {
		cmd_param->ret = transfer->ret;
		goto ret;
	}

	cmd_param->ret = pcsc_fetch_sw(transfer);
	/* skip sw1, sw2 */
	rbuf_actual = transfer->rbuf_actual - 2;

	if (apdu->sw1 == 0x9C && apdu->sw2 == 0x12) {
		cmd_param->ret = ICC_ERR_SEQUENCE_END;
		goto ret;
	} else if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
		data_len = rbuf_actual;
		if (data_len == 0) {
			cmd_param->ret = ICC_ERR_SEQUENCE_END;
			goto ret;
		}

		if (data_len != 14) {
			cmd_param->ret = ICC_ERR_UNKNOWN_RECEIVED;
			goto ret;
		}
		memcpy(filp->object_id.id, file_data, 4);
		filp->size = bebytes2ulong(file_data + 4);
		filp->read = bebytes2ushort(file_data + 8);
		filp->write = bebytes2ushort(file_data + 10);
		filp->del = bebytes2ushort(file_data + 12);
	}
ret:
	transfer->ret = cmd_param->ret;
	cmd_param->callback(transfer);

	icc_trans_param_free(cmd_param);
	free(apdu);
}

int mscfs_list_objects(pcsc_icc_t *icc,
		     uint8_t next, struct mscfs_file *filp,
		     pcsc_ll_cb callback, void *user_data)
{
	pcsc_transfer_t *card_param = NULL;
	pcsc_icc_trans_param *cmd_param = NULL;
	struct icc_apdu *apdu = NULL;
	int r;
	
	cmd_param = icc_trans_param_new();
	if (!cmd_param)
		goto fail;

	cmd_param->priv = filp;

	apdu = malloc(sizeof(struct icc_apdu));
	if (!apdu)
		goto fail;
	memset(apdu, 0, sizeof(struct icc_apdu));
	apdu->cse = ICC_APDU_CASE_2_SHORT;
	//apdu->cse = ICC_APDU_CASE_2;
	apdu->cla = icc->cla;
	apdu->ins = MSC_INS_LIST_OBJECTS;
	apdu->p1 = next;
	apdu->p2 = 0x00;
	apdu->le = 14;
	/* no resp but need set this in length */
	apdu->rx_buflen = 14;

	/* do not get slot here */
	card_param = pcsc_lower_need_transfer(pcsc_slot_by_icc(icc, 0),
					      callback, user_data);
	if (!card_param)
		goto fail;

	cmd_param->callback = pcsc_lower_noneed_transfer;
	cmd_param->apdu = apdu;
	card_param->icc_trans = cmd_param;

	r = pcsc_transmit_from_icc(card_param, mscfs_list_objects_complete);

	if (r != ICC_SUCCESS)
		goto fail;
	return ICC_SUCCESS;
fail:
	if (card_param) pcsc_lower_noneed_transfer(card_param);		
	if (cmd_param) icc_trans_param_free(cmd_param);
	if (apdu) free(apdu);
	return -1;
}

int mscfs_list_file(pcsc_icc_t *icc, struct mscfs_file *filp, int reset,
		    pcsc_ll_cb callback, void *user_data)
{
	uint8_t next = reset ? 0x00 : 0x01;

	return mscfs_list_objects(icc, next, filp, callback, user_data);
}

static int mscfs_lookup_path (struct mscfs *fs, const uint8_t *path, int pathlen,
		       struct msc_id *obj_id, int is_dir)
{
	uint8_t *oid = obj_id->id;

	if ((pathlen & 1) != 0)
		return ICC_ERR_INVALID_ARGS;
	if (is_dir) {
		/* Directory must be right next to root */
		if ((0 == memcmp(path, "\x3F\x00", 2) && pathlen == 4)
			|| (0 == memcmp(fs->curr_path, "\x3F\x00", 2) && pathlen == 2)) {
			oid[0] = path[pathlen - 2];
			oid[1] = path[pathlen - 1];
			oid[2] = oid[3] = 0;
		} else {
			return ICC_ERR_INVALID_ARGS;
		}
	}

	oid[0] = fs->curr_path[0];
	oid[1] = fs->curr_path[1];
	if (pathlen > 2 && memcmp(path, "\x3F\x00", 2) == 0) {
		path += 2;
		pathlen -= 2;
		oid[0] = 0x3F;
		oid[1] = 0x00;
	}
	/* Limit to a signal directory */
	if (pathlen > 4)
		return ICC_ERR_INVALID_ARGS;

	/* Reset to root */
	if (0 == memcmp(path, "\x3F\x00", 2) && pathlen == 2) {
		oid[0] = oid[2] = path[0];
		oid[1] = oid[3] = path[1];
	} else if (pathlen == 2) { /* Path preserved for current-path */
		oid[2] = path[0];
		oid[3] = path[1];
	} else if (pathlen == 4) {
		oid[0] = path[0];
		oid[1] = path[1];
		oid[2] = path[2];
		oid[3] = path[3];
	}

	return ICC_SUCCESS;
}

int mscfs_load_fileinfo(struct mscfs *fs, const uint8_t *path, int pathlen,
			struct mscfs_file **file_data)
{
	struct mscfs_file *pos;
	struct msc_id fullpath;

	BUG_ON(!fs || !path || !file_data);

	mscfs_lookup_path(fs, path, pathlen, &fullpath, 0);

	if (list_empty(&fs->file_cache_list))
		return ICC_ERR_CACHE_EMPTY;

	*file_data = NULL;
	list_for_each_entry(struct mscfs_file, pos, 
		&fs->file_cache_list, link) {
		struct msc_id obj_id;

		obj_id = pos->object_id;
		if (0 == memcmp(obj_id.id, fullpath.id, 4)) {
			*file_data = pos;
			break;
		}
	}

	if (*file_data == NULL && 
		((0 == memcmp("\x3F\x00\x00\x00", fullpath.id, 4)) 
		|| (0 == memcmp("\x3F\x00\x3F\x00", fullpath.id, 4)))) {
		static struct mscfs_file ROOT_FILE;

		ROOT_FILE.ef = 0;
		ROOT_FILE.size = 0;
		/* Faked Root ID */
		ROOT_FILE.object_id = root_id;

		ROOT_FILE.read = 0;
		ROOT_FILE.write = 0x02; /* User pin access */
		ROOT_FILE.del = 0x02;

		*file_data = &ROOT_FILE;
	} else if (*file_data == NULL) {
		return ICC_ERR_FILE_NOT_FOUND;
	}

	return ICC_SUCCESS;
}

/* -1 any, 0 DF, 1 EF */
int mscfs_check_selection(struct mscfs *fs, int required_item)
{
	if (fs->curr_path[0] == 0 && fs->curr_path[1] == 0)
		return ICC_ERR_INVALID_ARGS;
	if (required_item == 1 &&
		fs->curr_file[0] == 0 && fs->curr_file[1] == 0)
		return ICC_ERR_INVALID_ARGS;
	return 0;
}
#if 0

/* Construct object id */
int mscfs_lookup_local(struct mscfs *fs, const int id, struct msc_id *obj_id)
{
	uint8_t *oid = obj_id->id;

	oid[0] = fs->curr_path[0];
	oid[1] = fs->curr_path[1];
	oid[2] = (id >> 8) & 0xFF;
	oid[3] = (id & 0xFF);

	return 0;
}

uint16_t muscle_parse_single_acl(const struct scard_acl_entry *acl)
{
	uint16_t acl_entry = 0;

	while (acl) {
		int key = acl->key_ref;
		int method = acl->method;

		switch(method) {
		case ICC_AC_NEVER:
			/* Ignore... other items overwrite these */
			return MSC_ACL_NEVER;
		case ICC_AC_NONE:
		case ICC_AC_UNKNOWN:
			break;
		case ICC_AC_CHV:
			acl_entry |= (1 << key); /* assuming key 0 == SO */
			break;
		case ICC_AC_AUT:
		case ICC_AC_TERM:
		case ICC_AC_PRO:
		default:
			/* Ignored. */
			break;
		}
		acl = acl->next;
	}

	return acl_entry;
}

void muscle_parse_acls(const struct scard_file *filp, 
			      uint16_t *read_perm, uint16_t *write_perm, 
			      uint16_t *delete_perm)
{
	*read_perm = muscle_parse_single_acl(scard_file_get_acl_entry(filp, ICC_AC_OP_READ));
	*write_perm = muscle_parse_single_acl(scard_file_get_acl_entry(filp, ICC_AC_OP_UPDATE));
	*delete_perm = muscle_parse_single_acl(scard_file_get_acl_entry(filp, ICC_AC_OP_DELETE));
}

#endif
