#include "pcsc_priv.h"

DECLARE_LIST(pcsc_handle_list);
DECLARE_NOTIFY_CHAIN(pcsc_handle_chain);

#define for_each_slot(e)		\
	list_for_each_entry(pcsc_slot_t, e, &pcsc_handle_list, link)

#define for_each_slot_safe(e, n)		\
	list_for_each_entry_safe(pcsc_slot_t, e, n, &pcsc_handle_list, link)

static inline int __detect_icc_insert(pcsc_slot_t *hd);
static inline int __detect_icc_remove(pcsc_slot_t *hd);
static inline uint16_t __build_slot_idx(uint16_t r_idx, int s_idx);
static void __detect_icc(void *eloop, void *data);
static void __detect_icc_cb(pcsc_slot_t *hd);
static void __slot_free_stop(pcsc_slot_t *hd);
static void __slot_free_start(pcsc_slot_t *hd);
static void __slot_free_timeout(void *e, void *data);
static void __destroy_transfer(pcsc_transfer_t *trans);
static pcsc_transfer_t *__build_transfer(pcsc_slot_t *hd,
					 pcsc_appcmd_complete cb,
					 void *user_data);

static void pcsc_slot_start(pcsc_slot_t *hd);
static void pcsc_slot_stop(pcsc_slot_t *hd);
static void pcsc_slot_free(pcsc_slot_t *hd);

/* ifd ops */
static int ifd_slot_cancel(pcsc_slot_t *hd);
static int ifd_slot_icc_status(pcsc_slot_t *hd);
static int ifd_slot_power_off(pcsc_slot_t *hd);
static int ifd_slot_power_on(pcsc_slot_t *hd);
static int ifd_slot_xfr_block(pcsc_slot_t *hd, pcsc_transfer_t *t);
#ifdef NO_REF
static int ifd_slot_ifd_ctl(pcsc_slot_t *hd, pcsc_transfer_t *t);
#endif

/* icc ops */
static int icc_slot_create_file(pcsc_slot_t *, struct icc_file *filp,
				pcsc_trans_cb cb,  pcsc_transfer_t *);
static int icc_slot_read_record(pcsc_slot_t *, int rec_nr, uint8_t *rbuf,
				size_t rbuf_len, uint32_t flags,
				pcsc_trans_cb cb, pcsc_transfer_t *);
static int icc_slot_read_binary(pcsc_slot_t *, uint32_t offset, uint8_t *rbuf,
				size_t rbuf_len, uint32_t flags,
				pcsc_trans_cb cb, pcsc_transfer_t *);
static int icc_slot_select_file(pcsc_slot_t *, struct icc_path *,
				struct icc_file **, pcsc_trans_cb cb,
				pcsc_transfer_t *);

static void pcsc_raise_event(pcsc_slot_t *rd_ctx, int event);
static void pcsc_raise_ris(pcsc_slot_t *hd);
static void pcsc_raise_ors(pcsc_slot_t *rd_ctx);
static void pcsc_raise_css(pcsc_slot_t *rd_ctx);
static void pcsc_raise_csf(pcsc_slot_t *rd_ctx);
static void pcsc_raise_to(pcsc_slot_t *rd_ctx);
static void pcsc_raise_iccp(pcsc_slot_t *rd_ctx);
static void pcsc_raise_iccnp(pcsc_slot_t *rd_ctx);
static void pcsc_raise_cas(pcsc_slot_t *rd_ctx);
static void pcsc_raise_caf(pcsc_slot_t *rd_ctx);
#ifdef NO_REF
static void pcsc_raise_icca(pcsc_slot_t *rd_ctx);
static void pcsc_raise_iccd(pcsc_slot_t *rd_ctx);
#endif
static void pcsc_raise_iccr(pcsc_slot_t *rd_ctx);
static void pcsc_raise_cis(pcsc_slot_t *rd_ctx);
static void pcsc_raise_rrm(pcsc_slot_t *rd_ctx);
static void pcsc_raise_cds(pcsc_slot_t *rd_ctx);
static void pcsc_raise_cdf(pcsc_slot_t *rd_ctx);

static void pcsc_stm_exit(void *eloop, void *user_ctx);

static void pcsc_stm_log(const stm_instance_t *fsmi,
			int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

#define PCSC_STATE_INIT		0
#define PCSC_STATE_OPEN		1	/* Reader Opening */
#define PCSC_STATE_CSTATUSING	2	/* ICC statusing */
#define PCSC_STATE_CSTATUSED	3	/* ICC statused */
#define PCSC_STATE_PRESENT	4	/* ICC present */
#define PCSC_STATE_ABSENT	5	/* ICC absent */
#define PCSC_STATE_POWERUP	6	/* ICC powerup(actived) */
#define PCSC_STATE_DEACTIVE	7	/* ICC deactive */
#define PCSC_STATE_POWERDOWN	8	/* ICC powerdown(deactived) */
#define PCSC_STATE_EXIT		9	

#define PCSC_STATE_COUNT	10

#define PCSC_STATE_NAMES {	\
	"INIT",			\
	"OPEN",			\
	"CSTATUSING",		\
	"CSTATUSED",		\
	"PRESENT",		\
	"ABSENT",		\
	"POWERUP",		\
	"DEACTIVE",		\
	"POWERDOWN",		\
	"EXIT",			\
}

#define PCSC_EVENT_RIS		0	/* Reader InSerted*/
#define PCSC_EVENT_ORS		1	/* Open Reader Success */
#define PCSC_EVENT_ORF		2	/* Open Reader Failed */
#define PCSC_EVENT_CSS		3	/* icC Status Success */
#define PCSC_EVENT_CSF		4	/* icC Status Failed */
#define PCSC_EVENT_TO		5	/* Time Out*/
#define PCSC_EVENT_ICCP		6	/* ICC Present */
#define PCSC_EVENT_ICCNP	7	/* ICC Not Present */
#define PCSC_EVENT_CAS		8	/* Card Active Success */
#define PCSC_EVENT_CAF		9	/* Card Active Failed */
#define PCSC_EVENT_ICCA		10	/* ICC active */
#define PCSC_EVENT_ICCD		11	/* Card deactive */
#define PCSC_EVENT_ICCR		12	/* ICC removed */
#define PCSC_EVENT_CIS		13	/* Card InSerted */	
#define PCSC_EVENT_RRM		14	/* Reader ReMoved */
#define PCSC_EVENT_CDS		15	/* Card Deactive Success */
#define PCSC_EVENT_CDF		16	/* Card Deactive Failed */

#define PCSC_EVENT_COUNT	17

#define PCSC_EVENT_NAMES {	\
	"RIS",			\
	"ORS",			\
	"ORF",			\
	"CSS",			\
	"CSF",			\
	"TO",			\
	"ICCP",			\
	"ICCNP",		\
	"CAS",			\
	"CAF",			\
	"ICCA",			\
	"ICCD",			\
	"ICCR",			\
	"CIS",			\
	"RRM",			\
	"CDS",			\
	"CDF",			\
}

static void pcsc_raise_event(pcsc_slot_t *slot, int event)
{
	eloop_schedule_event(NULL, slot->fsmi, event, slot);
}

static void pcsc_raise_ris(pcsc_slot_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_RIS);
}

static void pcsc_raise_ors(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_ORS);
}

static void pcsc_raise_css(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_CSS);
}

static void pcsc_raise_csf(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_CSF);
}

static void pcsc_raise_to(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_TO);
}

static void pcsc_raise_iccp(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_ICCP);
}

static void pcsc_raise_iccnp(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_ICCNP);
}

static void pcsc_raise_cas(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_CAS);
}

static void pcsc_raise_caf(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_CAF);
}

#ifdef NO_REF
static void pcsc_raise_icca(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_ICCA);
}

static void pcsc_raise_iccd(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_ICCD);
}
#endif

static void pcsc_raise_iccr(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_ICCR);
}

static void pcsc_raise_cis(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_CIS);
}

static void pcsc_raise_rrm(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_RRM);
}

static void pcsc_raise_cds(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_CDS);
}

static void pcsc_raise_cdf(pcsc_slot_t *slot)
{
	pcsc_raise_event(slot, PCSC_EVENT_CDF);
}

static int pcsc_action_open(stm_instance_t *fsmi, void *data)
{
	pcsc_raise_ors(data);
	return 1;
}

static int pcsc_action_close(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *slot = (pcsc_slot_t *)data;

	pcsc_icc_down(slot->icc);
	pcsc_notify(PCSC_ICC_REMOVE, slot);

	return 1;
}

static int pcsc_action_erc(stm_instance_t *fsmi, void *data)
{
	eloop_register_timeout(NULL, 0, 0, 
		pcsc_stm_exit, NULL, data);
	return 1;
}

/* This "warm up" sequence is sometimes needed when pcscd is
 * restarted with the reader already connected. We get some
 * "usb_bulk_read: Resource temporarily unavailable" on the 
 * first few tries. It is an empirical hack
 */
#define ICC_STATUS_RETRY_MAX	3
static int icc_status_retry = ICC_STATUS_RETRY_MAX;

static void icc_status_complete(pcsc_slot_t *slot)
{
	uint32_t icc_status;

	if (slot->ret != PCSC_S_SUCCESS) {
		if ((--icc_status_retry) > 0) {
			pcsc_raise_to(slot);
		} else {
			pcsc_raise_csf(slot);
			icc_status_retry = ICC_STATUS_RETRY_MAX;
		}
	} else {

		icc_status = slot->icc->status;
		if (icc_status & PCSC_ICC_PRESENT_MASK) {
			/* ICC insert */
			pcsc_raise_iccp(slot);

		} else {
			pcsc_raise_iccnp(slot);
		}
		icc_status_retry = ICC_STATUS_RETRY_MAX;
		slot->old_icc_status = slot->icc->status;
	}
}

static int pcsc_action_icc_status(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *slot = (pcsc_slot_t *)data;
	int r;
	
	slot->cb = icc_status_complete;
	r = ifd_slot_icc_status(slot);

	if (r == PCSC_S_SUCCESS)
		pcsc_raise_css(slot);
	else
		pcsc_raise_csf(slot);
	return 1;
}

static void power_on_complete(pcsc_slot_t *slot)
{
	struct pcsc_atr_info atr_info;
	uint8_t atr[PCSC_MAX_ATR * 3];
	size_t i;

	if (slot->ret < 0) {
		if (slot->ret == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(slot);
		else
			pcsc_raise_caf(slot);
	} else {
		slot->icc->atr_len = slot->ret;
		if (pcsc_parse_atr(slot->icc->atr, slot->icc->atr_len, &atr_info) 
			== PCSC_S_SUCCESS) {
			slot->icc->proto = atr_info.default_proto;
			slot->icc->proto_supported = atr_info.supported_protos;

			for (i = 0; i < slot->icc->atr_len; i++) {
				if (i == slot->icc->atr_len - 1)
					sprintf(atr + i * 3, "%02X", slot->icc->atr[i]);
				else 
					sprintf(atr + i * 3, "%02X:", slot->icc->atr[i]);
			}
			pcsc_log(PCSC_LOG_DEBUG, "ATR: %s", atr);
			if (slot->icc->proto_supported & PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_DEBUG, "Support protocol: T0");
			if (slot->icc->proto_supported & PCSC_PROTOCOL_T1)
				pcsc_log(PCSC_LOG_DEBUG, "Support protocol: T1");

			if (slot->icc->proto == PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_DEBUG, "Default protocol: T0");
		} else {
			slot->icc->proto = PCSC_PROTOCOL_UNKNOWN;
			slot->icc->proto_supported = PCSC_PROTOCOL_UNKNOWN;
		}

		pcsc_raise_cas(slot);
		if (pcsc_icc_up(slot->icc))
			BUG();
		pcsc_notify(PCSC_ICC_INSERT, slot);
	}
}

/* active ICC */
static int pcsc_action_aicc(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *slot = (pcsc_slot_t *)data;
	int r;

	slot->cb = power_on_complete;

	r = ifd_slot_power_on(slot);

	if (r != PCSC_S_SUCCESS) {
		if (r == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(slot);
		else
			pcsc_raise_caf(slot);
	}
	return 1;
}

static void power_off_complete(pcsc_slot_t *slot)
{
	if (slot->ret != PCSC_S_SUCCESS) {
		if (slot->ret == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(slot);
		else
			pcsc_raise_cdf(slot);
	} else {
		pcsc_raise_cds(slot);
	}
}

/* deactive ICC */
static int pcsc_action_dicc(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *rd_ctx = (pcsc_slot_t *)data;
	int r;

	rd_ctx->cb = power_off_complete;

	r = ifd_slot_power_off(rd_ctx);

	if (r != PCSC_S_SUCCESS) {
		if (r == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_cdf(rd_ctx);
	}	
	return 1;
}

/* Card Not Present */
static int pcsc_action_cnp(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *hd = (pcsc_slot_t *)data;

	pcsc_icc_down(hd->icc);
	pcsc_notify(PCSC_ICC_REMOVE, hd);

	return 1;
}

/* Clear handle */
static int pcsc_action_chd(stm_instance_t *fsmi, void *data)
{
	pcsc_slot_t *ifd = (pcsc_slot_t *)data;
	
	ifd_slot_cancel(ifd);
	return 1;
}

static int pcsc_action_null(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static const stm_action_fn pcsc_act_open [] = {
	pcsc_action_open,
};

static const stm_action_fn pcsc_act_erc [] = {
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_close_erc [] = {
	pcsc_action_close,
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_icc_status [] = {
	pcsc_action_icc_status,
};

static const stm_action_fn pcsc_act_aicc [] = {
	pcsc_action_aicc,
};

static const stm_action_fn pcsc_act_cnp [] = {
	pcsc_action_cnp,
};

static const stm_action_fn pcsc_act_chd_cnp [] = {
	pcsc_action_chd,
	pcsc_action_cnp,
};

static const stm_action_fn pcsc_act_chd_dicc [] = {
	pcsc_action_chd,
	pcsc_action_dicc,
};


static const stm_action_fn pcsc_act_null [] = {
	pcsc_action_null,
};

#define STATE(state)	PCSC_STATE_##state
#define EVENT(event)	PCSC_EVENT_##event
#define ACTION(stem)	pcsc_act_##stem, \
			sizeof(pcsc_act_##stem) / sizeof(stm_action_fn) 

static const stm_entry_t pcsc_stm_entries[] = {
	/* state	event		action			new_state */
	{STATE(INIT),	EVENT(RIS),	ACTION(open),		STATE(OPEN),},

	{STATE(OPEN),	EVENT(ORS),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(OPEN),	EVENT(ORF),	ACTION(erc),		STATE(EXIT),},

	{STATE(CSTATUSING),EVENT(CSS),	ACTION(null),		STATE(CSTATUSED),},
	{STATE(CSTATUSING),EVENT(CSF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(CSTATUSING),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(CSTATUSED),EVENT(CSF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(CSTATUSED),EVENT(TO),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(CSTATUSED),EVENT(ICCP),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(CSTATUSED),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(CSTATUSED),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},
	
	{STATE(PRESENT),EVENT(CAS),	ACTION(null),		STATE(POWERUP),},
	{STATE(PRESENT),EVENT(CAF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(PRESENT),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(PRESENT),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(PRESENT),EVENT(RRM),	ACTION(erc),		STATE(EXIT),},

	{STATE(ABSENT),	EVENT(CIS),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(ABSENT),	EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(POWERUP),EVENT(ICCA),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(POWERUP),EVENT(ICCD),	ACTION(chd_dicc),	STATE(DEACTIVE),},
	{STATE(POWERUP),EVENT(ICCR),	ACTION(chd_cnp),	STATE(ABSENT),},
	{STATE(POWERUP),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(DEACTIVE),EVENT(CDS),	ACTION(null),		STATE(POWERDOWN),},
	{STATE(DEACTIVE),EVENT(CDF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(DEACTIVE),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(DEACTIVE),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(DEACTIVE),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(POWERDOWN),EVENT(ICCA),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(POWERDOWN),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(POWERDOWN),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{0,		0,		NULL,			0,},
};

static const char *pcsc_state_names[] = PCSC_STATE_NAMES;
static const char *pcsc_event_names[] = PCSC_EVENT_NAMES;

const stm_table_t pcsc_stm_table = {
	"PCSC",
	pcsc_stm_log,
	PCSC_STATE_COUNT,
	&pcsc_state_names[0],
	PCSC_EVENT_COUNT,
	&pcsc_event_names[0],
	pcsc_stm_entries,	
};

#undef STATE
#undef EVENT
#undef ACTION

static void pcsc_stm_exit(void *eloop, void *user_ctx) 
{
	pcsc_slot_t *rd_ctx = (pcsc_slot_t *)user_ctx;

	if (rd_ctx->fsmi) {
		eloop_delete_automaton(rd_ctx->fsmi);
		rd_ctx->fsmi = NULL;
	}

}

static inline uint16_t __build_slot_idx(uint16_t rdr_idx, int slot_idx)
{
	return (uint16_t)(rdr_idx << 8 | slot_idx);
}

pcsc_slot_t *pcsc_get_slot_by_icc_name(const char *name)
{
	pcsc_slot_t *hd;
	for_each_slot(hd) {
		if (strcasecmp(hd->icc->drv->name, name) == 0)
			return pcsc_slot_get(hd);
	}
	return NULL;
}

pcsc_slot_t *pcsc_slot_by_icc(pcsc_icc_t *icc, int get)
{
	pcsc_slot_t *hd;
	for_each_slot(hd) {
		if (hd->icc == icc) {
			if (get)
				return pcsc_slot_get(hd);
			else
				return (hd);
		}
	}
	return NULL;
}

uint16_t pcsc_idx_by_iccidx(uint16_t iccidx)
{
	pcsc_slot_t *slot;

	for_each_slot(slot) {
		if (slot->icc->idx == iccidx)
			return slot->idx;
	}
	return 0xFFFF;
}

static void __slot_free_timeout(void *e, void *data)
{
	pcsc_slot_t *hd = (pcsc_slot_t *)data;

	if (hd->fsmi == NULL &&
	    atomic_read(&hd->refcnt) == 1) {
		__slot_free_stop(hd);
		pcsc_slot_free(hd);
	} else
		__slot_free_start(hd);
}

static void __slot_free_start(pcsc_slot_t *hd)
{
	eloop_register_timeout(NULL, 1, 0, __slot_free_timeout, NULL, hd);
}

static void __slot_free_stop(pcsc_slot_t *hd)
{
	eloop_cancel_timeout(NULL, __slot_free_timeout, NULL, hd);
}

pcsc_slot_t *pcsc_slot_new(pcsc_ifd_t *rdr, int slot_idx)
{
	pcsc_slot_t *hd;

	hd = malloc(sizeof (pcsc_slot_t));
	if (!hd)
		goto err;

	memset(hd, 0, sizeof (pcsc_slot_t));

	hd->fsmi = eloop_create_automaton(&pcsc_stm_table, rdr->name, 
					  PCSC_STATE_INIT);
	if (!hd->fsmi)
		goto err;

	hd->idx = __build_slot_idx(rdr->idx, slot_idx);
	hd->old_icc_status = PCSC_ICC_STATUS_UNKNOWN;

	list_init(&hd->link);
	list_insert_before(&hd->link, &pcsc_handle_list);
	atomic_set(&hd->refcnt, 1);

	/* slot_start will get reader */
	hd->ifd = (rdr);
	hd->icc = pcsc_icc_new(hd->idx);
	
	return hd;
err:
	if (hd)
		free(hd);
	return NULL;
}

static void pcsc_slot_free(pcsc_slot_t *hd)
{
	if (hd->icc)
		pcsc_icc_free(hd->icc);
	list_delete(&hd->link);
	free(hd);
}

void pcsc_slot_free_all(pcsc_ifd_t *ifd)
{
	pcsc_slot_t *hd, *n;
	
	for_each_slot_safe(hd, n) {
		if (hd->ifd != ifd)
			continue;
		__slot_free_start(hd);
	}
}

void pcsc_start_by_ifd(pcsc_ifd_t *ifd)
{
	pcsc_slot_t *hd;
	for_each_slot(hd) {
		if (ifd == hd->ifd)
			pcsc_slot_start(hd);
	}
}

void pcsc_stop_by_ifd(pcsc_ifd_t *ifd)
{
	pcsc_slot_t *hd;
	for_each_slot(hd) {
		if (ifd == hd->ifd)
			pcsc_slot_stop(hd);
	}
}

void pcsc_get_feature(pcsc_ifd_t *ifd)
{
	pcsc_slot_t *slot;

	for_each_slot(slot) {
		if (ifd == slot->ifd && ifd->drv->get_feature) {
			ifd->drv->get_feature(slot);
			/* only get once? */
			break;
		}
	}
}

static void pcsc_slot_start(pcsc_slot_t *hd)
{
	eloop_register_timeout(NULL, 4, 0, __detect_icc, NULL, hd);
	pcsc_ifd_get(hd->ifd);

	/* sm start - reader insert event */
	pcsc_raise_ris(hd);
}

static void pcsc_slot_stop(pcsc_slot_t *hd)
{
	eloop_cancel_timeout(NULL, __detect_icc, NULL, hd);
	pcsc_ifd_put(hd->ifd);

	/* sm start - reader remove event */
	pcsc_raise_rrm(hd);
}

static void __detect_icc_cb(pcsc_slot_t *hd)
{
	if (pcsc_icc_status(hd->icc) != hd->old_icc_status) {
		pcsc_log(PCSC_LOG_INFO, "IFD: icc state changed, %s -> %s",
			 pcsc_card_status_str(hd->old_icc_status), 
			 pcsc_card_status_str(hd->icc->status));

		/* icc has 3 status(needed?)
		 * avoid raise insert event twice */
		if (hd->icc->status != PCSC_ICC_ABSENT &&
		    hd->old_icc_status != PCSC_ICC_PRESENT_POWERDOWN)
			__detect_icc_insert(hd);
		else if (hd->icc->status == PCSC_ICC_ABSENT)
			__detect_icc_remove(hd);
		/* record new status */
		hd->old_icc_status = hd->icc->status;
	}
}

static void __detect_icc(void *eloop, void *data)
{
	pcsc_slot_t *hd = (pcsc_slot_t *)data;

	hd->cb = __detect_icc_cb;
	pcsc_log(PCSC_LOG_DEBUG, "IFD: icc state detect");
	ifd_slot_icc_status(hd);

	eloop_register_timeout(NULL, 4, 0, __detect_icc, NULL, hd);
}

static inline int __detect_icc_insert(pcsc_slot_t *hd)
{
	pcsc_raise_cis(hd);
	return PCSC_S_SUCCESS;
}

static inline int __detect_icc_remove(pcsc_slot_t *hd)
{
	pcsc_raise_iccr(hd);
	return PCSC_S_SUCCESS;
}

/* icc / ifd ops */
static int ifd_slot_cancel(pcsc_slot_t *hd)
{
	return pcsc_ifd_ops(hd)->cancel(hd);
}

static int ifd_slot_icc_status(pcsc_slot_t *hd)
{
	return pcsc_ifd_ops(hd)->icc_status(hd);	
}

static int ifd_slot_power_off(pcsc_slot_t *hd)
{
	return pcsc_ifd_ops(hd)->power_off(hd);	
}

static int ifd_slot_power_on(pcsc_slot_t *hd)
{
	return pcsc_ifd_ops(hd)->power_on(hd);	
}

static int ifd_slot_xfr_block(pcsc_slot_t *hd, pcsc_transfer_t *p)
{
	return pcsc_ifd_ops(hd)->xfr_block(hd, p);	
}

#ifdef NO_REF
static int ifd_slot_ifd_ctl(pcsc_slot_t *hd, pcsc_transfer_t *p)
{
	return pcsc_ifd_ops(hd)->ifd_ctl(hd, p);	
}
#endif

static int icc_slot_create_file(pcsc_slot_t *hd, struct icc_file *filp,
				pcsc_trans_cb cb,  pcsc_transfer_t *trans)
{
	icc_driver_ops_t *ops = pcsc_icc_ops(hd);

	if (ops && ops->create_file)
		return ops->create_file(hd, filp, cb, trans);
	return -1;
}

static int icc_slot_read_record(pcsc_slot_t *hd, int rec_nr,
			      uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
			      pcsc_trans_cb cb, pcsc_transfer_t *card_param)
{
	icc_driver_ops_t *ops = pcsc_icc_ops(hd);

	if (ops && ops->read_record)
		return ops->read_record(hd, rec_nr, rbuf, rbuf_len, flags, cb, card_param);
	return -1;
}

static int icc_slot_read_binary(pcsc_slot_t *hd, uint32_t offset,
			      uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
			      pcsc_trans_cb cb, pcsc_transfer_t *card_param)
{
	icc_driver_ops_t *ops = pcsc_icc_ops(hd);

	if (ops && ops->read_binary)
		return ops->read_binary(hd, offset, rbuf, rbuf_len, flags, cb, card_param);
	return -1;
}

static int icc_slot_select_file(pcsc_slot_t *hd, struct icc_path *in_path,
			      struct icc_file **file_out, 
			      pcsc_trans_cb cb, pcsc_transfer_t *trans)
{
	icc_driver_ops_t *ops = pcsc_icc_ops(hd);
	if (ops && ops->select_file)
		return ops->select_file(hd, in_path, file_out, cb, trans);
	return -1;
}

pcsc_slot_t *pcsc_slot_get(pcsc_slot_t *hd)
{
	if (hd)
		atomic_inc(&hd->refcnt);
	return hd;
}

void pcsc_slot_put(pcsc_slot_t *hd)
{
	if (hd)	atomic_dec(&hd->refcnt);
}

void pcsc_slot_lock_put(pcsc_slot_t *hd)
{
	hd->locked = 0;
	pcsc_slot_put(hd);
}

uint16_t pcsc_get_slot_idx(pcsc_slot_t *slot)
{
	return slot->idx;
}

pcsc_slot_t *pcsc_slot_lock_get_by_idx(uint16_t idx)
{
	pcsc_slot_t *hd = pcsc_handle_get_by_idx(idx);
	if (hd) {
		if (hd->locked)
			goto locked;
		hd->locked = 1;
		return hd;
	}
locked:
	if (hd) pcsc_slot_put(hd);
	return NULL;
}

pcsc_slot_t *pcsc_handle_get_by_idx(uint16_t idx)
{
	pcsc_slot_t *hd;
	for_each_slot(hd) {
		if (hd->idx == idx)
			return pcsc_slot_get(hd);
	}
	return NULL;
}

/* use for refresh tpdu */
int pcsc_update_tpdu(pcsc_transfer_t *trans)
{
	size_t sbuf_len = icc_apdu_get_length(trans->icc_trans->apdu, trans->handle->icc->proto);

	if (sbuf_len != trans->ifd_trans->sbuf_len) {
		free(trans->ifd_trans->sbuf);

		trans->ifd_trans->sbuf = malloc(sbuf_len);
		if (NULL == trans->ifd_trans->sbuf)
			return -1;
		trans->ifd_trans->sbuf_len = sbuf_len;
	}

	return icc_apdu2tpdu(trans->icc_trans->apdu, 
			     trans->handle->icc->proto, 
			     trans->ifd_trans->sbuf,
			     trans->ifd_trans->sbuf_len);
}

int pcsc_transmit_from_icc(pcsc_transfer_t *trans, pcsc_trans_cb cb)
{
	pcsc_icc_trans_param *icc_param = trans->icc_trans;
	pcsc_ifd_trans_param *ifd_param;

	uint8_t *rbuf = NULL, *sbuf = NULL;
	size_t rbuf_len, sbuf_len;
	int r;

	icc_detect_apdu_cse(trans->handle, icc_param->apdu);
	r = icc_check_apdu(trans->handle, icc_param->apdu);

	if (r != ICC_SUCCESS)
		return r;
	
	trans->ifd_trans = malloc(sizeof(pcsc_ifd_trans_param));
	if (!trans->ifd_trans) {
		return ICC_ERR_NO_MEM;
	}
	memset(trans->ifd_trans, 0, sizeof(pcsc_ifd_trans_param));

	ifd_param = trans->ifd_trans;

	rbuf_len = icc_param->apdu->rx_buflen < 256 ? 
			258 : icc_param->apdu->rx_buflen + 2;
	
	rbuf = malloc(rbuf_len);
	if (!rbuf) {
		free(ifd_param);
		return ICC_ERR_NO_MEM;
	}

	sbuf_len = icc_apdu_get_length(icc_param->apdu, trans->handle->icc->proto);
	if (sbuf_len == 0) {
		free(rbuf);
		free(ifd_param);
		return ICC_ERR_NO_MEM;
	}
	sbuf= malloc(sbuf_len);
	if (!sbuf) {
		free(rbuf);
		free(ifd_param);
		return ICC_ERR_NO_MEM;
	}
	r = icc_apdu2tpdu(icc_param->apdu, trans->handle->icc->proto, sbuf, sbuf_len);

	if (r != ICC_SUCCESS)
		goto err;

	ifd_param->sbuf = sbuf;		/* TPDU */
	ifd_param->sbuf_len = sbuf_len;	/* TPDU length */
	ifd_param->callback = cb;
	/* XXX: not well at here */
	trans->rbuf = rbuf;		/* receive IFD response */
	trans->rbuf_len = rbuf_len;	/* max receive length */

	return pcsc_transmit(trans);

err:
	if (rbuf) free(rbuf);
	if (sbuf) free(sbuf);
	if (ifd_param) free(ifd_param);	

	return -1;
}

/* XXX: must build TPDU first,
 * some response will cause retry and ICC will call this routine directly
 * in this case it need be careful.
 */
int pcsc_transmit(pcsc_transfer_t *trans)
{
	return ifd_slot_xfr_block(trans->handle, trans);
}

/* fetch and check sw1,sw2 */
int pcsc_fetch_sw(pcsc_transfer_t *trans)
{
	uint8_t *rbuf;
	size_t rbuf_actual;
	int r = 0;
	pcsc_icc_trans_param *icc_trans = trans->icc_trans;
	pcsc_ifd_trans_param *ifd_trans = trans->ifd_trans;

	BUG_ON(!icc_trans || !ifd_trans);

	rbuf = trans->rbuf;
	rbuf_actual = trans->rbuf_actual;

	if (rbuf_actual < 2) {
		r = ICC_ERR_COMMUNICATION;
		goto ret;
	}

	icc_trans->apdu->sw1 = rbuf[rbuf_actual - 2];
	icc_trans->apdu->sw2 = rbuf[rbuf_actual - 1];

	r = icc_check_sw(trans->handle->icc,
			 icc_trans->apdu->sw1,
			 icc_trans->apdu->sw2);
ret:
	return r;
}

/* read_binary can share this */
static void __pcsc_cmd_common_cb(pcsc_transfer_t *trans)
{
	/* reach here, we don't need care icc param reclaim, thats by itself */
	if (trans) {
		pcsc_ifd_trans_param *ifd_param = trans->ifd_trans;
		if (trans->ret < ICC_SUCCESS)
			pcsc_log(PCSC_LOG_ERR, "SLOT: transfer fail");
		else
			pcsc_log(PCSC_LOG_DEBUG, "SLOT: transfer succ");
		
		if (trans->callback)
			trans->callback(trans->user_data, trans->ret);

		if (ifd_param) {
			if (ifd_param->sbuf) free(ifd_param->sbuf);
			free(ifd_param);	
		}
		__destroy_transfer(trans);
	}
}

/* APPLICATION API */

/* Note: doesnt know rbuf length and alloc it in future
 * but remember free it */
static pcsc_transfer_t *__build_transfer(pcsc_slot_t *hd, 
					 pcsc_appcmd_complete cb,
					 void *user_data)
{
	pcsc_transfer_t *trans = malloc(sizeof (pcsc_transfer_t));
	if (!trans)
		return NULL;

	memset(trans, 0, sizeof (pcsc_transfer_t));
	trans->callback = cb;
	trans->user_data = user_data;
	trans->ret = -1;
	trans->handle = hd;

	return trans;
}

static void __destroy_transfer(pcsc_transfer_t *trans)
{
	if (trans) {
		if (trans->rbuf) free(trans->rbuf);
		free(trans);
	}
}

/* PCSC API for user */
int pcsc_select_file(pcsc_slot_t *hd, struct icc_path *path,
		     struct icc_file **file_out,
		     pcsc_appcmd_complete cb, void *user_data)
{
	int ret;
	pcsc_transfer_t *trans = NULL;

	if (!hd)
		return -1;

	ret = icc_check_path(path);
	if (ret != 0)
		goto err;

	trans = __build_transfer(hd, cb, user_data);

	ret = icc_slot_select_file(hd, path, file_out, 
				 __pcsc_cmd_common_cb, trans);

	if (ret != 0)
		cb(user_data, ret);
	else
		goto out;
err:
	if (trans) __destroy_transfer(trans);
out:
	return ret;
}


int pcsc_create_file(pcsc_slot_t *hd, struct icc_file *filp,
		     pcsc_appcmd_complete cb, void *user_data)
{
	int ret;
	pcsc_transfer_t *trans;

	if (!hd)
		return -1;

	trans = __build_transfer(hd, cb, user_data);
	if (!trans)
		return -1;
	
	ret = icc_slot_create_file(hd, filp,
			__pcsc_cmd_common_cb, trans);
	if (ret != 0) {
		cb(user_data, ret);
		goto err;
	}
	return ret;
err:
	if (trans) __destroy_transfer(trans);
	return ret;

}

int pcsc_read_record(pcsc_slot_t *hd, int rec_nr,
		     uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
		     pcsc_appcmd_complete cb, void *user_data)
{
	int ret;
	pcsc_transfer_t *trans;

	if (!hd)
		return -1;

	trans = __build_transfer(hd, cb, user_data);
	if (!trans)
		return -1;

	ret = icc_slot_read_record(hd, rec_nr, rbuf, rbuf_len, flags,
				   __pcsc_cmd_common_cb, trans);

	if (ret != 0) {
		cb(user_data, ret);
		goto err;
	}
	return ret;
err:
	if (trans) __destroy_transfer(trans);
	return ret;
}

int pcsc_read_binary(pcsc_slot_t *hd, uint16_t offset,
		     uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
		     pcsc_appcmd_complete cb, void *user_data)
{
	int ret;
	pcsc_transfer_t *trans;

	if (!hd)
		return -1;

	trans = __build_transfer(hd, cb, user_data);
	if (!trans)
		return -1;

	ret = icc_slot_read_binary(hd, offset, rbuf, rbuf_len, flags,
				   __pcsc_cmd_common_cb, trans);

	if (ret != 0) {
		cb(user_data, ret);
		goto err;
	}
	return ret;
err:
	if (trans) __destroy_transfer(trans);
	return ret;
}

void pcsc_lower_noneed_transfer(pcsc_transfer_t *trans)
{
	if (trans->callback)
		trans->callback(trans->user_data, trans->ret);
	
	if (trans->ifd_trans) {
		if (trans->ifd_trans->sbuf)
			free(trans->ifd_trans->sbuf);
		free(trans->ifd_trans);	
	}
	__destroy_transfer(trans);
}

pcsc_transfer_t *
pcsc_lower_need_transfer(pcsc_slot_t *hd,
			 pcsc_appcmd_complete cb,
			 void *user_data)
{
	pcsc_transfer_t *trans;

	if (!hd)
		return NULL;

	trans = __build_transfer(hd, cb, user_data);
	if (!trans)
		return NULL;
	return trans;
}

int pcsc_register_notify(notify_t *nb)
{
	pcsc_slot_t *hd;
	pcsc_slot_t *last;
	int err;

	err = register_notify_chain(&pcsc_handle_chain, nb);
	if (err)
		goto unlock;

	for_each_slot(hd) {
		err = nb->call(nb, PCSC_REGISTER, hd);
		err = notify_to_errno(err);
		if (err)
			goto rollback;
	}
unlock:
	return err;
rollback:
	last = hd;
	for_each_slot(hd) {
		if (hd == last)
			break;
		nb->call(nb, PCSC_UNREGISTER, hd);
	}
	goto unlock;
}

void pcsc_unregister_notify(notify_t *nb)
{
	unregister_notify_chain(&pcsc_handle_chain, nb);
}

int pcsc_notify(unsigned long val, void *v)
{
	return call_notify_chain(&pcsc_handle_chain, val, v);
}

static int pcsc_slot_cmd_dump(ui_session_t *sess, ui_entry_t *inst,
			     void *ctx, int argc, char **argv)
{
	pcsc_slot_t *hd;
	ui_table_t *table = ui_table_by_name(sess, "pcsc_handle_list");
	char buf[25] = "";
	int i = 0;

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "pcsc_handle_list");
	if (!table)
		return -1;

	ui_add_title(table, 0, "index");
	ui_add_title(table, 1, "reader");
	ui_add_title(table, 2, "slot");
	ui_add_title(table, 3, "card");
	ui_add_title(table, 4, "lock");

	i = 0;

	for_each_slot(hd) {
		snprintf(buf, sizeof(buf), "%04x", hd->idx);
		ui_add_value(table, "index", i, buf);
		ui_add_value(table, "reader", i, hd->ifd->name);
		snprintf(buf, sizeof(buf), "%02x", (hd->idx & 0x00FF));
		ui_add_value(table, "slot", i, buf);
		ui_add_value(table, "card", i, pcsc_card_status_str(hd->icc->status));
		ui_add_value(table, "lock", i, hd->locked ? "on" : "off");
		i++;
	}

	sess->result_table = table;
	return 0;
}

ui_command_t pscs_slot_command = {
	"dump",
	"Dump all slot on the system",
	".pcsc.slot",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(pscs_slot_command.link),
	pcsc_slot_cmd_dump,
};

ui_schema_t pscs_handle_scheme[] = {
	/* .pcsc.handle */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".pcsc.slot", "slot", "PCSC reader slot" },

	{ UI_TYPE_NONE },
};

int __init pcsc_handle_init(void)
{
	ui_register_schema(pscs_handle_scheme);
	ui_register_command(&pscs_slot_command);

	return 0;
}

void __exit pcsc_handle_exit(void)
{
	ui_unregister_command(&pscs_slot_command);
	ui_unregister_schema(pscs_handle_scheme);
}
