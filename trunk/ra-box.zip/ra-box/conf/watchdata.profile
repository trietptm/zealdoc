#
# PKCS15 r/w profile for MuscleCards
#

cardinfo {
	label       = "WATCHDATA";
	manufacturer    = "WATCHDATA";

	max-pin-length	= 8;
	min-pin-length	= 2;
	pin-encoding	= ascii-numeric;
}

option default {
	macros {
		protected	= *=$PIN, READ=NONE;
		unprotected	= *=NONE;
		so-pin-flags	= local, initialized, soPin;
		so-min-pin-length = 8;
		so-pin-attempts	= 3;
		so-auth-id	= 0;
		so-puk-attempts	= 4;
		so-min-puk-length = 8;
		unusedspace-size = 128;
		odf-size	= 256;
		aodf-size	= 256;
		cdf-size	= 512;
		prkdf-size	= 256;
		pukdf-size	= 256;
		dodf-size	= 256;
	}
}

PIN so-pin {
	reference = 0;
	flags = local, initialized;
}
PIN so-puk {
	reference = 0;
}
PIN user-pin {
	reference = 1;
	attempts = 3;
	flags = local, initialized;
}
PIN user-puk {
	reference = 1;
	attempts = 10;
}

filesystem {
    DF MF {
        path	= 3F00;
        type	= DF;
	acl	= *=NONE, ERASE=AUT, CREATE=AUT;

	EF MAIN-KEY {
		file-id = 0000;
		size	= 28;
		acl	= *=NONE, WRITE=NEVER;
	}

	# This is the DIR file(Variable Record)
	EF DIR {
		type	= EF;
		file-id	= 2F00;
		size	= 128;
		acl	= *=NONE;
	}

	# Here comes the application DF
	DF PKCS15-AppDF {
		type	= DF;
		file-id	= 5018;
		aid	= A0:00:00:00:63:50:4B:43:53:2D:31:35;
		acl	= *=NONE, ERASE=AUT, CREATE=AUT;
		size	= 5000; 
		
		#Following 3 files is mandatory
		EF KEYS {
			type		= INTERNAL-EF;
			file-id		= 0000;
			size		= 320;
			structure	= LINEAR-VARIABLE;
			acl		= *=AUT, USE=NONE, READ=NEVER;
		}
		EF INFO {
			file-id = 4946;
			size = 128;
			ACL = *=NONE;
		}

		EF PKCS15-ODF {
			file-id		= 5031;
			size		= 256;
			ACL		= *=NONE;
		}

		EF PKCS15-TokenInfo {
			file-id		= 5032;
			size		= 128;
			ACL		= *=NONE;
		}

		EF PKCS15-UnusedSpace {
			file-id		= 5033;
			size		= 128;
			ACL		= *=NONE;
		}

		EF PKCS15-AODF {
			file-id		= 4401;
			size		= 256;
			ACL		= *=AUT, READ=NONE;
		}

		EF PKCS15-PrKDF {
			file-id		= 4402;
			size		= 256;
			acl		= *=AUT, READ=NONE;
		}

		EF PKCS15-PuKDF {
			file-id		= 4403;
			size		= 256;
			acl		= *=AUT, READ=NONE;
		}

		EF PKCS15-CDF {
			file-id		= 4404;
			size		= 512;
			acl		= *=AUT, READ=NONE;
		}

		EF PKCS15-DODF {
			file-id		= 4405;
			size		= 256;
			ACL		= *=AUT, READ=NONE;
		}
	template key-domain {
		# This is a dummy entry - pkcs15-init insists that
		# this is present
		EF private-key {
			type		= INTERNAL-EF;
			file-id		= 0000;
			structure	= TRANSPARENT;
			ACL		= *=NONE, UPDATE=AUT, WRITE=AUT, READ=AUT, USE=CHV, ERASE=AUT;
			size		= 330;
		}
                EF public-key {
			type		= INTERNAL-EF;
			file-id		= 0001;
			structure	= TRANSPARENT;
			ACL		= *=NONE, UPDATE=AUT, WRITE=AUT, ERASE=AUT;
			size		= 135;
		}

                # Certificate template
                EF certificate {
			file-id		= 0002;
			structure	= TRANSPARENT;
			ACL		= *=NONE, UPDATE=AUT, WRITE=AUT, ERASE=AUT;
			size		= 2048;
                }

	        # data objects are stored in transparent EFs.
                EF data {
    	            file-id	= 3300;
    	            structure	= TRANSPARENT;
    	            ACL		= *=NONE, UPDATE=CHV, WRITE=CHV, ERASE=AUT;
		    size	= 128;	#Must be set
                }
	    }
	}
    }
}
