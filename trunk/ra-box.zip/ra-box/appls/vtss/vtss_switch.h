#ifndef __VTSS_SWITCH_H_INCLUDE__
#define __VTSS_SWITCH_H_INCLUDE__

/* - Port Numbers -------------------------------------------------- */
/* Port Number: 1..VTSS_PORTS */
typedef uint vtss_port_no_t;    /* VTSS_PORT_NO_START..(VTSS_PORT_NO_END-1) */

/* - MAC interface ------------------------------------------------- */
/* The different interfaces for connecting MAC and PHY. */
#define VTSS_PORT_INTERFACE_UNDEFINED		0x00
#define VTSS_PORT_INTERFACE_NO_CONNECTION	0x01 /* No connection */
#define VTSS_PORT_INTERFACE_LOOPBACK		0x02 /* Internal loopback in MAC */
#define VTSS_PORT_INTERFACE_INTERNAL		0x03 /* Internal interface */
#define VTSS_PORT_INTERFACE_MII			0x04 /* MII (RMII does not exist) */
#define VTSS_PORT_INTERFACE_GMII		0x05 /* GMII */
#define VTSS_PORT_INTERFACE_RGMII		0x06 /* RGMII */
#define VTSS_PORT_INTERFACE_TBI			0x07 /* TBI */
#define VTSS_PORT_INTERFACE_RTBI		0x08 /* RTBI */
#define VTSS_PORT_INTERFACE_SGMII		0x09 /* SGMII */
#define VTSS_PORT_INTERFACE_SERDES		0x0a /* SERDES */
#define VTSS_PORT_INTERFACE_VAUI		0x0b /* VAUI */
#define VTSS_PORT_INTERFACE_XGMII		0x0c /* XGMII */

/* - Speed --------------------------------------------------------- */
/* Speed type */
#define	VTSS_SPEED_UNDEFINED	0
#define	VTSS_SPEED_10M		1
#define	VTSS_SPEED_100M		2
#define	VTSS_SPEED_1G		3
#define	VTSS_SPEED_2500M	4 /* 2.5G */
#define	VTSS_SPEED_5G		5 /* 5G or 2x2.5G */
#define	VTSS_SPEED_10G		6

/* - Port Status --------------------------------------------------- */
typedef struct _vtss_port_status_t {
	vtss_event_t link_down;  /* link down event occurred since last call */
	BOOL         link;       /* link is up. Remaining fields only valid if TRUE */
	int speed;      /* speed */
	BOOL         fdx;        /* full duplex */
	
	/* auto negotiation result */
	struct {
		BOOL obey_pause;     /* this port should obey PAUSE frames */
		BOOL generate_pause; /* link partner obeys PAUSE frames */
	} aneg;
} vtss_port_status_t;

/* ================================================================= *
 * chip operations
 * ================================================================= */
typedef struct _vtss_chipid_t {
	ushort  part_number; /* BCD encoded part number */
	uint    revision;    /* Chip revision */
} vtss_chipid_t;

int vtss_chipid_get(vtss_chipid_t * const chipid);

/* ================================================================= *
 * VLAN operations
 * ================================================================= */
/* VLAN Identifier */
typedef uint vtss_vid_t; /* 0-4095 */

#define VTSS_VID_NULL     ((const vtss_vid_t)0)     /* NULL VLAN ID */
#define VTSS_VID_DEFAULT  ((const vtss_vid_t)1)     /* Default VLAN ID */
#define VTSS_VID_RESERVED ((const vtss_vid_t)0xFFF) /* Reserved VLAN ID */
#define VTSS_VIDS         ((const vtss_vid_t)4096)  /* Number of VLAN IDs */
/* For use in vtss_vlan_port_mode_t.untagged_vid field only: */
#define VTSS_VID_ALL      ((const vtss_vid_t)0x1000)/* All VLAN IDs */

/* Tag Priority */
typedef uint vtss_tagprio_t;   /* 0-7 */

/* Tag Control Information (according to IEEE 802.1Q) */
typedef struct _vtss_tci_t {
	vtss_vid_t     vid;     /* VLAN ID */
	BOOL           cfi;     /* Canonical Format Indicator */
	vtss_tagprio_t tagprio; /* Tag priority */
} vtss_tci_t;

/* ================================================================= *
 * MACtab operations
 * ================================================================= */
/* MAC Address */
typedef struct _vtss_mac_t {
	uchar addr[6]; /* Network byte order */
} vtss_mac_t;

/* For easy setup of structures */
#define VTSS_MAC_NULL {{0,0,0,0,0,0}}

/* MAC Address in specific VLAN */
typedef struct _vtss_vid_mac_t {
	vtss_vid_t  vid; /* VLAN ID */
	vtss_mac_t  mac; /* MAC address */
} vtss_vid_mac_t;

/* For easy setup of structures */
#define VTSS_VID_MAC_NULL {VTSS_VID_NULL,VTSS_MAC_NULL}

/* ================================================================= *
 *  Port Control
 * ================================================================= */
/* Number of ports may optionally be less than number of chip ports */
/* The first logical port number is 1. */
#define VTSS_PORT_NO_START   ((vtss_port_no_t)0) 
#define VTSS_PORT_NO_END     (VTSS_PORT_NO_START+VTSS_PORTS)
#define VTSS_PORT_ARRAY_SIZE VTSS_PORT_NO_END

#define VTSS_PORT_IS_PORT(x) (x>=VTSS_PORT_NO_START && x<VTSS_PORT_NO_END)

/* Port or Aggregation Number identifying a port or aggregation.
   The same Aggregation Number is shared by all the ports in an aggregation.
   Non-aggregated ports use their port_no. */
typedef vtss_port_no_t vtss_poag_no_t; /* not aggregated: port_no, aggregated: VTSS_AGGR_NO_START..(VTSS_AGGR_NO_END-1) */

/* Number of aggregations and number of ports/aggregations */
#define VTSS_AGGRS           (VTSS_PORTS/2)
#define VTSS_POAGS           (VTSS_PORTS+VTSS_AGGRS)

#define VTSS_AGGR_NO_START   ((vtss_poag_no_t)VTSS_PORT_NO_END)
#define VTSS_AGGR_NO_END     (VTSS_AGGR_NO_START+VTSS_AGGRS)
#define VTSS_POAG_NO_START   VTSS_PORT_NO_START
#define VTSS_POAG_NO_END     VTSS_AGGR_NO_END
#define VTSS_POAG_ARRAY_SIZE VTSS_AGGR_NO_END
#define VTSS_POAG_IS_POAG(x) ((x>=VTSS_POAG_NO_START) && (x<VTSS_POAG_NO_END))

#define VTSS_POAG_IS_PORT(x) (x<VTSS_AGGR_NO_START)
#define VTSS_POAG_IS_AGGR(x) (x>=VTSS_AGGR_NO_START)

/* MII Management controller */
typedef enum _vtss_miim_controller_t {
	VTSS_MIIM_CONTROLLER_0    = 0, /* MIIM controller 0 (internal), clause 22 only */
	VTSS_MIIM_CONTROLLER_1    = 1, /* MIIM controller 1 (external), clause 22 only */
	VTSS_MIIM_CONTROLLERS,         /* Number of MIIM controllers */
	VTSS_MIIM_CONTROLLER_NONE = -1 /* Unassigned MIIM controller */
} vtss_miim_controller_t;

/* - Port mapping -------------------------------------------------- */
typedef struct _vtss_mapped_port_t {
	int unused;
	vtss_miim_controller_t miim_controller; /* MII Management controller */
	/* PHY address, ignored for VTSS_MIIM_CONTROLLER_NONE */
	int phy_addr;
} vtss_mapped_port_t;

/******************************************************************************
 * Description: Setup port mapping.
 *
 * \param mapped_ports (input): Port map array indexed by vtss_port_no_t.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_port_map_set(
    const vtss_mapped_port_t mapped_ports[VTSS_PORT_ARRAY_SIZE]);


/* - IEEE 802.3 clause 22 PHY access functions --------------------- */

/******************************************************************************
 * Description: Read value from PHY register.
 *
 * \param chip_no (input)        : Chip number (for multi chip targets only).
 * \param miim_controller (input): MII Management controller.
 * \param addr (input)           : PHY address on MIIM bus.
 * \param reg (input)            : PHY register address.
 * \param value (output)         : PHY register value.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_miim_phy_read(const vtss_miim_controller_t miim_controller,
		       const uint addr, const uint reg, ushort *const value);

/******************************************************************************
 * Description: Write value to PHY register.
 *
 * \param chip_no (input)        : Chip number (for multi chip targets only).
 * \param miim_controller (input): MII Management controller.
 * \param addr (input)           : PHY address on MIIM bus.
 * \param reg (input)            : PHY register address.
 * \param value (input)          : PHY register value.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_miim_phy_write(const vtss_miim_controller_t miim_controller,
			const uint addr, const uint reg, const ushort value);

/******************************************************************************
 * Description: Read, modify and write value to PHY register.
 *
 * \param chip_no (input)        : Chip number (for multi chip targets only).
 * \param miim_controller (input): MII Management controller.
 * \param phy_addr (input)       : PHY address on MIIM bus.
 * \param phy_reg (input)        : PHY register address.
 * \param value  (input)         : Register value (16 bit).
 * \param mask (input)           : Register mask, only bits enabled are changed.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_miim_phy_writemasked(const vtss_miim_controller_t miim_controller,
			      const uint addr, const uint reg,
			      const ushort value, const ushort mask);

/******************************************************************************
 * Description: Read value from PHY register.
 *
 * \param chip_no (input)        : Chip number (for multi chip targets only).
 * \param miim_controller (input): MII Management controller.
 * \param phy_addr (input)       : PHY address on MIIM bus.
 * \param phy_reg (input)        : PHY register (page and) address.
 *
 * \return : If negative, a vtss_rc_t error code. Else 16-bit register value.
 ******************************************************************************/
int vtss_register_phy_read(const vtss_miim_controller_t miim_controller,
			   const uint phy_addr,
			   const uint phy_reg,
			   ushort *const value);


/******************************************************************************
 * Description: Write value to PHY register.
 *
 * \param chip_no (input)        : Chip number (for multi chip targets only).
 * \param miim_controller (input): MII Management controller.
 * \param phy_addr (input)       : PHY address on MIIM bus.
 * \param phy_reg (input)        : PHY register (page and) address.
 * \param value  (input)         : Register value (16 bit).
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_register_phy_write(const vtss_miim_controller_t miim_controller,
			    const uint phy_addr,
			    const uint phy_reg,
			    const ushort value);


/******************************************************************************
 * Description: Read, modify and write value to PHY register.
 *
 * \param chip_no (input)        : Chip number (for multi chip targets only).
 * \param miim_controller (input): MII Management controller.
 * \param phy_addr (input)       : PHY address on MIIM bus.
 * \param phy_reg (input)        : PHY register (page and) address.
 * \param value  (input)         : Register value (16 bit).
 * \param mask (input)           : Register mask, only bits enabled are changed.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_register_phy_writemasked(const vtss_miim_controller_t miim_controller,
                                      const uint                   phy_addr,
                                      const uint                   phy_reg,
                                      const ushort                 value,
                                      const ushort                 mask);

/* - Port configuration and reset ---------------------------------- */

/* Interface type and speed */
typedef struct _vtss_port_interface_mode_t {
	int interface_type; 
	int speed;
} vtss_port_interface_mode_t;

/* Flow control */
typedef struct _vtss_flowcontrol_setup_t {
	BOOL       obey;     /* TRUE if PAUSE frames should be obeyed */
	BOOL       generate; /* TRUE if PAUSE frames should generated */
	vtss_mac_t smac;     /* Port MAC address used as SMAC in PAUSE frames */
} vtss_flowcontrol_setup_t;

/* Use this value for all frame gaps to get default values */
#define VTSS_FRAME_GAP_DEFAULT 0

/* Inter frame gap structure */
typedef struct _vtss_frame_gaps_t {
	uint hdx_gap_1;        /* Half duplex: First part of Rx to Tx gap */
	uint hdx_gap_2;        /* Half duplex: Second part of Rx to Tx gap */
	uint fdx_gap;          /* Full duplex: Tx to Tx gap */
} vtss_frame_gaps_t;

/* A selection of max frame lengths */
#define VTSS_MAXFRAMELENGTH_STANDARD 1518    /* IEEE 802.3 standard */
#define VTSS_MAXFRAMELENGTH_TAGGED   (VTSS_MAXFRAMELENGTH_STANDARD+4)

#define VTSS_MAXFRAMELENGTH_MAX      9600

/* VLAN awareness for frame length check */
typedef enum {
	VTSS_LENGTH_TAG_NONE,   /* No extra tags allowed */
	VTSS_LENGTH_TAG_SINGLE, /* Single tag allowed */
	VTSS_LENGTH_TAG_DOUBLE  /* Single and double tag allowed */
} vtss_length_check_t;

/* Port setup, which may change dynamically, e.g. after auto-negotiation */
typedef struct _vtss_port_setup_t {
	vtss_port_interface_mode_t interface_mode; /* Interface type and speed */
	BOOL                       powerdown;      /* Disable and power down the port */
	BOOL                       fdx;            /* TRUE if full duplex */
	vtss_flowcontrol_setup_t   flowcontrol;    /* Flow control setup */
	uint                       maxframelength; /* Maximum frame length */
	vtss_length_check_t        length_check;   /* VLAN awareness for length check */
	vtss_frame_gaps_t          frame_gaps;     /* Not XGMII: Interframe gaps */
	
#ifdef VTSS_FEATURE_EXC_COL_CONT
	BOOL                       exc_col_cont;   /* Excessive collision continuation */
#endif
} vtss_port_setup_t;

/******************************************************************************
 * Description: Setup port.
 *
 * \param port_no (input): Port number.
 * \param setup (input)  : Port setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_port_setup(const vtss_port_no_t            port_no,
                        const vtss_port_setup_t * const setup);


/* - Port Link Status ---------------------------------------------- */

/******************************************************************************
 * Description: Get port status.
 *
 * \param port_no (input): Port number.
 * \param setup (output) : Status structure.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_port_status_get(const vtss_port_no_t port_no,
			 vtss_port_status_t *const status);


/* - Counters ----------------------------------------------------- */
typedef struct _vtss_poag_counters_t {
	/* RMON counters (RFC 2819) */
	struct {
		/* Rx counters */
		uint64_t rx_etherStatsDropEvents;
		uint64_t rx_etherStatsOctets;
		uint64_t rx_etherStatsPkts;
#ifdef VTSS_FEATURE_PORT_CNT_PKT_CAST
		uint64_t rx_etherStatsBroadcastPkts;
		uint64_t rx_etherStatsMulticastPkts;
#endif
#ifdef VTSS_FEATURE_PORT_CNT_RMON_ADV
		uint64_t rx_etherStatsCRCAlignErrors;
		uint64_t rx_etherStatsUndersizePkts;
		uint64_t rx_etherStatsOversizePkts;
		uint64_t rx_etherStatsFragments;
		uint64_t rx_etherStatsJabbers;
		uint64_t rx_etherStatsPkts64Octets;
		uint64_t rx_etherStatsPkts65to127Octets;
		uint64_t rx_etherStatsPkts128to255Octets;
		uint64_t rx_etherStatsPkts256to511Octets;
		uint64_t rx_etherStatsPkts512to1023Octets;
		uint64_t rx_etherStatsPkts1024to1518Octets;
#endif
#ifdef VTSS_FEATURE_PORT_CNT_JUMBO
		uint64_t rx_etherStatsPkts1519toMaxOctets;  /* Proprietary */
#endif
		/* Tx counters */
		uint64_t tx_etherStatsDropEvents;
		uint64_t tx_etherStatsOctets;
		uint64_t tx_etherStatsPkts;
#ifdef VTSS_FEATURE_PORT_CNT_PKT_CAST
		uint64_t tx_etherStatsBroadcastPkts;
		uint64_t tx_etherStatsMulticastPkts;
#endif
		uint64_t tx_etherStatsCollisions;
#ifdef VTSS_FEATURE_PORT_CNT_RMON_ADV
		uint64_t tx_etherStatsPkts64Octets;
		uint64_t tx_etherStatsPkts65to127Octets;
		uint64_t tx_etherStatsPkts128to255Octets;
		uint64_t tx_etherStatsPkts256to511Octets;
		uint64_t tx_etherStatsPkts512to1023Octets;
		uint64_t tx_etherStatsPkts1024to1518Octets;
#endif
#ifdef VTSS_FEATURE_PORT_CNT_JUMBO
		uint64_t tx_etherStatsPkts1519toMaxOctets;  /* Proprietary */
#endif
	} rmon;
	
	/* Interfaces Group counters (RFC 2863) */ 
	struct {
		/* Rx counters */
		uint64_t ifInOctets;
#ifdef VTSS_FEATURE_PORT_CNT_PKT_CAST
		uint64_t ifInUcastPkts;
		uint64_t ifInMulticastPkts;
		uint64_t ifInBroadcastPkts;
		uint64_t ifInNUcastPkts;
#endif
		uint64_t ifInDiscards;
		uint64_t ifInErrors;
		
		/* Tx counters */
		uint64_t ifOutOctets;
#ifdef VTSS_FEATURE_PORT_CNT_PKT_CAST
		uint64_t ifOutUcastPkts;
		uint64_t ifOutMulticastPkts;
		uint64_t ifOutBroadcastPkts;
		uint64_t ifOutNUcastPkts;
#endif
		uint64_t ifOutDiscards;
		uint64_t ifOutErrors;
	} if_group;
	
#ifdef VTSS_FEATURE_PORT_CNT_BRIDGE
	/* Bridge counters (RFC 4188) */
	struct {
		uint64_t dot1dTpPortInDiscards;
	} bridge;
#endif
	
#ifdef VTSS_FEATURE_PORT_CNT_QOS
	/* Proprietary counters */
	struct {
		uint64_t rx_prio[VTSS_PRIOS];
		uint64_t tx_prio[VTSS_PRIOS];
	} prop;
#endif
} vtss_poag_counters_t;

/******************************************************************************
 * Description: Update counters for port.
 *
 * \param port_no (input): Port number.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_port_counters_update(const vtss_port_no_t port_no);


/******************************************************************************
 * Description: Clear counters for port.
 *
 * \param poag_no (input): Port/aggregation number.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_poag_counters_clear(const vtss_poag_no_t poag_no);


/******************************************************************************
 * Description: Get counters for port.
 *
 * \param poag_no (input)  : Port/aggregation number.
 * \param counters (output): Counter structure.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_poag_counters_get(const vtss_poag_no_t poag_no,
                               vtss_poag_counters_t * const counters);

/* ================================================================= *
 * MAC table
 * ================================================================= */

/* - MAC address table --------------------------------------------- */
#define VTSS_MAC_ADDR_START 1
#define VTSS_MAC_ADDR_END   (VTSS_MAC_ADDR_START+VTSS_MAC_ADDRS)

/* MAC address entry */
typedef struct _vtss_mac_table_entry_t {
	vtss_vid_mac_t vid_mac;                           /* VLAN ID and MAC addr */
	BOOL           destination[VTSS_POAG_ARRAY_SIZE]; /* Dest. ports */
	BOOL           copy_to_cpu;                       /* CPU copy flag */
	BOOL           locked;                            /* Locked/static flag */
	BOOL           aged;                              /* Age flag */
} vtss_mac_table_entry_t;

typedef struct _vtss_mac_table_status_t {
	vtss_event_t learned;  /* One or more entries were learned */
	vtss_event_t replaced; /* One or more entries were replaced */
	vtss_event_t moved;    /* One or more entries moved to another port */
	vtss_event_t aged;     /* One or more entries were aged */
} vtss_mac_table_status_t;

int vtss_mac_table_learn(const vtss_mac_table_entry_t * const entry);
int vtss_mac_table_forget_vid_mac(const vtss_vid_mac_t * const vid_mac);
int vtss_mac_table_flush(void);

#ifdef VTSS_FEATURE_MAC_AGE_AUTO
typedef ulong vtss_mac_age_time_t;
int vtss_mac_table_age_time_set(const vtss_mac_age_time_t age_time);
#endif
int vtss_mac_table_age(void);
int vtss_mac_table_age_vlan(const vtss_vid_t vid);
int vtss_mac_table_forget_port(const vtss_port_no_t port_no);
int vtss_mac_table_forget_vlan(const vtss_vid_t vid);
int vtss_mac_table_forget_port_in_vlan(const vtss_port_no_t port_no,
				       const vtss_vid_t vid);
int vtss_mac_table_read(const uint idx,
			vtss_mac_table_entry_t * const entry);
int vtss_mac_table_lookup(const vtss_vid_mac_t * const   vid_mac,
			  vtss_mac_table_entry_t * const entry);
int vtss_mac_table_status_get(vtss_mac_table_status_t * const status);
int vtss_mac_table_get_next(const vtss_vid_mac_t * const vid_mac,
			    vtss_mac_table_entry_t * const entry);

/* - Learning options ---------------------------------------------- */

/* Learning mode */
typedef struct _vtss_learn_mode_t {
	BOOL automatic; /* Automatic learning done by switch chip (default enabled) */
	BOOL cpu;       /* Learn frames copied to CPU (default disabled) */
	BOOL discard;   /* Learn frames discarded (default disabled) */
} vtss_learn_mode_t;

#ifdef VTSS_FEATURE_LEARN_PORT
int vtss_learn_port_mode_set(const vtss_port_no_t port_no,
			     vtss_learn_mode_t * const learn_mode);
#endif
#ifdef VTSS_FEATURE_LEARN_SWITCH
int vtss_learn_mode_set(vtss_learn_mode_t * const learn_mode);
#endif

/* - Port STP State ------------------------------------------------ */

/* Spanning Tree state */
#define VTSS_STP_STATE_DISABLED		0x00 /* STP state disabled (admin/operational down) */
#define VTSS_STP_STATE_BLOCKING		0x01 /* STP state blocking */
#define VTSS_STP_STATE_LISTENING	0x02 /* STP state listening */
#define VTSS_STP_STATE_LEARNING		0x03 /* STP state learning */
#define VTSS_STP_STATE_FORWARDING	0x04 /* STP state forwarding */
#define VTSS_STP_STATE_ENABLED		0x05 /* STP unaware */

int vtss_port_stp_state_get(const vtss_port_no_t port_no,
                            int * const stp_state);
int vtss_port_stp_state_set(const vtss_port_no_t port_no,
                            const int stp_state);

/* MSTP instance number: VTSS_MSTI_START..(VTSS_MSTI_END-1) */
typedef uint vtss_msti_t;

/* Number of MSTP instances */
#define VTSS_MSTIS           (65) /* Fairoaks-Ie/Gatwick-Ie */
#define VTSS_MSTIS_GW        (16) /* Fairoaks/Gatwick */
#define VTSS_MSTI_START      ((vtss_msti_t)1)
#define VTSS_MSTI_END        (VTSS_MSTI_START+VTSS_MSTIS)
#define VTSS_MSTI_ARRAY_SIZE VTSS_MSTI_END

/* MSTP state */
typedef enum _vtss_mstp_state_t {
	VTSS_MSTP_STATE_DISCARDING,
	VTSS_MSTP_STATE_LEARNING,
	VTSS_MSTP_STATE_FORWARDING
} vtss_mstp_state_t;

int vtss_mstp_vlan_set(const vtss_vid_t vid, 
                       const vtss_msti_t msti);
int vtss_port_mstp_state_set(const vtss_port_no_t port_no, 
                             const vtss_msti_t msti, 
                             const vtss_mstp_state_t state);

/* - VLAN Port Mode ------------------------------------------------ */

/* VLAN port modes according to 802.1Q section 12.10.1 */
/* VLAN acceptable frame type */
#define VTSS_VLAN_FRAME_ALL		0
#define VTSS_VLAN_FRAME_TAGGED		1
#define VTSS_VLAN_FRAME_UNTAGGED	2 /* Accept untagged frames only */

/* VLAN port parameters */
typedef struct _vtss_vlan_port_mode_t {
	BOOL aware;			/* VLAN awareness */
	vtss_vid_t pvid;		/* Port VLAN ID (ingress) */
	vtss_vid_t untagged_vid;	/* Port untagged VLAN ID  (egress) */
	int frame_type;			/* Acceptable frame type (ingress) */
#ifdef VTSS_FEATURE_VLAN_INGR_FILTER_PORT
	BOOL ingress_filter;		/* Ingress filtering */
#endif
#ifdef VTSS_FEATURE_VLAN_TYPE_STAG
	BOOL stag;			/* S-Tag type */
#endif
} vtss_vlan_port_mode_t;

int vtss_vlan_port_mode_get(const vtss_port_no_t port_no,
                            vtss_vlan_port_mode_t * const vlan_mode);
int vtss_vlan_port_mode_set(const vtss_port_no_t port_no,
			    const vtss_vlan_port_mode_t * const vlan_mode);

/* - VLAN table ---------------------------------------------------- */
int vtss_vlan_port_members_get(const vtss_vid_t vid,
			       BOOL member[VTSS_PORT_ARRAY_SIZE]);
int vtss_vlan_port_members_set(const vtss_vid_t vid,
			       BOOL member[VTSS_PORT_ARRAY_SIZE]);

/* - Port Isolation------------------------------------------------- */
#ifdef VTSS_FEATURE_ISOLATED_PORT
int vtss_isolated_vlan_set(const vtss_vid_t vid,
			   const BOOL isolated);
int vtss_isolated_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE]);
#endif


/* - Aggregation --------------------------------------------------- */

/******************************************************************************
 * Description: Get aggregation port members.
 *
 * \param poag_no (input): Port/aggregation number.
 * \param member (output): Aggregation port member array.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_aggr_port_members_get(const vtss_poag_no_t poag_no,
				   BOOL member[VTSS_PORT_ARRAY_SIZE]);


/******************************************************************************
 * Description: Set aggregation port members.
 *
 * \param poag_no (input): Port/aggregation number.
 * \param member (input) : Aggregation port member array.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_aggr_port_members_set(const vtss_poag_no_t poag_no,
				   const BOOL member[VTSS_PORT_ARRAY_SIZE]);


/******************************************************************************
 * Description: Get aggregation number for port.
 *
 * \param port_no (input): Port number.
 *
 * \return : Port/aggregation number. If the port is not a member of an 
 *           aggregation, the port number itself is returned.
 ******************************************************************************/
vtss_poag_no_t vtss_aggr_port_member_get(const vtss_port_no_t port_no);


/******************************************************************************
 * Description: Set aggregation number for port.
 *
 * \param port_no (input): Port number.
 * \param poag_no (input): Port/aggregation number. If the port number itself
 *                         is used, the port is not a member of an aggregation.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_aggr_port_member_set(const vtss_port_no_t port_no,
                                  const vtss_poag_no_t poag_no);


/* Aggregation traffic distribution mode */
typedef struct _vtss_aggr_mode_t {
	BOOL smac_enable;        /* Source MAC address */
	BOOL dmac_enable;        /* Destination MAC address */   
#ifdef VTSS_FEATURE_AGGR_MODE_ADV
	BOOL sip_dip_enable;     /* Source and destination IP address */
	BOOL sport_dport_enable; /* Source and destination UDP/TCP port */
#endif
#ifdef VTSS_FEATURE_AGGR_MODE_RANDOM
	BOOL random;             /* Pseudo random distribution */
#endif
} vtss_aggr_mode_t;

/******************************************************************************
 * Description: Set aggregation traffic distribution mode.
 *
 * \param mode (input): Distribution mode structure.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_aggr_mode_set(const vtss_aggr_mode_t * const mode);    

/* - Mirroring ----------------------------------------------------- */

int vtss_mirror_monitor_port_set(const vtss_port_no_t port_no);
int vtss_mirror_ingress_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE]);
int vtss_mirror_egress_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE]);

/* - IGMP  ----------------------------------------------------- */

/******************************************************************************
 * Description: Set IPv4 multicast flood mask.
 *
 * \param member (input): Port number array. Ports connected to IPv4 multicast
 *                        routers should be enabled.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_ipv4_mc_flood_mask_set(const BOOL member[VTSS_PORT_ARRAY_SIZE]);

#define VTSS_CHIP_PORT_AGGR_0 24 /* Chip port 24 and 25 are paired */
#define VTSS_CHIP_PORT_AGGR_1 26 /* Chip port 26 and 27 are paired */
#define VTSS_PORT_NO_AGGR_0	(VTSS_PORTS+1) /* Pseudo port mapping to chip port 25 */
#define VTSS_PORT_NO_AGGR_1	(VTSS_PORTS+2) /* Pseudo port mapping to chip port 27 */

/* Port array including internally aggregated ports */
#define VTSS_PORT_EXT_ARRAY_SIZE (VTSS_PORT_ARRAY_SIZE)

/* Bit field macros */
#define VTSS_BF_SIZE(n)      ((n+7)/8)
#define VTSS_BF_GET(a, n)    ((a[(n)/8] & (1<<((n)%8))) ? 1 : 0)
#define VTSS_BF_SET(a, n, v) { if (v) { a[(n)/8] |= (1<<((n)%8)); } else { a[(n)/8] &= ~(1<<((n)%8)); }}
#define VTSS_BF_CLR(a, n)    (memset(a, 0, VTSS_BF_SIZE(n)))

/* Port member bit field macros */
#define VTSS_PORT_BF_SIZE                VTSS_BF_SIZE(VTSS_PORTS)
#define VTSS_PORT_BF_GET(a, port_no)     VTSS_BF_GET(a, port_no - VTSS_PORT_NO_START)
#define VTSS_PORT_BF_SET(a, port_no, v)  VTSS_BF_SET(a, port_no - VTSS_PORT_NO_START, v)
#define VTSS_PORT_BF_CLR(a)              VTSS_BF_CLR(a, VTSS_PORTS)

/* - Port state definitions ---------------------------------------- */

/* Port map entry */
typedef struct {
	uint           phy_addr[VTSS_PORT_ARRAY_SIZE];       /* Map from vtss_port_no_t to phy add */
	uint           miim_controller[VTSS_PORT_ARRAY_SIZE];/* Map vtss_port to miim controller */
	BOOL           vtss_port_unused[VTSS_PORT_ARRAY_SIZE]; /* Port is unused */
} vtss_port_map_t;

typedef ulong vtss_chip_counter_t;

typedef struct _vtss_chip_counters_t {
	vtss_chip_counter_t rx_octets;
	vtss_chip_counter_t tx_octets;
	vtss_chip_counter_t rx_drops;
	vtss_chip_counter_t rx_packets;
	vtss_chip_counter_t rx_broadcasts;
	vtss_chip_counter_t rx_multicasts;
	vtss_chip_counter_t rx_crc_align_errors;
	vtss_chip_counter_t rx_shorts;
	vtss_chip_counter_t rx_longs;
	vtss_chip_counter_t rx_fragments;
	vtss_chip_counter_t rx_jabbers;
	vtss_chip_counter_t rx_64;
	vtss_chip_counter_t rx_65_127;
	vtss_chip_counter_t rx_128_255;
	vtss_chip_counter_t rx_256_511;
	vtss_chip_counter_t rx_512_1023;
	vtss_chip_counter_t rx_1024_1526;
	vtss_chip_counter_t rx_1527_max;
	vtss_chip_counter_t tx_drops;
	vtss_chip_counter_t tx_packets;
	vtss_chip_counter_t tx_broadcasts;
	vtss_chip_counter_t tx_multicasts;
	vtss_chip_counter_t tx_collisions;
	vtss_chip_counter_t tx_64;
	vtss_chip_counter_t tx_65_127;
	vtss_chip_counter_t tx_128_255;
	vtss_chip_counter_t tx_256_511;
	vtss_chip_counter_t tx_512_1023;
	vtss_chip_counter_t tx_1024_1526;
	vtss_chip_counter_t tx_1527_max;
	vtss_chip_counter_t tx_fifo_drops;
	vtss_chip_counter_t rx_pauses;
	vtss_chip_counter_t tx_pauses;
	vtss_chip_counter_t rx_classified_drops;
	vtss_chip_counter_t rx_class[VTSS_PRIOS]; /* Always use direct chip values, regardless of current prios. */
	vtss_chip_counter_t tx_class[VTSS_PRIOS]; /* Always use direct chip values, regardless of current prios. */
	vtss_chip_counter_t rx_local_drops;
	vtss_chip_counter_t rx_unicast;
	vtss_chip_counter_t tx_unicast;
	vtss_chip_counter_t tx_aging;
} vtss_chip_counters_t;

/* Structure for accumulated chip specific counters */
typedef struct {
	uint64_t  rx_octets;
	uint64_t  tx_octets;
	
	uint64_t  rx_drops;
	uint64_t  rx_packets;
	uint64_t  rx_broadcasts;
	uint64_t  rx_multicasts;
	uint64_t  rx_crc_align_errors;
	uint64_t  rx_shorts;
	uint64_t  rx_longs;
	uint64_t  rx_fragments;
	uint64_t  rx_jabbers;
	uint64_t  rx_64;
	uint64_t  rx_65_127;
	uint64_t  rx_128_255;
	uint64_t  rx_256_511;
	uint64_t  rx_512_1023;
	uint64_t  rx_1024_1526;
	uint64_t  rx_1527_max;
	
	uint64_t  tx_drops;
	uint64_t  tx_packets;
	uint64_t  tx_broadcasts;
	uint64_t  tx_multicasts;
	uint64_t  tx_collisions;
	uint64_t  tx_64;
	uint64_t  tx_65_127;
	uint64_t  tx_128_255;
	uint64_t  tx_256_511;
	uint64_t  tx_512_1023;
	uint64_t  tx_1024_1526;
	uint64_t  tx_1527_max;
	
	uint64_t  tx_fifo_drops;
	uint64_t  rx_pauses;
	uint64_t  tx_pauses;
	uint64_t  rx_classified_drops;
	uint64_t  rx_class[VTSS_PRIOS];
	uint64_t  tx_class[VTSS_PRIOS];
	uint64_t  rx_local_drops;
	uint64_t  rx_unicast;
	uint64_t  tx_unicast;
	uint64_t  tx_aging;
} vtss_port_big_counters_t;

/* - L2 state definitions ------------------------------------------ */

/* Port Group ID */
typedef uint vtss_pgid_no_t;
#define VTSS_PGID_NONE            (0)
#define VTSS_PGID_START           (1)
#define VTSS_PGID_SIZE            (VTSS_CHIP_PGIDS-(VTSS_CHIP_PORTS-VTSS_PORTS))
#define VTSS_PGID_END             (VTSS_PGID_START+VTSS_PGID_SIZE)
#define VTSS_PGID_UNICAST_START   (VTSS_PGID_START)
#define VTSS_PGID_UNICAST_END     (VTSS_PGID_START+VTSS_PORTS)
#define VTSS_PGID_KILL            (VTSS_PGID_UNICAST_END)
#define VTSS_PGID_BC              (VTSS_PGID_KILL+1)
#define VTSS_PGID_MULTICAST_START (VTSS_PGID_BC+1)
#define VTSS_PGID_MULTICAST_END   (VTSS_PGID_END)
#define VTSS_PGID_ARRAY_SIZE      VTSS_PGID_END

/* Mapping between high level PGID and chip PGID is done in the low level layer */

/* PGID entry */
typedef struct {
	BOOL member[VTSS_PORT_ARRAY_SIZE]; /* Egress ports/aggregations */
	BOOL resv;                         /* Fixed reservation */
	uint references;                   /* Number references to entry */
} vtss_pgid_entry_t;

/* Aggregation table */
typedef uint vtss_ac_no_t;

#define VTSS_AC_START ((vtss_ac_no_t)1)
#define VTSS_AC_END   (VTSS_AC_START+VTSS_ACS)

/* VLAN entry */
typedef struct {
	BOOL        enabled;                      /* One or more ports enabled */
	BOOL        member[VTSS_PORT_ARRAY_SIZE]; /* Egress ports */
	vtss_msti_t msti;                         /* MSTP intstance */
#ifdef VTSS_FEATURE_ISOLATED_PORT
	BOOL        isolated;
#endif
} vtss_vlan_entry_t;

/* MSTP entry */
typedef struct {
	vtss_mstp_state_t state[VTSS_PORT_ARRAY_SIZE];       /* MSTP state */
} vtss_mstp_entry_t;

#define VTSS_STP_FORWARDING(stp_state) (stp_state==VTSS_STP_STATE_FORWARDING || stp_state==VTSS_STP_STATE_ENABLED)
#define VTSS_STP_UP(stp_state)         (stp_state!=VTSS_STP_STATE_DISABLED)

/* Size of lookup page and pointer array */
#define VTSS_MAC_PAGE_SIZE 128 
#define VTSS_MAC_PTR_SIZE  (VTSS_MAC_ADDRS/VTSS_MAC_PAGE_SIZE)

/* MAC address table for get next operations */
typedef struct vtss_mac_entry_t {
	struct vtss_mac_entry_t *next;  /* Next in list */
	ulong                   mach;  /* VID and 16 MSB of MAC */
	ulong                   macl;  /* 32 LSB of MAC */
	uchar                   member[VTSS_PORT_BF_SIZE];
} vtss_mac_entry_t;

/* IPv4 and IPv6 multicast address */
#define VTSS_MAC_IPV4_MC(mac) (mac[0] == 0x01 && mac[1] == 0x00 && mac[2] == 0x5e && (mac[3] & 0x80) == 0x00)
#define VTSS_MAC_IPV6_MC(mac) (mac[0] == 0x33 && mac[1] == 0x33)

/* - Supplementary state definitions ------------------------------- */

/* Port configuration */
typedef struct {
	BOOL enable;		/* Admin enable/disable */
	BOOL autoneg;		/* Auto negotiation */
	int speed;		/* Forced port speed */
	BOOL fdx;		/* Forced duplex mode */
	BOOL flow_control;	/* Flow control */
	uint max_length;	/* Max frame length */
} vtss_port_conf_t;

/* Read MAC address table status bits */
int vtss_mac_table_status_read(void);

/* Get port status */
int vtss_port_status_get(const vtss_port_no_t port_no,
			 vtss_port_status_t * const status);

/* Write PGID member to chip */
int vtss_pgid_table_write(const vtss_pgid_no_t pgid_no);
int vtss_pgid_alloc(vtss_pgid_no_t *pgid_no, BOOL resv,
		    const BOOL member[VTSS_POAG_ARRAY_SIZE]);
int vtss_pgid_free(const vtss_pgid_no_t pgid_no);

#endif /* __VTSS_SWITCH_H_INCLUDE__ */
