#ifndef __PCSC_IFD_H_
#define __PCSC_IFD_H_

/* lower */
typedef struct __ifd_driver 		ifd_driver_t;
typedef struct _pcsc_trans_param 	pcsc_ifd_trans_param;

struct __ifd_driver {
	const char *name;
	int (*get_desc_attr)(void *lower, int type, void *v);
	int (*get_feature)(pcsc_slot_t *);
	int (*cancel)(pcsc_slot_t *);
	int (*icc_status)(pcsc_slot_t *);
	int (*power_on)(pcsc_slot_t *);
	int (*power_off)(pcsc_slot_t *);
	int (*xfr_block)(pcsc_slot_t *, pcsc_transfer_t *t);
	int (*ifd_ctl)(pcsc_slot_t *, pcsc_transfer_t *t);

	/* init transmit proto */
	int (*init_proto)(pcsc_slot_t *s, uint16_t proto);
	/* id_table */
};

struct _pcsc_ifd {
	char *name;
	int type;	/* device type */
	uint16_t idx;	/* reader index in system, bitmap */

	int nslots;
	/* FIXME: whats this? */
	struct pcsc_path10_data path10;

	/* below is ext feature of this reader */
	/* When you open the reader, you should determine(FIXME: How to ?) 
	 * wheter the reader support keypad/display. 
	 * SPEC: extend ifd.
	 */
	int keypad;
	int display;

	int row_num;
	int col_num;

	ifd_driver_t *drv;	/* e.g. ccid_ops */
	void *lower;		/* e.g. ccid_reader_t */

	uint16_t ifd_status;

	atomic_t refcnt;
	list_t link;
};

void __exit ifd_ccid_exit(void);
int __init ifd_ccid_init(void);

pcsc_ifd_t *pcsc_ifd_get(pcsc_ifd_t *rdr);
void pcsc_ifd_put(pcsc_ifd_t *rdr);
int ifd_build_param(pcsc_transfer_t *trans, pcsc_trans_cb cb);
void ifd_destroy_param(pcsc_ifd_trans_param *param);

/* ============================================================ *
 * API for lower
 * ============================================================ */
int pcsc_ifd_create(const char *name, int type, void *lower, ifd_driver_t *ops);
int pcsc_ifd_delete(const char *name, int type, void *lower);

#endif	/* __PCSC_IFD_H_ */

