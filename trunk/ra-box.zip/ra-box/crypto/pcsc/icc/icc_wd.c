#include "../pcsc_priv.h"

#include <openssl/des.h>

/* test call-chain arch */
#define ICC_DRIVER_WD_NAME		"watchdata"

/* Watch Data Card Control */
#define ICC_WD_MAX_KEY_SIZE		16

enum _wd_key_type {
	ICC_WD_KEY_TYPE_DES_ENCRYPT		= 0x30,
	ICC_WD_KEY_TYPE_DES_DECRYPT		= 0x31,
	ICC_WD_KEY_TYPE_DESMAC			= 0x32,
	ICC_WD_KEY_TYPE_INTERNAL		= 0x34,
	ICC_WD_KEY_TYPE_MAINTANCE		= 0x36,
	ICC_WD_KEY_TYPE_PIN_UNBLOCK		= 0x37,
	ICC_WD_KEY_TYPE_PIN_RELOAD		= 0x38,
	ICC_WD_KEY_TYPE_EXTERNAL_AUTH		= 0x39,
	ICC_WD_KEY_TYPE_MAIN			= ICC_WD_KEY_TYPE_EXTERNAL_AUTH,
	ICC_WD_KEY_TYPE_PIN			= 0x3A,
	ICC_WD_KEY_TYPE_UNBLOCK			= 0x3B,
	ICC_WD_KEY_TYPE_UPDATE_OVERDRAW		= 0x3C,
	ICC_WD_KEY_TYPE_DEBIT			= 0x3D,
	ICC_WD_KEY_TYPE_PURCHASE		= 0x3E,
	ICC_WD_KEY_TYPE_CREDIT			= 0x3F,
};

/*Default Card and DF 's Regsiter state*/
#define WD_SEC_STATE_NONE	0xF0
#define WD_SEC_STATE_PIN	0x11
#define WD_SEC_STATE_AUTH	0xAA
#define WD_SEC_STATE_NEVER	0xEF

/*Watchdata TimeCOS/PK file types(DF/EF, W/I EF, B/R structure, No.)*/
#define WD_FILE_TYPE_UNKNOWN		0x8000
#define WD_FILE_TYPE_DF			0x1000	/* DF */
#define WD_FILE_TYPE_MF			0x1100
#define WD_FILE_TYPE_DF_DDF		0x1210
#define WD_FILE_TYPE_DF_ADF		0x1220
#define WD_FILE_TYPE_DF_A5		0X1230	/* V3.5: create key file */
#define WD_FILE_TYPE_EF			0x2000	/* EF */
#define WD_FILE_TYPE_EF_W		0x2100	/* Working EF */
#define WD_FILE_TYPE_EF_I		0x2200	/* Internal EF */
/*Working EF*/
#define WD_FILE_TYPE_BINARY		0x2101
#define WD_FILE_TYPE_RECORD_FIX		0x2112
#define WD_FILE_TYPE_RECORD_CYCLIC	0x2113
#define WD_FILE_TYPE_WALLET		0x2114
#define WD_FILE_TYPE_ELEC_PASSBOOK	0x2115
#define WD_FILE_TYPE_ELEC_WALLET	0x2116
#define WD_FILE_TYPE_RECORD_VAR		0x2117
/*Internal EF*/
#define WD_FILE_TYPE_PRIVATE_KEY	0x2201
#define WD_FILE_TYPE_PUBLIC_KEY		0x2202
#define WD_FILE_TYPE_KEYS		0x2213


#define WD_MAX_DF_NAME	16
#define WD_MIN_DF_NAME	5

struct icc_cardctl_wd_write_key {

#define WRITE_KEY_ACTION_LOAD	0x00
#define WRITE_KEY_ACTION_UPDATE	0x01
	uint8_t action;
	uint8_t kid;	/*reference */
	uint8_t pid;	/*parent DF FID */
	/* Key header */
	uint8_t type;
	uint8_t perm_use;
	uint8_t perm_update;
	union {
		uint8_t ver;
		uint8_t next_state;	/* for EXTERNAL AUTH and PIN */
		uint8_t pinid;		/* for WD_KEY_TYPE_PIN_UNBLOCK */
	}b4;
	union {
		uint8_t flag;
		uint8_t tries;
	}b5;
	/* Key value */
	uint8_t value[ICC_WD_MAX_KEY_SIZE];
	size_t len;
};

static icc_atr_table wd_atr_table[] = {
	{
		"WatchData TimePOS", 
	 	"3B:7D:94:00:00:57:44:35:65:F4:86:93:07:17:BD:06:20:1E",
	 	NULL,
	},
	{
		"WatchData TimePOS", 
	 	"3B:7D:94:00:00:57:44:35:65:F4:86:93:07:17:BD:06:1D:2C",
	 	NULL,
	},

	{0},
};

#ifdef NO_REF
static icc_card_error_t wd_errors[] = {
	{ 0x9000, ICC_SUCCESS,			"Operation success" },

	{ 0x61FF, ICC_SUCCESS,			"Operation success, response length is ??"},

	{ 0x6281, ICC_ERR_MEMORY_FAILURE,	"Part of returned data may be corrupted" },
	{ 0x6283, ICC_ERR_CARD_CMD_FAILED,	"Selected file invalidated" },

	{ 0x63CF, ICC_ERR_CARD_CMD_FAILED,	"Retry times is x"},

	{ 0x6400, ICC_ERR_CARD_CMD_FAILED,	"State flag not changed" },

	{ 0x6581, ICC_ERR_MEMORY_FAILURE,	"Write EEPROM failure" },

	{ 0x6700, ICC_ERR_WRONG_LENGTH,		"Wrong length" },

	{ 0x6900, ICC_ERR_NOT_ALLOWED,		"CLA and wire protect are not matched" },
	{ 0x6901, ICC_ERR_CARD_CMD_FAILED,	"Invalid status" },
	{ 0x6981, ICC_ERR_CARD_CMD_FAILED,	"Command incompatible with file structure" },
	{ 0x6982, ICC_ERR_UNAUTHORIZED,		"Security status not satisfied" },
	{ 0x6983, ICC_ERR_AUTH_BLOCKED,		"Key blocked" },
	{ 0x6984, ICC_ERR_CARD_CMD_FAILED,	"Referenced data invalidated" },
	{ 0x6985, ICC_ERR_NOT_ALLOWED,		"Conditions of use not satisfied" },
	{ 0x6987, ICC_ERR_INCORRECT_PARAM,	"Expected SM data objects missing" },
	{ 0x6988, ICC_ERR_INCORRECT_PARAM,	"SM data objects incorrect" },

	{ 0x6A80, ICC_ERR_INCORRECT_PARAM,	"Incorrect parameters in the data field" },
	{ 0x6A81, ICC_ERR_NO_CARD_SUPPORT,	"Function not supported/NO MF/Card was blocked" },
	{ 0x6A82, ICC_ERR_FILE_NOT_FOUND,	"File not found" },
	{ 0x6A83, ICC_ERR_RECORD_NOT_FOUND,	"Record not found" },
	{ 0x6A84, ICC_ERR_CARD_CMD_FAILED,	"Not enough memory space in the file" },
	{ 0x6A86, ICC_ERR_INCORRECT_PARAM,	"Incorrect parameters P1-P2" },

	{ 0x6B00, ICC_ERR_INCORRECT_PARAM,	"Wrong parameter(s) P1-P2" },

	{ 0x6CFF, ICC_ERR_INCORRECT_PARAM,	"Wrong Le" },
	{ 0x6D00, ICC_ERR_INS_NOT_SUPPORTED,	"Instruction code not supported or invalid" },
	{ 0x6E00, ICC_ERR_CLASS_NOT_SUPPORTED,	"Invalid CLA" },
	{ 0x6F00, ICC_ERR_CARD_CMD_FAILED,	"Invalid data" },

	{ 0x9302, ICC_ERR_CARD_CMD_FAILED,	"MAC error" },
	{ 0x9303, ICC_ERR_CARD_CMD_FAILED,	"Application blocked" },

	{ 0x9401, ICC_ERR_CARD_CMD_FAILED,	"Money not enough" },
	{ 0x9403, ICC_ERR_CARD_CMD_FAILED,	"not found KEY" },
	{ 0x9406, ICC_ERR_CARD_CMD_FAILED,	"KEY cannot be used" },
};
#endif

/* used call-chain */
static void wd_bind(pcsc_icc_t *icc);
static void wd_unbind(pcsc_icc_t *icc);
static void wd_up(void *eloop_data, void *data);
static void wd_down(void *eloop_data, void *data);

/* ICC command */
static int wd_create_file(pcsc_slot_t *card_handle, struct icc_file *filp,
			  pcsc_trans_cb callback, pcsc_transfer_t *card_param);
static int wd_select_file(pcsc_slot_t *, struct icc_path *in_path,
			  struct icc_file **file_out, pcsc_trans_cb cb, pcsc_transfer_t *);
static int wd_external_auth(pcsc_slot_t *slot, const uint8_t *key, size_t key_len,
			    int kid, pcsc_trans_cb callback, pcsc_transfer_t *trans);

static void wd_bind(pcsc_icc_t *icc)
{
	pcsc_icc_get(icc);
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: bind");
	/* not sure whether driver has some private data to bind */
}

static void wd_unbind(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: unbind");
	pcsc_icc_put(icc);
}

static void wd_up(void *eloop_data, void *data)
{
	pcsc_icc_t *icc = (pcsc_icc_t *)data;
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: up");
	icc_up(icc);
}

static void wd_down(void *eloop_data, void *data)
{
	pcsc_icc_t *icc = (pcsc_icc_t *)data;

	pcsc_log(LOG_CALL_CHAIN, "ICC_C: down");
	icc_down(icc);
	wd_unbind(icc);
}

static int wd_drv_match(pcsc_icc_t *icc)
{
	if (icc_match_atr(wd_atr_table, icc->atr, icc->atr_len)) {
		pcsc_log(PCSC_LOG_INFO, "ICC: watchdata card matched");
		return 1;
	}
	return 0;
}

static int wd_drv_open(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "WD: driver open");
	
	icc->flags = 0;
	icc_format_path("3F00", &icc->curr_path);
	icc->curr_path.type = ICC_PATH_TYPE_PATH;
	icc->cla  = 0x00;
	icc->max_send = 178;
	icc->max_recv = 178;

	wd_bind(icc);

	/* async notify, but not necessary in these two layer. */
	eloop_register_timeout(NULL, 0, 0, 
			       wd_up, NULL, icc);
	return -1;
}

static int wd_drv_close(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "WD: driver close");

	/* async notify, but not necessary in these two layer. */
	eloop_register_timeout(NULL, 0, 0, 
			       wd_down, NULL, icc);
	return -1;
}

/* ============================================================ *
 * driver operations
 * ============================================================ */
static int wd_default_file(struct icc_path *in_path,
			   struct icc_file *filp)
{
	unsigned int op;

	/* TODO: get file info from config */
	if (in_path->type == ICC_PATH_TYPE_DF_NAME)
		return -1;
	filp->type = ICC_FILE_TYPE_WORKING_EF;
	filp->ef_structure = ICC_FILE_EF_TRANSPARENT;
	filp->status = ICC_FILE_STATUS_ACTIVATED;
	filp->id = (in_path->value[in_path->len - 2] << 8)
			| in_path->value[in_path->len - 1];
	filp->path = *in_path;

	switch (filp->id) {
	case 0x2F00:	
		filp->size = 128;
		break;
	case 0x4946:
		filp->size = 128;
		break;
	case 0x5031:
		filp->size = 256;
		break;
	case 0x5032:
		filp->size = 128;
		break;
	case 0x5033:
		filp->size = 128;
		break;
	case 0x4401:
	case 0x4402:
	case 0x4403:
	case 0x4404:
	case 0x4405:
		filp->size = 256;
		for (op = 0; op < ICC_AC_OP_MAX; op++) {
			icc_file_clear_acl_entries(filp, op);
			icc_file_add_acl_entry(filp, op, ICC_AC_AUT, 0);
		}
		icc_file_add_acl_entry(filp, ICC_AC_OP_READ, ICC_AC_NONE, 0);
		break;
	default:
		if ((filp->id & 0xFF00) == 0x3300) { /* Data object template */
			filp->size = 128;
			icc_file_add_acl_entry(filp, ICC_AC_OP_UPDATE, ICC_AC_CHV, 0);
			icc_file_add_acl_entry(filp, ICC_AC_OP_WRITE, ICC_AC_CHV, 0);
			icc_file_add_acl_entry(filp, ICC_AC_OP_ERASE, ICC_AC_AUT, 0);
		} else if ((filp->id & 0xFF00) == 0x0000) {
			if ((filp->id & 0x00FF) % 3 == 1) { /* Private Key */
				filp->size = 330;					
				icc_file_add_acl_entry(filp, ICC_AC_OP_UPDATE, ICC_AC_AUT, 0);
				icc_file_add_acl_entry(filp, ICC_AC_OP_WRITE, ICC_AC_AUT, 0);
				icc_file_add_acl_entry(filp, ICC_AC_OP_READ, ICC_AC_AUT, 0);
				icc_file_add_acl_entry(filp, ICC_AC_OP_USE, ICC_AC_CHV, 0);
				icc_file_add_acl_entry(filp, ICC_AC_OP_ERASE, ICC_AC_AUT, 0);
			} else if ((filp->id & 0x00FF) % 3 == 2) { /* Public Key */
				filp->size = 135;					
				icc_file_add_acl_entry(filp, ICC_AC_OP_UPDATE, ICC_AC_AUT, 0);
				icc_file_add_acl_entry(filp, ICC_AC_OP_WRITE, ICC_AC_AUT, 0);
				icc_file_add_acl_entry(filp, ICC_AC_OP_ERASE, ICC_AC_AUT, 0);
			} else { /* Certification */
				filp->size = 2048;					
				icc_file_add_acl_entry(filp, ICC_AC_OP_UPDATE, ICC_AC_AUT, 0);
				icc_file_add_acl_entry(filp, ICC_AC_OP_WRITE, ICC_AC_AUT, 0);
				icc_file_add_acl_entry(filp, ICC_AC_OP_ERASE, ICC_AC_AUT, 0);
			}
		} else {
			return ICC_ERR_FILE_NOT_FOUND;
		}
		break;
	}

	return 0;
}

static void __wd_select_file_complete(pcsc_transfer_t *transfer)
{
	pcsc_icc_trans_param *icc_param = transfer->icc_param;
	struct icc_apdu *apdu = icc_param->apdu;
	struct icc_path *curr_path = &transfer->handle->icc->curr_path;
	struct icc_path *in_path = icc_param->path;
	int rbuf_actual;
	int r;

	if (transfer->ret < PCSC_S_SUCCESS) {
		icc_param->ret = transfer->ret;
		goto out;
	}

	icc_param->ret = pcsc_fetch_check_sw(transfer);
	/* skip sw1, sw2 */
	rbuf_actual = transfer->rbuf_actual - 2;

	if (icc_param->ret != 0)
		goto out;

	if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
		switch (in_path->type) {
		case ICC_PATH_TYPE_FILE_ID:
		case ICC_PATH_TYPE_FROM_CURRENT:
		case ICC_PATH_TYPE_PATH:
			if (in_path->type == ICC_PATH_TYPE_PATH) {
				pcsc_log(PCSC_SHOW, "reset curr_path");
				in_path->type = ICC_PATH_TYPE_FROM_CURRENT;
				memset(curr_path->value, 0, curr_path->len);
				curr_path->len = 0;
			}
			/* update icc curr_path */
			icc_append_path_id(&transfer->handle->icc->curr_path,
					   icc_param->sbuf, 2);

			icc_param->sbuf += 2;
			icc_param->sbuf_len -= 2;
			if (icc_param->sbuf_len >= 2) {
				/* have more data to send,
				 * build APDU and send cmd again */
				apdu->tx_buf = icc_param->sbuf;
				apdu->tx_buflen = icc_param->sbuf_len;
				apdu->lc = 2;
				if (icc_param->file_out && apdu->tx_buflen == 2)
					apdu->le = transfer->rbuf_len - 2;

				apdu->cse = ICC_APDU_CASE_4_SHORT;
				apdu->ins = 0xA4;

				pcsc_sync_apdu(transfer);
				r = pcsc_transmit(transfer);
				if (r == ICC_SUCCESS)
					return;
				
				icc_param->ret = r;
				goto out;
			}
			/* XXX: do not break at here */
		case ICC_PATH_TYPE_DF_NAME:
			if (in_path->type == ICC_PATH_TYPE_DF_NAME)
				transfer->handle->icc->curr_path = *in_path;
			
			if (icc_param->file_out) {
				struct icc_file *filp;

				filp = icc_file_new();
				if (!filp) {
					icc_param->ret = ICC_ERR_NO_MEM;
					goto out;
				} else {
					/* have data */
					if (rbuf_actual > 0) {
						/* 7816-4 5.1.5: file control info(fci) */
						if (transfer->rbuf[0] == ICC_FCI_TAG_FCI)
						icc_param->ret = pcsc_icc_ops(transfer->handle)->process_fci(transfer->handle,
							filp, transfer->rbuf, rbuf_actual);
					} else {
						struct icc_path *temp;
						/* use full path */
						if (in_path->be_cut == 1)
							temp = curr_path;
						else
							temp = in_path;
						icc_param->ret = wd_default_file(temp, filp);
					}
					
					if (icc_param->ret == ICC_SUCCESS)
						*icc_param->file_out = filp;
					else
						icc_file_free(filp);
				}
			}
			break;
		}
	} else if (apdu->sw1 == 0x61) {
		uint8_t le = apdu->sw2 != 0 ? apdu->sw2 : 256;
		/* only T0 can use response for this */

		/* if rbuf_len < current - head or ... */
		transfer->rbuf += rbuf_actual;
		
		r = pcsc_icc_ops(transfer->handle)->get_response(
			transfer, transfer->rbuf, transfer->rbuf_len, le);
		if (r != 0) {
			transfer->ret = r;
			goto out;
		}
		return;
	}
	/* TODO: parse error sw and do right thing */
out:
	transfer->ret = icc_param->ret;
	icc_param->callback(transfer);

	free(in_path);
	icc_trans_param_free(icc_param);
}


/* no rbuf input */
static int __wd_select_file(pcsc_slot_t *card_handle,
			    struct icc_path *in_path,
			    struct icc_file **file_out,
			    pcsc_trans_cb callback,
			    pcsc_transfer_t *transfer)
{
	pcsc_icc_trans_param *icc_param;
	int r;
	int cse;	/*apdu case*/
	uint8_t cla, ins, p1, p2, *data;
	uint32_t lc, le;
	size_t datalen;

	icc_param = icc_trans_param_new();
	if (!icc_param) {
		r = ICC_ERR_NO_MEM;
		goto err;
	}

	icc_param->path = in_path;
	/* XXX: Because Watch Data Card only support SELECT_BY_FILE_ID
	 * (or DF NAME), we use icc_param->sbuf to trace the in_path. */
	icc_param->sbuf = in_path->value;
	icc_param->sbuf_len = in_path->len;
	icc_param->file_out = file_out;
	icc_param->callback = callback;
	
	/* build apdu */
	cse = ICC_APDU_CASE_4_SHORT;
	cla = card_handle->icc->cla;
	ins = ICC_APDU_INS_SELECT_FILE;
	data = icc_param->sbuf;
	datalen = icc_param->sbuf_len;
	
	switch (in_path->type) {
	case ICC_PATH_TYPE_DF_NAME:
		p1 = 0x04;
		p2 = 0x00;
		lc = icc_param->sbuf_len;
		if (file_out)
			le = ICC_APDU_BUFFER_MAX -2;
		break;
	case ICC_PATH_TYPE_FILE_ID:
	case ICC_PATH_TYPE_FROM_CURRENT:
	case ICC_PATH_TYPE_PATH:
		p1 = 0x00;
		p2 = 0x00;
		lc = 2;
		/* 2 means its last cmd */
		if (file_out && datalen == 2)
			le = ICC_APDU_BUFFER_MAX -2;
		break;
	default:
		r = ICC_ERR_NOT_SUPPORTED;
		goto err;
	}
	
	icc_param->apdu = pcsc_build_apdu(cse, cla, ins, p1, p2, lc, le, data, datalen);

	if (!icc_param->apdu) {
		r = ICC_ERR_NO_MEM;
		goto err;
	}

	transfer->icc_param = icc_param;

	r = pcsc_transmit_from_icc(transfer, __wd_select_file_complete);
	if (r != ICC_SUCCESS)
		goto err;
out:
	return r;
err:
	if (in_path) free(in_path);
	if (icc_param) icc_trans_param_free(icc_param);
	goto out;
}

static int wd_select_file(pcsc_slot_t *card_handle, 
			  struct icc_path *in_path,
			  struct icc_file **file_out, 
			  pcsc_trans_cb callback, 
			  pcsc_transfer_t *transfer)
{	
	struct icc_path *curr_path = &card_handle->icc->curr_path;
	struct icc_path *out_path;
	char buf[30];

	icc_deformat_path(in_path, buf, 30);
	pcsc_log(PCSC_LOG_DEBUG, "ICC: select_file, in_path=%s", buf);

	icc_deformat_path(curr_path, buf, 30);
	pcsc_log(PCSC_LOG_DEBUG, "ICC: select_file, curr_path=%s", buf);

	out_path = malloc(sizeof(struct icc_path));
	if (!out_path)
		return ICC_ERR_NO_MEM;

	memset(out_path, 0, sizeof (struct icc_path));

	switch (in_path->type) {
	case ICC_PATH_TYPE_FILE_ID:
		if (in_path->len != 2) {
			free(out_path);
			return ICC_ERR_INVALID_ARGS;
		}
	case ICC_PATH_TYPE_DF_NAME:
	case ICC_PATH_TYPE_FROM_CURRENT:
		*out_path = *in_path;
		break;
	case ICC_PATH_TYPE_PATH:
		/* Your select path is equal to the current path, 
		 * and you want not file_out, return directly. */
		if (icc_is_same_path(in_path, curr_path) && file_out == 0) {
			transfer->ret = ICC_SUCCESS;
			callback(transfer);
			free(out_path);
			return ICC_SUCCESS;
		} else if (icc_is_upper(curr_path, in_path)) {
			memcpy(out_path->value, in_path->value + curr_path->len, 
			       in_path->len - curr_path->len);
			out_path->len = in_path->len - curr_path->len;
			out_path->type = ICC_PATH_TYPE_FROM_CURRENT;
			out_path->be_cut = 1;
		} else {
			*out_path = *in_path;
		}
		break;
	default:
		free(out_path);
		return ICC_ERR_NOT_SUPPORTED;
	}
	
	return __wd_select_file(card_handle, out_path, file_out,
				callback, transfer);
}

typedef struct __external_priv {
	uint8_t random[8];
	uint8_t random_e[8];

	const uint8_t *key;
	size_t key_len;
	int kid;
} wd_ext_t;

static void __wd_des_encrypt(const uint8_t *key, int key_len,
			     uint8_t *data, uint8_t *data_en)
{
	if (key_len == 16) {
		DES_key_schedule ks_left, ks_right;
		const_DES_cblock *key_left, *key_right;
		key_left = (DES_cblock *)key;
		key_right = (DES_cblock *)key + 1;
		DES_set_key_unchecked(key_left, &ks_left);
		DES_set_key_unchecked(key_right, &ks_right);

		DES_ecb3_encrypt((const_DES_cblock*)data, (DES_cblock *)data_en, 
				&ks_left, &ks_right, &ks_left, DES_ENCRYPT); 
	} else if (key_len == 8) {
		DES_key_schedule ks;

		DES_set_key_unchecked((DES_cblock *)key, &ks);

		DES_ecb_encrypt((const_DES_cblock*)data, (DES_cblock *)data_en, 
				&ks, DES_ENCRYPT); 
	}

}

static void __ext_auth_3_cb(pcsc_transfer_t *trans)
{
	pcsc_icc_trans_param *param = trans->icc_param;
	wd_ext_t *ext = param->priv;
	struct icc_apdu *apdu = param->apdu;

	if (trans->ret != 0) {
		param->ret = trans->ret;
	} else {
		param->ret = pcsc_fetch_check_sw(trans);
		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
			pcsc_log(PCSC_LOG_INFO, "WD: external auth success");
		} else
			pcsc_log(PCSC_LOG_INFO, "WD: external auth failure");
	}

	trans->ret = param->ret;
	param->callback(trans);
	icc_trans_param_free(param);
	memset(ext, 0, sizeof (wd_ext_t));
	free(ext);
}

static void __ext_auth_1_cb(void *u, int ret)
{
	pcsc_transfer_t *trans = (pcsc_transfer_t *)u;
	pcsc_icc_trans_param *param = trans->icc_param;
	wd_ext_t *ext = param->priv;

	int cse;	/*apdu case*/
	uint8_t cla, ins, p1, p2, *data;
	uint32_t lc, le;
	size_t datalen;

	/* wd card ext-auth use 8 bytes random */
	if (ret < 0 || ret != 8) {
		pcsc_log(PCSC_LOG_ERR, "get challenge failure");
		goto out;
	}

	/* step 2 */
	__wd_des_encrypt(ext->key, ext->key_len, ext->random, ext->random_e);
	
	cse = ICC_APDU_CASE_3_SHORT;
	cla = trans->handle->icc->cla;
	ins = ICC_APDU_INS_EXTERNAL_AUTH;
	p1 = 0x00;
	p2 = ext->kid;
	lc = 8;
	le = 0;
	data = ext->random_e;
	datalen = lc;

	param->apdu = pcsc_build_apdu(cse, cla, ins, p1, p2, lc, le, data, datalen);
	if (!param->apdu)
		goto out;
	/* step 3 */
	if (pcsc_transmit_from_icc(trans, __ext_auth_3_cb) != 0)	
		goto out;
	return;
out:
	trans->ret = -1;
	param->callback(trans);
	icc_trans_param_free(param);
	memset(ext, 0, sizeof (wd_ext_t));
	free(ext);
}

/* Following steps:
 * 1) Get 8 bytes random number RNDicc from ICC
 * 2) D1 = DES(Key, RNDicc)
 * 3) Send APDU with lc(data) field=D1 and p2=KID to ICC to do external authenticate
 * Get the response and check SW
 */
static int wd_external_auth(pcsc_slot_t *slot, const uint8_t *key, size_t key_len,
			    int kid, pcsc_trans_cb callback, pcsc_transfer_t *trans)
{
	int rv;
	pcsc_icc_trans_param *param;
	wd_ext_t *ext;

	/* invalid key length */
	if (key_len != 8 && key_len != 16)
		return -1;

	param = icc_trans_param_new();
	if (!param)
		return ICC_ERR_NO_MEM;

	ext = malloc(sizeof (wd_ext_t));
	if (!ext) {
		icc_trans_param_free(param);
		return ICC_ERR_NO_MEM;
	}
	memset(ext, 0, sizeof (wd_ext_t));

	ext->key = key;
	ext->key_len = key_len;
	ext->kid = kid;
	param->priv = ext;
	
	param->callback = callback;
	trans->icc_param = param;

	/* step 1 */
	rv = pcsc_get_challenge(slot, ext->random, 8, __ext_auth_1_cb, trans);
	if (rv != 0)
		icc_trans_param_free(param);
		free(ext);
	return rv;
}

static int wd_pin_cmd(pcsc_slot_t *slot, struct icc_pin_cmd_data *cmd_data,
		      int *tries_left,
		      pcsc_trans_cb callback, pcsc_transfer_t *t)
{
	switch (cmd_data->cmd) {
	case ICC_PIN_CMD_VERIFY:
		switch (cmd_data->pin_type) {
		case ICC_AC_AUT:
			if (cmd_data->pin1.len > 16)
				return -1;
			return wd_external_auth(slot, cmd_data->pin1.data,
					(size_t)(cmd_data->pin1.len), 
					cmd_data->pin_ref, callback, t);
		}
		break;
	}

//	return iso_ops->pin_cmd(card, cmd_data, tries_left);
	return -1;
}

static int file_type_sc_to_wd(const struct icc_file *filp)
{
	int wd_file_type = WD_FILE_TYPE_UNKNOWN;

	switch (filp->type) {
	case ICC_FILE_TYPE_DF:
		if (filp->id == 0x3F00)
			wd_file_type = WD_FILE_TYPE_MF;
		else
			wd_file_type = WD_FILE_TYPE_DF;
		break;
	case ICC_FILE_TYPE_WORKING_EF:
		switch (filp->ef_structure) {
		case ICC_FILE_EF_TRANSPARENT:
			wd_file_type = WD_FILE_TYPE_BINARY;
			break;
		case ICC_FILE_EF_LINEAR_FIXED:
		case ICC_FILE_EF_LINEAR_FIXED_TLV:
			wd_file_type = WD_FILE_TYPE_RECORD_FIX;
			break;
		case ICC_FILE_EF_CYCLIC:
		case ICC_FILE_EF_CYCLIC_TLV:
			wd_file_type = WD_FILE_TYPE_RECORD_CYCLIC;
			break;
		case ICC_FILE_EF_LINEAR_VARIABLE:
		case ICC_FILE_EF_LINEAR_VARIABLE_TLV:
			wd_file_type = WD_FILE_TYPE_RECORD_VAR;
			break;
		}
		break;
	case ICC_FILE_TYPE_INTERNAL_EF:
		switch (filp->ef_structure){
		case ICC_FILE_EF_LINEAR_VARIABLE:
		case ICC_FILE_EF_LINEAR_VARIABLE_TLV:
			if (filp->id == 0x0000)
				wd_file_type = WD_FILE_TYPE_KEYS;
			break;
		case ICC_FILE_EF_TRANSPARENT:
			/* XXX: For PKI, We assume:
			 *	the file id of private key % 3 == 1
			 *	the file id of public key %3 == 2
			 *	the file id of certificate % 3 == 0
			 */
			if ((filp->id & 0xFF00) == 0x0000) {
				if ((filp->id & 0x00FF) % 3 == 1)
					wd_file_type = WD_FILE_TYPE_PRIVATE_KEY;
				else if ((filp->id & 0x00FF) % 3 == 2)
					wd_file_type = WD_FILE_TYPE_PUBLIC_KEY;
				else /*Cert*/
					wd_file_type = WD_FILE_TYPE_BINARY;
			}
			break;
		}
		break;
	}

	return wd_file_type;
}

static uint8_t acl2permission(const struct icc_file *filp, unsigned int op)
{
	uint8_t perm = WD_SEC_STATE_NONE;
	const struct icc_acl_entry *acl;

	acl = icc_file_get_acl_entry(filp, op);

	if (!acl) {
		perm = WD_SEC_STATE_NONE;
	} else {
		switch (acl->method) {
		case ICC_AC_UNKNOWN:
		case ICC_AC_NONE:
			perm = WD_SEC_STATE_NONE;
			break;
		case ICC_AC_CHV:
		case ICC_AC_TERM:
		case ICC_AC_PRO:
			perm = WD_SEC_STATE_PIN;
			break;
		case ICC_AC_AUT:
			perm = WD_SEC_STATE_AUTH;
			break;
		case ICC_AC_NEVER:
			perm = WD_SEC_STATE_NEVER;
			break;
		default:
			perm = WD_SEC_STATE_NONE;
			break;
		}
	}

	return perm;
}

/* XXX: We do not support CIRCURIT PROTECTED */
static int wd_format_ef_header(int wd_file_type, const struct icc_file *filp,
			       uint8_t *out, size_t *outlen)
{
	uint8_t *p = out;

	switch (wd_file_type) {
	case WD_FILE_TYPE_MF:
		*p++ = 0x38;
		*p++ = 0xFF;	/*File size(2 bytes)*/
		*p++ = 0xFF;
		*p++ = acl2permission(filp, ICC_AC_OP_CREATE);
		*p++ = acl2permission(filp, ICC_AC_OP_DELETE);
		*p++ = 0xFF;	/*The next 8 bytes reserved*/
		*p++ = 0xFF;
		*p++ = 0xFF;
		*p++ = 0xFF;
		*p++ = 0xFF;
		*p++ = 0xFF;
		*p++ = 0xFF;
		*p++ = 0xFF;
		break;
	case WD_FILE_TYPE_DF:
		*p++ = 0x38;	/*File Type*/
		*p++ = (filp->size >> 8) & 0xFF;
		*p++ = filp->size  & 0xFF;
		*p++ = acl2permission(filp, ICC_AC_OP_CREATE);
		*p++ = acl2permission(filp, ICC_AC_OP_DELETE);
		*p++ = 0xFF;	/*The next 3 bytes reserved*/
		*p++ = 0xFF;
		*p++ = 0xFF;
		if (filp->df_name_len > 0) {
			if (filp->df_name_len >= WD_MIN_DF_NAME &&
			    filp->df_name_len <= WD_MAX_DF_NAME) {
				memcpy(p, filp->df_name, filp->df_name_len);
				p += filp->df_name_len;
			} else {
				return ICC_ERR_INVALID_ARGS;
			}
		}

		break;
	case WD_FILE_TYPE_BINARY:
		*p++ = 0x28;	/*File Type*/
		*p++ = (filp->size >> 8) & 0xFF;
		*p++ = filp->size  & 0xFF;
		*p++ = acl2permission(filp, ICC_AC_OP_READ);
		*p++ = acl2permission(filp, ICC_AC_OP_WRITE);
		*p++ = 0xFF;
		*p++ = 0xFF;

		break;
	case WD_FILE_TYPE_RECORD_FIX:
		if (filp->record_count < 2 || filp->record_count > 254)
			return ICC_ERR_INVALID_ARGS;
		if (filp->record_length > 178)
			return ICC_ERR_INVALID_ARGS;
		*p++ = 0x2A;/*File Type*/
		*p++ = filp->record_count;
		*p++ = filp->record_length;
		*p++ = acl2permission(filp, ICC_AC_OP_READ);
		*p++ = acl2permission(filp, ICC_AC_OP_WRITE);
		*p++ = 0xFF;
		*p++ = 0xFF;

		break;
	case WD_FILE_TYPE_RECORD_CYCLIC:
		if (filp->record_count < 2 || filp->record_count > 254)
			return ICC_ERR_INVALID_ARGS;
		if (filp->record_length > 178)
			return ICC_ERR_INVALID_ARGS;
		*p++ = 0x2E;	/* file type */
		*p++ = filp->record_count;
		*p++ = filp->record_length;
		*p++ = acl2permission(filp, ICC_AC_OP_READ);
		*p++ = acl2permission(filp, ICC_AC_OP_WRITE);
		*p++ = 0xFF;
		*p++ = 0xFF;

		break;
	case WD_FILE_TYPE_RECORD_VAR:
		*p++ =  0x2C;/*File Type*/
		*p++ = (filp->size >> 8) & 0xFF;
		*p++ = filp->size  & 0xFF;
		*p++ = acl2permission(filp, ICC_AC_OP_READ);
		*p++ = acl2permission(filp, ICC_AC_OP_WRITE);
		*p++ = 0xFF;
		*p++ = 0xFF;

		break;
	case WD_FILE_TYPE_PRIVATE_KEY:
		if (filp->size < 330)
			return ICC_ERR_INVALID_ARGS;
		*p++ = 0x3D;/*File Type*/
		*p++ = (filp->size >> 8) & 0xFF;
		*p++ = filp->size  & 0xFF;
		*p++ = acl2permission(filp, ICC_AC_OP_USE);
		*p++ = acl2permission(filp, ICC_AC_OP_UPDATE);
		*p++ = acl2permission(filp, ICC_AC_OP_READ);
		*p++ = 0xFF;

		break;
	case WD_FILE_TYPE_PUBLIC_KEY:
		if (filp->size < 135)
			return ICC_ERR_INVALID_ARGS;
		*p++ = 0x3E;/*File Type*/
		*p++ = (filp->size >> 8) & 0xFF;
		*p++ = filp->size  & 0xFF;
		*p++ = acl2permission(filp, ICC_AC_OP_USE);
		*p++ = acl2permission(filp, ICC_AC_OP_UPDATE);
		*p++ = acl2permission(filp, ICC_AC_OP_READ);
		*p++ = 0xFF;

		break;
	case WD_FILE_TYPE_KEYS:
		*p++ = 0x3F;
		*p++ = (filp->size >> 8) & 0xFF;
		*p++ = filp->size  & 0xFF;
		*p++ = 0xFF;
		*p++ = acl2permission(filp, ICC_AC_OP_WRITE);
		*p++ = 0xFF;
		*p++ = 0xFF;
		break;
/*TODO:
 *	WD_FILE_TYPE_WALLET
 *	WD_FILE_TYPE_ELEC_PASSBOOK
 *	WD_FILE_TYPE_ELEC_WALLET
 */
	default:
		return ICC_ERR_NOT_SUPPORTED;		
	}

	*outlen = p - out;
	return ICC_SUCCESS;
}

static int wd_construct_fci(pcsc_slot_t *card_handle, 
			    struct icc_file *filp,
			    uint8_t *fci_buf, size_t *fci_buflen)
{
	/*TODO: Support Security Message*/
	int file_type = file_type_sc_to_wd(filp);
	
	return wd_format_ef_header(file_type, filp, fci_buf, fci_buflen);
}

static void wd_create_file_complete(pcsc_transfer_t *transfer)
{
	pcsc_icc_trans_param *param = transfer->icc_param;

	if (transfer->ret != ICC_SUCCESS)
		param->ret = transfer->ret;
	else
		param->ret = pcsc_fetch_check_sw(transfer);

	transfer->ret = param->ret;
	param->callback(transfer);

	icc_trans_param_free(param);
}

/* FID must apply:
 * MF			- 3F00
 * KEY			- 0000
 * PR/PU & 0xFF00	- 0000	
 * DEPOSIT		- 0001
 * PURSE		- 0002
 */
static int wd_create_file(pcsc_slot_t *card_handle, 
			  struct icc_file *filp,
			  pcsc_trans_cb callback, 
			  pcsc_transfer_t *trans)
{
	pcsc_icc_trans_param *param;
	struct icc_apdu *apdu;
	uint8_t fci_buf[ICC_APDU_BUFFER_MAX];
	size_t fci_buflen;
	int r;

	if (!filp)
		return -1;

	param = icc_trans_param_new();

	if (!param)
		return ICC_ERR_NO_MEM;
	param->callback = callback;
	
	fci_buflen = sizeof(fci_buf);
	r = pcsc_icc_ops(card_handle)->construct_fci(card_handle, filp, 
						     fci_buf, &fci_buflen);

	if (r != ICC_SUCCESS) {
		icc_trans_param_free(param);
		return r;
	}

	apdu = malloc(sizeof(struct icc_apdu));
	if (!apdu) {
		icc_trans_param_free(param);
		return ICC_ERR_NO_MEM;	
	}
	memset(apdu, 0, sizeof(struct icc_apdu));
	apdu->cse = ICC_APDU_CASE_3_SHORT;
	apdu->cla = 0x80;
	apdu->ins = ICC_APDU_INS_CREATE_FILE;
	apdu->p1 = (filp->id >> 8) & 0xFF;
	apdu->p2 = filp->id & 0xFF;
	apdu->lc = fci_buflen;
	apdu->tx_buf = fci_buf;
	apdu->tx_buflen = fci_buflen;

	param->apdu = apdu;
	trans->icc_param = param;

	r = pcsc_transmit_from_icc(trans, wd_create_file_complete);
	if (r != ICC_SUCCESS)
		icc_trans_param_free(param);

	return r;	
}

#ifdef NO_REF
static int wd_construct_key_header(struct icc_cardctl_wd_write_key *keyp,
				   uint8_t *key_data, size_t *key_datalen)
{
	uint8_t *p = key_data;

	if (keyp->len + 5 > *key_datalen)
		return ICC_ERR_INSUF_BUFFER;

	*p++ = keyp->type;
	switch (keyp->type) {
	case ICC_WD_KEY_TYPE_DES_ENCRYPT:
	case ICC_WD_KEY_TYPE_DES_DECRYPT:
	case ICC_WD_KEY_TYPE_DESMAC:
	case ICC_WD_KEY_TYPE_INTERNAL:
	case ICC_WD_KEY_TYPE_UPDATE_OVERDRAW:
	case ICC_WD_KEY_TYPE_DEBIT:
	case ICC_WD_KEY_TYPE_PURCHASE:
	case ICC_WD_KEY_TYPE_CREDIT:
		if (keyp->len != 8 && keyp->len != 16)
			return ICC_ERR_INVALID_ARGS;
		*p++ = keyp->perm_use;
		*p++ = keyp->perm_update;
		*p++ = keyp->b4.ver;
		*p++ = keyp->b5.flag;
		break;
	case ICC_WD_KEY_TYPE_MAINTANCE:
	case ICC_WD_KEY_TYPE_PIN_UNBLOCK:
	case ICC_WD_KEY_TYPE_PIN_RELOAD:
		if (keyp->len != 8 && keyp->len != 16)
			return ICC_ERR_INVALID_ARGS;
		*p++ = keyp->perm_use;
		*p++ = keyp->perm_update;
		*p++ = 0xFF;
		*p++ = keyp->b5.tries;
		break;
	case ICC_WD_KEY_TYPE_EXTERNAL_AUTH:
		if (keyp->len != 8 && keyp->len != 16)
			return ICC_ERR_INVALID_ARGS;
		*p++ = keyp->perm_use;
		*p++ = keyp->perm_update;
		*p++ = keyp->b4.next_state;
		*p++ = keyp->b5.tries;
		break;
	case ICC_WD_KEY_TYPE_PIN:
		if (keyp->len < 2 || keyp->len > 8)
			return ICC_ERR_INVALID_ARGS;
		*p++ = keyp->perm_use;
		*p++ = 0xEF;
		*p++ = keyp->b4.next_state;
		*p++ = keyp->b5.tries;
		break;
	case ICC_WD_KEY_TYPE_UNBLOCK:
		if (keyp->len != 8)
			return ICC_ERR_INVALID_ARGS;
		*p++ = keyp->perm_use;
		*p++ = keyp->perm_update;
		*p++ = keyp->b4.pinid;
		*p++ = keyp->b5.tries;
		break;
	default:
		return ICC_ERR_NOT_SUPPORTED;
	}

	memcpy(p, keyp->value, keyp->len);
	p += keyp->len;

	*key_datalen = p - key_data;

	return ICC_SUCCESS;
}

static void wd_write_key_complete(pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param = card_param->icc_trans;
	struct icc_apdu *apdu = cmd_param->apdu;

	if (card_param->ret != ICC_SUCCESS)
		cmd_param->ret = card_param->ret;
	else {
		cmd_param->ret = pcsc_fetch_check_sw(card_param);
	}

	card_param->ret = cmd_param->ret;
	cmd_param->callback(card_param);

	icc_trans_param_free(cmd_param);
}

static int wd_write_key(pcsc_slot_t *card_handle, 
			struct icc_cardctl_wd_write_key *keyp,
			pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	uint8_t key_data[258];
	size_t key_datalen = sizeof(key_data);
	int r;

	cmd_param = icc_trans_param_new();
	if (!cmd_param)
		return ICC_ERR_NO_MEM;
	cmd_param->callback = callback;

	apdu = malloc(sizeof(struct icc_apdu));
	if (!apdu) {
		icc_trans_param_free(cmd_param);
		return ICC_ERR_NO_MEM;
	}
	memset(apdu, 0, sizeof(struct icc_apdu));
	apdu->cse = ICC_APDU_CASE_3_SHORT;
	apdu->cla = 0x80;
	apdu->ins = 0xD4;
	if (keyp->action == WRITE_KEY_ACTION_LOAD) {
		apdu->p1 = 0x01;
		r = wd_construct_key_header(keyp, key_data, &key_datalen);
		if (r != ICC_SUCCESS) {
			icc_trans_param_free(cmd_param);
			free(apdu);
			return r;
		}
	} else {
		apdu->p1 = keyp->type;
		if (keyp->len > sizeof(key_data)) {
			icc_trans_param_free(cmd_param);
			free(apdu);
			return ICC_ERR_INVALID_ARGS;
		}
		memcpy(key_data, keyp->value, keyp->len);
		key_datalen = keyp->len;
	}
	apdu->p2 = keyp->kid;
	/* TODO: construct key data */
	apdu->lc = key_datalen;
	apdu->data = key_data;
	apdu->datalen = key_datalen;

	cmd_param->apdu = apdu;
	card_param->icc_trans = cmd_param;

	r = pcsc_transmit_from_icc(card_param, wd_write_key_complete);
	if (r != ICC_SUCCESS)
		icc_trans_param_free(cmd_param);

	return r;
}

static int wd_card_ctl(pcsc_slot_t *card_handle, 
		       unsigned long request, void *data,
		       pcsc_appcmd_complete callback, void *user_data)
{
#if 0
	struct icc_cardctl_wd_write_key *keyp;

	switch (request) {
	case ICC_CARDCTL_WRITE_KEY:
		keyp = (struct icc_cardctl_wd_write_key *)data;
		return wd_write_key(card_handle, keyp, callback, user_data);
	default:
		return ICC_ERR_INVALID_ARGS;
	}
#endif
	return -1;
}
#endif

static icc_driver_ops_t watchdata_ops = {
	iso7816_read_binary,
	iso7816_write_binary,
	iso7816_update_binary,
	NULL,
	iso7816_read_record,
	iso7816_write_record,
	iso7816_append_record,
	iso7816_update_record,
	NULL,
	NULL,
	wd_select_file,
	iso7816_get_response,
	NULL,
	wd_pin_cmd,
	NULL,
	wd_external_auth,
	iso7816_get_challenge,	/* rnd_len is 0x04~0x10 */
	NULL,
	NULL,
	wd_create_file,
	iso7816_delete_file,
	NULL,
	iso7816_check_sw,	/* FIXME: need self? */
	NULL,
	iso7816_process_fci,
	NULL,
	NULL,	/* extension for private cmd */
	/*
		private cmd:
		decrease,
		increase,
	 */

};

static icc_driver_t wd_driver = {
	ICC_DRIVER_WD_NAME,
	ICC_DRV_SYNC_MATCH,
	wd_drv_match,
	wd_drv_open,	/* call-chain */
	wd_drv_close,	/* call-chain */
	&watchdata_ops,
};

int __init icc_wd_init(void)
{
	icc_register_driver(&wd_driver);
	return 0;
}

void __exit icc_wd_exit(void)
{
	icc_unregister_driver(&wd_driver);
}
