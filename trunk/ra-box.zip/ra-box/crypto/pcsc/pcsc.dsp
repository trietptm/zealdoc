# Microsoft Developer Studio Project File - Name="pcsc" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Static Library" 0x0104

CFG=pcsc - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "pcsc.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "pcsc.mak" CFG="pcsc - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "pcsc - Win32 Release" (based on "Win32 (x86) Static Library")
!MESSAGE "pcsc - Win32 Debug" (based on "Win32 (x86) Static Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "pcsc - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_MBCS" /D "_LIB" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_MBCS" /D "_LIB" /YX /FD /c
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo

!ELSEIF  "$(CFG)" == "pcsc - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "..\..\bin\debug"
# PROP Intermediate_Dir "..\..\obj\debug\pcsc"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_MBCS" /D "_LIB" /YX /FD /GZ /c
# ADD CPP /nologo /MTd /W3 /Gm /GX /ZI /Od /I "../../include" /I "../../lib/missing" /D "WIN32" /D "_DEBUG" /D "_MBCS" /D "_LIB" /FR /YX /FD /GZ /c
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo

!ENDIF 

# Begin Target

# Name "pcsc - Win32 Release"
# Name "pcsc - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\icc\icc_iso7816.c
# End Source File
# Begin Source File

SOURCE=.\icc\icc_muscle.c
# End Source File
# Begin Source File

SOURCE=.\icc\icc_wd.c
# End Source File
# Begin Source File

SOURCE=.\ifd\ifd_ccid.c
# End Source File
# Begin Source File

SOURCE=.\icc\muscle_fs.c
# End Source File
# Begin Source File

SOURCE=.\pcsc_core.c
# End Source File
# Begin Source File

SOURCE=.\pcsc_handle.c
# End Source File
# Begin Source File

SOURCE=.\pcsc_icc.c
# End Source File
# Begin Source File

SOURCE=.\pcsc_ifd.c
# End Source File
# Begin Source File

SOURCE=.\pcsc_mics.c
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\icc\muscle_fs.h
# End Source File
# Begin Source File

SOURCE=..\..\include\pcsc.h
# End Source File
# Begin Source File

SOURCE=..\..\include\pcsc_defs.h
# End Source File
# Begin Source File

SOURCE=.\pcsc_icc.h
# End Source File
# Begin Source File

SOURCE=.\pcsc_ifd.h
# End Source File
# Begin Source File

SOURCE=..\..\include\pcsc_pinpad.h
# End Source File
# Begin Source File

SOURCE=.\pcsc_priv.h
# End Source File
# End Group
# Begin Source File

SOURCE=.\Kbuild
# End Source File
# Begin Source File

SOURCE=.\Kconfig
# End Source File
# End Target
# End Project
