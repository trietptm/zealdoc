/*
 * *******************************************************************
 * md4.c -- Implementation of MD4 Message Digest Algorithm
 * Updated: 2/16/90 by Ronald L. Rivest
 * (C) 1990 RSA Data Security, Inc.
 * *******************************************************************
 */

#include <stdio.h>
#include <md4.h>

/* Compile-time declarations of MD4 "magic constants". */
#define I0  0x67452301       /* Initial values for MD buffer */
#define I1  0xefcdab89
#define I2  0x98badcfe
#define I3  0x10325476
#define C2  013240474631     /* round 2 constant = sqrt(2) in octal */
#define C3  015666365641     /* round 3 constant = sqrt(3) in octal */
/* C2 and C3 are from Knuth, The Art of Programming, Volume 2
 * (Seminumerical Algorithms), Second Edition (1981), Addison-Wesley.
 * Table 2, page 660.
 */

#define fs1  3               /* round 1 shift amounts */
#define fs2  7
#define fs3 11
#define fs4 19
#define gs1  3               /* round 2 shift amounts */
#define gs2  5
#define gs3  9
#define gs4 13
#define hs1  3               /* round 3 shift amounts */
#define hs2  9
#define hs3 11
#define hs4 15

/* Compile-time macro declarations for MD4.
** Note: The "rot" operator uses the variable "tmp".
** It assumes tmp is declared as unsigned int, so that the >>
** operator will shift in zeros rather than extending the sign bit.
*/
#define f(X,Y,Z)             ((X&Y) | ((~X)&Z))
#define g(X,Y,Z)             ((X&Y) | (X&Z) | (Y&Z))
#define h(X,Y,Z)             (X^Y^Z)
#define rot(X,S)             (tmp=X,(tmp<<S) | (tmp>>(32-S)))
#define ff(A,B,C,D,i,s)      A = rot((A + f(B,C,D) + X[i]),s)
#define gg(A,B,C,D,i,s)      A = rot((A + g(B,C,D) + X[i] + C2),s)
#define hh(A,B,C,D,i,s)      A = rot((A + h(B,C,D) + X[i] + C3),s)

/* md4_print(ctx)
 * Print message digest buffer ctx as 32 hexadecimal digits.
 * Order is from low-order byte of buffer[0] to high-order byte of
 * buffer[3].
 * Each byte is printed with high-order hexadecimal digit first.
 * This is a user-callable routine.
 */
void md4_print(md4_t *ctx)
{
	int i, j;
	for (i = 0; i < 4; i++)
		for (j = 0; j < 32; j = j+8)
			printf("%02x",(ctx->buffer[i]>>j) & 0xFF);
}

/* md4_init(ctx)
 * Initialize message digest buffer ctx.
 * This is a user-callable routine.
 */
void md4_init(md4_t *ctx)
{
	int i;
	ctx->buffer[0] = I0;
	ctx->buffer[1] = I1;
	ctx->buffer[2] = I2;
	ctx->buffer[3] = I3;
	for (i = 0; i < 8; i++) ctx->count[i] = 0;
	ctx->done = 0;
}

/* md4_block(ctx,X)
 * Update message digest buffer ctx->buffer using 16-word data block X.
 * Assumes all 16 words of X are full of data.
 * Does not update ctx->count.
 * This routine is not user-callable.
 */
static void md4_block(md4_t *ctx, const uint8_t *Xb)
{
	register unsigned int tmp, A, B, C, D;
	unsigned int X[16];
	int i;
	
	for (i = 0; i < 16; ++i) {
		X[i] = Xb[0] + (Xb[1] << 8) + (Xb[2] << 16) + (Xb[3] << 24);
		Xb += 4;
	}
	
	A = ctx->buffer[0];
	B = ctx->buffer[1];
	C = ctx->buffer[2];
	D = ctx->buffer[3];
	/* Update the message digest buffer */
	ff(A , B , C , D ,  0 , fs1); /* Round 1 */
	ff(D , A , B , C ,  1 , fs2);
	ff(C , D , A , B ,  2 , fs3);
	ff(B , C , D , A ,  3 , fs4);
	ff(A , B , C , D ,  4 , fs1);
	ff(D , A , B , C ,  5 , fs2);
	ff(C , D , A , B ,  6 , fs3);
	ff(B , C , D , A ,  7 , fs4);
	ff(A , B , C , D ,  8 , fs1);
	ff(D , A , B , C ,  9 , fs2);
	ff(C , D , A , B , 10 , fs3);
	ff(B , C , D , A , 11 , fs4);
	ff(A , B , C , D , 12 , fs1);
	ff(D , A , B , C , 13 , fs2);
	ff(C , D , A , B , 14 , fs3);
	ff(B , C , D , A , 15 , fs4);
	gg(A , B , C , D ,  0 , gs1); /* Round 2 */
	gg(D , A , B , C ,  4 , gs2);
	gg(C , D , A , B ,  8 , gs3);
	gg(B , C , D , A , 12 , gs4);
	gg(A , B , C , D ,  1 , gs1);
	gg(D , A , B , C ,  5 , gs2);
	gg(C , D , A , B ,  9 , gs3);
	gg(B , C , D , A , 13 , gs4);
	gg(A , B , C , D ,  2 , gs1);
	gg(D , A , B , C ,  6 , gs2);
	gg(C , D , A , B , 10 , gs3);
	gg(B , C , D , A , 14 , gs4);
	gg(A , B , C , D ,  3 , gs1);
	gg(D , A , B , C ,  7 , gs2);
	gg(C , D , A , B , 11 , gs3);
	gg(B , C , D , A , 15 , gs4);
	hh(A , B , C , D ,  0 , hs1); /* Round 3 */
	hh(D , A , B , C ,  8 , hs2);
	hh(C , D , A , B ,  4 , hs3);
	hh(B , C , D , A , 12 , hs4);
	hh(A , B , C , D ,  2 , hs1);
	hh(D , A , B , C , 10 , hs2);
	hh(C , D , A , B ,  6 , hs3);
	hh(B , C , D , A , 14 , hs4);
	hh(A , B , C , D ,  1 , hs1);
	hh(D , A , B , C ,  9 , hs2);
	hh(C , D , A , B ,  5 , hs3);
	hh(B , C , D , A , 13 , hs4);
	hh(A , B , C , D ,  3 , hs1);
	hh(D , A , B , C , 11 , hs2);
	hh(C , D , A , B ,  7 , hs3);
	hh(B , C , D , A , 15 , hs4);
	ctx->buffer[0] += A;
	ctx->buffer[1] += B;
	ctx->buffer[2] += C;
	ctx->buffer[3] += D;
}

/* md4_update(ctx,X,count)
 * Input: X -- a pointer to an array of unsigned characters.
 *        count -- the number of bits of X to use.
 *          (if not a multiple of 8, uses high bits of last byte.)
 * Update ctx using the number of bits of X given by count.
 * This is the basic input routine for an MD4 user.
 * The routine completes the MD computation when count < 512, so
 * every MD computation should end with one call to md4_update with a
 * count less than 512.  A call with count 0 will be ignored if the
 * MD has already been terminated (done != 0), so an extra call with
 * count 0 can be given as a "courtesy close" to force termination
 * if desired.
 */
void md4_update(md4_t *ctx, const uint8_t *X, size_t count)
{
	unsigned int i, tmp, bit, byte, mask;
	unsigned char XX[64];
	unsigned char *p;
	
	/* return with no error if this is a courtesy close with count
	 * zero and ctx->done is true.
	 */
	if (count == 0 && ctx->done) return;
	/* check to see if MD is already done and report error */
	if (ctx->done) {
		printf("\nError: md4_update MD already done.");
		return;
	}
	
	/* Add count to ctx->count */
	tmp = count;
	p = ctx->count;
	while (tmp) {
		tmp += *p;
		*p++ = tmp;
		tmp = tmp >> 8;
	}
	
	/* Process data */
	if (count == 512) {
		/* Full block of data to handle */
		md4_block(ctx,X);
	} else if (count > 512) {
		/* Check for count too large */
		printf("\nError: md4_update called with illegal count value %d.",
			count);
		return;
	} else {
		/* partial block -- must be last block so finish up */
		/* Find out how many bytes and residual bits there are */
		byte = count >> 3;
		bit =  count & 7;
		/* Copy X into XX since we need to modify it */
		if (count)
			for (i=0;i<=byte;i++) XX[i] = X[i];
		for (i=byte+1;i<64;i++) XX[i] = 0;
		/* Add padding '1' bit and low-order zeros in last byte */
		mask = 1 << (7 - bit);
		XX[byte] = (XX[byte] | mask) & ~( mask - 1);
		/* If room for bit count, finish up with this block */
		if (byte <= 55) {
			for (i = 0; i < 8; i++) XX[56+i] = ctx->count[i];
			md4_block(ctx,XX);
		} else {
			/* need to do two blocks to finish up */
			md4_block(ctx,XX);
			for (i = 0; i < 56; i++) XX[i] = 0;
			for (i = 0; i < 8; i++)  XX[56+i] = ctx->count[i];
			md4_block(ctx,XX);
		}
		/* Set flag saying we're done with MD computation */
		ctx->done = 1;
	}
}

/* finish up MD4 computation and return message digest */
void md4_final(md4_t *ctx, uint8_t *buf)
{
	int i, j;
	unsigned int w;
	
	md4_update(ctx, NULL, 0);
	for (i = 0; i < 4; ++i) {
		w = ctx->buffer[i];
		for (j = 0; j < 4; ++j) {
			*buf++ = w;
			w >>= 8;
		}
	}
}
