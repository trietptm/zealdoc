# Microsoft Developer Studio Project File - Name="crypto" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Static Library" 0x0104

CFG=crypto - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "crypto.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "crypto.mak" CFG="crypto - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "crypto - Win32 Release" (based on "Win32 (x86) Static Library")
!MESSAGE "crypto - Win32 Debug" (based on "Win32 (x86) Static Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "crypto - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "..\bin\release"
# PROP BASE Intermediate_Dir "..\obj\release\crypto"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "..\bin\release"
# PROP Intermediate_Dir "..\obj\release\crypto"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_MBCS" /D "_LIB" /YX /FD /c
# ADD CPP /nologo /MT /W3 /GX /O2 /I "../include" /I "../lib/missing" /D "NDEBUG" /D "WIN32" /D HAVE_AUTOCONF_H=1 /D REGEX_MALLOC=1 /FD /c
# SUBTRACT CPP /YX /Yc /Yu
# ADD BASE RSC /l 0x804 /d "NDEBUG"
# ADD RSC /l 0x804 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo

!ELSEIF  "$(CFG)" == "crypto - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "..\bin\debug"
# PROP BASE Intermediate_Dir "..\obj\debug\crypto"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "..\bin\debug"
# PROP Intermediate_Dir "..\obj\debug\crypto"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_MBCS" /D "_LIB" /YX /FD /GZ /c
# ADD CPP /nologo /MTd /W3 /Gm /GX /ZI /Od /I "../include" /I "../lib/missing" /D "_DEBUG" /D "GETPID_IS_MEANINGLESS" /D "WIN32" /D HAVE_AUTOCONF_H=1 /D REGEX_MALLOC=1 /FD /GZ /c
# SUBTRACT CPP /YX /Yc /Yu
# ADD BASE RSC /l 0x804 /d "_DEBUG"
# ADD RSC /l 0x804 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo

!ENDIF 

# Begin Target

# Name "crypto - Win32 Release"
# Name "crypto - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\base64.c
# End Source File
# Begin Source File

SOURCE=.\crypt.c
# End Source File
# Begin Source File

SOURCE=.\crypto_api.c
# End Source File
# Begin Source File

SOURCE=.\crypto_cipher.c
# End Source File
# Begin Source File

SOURCE=.\crypto_comp.c
# End Source File
# Begin Source File

SOURCE=.\crypto_core.c
# End Source File
# Begin Source File

SOURCE=.\crypto_digest.c
# End Source File
# Begin Source File

SOURCE=.\crypto_eay.c
# End Source File
# Begin Source File

SOURCE=.\dh.c
# End Source File
# Begin Source File

SOURCE=.\dsa.c
# End Source File
# Begin Source File

SOURCE=.\fnv.c
# End Source File
# Begin Source File

SOURCE=.\hmac.c
# End Source File
# Begin Source File

SOURCE=.\isaac.c
# End Source File
# Begin Source File

SOURCE=.\md4.c
# End Source File
# Begin Source File

SOURCE=.\md5.c
# End Source File
# Begin Source File

SOURCE=.\mpi.c
# End Source File
# Begin Source File

SOURCE=.\rand.c
# End Source File
# Begin Source File

SOURCE=.\rc4.c
# End Source File
# Begin Source File

SOURCE=.\rsa.c
# End Source File
# Begin Source File

SOURCE=.\sha1.c
# End Source File
# Begin Source File

SOURCE=.\sha2.c
# End Source File
# Begin Source File

SOURCE=.\uuid.c
# End Source File
# Begin Source File

SOURCE=.\vchar.c
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=..\include\base64.h
# End Source File
# Begin Source File

SOURCE=..\include\crypto.h
# End Source File
# Begin Source File

SOURCE=..\include\openssl\crypto.h
# End Source File
# Begin Source File

SOURCE=..\include\crypto_eay.h
# End Source File
# Begin Source File

SOURCE=.\crypto_priv.h
# End Source File
# Begin Source File

SOURCE=..\include\dsa.h
# End Source File
# Begin Source File

SOURCE=..\include\fnv.h
# End Source File
# Begin Source File

SOURCE=..\include\hmac.h
# End Source File
# Begin Source File

SOURCE=..\include\isaac.h
# End Source File
# Begin Source File

SOURCE=..\include\md4.h
# End Source File
# Begin Source File

SOURCE=..\include\md5.h
# End Source File
# Begin Source File

SOURCE=..\include\mpi.h
# End Source File
# Begin Source File

SOURCE=..\include\rsa.h
# End Source File
# Begin Source File

SOURCE=..\include\sha1.h
# End Source File
# Begin Source File

SOURCE=..\include\sha2.h
# End Source File
# Begin Source File

SOURCE=..\include\uuid.h
# End Source File
# End Group
# Begin Source File

SOURCE=.\Kbuild
# End Source File
# End Target
# End Project
