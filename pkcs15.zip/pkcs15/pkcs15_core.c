#include "pkcs15_priv.h"

#define PKCS15_SERVICE_DESC	"Public-key cryptography standards 15"

int pkcs15_logger = 0;
log_source_t pkcs15_log_source = {
	"pkcs15"
};

void pkcs15_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(pkcs15_logger, level, format, ap);
	va_end(ap);
}

static int __init pkcs15_log_init(void)
{
	pkcs15_logger = log_register_source(&pkcs15_log_source);
	return !pkcs15_logger;
}

static void __exit pkcs15_log_exit(void)
{
	log_unregister_source(pkcs15_logger);
}

ui_argument_t pkcs15_reader_args = {
	"idex",
	"reader index",
	NULL,
	UI_TYPE_INT,
};

ui_command_t pkcs15_connect_cmd = {
	"connect",
	"connect card",
	".pkcs15",
	UI_CMD_SINGLE_INST,
	&pkcs15_reader_args,
	1,
	LIST_HEAD_INIT(pkcs15_connect_cmd.link),
	pkcs15_tool_connect,
};

ui_command_t pkcs15_disconnect_cmd = {
	"disconnect",
	"disconnect card",
	".pkcs15",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(pkcs15_disconnect_cmd.link),
	pkcs15_tool_disconnect,
};

ui_command_t pkcs15_bind_cmd = {
	"bind",
	"bind card",
	".pkcs15",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(pkcs15_bind_cmd.link),
	pkcs15_tool_bind,
};

ui_command_t pkcs15_unbind_cmd = {
	"unbind",
	"unbind card",
	".pkcs15",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(pkcs15_bind_cmd.link),
	pkcs15_tool_unbind,
};

ui_schema_t pkcs15_schema[] = {
	{ UI_TYPE_CLASS, 
	  UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, 
	  NULL, 
	  NULL,
	  ".pkcs15", 
	  "pkcs15", 
	  PKCS15_SERVICE_DESC},
	
	{ UI_TYPE_NONE },
};

static int __init pkcs15_cmd_init(void)
{
	ui_register_schema(pkcs15_schema);
	ui_register_command(&pkcs15_connect_cmd);
	ui_register_command(&pkcs15_disconnect_cmd);

	ui_register_command(&pkcs15_bind_cmd);
	ui_register_command(&pkcs15_unbind_cmd);	

	return 0;
}
	
static void __exit pkcs15_cmd_exit(void)
{
	ui_unregister_command(&pkcs15_unbind_cmd);	
	ui_unregister_command(&pkcs15_bind_cmd);
	ui_unregister_command(&pkcs15_disconnect_cmd);
	ui_unregister_command(&pkcs15_connect_cmd);
	ui_unregister_schema(pkcs15_schema);
}

modlinkage int __init pkcs15_init(void)
{
	pkcs15_log_init();
	pkcs15_cmd_init();

	return 0;
}

modlinkage void __exit pkcs15_exit(void)
{
	pkcs15_cmd_exit();
	pkcs15_log_exit();
}

subsys_initcall(pkcs15_init);
subsys_exitcall(pkcs15_exit);
