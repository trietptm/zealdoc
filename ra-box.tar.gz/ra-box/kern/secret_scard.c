#include <secret.h>
#include <strutl.h>
#include <pkcs15.h>
#ifdef WIN32
#include <conio.h>
#endif
#include "secret_priv.h"

/* TLV format in the card
	+---+---+---+---+---+---+--------+---+---+-----+----+---+-------+---+---+--------+-----------
	|'S'| L1|id | L2|'D'| L | Domain |'U'| L |User |'F' | L | Format|'P'| L |Password| ... ...
	+---+---+---+---+---+---+--------+---+---+-----+----+---+-------+---+---+--------+-----------
		|	|<----------------------------L2-------------------------------->|
		|<----------------------------------L1(one entry)----------------------->|<---other entries---
 */
/*
 * path: 3f00 3f01 0008(ef record)
 * Now short for testing
	+---+---+---+---+---+---+--------+---+---+-----+----+--------
	|'S'| L1|id | L2|'U'| L |User |'P'| L |Password| ... ...
	+---+---+---+---+---+---+--------+---+---+-----+----+--------
		|	|<---------L2----------------->|
		|<--------------L1(one entry)--------->|<---other entries---
 * */
/* vpn - 0x76 0x70 0x6E */
#define SC_PKCS15_DATA_SECRET_TAG	'S'	// 0x53

#define SECRET_DOMAIN_TAG	'D'
#define SECRET_USER_TAG		'U'	// 0x55
#define SECRET_FORMAT_TAG	'F'
#define SECRET_PWD_TAG		'P'	// 0x50

#define SCARD_READER_ID		0
#define SCARD_SLOT_ID		0
#define SC_PKCS15_SECRET_APPOID	"1.1.1"

struct sc_secret_entry {
	uint8_t id;
	uint8_t len;	/*Do not contain id and len*/

	const char *domain;
	const char *user;
	const char *format;
	char secret[MAX_SECRET_LEN];
	int sec_len;
};

typedef struct _scard_trans {
	/* SP who will help me, maybe P15 */
	void *priv;
	void *slot;
	uint16_t idx;
	int type;
#define TRANS_T_SELF	0
#define TRANS_T_PKCS	1

	int card_off;
	int selected;
	int rec_nr;

	struct sc_secret_entry entry;
#define TEMP_MAX_REC_LEN	256
	uint8_t resp[TEMP_MAX_REC_LEN];
	int resplen;

	char *up_secret;
	list_t link;
} scard_trans_t;

DECLARE_LIST(card_trans);

#define for_each_trans(t)			\
	list_for_each_entry(scard_trans_t, t, &card_trans, link)
#define for_each_trans_safe(t, n)			\
	list_for_each_entry_safe(scard_trans_t, t, n, &card_trans, link)

#define DEF_CARD_NAME	"watchdata"

static int __parse_secret(const uint8_t *data, int data_len, 
			  struct sc_secret_entry *record);
static int load_secret_self(scard_trans_t *trans, int type);
static void __card_reset_nr(scard_trans_t *t);

#if 0
static char *getpass(const char *prompt)
{
	static char buf[128];
	size_t i;

	fputs(prompt, stderr);
	fflush(stderr);

	for (i = 0; i < sizeof(buf) - 1; i++) {
		buf[i] = _getch();
		if (buf[i] == '\r')
			break;
	}
	buf[i] = 0;
	fputs("\n", stderr);

	return buf;
}

static uint8_t * get_pin(const char *prompt, sc_pkcs15_object_t *pin_obj)
{
	sc_pkcs15_pin_info_t *pinfo = (sc_pkcs15_pin_info_t *) pin_obj->data;
	char buf[80];
	char *pincode;
	
	sprintf(buf, "%s [%s]: ", prompt, pin_obj->label);
	while (1) {
		pincode = getpass(buf);
		if (strlen(pincode) == 0)
			return NULL;
		if (strlen(pincode) < pinfo->min_length) {
			printf("PIN code too short, try again.\n");
			continue;
		}
		if (strlen(pincode) > pinfo->max_length) {
			printf("PIN code too long, try again.\n");
			continue;
		}
		return (uint8_t *) strdup(pincode);
	}
}

static int authenticate(struct secret_scard_trans *scard_trans,
			sc_pkcs15_object_t *obj)
{
	sc_pkcs15_pin_info_t	*pin_info;
	sc_pkcs15_object_t	*pin_obj;
	uint8_t			*pin;
	int			r;

	if (obj->auth_id.len == 0)
		return 0;
	r = sc_pkcs15_find_pin_by_auth_id(scard_trans->p15card, 
					  &obj->auth_id, &pin_obj);
	if (r)
		return r;

	pin_info = (sc_pkcs15_pin_info_t *) pin_obj->data;
	pin = get_pin("Please enter PIN", pin_obj);

	return sc_pkcs15_verify_pin(scard_trans->p15card, pin_info,
			pin, pin? strlen((char *) pin) : 0);
}
#endif

static int connect_card(struct secret_scard_trans *scard_trans)
{
	pcsc_slot_t *slot;

	slot = pcsc_get_slot_by_icc_name(DEF_CARD_NAME);

	if (!slot)
		return -1;
	/* TODO: find card and lock it? */
	return 0;
}

static void scard_exit(void *trans)
{
	scard_trans_t *scard_trans = (scard_trans_t *)trans;

	if (!scard_trans)
		return;
	if (scard_trans->slot)
		pcsc_slot_lock_put(scard_trans->slot);
	list_delete(&scard_trans->link);
	memset(&scard_trans->entry, 0, sizeof (struct sc_secret_entry));
	memset(scard_trans, 0, sizeof (scard_trans_t));
	free(scard_trans);
}

static void *scard_init(void)
{
	scard_trans_t *trans;
	uint16_t *idx;
	const char *type;

	trans = malloc(sizeof (scard_trans_t));
	if (!trans)
		return NULL;

	memset(trans, 0, sizeof (scard_trans_t));
	list_init(&trans->link);
	list_insert_before(&trans->link, &card_trans);

	idx = (uint16_t *)secret_read_profile(SECRET_SOURCE_CARD,
					      SECRET_PROF_SLOT);

	type = (const char *)secret_read_profile(SECRET_SOURCE_CARD,
					         SECRET_PROF_TYPE);
	if (!type)
		goto fail;

	if (strcasecmp(type, "pkcs15") == 0)
		trans->type = TRANS_T_PKCS;
	else
		trans->type = TRANS_T_SELF;

	/* from 1~N */
	__card_reset_nr(trans);
	trans->idx = *idx;
	trans->slot = pcsc_slot_lock_get_by_idx(*idx);
	if (!trans->slot)
		goto fail;

	return trans;
fail:
	scard_exit(trans);
	return NULL;
}

static int decode_secret_entry(const uint8_t *entry, size_t len, 
			       struct sc_secret_entry *record)
{
	uint8_t T, L;
	const uint8_t *V, *p = entry;
	secret_t sec;

	memset(record, 0, sizeof(*record));

	record->id = *p++;
	record->len = *p++;

	if ((unsigned int)(record->len + 2) < len)
		return -1;
	memset(&sec, 0, sizeof(sec));
	while ((size_t)(p - entry) < record->len) {
		T = *p++;
		L = *p++;
		V = p;
		switch (T) {
		case SECRET_DOMAIN_TAG:
			record->domain = V;
			break;
		case SECRET_USER_TAG:
			record->user = V;
			break;
		case SECRET_FORMAT_TAG:
			record->format = V;
			break;
		case SECRET_PWD_TAG:
			strncpy(record->secret, V, L);
			record->sec_len = L;
			break;
		default:
			return -1;
		}
		p += L;
	}

	return 0;
}

static int encode_secret_entry(struct sc_secret_entry *record,
			       uint8_t *entry, size_t *len)
{
	uint8_t *p = entry;
	size_t L;

	*p++ = record->id;
	*p++ = record->len;
	
	*p++ = SECRET_USER_TAG;
	L = strlen (record->user);
	*p++ = (uint8_t)L + 1;
	memcpy(p, record->user, L);
	p += L;
	*p++ = '\0';

	*p++ = SECRET_PWD_TAG;
	L = strlen (record->secret);
	*p++ = (uint8_t) L + 1;
	memcpy(p, record->secret, L);
	p += L;
	*p++ = '\0';
	
	/*Reset the entry(id)'s length*/
	entry[1] = (uint8_t)(p - entry - 2);

	*len = p - entry;

	return 0;
}

static int __parse_secret(const uint8_t *data, int data_len, 
			  struct sc_secret_entry *record)
{
	int r;
	const uint8_t *p = data;
	size_t plen = data_len;
	struct sc_secret_entry rcd;

	if (*p != SC_PKCS15_DATA_SECRET_TAG)
		return -1;
	/* skip 'S' and ID */
	p += 2;
	plen -= 2;

	while(plen > 0) {
		memset(&rcd, 0, sizeof(rcd));
		r= decode_secret_entry(p, plen, &rcd);
		if (r != 0)
			return r;
#if 1
		if (!strncmp(record->user, rcd.user, strlen(record->user))) {
			strncpy(record->secret, rcd.secret, rcd.sec_len);
			record->sec_len = rcd.sec_len;
			return 0;
		}
#endif
#if 0
		if (!strcmp(record->domain, rcd.domain) 
			&& !strcmp(record->user, rcd.user)
			&& !strcmp(record->format, rcd.format)) {
			strncpy(record->secret, rcd.secret, rcd.sec_len);
			record->sec_len = rcd.sec_len;
			return 0;
		}
#endif
		p += rcd.len + 2;
		plen -= rcd.len + 2;
	}
	
	return -1;
}

static int __self_load_s2(scard_trans_t *trans)
{
	int ret;
	
	ret = __parse_secret(trans->resp, trans->resplen,
			     &trans->entry);
	if (ret == 0) {
		strncpy(trans->up_secret, 
			trans->entry.secret, trans->entry.sec_len);
		trans->up_secret[trans->entry.sec_len] = '\0';
		
	}
	return ret;
}

static void __self_load_s1(void *user, int ret)
{
	scard_trans_t *trans = (scard_trans_t *)user;

	if (ret >= 0) {
		if (0 == trans->selected) {
			log_kern(LOG_DEBUG, "CARD: select file succ");
			trans->selected = 1;
			load_secret_self(trans, 0);
		} else {
			log_kern(LOG_DEBUG, "CARD: read record succ, len=%d", ret);
			if (ret == 0) {
				/* since we read record from 1, when arrived EOF 
				 * it will return 0
				 */
				goto out;
			}

			BUG_ON(ret > TEMP_MAX_REC_LEN);
			/* real record length */
			trans->resplen = ret;
			if (__self_load_s2(trans) == 0)
				secret_source_success(trans);
			else
				/* next record */
				load_secret_self(trans, 0);
			return;
		}
	}
out:
	secret_source_failure(trans);
}

static void __card_reset_nr(scard_trans_t *t)
{
	t->rec_nr = 1;
}

/* do two things:
 * 1) select file if not selected,
 * 2) read record if selected file
 * the callback will parse record, if match or not raise new event
 *
 * @type: whether reset rec_nr(read from head of file)
 */
static int load_secret_self(scard_trans_t *trans, int type)
{
	int ret = 0;

	if (trans->selected == 0) {
		const char *path;
		struct icc_path ef_path;

		path = secret_read_profile(SECRET_SOURCE_CARD, SECRET_PROF_PATH);
		if (!path)
			return -1;
		icc_format_path(path, &ef_path);
		
		ret = pcsc_select_file(trans->slot, &ef_path, NULL,
				       __self_load_s1, trans);
	} else {
		if (type == 1)
			__card_reset_nr(trans);
		ret = pcsc_read_record(trans->slot, trans->rec_nr++,
				       trans->resp, TEMP_MAX_REC_LEN, ICC_RECORD_BY_REC_NR, 
				       __self_load_s1, trans);
		/* only when internal(type=1) error need raise failure event */
		if (ret != 0 && type != 1)
			secret_source_failure(trans);
	}
	return ret;
}

static int scard_start_search(void *data, 
			      const char *domain, const char *user,
			      const char *format, char *secret)
{
	scard_trans_t *trans = (scard_trans_t *)data;
	struct sc_secret_entry *entry = &trans->entry;
	int r = -1;

	/* whether get card off event before */
	if (!trans || trans->card_off) {
		secret_source_failure(trans);
		return -1;
	}

	entry->domain = domain;
	entry->user = user;
	entry->format = format;

	trans->up_secret = secret;

	if (trans->type == TRANS_T_SELF)
		r = load_secret_self(trans, 1);
	else {
		/* TODO: use pkcs15 API */
	}
	if (r != 0)
		goto fail;
	return r;	
fail:
	secret_source_failure(trans);
	return r;
}

static int delete_record(uint8_t *data, size_t *data_len, 
			 struct sc_secret_entry *record)
{
	int r;
	uint8_t *p = data;
	size_t plen = *data_len;
	struct sc_secret_entry rcd;

	if (*p++ != SC_PKCS15_DATA_SECRET_TAG)
		return -1;
	*p++;
	plen -= 2;

	while(plen > 0) {
		memset(&rcd, 0, sizeof(rcd));
		r= decode_secret_entry(p, plen, &rcd);
		if (r != 0)
			return r;
		if (!strcmp(record->domain, rcd.domain) 
			&& !strcmp(record->user, rcd.user)
			&& !strcmp(record->format, rcd.format)) {
			p = memmove(p, p + rcd.len + 2, plen - rcd.len - 2);
			if (p == NULL)
				return -1;
			else {
				*data_len -= rcd.len - 2;
				return 0;
			}
		}
		p += rcd.len + 2;
		plen -= rcd.len + 2;
	}
	
	return -1;	
}


static int scard_start_delete(void *trans,
			      const char *domain, const char *user,
			      const char *format)
{
	struct secret_scard_trans *scard_trans = (struct secret_scard_trans *)trans;
	int r;
	uint8_t *buf = NULL;
	size_t buf_len;
	struct sc_secret_entry record;

	if (!scard_trans) {
		secret_source_failure(scard_trans);
		return -1;
	}
	/* FIXME: */
//	r = load_secret_self(scard_trans, SC_PKCS15_SECRET_APPOID, &buf, &buf_len);
	if (r != 0)
		goto out;

	memset(&record, 0, sizeof(record));
	record.domain = domain;
	record.user = user;
	record.format = format;
	/*TODO: delete record and update to scard*/
	r = delete_record(buf, &buf_len, &record);
	if (r != 0)
		goto out;
	
out:
	if (r != 0)
		secret_source_failure(scard_trans);
	else
		secret_source_success(scard_trans);
	if (buf)
		free(buf);
	buf = NULL;

	return r;	
}

static void __card_off(void *data)
{
	scard_trans_t *trans, *node;
	
	/* FIXME: not all trans need to close */
	for_each_trans_safe(trans, node) {
		if (trans->slot == data) {
			trans->card_off = 1;
			trans->selected = 0;	/* need reselect */
			pcsc_slot_lock_put(trans->slot);
			trans->slot = NULL;
			secret_source_failure(trans);
		}
	}
}

static int card_event(notify_t *nb,
		      unsigned long event, void *data)
{
	switch(event) {
	case PCSC_ICC_REMOVE:
		__card_off(data);
		break;
	default:
		break;
	}
	return 0;
}

static notify_t secret_card_notify = {
	NULL,
	card_event,
	9,
};

secret_source_t secret_scard = {
	SECRET_SOURCE_CARD,
	scard_init,
	scard_exit,
	scard_start_search,
	NULL, /* scard_start_delete, */
	NULL, /*secret_scard_start_update, */
};

modlinkage int __init secret_scard_init(void)
{
	pcsc_register_notify(&secret_card_notify);

	return secret_register_source(&secret_scard);
}

modlinkage void __exit secret_scard_exit(void)
{
	secret_unregister_source(&secret_scard);
}

module_init(secret_scard_init);
module_exit(secret_scard_exit);
