#if 0
#include <sysdep.h>
#include <eloop.h>
#include <setjmp.h>

typedef struct _eloop_wait_t {
	int event_sec;
	int event_usec;
	eloop_complete_cb event_comp;
	void *event_data;
	jmp_buf event_ctx;
	int started;
	int complete;
	eloop_t *eloop;
	list_t link;
} eloop_wait_t;

static void eloop_wait_event_timeout(void *edata, eloop_wait_t *wdata);
static void eloop_wait_event_complete(void *edata, eloop_wait_t *wdata);

extern eloop_t *eloop_main;
DECLARE_LIST(eloop_waiters);
eloop_wait_t *current_wait = NULL;

static void eloop_wait_event_complete(void *edata, eloop_wait_t *wdata)
{
	if (!wdata->event_comp(edata, wdata->event_data)) {
		eloop_register_timeout(wdata->eloop,
				       wdata->event_sec,
				       wdata->event_usec,
				       eloop_wait_event_complete,
				       edata, wdata);
		wdata->complete = 0;
	} else {
		eloop_cancel_timeout(wdata->eloop,
				     eloop_wait_event_timeout,
				     edata, wdata);
		wdata->complete = 1;
		current_wait = wdata;
		longjmp(wdata->event_ctx, 1);
	}
}

static void eloop_wait_event_timeout(void *edata, eloop_wait_t *wdata)
{
	eloop_cancel_timeout(wdata->eloop, eloop_wait_event_complete,
			     edata, wdata);
	wdata->complete = 0;
	current_wait = wdata;
	longjmp(wdata->event_ctx, 1);
}

int eloop_register_waiter(eloop_t *eloop,
			  unsigned long event_sec,
			  unsigned long event_usec,
			  unsigned long tout_sec,
			  unsigned long tout_usec,
			  eloop_complete_cb comp_cb, void *data)
{
	eloop_wait_t *wdata;
	int __state__;

	if (!eloop)
		eloop = eloop_main;

	wdata = malloc(sizeof (eloop_wait_t));
	if (!wdata) return -1;
	wdata->event_data = data;
	wdata->event_sec = event_sec;
	wdata->event_usec = event_usec;
	wdata->event_comp = comp_cb;
	wdata->eloop = eloop;

	if ((__state__ = setjmp(wdata->event_ctx)) == 0) {
		eloop_register_timeout(eloop, 0, 0,
				       eloop_wait_event_complete,
				       NULL, wdata);
		eloop_register_timeout(eloop, tout_sec, event_usec,
				       eloop_wait_event_timeout,
				       NULL, wdata);

		list_init(&wdata->link);
		list_insert_before(&wdata->link, &eloop_waiters);
		eloop_schedule(eloop);
		return 0;
	} else {
		int comp;

		wdata = current_wait;
		current_wait = NULL;
		comp = wdata->complete;
		list_delete(&wdata->link);
		free(wdata);
		return comp ? 0 : -1;
	}
}

eloop_wait_t *eloop_find_waiter(eloop_t *eloop,
				eloop_complete_cb comp_cb, void *data)
{
	eloop_wait_t *wdata;
	list_t *pos, *n;

	if (!eloop)
		eloop = eloop_main;
	list_iterate_forward(pos, n, &eloop_waiters) {
		wdata = list_entry(pos, eloop_wait_t, link);
		if (wdata->eloop == eloop &&
		    wdata->event_data == data &&
		    wdata->event_comp == comp_cb)
			return wdata;
	}
	return NULL;
}

void eloop_unregister_waiter(eloop_t *eloop,
			     eloop_complete_cb comp_cb, void *data)
{
	eloop_wait_t *wdata;

	wdata = eloop_find_waiter(eloop, comp_cb, data);
	if (wdata) {
		list_delete(&wdata->link);
		eloop_cancel_timeout(wdata->eloop, eloop_wait_event_complete,
				     NULL, wdata);
		eloop_cancel_timeout(wdata->eloop, eloop_wait_event_timeout,
				     NULL, wdata);
		wdata->complete = 0;
		current_wait = wdata;
		longjmp(wdata->event_ctx, 1);
	}
}
#endif
