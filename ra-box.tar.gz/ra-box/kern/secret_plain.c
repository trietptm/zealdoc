#include <secret.h>
#include "secret_priv.h"

#define SECRET_PLAIN_MAXLEN	20

secret_format_t secret_plain = {
	SECRET_FORMAT_PLAIN,
	"Secret Plain Format",
	SECRET_FORMAT_PRINT,
	/* plain need not parse */
};

modlinkage int __init secret_plain_init(void)
{
	secret_register_format(&secret_plain);
	return 0;
}

modlinkage void __exit secret_plain_exit(void)
{
	secret_unregister_format(&secret_plain);
}

module_init(secret_plain_init);
module_exit(secret_plain_exit);
