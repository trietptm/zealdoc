#ifndef __PCAP_SCANNER_H_INCLUDE__
#define __PCAP_SCANNER_H_INCLUDE__

int pcap_get_lineno(void);
FILE *pcap_get_in(void);
FILE *pcap_get_out(void);
int pcap_get_leng(void);
char *pcap_get_text(void);
void pcap_set_lineno(int line_number);
void pcap_set_in(FILE *in_str);
void pcap_set_out(FILE *out_str);
int pcap_get_debug(void);
void pcap_set_debug(int bdebug);
int pcap_lex_destroy(void);
void pcap_lex_unput(int c);

#endif

