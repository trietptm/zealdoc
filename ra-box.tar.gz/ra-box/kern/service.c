#include <service.h>
#include <module.h>
#include <logger.h>
#include <strutl.h>
#include <cli_api.h>

#define SERVICE_ALL_MODULE	"all"

typedef enum _service_status_t {
	UNREGISTERED = 1,
	STARTED,
	STARTING,
	START_FAILED,
	STOPPING,
	STOPPED,
	STOP_FAILED
} service_status_t;

string_map_t service_status[] = {
	{ "unregistered", UNREGISTERED, NULL, },
	{ "started", STARTED, NULL, },
	{ "starting", STARTING, NULL, },
	{ "start failed", START_FAILED, NULL, },
	{ "stopping", STOPPING, NULL, },
	{ "stopped", STOPPED, NULL, },
	{ "stop failed", STOP_FAILED, NULL, },
	{ NULL, 0, NULL },
};

typedef struct _service_ctrl_t {
	const char *name;
	list_t link;
	list_t depend_on;
	list_t depend_by;
	service_t *service;
	service_status_t status;
	atomic_t ref;
} service_ctrl_t;

typedef struct _service_node_t {
	service_ctrl_t *depend_on;
	service_ctrl_t *depend_by;
	list_t link_depend_on;
	list_t link_depend_by;
} service_node_t;

DECLARE_LIST(service_ctrls);

#define for_each_service_ctrl(d)	\
	list_for_each_entry(service_ctrl_t, d, &service_ctrls, link)

service_t service_all = {
	SERVICE_ALL_MODULE,
	"All module services",
};

service_ctrl_t service_all_module = {
	SERVICE_ALL_MODULE,
	LIST_HEAD_INIT(service_all_module.link),
	LIST_HEAD_INIT(service_all_module.depend_on),
	LIST_HEAD_INIT(service_all_module.depend_by),
	&service_all,
};

service_t unregistered_svc = {
	NULL,
	NULL,
	SERVICE_UP_NEVER,
	SERVICE_FLAG_SYSTEM,
	LIST_HEAD_INIT(unregistered_svc.depends),
	NULL,
	NULL
};

#define IS_VALID_SERVICE(svc)		\
	((svc)->name && *((svc)->name) && (svc)->start && (svc)->stop)

static const char *service_status2name(int status)
{
	return int2name(service_status, status, "unknown");
}

static service_node_t *service_node_new(service_ctrl_t *depend_on,
					service_ctrl_t *depend_by)
{
	service_node_t *node = NULL;

	node = (service_node_t *)malloc(sizeof(service_node_t));
	list_init(&node->link_depend_on);
	list_init(&node->link_depend_by);
	node->depend_on = depend_on;
	node->depend_by = depend_by;
	return node;
}

static service_ctrl_t *find_service_ctrl(const char *name)
{
	service_ctrl_t *ctrl = NULL;

	if (!name)
		return NULL;

	for_each_service_ctrl(ctrl) {
		if (strcasecmp(ctrl->name, name) == 0)
			return ctrl;
	}
	return NULL;
}

static service_ctrl_t *service_new(service_t *svc, const char *name)
{
	service_ctrl_t *ctrl = NULL;

	ctrl = find_service_ctrl(name);
	if (ctrl) {
		if (ctrl->status == UNREGISTERED && IS_VALID_SERVICE(svc)) {
			ctrl->service = svc;
			ctrl->status = STOPPED;
		}
		return ctrl;
	}

	ctrl = (service_ctrl_t *)malloc(sizeof(service_ctrl_t));
	if (ctrl) {
		memset(ctrl, 0, sizeof(service_ctrl_t));
		ctrl->service = svc;
		ctrl->name = name;
		atomic_set(&ctrl->ref, 0);
		list_init(&ctrl->link);
		list_init(&ctrl->depend_on);
		list_init(&ctrl->depend_by);
		list_insert_before(&ctrl->link, &service_ctrls);
		if (IS_VALID_SERVICE(svc))
			ctrl->status = STOPPED;
		else
			ctrl->status = UNREGISTERED;
	}
	return ctrl;
}

static void service_del(service_ctrl_t *ctrl)
{
	list_t *pos = NULL, *n = NULL;
	service_node_t *node = NULL;

	assert(ctrl->status == UNREGISTERED);
	list_iterate_forward(pos, n, &ctrl->depend_by) {
		node = list_entry(pos, service_node_t, link_depend_by);
		/* unregistered service added by service module */
		if (node->depend_on->status == UNREGISTERED) {
			atomic_dec(&node->depend_by->ref);
			atomic_dec(&node->depend_on->ref);
			list_delete(&node->link_depend_on);
			list_delete(&node->link_depend_by);
			if (atomic_read(&node->depend_on->ref) == 0) {
				list_delete_init(&node->depend_on->link);
				free(node->depend_on);
			}
			free(node);
		}
	}
	list_iterate_forward(pos, n, &ctrl->depend_on) {
		node = list_entry(pos, service_node_t, link_depend_on);
		atomic_dec(&node->depend_by->ref);
		atomic_dec(&node->depend_on->ref);
		list_delete(&node->link_depend_on);
		list_delete(&node->link_depend_by);
		if (node->depend_by->status == UNREGISTERED)
			service_del(node->depend_by);
		free(node);
	}
	if (atomic_read(&ctrl->ref) == 0) {
		list_delete_init(&ctrl->link);
		free(ctrl);
	} else {
		ctrl->service = &unregistered_svc;
	}
}

static void service_dependency(service_ctrl_t *ctrl,
			       const char *depend)
{
	service_ctrl_t *dep;

	/* service should never have been started once */
	assert(ctrl && ctrl->status == UNREGISTERED || ctrl->status == STOPPED);

	dep = service_new(&unregistered_svc, depend);
	if (dep) {
		service_node_t *node = service_node_new(ctrl, dep);
		list_insert_before(&node->link_depend_on, &ctrl->depend_on);
		list_insert_before(&node->link_depend_by, &dep->depend_by);
		atomic_inc(&dep->ref);
		atomic_inc(&ctrl->ref);
	}
}

handle_t register_service(service_t *svc)
{
	service_ctrl_t *ctrl = NULL;

	if (svc && svc->name && *svc->name) {
		ctrl = service_new(svc, svc->name);
		if (!ctrl) return NULL;
	}
	return (handle_t *)ctrl;
}

void unregister_service(handle_t hdl)
{
	service_ctrl_t *ctrl = (service_ctrl_t *)hdl;

	BUG_ON(ctrl->status != STOPPED);

	if (ctrl) {
		ctrl->status = UNREGISTERED;
		service_del(ctrl);
	}
}

static int __service_start(service_ctrl_t *ctrl)
{
	service_node_t *node = NULL;
	list_t *n = NULL, *pos = NULL;

	assert(ctrl && ctrl->name && *ctrl->name);
	if (ctrl->status == STARTED) return 0;
	if (ctrl->status != STOPPED) {
		log_kern(LOG_ERR, "SERV: starting service failure, serv=%s",
			 ctrl->name);
		return 1;
	}
	ctrl->status = STARTING;
	list_iterate_forward(pos, n, &ctrl->depend_on) {
		node = list_entry(pos, service_node_t, link_depend_on);
		if (__service_start(node->depend_by) != 0) {
			ctrl->status = START_FAILED;
			log_kern(LOG_ERR,
				 "SERV: starting service failure, serv=%s",
				 ctrl->name);
			return 1;
		}
	}

	if ((*ctrl->service->start)() != 0) {
		ctrl->status = START_FAILED;
		log_kern(LOG_ERR,
			 "SERV: starting service failure, serv=%s",
			 ctrl->name);
		return 1;
	}
	ctrl->status = STARTED;
	log_kern(LOG_INFO, "SERV: starting service success, serv=%s",
		 ctrl->name);
	return 0;
}

static int __service_stop(service_ctrl_t *ctrl)
{
	service_node_t *node = NULL;
	list_t *n = NULL, *pos = NULL;
	
	assert(ctrl && ctrl->name && *ctrl->name);
	if (ctrl->status == STOPPED || ctrl->status == UNREGISTERED) return 0;
	if (ctrl->status != STARTED) {
		log_kern(LOG_ERR, "SERV: stopping service failure, serv=%s",
			 ctrl->name);
		return 1;
	}
	ctrl->status = STOPPING;
	list_iterate_forward(pos, n, &ctrl->depend_by) {
		node = list_entry(pos, service_node_t, link_depend_by);
		if (__service_stop(node->depend_on) != 0) {
			ctrl->status = STOP_FAILED;
			log_kern(LOG_ERR,
				 "SERV: stopping service failure, serv=%s",
				 ctrl->name);
			return 1;
		}
	}

	(*ctrl->service->stop)();
	ctrl->status = STOPPED;
	log_kern(LOG_INFO, "SERV: stopping service success, serv=%s",
		 ctrl->name);
	return 0;
}

int service_start(const char *name)
{
	return __service_start(find_service_ctrl(name));
}

int service_stop(const char *name)
{
	return __service_stop(find_service_ctrl(name));
}

int service_register_depend(const char *svc, const char *dep)
{
	service_ctrl_t *ctrl = NULL;

	assert(svc && dep && *dep);

	ctrl = find_service_ctrl(svc);
	if (!ctrl)
		ctrl = service_new(&unregistered_svc, svc);
	if (ctrl) {
		service_dependency(ctrl, dep);
	} else {
		log_kern(LOG_ERR,
			 "SERV: failed to register service, svc=%s",
			 svc);
		return -1;
	}
	return 0;
}

void services_start(void)
{
	service_ctrl_t *ctrl;
	ui_entry_t *cp = NULL;
	ui_entry_t *cs;

	cs = ui_inst_lookup_conf(NULL, "service", NULL);
	if (!cs) {
		log_kern(LOG_ERR, "SERV: cannot load instance, oid=service");
		return;
	}

	while ((cp = ui_mvalue_iterate_conf(cs,
					    "always_up", cp)) != NULL) {
		ctrl = find_service_ctrl(ui_get_conf_value(cp));
		if (ctrl->service->flags & SERVICE_FLAG_MODULE) {
			ctrl->service->up_timing = SERVICE_UP_ALWAYS;
		}
	}
	for_each_service_ctrl(ctrl) {
		if (ctrl->service->up_timing == SERVICE_UP_ALWAYS)
			__service_start(ctrl);
	}
}

void services_stop(void)
{
	service_ctrl_t *ctrl;

	for_each_service_ctrl(ctrl) {
		__service_stop(ctrl);
	}
}

static int service_start_module(void)
{
	int res = 0, tres;
	service_ctrl_t *ctrl;

	for_each_service_ctrl(ctrl) {
		if (ctrl->service->flags & SERVICE_FLAG_MODULE) {
			tres = __service_start(ctrl);
			if (tres && !res)
				res = tres;
		}
	}
	return res;
}

static int service_stop_module(void)
{
	int res = 0, tres;
	service_ctrl_t *ctrl;

	for_each_service_ctrl(ctrl) {
		if (ctrl->service->flags & SERVICE_FLAG_MODULE){
			tres = __service_stop(ctrl);
			if (tres && !res)
				res = tres;
		}
	}
	return res;
}

static void service_started_foreach(ui_choice_t *choice,
				    ui_iterate_fn func, void *data)
{
	service_ctrl_t *ctrl;

	for_each_service_ctrl(ctrl) {
		if (ctrl->service->flags & SERVICE_FLAG_MODULE) {
			if (ctrl->status == STARTED)
				func(choice, ctrl, data);
		}
	}
	func(choice, &service_all_module, data);
}

static void service_stopped_foreach(ui_choice_t *choice,
				    ui_iterate_fn func, void *data)
{
	service_ctrl_t *ctrl;

	for_each_service_ctrl(ctrl) {
		if (ctrl->service->flags & SERVICE_FLAG_MODULE) {
			if (ctrl->status == STOPPED)
				func(choice, ctrl, data);
		}
	}
	func(choice, &service_all_module, data);
}

static void service_module_foreach(ui_choice_t *choice,
				   ui_iterate_fn func, void *data)
{
	service_ctrl_t *ctrl;

	for_each_service_ctrl(ctrl) {
		if (ctrl->service->flags & SERVICE_FLAG_MODULE) {
			func(choice, ctrl, data);
		}
	}
}

static const char *service_ctrl_name(const void *iter)
{
	const service_ctrl_t *ctrl = (const service_ctrl_t *)iter;
	return ctrl->service->name;
}

static const char *service_ctrl_desc(const void *iter)
{
	const service_ctrl_t *ctrl = (const service_ctrl_t *)iter;
	return ctrl->service->desc;
}

ui_choice_t service_module_choice = {
	"module_service",
	NULL,
	service_module_foreach,
	service_ctrl_name,
	service_ctrl_desc,
};

ui_choice_t service_started_choice = {
	"started_service",
	NULL,
	service_started_foreach,
	service_ctrl_name,
	service_ctrl_desc,
};

ui_choice_t service_stopped_choice = {
	"stopped_service",
	NULL,
	service_stopped_foreach,
	service_ctrl_name,
	service_ctrl_desc,
};

static ui_schema_t service_schema[] = {
	/* .service */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".service", "service", "System service manager" },
	{ UI_TYPE_ATTRIBUTE, 0,
	  UI_TYPE_CHOICE, "module_service", NULL,
	  ".service.always_up", "always_up",
	  "Services started after booting" },
	{ UI_TYPE_NONE },
};

static int service_cmd_start(ui_session_t *sess, ui_entry_t *inst,
			     void *ctx, int argc, char **argv)
{
	int res = -1;
	if (argv[0]) {
		if (!argv[0][0] || strcasecmp(argv[0], SERVICE_ALL_MODULE) == 0)
			res = service_start_module();
		else
			res = service_start(argv[0]);
	}
	return res;
}

static int service_cmd_stop(ui_session_t *sess, ui_entry_t *inst,
			    void *ctx, int argc, char **argv)
{
	int res = -1;
	if (argv[0]) {
		if (!argv[0][0] || strcasecmp(argv[0], SERVICE_ALL_MODULE) == 0)
			res = service_stop_module();
		else
			res = service_stop(argv[0]);
	}
	return res;
}

static int service_cmd_status(ui_session_t *sess, ui_entry_t *inst,
			      void *ctx, int argc, char **argv)
{
	service_ctrl_t *ctrl;
	int i = 0;
	ui_table_t *table = ui_table_by_name(sess, "service_status");

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "service_status");
	if (!table)
		return -1;

	ui_add_title(table, 0, "name");
	ui_add_title(table, 1, "type");
	ui_add_title(table, 2, "status");

	for_each_service_ctrl(ctrl) {
		ui_add_value(table, "name", i, ctrl->name);//->service->name);
		if (ctrl->service->flags & SERVICE_FLAG_MODULE) {
			ui_add_value(table, "type", i, "module");
		} else {
			ui_add_value(table, "type", i, "system");
		}
		ui_add_value(table, "status", i, service_status2name(ctrl->status));
		i++;
	}
	sess->result_table = table;
	return 0;
}

ui_argument_t service_stop_args[] = {
	{ "service",
	  "Started service name",
	  "started_service",
	  UI_TYPE_CHOICE, },
};

ui_argument_t service_start_args[] = {
	{ "service",
	  "Stopped service name",
	  "stopped_service",
	  UI_TYPE_CHOICE, },
};

ui_command_t service_stop_command = {
	"stop",
	"Stop registered service",
	".service",
	UI_CMD_SINGLE_INST,
	service_stop_args,
	1,
	LIST_HEAD_INIT(service_stop_command.link),
	service_cmd_stop,
};

ui_command_t service_start_command = {
	"start",
	"Start registered service",
	".service",
	UI_CMD_SINGLE_INST,
	service_start_args,
	1,
	LIST_HEAD_INIT(service_start_command.link),
	service_cmd_start,
};

ui_command_t service_status_command = {
	"status",
	"Display service status",
	".service",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(service_status_command.link),
	service_cmd_status,
};

static int service_cmd_dump(ui_session_t *sess, ui_entry_t *inst,
			    void *ctx, int argc, char **argv)
{
	ui_conf_dump_root();
	return 0;
}

ui_command_t service_dump_command = {
	"dump",
	"Dump service configuration",
	".service",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(service_dump_command.link),
	service_cmd_dump,
};

int __init service_init(void)
{
	ui_register_schema(service_schema);
	ui_register_command(&service_status_command);
	ui_register_command(&service_start_command);
	ui_register_command(&service_stop_command);
	ui_register_command(&service_dump_command);
	ui_register_choice(&service_module_choice);
	ui_register_choice(&service_started_choice);
	ui_register_choice(&service_stopped_choice);
	return 0;
}

void __exit service_exit(void)
{
	ui_unregister_choice(&service_started_choice);
	ui_unregister_choice(&service_stopped_choice);
	ui_unregister_choice(&service_module_choice);
	ui_unregister_command(&service_dump_command);
	ui_unregister_command(&service_start_command);
	ui_unregister_command(&service_stop_command);
	ui_unregister_command(&service_status_command);
	ui_unregister_schema(service_schema);
}
