#ifndef __MODULE_H_INCLUDE__
#define __MODULE_H_INCLUDE__

#include <sysdep.h>

#ifdef CONFIG_MODULE
#define modlinkage	static
#else
#define modlinkage
#endif

/* These are for everybody (although not all archs will actually
 * discard it in modules)
 */
#ifdef MODULE
#define __init		__attribute__((__section__(".init.text"))) __cold
#define __initdata	__attribute__((__section__(".init.data")))
#define __exitdata	__attribute__((__section__(".exit.data")))
#define __exit		__attribute__((__section__(".exit.text"))) __cold
#else
#define __init
#define __initdata
#define __exitdata
#define __exit
#endif
#define __exit_call	__attribute_used__ __attribute__((__section__(".exitcall.exit")))

typedef int (*initcall_t)(void);
typedef void (*exitcall_t)(void);

/* initcalls are now grouped by functionality into separate 
 * subsections. Ordering inside the subsections is determined
 * by link order. 
 * For backwards compatibility, initcall() puts the call in 
 * the device init subsection.
 *
 * The `id' arg to __define_initcall() is needed so that multiple initcalls
 * can point at the same handler without causing duplicate-symbol build errors.
 */

#define __define_initcall(level,fn,id) \
	static const initcall_t __initcall_##fn##id __attribute_used__ \
	__attribute__((__section__(".initcall" level ".init"))) = fn

/*
 * A "pure" initcall has no dependencies on anything else, and purely
 * initializes variables that couldn't be statically initialized.
 *
 * This only exists for built-in code, not for modules.
 */
#define pure_initcall(fn)		__define_initcall("0",fn,0)
#define core_initcall(fn)		__define_initcall("1",fn,1)
#define core_initcall_sync(fn)		__define_initcall("1s",fn,1s)
#define postcore_initcall(fn)		__define_initcall("2",fn,2)
#define postcore_initcall_sync(fn)	__define_initcall("2s",fn,2s)
#define arch_initcall(fn)		__define_initcall("3",fn,3)
#define arch_initcall_sync(fn)		__define_initcall("3s",fn,3s)
#define subsys_initcall(fn)		__define_initcall("4",fn,4)
#define subsys_initcall_sync(fn)	__define_initcall("4s",fn,4s)
#define device_initcall(fn)		__define_initcall("5",fn,4)
#define device_initcall_sync(fn)	__define_initcall("5s",fn,4s)

#define __initcall(fn) device_initcall(fn)
#define __exitcall(fn) \
	static exitcall_t __exitcall_##fn __exit_call = fn

#define core_exitcall(fn)		__exitcall(fn)
#define postcore_exitcall(fn)		__exitcall(fn)
#define arch_exitcall(fn)		__exitcall(fn)
#define subsys_exitcall(fn)		__exitcall(fn)
#define device_exitcall(fn)		__exitcall(fn)

#define module_init(x)	__initcall(x);
#define module_exit(x)	__exitcall(x);

void __init early_end(void);
int __init early_begin(void);
int __init system_init(void);
void __exit system_exit(void);

int __init eloop_init(void);
void __exit eloop_exit(void);

/* the essential modules */
int __init log_early_init(void);
void __exit log_early_exit(void);
void __exit log_exit(void);
int __init service_init(void);
void __exit service_exit(void);
int __init secret_init(void);
void __exit secret_exit(void);

#endif /* __MODULE_H_INCLUDE__ */
