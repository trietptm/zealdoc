/* Readline.h -- the names of functions callable from within readline. */

/* Copyright (C) 1987-2005 Free Software Foundation, Inc.

   This file is part of the GNU Readline Library, a library for
   reading lines of text with interactive input and history editing.

   The GNU Readline Library is free software; you can redistribute it
   and/or modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2, or
   (at your option) any later version.

   The GNU Readline Library is distributed in the hope that it will be
   useful, but WITHOUT ANY WARRANTY; without even the implied warranty
   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   The GNU General Public License is often shipped with GNU software, and
   is generally kept in a file called COPYING or LICENSE.  If you do not
   have a copy of the license, write to the Free Software Foundation,
   59 Temple Place, Suite 330, Boston, MA 02111 USA. */

#ifndef __CLI_READLINE_H_INCLUDE__
#define __CLI_READLINE_H_INCLUDE__

#include <ctype.h>
#include <string.h>
#include <sysdep.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Generic function that takes a character buffer (which could be the readline
   line buffer) and an index into it (which could be rl_point) and returns
   an int. */
typedef int cli_linebuf_fn(char *, int);
typedef int cli_command_fn(cli_session_t *, int, int);

typedef struct _cli_kmentry_t {
	char type;
	cli_command_fn *function;
} cli_kmentry_t;

/* This must be large enough to hold bindings for all of the characters
   in a desired character set (e.g, 128 for ASCII, 256 for ISO Latin-x,
   and so on) plus one for subsequence matching. */
#define KEYMAP_SIZE 257
#define ANYOTHERKEY KEYMAP_SIZE-1
typedef cli_kmentry_t *cli_keymap_t;

/* Hex-encoded Readline version number. */
#define RL_READLINE_VERSION	0x0502		/* Readline 5.2 */
#define RL_VERSION_MAJOR	5
#define RL_VERSION_MINOR	2

/* Readline data structures. */

/* Maintaining the state of undo.  We remember individual deletes and inserts
   on a chain of things to do. */

/* **************************************************************** */
/*								    */
/*	     Functions available to bind to key sequences	    */
/*								    */
/* **************************************************************** */

extern int rl_set_prompt(cli_session_t *, const char *);
extern int rl_expand_prompt(cli_session_t *, char *);

extern int rl_initialize(cli_session_t *);

/* Functions for undoing, from undo.c */
extern void rl_add_undo(cli_session_t *, int, int, int, char *);
extern void rl_free_undo_list(cli_session_t *);
extern int rl_do_undo(cli_session_t *);
extern int rl_begin_undo_group(cli_session_t *);
extern int rl_end_undo_group(cli_session_t *);

/* Functions for redisplay. */
extern void rl_redisplay(cli_session_t *);
extern int rl_on_new_line(cli_session_t *);
extern int rl_forced_update_display(cli_session_t *);
extern int rl_clear_message(cli_session_t *);
extern int rl_reset_line_state(cli_session_t *);
extern int rl_message(cli_session_t *, const char *format, ...);

/* Undocumented in texinfo manual. */
extern int rl_character_len(cli_session_t *, int, int);

/* Save and restore internal prompt redisplay information. */
extern void rl_save_prompt(cli_session_t *);
extern void rl_restore_prompt(cli_session_t *);

/* Modifying text. */
extern void rl_replace_line(cli_session_t *, const char *, int);
extern int rl_insert_text(cli_session_t *, const char *);
extern int rl_delete_text(cli_session_t *, int, int);
extern int cli_kill_text(cli_session_t *, int, int);
extern char *rl_copy_text(cli_session_t *, int, int);

/* Terminal and tty mode management. */
extern int rl_reset_terminal(cli_session_t *, const char *);
extern void rl_resize_terminal(cli_session_t *);
extern void rl_set_screen_size(cli_session_t *, int, int);
extern void rl_get_screen_size(cli_session_t *, int *, int *);

/* Functions for character input. */
extern int rl_execute_next(cli_session_t *, int);
extern int rl_clear_pending_input(cli_session_t *);
extern int rl_read_key(cli_session_t *);
extern int rl_getc(int);

/* `Public' utility functions . */
extern void rl_extend_line_buffer(cli_session_t *, int);
extern int rl_alphabetic(int);

/* Undocumented. */
extern int rl_maybe_save_line(cli_session_t *);
extern int rl_maybe_unsave_line(cli_session_t *);
extern int rl_maybe_replace_line(cli_session_t *);

/* Completion functions. */
extern int rl_complete_internal(cli_session_t *sess, int);
extern void rl_display_match_list(cli_session_t *sess, char **, int, int);
extern int rl_completion_mode(cli_command_fn *);

/* **************************************************************** */
/*								    */
/*			Well Published Variables		    */
/*								    */
/* **************************************************************** */

/* The name of the calling program.  You should initialize this to
   whatever was in argv[0].  It is used when parsing conditionals. */
extern const char *rl_readline_name;

/* Completion variables. */
/* The basic list of characters that signal a break between words for the
   completer routine.  The initial contents of this variable is what
   breaks words in the shell, i.e. "n\"\\'`@$>". */
extern const char *rl_basic_word_break_characters;

/* The list of characters that signal a break between words for
   rl_complete_internal.  The default list is the contents of
   rl_basic_word_break_characters.  */
extern /*const*/ char *rl_completer_word_break_characters;

/* List of characters which can be used to quote a substring of the line.
   Completion occurs on the entire substring, and within the substring   
   rl_completer_word_break_characters are treated as any other character,
   unless they also appear within this list. */
extern const char *rl_completer_quote_characters;

/* List of quote characters which cause a word break. */
extern const char *rl_basic_quote_characters;

/* Set to a character describing the type of completion being attempted by
   rl_complete_internal; available for use by application completion
   functions. */
extern int rl_completion_type;

/* Up to this many items will be displayed in response to a
   possible-completions call.  After that, we ask the user if she
   is sure she wants to see them all.  The default value is 100. */
extern int rl_completion_query_items;

/* If set to non-zero by an application completion function,
   rl_completion_append_character will not be appended. */
extern int rl_completion_suppress_append;

/* Set to any quote character readline thinks it finds before any application
   completion function is called. */
extern int rl_completion_quote_character;

/* Set to a non-zero value if readline found quoting anywhere in the word to
   be completed; set before any application completion function is called. */
extern int rl_completion_found_quote;

/* If non-zero, the completion functions don't append any closing quote.
   This is set to 0 by rl_complete_internal and may be changed by an
   application-specific completion function. */
extern int rl_completion_suppress_quote;

/* If non-zero, then disallow duplicates in the matches. */
extern int rl_ignore_completion_duplicates;

/* Input error; can be returned by (*rl_getc_function) if readline is reading
   a top-level command (RL_ISSTATE (RL_STATE_READCMD)). */
#define READERR			(-2)

/* Definitions available for use by readline clients. */
#define RL_PROMPT_START_IGNORE	'\001'
#define RL_PROMPT_END_IGNORE	'\002'

/* Possible values for do_replace argument to rl_filename_quoting_function,
   called by rl_complete_internal. */
#define NO_MATCH        0
#define SINGLE_MATCH    1
#define MULT_MATCH      2

#ifdef __cplusplus
}
#endif

#endif /* __CLI_READLINE_H_INCLUDE__ */
