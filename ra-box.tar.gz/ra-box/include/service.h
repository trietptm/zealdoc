#ifndef __SERVICE_H_INCLUDE__
#define __SERVICE_H_INCLUDE__

#include <sysdep.h>
#include <list.h>

typedef struct _service_t {
	const char *name;
	const char *desc;
#define SERVICE_UP_NEVER	0
#define SERVICE_UP_ALWAYS	1
#define SERVICE_UP_DEMAND	2
	int flags;
#define SERVICE_FLAG_SYSTEM	0x01	/* cannot be stopped */
#define SERVICE_FLAG_MODULE	0x02	/* module service can be stopped */
	int up_timing;
	list_t depends;
	int (*start)(void);
	void (*stop)(void);
} service_t;

typedef void *handle_t;

handle_t register_service(service_t *svc);
void unregister_service(handle_t svc_hdl);

int service_register_depend(const char *svc, const char *dep);

int service_start(const char *name);
int service_stop(const char *name);

void services_start(void);
void services_stop(void);

#endif /* __SERVICE_H_INCLUDE__ */
