#ifndef __SYSLOG_CONF_H_INCLUDE__
#define __SYSLOG_CONF_H_INCLUDE__

#include <sysdep.h>
#include <syslog.h>

#define SYSLOG_PORT		514
#define SYSLOG_SERVICE_NAME	"syslog"

#endif /* __SYSLOG_CONF_H_INCLUDE__ */
