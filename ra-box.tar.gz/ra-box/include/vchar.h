#ifndef __VCHAR_H_INCLUDE__
#define __VCHAR_H_INCLUDE__

/*
 *	bp      v
 *	v       v
 *	........................
 *	        <--------------> l
 *	<----------------------> bl
 */
typedef struct _vchar_t_ {
	size_t l;	/* length of the value */
	caddr_t v;	/* place holder to the pointer to the value */
} vchar_t;

#define VPTRINIT(p) \
do { \
	if (p) { \
		vfree(p); \
		(p) = NULL; \
	} \
} while(0);

extern vchar_t *vmalloc(size_t);
extern vchar_t *vrealloc(vchar_t *, size_t);
extern void vfree(vchar_t *);
extern vchar_t *vdup(vchar_t *);

extern caddr_t val2str(const char *, size_t);
extern char *str2val(const char *, int, size_t *);

#endif
