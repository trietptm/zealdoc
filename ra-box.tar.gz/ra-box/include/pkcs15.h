#ifndef __PKCS15_H__
#define __PKCS15_H__

#include <pcsc.h>

#define PKCS15_ID_MAX		255
#define PKCS15_LABEL_MAX	255
/* 3F005015 is our first selection. Other then use 3F00 */
#define PKCS15_PREFER_ROOT	"5015"

struct pkcs15_id {
	uint8_t value[PKCS15_ID_MAX];
	size_t len;
};

/* A large integer, big endian notation */
struct pkcs15_bignum {
	uint8_t *data;
	size_t len;
};

struct pkcs15_der {
	uint8_t *value;
	size_t len;
};

struct pkcs15_sec_env_info {
	int sec;
	struct icc_object_id owner;
	uint8_t aid[ICC_AID_MAX];
	size_t aid_len;
};

struct pkcs15_tokeninfo {
	uint32_t version;
	uint32_t flags;
	char *label;
	uint8_t *serial_num;
	uint8_t *manufacturer_id;
	uint8_t *last_update;
	uint8_t *prefered_lang;
	struct pkcs15_sec_env_info **sec_info;
	size_t sec_info_num;
};

/* PKCS #15 DF Types */
#define PKCS15_PRKDF			0
#define PKCS15_PUKDF			1
#define PKCS15_PUKDF_TRUSTED		2
#define PKCS15_SKDF			3
#define PKCS15_CDF			4
#define PKCS15_CDF_TRUSTED		5
#define PKCS15_CDF_USEFUL		6
#define PKCS15_DODF			7
#define PKCS15_AODF			8
#define PKCS15_DF_TYPE_COUNT		9

struct pkcs15_df {
	uint32_t type;
	struct icc_path path;
	struct icc_file *filp;
	int record_len;
	int enumerated;

	list_t link;
};

/* PKCS#15 Object Types */
#define PKCS15_TYPE_CLASS_MASK		0xF00

#define PKCS15_TYPE_PRKEY		0x100
#define PKCS15_TYPE_PRKEY_RSA		0x101
#define PKCS15_TYPE_PRKEY_DSA		0x102

#define PKCS15_TYPE_PUBKEY		0x200
#define PKCS15_TYPE_PUBKEY_RSA		0x201
#define PKCS15_TYPE_PUBKEY_DSA		0x202

#define PKCS15_TYPE_CERT		0x400
#define PKCS15_TYPE_CERT_X509		0x401
#define PKCS15_TYPE_CERT_SPKI		0x402

#define PKCS15_TYPE_DATA_OBJECT		0x500

#define PKCS15_TYPE_AUTH		0x600
#define PKCS15_TYPE_AUTH_PIN		0x601

#define PKCS15_TYPE_TO_CLASS(t)		(1 << ((t) >> 8))
/* PKCS15 Object Class */
#define PKCS15_SEARCH_CLASS_PRKEY	0x0002U
#define PKCS15_SEARCH_CLASS_PUBKEY	0x0004U
#define PKCS15_SEARCH_CLASS_CERT	0x0010U
#define PKCS15_SEARCH_CLASS_DATA	0x0020U
#define PKCS15_SEARCH_CLASS_AUTH	0x0040U

struct pkcs15_object {
	uint32_t type;
	
	char label[PKCS15_LABEL_MAX]; /* Zero terminated */
	unsigned int flags;
	struct pkcs15_id auth_id;
	
	struct pkcs15_der der;
	
	int user_consent;
	void *priv;
	list_t link;
};

struct pkcs15_handle {
	pcsc_handle_t *card_handle;
	struct pkcs15_tokeninfo tokeninfo;

	struct icc_file *app_root;
	struct icc_file *odf, *tif, *unused;

	list_t df_list;
	list_t obj_list;
};

/* During binding, you should enumate all df and objects, 
 * and save them in the memory.
 * When you add/upate/remove df/obj, update the memory. */

struct pkcs15_bind_trans *pkcs15_bind(uint16_t idx, struct pkcs15_handle **p15_handle_out,
		pcsc_appcmd_complete cb, void *user_data);

int pkcs15_unbind(struct pkcs15_handle *p15_handle);

int pkcs15_get_object(struct pkcs15_handle *p15_handle, uint32_t obj_type,
		      struct pkcs15_object **objs, size_t *objs_count,
		      pcsc_appcmd_complete complete, void *user_data);
int pkcs15_find_object_by_id(struct pkcs15_handle *p15_handle, 
			     uint32_t obj_type, const struct pkcs15_id *obj_id,
			     struct pkcs15_object **objs,
			     pcsc_appcmd_complete complete, void *user_data);

int pkcs15_encode_dir(struct pkcs15_handle *p15_handle, 
		      uint8_t **out, size_t *out_len);
int pkcs15_encode_odf (struct pkcs15_handle *p15_handle,
		       uint8_t **out, size_t *out_len);
int pkcs15_encode_tokeninfo(struct pkcs15_handle *p15_handle,
			    uint8_t **out, size_t *out_len);
int pkcs15_encode_df(struct pkcs15_handle *p15_handle,
		     uint8_t **out, size_t *out_len);
int pkcs15_parse_df(struct pkcs15_handle *p15_handle, 
		    struct pkcs15_df *df);

struct pkcs15_pubkey_rsa {
	struct pkcs15_bignum modules;
	struct pkcs15_bignum exponent;
};

struct pkcs15_prkey_rsa {
	/* Public components */
	struct pkcs15_bignum modules;
	struct pkcs15_bignum exponent;
	/* Private components */
	struct pkcs15_bignum d;
	struct pkcs15_bignum p;
	struct pkcs15_bignum q;

	/* Optional CRT elements */
	struct pkcs15_bignum iqmp;
	struct pkcs15_bignum dmp1;
	struct pkcs15_bignum dmq1;
};

struct pkcs15_pubkey_dsa {
	struct pkcs15_bignum pub;
	struct pkcs15_bignum p;
	struct pkcs15_bignum q;
	struct pkcs15_bignum g;
};

struct pkcs15_prkey_dsa {
	/* Public components */
	struct pkcs15_bignum pub;
	struct pkcs15_bignum p;
	struct pkcs15_bignum q;
	struct pkcs15_bignum g;

	/* Private key */
	struct pkcs15_bignum priv;	
};

struct pkcs15_pubkey {
	int algorithm;
	
	/* Decoded Key*/
	union {
		struct pkcs15_pubkey_rsa rsa;
		struct pkcs15_pubkey_dsa dsa;
	} u;

	/* DER encoded raw key */
	struct pkcs15_der data;
};

struct pkcs15_pubkey_info {
	struct pkcs15_id id; /* Correlates to private key id */
	unsigned int usage, access_flags;
	int native, key_ref;
	size_t modules_len;
	uint8_t *subject;
	size_t subject_len;

	struct icc_path path;
};

int pkcs15_read_pubkey(struct pkcs15_handle *p15_handle, 
		       const struct pkcs15_object *obj,
		       struct pkcs15_pubkey **out,
		       pcsc_appcmd_complete callback, void *user_data);
int pkcs15_encode_pubkey_rsa(struct pkcs15_pubkey *pubkey, 
			     uint8_t **out, size_t *out_len);
int pkcs15_encode_pubkey_dsa(struct pkcs15_pubkey *pubkey, 
			     uint8_t **out, size_t *out_len);
int pkcs15_encode_pubkey(struct pkcs15_pubkey *pubkey, 
			 uint8_t **out, size_t *out_len);
int pkcs15_decode_pubkey_rsa(const uint8_t *in, size_t in_len, 
			     struct pkcs15_pubkey *pubkey);
int pkcs15_decode_pubkey_dsa(const uint8_t *in, size_t in_len, 
			     struct pkcs15_pubkey *pubkey);
int pkcs15_decode_pubkey(const uint8_t *in, size_t in_len, 
			 struct pkcs15_pubkey *pubkey);

struct pkcs15_prkey {
	int algorithm;
	union {
		struct pkcs15_prkey_rsa rsa;
		struct pkcs15_prkey_dsa dsa;
	} u;
};

struct pkcs15_prkey_info {
	struct pkcs15_id id; /* Correlates to public cert id */
	unsigned int usage, access_flags;
	int native, key_ref;
	size_t modules_len;
	uint8_t *subject;
	size_t subject_len;

	struct icc_path path;
};

int pkcs15_read_prkey(struct pkcs15_handle *p15_handle, 
		      const struct pkcs15_object *obj,
		      struct pkcs15_prkey **out,
		      pcsc_appcmd_complete callback, void *user_data);
int pkcs15_encode_prkey(const struct pkcs15_prkey *prkey, 
			uint8_t **out, size_t *out_len);
int pkcs15_decode_prkey(const uint8_t *in, size_t in_len,
			struct pkcs15_prkey *prkey);

struct pkcs15_cert {
	int version;
	uint8_t *serial_num;
	size_t serial_len;
	uint8_t *issuer;
	size_t issuer_len;
	uint8_t *subject;
	size_t subject_len;
	uint8_t *crl;
	size_t crl_len;

	struct pkcs15_pubkey pubkey;
	uint8_t *cert_data; /* DER encoded raw cert */
	size_t cert_data_len;
};

struct pkcs15_cert_info {
	struct pkcs15_id id;
	int authority;
	struct icc_path path;

	struct pkcs15_der value;
};

int pkcs15_read_cert (struct pkcs15_handle *p15_handle, 
		      const struct pkcs15_object *obj,
		      struct pkcs15_cert **out,
		      pcsc_appcmd_complete callback, void *user_data);

struct pkcs15_data {
	uint8_t *data; /* DER encoded raw data object */
	size_t data_len;
};

struct pkcs15_data_info {
	/* FIXME: There is no pkcs15 id in DATA type */
	struct pkcs15_id id;

	/* Identify the application: 
	 * either or both may be set */
	char app_label[PKCS15_LABEL_MAX];
	struct icc_object_id app_oid;

	struct icc_path path;
};

int pkcs15_read_data_object (struct pkcs15_handle *p15_handle,
			     const struct pkcs15_object *obj,
			     struct pkcs15_data **out,
			     pcsc_appcmd_complete callback, void *user_data);
int pkcs15_find_data_obj_by_id (struct pkcs15_handle *p15_handle, 
				const struct pkcs15_id *obj_id,
				struct pkcs15_object **objs,
				pcsc_appcmd_complete complete, void *user_data);

struct pkcs15_pin_info {
	struct pkcs15_id auth_id;
	int ref;
	uint32_t flags, type;
	size_t min_len, max_len, stored_len;
	uint8_t pad_char;
	struct icc_path path;

	int tries_left;
};

int pkcs15_find_pin_by_ref(struct pkcs15_handle *p15_handle,
			   const struct icc_path *path, int ref,
			   struct pkcs15_object **out);
int pkcs15_verify_pin(struct pkcs15_handle *p15_handle, 
		      struct pkcs15_pin_info *pin_info,
		      uint8_t *pin_value, size_t pin_len,
		      pcsc_appcmd_complete callback, void *user_data);
int pkcs15_change_pin(struct pkcs15_handle *p15_handle, 
		      struct pkcs15_pin_info *pin_info,
		      uint8_t *old_pin_value, size_t old_pin_len,
		      uint8_t *new_pin_value, size_t new_pin_len,
		      pcsc_appcmd_complete callback, void *user_data);
int pkcs15_unblock_pin(struct pkcs15_handle *p15_handle, 
		       struct pkcs15_pin_info *pin_info,
		       uint8_t *puk_value, size_t puk_len,
		       uint8_t *new_pin_value, size_t new_pin_len,
		       pcsc_appcmd_complete callback, void *user_data);



#define PKCS15_SUCCESS			0
#define PKCS15_ERR_NO_MEM		-1
#define PKCS15_ERR_INVALID_ARGS		-2
#define PKCS15_ERR_NOT_SUPPORTED	-3
#define PKCS15_ERR_INVALID_HANDLE	-4
#define PKCS15_ERR_CARD_INACTIVE	-5
#define PKCS15_ERR_INSUF_BUFFER		-6

#define PKCS15_ERR_INVALID_ASN1_OBJ	-10
#define PKCS15_ERR_ASN1_OBJ_NOT_FOUND	-11
#define PKCS15_ERR_ASN1_END_OF_CONTENTS -12
#define PKCS15_ERR_OBJECT_NOT_FOUND	-13


#define PKCS15_ERR_OTHER		-99

#endif /* __PKCS15_H__ */

