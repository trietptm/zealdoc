#ifndef __PPP_BCP_H_INCLUDE__
#define __PPP_BCP_H_INCLUDE__

#include <ppp_nego.h>

#define CI_BRIDGE_IDENTIFICATION	1
#define CI_LINE_IDENTIFICATION		2
#define CI_MAC_SUPPORT			3
#define CI_TINYGRAM_COMPRESSION		4
#define CI_LAN_IDENTIFICATION		5	/* obsolete (since RFC 2878) */
#define CI_MAC_ADDRESS			6
#define CI_SPANNING_TREE_PROTOCOL	7	/* old format (RFC 1638) */
#define CI_IEEE_802_TAGGED_FRAME	8
#define CI_MANAGEMENT_INLINE		9	/* new format (RFC 2878) */

/* values for MAC Support */
#define MAC_IEEE_802_3			1
#define MAC_IEEE_802_4			2
#define MAC_IEEE_802_5_NON		3
#define MAC_FDDI_NON			4
#define MAC_IEEE_802_5			11
#define MAC_FDDI			12

/* Multicast bit */
#define BCP_MULTICAST			1

/* values for Spanning Tree protocol */
#define SPAN_NONE			0
#define SPAN_IEEE_802_1D		1
#define SPAN_IEEE_802_1G		2
#define SPAN_IBM			3
#define SPAN_DEC			4
#define MAX_SPANTREE			SPAN_DEC

#define ETH_ALEN			6	/* ethernet address length */

#endif /* __PPP_BCP_H_INCLUDE__ */
