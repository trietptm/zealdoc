#ifndef __NET_RTNL_H_INCLUDE__
#define __NET_RTNL_H_INCLUDE__

#include <sysdep.h>
#include <net_skb.h>
#include <linux/netlink.h>

#define RTNL_SERVICE_NAME	"rtnl"

typedef int (*rtnl_handle_t)(struct nlmsghdr *, void *);

int rtnl_register_handler(int protocol, int msgtype,
			  rtnl_handle_t doit);
int rtnl_unregister_handler(int protocol, int msgtype);
void rtnl_unregister_all_handlers(int protocol);
int rtnl_wild_dump(int family, int type);

static inline int rtm_msgindex(int msgtype)
{
	int msgindex = msgtype - RTM_BASE;

	/*
	 * msgindex < 0 implies someone tried to register a netlink
	 * control code. msgindex >= RTM_NR_MSGTYPES may indicate that
	 * the message type has not been added to linux/rtnetlink.h
	 */
	BUG_ON(msgindex < 0 || msgindex >= RTM_NR_MSGTYPES);
	return msgindex;
}

#ifdef WIN32
#include <rtnl_win32.h>
#endif

int __init rtnl_sys_init(void);
void __exit rtnl_sys_exit(void);

#endif /* __NET_RTNL_H_INCLUDE__ */
