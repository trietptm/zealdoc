#ifndef __PCSC_DEFS_H__
#define __PCSC_DEFS_H__

/* ALL PC/SC framework(ifd/icc/handle) define and enum. */

/* ifd exchange (ESCAPE command) */
#define IOCTL_SMARTCARD_VENDOR_IFD_EXCHANGE	SCARD_CTL_CODE(1)

#define PCSC_SERVICE_DESC	"Personal computer smart card"

#define PCSC_MAX_READERS	16
#define PCSC_MAX_DEVID_PARTS	5
#define PCSC_MAX_ATR		33

enum pcsc_ifd_type {
	PCSC_IFD_TYPE_USB = 1,
};

enum pcsc_ifd_status {
	PCSC_IFD_STATUS_FAILED	= 0x0000,
	PCSC_IFD_STATUS_ABSENT	= 0x0001,
	PCSC_IFD_STATUS_PRESENT	= 0x0010,
};

enum pcsc_icc_status {
	PCSC_ICC_STATUS_UNKNOWN		= 0xFFFF,	/*Unknown state */
	PCSC_ICC_PRESENT_MASK		= 0x00F0,
	PCSC_ICC_POWER_MASK		= 0x000F,

	PCSC_ICC_PRESENT_POWERUP	= 0x0011,
	PCSC_ICC_PRESENT_POWERDOWN	= 0x0010,
	PCSC_ICC_ABSENT			= 0x0000,

	PCSC_ICC_STATUS_NEGOTIABLE	= 0x0200,	/*Ready for PTS*/
	PCSC_ICC_STATUS_SPECIFIC	= 0x0400,	/*PTS has been set*/
};

enum pcsc_protocol {
	PCSC_PROTOCOL_UNKNOWN	= 0x00000000,
	PCSC_PROTOCOL_T0	= 0x00000001,
	PCSC_PROTOCOL_T1	= 0x00000002,
	PCSC_PROTOCOL_T15	= 0x00000008,
};

enum pcsc_error {
	PCSC_S_SUCCESS			= 0,
	PCSC_E_NO_MEMORY		= -1,
	PCSC_E_INVALID_HANDLE		= -2,
	PCSC_E_INVALID_PARAMETER	= -3,
	PCSC_E_INSUFFICIENT_BUFFER	= -4,
	PCSC_E_CANCELLED		= -5,
	PCSC_E_TIMEOUT			= -6, /*  The user-specified timeout value has expired. */
	PCSC_E_SHARING_VIOLATION	= -7,
	PCSC_E_NOT_SUPPORTED		= -8,
	PCSC_E_NOT_READY		= -9,
	PCSC_E_INVALID_SLOT		= -10,
	
	PCSC_E_NO_SMARTCARD		= -20,
	PCSC_E_UNKNOWN_CARD		= -21,
	PCSC_E_PROTO_MISMATCH		= -22,
	PCSC_E_INVALID_ATR		= -23,
	
	PCSC_E_UNRESPONSIVE_CARD	= -30,
	PCSC_E_UNPOWERED_CARD		= -31,
	PCSC_E_RESET_CARD		= -32,
	PCSC_E_REMOVED_CARD		= -33,
	PCSC_E_INSERTED_CARD		= -34,

	PCSC_E_NO_READER		= -40,
	PCSC_E_UNKNOWN_READER		= -41,
	PCSC_E_READER_UNAVAILABLE	= -42, /*  The specified reader is not currently available for use. */
	PCSC_E_READER_BUSY		= -43, 
	
	PCSC_F_INTERNAL_ERROR		= -99,
};

enum atr_info_ts {
	PCSC_ATR_TS_DIRECT	= 0x01,
	PCSC_ATR_TS_INVERSE	= 0x02,
};

#define PCSC_GET_ATTR_NSLOT	0x01	/* slot number */

/* ============================================================ *
 * for ICC
 * ============================================================ */

#define ICC_AID_MAX	16
#define ICC_APP_MAX	8
#define ICC_OBJECT_ID_OCTETS_MAX	16

#define ICC_ATR_MAX	33
#define ICC_PATH_MAX	16

#define ICC_SHORT_LC_MAX	255
#define ICC_SHORT_LE_MAX	256
#define ICC_EXT_LC_MAX	65535
#define ICC_EXT_LE_MAX	65536

enum icc_protocol {
	ICC_PROTOCOL_T0  = 0x00000001,
	ICC_PROTOCOL_T1  = 0x00000002,
	ICC_PROTOCOL_RAW = 0x00001000,
	ICC_PROTOCOL_ANY = 0xFFFFFFFF,
};

enum icc_apdu_case {
	ICC_APDU_CASE_NONE	= 0x00,
	
	ICC_APDU_CASE_1	= 0x01,/* CLA INS P1 P2 */
	ICC_APDU_CASE_2_SHORT	= 0x02,/* CLA INS P1 P2 Le */
	ICC_APDU_CASE_3_SHORT	= 0x03,/* CLA INS P1 P2 Lc Data */
	ICC_APDU_CASE_4_SHORT	= 0x04,/* CLA INS P1 P2 Lc Data Le */
	ICC_APDU_SHORT_MASK	= 0x0f,

	ICC_APDU_EXT		= 0x10,
	ICC_APDU_CASE_2_EXT	= ICC_APDU_CASE_2_SHORT | ICC_APDU_EXT,
	ICC_APDU_CASE_3_EXT	= ICC_APDU_CASE_3_SHORT | ICC_APDU_EXT,
	ICC_APDU_CASE_4_EXT	= ICC_APDU_CASE_4_SHORT | ICC_APDU_EXT,

	/* The following types let icc determinates whether to use
	 * short or extended APDUs*/
	ICC_APDU_CASE_2	= 0x22,
	ICC_APDU_CASE_3	= 0x23,
	ICC_APDU_CASE_4	= 0x24,
};

/* use command chaining if the Lc value is greater than normally allowed. */
#define ICC_APDU_FLAG_CHAINING	0x00000001UL
/* do not automatically call GET RESPONSE command to read all available data.*/
#define ICC_APDU_FLAG_NO_GET_RESP	0x00000002UL
/* do not automatically try a re-transmit with a new  length if the card 
 * return 0x6Cxx(wrong length) */
#define ICC_APDU_FLAG_NO_RETRY_WL	0x00000004UL

enum icc_path_type {
	ICC_PATH_TYPE_FILE_ID		= 0,
	ICC_PATH_TYPE_DF_NAME		= 1,
	ICC_PATH_TYPE_PATH		= 2,
	ICC_PATH_TYPE_FROM_CURRENT	= 3,
	ICC_PATH_TYPE_PARENT		= 4,
};

enum icc_file_type {
	ICC_FILE_TYPE_DF		= 0x04,
	ICC_FILE_TYPE_INTERNAL_EF	= 0x03,
	ICC_FILE_TYPE_WORKING_EF	= 0x01,
};

enum icc_ef_structure {
	ICC_FILE_EF_UNKNOWN			= 0x00,
	ICC_FILE_EF_TRANSPARENT			= 0x01,
	ICC_FILE_EF_LINEAR_FIXED		= 0x02,
	ICC_FILE_EF_LINEAR_FIXED_TLV		= 0x03,
	ICC_FILE_EF_LINEAR_VARIABLE		= 0x04,
	ICC_FILE_EF_LINEAR_VARIABLE_TLV		= 0x05,
	ICC_FILE_EF_CYCLIC			= 0x06,
	ICC_FILE_EF_CYCLIC_TLV			= 0x07,
};

enum icc_access_control_method {
	ICC_AC_NONE		= 0x00000000,
	ICC_AC_CHV		= 0x00000001,	/* Card Holder Verif. */
	ICC_AC_TERM		= 0x00000002,	/* Terminal Auth. */
	ICC_AC_PRO		= 0x00000004,	/* Secure Messaging. */
	ICC_AC_AUT		= 0x00000008,	/* Key Auth. */

	ICC_AC_NEVER		= 0xFFFFFFFE,
	ICC_AC_UNKNOWN		= 0xFFFFFFFF,
};


/* Operations relating to access control (in case of DF) */
#define	ICC_AC_OP_SELECT		0x00
#define	ICC_AC_OP_LOCK			0x01
#define	ICC_AC_OP_DELETE		0x02
#define	ICC_AC_OP_CREATE		0x03
#define	ICC_AC_OP_REHABILITATE		0x04
#define	ICC_AC_OP_INVALIDATE		0x05
#define	ICC_AC_OP_LIST_FILES		0x06
#define	ICC_AC_OP_CRYPTO		0x07
#define	ICC_AC_OP_DELETE_SELF		0x08

/* Operations relating to access control (in case of EF) */
#define	ICC_AC_OP_READ			0x00
#define	ICC_AC_OP_UPDATE		0x01
#define ICC_AC_OP_ERASE			0x02
#define	ICC_AC_OP_WRITE			0x03
#define	ICC_AC_OP_USE			0x04 /* (in case of KEY(eg.WATCHDATA card)) */

#define ICC_AC_OP_MAX			0x09

#define ICC_AC_KEY_REF_NONE		0xFFFFFFFF

/* File status flags */
#define ICC_FILE_STATUS_ACTIVATED	0x00
#define ICC_FILE_STATUS_INVALIDATED	0x01
#define ICC_FILE_STATUS_CREATION	0x02 /* Full access in this state,
					      * (at least for SetCOS 4.4 */
enum _algorithm_id {
	/* PK algorithms */
	ICC_ALGORITHM_RSA		= 0,
	ICC_ALGORITHM_DSA		= 1,
	ICC_ALGORITHM_EC		= 2,

	/* Symmetric algorithms */
	ICC_ALGORITHM_DES		= 64,
	ICC_ALGORITHM_3DES		= 65,

	/* Hash algorithms */
	ICC_ALGORITHM_MD5		= 128,
	ICC_ALGORITHM_SHA1		= 129,

	/* Key derivation algorithms */
	ICC_ALGORITHM_PBKDF2		= 192,

	/* Key encryption algoprithms */
	ICC_ALGORITHM_PBES2		= 256,
};

enum _algorithm_flags {
	ICC_ALGORITHM_ONBOARD_KEY_GEN		= 0x80000000,
	ICC_ALGORITHM_NEED_USAGE		= 0x40000000,
	ICC_ALGORITHM_SPECIFIC_FLAGS		= 0x0000FFFF,

	ICC_ALGORITHM_RSA_RAW			= 0x00000001,

	/* If the card is willing to produce a cryptogram padded with
	 * the following methods, se these flags accordingly. */
	ICC_ALGORITHM_RSA_PAD_NONE		= 0x00000000,
	ICC_ALGORITHM_RSA_PAD_PKCS1		= 0x00000002,
	ICC_ALGORITHM_RSA_PAD_ANSI		= 0x00000004,
	ICC_ALGORITHM_RSA_PAD_ISO9796		= 0x00000008,
	ICC_ALGORITHM_RSA_PADS			= 0x0000000E,

	/* If the card is willing to produce a cryptogram with the following 
	 * hash values, set these flags accordingly. */
	ICC_ALGORITHM_RSA_HASH_NONE		= 0x00000010,
	ICC_ALGORITHM_RSA_HASH_SHA1		= 0x00000020,
	ICC_ALGORITHM_RSA_HASH_MD5		= 0x00000040,
	ICC_ALGORITHM_RSA_HASH_MD5_SHA1		= 0x00000080,
	ICC_ALGORITHM_RSA_HASH_RIPEMD160	= 0x00000100,
	ICC_ALGORITHM_RSA_HASH_SHA256		= 0x00000200,
	ICC_ALGORITHM_RSA_HASH_SHA384		= 0x00000400,
	ICC_ALGORITHM_RSA_HASH_SHA512		= 0x00000800,
	ICC_ALGORITHM_RSA_HASH_SHA224		= 0x00001000,
	ICC_ALGORITHM_RSA_HASHS			= 0x00001FE0,
};

#define ICC_DEFAULT_SEND_MAX	255
#define ICC_DEFAULT_RECV_MAX	256

/* Card can handle large(> 256 bytes) buffers in calls to read binary,
 * write binary and update binary; if not, several successive calls to
 * the corresponding function is made. */
#define ICC_CAPS_APDU_EXT		0x00000001
/* Card has on-board random number source. */
#define ICC_CAPS_RNG			0x00000002
/* Card doesn't return any File control Info. */
#define ICC_CAPS_NO_FCI			0x00000004
/* Use the card's ACs in icc_pkcs15init_auth(), 
 * instead of relying on the ACL info in the profile files. */
#define ICC_CAP_USE_FCI_AC		0x00000008
#define ICC_CAP_RSA_2048		0x00000010

/* ICC ASN.1 */
#define ICC_ASN1_TAG_CLASS_MASK		0xC0
#define ICC_ASN1_TAG_UNIVERSAL		0x00
#define ICC_ASN1_TAG_APPLICATION	0x40
#define ICC_ASN1_TAG_CONTEXT		0x80
#define ICC_ASN1_TAG_PRIVATE		0xC0

#define ICC_ASN1_TAG_CONSTRUCTED	0x20
#define ICC_ASN1_TAG_PRIMITIVE		0x1F

enum _fci_tag {
	ICC_FCI_TAG_FCI		= 0x6F,
	ICC_FCI_TAG_SPEC	= 0xA5,

	ICC_FCI_TAG_SIZE	= 0x80,/* For transparent EF */
	ICC_FCI_TAG_ANY		= 0x81,/* For any EF */
	ICC_FCI_TAG_FD		= 0x82,/* File Descriptor */
	ICC_FCI_TAG_FID		= 0x83,
	ICC_FCI_TAG_DF_NAME	= 0x84,
	ICC_FCI_TAG_PROPRIETARY = 0x85,
	ICC_FCI_TAG_SECURITY	= 0x86,
	ICC_FCI_TAG_EF_ID	= 0x87,	/* Ideftifier of and EF containing
					 * an extension of the FCI*/
	ICC_FCI_TAG_SFI		= 0x88,
	ICC_FCI_TAG_PRIV	= 0x9F0C,
};

enum {
	ICC_SUCCESS			= 0,
	ICC_ERR_INVALID_ARGS		= -1,
	ICC_ERR_NO_MEM			= -2,
	ICC_ERR_INSUF_BUFFER		= -3,
	ICC_ERR_NOT_SUPPORTED		= -4,
	ICC_ERR_NOT_MATCH		= -5,

	ICC_ERR_INVALID_ASN1_OBJ	= -6,

	ICC_ERR_NO_READER		= -10,
	ICC_ERR_NO_CARD			= -11,
	ICC_ERR_NO_DRIVER		= -12,
	ICC_ERR_INVALID_HANDLE		= -13,

	ICC_ERR_COMMUNICATION		= - 20,


	ICC_ERR_INVALID_ASN1_OBJECT	= -50,

	/* Resulting from a card command or related to the card*/
	ICC_ERR_CARD_CMD_FAILED		= -1200,
	ICC_ERR_FILE_NOT_FOUND		= -1201,
	ICC_ERR_RECORD_NOT_FOUND	= -1202,
	ICC_ERR_CLASS_NOT_SUPPORTED	= -1203,
	ICC_ERR_INS_NOT_SUPPORTED	= -1204,
	ICC_ERR_INCORRECT_PARAM		= -1205,
	ICC_ERR_WRONG_LENGTH		= -1206,
	ICC_ERR_MEMORY_FAILURE		= -1207,
	ICC_ERR_NO_CARD_SUPPORT		= -1208,
	ICC_ERR_NOT_ALLOWED		= -1209,
	ICC_ERR_INVALID_CARD		= -1210,
	ICC_ERR_UNAUTHORIZED		= -1211,
	ICC_ERR_AUTH_BLOCKED		= -1212,
	ICC_ERR_UNKNOWN_RECEIVED	= -1213,
	ICC_ERR_PIN_CODE_INCORRECT	= -1214,
	ICC_ERR_FILE_EXISTS		= -1215,
	ICC_ERR_DATA_OBJ_NOT_FOUND	= -1216,

	/* Muscle */
	ICC_ERR_SEQUENCE_END		= -1217, /* 9C12*/
	ICC_ERR_CACHE_EMPTY		= -1218,
	ICC_ERR_AUTH_FAILED		= -1220,
	ICC_ERR_INVALID_ALG		= -1222,
	ICC_ERR_INVALID_SIG		= -1223,

	
	ICC_ERR_UNSPECIFIED		= -99,
};

/* flags for record operations */
#define ICC_RECORD_EF_ID_MASK	0x0001FUL
/* use first record */
#define ICC_RECORD_BY_REC_ID	0x00000UL
/* use the specified record number */
#define ICC_RECORD_BY_REC_NR	0x00100UL
/* use currently selected record */
#define ICC_RECORD_CURRENT	0x00000UL

#define ICC_PIN_CMD_VERIFY		0
#define ICC_PIN_CMD_CHANGE		1
#define ICC_PIN_CMD_UNBLOCK		2

#define ICC_PIN_CMD_USE_PINPAD		0x0001
#define ICC_PIN_CMD_NEED_PADDING	0x0002
/* Pin encode type */
#define ICC_PIN_ENCODING_ASCII	0
#define ICC_PIN_ENCODING_BCD		1
#define ICC_PIN_ENCODING_GLP		2 /* Global Platform - Card Spec V2.0.1*/

/*===========================================================================*/
/*			Card Control CMDs				     */
/*===========================================================================*/
#define _CTL_PREFIX(a, b, c) (((a) << 24) | ((b) << 16) | ((c) << 8))

enum icc_ctl_request {
	/*
	 * Generic card_ctl calls
	 */
	ICC_CARDCTL_GENERIC_BASE = 0x00000000,
	ICC_CARDCTL_ERASE_CARD,
	ICC_CARDCTL_GET_DEFAULT_KEY,
	ICC_CARDCTL_LIFECYCLE_GET,
	ICC_CARDCTL_LIFECYCLE_SET,
	ICC_CARDCTL_GET_SERIALNR,

	/*
	 * Watch Data TimeCOS/PK specific calls
	 */
	 ICC_CARDCTL_WD_BASE = _CTL_PREFIX('W', 'D', 'P'),
	 ICC_CARDCTL_WD_GENERATE_KEY,
	 ICC_CARDCTL_WD_DATA_COMPRESS,
	 ICC_CARDCTL_WD_ENCRYPT,
	 ICC_CARDCTL_WD_DECRYPT,
	 ICC_CARDCTL_WD_VERIFY_SIGN,
	 ICC_CARDCTL_WRITE_KEY,
	 ICC_CARDCTL_WD_IMPORT_KEY,
};

#define ICC_APDU_BUFFER_MAX	258

#if 0
enum icc_apdu_ins_type {
	ICC_APDU_INS_READ_BINARY	= 0xB0,
	ICC_APDU_INS_WRIET_BINARY	= 0XD0,
	ICC_APDU_INS_UPDATA_BINARY	= ??
};
#endif
#endif /* __PCSC_DEFS_H__ */

