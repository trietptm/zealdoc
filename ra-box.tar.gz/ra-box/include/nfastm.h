/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2008
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@hzcnc.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)nfastm.h: time driven non-deterministic finite-state machine 
 * $Id: nfastm.h,v 1.5 2008-06-23 07:16:56 zhenglv Exp $
 */

#ifndef __NFASTM_H_INCLUDE__
#define __NFASTM_H_INCLUDE__

/* ============================================================
 * state machine
 * ============================================================ */

/**
 * STM_STATE - Declaration of a state machine function
 * @machine: State machine name
 * @state: State machine state
 *
 * This macro is used to declare a state machine function. It is used in place
 * of a C function definition to declare functions to be run when the state is
 * entered by calling STM_ENTER or STM_ENTER_GLOBAL.
 */
#define STM_STATE(machine, state) \
static void stm_ ## machine ## _ ## state(STATE_MACHINE_DATA *sm, \
	int global)

/**
 * STM_ENTRY - State machine function entry point
 * @machine: State machine name
 * @state: State machine state
 *
 * This macro is used inside each state machine function declared with
 * STM_STATE. STM_ENTRY should be in the beginning of the function body, but
 * after declaration of possible local variables. This macro prints debug
 * information about state transition and update the state machine state.
 */
#define STM_ENTRY(machine, state) \
if (!global || sm->stm_state != machine ## _ ## state) { \
	sm->stm_changed = TRUE; \
	STM_LOG(STM_LOG_LEVEL, STATE_MACHINE_DEBUG_PREFIX ": " #machine \
		" entering state " #state); \
} else { \
	sm->stm_changed = FALSE; \
} \
sm->stm_state = machine ## _ ## state;

/**
 * STM_ENTER - Enter a new state machine state
 * @machine: State machine name
 * @state: State machine state
 *
 * This macro expands to a function call to a state machine function defined
 * with STM_STATE macro. STM_ENTER is used in a state machine step function to
 * move the state machine to a new state.
 */
#define STM_ENTER(machine, state) \
stm_ ## machine ## _ ## state(sm, 0)

/**
 * STM_ENTER_GLOBAL - Enter a new state machine state based on global rule
 * @machine: State machine name
 * @state: State machine state
 *
 * This macro is like STM_ENTER, but this is used when entering a new state
 * based on a global (not specific to any particular state) rule. A separate
 * macro is used to avoid unwanted debug message floods when the same global
 * rule is forcing a state machine to remain in on state.
 */
#define STM_ENTER_GLOBAL(machine, state) \
stm_ ## machine ## _ ## state(sm, 1)

/**
 * STM_STEP - Declaration of a state machine step function
 * @machine: State machine name
 *
 * This macro is used to declare a state machine step function. It is used in
 * place of a C function definition to declare a function that is used to move
 * state machine to a new state based on state variables. This function uses
 * STM_ENTER and STM_ENTER_GLOBAL macros to enter new state.
 */
#define STM_STEP(machine) \
static void stm_ ## machine ## _step(STATE_MACHINE_DATA *sm)

/**
 * STM_STEP_RUN - Call the state machine step function
 * @machine: State machine name
 *
 * This macro expands to a function call to a state machine step function
 * defined with STM_STEP macro.
 */
#define STM_STEP_RUN(machine) stm_ ## machine ## _step(sm)

#endif /* __NFASTM_H_INCLUDE__ */
