#ifndef __NET_NAC_H_INCLUDE__
#define __NET_NAC_H_INCLUDE__

typedef struct _nac_t nac_t;
typedef struct _nac_client_t nac_client_t;
typedef unsigned long nac_param_t;

#define NAC_SERVICE_NAME	"nac"

/* ============================================================ *
 * concentrator definitions
 * ============================================================ */
typedef struct _nac_inter_t {
	const char *name;
	const char *desc;

	int (*open)(nac_client_t *client);
	void (*close)(nac_client_t *client);
	list_t link;
} nac_inter_t;

#define NAC_CODE_SUCCESS	0x01
#define NAC_CODE_FAILURE	0x02
#define NAC_CODE_UPDATED	0x03

typedef struct _nac_back_t {
	const char *name;
	const char *desc;

	/* start / stop nac service */
	void *(*start)(nac_t *, ui_entry_t *bcs);
	void (*stop)(nac_t *, void *);

	/* start / stop nac session */
	void *(*open)(nac_client_t *, nac_param_t);
	void (*close)(nac_client_t *, void *);
	void (*advance)(nac_client_t *, void *);
	void (*retreat)(nac_client_t *, void *);

	list_t link;
} nac_back_t;

typedef struct _nac_front_t {
	const char *name;
	const char *desc;

	/* start / stop nac session */
	void *(*open)(nac_client_t *, nac_param_t param);
	void (*close)(nac_client_t *, void *);
	void (*advance)(nac_client_t *, void *);
	void (*retreat)(nac_client_t *, void *);

	list_t link;
} nac_front_t;

struct _nac_client_t {
	nac_t *nac;

	stm_instance_t *fsmi;		/* state machine instance */

	void *front_ctx;
	void *back_ctx;

	/* items set by nac_front_t's request call */
	net_avp_t *front_items;
	/* items set by nac_back_t's reply call */
	net_avp_t *back_items;
	/* items loaded from ui_conf */
	net_avp_t *config_items;
	/* items rejected by nac_front_t */
	net_avp_t *front_reject_items;
	/* items rejected by nac_back_t */
	net_avp_t *back_reject_items;

	int closing;
	atomic_t refcnt;
	list_t link;
};

/* ============================================================ *
 * concentrator operations
 * ============================================================ */
#define NAC_BACK	NIC_FRONT
#define NAC_FRONT	NIC_BACK
nac_front_t *nac_frontend_by_name(const char *name);
int nac_register_frontend(nac_front_t *end);
void nac_unregister_frontend(nac_front_t *end);

nac_back_t *nac_backend_by_name(const char *name);
int nac_register_backend(nac_back_t *end);
void nac_unregister_backend(nac_back_t *end);

nac_inter_t *nac_internet_by_name(const char *name);
int nac_register_internet(nac_inter_t *end);
void nac_unregister_internet(nac_inter_t *end);

net_avp_t *nac_iterate_back_avp(nac_client_t *client, int reject,
				int attr, net_avp_t *last);
net_avp_t *nac_get_back_avp(nac_client_t *client, int reject, int attr);
net_avp_t *nac_iterate_front_avp(nac_client_t *client, int reject,
				 int attr, net_avp_t *last);
net_avp_t *nac_get_front_avp(nac_client_t *client, int reject, int attr);

void nac_add_front_long(nac_client_t *client, int reject,
			int attr, uint32_t lvalue);
void nac_add_back_long(nac_client_t *client, int reject,
		       int attr, uint32_t lvalue);
void nac_add_front_string(nac_client_t *client, int reject,
			  int attr, const char *strval);
void nac_set_front_long(nac_client_t *client, int reject,
			int attr, uint32_t lvalue);
void nac_set_back_long(nac_client_t *client, int reject,
		       int attr, uint32_t lvalue);
void nac_set_front_string(nac_client_t *client, int reject,
			  int attr, const char *strval);
void nac_set_back_string(nac_client_t *client, int reject,
			 int attr, const char *strval);
void nac_set_back_octects(nac_client_t *client, int reject, int attr,
			  const uint8_t *strval, int length);
void nac_set_front_octects(nac_client_t *client, int reject, int attr,
			   const uint8_t *strval, int length);
void nac_unset_back_avp(nac_client_t *client, int reject, int attr);
void nac_unset_front_avp(nac_client_t *client, int reject, int attr);

/* create and destroy the NAC client */
nac_client_t *nac_client_open(nac_t *nac, nac_param_t param);
void nac_client_close(nac_client_t *client);

void nac_back_stopped(nac_t *nac);
void nac_front_stopped(nac_t *nac);
void nac_inter_stopped(nac_t *nac);

/* API generating NAC events */
/* Open */
void nac_client_start(nac_client_t *client);
/* Close */
void nac_client_stop(nac_client_t *client);
/* RFU */
void nac_front_updated(nac_client_t *client);
/* RBU */
void nac_back_updated(nac_client_t *client);
/* RFJ */
void nac_front_rejected(nac_client_t *client);
/* RBJ */
void nac_back_rejected(nac_client_t *client);
/* RFS */
void nac_front_success(nac_client_t *client);
/* RBS */
void nac_back_success(nac_client_t *client);
/* RNF
 * called by front-mode or back-mode when they failed to handle
 * NAC requests.
 * currently no effect will be taken when this event is arriving.
 */
void nac_client_failure(nac_client_t *client);
/* NNT
 * called by inter-mode when internetworking is terminated
 */
void nac_client_terminated(nac_client_t *client);

const char *nac_state_name(nac_client_t *client);

nac_t *nac_get(nac_t *nac);
void nac_put(nac_t *nac);
nac_client_t *nac_client_get(nac_client_t *client);
void nac_client_put(nac_client_t *client);
nac_t *nac_by_name(const char *name);

#if 0
nic_t *nac_nic_config_front(nac_client_t *client);
nic_t *nac_nic_config_back(nac_client_t *client);
void nac_nic_config_free(nic_t *dev);
#endif

/* NAC attributes */
const char *nac_name(nac_t *nac);

#endif /* __NET_NAC_H_INCLUDE__ */
