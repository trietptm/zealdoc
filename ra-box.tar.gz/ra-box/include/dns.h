#ifndef __DNS_H_INCLUDE__
#define __DNS_H_INCLUDE__

#include <sysdep.h>

#define DNS_SERVICE_NAME	"dns"

int dns_update_config(void);
int dns_register_server(const char *string);
void dns_unregister_server(const char *string);
int dns_register_domain(const char *string);
void dns_unregister_domain(const char *string);

int dns_exist_start(void);
void dns_conf_stop(void);

#endif /* __DNS_H_INCLUDE__ */
