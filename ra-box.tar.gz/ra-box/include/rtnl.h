#ifndef __RTNL_H_INCLUDE__
#define __RTNL_H_INCLUDE__

#include <sysdep.h>
#include <uiserv.h>
#include <netsvc.h>

typedef struct _rtnl_link_t rtnl_link_t;

#define RTNL_SERVICE_NAME	"rtnl"

typedef struct _rtnl_monitor_t {
	const char *name;
	int subscriptions;
	int protocol;

	int (*start)(void);
	void (*stop)(void);
	int (*started)(void);

	list_t link;
} rtnl_monitor_t;

struct _rtnl_link_t {
	const char *kind;
	int maxattr;
	int (*parse_opt)(rtnl_link_t *link, net_avp_t *items,
			 struct nlmsghdr *msg);
#if 0
	void (*print_opt)(rtnl_link_t *link, ui_session_t *sess,
			  struct rtattr *[]);
	void (*print_xstats)(rtnl_link_t *link, ui_session_t *sess,
			     struct rtattr *);
#endif
	list_t link;
};

rtnl_link_t *rtnl_link_by_kind(const char *kind);
int rtnl_register_link(rtnl_link_t *type);
void rtnl_unregister_link(rtnl_link_t *type);

rtnl_monitor_t *rtnl_monitor_by_name(const char *name);
rtnl_monitor_t *rtnl_monitor_by_group(int group);
int rtnl_register_monitor(rtnl_monitor_t *mon);
void rtnl_unregister_monitor(rtnl_monitor_t *mon);

#endif /* __RTNL_H_INCLUDE__ */
