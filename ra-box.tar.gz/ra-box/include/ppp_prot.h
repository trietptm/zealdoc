#ifndef __PPP_PROT_H_INCLUDE__
#define __PPP_PROT_H_INCLUDE__

#include <ppp.h>

typedef struct _ppp_protocol_t ppp_protocol_t;
typedef struct _ppp_protinst_t ppp_protinst_t;

struct _ppp_protocol_t {
	/* PPP protocol number */
	uint16_t protocol;
	/* protocol type, indicating in which phase this
	 * protocol is valid
	 */
	int protocol_type;
#define PPP_PROTO_LCP	0x01
#define PPP_PROTO_LQR	0x02
	/* Authentication/Authorization/Audit protocol */
#define PPP_PROTO_AAA	0x04
#define PPP_PROTO_NCP	0x08
	/* text name of protocol */
	const char *name;
	/* long name of protocol */
	const char *long_name;
	/* text name of corresponding data protocol */
	char *data_name;
	/* init protocol instance */
	int (*init)(ppp_phase_t *phase);
	/* exit protocol instance */
	void (*exit)(ppp_phase_t *phase, ppp_protinst_t *inst);
	/* process a received packet */
	void (*input)(ppp_protinst_t *inst, msgbuf_t *msg);
	/* process a received data packet */
	void (*datainput)(ppp_protinst_t *inst, msgbuf_t *msg);

	/* lower layer has come up */
	void (*lowerup)(ppp_protinst_t *inst);
	/* lower layer has gone down */
	void (*lowerdown)(ppp_protinst_t *inst);
	/* process a received protocol-reject */
	void (*protrej)(ppp_protinst_t *inst);

	/* NAC peer end has been updated, require this end to advance
	 * core logic of protocol's NAC state machine
	 */
	void (*nacadvance)(ppp_protinst_t *inst);
	void (*nacretreat)(ppp_protinst_t *inst);
	list_t link;
};

/* ============================================================ *
 * protocol operations
 * ============================================================ */
ppp_protocol_t *ppp_protocol_by_proto(uint16_t proto);
int ppp_register_protocol(ppp_protocol_t *prot);
void ppp_unregister_protocol(ppp_protocol_t *prot);
const char *ppp_protocol_name(uint16_t proto);

void ppp_instance_enable(ppp_phase_t *ctx, ppp_protinst_t *inst, int type);
void ppp_instance_disable(ppp_phase_t *ctx, ppp_protinst_t *inst);
ppp_protinst_t *ppp_instance_by_proto(ppp_phase_t *phase, uint16_t proto);

#endif /* __PPP_PROT_H_INCLUDE__ */
