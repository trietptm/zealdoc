#ifndef __ATOMIC_H_INCLUDE__
#define __ATOMIC_H_INCLUDE__

/* We're single threaded, this is sufficient for us, keen on using
 * atomic_t for portablity.
 */

/*
 * Atomic operations that C can't guarantee us.  Useful for
 * resource counting etc..
 */

/*
 * Make sure gcc doesn't try to be clever and move things around
 * on us. We need to use _exactly_ the address the user gave us,
 * not some alias that contains the same information.
 */
typedef struct { int counter; } atomic_t;

#define ATOMIC_INIT(i)	{ (i) }

/**
 * atomic_read - read atomic variable
 * @v: pointer of type atomic_t
 * 
 * Atomically reads the value of @v.
 */ 
#define atomic_read(v)		((v)->counter)

/**
 * atomic_set - set atomic variable
 * @v: pointer of type atomic_t
 * @i: required value
 * 
 * Atomically sets the value of @v to @i.
 */ 
#define atomic_set(v,i)		(((v)->counter) = (i))

static inline void atomic_add(int i, atomic_t * v)
{
	v->counter += i;
}

static inline void atomic_sub(int i, atomic_t * v)
{
	v->counter -= i;
}

static inline int atomic_add_return(int i, atomic_t * v)
{
	int __temp = 0;

	v->counter += i;
	__temp = v->counter;

	return __temp;
}

#define atomic_add_negative(a, v)	(atomic_add_return((a), (v)) < 0)
static inline int atomic_sub_return(int i, atomic_t * v)
{
	int __temp = 0;

	v->counter -= i;
	__temp = v->counter;

	return __temp;
}

static inline void atomic_inc(volatile atomic_t * v)
{
	v->counter++;
}

#define atomic_inc_not_zero(v) atomic_add_unless((v), 1, 0)

static inline void atomic_dec(volatile atomic_t * v)
{
	v->counter--;
}

static inline void atomic_clear_mask(unsigned int mask, atomic_t * v)
{
	v->counter &= ~mask;
}

static inline void atomic_set_mask(unsigned int mask, atomic_t * v)
{
	v->counter |= mask;
}

#define atomic_dec_return(v) atomic_sub_return(1,(v))
#define atomic_inc_return(v) atomic_add_return(1,(v))

/*
 * atomic_inc_and_test - increment and test
 * @v: pointer of type atomic_t
 *
 * Atomically increments @v by 1
 * and returns true if the result is zero, or false for all
 * other cases.
 */
#define atomic_inc_and_test(v) (atomic_inc_return(v) == 0)

#define atomic_sub_and_test(i,v) (atomic_sub_return((i), (v)) == 0)
#define atomic_dec_and_test(v) (atomic_sub_return(1, (v)) == 0)

#endif /* __ATOMIC_H_INCLUDE__ */
