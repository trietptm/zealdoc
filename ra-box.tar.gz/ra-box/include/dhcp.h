#ifndef __DHCP_H_INCLUDE__
#define __DHCP_H_INCLUDE__

#include <sysdep.h>
#include <list.h>
#include <bitops.h>
#include <netsvc.h>

#include <linux/if_arp.h> /* ARPHRDs */

typedef struct _dhcp_intfc_t dhcp_intfc_t;
typedef struct _dhcp_message_t dhcp_message_t;
typedef struct _dhcp_config_t dhcp_config_t;
typedef struct _dhcp_option_t dhcp_option_t;
typedef struct _dhcp_universe_t dhcp_universe_t;
typedef struct _dhcp_parse_t dhcp_parse_t;
typedef struct _dhcp_network_t dhcp_network_t;
typedef struct _dhcp_subnet_t dhcp_subnet_t;
typedef struct _dhcp_pool_t dhcp_pool_t;

#define DHCP_BOOTREQUEST	0x01
#define DHCP_BOOTREPLY		0x02

#define DHCP_BROADCAST		0x80
#define DHCP_UNICAST		0x00

#define DHCPS_PORT		67
#define DHCPC_PORT		68

/* possible values for hardware type (htype) field... */
#define HTYPE_ETHER	1               /* Ethernet 10Mbps              */
#define HTYPE_IEEE802	6               /* IEEE 802.2 Token Ring...	*/

/* magic cookie validating dhcp options field (and bootp vendor
 * extensions field).
 */
#define DHCP_OPTIONS_COOKIE	"\143\202\123\143"

/* ============================================================ *
 * option definitions
 * ============================================================ */
#define DHCP_OPT_PAD					0
#define DHCP_OPT_END					255

#define DHCP_OPT_SUBNET_MASK				1
#define DHCP_OPT_ROUTER					3
#define DHCP_OPT_DOMAIN_NAME_SERVER			6
#define DHCP_OPT_HOST_NAME				12
#define DHCP_OPT_PERFORM_ROUTER_DISCOVERY		31
#define DHCP_OPT_STATIC_ROUTES				33
#define DHCP_OPT_VENDOR_SPECIFIC_INFORMATION		43
#define DHCP_OPT_NETBIOS_NAME_SERVER			44
#define DHCP_OPT_NETBIOS_DATAGRAM_DISTRIBUTION_SERVER	45
#define DHCP_OPT_NETBIOS_NODE_TYPE			46
#define DHCP_OPT_NETBIOS_SCOPE				47

#define DHCP_OPT_REQUESTED_IP_ADDRESS			50
#define DHCP_OPT_IP_ADDRESS_LEASE_TIME			51
#define DHCP_OPT_OPTION_OVERLOAD			52
#define DHCP_OPT_DHCP_MESSAGE_TYPE			53
#define DHCP_OPT_SERVER_IDENTIFIER			54
#define DHCP_OPT_PARAMETER_REQUEST_LIST			55
#define DHCP_OPT_MESSAGE				56
#define DHCP_OPT_MAXIMUM_DHCP_MESSAGE_SIZE		57
#define DHCP_OPT_RENEWAL_T1_TIME_VALUE			58
#define DHCP_OPT_REBINDING_T2_TIME_VALUE		59
#define DHCP_OPT_VENDOR_CLASS_IDENTIFIER		60
#define DHCP_OPT_CLIENT_IDENTIFIER			61
#define DHCP_OPT_RELAY_AGENT_INFORMATION		82
#define DHCP_OPT_AUTO_CONFIGURATION			116
#define DHCP_OPT_SUBNET_SELECTION			118 /* RFC3011! */

#define DHCP_OPT_MS_PRIVATE_FRAGMENTATION		250

/* Option-Overload values */
#define DHCP_OPTION_OVERLOAD_SNAME	0x01
#define DHCP_OPTION_OVERLOAD_FILE	0x02

#define DHCP_RAI_CIRCUIT_ID		1	/* RFC3046 */
#define DHCP_RAI_REMOTE_ID		2	/* RFC3046 */
#define DHCP_RAI_LINK_SELECT		5	/* RFC3527 */

#define BOOTP_MIN_LEN		300
#define DHCP_MIN_LEN            548

#define DHCPDISCOVER		1
#define DHCPOFFER		2
#define DHCPREQUEST		3
#define DHCPDECLINE		4
#define DHCPACK			5
#define DHCPNAK			6
#define DHCPRELEASE		7
#define DHCPINFORM		8

/* An internet address of up to 128 bits. */
typedef struct _dhcp_iaddr_t {
	unsigned len;
	unsigned char iabuf[16];
} dhcp_iaddr_t;

typedef struct _dhcp_haddr_t {
	uint8_t hlen;
	uint8_t hbuf[17];
	/* htype + hdata */
} dhcp_haddr_t;

struct _dhcp_pool_t {
	dhcp_network_t *shared_network;
#if 0
	struct permit *permit_list;
	struct permit *prohibit_list;
	struct lease *active;
	struct lease *expired;
	struct lease *free;
	struct lease *backup;
	struct lease *abandoned;
	struct lease *reserved;
#endif
	time_t next_event_time;
	int lease_count;
	int free_leases;
	int backup_leases;
	int index;
	list_t link;
};

struct _dhcp_subnet_t {
	dhcp_subnet_t *next_subnet;
	dhcp_subnet_t *next_sibling;
	dhcp_network_t *shared_network;
	dhcp_intfc_t *intfc;
	dhcp_iaddr_t interface_address;
	dhcp_iaddr_t net;
	dhcp_iaddr_t netmask;
};

struct _dhcp_network_t {
	char *name;
	dhcp_subnet_t *subnets;
	dhcp_intfc_t *intfc;
	dhcp_pool_t *pools;
	list_t link;
};

struct _dhcp_message_t {
	uint8_t op;
	uint8_t htype;
	uint8_t hlen;
	uint8_t hops;
	uint32_t xid;
	uint16_t secs;
	uint16_t flags;
	uint32_t ciaddr;
	uint32_t yiaddr;
	uint32_t siaddr;
	uint32_t giaddr;
	uint8_t chaddr[16];
	uint8_t *sname;
	uint8_t *file;
	uint8_t *options;

	/* dhcp message type */
	dhcp_intfc_t *intfc;
	dhcp_network_t *shared_network;
	uint8_t message_type;
	dhcp_parse_t *universes;
	int universes_count;
};

/* ============================================================ *
 * server modes
 * ============================================================ */
#define DHCP_MODE_CLIENT	0x01	/* generic client */
#define DHCP_MODE_SERVER	0x02	/* generic server */
#define DHCP_MODE_RELAY		0x03	/* relay agent */

typedef struct _dhcp_mode_t {
	int mode;
	unsigned long flags;
#define DHCP_FLAG_START_DEVUP	0x00000001
#define DHCP_FLAG_START_DEVREG	0x00000002
	const char *name;
	uint16_t this_port;
	uint16_t peer_port;
	void (*process)(dhcp_intfc_t *intfc, msgbuf_t *msg);
	list_t link;
} dhcp_mode_t;

typedef struct _dhcp_channel_t {
	const char *name;
	int (*start)(dhcp_intfc_t *);
	void (*stop)(dhcp_intfc_t *);
	list_t link;
} dhcp_channel_t;

typedef struct _dhcp_profile_t {
	const char *name;

	atomic_t refcnt;

	ui_entry_t *cs;
	list_t link;
} dhcp_profile_t;

#define DHCP_SERVICE_NAME	"dhcp"

int dhcp_register_mode(dhcp_mode_t *mode);
void dhcp_unregister_mode(dhcp_mode_t *mode);

static inline dhcp_profile_t *dhcp_profile_get(dhcp_profile_t *profile)
{
	atomic_inc(&profile->refcnt);
	return profile;
}
static inline void dhcp_profile_put(dhcp_profile_t *profile)
{
	atomic_dec(&profile->refcnt);
}

int dhcp_register_universe(dhcp_universe_t *universe,
			   dhcp_option_t *options);
void dhcp_unregister_universe(dhcp_universe_t *universe,
			      dhcp_option_t *options);

#endif /* __DHCP_H_INCLUDE__ */
