#ifndef __MSCHAP_H_INCLUDE__
#define __MSCHAP_H_INCLUDE__

#include <sysdep.h>
#include <sha1.h>
#include <md4.h>

#define MSCHAP_CHALLENGE_LEN	8	/* Challenge length for MS-CHAP */
#define MSCHAP_RESPONSE_LEN	49	/* Response length for MS-CHAP */

/* E=eeeeeeeeee error codes for MS-CHAP failure messages. */
#define MSCHAP_ERROR_RESTRICTED_LOGON_HOURS	646
#define MSCHAP_ERROR_ACCT_DISABLED		647
#define MSCHAP_ERROR_PASSWD_EXPIRED		648
#define MSCHAP_ERROR_NO_DIALIN_PERMISSION	649
#define MSCHAP_ERROR_AUTHENTICATION_FAILURE	691
#define MSCHAP_ERROR_CHANGING_PASSWORD		709

/*
 * Offsets within the response field for MS-CHAP
 */
#define MSCHAP_RESP_LMPASS_OFF	0
#define MSCHAP_RESP_LMPASS_LEN	24
#define MSCHAP_RESP_NTPASS_OFF	24
#define MSCHAP_RESP_NTPASS_LEN	24
#define MSCHAP_RESP_USENT_OFF	48

const char *mschap_parse_failure(const uint8_t *p, size_t len,
				 int *ecode, int *retry,
				 char chal[MSCHAP_CHALLENGE_LEN],
				 int *chal_len, int *version);

void NtChallengeResponse(IN const uint8_t Challenge[MSCHAP_CHALLENGE_LEN],
			 IN const char *Password,
			 OUT uint8_t Response[MSCHAP_RESP_NTPASS_LEN]);
void LmChallengeResponse(IN const uint8_t Challenge[MSCHAP_CHALLENGE_LEN],
			 IN const char *Password,
			 OUT uint8_t Response[MSCHAP_RESP_LMPASS_LEN]);
void NtPasswordHash(IN const char *Password,
		    OUT uint8_t PasswordHash[MD4_DIGESTSIZE]);
void ChallengeResponse(IN const uint8_t Challenge[MSCHAP_CHALLENGE_LEN],
		       IN const uint8_t PasswordHash[MD4_DIGESTSIZE],
		       OUT uint8_t Response[24]);
void HashNtPasswordHash(IN const uint8_t PasswordHash[MD4_DIGESTSIZE],
			OUT uint8_t PasswordHashHash[MD4_DIGESTSIZE]);
void LmPasswordHash(IN const char *Password,
		    OUT uint8_t PasswordHash[MD4_DIGESTSIZE]);
void DesHash(IN const char Clear[7], OUT uint8_t *Cypher);
void DesEncrypt(IN const uint8_t *Clear, IN const char *Key,
		OUT uint8_t *Cipher);

#endif /* __MSCHAP_H_INCLUDE__ */
