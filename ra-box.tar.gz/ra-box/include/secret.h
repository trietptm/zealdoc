#ifndef __SECRET_H_INCLUDE__
#define __SECRET_H_INCLUDE__

#include <sysdep.h>

#define MAX_SECRET_LINE_LEN		128
#define MAX_SECRET_WORD_LEN		64
#define MAX_NAME_LEN			32
#define MAX_SECRET_LEN			MAX_SECRET_WORD_LEN

typedef void (*complete_cb)(void *ctx, int res);

/* FIXME: Delete this struct. So do not use this one. */
typedef struct _secret_t secret_t;
struct _secret_t {
	const char *host;
	const char *user;
	const char *passwd;
	char secret[MAX_SECRET_LEN];
	void *search;

	complete_cb complete;
	void *ctx;
};

/* call by outside */
void secret_search_stop(void *sear);
/* TODO: add type select(card/file/nac?) */
void *secret_search_start(const char *domain, const char *user,
			  const char *format, 
			  char *secret, void *ctx, complete_cb comp);

#endif /* __SECRET_H_INCLUDE__ */
