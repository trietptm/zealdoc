#ifndef __NET_DEV_H_INCLUDE__
#define __NET_DEV_H_INCLUDE__

#include <sysdep.h>
#include <notify.h>
#include <linux/if.h>

/* link type */
typedef struct _net_driver_t net_driver_t;
/* link device */
typedef struct _net_device_t net_device_t;

#define MAX_ADDR_LEN		32

/* ============================================================ *
 * L2-MAC definitions
 * ============================================================ */
struct _net_device_t {
	char ifname[IFNAMSIZ];
	int ifindex;

#ifdef WIN32
	/* used for pcap */
	char *device;
#endif
	char *kernel_driver;

	net_driver_t *link_driver;
	void *link_private;

	uint16_t mtu;		/* MTU */
	uint8_t operstate;	/* operstate */
	uint8_t link_mode;	/* mapping policy to operstate */
	uint32_t tx_queue_len;	/* TX queue length */
	uint32_t weight;
	unsigned int flags;
	/* hwaddr attrs */
	int addr_type;		/* equivlant to link_type */
	uint8_t dev_addr[MAX_ADDR_LEN];
	uint8_t broadcast[MAX_ADDR_LEN];	/* hw bcast add	*/

	ui_entry_t *cs;

	/* common object */
	atomic_t refcnt;	/* refcnt */
	list_t link;		/* link to management list */
	int closing : 1;	/* zombie flag */

	int ext_exist : 1;	/* added by exist */
	int user_entry : 1;	/* added by config entry */
	int link_ready : 1;	/* added by rtnl event */
	int link_down : 1;	/* set by link layer */
};

typedef struct _net_ifconf_t {
	const char *name;

	void (*set_addr)(net_device_t *dev,
			 uint8_t *addr, int alen);
	void (*set_bcast)(net_device_t *dev,
			  uint8_t *addr, int alen);
	void (*set_mtu)(net_device_t *dev, uint16_t mtu);
	void (*set_txqlen)(net_device_t *dev, uint32_t txqlen);
	void (*set_flags)(net_device_t *dev, uint32_t flags);
	void (*unset_flags)(net_device_t *dev, uint32_t flags);
} net_ifconf_t;

#ifdef CONFIG_ETHER_UNIT
#define NET_MAX_ETHER	CONFIG_ETHER_UNIT
#else
#define NET_MAX_ETHER	1
#endif

/* link type operations */
struct _net_driver_t {
	const char *name;
	const char *desc;

	const char *prefix;
	int addr_len;

	int flags;
#define NET_FLAG_MULTILINK	0x01

	int index_format;
#define NET_FORMAT_NONE		0	/* lo */
#define NET_FORMAT_ONE		1	/* eth0, ppp0 */
#define NET_FORMAT_TWO		2	/* eth0.0 */
	int max_index;
#define NET_INDEX_NONE		0

	/* active open / close
	 * driver object is not yet present, net_device layer call
	 * __net_device_create which will call driver specific open method
	 * in such case, driver object's state machine hasn't been
	 * started, open is to start the net_device's driver specific
	 * state machine
	 */
	void (*open)(net_device_t *dev);
	void (*close)(net_device_t *dev);

	list_t link;
};

/* net_device_t states */
#define NET_DEVICE_UNDEF	0x00
#define NET_DEVICE_CONFIG	0x01
#define NET_DEVICE_STARTED	0x03
#define NET_DEVICE_STOPPED	0x04

/* kernel like netdev notifier emulation */
/* add to net_devices */
#define NET_DEVICE_REGISTER	0x01
/* remove from net_devices */
#define NET_DEVICE_UNREGISTER	0x02
/* add to devfs */
#define NET_DEVICE_ADD		0x03
/* remove from sysfs */
#define NET_DEVICE_REMOVE	0x04
/* add IFF_UP flag */
#define NET_DEVICE_UP		0x05
/* remove IFF_UP flag */
#define NET_DEVICE_GOING_DOWN	0x06
#define NET_DEVICE_DOWN		0x07
/* MTU changed */
#define NET_DEVICE_CHANGEMTU	0x08
/* MAC address changed */
#define NET_DEVICE_CHANGEADDR	0x09
/* operstate changed */
#define NET_DEVICE_CHANGE	0x0a

int net_unregister_notify(notify_t *nb);
int net_register_notify(notify_t *nb);

net_device_t *net_device_get(net_device_t *dev);
void net_device_put(net_device_t *dev);
net_device_t *net_device_by_name(const char *ifname);
net_device_t *net_device_get_by_name(const char *ifname);
net_device_t *net_device_by_index(int ifindex);
net_device_t *net_device_get_by_index(int ifindex);
int net_device_notify(unsigned long val, void *v);
int net_device_state(net_device_t *dev);
net_device_t *net_device_create(const char *ifname,
				const char *kind);
void net_device_delete(net_device_t *dev);

/* net_device may be created by NETLINK message with net_device_new
 * functions offered here will help to call driver->open to complete
 * template based net_devices, such driver may call net_register_notify
 * waiting for such devices up
 * enable is a wrapper for driver->open & net_device_start
 */
int net_device_enable(net_device_t *dev, ui_entry_t *cs);

void *net_link_get(net_device_t *dev);
void net_link_set(net_device_t *dev, void *priv);

/* ============================================================ *
 * ioctl wrappers
 * ============================================================ */
unsigned int __net_device_index(int fd, net_device_t *dev);
int __net_device_set_addr(int s, net_device_t *dev,
			  uint8_t *addr, int alen);
int __net_device_set_bcast(int s, net_device_t *dev,
			   uint8_t *addr, int alen);
int __net_device_set_mtu(int s, net_device_t *dev,
			 uint16_t mtu);
int __net_device_set_txqlen(int s, net_device_t *dev,
			    uint32_t qlen);
int __net_device_change_flags(int s, net_device_t *dev,
			      uint32_t flags, uint32_t mask);
int __net_device_set_flags(int s, net_device_t *dev,
			   uint32_t flags);
int __net_device_unset_flags(int s, net_device_t *dev,
			     uint32_t flags);
int __net_device_up(int s, net_device_t *dev);
int __net_device_down(int s, net_device_t *dev);

/* ============================================================ *
 * netdev operations
 * ============================================================ */
void net_device_set_addr(net_device_t *dev,
			 uint8_t *addr, int alen);
void net_device_set_bcast(net_device_t *dev,
			  uint8_t *addr, int alen);
void net_device_set_mtu(net_device_t *dev, uint16_t mtu);
void net_device_set_txqlen(net_device_t *dev, uint32_t txqlen);
void net_device_set_flags(net_device_t *dev, uint32_t flags);
void net_device_unset_flags(net_device_t *dev, uint32_t flags);
void net_device_set_ops(net_ifconf_t *ops);
void net_device_unset_ops(net_ifconf_t *ops);
void net_device_set_hook(void (*hook)(net_device_t *));
void net_device_unset_hook(void);

void net_device_update(net_device_t *dev);
void net_device_up(net_device_t *dev);
void net_device_down(net_device_t *dev);
unsigned int net_device_index(net_device_t *dev);

const char *net_device_n2a(uint8_t *addr, int alen,
			   int type, char *buf, int blen);
int net_device_a2n(uint8_t *addr, int alen, const char *astr);
const char *net_device_state2name(int state);
const char *net_device_operstate2name(int operstate);
const char *net_device_flag2name(int flag);
int net_device_name2flag(const char *name);
const char *net_device_arphrd2name(int hrd);

/* ============================================================ *
 * driver operations
 * ============================================================ */
net_driver_t *net_driver_by_name(const char *name);
int net_register_driver(net_driver_t *driver);
void net_unregister_driver(net_driver_t *driver);
net_driver_t *net_iterate_driver(net_driver_t *driver);
/* for pcap_open */
const char *net_device_name(net_device_t *dev);

#ifdef WIN32
#include <nif_win32.h>
#endif

#endif /* __NET_DEV_H_INCLUDE__ */
