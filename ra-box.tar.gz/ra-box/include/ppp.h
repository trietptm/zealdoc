/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2008
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@gmail.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)ppp.h: point to point protocol externals
 * $Id: ppp.h,v 1.258 2009-02-24 07:42:11 zhenglv Exp $
 */

#ifndef __PPP_H_INCLUDE__
#define __PPP_H_INCLUDE__

#include <sysdep.h>
#include <notify.h>
#include <dfastm.h>
#include <netsvc.h>
#include <uiserv.h>
#include <list.h>
#include <service.h>
#include <net/ppp_defs.h>

#ifndef PPP_EAP
#define PPP_EAP		0xc227
#endif

#define MAXNAMELEN	256	/* max length of hostname or name for auth */

#define PPP_SERVICE_NAME	"ppp"

typedef struct _ppp_phase_t ppp_phase_t;
typedef struct _ppp_profile_t ppp_profile_t;
typedef struct _ppp_channel_t ppp_channel_t;

#include <ppp_auth.h>

/* This struct contains pointers to a set of procedures for
 * doing operations on a "channel".  A channel provides a way
 * to send and receive PPP packets - the canonical example is
 * a serial port device in PPP line discipline.
 */
struct _ppp_channel_t {
	/* channel name */
	const char *name;
	const char *desc;

	/* make outgoing PPP message */
	msgbuf_t *(*make_message)(ppp_phase_t *ctx);

	/* send outgoing PPP message */
	int (*send)(ppp_phase_t *ctx, msgbuf_t *msg);
	/* active open channel */
	int (*open)(ppp_phase_t *ctx);
	/* close channel */
	void (*close)(ppp_phase_t *ctx);

	/* control (set/get) supported PPP options */
	int (*set_recv_option)(ppp_phase_t *ctx, uint16_t protocol,
			       uint8_t option, void *arg);
	int (*get_recv_option)(ppp_phase_t *ctx, uint16_t protocol,
			       uint8_t option, void *arg);
	int (*set_send_option)(ppp_phase_t *ctx, uint16_t protocol,
			       uint8_t option, void *arg);
	int (*get_send_option)(ppp_phase_t *ctx, uint16_t protocol,
			       uint8_t option, void *arg);

	void (*nac_advance)(ppp_phase_t *phase, void *data);
	void (*nac_retreat)(ppp_phase_t *phase, void *data);
	list_t link;
};

struct _ppp_profile_t {
	ui_entry_t *cs;
	const char *name;

	int restart_timer;	/* restart timer */
	int max_terminate;	/* Max-Terminate */
	int max_configure;	/* Max-Configure */
	int max_failure;	/* Max-Failure */
	/* looped-back link can be worked out by LCP Magic-Number */
	int max_loopback;
	int listen_time;
	int channel_timeout;	/* wait lower timer */
	int request_timeout;	/* wait request timer */

	int debug_kernel;

	/* XXX: Hack on Pool only Backend
	 * this is not a good idea, backend should support auth-types,
	 * but since we only have an IP pool as local backend, we put
	 * flag here to allow PPP performing authentication by itself
	 * Note that PPP must call ppp_peer_updated when !auth_spoofing
	 * where a NAC request will be generated
	 */
	int auth_spoofing;
	int auth_mutual;
	/* XXX: Force for Server or Mutual Authentication enabled Client
	 * when PPP server or mutual authentication enabled client's auth-type
	 * was rejected, link will fail if auth_force is enabled
	 */
	int auth_force;

	ppp_channel_t *channel;

	atomic_t refcnt;
	
	const char *auth_domain;
	const char *auth_user;
	list_t link;
};

/* ============================================================ *
 * phase operations
 * ============================================================ */
ppp_phase_t *ppp_phase_get(ppp_phase_t *phase);
void ppp_phase_put(ppp_phase_t *phase);
void ppp_phase_delete(ppp_phase_t *phase);
ppp_phase_t *ppp_phase_create(int unit, int mode, ppp_profile_t *prof);
int ppp_phase_send(ppp_phase_t *ctx, msgbuf_t *msg, uint16_t proto);
int ppp_phase_recv(ppp_phase_t *ctx, msgbuf_t *msg);
msgbuf_t *ppp_phase_message(ppp_phase_t *ctx);

/* ============================================================ *
 * profile operations
 * ============================================================ */
static inline ppp_profile_t *ppp_profile_get(ppp_profile_t *profile)
{
	atomic_inc(&profile->refcnt);
	return profile;
}
static inline void ppp_profile_put(ppp_profile_t *profile)
{
	atomic_dec(&profile->refcnt);
}
void ppp_profile_free(ppp_profile_t *prof);

/* ============================================================ *
 * channel operations
 * ============================================================ */
int ppp_register_channel(ppp_channel_t *chan);
void ppp_unregister_channel(ppp_channel_t *chan);
ppp_channel_t *ppp_channel_by_name(const char *name);

/* ioctl interface, converted to negotiation options */
int ppp_channel_set_recv(ppp_phase_t *ctx, uint16_t protocol,
			 uint8_t option, void *arg);
int ppp_channel_get_recv(ppp_phase_t *ctx, uint16_t protocol,
			 uint8_t option, void *arg);
int ppp_channel_set_send(ppp_phase_t *ctx, uint16_t protocol,
		         uint8_t option, void *arg);
int ppp_channel_get_send(ppp_phase_t *ctx, uint16_t protocol,
		         uint8_t option, void *arg);

int ppp_channel_send(ppp_phase_t *phase, msgbuf_t *msg);
void ppp_channel_up(ppp_phase_t *ctx);
void ppp_channel_down(ppp_phase_t *ctx);
void ppp_channel_set_rname(ppp_phase_t *phase, const char *rname);
int ppp_unit_number(ppp_phase_t *phase);
int ppp_unit_descriptor(ppp_phase_t *phase);
int ppp_channel_index(ppp_phase_t *phase);
int ppp_channel_descriptor(ppp_phase_t *phase);
void ppp_channel_set(ppp_phase_t *phase, void *priv);
void *ppp_channel_get(ppp_phase_t *phase);

int ppp_unit_alloc(int unit_id);
void ppp_unit_free(int unit_id);
int ppp_unit_open(ppp_phase_t *phase);
void ppp_unit_close(ppp_phase_t *phase);
int ppp_channel_connect(ppp_phase_t *phase, int fd, int mru);
int ppp_channel_disconnect(ppp_phase_t *phase);

#endif /* __PPP_H_INCLUDE__ */
