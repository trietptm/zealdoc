/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2008
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@gmail.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)l2tp.h: layer-2 tunneling protocol externals
 * $Id: l2tp.h,v 1.249 2009-02-23 02:43:21 zhenglv Exp $
 */

#ifndef __L2TP_H_INCLUDE__
#define __L2TP_H_INCLUDE__

#ifdef __cplusplus
extern "C" {
#endif

#include <sysdep.h>
#include <list.h>
#include <md5.h>
#include <netsvc.h>

typedef struct _l2tp_xprt_t l2tp_xprt_t;
typedef struct _l2tp_tunnel_t l2tp_tunnel_t;
typedef struct _l2tp_session_t l2tp_session_t;
typedef struct _l2tp_profile_t l2tp_profile_t;

#define L2TP_SERVICE_NAME	"l2tp"
#define L2TP_SERVICE_DESC	"Layer-2 tunneling protocol"

#define L2TP_PORT		1701

#define L2TP_VERSION		0x0002
#define L2F_VERSION		0x0001

#define L2TP_VECTOR_LEN		MD5_DIGESTSIZE
#define L2TP_STRING_LEN		120

#define L2TP_NOTIFY_TUNNEL_OPEN		0x01
#define L2TP_NOTIFY_TUNNEL_CLOSE	0x02
#define L2TP_NOTIFY_TUNNEL_UP		0x03
#define L2TP_NOTIFY_TUNNEL_GOING_DOWN	0x04
#define L2TP_NOTIFY_TUNNEL_DOWN		0x05
#define L2TP_NOTIFY_SESSION_OPEN	0x06
#define L2TP_NOTIFY_SESSION_CLOSE	0x07
#define L2TP_NOTIFY_SESSION_UP		0x08
#define L2TP_NOTIFY_SESSION_GOING_DOWN	0x09
#define L2TP_NOTIFY_SESSION_DOWN	0x10

/* ============================================================ *
 * result & error codes
 * ============================================================ */
#define L2TP_RESULT_RESV		0
#define L2TP_RESULT_CLOSE		1
#define L2TP_RESULT_ERROR		2

/* StopCCN result codes */
#define L2TP_RESULT_EEXIST		3
#define L2TP_RESULT_EAUTHZ		4
#define L2TP_RESULT_EPROTO		5
#define L2TP_RESULT_EDOWN		6
#define L2TP_RESULT_EFINSM		7
#define L2TP_RESULT_STOPCCN_COUNT	8

/* CDN result codes */
#define L2TP_RESULT_EADMIN	3
#define L2TP_RESULT_ETNORES	4
#define L2TP_RESULT_EPNORES	5
#define L2TP_RESULT_EINVAL	6
#define L2TP_RESULT_ECARRIER	7
#define L2TP_RESULT_EBUSY	8
#define L2TP_RESULT_ETONE	9
#define L2TP_RESULT_ETIMEOUT	10
#define L2TP_RESULT_EFRAME	11
#define L2TP_RESULT_CDN_COUNT	12

#define L2TP_ERROR_NOERR	0
#define L2TP_ERROR_EFAULT	2
#define L2TP_ERROR_ERANGE	3
#define L2TP_ERROR_ENOMEM	4
#define L2TP_ERROR_EINVAL	5
#define L2TP_ERROR_EVNDOR	6
#define L2TP_ERROR_EBUSY	7
#define L2TP_ERROR_EMAVP	8

/* overall configuration */
typedef struct _l2tp_config_t {
	int wait_timeout;
	uint16_t protocol_ver;			/* Protocol Version */
#define L2TP_PROTOCOL_VER	0x0100
	uint16_t firmware_rev;			/* Firmware Revision */
#define L2TP_FIRMWARE_REV	0x0100		/* major 1, minor 0 */

	uint32_t framing_cap;			/* Framing Capabilities */
#define L2TP_FRAMING_ASYNC		0x00000002
#define L2TP_FRAMING_SYNC		0x00000001

	uint32_t bearer_cap;			/* Bearer Capabilities */
#define L2TP_BEARER_ANALOG		0x00000002
#define L2TP_BEARER_DIGITAL		0x00000001

	uint16_t receive_ws;			/* Receive Windows Size */
#define L2TP_MIN_RECEIVE_WS		1
#define L2TP_MAX_RECEIVE_WS		16

	uint16_t max_retrans;
	uint16_t retrans_cap;
/* retransmission cap MUST be no less than 8 seconds */

	uint16_t hello_interval;
} l2tp_config_t;

/* control connection configuration */
struct _l2tp_profile_t {
	const char *name;

	int mode;

	/* if challenge required */
	char *secret;
	int reorder_timeout;
	int auth_mode;

	/* flags */
	int hide_avps;		/* hide AVPs */
	int seq_required;

	ui_entry_t *cs;

	uint32_t minimum_bps;	/* Minimum BPS */
	uint32_t maximum_bps;	/* Maximum BPS */

	/* used for outgoing call */
	uint32_t addr;
	uint16_t port;

	atomic_t refcnt;
	list_t link;
};

/* tunnel mode */
#define L2TP_MODE_LNS		0x01
#define L2TP_MODE_LAC		0x02

/* call type */
#define L2TP_OUTGOING		0x01
#define L2TP_INCOMING		0x02

struct _l2tp_session_t {
	char *name;

	atomic_t refcnt;
	list_t link;
	int closing : 1;

	int side;
	int mode;

	unsigned long flags;
	int reorder_timeout;

	stm_instance_t *fsmi;		/* state machine instance */

	uint32_t call_ser_no;		/* Call Serial Number */

	uint32_t peer_addr;
	uint16_t peer_port;
	uint32_t this_addr;
	uint16_t this_port;

#define L2TP_SESSION_ID_NONE	0
	uint16_t peer_sid;		/* peer's session identifier */
	uint16_t this_sid;		/* local's session identifier */

	uint16_t this_tid;
	uint16_t peer_tid;

	uint16_t mru;
	uint16_t mtu;

	int seq_enabled : 1;

	uint16_t Nr;
	uint16_t Ns;

	uint16_t result;
	uint16_t error;

	int32_t this_phys_channel;		/* Physical Channel ID */
	int32_t peer_phys_channel;		/* Physical Channel ID */

	char sub_address[L2TP_STRING_LEN];	/* Sub Address */
	char called_number[L2TP_STRING_LEN];	/* Called Number */
	char calling_number[L2TP_STRING_LEN];	/* Calling Number */

	uint32_t bearer_type;			/* Bearer Type */
	uint32_t framing_type;			/* Framing Type */

	uint32_t tx_speed;			/* Tx Connect Speed */
	uint32_t rx_speed;			/* Rx Connect Speed */
#define L2TP_DEF_CONNECT_SPEED		1000000

	char priv_group[L2TP_STRING_LEN];	/* Private Group ID */

	/*===== interface between L2TP and transports =====*/
	l2tp_xprt_t *xprt;

	int data_fd;

	/* which NIC we are sending and receiving through? */
	nic_t *nic;

	/*===== interface between L2TP and PPP =====*/
	/* XXX: Referrence of PPP Phase
	 * no nic_t is referrenced, because PPP proxy may not contain a
	 * valid nic_t
	 */
	ppp_phase_t *phase;
	/* ensure no DOWN event sending to PPP before UP event*/
	int this_layer_up;

	/*===== interface between L2TP and RADIUS =====*/
	nac_client_t *nac_client;
};

/* call param, used as nic_param_t for NETDEV_FRONT */
typedef struct _l2tp_call_t {
	uint32_t peer_addr;
	uint16_t peer_port;
	uint16_t peer_sid;
	uint16_t this_tid;
	int mode;
	int side;
} l2tp_call_t;

/* APIs for PPPoL2TP */
#define L2TP_HEADER_CTRL_LEN		12
#define L2TP_HEADER_MAX_DATA_LEN	14
#define L2TP_HEADER_MIN_DATA_LEN	6

/* message types */
/* control connection management */
#define L2TP_MESSAGE_ZLB		0
#define L2TP_MESSAGE_SCCRQ		1
#define L2TP_MESSAGE_SCCRP		2
#define L2TP_MESSAGE_SCCCN		3
#define L2TP_MESSAGE_STOPCCN		4
#define L2TP_MESSAGE_HELLO		6

/* call management */
#define L2TP_MESSAGE_OCRQ		7
#define L2TP_MESSAGE_OCRP		8
#define L2TP_MESSAGE_OCCN		9
#define L2TP_MESSAGE_ICRQ		10
#define L2TP_MESSAGE_ICRP		11
#define L2TP_MESSAGE_ICCN		12
#define L2TP_MESSAGE_CDN		14

/* error reporting */
#define L2TP_MESSAGE_WEN		15

/* ppp session control */
#define L2TP_MESSAGE_SLI		16

#define L2TP_MESSAGE_DATA		0xffff

#define L2TP_MESSAGE_NUM_TYPES		17
#define L2TP_MESSAGE_ILLEGAL_TYPE	(uint16_t)(-1)

msgbuf_t *l2tp_make_message(int len, uint16_t type,
			    uint16_t tid, uint16_t sid);
l2tp_session_t *l2tp_session_by_phase(ppp_phase_t *phase);

int l2tp_channel_open(l2tp_session_t *session);
void l2tp_channel_close(l2tp_session_t *session);
int l2tp_channel_send(ppp_phase_t *phase, msgbuf_t *msg);

void l2tp_nac_open_client(l2tp_session_t *session);

/* ============================================================ *
 * tunnel operations
 * ============================================================ */
l2tp_tunnel_t *l2tp_tunnel_by_tid(uint16_t id);
l2tp_tunnel_t *l2tp_tunnel_by_xprt(l2tp_xprt_t *xprt);
l2tp_tunnel_t *l2tp_tunnel_by_peer(uint16_t id,
				   uint32_t peer_addr);
l2tp_tunnel_t *l2tp_tunnel_by_call(int side, uint16_t id,
				   uint32_t peer_addr);
int l2tp_tunnel_is_established(l2tp_tunnel_t *tunnel);
int l2tp_tunnel_header_len(void);

/* outgoing tunnel open */
uint16_t __l2tp_tunnel_outgoing(l2tp_profile_t *prof);
/* incoming tunnel open */
uint16_t __l2tp_tunnel_incoming(l2tp_profile_t *prof,
				nic_t *dev, uint16_t p_tid,
				uint32_t peer_addr,
				uint16_t peer_port,
				uint32_t this_addr);
/* close */
void __l2tp_tunnel_delete(l2tp_tunnel_t *tunnel);
int l2tp_tunnel_established(uint16_t tid);

#define L2TP_TUNNEL_REGISTER	0x01
#define L2TP_TUNNEL_UNREGISTER	0x02
#define L2TP_TUNNEL_ESTABLISH	0x03
#define L2TP_TUNNEL_DISTABLISH	0x04

int l2tp_register_notify(notify_t *nb);
int l2tp_unregister_notify(notify_t *nb);
int l2tp_tunnel_notify(unsigned long val, void *v);
l2tp_tunnel_t *l2tp_tunnel_get(l2tp_tunnel_t *tunnel);
void l2tp_tunnel_put(l2tp_tunnel_t *tunnel);

/* ============================================================ *
 * session operations
 * ============================================================ */
void l2tp_session_raise(l2tp_session_t *session, int event);
int l2tp_session_recv(l2tp_session_t *session, msgbuf_t *msg);

l2tp_session_t *l2tp_session_get(l2tp_session_t *sess);
void l2tp_session_put(l2tp_session_t *sess);
l2tp_session_t *l2tp_session_by_sid(uint16_t sid);
l2tp_session_t *l2tp_session_by_peer(uint16_t sid,
				     uint32_t addr, uint16_t port);

/* open */
uint16_t __l2tp_session_incoming(l2tp_tunnel_t *tunnel,
				 ppp_phase_t *phase,
				 uint16_t session_id);
uint16_t __l2tp_session_outgoing(l2tp_profile_t *prof, ppp_phase_t *phase);
void __l2tp_session_delete(l2tp_session_t *session);

void l2tp_session_advance(l2tp_session_t *session);
int l2tp_session_established(uint16_t sid);
int l2tp_session_is_established(l2tp_session_t *session);
int l2tp_channel_set_recv(l2tp_session_t *session,
			  uint16_t protocol,
			  uint8_t option_type,
			  void *arg);
int l2tp_channel_get_recv(l2tp_session_t *session,
			  uint16_t protocol,
			  uint8_t option_type,
			  void *arg);
int l2tp_channel_set_send(l2tp_session_t *session,
			  uint16_t protocol,
			  uint8_t option_type,
			  void *arg);
int l2tp_channel_get_send(l2tp_session_t *session,
			  uint16_t protocol,
			  uint8_t option_type,
			  void *arg);

/* ============================================================ *
 * profile operations
 * ============================================================ */
void l2tp_profile_free(l2tp_profile_t *prof);
l2tp_profile_t *l2tp_profile_get_by_name(const char *name);

int l2tp_name2authmode(const char *name);
int l2tp_name2mode(const char *name);
const char *l2tp_side2name(int side);
const char *l2tp_mode2name(int mode);

#ifdef __cplusplus
}
#endif

#endif
