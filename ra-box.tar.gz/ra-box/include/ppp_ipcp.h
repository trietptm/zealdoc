/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2005
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@hzcnc.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)ppp_ipcp.h: internet protocol control protocol interface
 * $Id: ppp_ipcp.h,v 1.33 2009-02-10 04:21:29 zhenglv Exp $
 */

#ifndef __PPP_IPCP_H_INCLUDE__
#define __PPP_IPCP_H_INCLUDE__

#include <ppp_nego.h>

#define IPCP_SERVICE_NAME	"ipcp"

/*
 * Options.
 */
#define IPCP_CI_ADDRS		1	/* IP-Addresses, oboseleted */
#define IPCP_CI_COMP		2	/* IP-Compression-Protocol */
#define	IPCP_CI_ADDR		3	/* IP-Address */

#define IPCP_CI_DNS1		129	/* Primary DNS value */
#define IPCP_CI_WINS1		130	/* Primary WINS value */
#define IPCP_CI_DNS2		131	/* Secondary DNS value */
#define IPCP_CI_WINS2		132	/* Secondary WINS value */

#define IPCP_MAX_STATES 16		/* see slcompress.h */

/* RFC1172 mode (0x0037) */
#define IPCP_VJ_COMP_OLD	0x0037
/* RFC1332 mode (0x002d), with Max-Slot-Id & Comp-Slot-Id */
#define IPCP_VJ_COMP		0x002d

typedef struct _ipcp_vjcomp_t {
	uint16_t vj_protocol;
	uint8_t max_slot_id;
	uint8_t comp_slot_id;
} ipcp_vjcomp_t;

#endif /* __PPP_IPCP_H_INCLUDE__ */
