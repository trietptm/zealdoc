#ifndef __NIF_WIN32_H_INCLUDE__
#define __NIF_WIN32_H_INCLUDE__

#include <sysdep.h>
#include <list.h>
#include <atomic.h>
#include <linux/if.h>

typedef struct _ext_device_t {
	char ifname[IFNAMSIZ];
	char *device;
	int ifindex;
	uint16_t mtu;
	uint8_t addr[16];
	int addr_len;
	atomic_t refcnt;
	list_t link;
	int flags;
} ext_device_t;

typedef struct _ext_ifaddr_t {
	char name[IFNAMSIZ];
	unsigned char flags;
	uint32_t local;
	uint32_t address;
	uint32_t netmask;
	int ifindex;
	atomic_t refcnt;
	list_t link;
} ext_ifaddr_t;

ext_device_t *ext_device_new(const char *ifname, uint8_t *addr,
			     int alen, int mtu);
ext_device_t *ext_device_hold(ext_device_t *dev);
void ext_device_free(ext_device_t *dev);

ext_ifaddr_t *ext_ifaddr_new(const char *label, int ifindex,
			     uint32_t addr, uint32_t netmask);
void ext_ifaddr_free(ext_ifaddr_t *ifa);
ext_ifaddr_t *ext_ifaddr_hold(ext_ifaddr_t *ifa);

#endif /* __NIF_WIN32_H_INCLUDE__ */
