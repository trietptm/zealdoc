#ifndef __VTSS_CONF_H_INCLUDE__
#define __VTSS_CONF_H_INCLUDE__

/* ================================================================= *
   Introduction:
   The API consists of a number of components. Each component may
   have its own source files, API and compile options. This file 
   describes each component briefly. Compile options for switch/PHY 
   API and the application component are also included.
   For other components, please refer to the API header files listed.
 * ================================================================= */

#ifdef CONFIG_VTSS_ROUTER_VLAN_LAN
#define VTSS_ROUTER_VLAN_LAN	CONFIG_VTSS_ROUTER_VLAN_LAN
#else
#define VTSS_ROUTER_VLAN_LAN	1
#endif

#ifdef CONFIG_VTSS_ROUTER_PORT_5_IF
#define VTSS_ROUTER_PORT_5_IF	CONFIG_VTSS_ROUTER_PORT_5_IF
#else
#define VTSS_ROUTER_PORT_5_IF	5
#endif

/* ================================================================= *
 *  Switch/PHY API options
 * ================================================================= */

#endif /* __VTSS_CONF_H_INCLUDE__ */
