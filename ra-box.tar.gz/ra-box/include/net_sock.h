#ifndef __NET_SOCK_H_INCLUDE__
#define __NET_SOCK_H_INCLUDE__

#define IN_PORT_ANY	0

uint8_t sockaddrlen(const struct sockaddr *sa);
struct sockaddr *sockaddrdup(struct sockaddr *src);
struct sockaddr *getlocaladdr(struct sockaddr *remote);
char *sockaddr2str(const struct sockaddr *saddr);
char *sockaddr2str_r(const struct sockaddr *saddr, char *buf, int len);

int recvfromto(int s, void *buf, size_t buflen, int flags,
	       struct sockaddr *from, socklen_t *fromlen,
	       struct sockaddr *to, socklen_t *tolen);
int sendfromto(int s, const void *buf, size_t buflen,
	       struct sockaddr *src, struct sockaddr *dst);
ssize_t sendtov(int s, struct iovec *iov, int iovcnt, size_t max,
		int flags, struct sockaddr *name, size_t namelen);
int sockaddrcmp_noport(const struct sockaddr *addr1,
		       const struct sockaddr *addr2);
int sockaddrcmp_port(const struct sockaddr *addr1,
		     const struct sockaddr *addr2);
int sockaddrcmp_wild(const struct sockaddr *addr1,
		     const struct sockaddr *addr2);
const struct sockaddr *sockaddrany(int family);

#endif /* __NET_SOCK_H_INCLUDE__ */
