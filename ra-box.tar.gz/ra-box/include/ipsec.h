#ifndef __IPSEC_H_INCLUDE__
#define __IPSEC_H_INCLUDE__

#include <sysdep.h>
#include <crypto.h>
#include <list.h>
#include <uiserv.h>

#include <ipsec_algo.h>
#include <ipsec_doi.h>
#include <oakley.h>

#define IPSEC_SERVICE_NAME	"ipsec"

typedef caddr_t ipsec_policy_t;

typedef struct _ipsec_config_t {
	int dummy;
} ipsec_config_t;

typedef struct _ipsec_profile_t {
	const char *name;
	int identity_only;
	int secrecy;
	int integrity;
	atomic_t refcnt;
	ui_entry_t *cs;
	list_t link;
} ipsec_profile_t;

typedef struct _ipsec_proposal_t {
	const char *name;
	uint32_t seconds;
	uint32_t kilobytes;
	uint8_t life_type;
	uint8_t group_desc;
	uint8_t encap_mode;
	uint8_t auth_algo;
	uint8_t key_length;
	uint8_t key_rounds;
	atomic_t refcnt;
	ui_entry_t *cs;
	list_t link;
} ipsec_proposal_t;

/* ============================================================ *
 * profile operations
 * ============================================================ */
ipsec_profile_t *ipsec_profile_get_by_name(const char *name);
void ipsec_profile_free(ipsec_profile_t *prof);

int ipsec_acquire(struct sockaddr *remote, struct sockaddr *local);

void ipsec_free_policy(ipsec_policy_t buf);
ipsec_policy_t ipsec_set_policy(const char *msg, int msglen);
int ipsec_set_bypass(int so, int family);
int ipsec_policy_len(ipsec_policy_t policy);

#endif /* __IPSEC_H_INCLUDE__ */
