#ifndef __IKE_H_INCLUDE__
#define __IKE_H_INCLUDE__

#include <sysdep.h>
#include <crypto.h>
#include <uiserv.h>
#include <list.h>
#include <isakmp.h>
#include <ipsec_doi.h>
#include <oakley.h>

#define IKE_SERVICE_NAME	"ike"

typedef struct _ike_config_t {
	int dummy;
} ike_config_t;

typedef struct _ike_proposal_t {
	const char *name;
	int prop_no;
	int trns_no;
	time_t lifetime;
	size_t lifekbytes;
	int enctype;
	int encklen;
	int authmethod;
	int hashtype;
	int vendorid;
	int dh_group;			/* don't use it if aggressive mode */
	oakley_group_t *dhgrp;		/* don't use it if aggressive mode */
	ui_entry_t *cs;
	atomic_t refcnt;
	list_t link;
} ike_proposal_t;

#endif /* __IKE_H_INCLUDE__ */
