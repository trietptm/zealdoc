#ifndef __NET_NIC_H_INCLUDE__
#define __NET_NIC_H_INCLUDE__

typedef struct _nic_family_t nic_family_t;

#define NIC_SERVICE_NAME	"nic"

#define NIC_UP			0x0001
#define NIC_DOWN		0x0002
#define NIC_GOING_DOWN		0x0003
#define NIC_REGISTER		0x0004
#define NIC_UNREGISTER		0x0005
#define NIC_CHANGEMTU		0x0006
#define NIC_INSERT		0x0007
#define NIC_DELETE		0x0008

/* ============================================================ *
 * interface definitions
 * ============================================================ */
typedef struct _nic_t {
	char name[IFNAMSIZ];
	net_device_t *dev;

	nic_family_t *family;

	int type;
#define NIC_UNDEF		0x00
	/* nac frontend dev */
#define NIC_FRONT		0x01
	/* nac backend dev */
#define NIC_BACK		0x02
#define NIC_HOST		NIC_BACK

	int link_ready : 1;
	int user_entry : 1;

	/* extra_data */
} nic_t;

struct _nic_family_t {
	int family;
	const char *name;
	const char *desc;
	int extra_size;

	nic_t *(*open)(const char *name, int type);
	void (*close)(nic_t *);
	nic_t *(*get)(nic_t *);
	void (*put)(nic_t *);
	nic_t *(*iter)(nic_t *);
	struct sockaddr *(*get_addr)(nic_t *);

	list_t link;
};

/* ============================================================ *
 * address notifiers
 * ============================================================ */
int nic_unregister_notify(notify_t *nb);
int nic_register_notify(notify_t *nb);
int nic_address_notify(unsigned long val, void *v);

/* ============================================================ *
 * address families
 * ============================================================ */
nic_family_t *nic_family_by_name(const char *name);
nic_family_t *nic_family_by_proto(int protocol);
void nic_unregister_family(nic_family_t *family);
int nic_register_family(nic_family_t *family);

/* ============================================================ *
 * interface operations
 * ============================================================ */
void nic_close(nic_t *dev);
nic_t *nic_open(const char *name, int family, int type);
nic_t *nic_get(nic_t *dev);
void nic_put(nic_t *dev);
nic_t *nic_new(const char *name, int family, int type);
void nic_free(nic_t *nic);

struct sockaddr *nic_sockaddr(nic_t *dev);

nic_t *nic_by_name(const char *name, int family);
nic_t *nic_by_sockaddr(struct sockaddr *addr);
nic_t *nic_get_by_name(const char *name, int family);
nic_t *nic_get_by_sockaddr(struct sockaddr *addr);

const char *nic_type2name(int type);

#endif /* __NET_NIC_H_INCLUDE__ */
