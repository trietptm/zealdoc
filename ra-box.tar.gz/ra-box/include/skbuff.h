#ifndef __SKBUFF_H_INCLUDE__
#define __SKBUFF_H_INCLUDE__

#include <sysdep.h>
#include <netsvc.h>
#include <atomic.h>
#include <bitops.h>
#include <panic.h>
#include <logger.h>
#include <list.h>

typedef struct _sk_buff_t sk_buff_t;
typedef struct _sk_page_t sk_page_t;

#define current_text_addr()	NULL

#define SKB_DATA_ALIGN(X)	(X)

#define SKB_PAGE_SIZE		(1<<12)

/* To allow 64K frame to be packed as single skb without frag_list */
#define MAX_SKB_FRAGS (65536/SKB_PAGE_SIZE + 2)

struct _sk_page_t {
	atomic_t _count;
};

typedef struct _skb_frag_t {
	sk_page_t *page;
	uint32_t page_offset;
	uint32_t size;
} skb_frag_t;

/* This data is invariant across clones and lives at
 * the end of the header data, ie. at skb->end.
 */
typedef struct _skb_shinfo_t {
	atomic_t	dataref;
	unsigned short	nr_frags;
	unsigned short	gso_size;
	/* Warning: this field is not always filled in (UFO)! */
	unsigned short	gso_segs;
	unsigned short  gso_type;
	uint16_t         ip6_frag_id;
	sk_buff_t	*frag_list;
	skb_frag_t	frags[MAX_SKB_FRAGS];
} skb_shinfo_t;

/* We divide dataref into two halves.  The higher 16 bits hold references
 * to the payload part of skb->data.  The lower 16 bits hold references to
 * the entire skb->data.  A clone of a headerless skb holds the length of
 * the header in skb->hdr_len.
 *
 * All users must obey the rule that the skb->data reference count must be
 * greater than or equal to the payload reference count.
 *
 * Holding a reference to the payload part means that the user does not
 * care about modifications to the header part of skb->data.
 */
#define SKB_DATAREF_SHIFT 16
#define SKB_DATAREF_MASK ((1 << SKB_DATAREF_SHIFT) - 1)


enum {
	SKB_FCLONE_UNAVAILABLE,
	SKB_FCLONE_ORIG,
	SKB_FCLONE_CLONE,
};

enum {
	SKB_GSO_TCPV4 = 1 << 0,
	SKB_GSO_UDP = 1 << 1,

	/* This indicates the skb is from an untrusted source. */
	SKB_GSO_DODGY = 1 << 2,

	/* This indicates the tcp segment has CWR set. */
	SKB_GSO_TCP_ECN = 1 << 3,

	SKB_GSO_TCPV6 = 1 << 4,
};

typedef unsigned char *sk_buff_data_t;

struct _sk_buff_t {
	/* These two members must be first. */
	sk_buff_t		*next;
	sk_buff_t		*prev;

	int			sk;
	time_t			tstamp;
	net_device_t		*dev;

	/*
	 * This is the control buffer. It is free to use for every
	 * layer. Please put your private variables there. If you
	 * want to keep them across layers you have to do a skb_clone()
	 * first. This is owned by whoever has the skb queued ATM.
	 */
	char			cb[48];

	unsigned int		len,
				data_len;
	uint16_t		mac_len,
				hdr_len;
	uint8_t			local_df:1,
				cloned:1,
				nohdr:1;
	uint8_t			pkt_type:3,
				fclone:2;
	uint16_t		protocol;

	void			(*destructor)(sk_buff_t *skb);

	int			iif;
	uint16_t		queue_mapping;

	/* 2 byte hole */

	uint32_t		mark;

	/* These elements must be at the end, see alloc_skb() for details.  */
	sk_buff_data_t		tail;
	sk_buff_data_t		end;
	unsigned char		*head,
				*data;
	unsigned int		truesize;
	atomic_t		users;
};

static inline void skb_get_page(sk_page_t *page)
{
	//page = compound_head(page);
	BUG_ON(atomic_read(&page->_count) == 0);
	atomic_inc(&page->_count);
}

static inline void skb_put_page(sk_page_t *page)
{
	atomic_dec(&page->_count);
}

void free_skb(sk_buff_t *skb);
void __kfree_skb(sk_buff_t *skb);
sk_buff_t *__alloc_skb(unsigned int size, int fclone);
static inline sk_buff_t *alloc_skb(unsigned int size)
{
	return __alloc_skb(size, 0);
}

static inline sk_buff_t *alloc_skb_fclone(unsigned int size)
{
	return __alloc_skb(size, 1);
}

void kfree_skbmem(sk_buff_t *skb);
sk_buff_t *skb_clone(sk_buff_t *skb);
sk_buff_t *skb_copy(const sk_buff_t *skb);
sk_buff_t *pskb_copy(sk_buff_t *skb);
int pskb_expand_head(sk_buff_t *skb, int nhead, int ntail);
sk_buff_t *skb_realloc_headroom(sk_buff_t *skb, unsigned int headroom);
sk_buff_t *skb_copy_expand(const sk_buff_t *skb,
			   int newheadroom, int newtailroom);
int skb_pad(sk_buff_t *skb, int pad);
void skb_over_panic(sk_buff_t *skb, int len, void *here);
void skb_under_panic(sk_buff_t *skb, int len, void *here);
void skb_truesize_bug(sk_buff_t *skb);

static inline unsigned char *skb_end_pointer(const sk_buff_t *skb)
{
	return skb->end;
}

/* Internal */
#define skb_shinfo(SKB)	((skb_shinfo_t *)(skb_end_pointer(SKB)))

/**
 *	skb_get - reference buffer
 *	@skb: buffer to reference
 *
 *	Makes another reference to a socket buffer and returns a pointer
 *	to the buffer.
 */
static inline sk_buff_t *skb_get(sk_buff_t *skb)
{
	atomic_inc(&skb->users);
	return skb;
}

/*
 * If users == 1, we are the only owner and are can avoid redundant
 * atomic change.
 */

/**
 *	skb_cloned - is the buffer a clone
 *	@skb: buffer to check
 *
 *	Returns true if the buffer was generated with skb_clone() and is
 *	one of multiple shared copies of the buffer. Cloned buffers are
 *	shared data so must not be written to under normal circumstances.
 */
static inline int skb_cloned(const sk_buff_t *skb)
{
	return skb->cloned &&
	       (atomic_read(&skb_shinfo(skb)->dataref) & SKB_DATAREF_MASK) != 1;
}

/**
 *	skb_header_cloned - is the header a clone
 *	@skb: buffer to check
 *
 *	Returns true if modifying the header part of the buffer requires
 *	the data to be copied.
 */
static inline int skb_header_cloned(const sk_buff_t *skb)
{
	int dataref;

	if (!skb->cloned)
		return 0;

	dataref = atomic_read(&skb_shinfo(skb)->dataref);
	dataref = (dataref & SKB_DATAREF_MASK) - (dataref >> SKB_DATAREF_SHIFT);
	return dataref != 1;
}

/**
 *	skb_header_release - release reference to header
 *	@skb: buffer to operate on
 *
 *	Drop a reference to the header part of the buffer.  This is done
 *	by acquiring a payload reference.  You must not read from the header
 *	part of skb->data after this.
 */
static inline void skb_header_release(sk_buff_t *skb)
{
	BUG_ON(skb->nohdr);
	skb->nohdr = 1;
	atomic_add(1 << SKB_DATAREF_SHIFT, &skb_shinfo(skb)->dataref);
}

/**
 *	skb_shared - is the buffer shared
 *	@skb: buffer to check
 *
 *	Returns true if more than one person has a reference to this
 *	buffer.
 */
static inline int skb_shared(const sk_buff_t *skb)
{
	return atomic_read(&skb->users) != 1;
}

/**
 *	skb_share_check - check if buffer is shared and if so clone it
 *	@skb: buffer to check
 *	@pri: priority for memory allocation
 *
 *	If the buffer is shared the buffer is cloned and the old copy
 *	drops a reference. A new clone with a single reference is returned.
 *	If the buffer is not shared the original buffer is returned. When
 *	being called from interrupt status or with spinlocks held pri must
 *	be GFP_ATOMIC.
 *
 *	NULL is returned on a memory allocation failure.
 */
static inline sk_buff_t *skb_share_check(sk_buff_t *skb)
{
	if (skb_shared(skb)) {
		sk_buff_t *nskb = skb_clone(skb);
		free_skb(skb);
		skb = nskb;
	}
	return skb;
}

/*
 *	Copy shared buffers into a new sk_buff. We effectively do COW on
 *	packets to handle cases where we have a local reader and forward
 *	and a couple of other messy ones. The normal one is tcpdumping
 *	a packet thats being forwarded.
 */

/**
 *	skb_unshare - make a copy of a shared buffer
 *	@skb: buffer to check
 *	@pri: priority for memory allocation
 *
 *	If the socket buffer is a clone then this function creates a new
 *	copy of the data, drops a reference count on the old copy and returns
 *	the new copy with the reference count at 1. If the buffer is not a clone
 *	the original buffer is returned. When called with a spinlock held or
 *	from interrupt state @pri must be %GFP_ATOMIC
 *
 *	%NULL is returned on a memory allocation failure.
 */
static inline sk_buff_t *skb_unshare(sk_buff_t *skb)
{
	if (skb_cloned(skb)) {
		sk_buff_t *nskb = skb_copy(skb);
		free_skb(skb);	/* Free our shared copy */
		skb = nskb;
	}
	return skb;
}

static inline int skb_is_nonlinear(const sk_buff_t *skb)
{
	return skb->data_len;
}

static inline unsigned int skb_headlen(const sk_buff_t *skb)
{
	return skb->len - skb->data_len;
}

#define SKB_PAGE_ASSERT(skb) 	BUG_ON(skb_shinfo(skb)->nr_frags)
#define SKB_FRAG_ASSERT(skb) 	BUG_ON(skb_shinfo(skb)->frag_list)
#define SKB_LINEAR_ASSERT(skb)  BUG_ON(skb_is_nonlinear(skb))

static inline unsigned char *skb_tail_pointer(const sk_buff_t *skb)
{
	return skb->tail;
}

static inline void skb_reset_tail_pointer(sk_buff_t *skb)
{
	skb->tail = skb->data;
}

static inline void skb_set_tail_pointer(sk_buff_t *skb, const int offset)
{
	skb->tail = skb->data + offset;
}

/*
 *	Add data to an sk_buff
 */
static inline unsigned char *__skb_put(sk_buff_t *skb, unsigned int len)
{
	unsigned char *tmp = skb_tail_pointer(skb);
	SKB_LINEAR_ASSERT(skb);
	skb->tail += len;
	skb->len  += len;
	return tmp;
}

/**
 *	skb_put - add data to a buffer
 *	@skb: buffer to use
 *	@len: amount of data to add
 *
 *	This function extends the used data area of the buffer. If this would
 *	exceed the total buffer size the kernel will panic. A pointer to the
 *	first byte of the extra data is returned.
 */
static inline unsigned char *skb_put(sk_buff_t *skb, unsigned int len)
{
	unsigned char *tmp = skb_tail_pointer(skb);
	SKB_LINEAR_ASSERT(skb);
	skb->tail += len;
	skb->len  += len;
	if (skb->tail > skb->end)
		skb_over_panic(skb, len, current_text_addr());
	return tmp;
}

static inline unsigned char *__skb_push(sk_buff_t *skb, unsigned int len)
{
	skb->data -= len;
	skb->len  += len;
	return skb->data;
}

/**
 *	skb_push - add data to the start of a buffer
 *	@skb: buffer to use
 *	@len: amount of data to add
 *
 *	This function extends the used data area of the buffer at the buffer
 *	start. If this would exceed the total buffer headroom the kernel will
 *	panic. A pointer to the first byte of the extra data is returned.
 */
static inline unsigned char *skb_push(sk_buff_t *skb, unsigned int len)
{
	skb->data -= len;
	skb->len  += len;
	if (skb->data<skb->head)
		skb_under_panic(skb, len, current_text_addr());
	return skb->data;
}

static inline unsigned char *__skb_pull(sk_buff_t *skb, unsigned int len)
{
	skb->len -= len;
	BUG_ON(skb->len < skb->data_len);
	return skb->data += len;
}

/**
 *	skb_pull - remove data from the start of a buffer
 *	@skb: buffer to use
 *	@len: amount of data to remove
 *
 *	This function removes data from the start of a buffer, returning
 *	the memory to the headroom. A pointer to the next data in the buffer
 *	is returned. Once the data has been pulled future pushes will overwrite
 *	the old data.
 */
static inline unsigned char *skb_pull(sk_buff_t *skb, unsigned int len)
{
	return (len > skb->len) ? NULL : __skb_pull(skb, len);
}

unsigned char *__pskb_pull_tail(sk_buff_t *skb, int delta);

static inline unsigned char *__pskb_pull(sk_buff_t *skb, unsigned int len)
{
	if (len > skb_headlen(skb) &&
	    !__pskb_pull_tail(skb, len-skb_headlen(skb)))
		return NULL;
	skb->len -= len;
	return skb->data += len;
}

static inline unsigned char *pskb_pull(sk_buff_t *skb, unsigned int len)
{
	return (len > skb->len) ? NULL : __pskb_pull(skb, len);
}

static inline int pskb_may_pull(sk_buff_t *skb, unsigned int len)
{
	if (len <= skb_headlen(skb))
		return 1;
	if (len > skb->len)
		return 0;
	return __pskb_pull_tail(skb, len-skb_headlen(skb)) != NULL;
}

/**
 *	skb_headroom - bytes at buffer head
 *	@skb: buffer to check
 *
 *	Return the number of bytes of free space at the head of an &sk_buff.
 */
static inline int skb_headroom(const sk_buff_t *skb)
{
	return skb->data - skb->head;
}

/**
 *	skb_tailroom - bytes at buffer end
 *	@skb: buffer to check
 *
 *	Return the number of bytes of free space at the tail of an sk_buff
 */
static inline int skb_tailroom(const sk_buff_t *skb)
{
	return skb_is_nonlinear(skb) ? 0 : skb->end - skb->tail;
}

/**
 *	skb_reserve - adjust headroom
 *	@skb: buffer to alter
 *	@len: bytes to move
 *
 *	Increase the headroom of an empty &sk_buff by reducing the tail
 *	room. This is only allowed for an empty buffer.
 */
static inline void skb_reserve(sk_buff_t *skb, int len)
{
	skb->data += len;
	skb->tail += len;
}

int ___pskb_trim(sk_buff_t *skb, unsigned int len);

static inline void __skb_trim(sk_buff_t *skb, unsigned int len)
{
	if (skb->data_len) {
		return;
	}
	skb->len = len;
	skb_set_tail_pointer(skb, len);
}

/**
 *	skb_trim - remove end from a buffer
 *	@skb: buffer to alter
 *	@len: new length
 *
 *	Cut the length of a buffer down by removing data from the tail. If
 *	the buffer is already under the length specified it is not modified.
 *	The skb must be linear.
 */
static inline void skb_trim(sk_buff_t *skb, unsigned int len)
{
	if (skb->len > len)
		__skb_trim(skb, len);
}


static inline int __pskb_trim(sk_buff_t *skb, unsigned int len)
{
	if (skb->data_len)
		return ___pskb_trim(skb, len);
	__skb_trim(skb, len);
	return 0;
}

static inline int pskb_trim(sk_buff_t *skb, unsigned int len)
{
	return (len < skb->len) ? __pskb_trim(skb, len) : 0;
}

/**
 *	pskb_trim_unique - remove end from a paged unique (not cloned) buffer
 *	@skb: buffer to alter
 *	@len: new length
 *
 *	This is identical to pskb_trim except that the caller knows that
 *	the skb is not cloned so we should never get an error due to out-
 *	of-memory.
 */
static inline void pskb_trim_unique(sk_buff_t *skb, unsigned int len)
{
	int err = pskb_trim(skb, len);
	BUG_ON(err);
}

/**
 *	skb_orphan - orphan a buffer
 *	@skb: buffer to orphan
 *
 *	If a buffer currently has an owner then we call the owner's
 *	destructor function and make the @skb unowned. The buffer continues
 *	to exist but is no longer charged to its former owner.
 */
static inline void skb_orphan(sk_buff_t *skb)
{
	if (skb->destructor)
		skb->destructor(skb);
	skb->destructor = NULL;
	skb->sk		= -1;
}

static inline int __skb_linearize(sk_buff_t *skb)
{
	return __pskb_pull_tail(skb, skb->data_len) ? 0 : -ENOMEM;
}

/**
 *	skb_linearize - convert paged skb to linear one
 *	@skb: buffer to linarize
 *
 *	If there is no free memory -ENOMEM is returned, otherwise zero
 *	is returned and the old skb data released.
 */
static inline int skb_linearize(sk_buff_t *skb)
{
	return skb_is_nonlinear(skb) ? __skb_linearize(skb) : 0;
}

int skb_copy_bits(const sk_buff_t *skb, int offset,
		  void *to, int len);
int skb_store_bits(sk_buff_t *skb, int offset,
		   const void *from, int len);

static inline void *skb_header_pointer(const sk_buff_t *skb, int offset,
				       int len, void *buffer)
{
	int hlen = skb_headlen(skb);

	if (hlen - offset >= len)
		return skb->data + offset;

	if (skb_copy_bits(skb, offset, buffer, len) < 0)
		return NULL;

	return buffer;
}

static inline void skb_copy_from_linear_data(const sk_buff_t *skb,
					     void *to,
					     const unsigned int len)
{
	memcpy(to, skb->data, len);
}

static inline void skb_copy_from_linear_data_offset(const sk_buff_t *skb,
						    const int offset, void *to,
						    const unsigned int len)
{
	memcpy(to, skb->data + offset, len);
}

static inline void skb_copy_to_linear_data(sk_buff_t *skb,
					   const void *from,
					   const unsigned int len)
{
	memcpy(skb->data, from, len);
}

static inline void skb_copy_to_linear_data_offset(sk_buff_t *skb,
						  const int offset,
						  const void *from,
						  const unsigned int len)
{
	memcpy(skb->data + offset, from, len);
}

#endif /* __SKBUFF_H_INCLUDE__ */
