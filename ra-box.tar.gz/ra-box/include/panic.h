#ifndef __PANIC_H_INCLUDE__
#define __PANIC_H_INCLUDE__

#include <sysdep.h>
#include <logger.h>

void __panic(const char *file, int line);

#define panic()		__panic(__FILE__, __LINE__)
#ifdef NDEBUG
#define BUG_ON(expr)	do { if (expr) panic(); } while (0)
#else
#define BUG_ON(expr)	assert(!(expr))
#endif
#define BUG()		panic()

#define BUG_TRAP(x) do { \
	if (!(x)) { \
		log_kern(LOG_ERR, \
			 "KERN: assertion (%s) failed, file=%s, line=%d", \
			 #x,  __FILE__ , __LINE__); \
	} \
} while(0)

#endif /* __PANIC_H_INCLUDE__ */

