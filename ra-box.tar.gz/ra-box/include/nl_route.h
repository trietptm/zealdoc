#ifndef __NL_ROUTE_H__
#define __NL_ROUTE_H__

#include <limits.h>
#include <sysdep.h>
#include <list.h>
#include <dfastm.h>
#include <eloop.h>
#include <syslog.h>
#include <uiserv.h>
#include <errno.h>
#include <strutl.h>
#include <netsvc.h>
#include <logger.h>

#include <ppp.h>
#include <ppp_ipcp.h>
/* ============================================================ *
 * logging operations
 * ============================================================ */
#define NETLINK_LOG_CRIT		LOG_EMERG
#define NETLINK_LOG_FAIL		LOG_CRIT
#define NETLINK_LOG_ERR			LOG_ERR
#define NETLINK_LOG_WARN		LOG_WARNING
#define NETLINK_LOG_INFO		LOG_INFO
#define NETLINK_LOG_DEBUG		LOG_DEBUG

typedef struct _netlink_type_t netlink_type_t;
typedef struct _netlink_subtype_t netlink_subtype_t;

struct _netlink_type_t {
	uint8_t type;
#define NL_TYPE_ROUTE		0x01
#define NL_TYPE_FIREWALL	0x02
/* and so on */
	const char *name;
	
	bool (*init)(netlink_subtype_t *subtype);
	void (*exit)(netlink_subtype_t *subtype);
	/* open socket with type and bind with peer addr */
	list_t link;
};

struct _netlink_subtype_t {
	void	*sub;
};

void netlink_log(int level, const char *format, ...);
netlink_type_t *netlink_allowType(uint8_t code);

int netlink_register_type(netlink_type_t *type);
void netlink_unregister_type(netlink_type_t *type);

#endif /* __NL_ROUTE_H__ */
