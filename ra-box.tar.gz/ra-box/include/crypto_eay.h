#ifndef __CRYPTO_EAY_H_INCLUDE__
#define __CRYPTO_EAY_H_INCLUDE__

#include <sysdep.h>
#include <vchar.h>
#include <list.h>
#include <openssl/opensslv.h>
#include <openssl/pem.h>
#include <openssl/evp.h>
#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/x509_vfy.h>
#include <openssl/bn.h>
#include <openssl/dh.h>
#include <openssl/md5.h>
#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/des.h>
#include <openssl/crypto.h>
#include <openssl/blowfish.h>
#include <openssl/cast.h>
#include <openssl/err.h>
#include <openssl/rc5.h>
#include <openssl/idea.h>
#include <openssl/aes.h>
#include <openssl/rsa.h>

typedef struct _crypto_hmac_t {
	char *name;
	int type;
	caddr_t (*init)(vchar_t *);
	void (*update)(caddr_t, vchar_t *);
	vchar_t *(*final)(caddr_t);
	int (*hashlen)(void);
	vchar_t *(*one)(vchar_t *, vchar_t *);
} crypto_hmac_t;

typedef struct _crypto_hash_t {
	char *name;
	int type;
	caddr_t (*init)(void);
	void (*update)(caddr_t, vchar_t *);
	vchar_t *(*final)(caddr_t);
	int (*hashlen)(void);
	vchar_t *(*one)(vchar_t *);
} crypto_hash_t;

typedef struct _crypto_cipher_t {
	char *name;
	int type;
	int blocklen;
	vchar_t *(*encrypt)(vchar_t *, vchar_t *, vchar_t *);
	vchar_t *(*decrypt)(vchar_t *, vchar_t *, vchar_t *);
	int (*weakkey)(vchar_t *);
	int (*keylen)(int);
} crypto_cipher_t;

#define GENT_OTHERNAME	GEN_OTHERNAME
#define GENT_EMAIL	GEN_EMAIL
#define GENT_DNS	GEN_DNS
#define GENT_X400	GEN_X400
#define GENT_DIRNAME	GEN_DIRNAME
#define GENT_EDIPARTY	GEN_EDIPARTY
#define GENT_URI	GEN_URI
#define GENT_IPADD	GEN_IPADD
#define GENT_RID	GEN_RID

int eay_v2bn(BIGNUM **, vchar_t *);
int eay_bn2v(vchar_t **, BIGNUM *);

/* RNG */
vchar_t *eay_set_random(u_int32_t);
u_int32_t eay_random(void);

char *eay_strerror(void);

/* DH */
int eay_dh_generate(vchar_t *, u_int32_t, u_int,
		    vchar_t **, vchar_t **);
int eay_dh_compute(vchar_t *, u_int32_t, vchar_t *,
		   vchar_t *, vchar_t *, vchar_t **);

/* Base 64 */
vchar_t *base64_encode(char *in, long inlen);
vchar_t *base64_decode(char *in, long inlen);

RSA *base64_pubkey2rsa(char *in);
RSA *bignum_pubkey2rsa(BIGNUM *in);

/* hash */
/* HMAC SHA2 */
extern vchar_t *eay_hmacsha2_512_one(vchar_t *, vchar_t *);
extern caddr_t eay_hmacsha2_512_init(vchar_t *);
extern void eay_hmacsha2_512_update(caddr_t, vchar_t *);
extern vchar_t *eay_hmacsha2_512_final(caddr_t);
#if defined(WITH_SHA2)
extern vchar_t *eay_hmacsha2_384_one(vchar_t *, vchar_t *);
extern caddr_t eay_hmacsha2_384_init(vchar_t *);
extern void eay_hmacsha2_384_update(caddr_t, vchar_t *);
extern vchar_t *eay_hmacsha2_384_final(caddr_t);
#endif
extern vchar_t *eay_hmacsha2_256_one(vchar_t *, vchar_t *);
extern caddr_t eay_hmacsha2_256_init(vchar_t *);
extern void eay_hmacsha2_256_update(caddr_t, vchar_t *);
extern vchar_t *eay_hmacsha2_256_final(caddr_t);

/* HMAC SHA1 */
vchar_t *eay_hmacsha1_one(vchar_t *, vchar_t *);
caddr_t eay_hmacsha1_init(vchar_t *);
void eay_hmacsha1_update(caddr_t, vchar_t *);
vchar_t *eay_hmacsha1_final(caddr_t);

/* HMAC MD5 */
vchar_t *eay_hmacmd5_one(vchar_t *, vchar_t *);
caddr_t eay_hmacmd5_init(vchar_t *);
void eay_hmacmd5_update(caddr_t, vchar_t *);
vchar_t *eay_hmacmd5_final(caddr_t);

/* SHA2 functions */
caddr_t eay_sha2_512_init(void);
void eay_sha2_512_update(caddr_t, vchar_t *);
vchar_t *eay_sha2_512_final(caddr_t);
vchar_t *eay_sha2_512_one(vchar_t *);
int eay_sha2_512_hashlen(void);

#if defined(WITH_SHA2)
caddr_t eay_sha2_384_init(void);
void eay_sha2_384_update(caddr_t, vchar_t *);
vchar_t *eay_sha2_384_final(caddr_t);
vchar_t *eay_sha2_384_one(vchar_t *);
#endif
int eay_sha2_384_hashlen(void);

caddr_t eay_sha2_256_init(void);
void eay_sha2_256_update(caddr_t, vchar_t *);
vchar_t *eay_sha2_256_final(caddr_t);
vchar_t *eay_sha2_256_one(vchar_t *);
int eay_sha2_256_hashlen(void);

/* SHA functions */
caddr_t eay_sha1_init(void);
void eay_sha1_update(caddr_t, vchar_t *);
vchar_t *eay_sha1_final(caddr_t);
vchar_t *eay_sha1_one(vchar_t *);
int eay_sha1_hashlen(void);

/* MD5 functions */
caddr_t eay_md5_init(void);
void eay_md5_update(caddr_t, vchar_t *);
vchar_t *eay_md5_final(caddr_t);
vchar_t *eay_md5_one(vchar_t *);
int eay_md5_hashlen(void);

int eay_null_keylen(int);
int eay_null_hashlen(void);
int eay_kpdk_hashlen(void);

/* 3DES */
vchar_t *eay_3des_encrypt(vchar_t *, vchar_t *, vchar_t *);
vchar_t *eay_3des_decrypt(vchar_t *, vchar_t *, vchar_t *);
int eay_3des_weakkey(vchar_t *);
int eay_3des_keylen(int);

/* blowfish */
vchar_t *eay_bf_encrypt(vchar_t *, vchar_t *, vchar_t *);
vchar_t *eay_bf_decrypt(vchar_t *, vchar_t *, vchar_t *);
int eay_bf_weakkey(vchar_t *);
int eay_bf_keylen(int);

/* RC5 */
vchar_t *eay_rc5_encrypt(vchar_t *, vchar_t *, vchar_t *);
vchar_t *eay_rc5_decrypt(vchar_t *, vchar_t *, vchar_t *);
int eay_rc5_weakkey(vchar_t *);
int eay_rc5_keylen(int);

/* IDEA */
vchar_t *eay_idea_encrypt(vchar_t *, vchar_t *, vchar_t *);
vchar_t *eay_idea_decrypt(vchar_t *, vchar_t *, vchar_t *);
int eay_idea_weakkey(vchar_t *);
int eay_idea_keylen(int);

/* CAST */
vchar_t *eay_cast_encrypt(vchar_t *, vchar_t *, vchar_t *);
vchar_t *eay_cast_decrypt(vchar_t *, vchar_t *, vchar_t *);
int eay_cast_weakkey(vchar_t *);
int eay_cast_keylen(int);

/* AES(RIJNDAEL) */
vchar_t *eay_aes_encrypt(vchar_t *, vchar_t *, vchar_t *);
vchar_t *eay_aes_decrypt(vchar_t *, vchar_t *, vchar_t *);
int eay_aes_weakkey(vchar_t *);
int eay_aes_keylen(int);

/* DES */
vchar_t *eay_des_encrypt(vchar_t *, vchar_t *, vchar_t *);
vchar_t *eay_des_decrypt(vchar_t *, vchar_t *, vchar_t *);
int eay_des_weakkey(vchar_t *);
int eay_des_keylen(int len);

/* RSA */
vchar_t *eay_rsa_sign(vchar_t *, RSA *);
int eay_rsa_verify(vchar_t *, vchar_t *, RSA *);
int eay_check_rsasign(vchar_t *source, vchar_t *sig, RSA *rsa);
vchar_t *eay_get_rsasign(vchar_t *src, RSA *rsa);

vchar_t *evp_crypt(vchar_t *data, vchar_t *key,
		   vchar_t *iv, const EVP_CIPHER *e, int enc);
int evp_weakkey(vchar_t *key, const EVP_CIPHER *e);
int evp_keylen(int len, const EVP_CIPHER *e);
		   
vchar_t *eay_str2asn1dn(const char *str, int len);
vchar_t *eay_hex2asn1dn(const char *hex, int len);
int eay_cmp_asn1dn(vchar_t *n1, vchar_t *n2);

int eay_check_x509cert(vchar_t *cert, char *CApath,
		       char *CAfile, int local);
vchar_t *eay_get_x509asn1subjectname(vchar_t *cert);
int eay_get_x509subjectaltname(vchar_t *cert, char **altname,
			       int *type, int pos);
char *eay_get_x509text(vchar_t *cert);
vchar_t *eay_get_x509cert(const char *path);
int eay_check_x509sign(vchar_t *source, vchar_t *sig, vchar_t *cert);
vchar_t *eay_get_x509sign(vchar_t *src, vchar_t *privkey);

vchar_t *eay_get_pkcs1privkey(const char *path);
vchar_t *eay_get_pkcs1pubkey(const char *path);

void crypto_rand_seed(const void *data, size_t size);
uint32_t crypto_rand_number(void);
void crypto_rand_bytes(uint8_t *buf, size_t len);

#ifdef CONFIG_CRYPTO
int crypto_start(void);
void crypto_stop(void);
#else
static inline int crypto_start(void) { return 0; }
static inline void crypto_stop(void) {}
#endif

#endif /* __CRYPTO_EAY_H_INCLUDE__ */
