#ifndef __AFNL_WIN32_H_INCLUDE__
#define __AFNL_WIN32_H_INCLUDE__

#define NETLINK_ROUTE_PORT		54324
#define NETLINK_KOBJECT_UEVENT_PORT	54323

typedef struct _netlink_sock_t netlink_sock_t;

struct _netlink_sock_t {
	/* struct sock has to be the first member of netlink_sock */
	int sock;
	int protocol;
	netlink_callback_t *cb;
	int (*data_ready)(struct nlmsghdr *, struct sockaddr_in *,
			  netlink_sock_t *);
	list_t mc_list;
	list_t link;
};

int nlmsg_notify(netlink_sock_t *sk, msgbuf_t *skb, uint32_t pid,
		 unsigned int group, int report);

void netlink_kernel_destroy(netlink_sock_t *nlk);
netlink_sock_t *netlink_kernel_create(int unit, unsigned int groups,
				      int (*input)(struct nlmsghdr *,
						   struct sockaddr_in *,
						   netlink_sock_t *));
int netlink_dump_start(netlink_sock_t *nlk,
		       struct sockaddr_in *addr,
		       struct nlmsghdr *nlh,
		       int (*dump)(msgbuf_t *skb, netlink_callback_t *),
		       int (*done)(netlink_callback_t *));
int netlink_broadcast(netlink_sock_t *sk, msgbuf_t *skb,
		      uint32_t pid, uint32_t group);
int netlink_unicast(netlink_sock_t *sk, msgbuf_t *skb,
		    uint32_t pid);
uint16_t netlink_unit2port(int unit);

/**
 * nlmsg_multicast - multicast a netlink message
 * @sk: netlink socket to spread messages to
 * @skb: netlink message as socket buffer
 * @pid: own netlink pid to avoid sending to yourself
 * @group: multicast group id
 * @flags: allocation flags
 */
static inline int nlmsg_multicast(netlink_sock_t *sk, msgbuf_t *skb,
				  uint32_t pid, unsigned int group)
{
	int err;
	err = netlink_broadcast(sk, skb, pid, group);
	if (err > 0)
		err = 0;
	return err;
}

/**
 * nlmsg_unicast - unicast a netlink message
 * @sk: netlink socket to spread message to
 * @skb: netlink message as socket buffer
 * @pid: netlink pid of the destination socket
 */
static inline int nlmsg_unicast(netlink_sock_t *sk, msgbuf_t *skb,
				uint32_t pid)
{
	int err;
	err = netlink_unicast(sk, skb, pid);
	if (err > 0)
		err = 0;
	return err;
}

#endif /* __AFNL_WIN32_H_INCLUDE__ */
