#ifndef __IPSEC_ALGO_H_INCLUDE__
#define __IPSEC_ALGO_H_INCLUDE__

#include <sysdep.h>
#include <oakley.h>

/* algorithm class */
enum {
	algclass_ipsec_enc,
	algclass_ipsec_auth,
	algclass_ipsec_comp,
	algclass_isakmp_enc,
	algclass_isakmp_hash,
	algclass_isakmp_dh,
	algclass_isakmp_ameth,	/* authentication method. */
#define MAXALGCLASS	7
};

#define ALG_DEFAULT_KEYLEN	64

#define ALGTYPE_NOTHING		0

/* algorithm type */
enum algtype {
	algtype_nothing = 0,

	/* enc */
	algtype_des_iv64,
	algtype_des,
	algtype_3des,
	algtype_rc5,
	algtype_idea,
	algtype_cast128,
	algtype_blowfish,
	algtype_3idea,
	algtype_des_iv32,
	algtype_rc4,
	algtype_null_enc,
	algtype_aes,
	algtype_twofish,
	algtype_camellia,

	/* ipsec auth */
	algtype_hmac_md5,
	algtype_hmac_sha1,
	algtype_des_mac,
	algtype_kpdk,
	algtype_non_auth,
	algtype_hmac_sha2_256,
	algtype_hmac_sha2_384,
	algtype_hmac_sha2_512,

	/* ipcomp */
	algtype_oui,
	algtype_deflate,
	algtype_lzs,

	/* hash */
	algtype_md5,
	algtype_sha1,
	algtype_tiger,
	algtype_sha2_256,
	algtype_sha2_384,
	algtype_sha2_512,

	/* dh_group */
	algtype_modp768,
	algtype_modp1024,
	algtype_ec2n155,
	algtype_ec2n185,
	algtype_modp1536,
	algtype_modp2048,
	algtype_modp3072,
	algtype_modp4096,
	algtype_modp6144,
	algtype_modp8192,

	/* authentication method. */
	algtype_psk,
	algtype_dsssig,
	algtype_rsasig,
	algtype_rsaenc,
	algtype_rsarev,
	algtype_gssapikrb,
};

struct hmac_algorithm {
	const char *name;
	int type;
	int doi;
	caddr_t (*init)(vchar_t *);
	void (*update)(caddr_t, vchar_t *);
	vchar_t *(*final)(caddr_t);
	int (*hashlen)(void);
	vchar_t *(*one)(vchar_t *, vchar_t *);
};

struct hash_algorithm {
	const char *name;
	int type;
	int doi;
	caddr_t (*init)(void);
	void (*update)(caddr_t, vchar_t *);
	vchar_t *(*final)(caddr_t);
	int (*hashlen)(void);
	vchar_t *(*one)(vchar_t *);
};

struct enc_algorithm {
	const char *name;
	int type;
	int doi;
	int blocklen;
	vchar_t *(*encrypt)(vchar_t *, vchar_t *, vchar_t *);
	vchar_t *(*decrypt)(vchar_t *, vchar_t *, vchar_t *);
	int (*weakkey)(vchar_t *);
	int (*keylen)(int);
};

/* dh group */
struct dh_algorithm {
	const char *name;
	int type;
	int doi;
	oakley_group_t *dhgroup;
};

/* ipcomp, auth meth, dh group */
struct misc_algorithm {
	const char *name;
	int type;
	int doi;
};

int alg_ipsec_encdef_doi(int type);
int alg_ipsec_compdef_doi(int type);
int alg_oakley_encdef_doi(int type);
int alg_oakley_authdef_doi(int type);

int alg_oakley_hashdef_doi(int type);
vchar_t *alg_oakley_hashdef_one(int doi, vchar_t *buf);

int alg_oakley_dhdef_doi(int type);
oakley_group_t *alg_oakley_dhdef_group(int doi);

int alg_ipsec_hmacdef_doi(int type);
vchar_t *alg_oakley_hmacdef_one(int doi, vchar_t *key, vchar_t *buf);

int algtype2doi(int class, int type);

#endif /* __IPSEC_ALGO_H_INCLUDE__ */
