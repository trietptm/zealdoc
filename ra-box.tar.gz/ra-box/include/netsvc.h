#ifndef __NETSVC_H_INCLUDE__
#define __NETSVC_H_INCLUDE__

#include <sysdep.h>
#include <list.h>
#include <uiserv.h>
#include <notify.h>
#include <dfastm.h>

#include <linux/route.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>

#include <net_nl.h>
#include <net_rtnl.h>
/* attribute-value pairs */
#include <net_avp.h>
/* device */
#include <net_if.h>
/* inet device */
#include <net_in4.h>
/* access interface, deperecated */
#include <net_nic.h>
/* access concentrator */
#include <net_nac.h>
/* routing */
#include <net_rt.h>
/* socket utility */
#include <net_sock.h>
#include <net_skb.h>
#include <skbuff.h>

#define NET_UNIT_STARTING	0x01
#define NET_UNIT_STARTED	0x02
#define NET_UNIT_STOPPING	0x03
#define NET_UNIT_STOPPED	0x04

#define NET_SERVICE_NAME	"net"

#define NET_UP_NEVER	0
#define NET_UP_ALWAYS	1
#define NET_UP_DEMAND	2

typedef struct _net_config_t {
	const char *host;
	const char *domain;
	const char *username;
	const char *password;
} net_config_t;

/* ============================================================ *
 * system operations (may be deprecated)
 * ============================================================ */
const char *net_host_name(void);
const char *net_domain_name(void);

/* ============================================================ *
 * ioctl wrappers
 * ============================================================ */
int __net_config_open(void);
void __net_config_close(int s);

/* ============================================================ *
 * utility operation
 * ============================================================ */
const char *net_up2name(int up);
const char *net_up2desc(int up);
int net_name2up(const char *str);
void ui_parse_net_uptiming(const char *str, void *data);

#endif /* __NETSVC_H_INCLUDE__ */
