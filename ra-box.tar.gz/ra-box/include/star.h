#ifndef __STAR_H_INCLUDE__
#define __STAR_H_INCLUDE__

#include <sysdep.h>

#define _PATH_STAR_GSW_DEV		"/proc/grocx/gsw_devices"
#define STAR_SERVICE_NAME		"star"

#define STAR_GSW_PORT_MAC0	VTSS_GRX_PORT_MAC0	/* port type for MAC0 port */
#define STAR_GSW_PORT_MAC1	VTSS_GRX_PORT_MAC1	/* port type for MAC1 port */
#define STAR_GSW_PORT_CPU	VTSS_GRX_PORT_CPU	/* port type for CPU port */

#ifdef CONFIG_STAR_MAC1_LOG_PORT
#define STAR_MAC1_LOG_PORT	CONFIG_STAR_MAC1_LOG_PORT
#else
#define STAR_MAC1_LOG_PORT	0
#endif

#ifdef CONFIG_STAR_MAC0_LOG_PORT
#define STAR_MAC0_LOG_PORT	CONFIG_STAR_MAC0_LOG_PORT
#else
#define STAR_MAC0_LOG_PORT	0
#endif

typedef struct _star_counter_t {
	uint32_t rx_ok_pkt;
	uint32_t rx_ok_byte;
	uint32_t rx_runt_pkt;
	uint32_t rx_over_size_pkt;	
	uint32_t rx_no_buffer_drop_pkt;	
	uint32_t rx_crc_err_pkt;
	uint32_t rx_arl_drop_pkt;		
	uint32_t rx_vlan_ingress_drop_pkt;
	uint32_t rx_csum_err_pkt;
	uint32_t rx_pause_frame_pkt;

	uint32_t tx_ok_pkt;
	uint32_t tx_ok_byte;
	uint32_t tx_pause_frame_pkt;

	/* cpu port */
	uint32_t ts_ok_pkt;
	uint32_t ts_ok_byte;
	uint32_t ts_no_dest_drop_pkt;
	uint32_t ts_arl_drop_pkt;
	uint32_t ts_vlan_ingress_drop_pkt;
	uint32_t fs_ok_pkt;
	uint32_t fs_ok_byte;
} star_counter_t;

const char *star_get_lan_device(void);
const char *star_get_wan_device(void);

/* CPU_RX flags */
#define STAR_GSW_PACKET_UNKNOWN		0x01
#define STAR_GSW_PACKET_MULTICAST	0x02
#define STAR_GSW_PACKET_BROADCAST	0x04

int star_set_packet_control(uint port_no, unsigned long rx_flags);
int star_get_packet_control(uint port_no, unsigned long *rx_flags);
int star_clear_port_counter(uint port_no);
int star_get_port_counter(uint port_no, star_counter_t *cnts);

#endif /* __STAR_H_INCLUDE__ */
