/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2005
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@hzcnc.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)ppp_chap.h: challenge handshake authentication protocol interface
 * $Id: ppp_chap.h,v 1.53 2009-02-24 09:33:07 zhenglv Exp $
 */

#ifndef __PPP_CHAP_H_INCLUDE__
#define __PPP_CHAP_H_INCLUDE__

#include <ppp_auth.h>

typedef struct _ppp_chaptype_t ppp_chaptype_t;
typedef struct _ppp_chapalgo_t ppp_chapalgo_t;

/* CHAP packets begin with a standard header with code, id, len (2 bytes).
 */
#define CHAP_HDRLEN	4

/* values for the code field */
#define CHAP_CODE_CHALLENGE	1
#define CHAP_CODE_RESPONSE	2
#define CHAP_CODE_SUCCESS	3
#define CHAP_CODE_FAILURE	4
#define CHAP_CODE_PENDING	0xff

/* CHAP digest codes */
#define CHAP_MD5		0x05
#define CHAP_MSCHAP		0x80
#define CHAP_MSCHAPV2		0x81

/* Semi-arbitrary limits on challenge and response fields */
#define MAX_CHALLENGE_LEN	64
#define MAX_RESPONSE_LEN	64

/* the code for each digest type has to supply one of these.
 */
struct _ppp_chaptype_t {
	/* algorithm type */
	uint8_t algorithm;
	/* text name of this algorithm */
	const char *name;
	const char *desc;
	/* init algorithm plugin */
	int (*init)(ppp_authinst_t *inst);
	/* exit algorithm plugin */
	void (*exit)(ppp_authinst_t *inst, ppp_chapalgo_t *algo);

	/* Note: challenge and response arguments below are formatted as
	 * a length byte followed by the actual challenge/response data.
	 */
	int (*challenge)(ppp_chapalgo_t *inst, uint8_t *id, msgbuf_t *req);
	int (*response)(ppp_chapalgo_t *, uint8_t *id,
			msgbuf_t *req, msgbuf_t *resp);
	int (*validate)(ppp_chapalgo_t *inst, uint8_t id,
			msgbuf_t *resp, const char *user);
	int (*handle_success)(ppp_chapalgo_t *inst, uint8_t id, msgbuf_t *msg);
	/* if want retry, return 1 */
	bool (*handle_failure)(ppp_chapalgo_t *inst, uint8_t id,
			       msgbuf_t *req, msgbuf_t *resp);
	list_t link;
};

struct _ppp_chapalgo_t {
	ppp_authinst_t *authinst;
	ppp_chaptype_t *algorithm;

	int priority;

	int rcn_count;
	int scn_count;
	int nac_allowed;
	int nac_wanted;
	list_t link;
};

/* make challenge by chap / mschap / mschapv2 */
inline static uint8_t chap_random_byte(void)
{
	int rand_num;
	
	rand_num = random();
	/* XOR the bytes together just in case the random number generator
	 * has a weakness in some range.
	 */
	return (rand_num ^ (rand_num >> 8) ^ (rand_num >> 16) ^ (rand_num >> 24));
}

void chap_make_challenge(uint8_t *challenge, int len);

/* Called by digest code to register a digest type */
ppp_chaptype_t *ppp_chap_find_algorithm(int mdalgo);
int ppp_chap_register_algorithm(ppp_chaptype_t *algo);
void ppp_chap_unregister_algorithm(ppp_chaptype_t *algo);

void ppp_chap_algo_enable(ppp_authinst_t *auth, ppp_chapalgo_t *inst);
void ppp_chap_algo_disable(ppp_authinst_t *auth, ppp_chapalgo_t *inst);

const char *ppp_chap_code2str(uint8_t code);
const char *ppp_chap_domain_name(ppp_chapalgo_t *algo, const char *name);
const char *ppp_chap_user_name(ppp_chapalgo_t *algo);

#endif /* __PPP_CHAP_H_INCLUDE__ */
