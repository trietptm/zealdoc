#ifndef __RTNL_WIN32_H_INCLUDE__
#define __RTNL_WIN32_H_INCLUDE__

#define HAVE_RTNL_SYS_INIT 1

typedef int (*rtnl_doit_t)(struct nlmsghdr *, void *);
typedef int (*rtnl_dumpit_t)(msgbuf_t *, netlink_callback_t *);

int rtnl_register_server(int protocol, int msgtype,
			 rtnl_doit_t doit,
			 rtnl_dumpit_t dumpit);
int rtnl_unregister_server(int protocol, int msgtype);
void rtnl_unregister_all_servers(int protocol);

int rtnl_notify(msgbuf_t *skb, uint32_t pid, uint32_t group,
		struct nlmsghdr *nlh);
void rtnl_set_sk_err(uint32_t group, int error);

#endif
