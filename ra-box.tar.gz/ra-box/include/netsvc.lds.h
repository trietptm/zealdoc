
#ifndef LOAD_OFFSET
#define LOAD_OFFSET 0
#endif

/* Align . to a 8 byte boundary equals to maximum function alignment. */
#define ALIGN_FUNCTION()  . = ALIGN(8)

#define INITCALLS							\
  	*(.initcall0.init)						\
  	*(.initcall0s.init)						\
  	*(.initcall1.init)						\
  	*(.initcall1s.init)						\
  	*(.initcall2.init)						\
  	*(.initcall2s.init)						\
  	*(.initcall3.init)						\
  	*(.initcall3s.init)						\
  	*(.initcall4.init)						\
  	*(.initcall4s.init)						\
  	*(.initcall5.init)						\
  	*(.initcall5s.init)

#define PERCPU(align)							\
	. = ALIGN(align);						\
	__per_cpu_start = .;						\
	.data.percpu  : AT(ADDR(.data.percpu) - LOAD_OFFSET) {		\
		*(.data.percpu)						\
		*(.data.percpu.shared_aligned)				\
	}								\
	__per_cpu_end = .;
