#ifndef __NOTIFY_H_INCLUDE__
#define __NOTIFY_H_INCLUDE__

#include <sysdep.h>

#define NOTIFY_DONE		0x0000		/* Don't care */
#define NOTIFY_OK		0x0001		/* Suits me */
#define NOTIFY_STOP_MASK	0x8000		/* Don't call further */
#define NOTIFY_BAD		(NOTIFY_STOP_MASK|0x0002)
						/* Bad/Veto action */
/*
 * Clean way to return from the notifier and stop further calls.
 */
#define NOTIFY_STOP		(NOTIFY_OK|NOTIFY_STOP_MASK)

/* Encapsulate (negative) errno value (in particular, NOTIFY_BAD <=> EPERM). */
static inline int notify_from_errno(int err)
{
	return NOTIFY_STOP_MASK | (NOTIFY_OK - err);
}

/* Restore (negative) errno value from notify return value. */
static inline int notify_to_errno(int ret)
{
	ret &= ~NOTIFY_STOP_MASK;
	return ret > NOTIFY_OK ? NOTIFY_OK - ret : 0;
}

struct _notify_t;
typedef int (*notify_cb)(struct _notify_t *, unsigned long, void *);

typedef struct _notify_t {
	struct _notify_t *next;
	notify_cb call;
	int priority;
} notify_t;

typedef struct _notify_head_t {
	notify_t *head;
} notify_head_t;

#define NOTIFY_HEAD_INIT(name)	{ NULL }
#define INIT_NOTIFY_HEAD(nb)	((nb).head = NULL)

#define DECLARE_NOTIFY_CHAIN(name) \
	notify_head_t name = NOTIFY_HEAD_INIT(name)

/* ============================================================ *
 * notifier operations
 * ============================================================ */
int register_notify_chain(notify_head_t *nh, notify_t *nb);
int unregister_notify_chain(notify_head_t *nh, notify_t *nb);
int call_notify_chain(notify_head_t *nh, unsigned long val, void *v);

#endif /* __NOTIFY_H_INCLUDE__ */
