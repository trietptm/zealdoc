#ifndef __UDEV_H_INCLUDE__
#define __UDEV_H_INCLUDE__

#include <sysdep.h>
#include <fsserv.h>
#include <notify.h>
#include <list.h>

#define UDEV_SERVICE_NAME		"udev"
#ifdef WIN32
#define UDEV_PORT			54322
#endif

typedef struct _udev_device_t udev_device_t;
typedef struct _udev_trigger_t udev_trigger_t;
typedef struct _udev_rule_t udev_rule_t;
typedef struct _udev_event_t udev_event_t;

/* device DB entry */
typedef struct _udev_node_t {
	char *filename;
	list_t link;
} udev_node_t;

typedef int (*udev_program_t)(udev_event_t *msg, udev_device_t *dev);

/* ============================================================ *
 * trigger operation
 * ============================================================ */
udev_trigger_t *udev_trigger_new(void);
void udev_trigger_free(udev_trigger_t *trigger);
void udev_filter_subsystem(udev_trigger_t *trigger,
			   const char *subsystem, int match);
void udev_filter_attr(udev_trigger_t *trigger, const char *attr, int match);
void udev_event_trigger(udev_trigger_t *trigger, const char *action);

/* ============================================================ *
 * rules operation
 * ============================================================ */
int udev_register_rule(const char *rule);

/* ============================================================ *
 * program operation
 * ============================================================ */
int udev_register_program(const char *name, udev_program_t program);
void udev_unregister_program(const char *name);

/* ============================================================ *
 * environ operation
 * ============================================================ */
int udev_event_setenv(udev_event_t *msg, const char *name,
		      const char *value, int overwrite);
int udev_event_unsetenv(udev_event_t *msg, const char *name);
int udev_event_clearenv(udev_event_t *msg);
int udev_event_putenv(udev_event_t *msg, const char *string);
char *udev_event_getenv(udev_event_t *msg, const char *var);

void udev_append_result(udev_device_t *dev, const char *result);

/* ============================================================ *
 * notify operation
 * ============================================================ */
int udev_register_notify(notify_t *nb);
int udev_unregister_notify(notify_t *nb);

#define UDEV_CREATE	0x00
#define UDEV_DELETE	0x01

#endif /*__UDEV_H_INCLUDE__*/
