#ifndef __PPP_NEGO_H_INCLUDE__
#define __PPP_NEGO_H_INCLUDE__

#include <ppp_prot.h>

typedef struct _ppp_negocall_t ppp_negocall_t;
typedef struct _ppp_negoinst_t ppp_negoinst_t;

#include <ppp_lcp.h>
#include <ppp_ipcp.h>
#include <ppp_bcp.h>
#include <ppp_ccp.h>
#include <ppp_lqr.h>

/* Option negotiation extension callbacks implemented by PPP protocol */
struct _ppp_negocall_t {
	/* string name for protocol (for messages) */
	const char *name;
	/* init our Configuration Options */
	void (*opt_init)(ppp_negoinst_t *);
	/* reset our Configuration Options */
	void (*opt_reset)(ppp_negoinst_t *);

	/* build our Configure-Request */
	int  (*opt_bcr)(ppp_negoinst_t *, msgbuf_t *,
			int ci_space);
	/* parse his Configure-Ack/Nak/Rej */
	int  (*opt_pcp)(ppp_negoinst_t *, msgbuf_t *, uint8_t code);

	/* request peer's Configuration Options
	 * return TRUE if options changed
	 */
	int  (*opt_rcr)(ppp_negoinst_t *, int,
			msgbuf_t *, msgbuf_t *);
	/* ACK our Configuration Options */
	void (*opt_rca)(ppp_negoinst_t *, msgbuf_t *);
	/* NAK our Configuration Options */
	void (*opt_rcn)(ppp_negoinst_t *, msgbuf_t *);
	/* reject our Configuration Options */
	void (*opt_rcj)(ppp_negoinst_t *, msgbuf_t *);

	/* called when This-Layer-Started */
	int  (*start)(ppp_negoinst_t *);
	/* called when This-Layer-Finished */
	void (*finish)(ppp_negoinst_t *);
	/* called when This-Layer-Up */
	int  (*up)(ppp_negoinst_t *);
	/* called when This-Layer-Down */
	void (*down)(ppp_negoinst_t *);
	/* called when unknown code received */
	void (*extra_code)(ppp_protinst_t *, uint8_t code,
			   uint8_t id, msgbuf_t *msg);

	/* called after NAC-Update-Notified arrives in xxx_Q state */
	bool (*opt_cnq)(ppp_negoinst_t *);
	/* called after NAC-Update-Notified arrives in xxx_P states */
	bool (*opt_cnp)(ppp_negoinst_t *, msgbuf_t *);
	/* called after NAC-Update-Rejected arrives in xxx_P states */
	/* return TRUE if NAC other side said request id bad (RCR_M) */
	bool (*opt_cnj)(ppp_negoinst_t *, msgbuf_t *);
};

/* ============================================================ *
 * negotiation automaton
 * ============================================================ */
/* ============================================================ *
 * RFC-1661 states
 * ============================================================ */
#define PPP_NEGO_STATE_INITIAL		0
#define PPP_NEGO_STATE_STARTING		1
#define PPP_NEGO_STATE_CLOSED		2
#define PPP_NEGO_STATE_STOPPED		3
#define PPP_NEGO_STATE_CLOSING		4
#define PPP_NEGO_STATE_STOPPING		5
#define PPP_NEGO_STATE_REQ_SENT		6
#define PPP_NEGO_STATE_ACK_RCVD		7
#define PPP_NEGO_STATE_ACK_SENT		8
#define PPP_NEGO_STATE_OPENED		9

/* ============================================================ *
 * NAC states
 * ============================================================ */
/* Starting-q: Starting (Wait-Request)
 * In this state, automaton has started, but neigther NAC request items
 * nor lower layer is ready, in this state, the automaton can not send out
 * Configure-Request.
 */
#define PPP_NEGO_STATE_STARTING_Q	10
/* Req-Sent-q: Request-Sent (Wait-Request)
 * In this state, the lower layer has been ready, but without NAC request
 * items, automaton can not send out Configure-Request.
 */
#define PPP_NEGO_STATE_REQ_SENT_Q	11
/* Ack-Sent-q: Ack-Sent (Wait-Request)
 * In this state, the lower layer has been ready, and the automaton has
 * replied peer's Configure-Request with Configure-Ack, but without NAC
 * request items, automaton can not send out Configure-Request.
 */
#define PPP_NEGO_STATE_ACK_SENT_Q	12
/* Req-Sent-p: Req-Sent (Wait-Reply)
 * In this state, the automaton has sent out local Configure-Request, but
 * without NAC reply items, automaton can not send out
 * Configure-Ack/Nak/Reject to a newly received Configure-Request.
 */
#define PPP_NEGO_STATE_REQ_SENT_P	13
/* Ack-Rcvd-p: Ack-Rcvd (Wait-Reply)
 * In this state, the automaton has received peer's reply to outgoing
 * Configure-Request, but without NAC reply items, automaton can not send
 * out Configure-Ack/Nak/Reject to a newly received Configure-Request.
 */
#define PPP_NEGO_STATE_ACK_RCVD_P	14
#define PPP_NEGO_STATE_COUNT		15

/* ============================================================ *
 * RFC-1661 events
 * ============================================================ */
#define PPP_NEGO_EVENT_UP		0
#define PPP_NEGO_EVENT_DOWN		1
#define PPP_NEGO_EVENT_OPEN		2
#define PPP_NEGO_EVENT_CLOSE		3
#define PPP_NEGO_EVENT_TO_P		4
#define PPP_NEGO_EVENT_TO_M		5
#define PPP_NEGO_EVENT_RCR_P		6
#define PPP_NEGO_EVENT_RCR_M		7
#define PPP_NEGO_EVENT_RCA		8
#define PPP_NEGO_EVENT_RCN		9
#define PPP_NEGO_EVENT_RTR		10
#define PPP_NEGO_EVENT_RTA		11
#define PPP_NEGO_EVENT_RUC		12
#define PPP_NEGO_EVENT_RXJ_P		13
#define PPP_NEGO_EVENT_RXJ_M		14
#define PPP_NEGO_EVENT_RXR		15

/* ============================================================ *
 * NAC events
 * ============================================================ */
/* RCR=: Receive-Configure-Request (Pending)
 * Configure-Request has been received on an end, without NAC reply items,
 * the end can not reply the Configure-Request.  Thus the end must request
 * the other end of NAC and wait for its reply on this event.
 */
#define PPP_NEGO_EVENT_RCR_E		16
/* RCR~: Receive-Configure-Request (Timeout)
 * After a configured period of time without receiving any Configure-Request,
 * this event will occur, it will always lead to This-Layer-Down state.
 */
#define PPP_NEGO_EVENT_RCR_W		17
/* NUN: NAC-Update-Notified
 * Whenever the other end of NAC has updated its items, this event will occur,
 * automaton then call protocol handlers to check whether request or reply
 * items are ready through CNQ (Check-NAC-Request) and CNP (Check-NAC-Reply)
 * action.
 * NQR might be raised by CNQ or no event if request is not ready.
 * one of RCR+ / RCR- / RCR= should be raised by CNP.
 */
#define PPP_NEGO_EVENT_NUN		18
/* NUN: NAC-Reject-Notified
 * Whenever the other end of NAC has rejected our items, this event will
 * occur, automaton then call protocol handlers to check whether RCR- should
 * be issued through CNJ (Check-NAC-Reject) action.
 * RCR- might be raised by CNJ or no event if reject is not concerned to this
 * automaton.
 */
#define PPP_NEGO_EVENT_NJN		19
/* NQR: NAC-Request-Ready
 * This event will be generated by CNQ when protocol handler returns request
 * items ready.
 */
#define PPP_NEGO_EVENT_NQR		20
/* RCR: Receive-Configure-Request
 * This event will be generated by packet receiver, a CNP action should be
 * taken after this event occurs.
 * one of RCR- / RCR+ / RCR= should be raised by CNP.
 */
#define PPP_NEGO_EVENT_RCR		21
#define PPP_NEGO_EVENT_COUNT		22

/* XXX: No Automaton Options Implemented
 * Interface retry mechanism can ensure restart of PPP automaton, so options
 * are disabled in our automaton.
 */
/* After the peer fails to respond to Configure-Requests, an
 * implementation MAY wait passively for the peer to send
 * Configure-Requests.  In this case, the This-Layer-Finished
 * action is not used for the TO- event in states Req-Sent, Ack-
 * Rcvd and Ack-Sent.
 * This option is useful for dedicated circuits, or circuits which
 * have no status signals available, but SHOULD NOT be used for
 * switched circuits.
 */
/*#define PPP_NEGO_OPT_PASSIVE		0x01*/
/* Experience has shown that users will execute an additional Open
 * command when they want to renegotiate the link.  This might
 * indicate that new values are to be negotiated.
 *
 * Since this is not the meaning of the Open event, it is
 * suggested that when an Open user command is executed in the
 * Opened, Closing, Stopping, or Stopped states, the
 * implementation issue a Down event, immediately followed by an
 * Up event.  Care must be taken that an intervening Down event
 * cannot occur from another source.
 *
 * The Down followed by an Up will cause an orderly renegotiation
 * of the link, by progressing through the Starting to the
 * Request-Sent state.  This will cause the renegotiation of the
 * link, without any harmful side effects.
 */
/*#define PPP_NEGO_OPT_RESTART		0x02*/
/* Since the correct packet has already been received before
 * reaching the Ack-Rcvd or Opened states, it is extremely
 * unlikely that another such packet will arrive.  As specified,
 * all invalid Ack/Nak/Rej packets are silently discarded, and do
 * not affect the transitions of the automaton.
 *
 * However, it is not impossible that a correctly formed packet
 * will arrive through a coincidentally-timed cross-connection.
 * It is more likely to be the result of an implementation error.
 * At the very least, this occurance SHOULD be logged.
 */
/*#define PPP_NEGO_OPT_CROSSED		0x04*/

/* ============================================================ *
 * genenric handlers
 * ============================================================ */
void ppp_nego_generic_lowerup(ppp_protinst_t *inst);
void ppp_nego_generic_lowerdown(ppp_protinst_t *inst);
void ppp_nego_generic_protrej(ppp_protinst_t *inst);
void ppp_nego_generic_advance(ppp_protinst_t *inst);
void ppp_nego_generic_retreat(ppp_protinst_t *inst);
void ppp_nego_generic_input(ppp_protinst_t *inst, msgbuf_t *msg);
void ppp_nego_generic_exit(ppp_phase_t *phase, ppp_protinst_t *insti);
void ppp_nego_generic_init(ppp_phase_t *phase, ppp_protinst_t *insti);

/* no ppp_nego_enable / ppp_nego_disable version */
void __ppp_nego_generic_init(ppp_phase_t *phase, ppp_protinst_t *insti);
void __ppp_nego_generic_exit(ppp_phase_t *phase, ppp_protinst_t *insti);

/* ============================================================ *
 * automaton externals
 * ============================================================ */
void ppp_nego_open(ppp_protinst_t *inst);
void ppp_nego_close(ppp_protinst_t *inst);
void ppp_nego_raise_event(ppp_negoinst_t *inst, int event);
/* other automaton externals should be ppp_protocol_xxx */

/* ============================================================ *
 * automaton internals
 * ============================================================ */
void ppp_nego_enable(ppp_phase_t *phase, ppp_negoinst_t *inst);
void ppp_nego_disable(ppp_phase_t *phase, ppp_negoinst_t *inst);
int ppp_nego_encode_option(msgbuf_t *msg, uint8_t type,
			   uint8_t length, uint8_t *data);
int ppp_nego_encode_header(msgbuf_t *msg, uint8_t code, uint8_t id);
int ppp_nego_decode_option(msgbuf_t *msg, uint8_t *type,
			   uint8_t *length, uint8_t **data);
void ppp_nego_save_reply(ppp_negoinst_t *inst, msgbuf_t *reply,
			 int peer);
void ppp_nego_send_reply(ppp_negoinst_t *inst, int peer);
void ppp_nego_save_request(ppp_negoinst_t *inst, msgbuf_t *request,
			   int peer, uint8_t peer_id);

#endif /* __PPP_NEGO_H_INCLUDE__ */
