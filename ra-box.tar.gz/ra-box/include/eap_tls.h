#ifndef __EAP_TLS_H_INCLUDE__
#define __EAP_TLS_H_INCLUDE__

#include <sysdep.h>
#include <netsvc.h>

typedef struct _eap_tls_conn_t *eap_tls_conn_t;

typedef struct _eap_tls_t {
	eap_tls_conn_t *conn;

	msgbuf_t *tls_out;
	size_t tls_out_limit;
	msgbuf_t *tls_in;

	int phase2;
	int include_tls_length; /* include TLS length field even if the TLS
				 * data is not fragmented */
	int tls_ia; /* Enable TLS/IA */
} eap_tls_t;

#endif /* __EAP_TLS_H_INCLUDE__ */
