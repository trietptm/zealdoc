#ifndef __RSA_H_INCLUDE__
#define __RSA_H_INCLUDE__

#include <sysdep.h>
#include <mpi.h>

/* RSA key lengths */
#define MIN_RSA_MODULUS_BITS 508
#define MAX_RSA_MODULUS_BITS 1024
#define MAX_RSA_MODULUS_LEN ((MAX_RSA_MODULUS_BITS + 7) / 8)
#define MAX_RSA_PRIME_BITS ((MAX_RSA_MODULUS_BITS + 1) / 2)
#define MAX_RSA_PRIME_LEN ((MAX_RSA_PRIME_BITS + 7) / 8)

/* error codes */
#define RSA_ERROR_DATA			0x0001
#define RSA_ERROR_LEN			0x0002
#define RSA_ERROR_MODULUS_LEN		0x0003

/* RSA public and private key */
typedef struct _rsa_public_t {
	/* length in bits of modulus */
	unsigned int bits;
	/* n the RSA modulus, a positive integer */
	uint8_t n[MAX_RSA_MODULUS_LEN];
	/* e the RSA public exponent, a positive integer */
	uint8_t e[MAX_RSA_MODULUS_LEN];
} rsa_public_t;

typedef struct _rsa_private_t {
	unsigned int bits;
	/* n the RSA modulus, a positive integer */
	uint8_t n[MAX_RSA_MODULUS_LEN];
	/* e the RSA public exponent, a positive integer */
	uint8_t e[MAX_RSA_MODULUS_LEN];
	/* d the RSA private exponent, a positive integer */
	uint8_t d[MAX_RSA_MODULUS_LEN];
	/* ri the ith factor, a positive integer */
	uint8_t r[2][MAX_RSA_PRIME_LEN];
	/* di the ith factor�fs CRT exponent, a positive integer */
	uint8_t dR[2][MAX_RSA_PRIME_LEN];
	/* ti the ith factor�fs CRT coefficient, a positive integer */
	uint8_t t[MAX_RSA_PRIME_LEN];
} rsa_private_t;

/* RSA prototype key */
/*
 * An rsa_proto_key_t value is a structure specifying the length
 * in bits of the RSA modulus and the public exponent for key-pair
 * generation. There are two fields:
 *
 *        bits     length in bits of the modulus (not less than
 *                   MIN_RSA_MODULUS_BITS and not greater than
 *                   MAX_RSA_MODULUS_BITS)
 *
 *  useFermat4     a flag specifying the public exponent. If
 *                   nonzero, it specifies F4 (65537); if 0, F0 (3)
 */
typedef struct _rsa_param_t {
	unsigned int bits;	/* length in bits of modulus */
	int useFermat4;		/* public exponent (1 = F4, 0 = 3) */
} rsa_param_t;

int rsa_gen_pem_keys(rsa_public_t *publicKey,
		     rsa_private_t *privateKey,
		     rsa_param_t *protoKey);

int rsa_public_encrypt(rsa_public_t *publicKey,
		       uint8_t *output, size_t *outputLen,
		       uint8_t *input, size_t inputLen);
int rsa_public_decrypt(rsa_public_t *publicKey,
		       uint8_t *output, size_t *outputLen,
		       uint8_t *input, size_t inputLen);
int rsa_private_encrypt(rsa_private_t *privateKey,
			uint8_t *output, size_t *outputLen,
			uint8_t *input, size_t inputLen);
int rsa_private_decrypt(rsa_private_t *privateKey,
			uint8_t *output, size_t *outputLen,
			uint8_t *input, size_t inputLen);
void rsa_prime_find(mpi_t *, unsigned int, mpi_t *,
		    unsigned int, mpi_t *, unsigned int);

#endif /* __RSA_H_INCLUDE__ */
