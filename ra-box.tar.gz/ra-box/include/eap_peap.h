#ifndef __EAP_PEAP_H_INCLUDE__
#define __EAP_PEAP_H_INCLUDE__

/* PEAP Flags from draft 02
 *	
 *    Note that its just 6 bits in this draft(other draft may not)
 *	 0 1 2 3 4 5
 *	+-+-+-+-+-+-+
 *	|L M S R R R|
 *	+-+-+-+-+-+-+
 *
 *	L = Length included
 *	M = More fragments
 *	S = PEAP start
 *	R = Reserved (must be zero)
 *   
 *  The L bit (length included) is set to indicate the presence of the
 *  four octet TLS Message Length field, and MUST be set for the first
 *  fragment of a fragmented TLS message or set of messages. The M bit
 *  (more fragments) is set on all but the last fragment. The S bit (PEAP
 *  start) is set in a PEAP Start message. This differentiates the PEAP
 *  Start message from a fragment acknowledgment.
 *
 */
#define PEAP_FLAGS_BITS_COUNT		6	/* for clear last bits in this octec */
#define PEAP_FLAGS_CLR_VER		0xFC	/* 11111100 for clear version field */
#define PEAP_FLAGS_L		0x80
#define PEAP_FLAGS_M		0x40
#define PEAP_FLAGS_S		0x20
#define PEAP_FLAGS_L_M		(PEAP_FLAGS_L | PEAP_FLAGS_M)

/* in NONE/ACK/FINAL package, flags is 0x00 */
#define PEAP_FLAGS_NONE		0x00
#define PEAP_FLAGS_FINAL	PEAP_FLAGS_NONE
#define PEAP_FLAGS_ACK		PEAP_FLAGS_NONE
#define PEAP_FLAGS_APP		PEAP_FLAGS_NONE
/* not sure which version we used */
#define PEAP_VERSION_MASK 0x07

/* RFC 2246 */
#define PEAP_TLS_MAX_LEN	16384

#include <openssl/crypto.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/ssl.h>

#define PEAP_SERVICE_NAME	"peap"

typedef struct _peap_ssl_t peap_ssl_t;
typedef struct _peap_message_t peap_message_t;
typedef struct _peap_profile_t peap_profile_t;
typedef struct _peap_config_t peap_config_t;

struct _peap_ssl_t {
	SSL	*ssl;
	SSL_CTX	*ctx;
	BIO	*ssl_in, *ssl_out;

	const char *ca_file_path;
	int ca_filetype;	/* asn1 or pem now */

	/* for phase 2 */
#ifdef DO_PHASE_TWO

#endif
};

/************************************************************************/
/*  RFC 2246 2.7 Fragmentation
 *
 *  PEAP fragmentation support is provided through addition of flag bits
 *  within the EAP-Response and EAP-Request packets, as well as a TLS
 *  Message Length field of four octets. Flags include the Length included
 *  (L), More fragments (M), and PEAP Start (S) bits. The L flag is set to
 *  indicate the presence of the four octet TLS Message Length field, and
 *  MUST be set for the first fragment of a fragmented TLS message or set of
 *  messages. The M flag is set on all but the last fragment. The S flag is
 *  set only within the PEAP start message sent from the EAP server to the
 *  peer. The TLS Message Length field is four octets, and provides the
 *  total length of the TLS message or set of messages that is being
 *  fragmented; this simplifies buffer allocation.                                                                     */
/************************************************************************/
struct _peap_message_t {
	uint8_t last_in;	/* In peap, MORE flags indicate(trigger) this */
#define COMPLETE	0x04
#define FIRST_IN	0X02
#define LAST_IN		0x01

	int total_len;	/* total length of TLS data in fragment list,
			 * it come from the first(Length && more) packet */

	int id;		/* sequence stuff, store corresponding request packet's ID */
	msgbuf_t *req;	/* fragments request package */
	int req_len;	/* for single request packet length */

	uint16_t timeout;	/* read from profile */
	struct timeval stamp;	/* last fragment's stamp */

	list_t link;		/* linked list of request fragments */
};

struct _peap_config_t {
	int temp;
};

struct _peap_profile_t {
	const char *name;
	/* eap section */
	ui_entry_t *cs;

	/* in eap profile */
	const char *peap_caCertPath;
	const char *peap_caFiletype;
	const char *peap_inner_method;
	/* read from lower */
	const char *username;
	const char *password;
	list_t link;
};

/* For fragment handle */
void peap_message_free(void *data);
peap_message_t *peap_message_new(void);
int peap_message_add_info(msgbuf_t *msg);

/* SSL */
peap_ssl_t *peap_do_ssl_init(void);
int peap_do_ssl_connect(peap_ssl_t *insti);
#endif	/* __EAP_PEAP_H_INCLUDE__ */
