#ifndef __BRIDGE_H_INCLUDE__
#define __BRIDGE_H_INCLUDE__

#include <sysdep.h>
#include <atomic.h>
#include <netsvc.h>
#include <notify.h>

#include <linux/if_bridge.h>

#define BRIDGE_SERVICE_NAME	"bridge"
#define BRIDGE_GC_TIMEOUT	1
#define BRIDGE_RETRY_DELAY	5
#define BR_MAX_PORTS	10

typedef struct _bridge_id_t {
	uint8_t prio[2];
	uint8_t addr[6];
} bridge_id_t;

typedef struct _br_profile_t {
	const char *name;
	
	int stp;
	int max_age;
	int hello_time;
	int forward_delay;
	int bridge_max_age;
	int ageing_time;
	int bridge_hello_time;
	int bridge_forward_delay;
	
	ui_entry_t *cs;
	atomic_t refcnt;
	list_t link;
} br_profile_t;

typedef struct _bridge_t {
	int brno;
	net_device_t *dev;
	br_profile_t *profile;

	struct __bridge_info br_info;
	int closing;
	int in_kernel;	/* attach to kernel */
	atomic_t refcnt;
	list_t port_list;	/* interface list */
	list_t link;
} bridge_t;

typedef struct _bridge_port_t {
	bridge_t *br;
	const char *ifname;	/* port_ifname in profile */
	net_device_t *dev;

	int state;
	struct __port_info port_info;
	/* one device belong to one bridge
	 * so no refernce count used 
	 */
	/* when get NETDEV_XXX notify, attach dev to port */
	int wait_dev;	/* wait rabox net_device_t */
	int in_kernel;	/* attach to kernel */
	list_t link;
} bridge_port_t;

/* bridge notify */
#define BR_BRIDGE_REGISTER	0x01
#define BR_BRIDGE_UNREGISTER	0x02
#define BR_BRIDGE_ADD		0x03
#define BR_BRIDGE_DEL		0x04
#define BR_BRIDGE_UP		0x05
#define BR_BRIDGE_GOING_DOWN	0x06
#define BR_BRIDGE_DOWN		0x07
#define BR_BRIDGE_ENABLE_STP	0x08
#define BR_BRIDGE_DISABLE_STP	0x09
/* port notify */
#define BR_PORT_ADD		0x0A
#define BR_PORT_DEL		0x0B
#define BR_PORT_UP		0x0C
#define BR_PORT_GOING_DOWN	0x0D
#define BR_PORT_DOWN		0x0E
#define BR_PORT_ENABLE_STP	0x0F
#define BR_PORT_DISABLE_STP	0x10

/* ============================================================ *
 * profile operations
 * ============================================================ */
static inline br_profile_t *br_profile_get(br_profile_t *profile)
{
	atomic_inc(&profile->refcnt);
	return profile;
}
static inline void br_profile_put(br_profile_t *profile)
{
	atomic_dec(&profile->refcnt);
}

/* ============================================================ *
 * bridge operations
 * ============================================================ */
static inline bridge_t *br_bridge_get(bridge_t *br)
{
	atomic_inc(&br->refcnt);
	return br;
}
static inline void br_bridge_put(bridge_t *br)
{
	atomic_dec(&br->refcnt);
}

int br_add_bridge(const char *brname);
void br_del_bridge(const char *brname);
int br_add_interface(const char *brname, bridge_port_t *port);
void br_del_interface(const char *brname, bridge_port_t *port);
/* set bridge state */
int br_set_bridge_stp(const char *brname, int enable);
int br_set_bridge_priority(const char *brname, int bridge_priority);
int br_set_bridge_max_age(const char *brname, struct timeval *tv);
int br_set_bridge_ageing_time(const char *brname, struct timeval *tv);
int br_set_bridge_forward_delay(const char *brname, struct timeval *tv);
int br_set_bridge_hello_time(const char *brname, struct timeval *tv);
/* set port state */
int br_set_path_cost(const char *brname, int p_ifindex, int cost);
int br_set_port_priority(const char *brname, int p_ifindex, int priority);

/* get bridge info */
int br_get_bridge_info(bridge_t *br);
/* get port info */
int br_get_port_info(bridge_t *br, bridge_port_t *port);

int br_register_notify(notify_t *nb);
void br_unregister_notify(notify_t *nb);
/* bridge and port use the same notify, so need check event for the *v type */
int br_device_notify(unsigned long val, void *v);

#endif /* __BRIDGE_H_INCLUDE__ */
