#ifndef __EAP_H_INCLUDE__
#define __EAP_H_INCLUDE__

#include <sysdep.h>
#include <netsvc.h>
#include <logger.h>
#include <syslog.h>
#include <uiserv.h>
#include <list.h>
#include <eloop.h>
#include <nfastm.h>

typedef struct _eap_config_t eap_config_t;
typedef struct _eap_link_t eap_link_t;
typedef struct _eap_peer_t eap_peer_t;
typedef struct _eap_method_t eap_method_t;
typedef struct _eap_type_t eap_type_t;
typedef struct _eap_profile_t eap_profile_t;

/*
 *  0                   1                   2                   3
 *  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |     Code      |  Identifier   |            Length             |
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |    Data ...
 * +-+-+-+-+
 */
#define EAP_CODE_REQUEST	1
#define EAP_CODE_RESPONSE	2
#define EAP_CODE_SUCCESS	3
#define EAP_CODE_FAILURE	4

#define EAP_ID_NONE		0

#define EAP_HDRLEN		4

#define EAP_CLIENT_TIMEOUT	60

struct _eap_config_t {
	int ClientTimeout;
};

typedef struct _eap_key_t {
	uint8_t *keyData;
	int keyDataLen;
} eap_key_t;

struct _eap_type_t {
	uint8_t type;
	unsigned long flags;
#define EAP_TYPE_TUNNELING	0x00000001
	const char *name;
	bool (*init)(eap_peer_t *peer);
	void (*exit)(eap_peer_t *peer, eap_method_t *method);

	/* method may have different user identity?
	 * identityLen should not include the NULL terminator
	 */
	bool (*getIdentity)(eap_method_t *m, uint8_t **identity,
			    size_t *identityLen);
	bool (*putIdentity)(eap_method_t *m, uint8_t *identity,
			    size_t identityLen);
	/* EAP state machine (RFC4137) defined methods */
	bool (*check)(eap_method_t *m, msgbuf_t *req);
	bool (*process)(eap_method_t *m, msgbuf_t *req,
			int *methodState, int *decision);
	bool (*isKeyAvailable)(eap_method_t *m);
	msgbuf_t *(*buildResp)(eap_method_t *m, uint8_t reqId);
	eap_key_t *(*getKey)(eap_method_t *m);

	list_t link;
};

/* instantiated EAP method */
struct _eap_method_t {
	eap_type_t *methodType;
	int priority;
	eap_peer_t *stateMachine;
	list_t link;
};

struct _eap_profile_t {
	const char *name;
	ui_entry_t *cs;
	/* EAP PEER */
	int ClientTimeout;

	/* PAE SUPP BE */
	int authPeriod;

	/* PAE SUPP_FE */
	int heldPeriod;
	int startPeriod;
	int maxStart;

	const char *username;
	const char *password;

	list_t link;
};

#define EAP_TYPE_NONE		0
#define EAP_TYPE_IDENTITY	1 /* RFC 3748 */
#define EAP_TYPE_NOTIFICATION	2 /* RFC 3748 */
#define EAP_TYPE_NAK		3 /* Response only, RFC 3748 */

struct _eap_peer_t {
	/* Lower Layer to Peer */
	int idleWhile;
	bool portEnabled;
	bool eapReq;
	msgbuf_t *eapReqData;
	bool eapRestart;
	bool altAccept;
	bool altReject;

	/* Peer to Lower Layer */
	bool eapResp;
	bool eapNoResp;
	bool eapSuccess;
	bool eapFail;
	msgbuf_t *eapRespData;
	eap_key_t *eapKeyData;
	bool eapKeyAvailable;

#define EAP_EVENT_RESP		0x01
#define EAP_EVENT_NO_RESP	0x02
#define EAP_EVENT_SUCCESS	0x03
#define EAP_EVENT_FAIL		0x04
#define EAP_EVENT_KEY_AVAIL	0x05

	/* Constants */
	int ClientTimeout;

	/* Interface between Peer State Machine and Methods */
	bool ignore;
	bool allowNotifications;
	int decision;
#define EAP_DECISION_FAIL		0
#define EAP_DECISION_COND_SUCC		1
#define EAP_DECISION_UNCOND_SUCC	2
	int methodState;
#define EAP_METHOD_NONE			0
#define EAP_METHOD_INIT			1
#define EAP_METHOD_CONT			2
#define EAP_METHOD_MAY_CONT		3
#define EAP_METHOD_DONE			4

	/* Long-Term (Maintained between Packets) */
	uint8_t selectedMethod;
	uint8_t lastId;
	msgbuf_t *lastRespData;

	/* Short-Term (Not Maintained between Packets) */
	bool rxReq;
	bool rxSuccess;
	bool rxFailure;
	uint8_t reqId;
	uint8_t reqMethod;

	list_t allowMethods;

	eap_profile_t *eapProfile;

	/* PAE Supplicant as lower layer */
	void *lowerLayer;
	void (*raiseEvent)(void *lower, int event);
	msgbuf_t *(*allocLowerMsg)(void *lower);
	const char *(*getUsername)(void *lower);
	const char *(*getPassword)(void *lower);

	/* Peer State Machine States */
	enum {
		EAP_PEER_DISABLED=0, EAP_PEER_INITIALIZE,
		EAP_PEER_IDLE, EAP_PEER_RECEIVED,
		EAP_PEER_DISCARD, EAP_PEER_SEND_RESPONSE,
		EAP_PEER_METHOD, EAP_PEER_GET_METHOD,
		EAP_PEER_IDENTITY, EAP_PEER_NOTIFICATION,
		EAP_PEER_RETRANSMIT,
		EAP_PEER_SUCCESS, EAP_PEER_FAILURE,
	} stm_state;
	int stm_changed;
};

/* Peer State Machine Procedures */
void eap_parseEapReq(eap_peer_t *sm);
void eap_processNotify(eap_peer_t *sm, msgbuf_t *req);
void eap_processIdentity(eap_peer_t *sm, msgbuf_t *req);
eap_method_t *eap_allowMethod(eap_peer_t *sm, uint8_t type);
void eap_buildNotify(eap_peer_t *sm);
void eap_buildIdentity(eap_peer_t *sm);
void eap_buildNak(eap_peer_t *sm);

void eap_peer_init(eap_peer_t *sm, eap_profile_t *prof, bool tunneling);
void eap_peer_exit(eap_peer_t *sm);
void eap_peer_run(eap_peer_t *sm);

void eap_enableMethod(eap_peer_t *sm, eap_method_t *m);
const char *eap_methodName(eap_peer_t *sm, uint8_t type);
void eap_disableMethod(eap_peer_t *sm, eap_method_t *m);

int eap_register_type(eap_type_t *type);
void eap_unregister_type(eap_type_t *type);
void eap_types_init(eap_peer_t *sm, unsigned long flags);
void eap_types_exit(eap_peer_t *sm);

eap_key_t *eap_key_new(uint8_t *data, int len);
void eap_key_free(eap_key_t *key);

eap_profile_t *eap_profile_new(void);
void eap_profile_free(eap_profile_t *prof);
eap_profile_t *eap_profile_by_name(const char *name);

#define EAP_SERVICE_NAME	"eap"

#endif /* __EAP_H_INCLUDE__ */
