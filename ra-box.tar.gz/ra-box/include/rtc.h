#ifndef __RTC_H_INCLUDE__
#define __RTC_H_INCLUDE__

#include <sysdep.h>

#define RTC_SERVICE_NAME	"rtc"

#endif /* __RTC_H_INCLUDE__ */
