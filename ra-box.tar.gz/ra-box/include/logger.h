#ifndef __LOGGER_H_INCLUDE__
#define __LOGGER_H_INCLUDE__

#include <sysdep.h>
#include <syslog.h>
#include <list.h>

#define KMSG_SERVICE_NAME	"kmsg"

#define LOG_MECH_NOTDEF		0x00
#define LOG_MECH_STREAM		0x01
#define LOG_MECH_SYSLOG		0x02
#define LOG_MECH_TERMIN		0x03	/* terminal, implemented by cli */

#define LOG_LEVEL_DEFAULT	LOG_DEBUG

typedef struct _log_source_t {
	const char *tag;
} log_source_t;

typedef struct _log_output_t log_output_t;

typedef struct _log_method_t {
	const char *name;
	int mech;
	void (*output)(log_output_t *out, int level, const char *string);
	list_t link;
} log_method_t;

#ifdef CONFIG_LOG
void logging(int logger, int level, const char *format, ...);
void loggingv(int logger, int level, const char *format, va_list args);
void log_kern(int level, const char *format, ...);
extern int log_logger;
#else
static inline void logging(int logger, int level, const char *format, ...)
{
}
static inline void loggingv(int logger, int level,
			    const char *format, va_list args)
{
}
static inline void log_kern(int level, const char *format, ...)
{
}
#endif

int log_register_source(log_source_t *src);
void log_unregister_source(int logger);

int log_register_method(log_method_t *mech);
void log_unregister_method(log_method_t *mech);
log_method_t *log_method_by_mech(int mech);

log_output_t *log_register_output(int mech, unsigned long param);
void log_unregister_output(log_output_t *out);
void log_set_level(log_output_t *out, int level);
unsigned long log_get_param(log_output_t *out);

int log_mech_by_name(const char *name);

#endif /* __LOGGER_H_INCLUDE__ */
