#include "udev_priv.h"

#define UDEV_SERVICE_DESC	"Dynamic device manager"

int udev_logger = 0;
log_source_t udev_log_source = {
	"udev",
};

void udev_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(udev_logger, level, format, ap);
	va_end(ap);
}

static int __init udev_log_init(void)
{
	udev_logger = log_register_source(&udev_log_source);
	return !udev_logger;
}

static void __exit udev_log_exit(void)
{
	log_unregister_source(udev_logger);
}

udev_device_t *udev_device_new(void)
{
	udev_device_t *udev;

	udev = malloc(sizeof(udev_device_t));
	if (udev == NULL)
		return NULL;
	memset(udev, 0x00, sizeof(udev_device_t));

	list_init(&udev->symlink_list);
	list_init(&udev->env_list);

	/* set sysfs device to local storage, can be overridden if needed */
	udev->dev = &udev->dev_local;

	/* default node permissions */
	udev->mode = 0660;
	strcpy(udev->owner, "root");
	strcpy(udev->group, "root");

	udev->event_timeout = -1;
	return udev;
}

void udev_device_free(udev_device_t *udev)
{
	udev_name_list_cleanup(&udev->symlink_list);
	udev_name_list_cleanup(&udev->env_list);
	if (udev->program_result)
		free(udev->program_result);
	free(udev);
}

static int udev_start(void)
{
	udev_event_start();
	/* scan cold-plugged devices */
	udev_cold_start();
	return 0;
}

static void udev_stop(void)
{
	udev_event_stop();
}

service_t udev_service = {
	UDEV_SERVICE_NAME,
	UDEV_SERVICE_DESC,
	SERVICE_UP_ALWAYS,
	SERVICE_FLAG_SYSTEM,
	LIST_HEAD_INIT(udev_service.depends),
	udev_start,
	udev_stop,
};

handle_t udev_handle;

static int __init udev_serv_init(void)
{
	udev_handle = register_service(&udev_service);
	return udev_handle ? 0 : -1;
}

static void __exit udev_serv_exit(void)
{
	unregister_service(udev_handle);
}

modlinkage int __init udev_init(void)
{
	udev_log_init();
	udev_serv_init();
	return 0;
}

modlinkage void __exit udev_exit(void)
{
	udev_serv_exit();
	udev_rule_exit();
	udev_log_exit();
}

core_initcall(udev_init);
core_exitcall(udev_exit);
