#include "udev_priv.h"

DECLARE_LIST(udev_progs);

#define for_each_prog(prog)	\
	list_for_each_entry(udev_prog_t, prog, &udev_progs, link)

int udev_prog_run(udev_event_t *msg, udev_device_t *dev,
		  const char *command, const char *subsystem)
{
	udev_prog_t *prog = udev_prog_by_name(command);

	if (!prog) {
		udev_log(UDEV_LOG_ERR,
			 "PROG: unregistered program, prog=%s, subsystem=%s",
			 command, subsystem);
		return -1;
	}

	if (dev->program_result) {
		free(dev->program_result);
		dev->program_result = strdup("");
		if (!dev->program_result) {
			udev_log(UDEV_LOG_ERR,
				 "PROG: no memory for program, prog=%s, subsystem=%s",
				 command, subsystem);
			return -1;
		}
	}

	return prog->program(msg, dev);
}

udev_prog_t *udev_prog_by_name(const char *name)
{
	udev_prog_t *prog;

	for_each_prog(prog) {
		if (strcasecmp(name, prog->name) == 0)
			return prog;
	}
	return NULL;
}

int udev_register_program(const char *name, udev_program_t program)
{
	udev_prog_t *prog = udev_prog_by_name(name);

	if (prog) {
		if (prog->program != program) {
			udev_log(UDEV_LOG_ERR, "PROG: duplicated program, prog=%s",
				 name);
			return -1;
		}
		return 0;
	}

	prog = malloc(sizeof (udev_prog_t));
	if (prog) {
		memset(prog, 0, sizeof (udev_prog_t));
		prog->name = name;
		prog->program = program;
		list_init(&prog->link);
		list_insert_before(&prog->link, &udev_progs);
	}
	return 0;
}

void udev_unregister_program(const char *name)
{
	udev_prog_t *prog = udev_prog_by_name(name);

	if (prog) {
		list_delete(&prog->link);
		free(prog);
	}
}
