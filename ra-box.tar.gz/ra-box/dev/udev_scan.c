#include "udev_priv.h"

#define UDEV_SCAN_DONE		0
#define UDEV_SCAN_DEVICES	1
#define UDEV_SCAN_SUBSYSTEM	2

struct _udev_trigger_t {
	list_t trigger_devices;
	list_t filter_match_subsystems;
	list_t filter_nomatch_subsystems;
	list_t filter_match_attrs;
	list_t filter_nomatch_attrs;
	const char *action;
	int scan;
	int subsystem;
};

static void udev_trigger_exec(udev_trigger_t *trigger);
static void udev_scan_subsystem(udev_trigger_t *trigger,
				const char *subsys, int scan);
static void udev_scan_class(udev_trigger_t *trigger);
static void udev_scan_block(udev_trigger_t *trigger);

static int udev_delay_device(const char *devpath)
{
	static const char *delay_udev_trigger_devices[] = {
		"*/md*",
		"*/dm-*",
		NULL
	};
	int i;

	for (i = 0; delay_udev_trigger_devices[i] != NULL; i++)
		if (fnmatch(delay_udev_trigger_devices[i], devpath, 0) == 0)
			return 1;
	return 0;
}

static int udev_trigger_devices_insert(udev_trigger_t *trigger, const char *path)
{
	char filename[PATH_SIZE];
	char devpath[PATH_SIZE];
	struct stat statbuf;

	/* we only have a device, if we have an uevent file */
	strlcpy(filename, path, sizeof(filename));
	strlcat(filename, "/uevent", sizeof(filename));
	if (stat(filename, &statbuf) < 0)
		return -1;
	if (!(statbuf.st_mode & S_IWUSR))
		return -1;

	strlcpy(devpath, &path[strlen(_PATH_SYS)], sizeof(devpath));

	/* resolve possible link to real target */
	if (lstat(path, &statbuf) < 0)
		return -1;
	if (S_ISLNK(statbuf.st_mode))
		if (sysfs_resolve_link(devpath, sizeof(devpath)) != 0)
			return -1;

	udev_log(UDEV_LOG_DEBUG, "TRIG: adding device, dev=%s" , path);
	udev_name_list_add(&trigger->trigger_devices, devpath, 1);
	return 0;
}

#ifdef WIN32
static int udev_emulate_uevent(const char *buf, int size)
{
	struct sockaddr_in saddr;
	int count = 16 * 1024 * 1024;
	int sock = -1;

	sock = socket(AF_INET, SOCK_DGRAM, 0);
	if (sock < 0) {
		return -1;
	}

	memset(&saddr, 0, sizeof(saddr));
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(UDEV_PORT);
	saddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	setsockopt(sock, SOL_SOCKET, SO_RCVBUFFORCE,
		   (const char *)&count, sizeof(count));

	count = sendto(sock, buf, size, 0, (struct sockaddr *)&saddr, sizeof(saddr));
	closesocket(sock);
	return count;
}

static void udev_trigger_uevent(const char *devpath, const char *action)
{
	udev_device_t *udev = NULL;
	udev_name_t *name_loop;
	char buf[4096];
	size_t bufpos = 0;
	ssize_t count;
	char path[PATH_SIZE];
	int fd;
	char link_target[PATH_SIZE];
	int len;
	int err = 0;

	udev = udev_device_new();

	/* add header */
	bufpos = snprintf(buf, sizeof(buf)-1, "%s@%s", action, devpath);
	bufpos++;

	/* add standard keys */
	bufpos += snprintf(&buf[bufpos], sizeof(buf)-1, "DEVPATH=%s", devpath);
	bufpos++;
	bufpos += snprintf(&buf[bufpos], sizeof(buf)-1, "ACTION=%s", action);
	bufpos++;

	/* add subsystem */
	strlcpy(path, _PATH_SYS, sizeof(path));
	strlcat(path, devpath, sizeof(path));
	strlcat(path, "/subsystem", sizeof(path));
	len = readlink(path, link_target, sizeof(link_target));
	if (len > 0) {
		char *pos;

		link_target[len] = '\0';
		pos = strrchr(link_target, '/');
		if (pos != NULL) {
			bufpos += snprintf(&buf[bufpos], sizeof(buf)-1, "SUBSYSTEM=%s", &pos[1]);
			bufpos++;
		}
	}

	/* add symlinks and node name */
	path[0] = '\0';
	for_each_name(name_loop, udev->symlink_list) {
		strlcat(path, _PATH_DEV, sizeof(path));
		if (strlast(path) != '/')
			strlcat(path, "/", sizeof(path));
		strlcat(path, name_loop->name, sizeof(path));
		strlcat(path, " ", sizeof(path));
	}
	remove_trailing_chars(path, ' ');
	if (path[0] != '\0') {
		bufpos += snprintf(&buf[bufpos], sizeof(buf)-1, "DEVLINKS=%s", path);
		bufpos++;
	}
	if (udev->name[0] != '\0') {
		strlcpy(path, _PATH_DEV, sizeof(path));
		if (strlast(path) != '/')
			strlcat(path, "/", sizeof(path));
		strlcat(path, udev->name, sizeof(path));
		bufpos += snprintf(&buf[bufpos], sizeof(buf)-1, "DEVNAME=%s", path);
		bufpos++;
	}

	/* add keys from device "uevent" file */
	strlcpy(path, _PATH_SYS, sizeof(path));
	strlcat(path, devpath, sizeof(path));
	strlcat(path, "/uevent", sizeof(path));
	fd = open(path, O_RDONLY);
	if (fd >= 0) {
		char value[4096];

		count = read(fd, value, sizeof(value));
		close(fd);
		if (count > 0) {
			char *key;

			value[count] = '\0';
			key = value;
			while (key[0] != '\0') {
				char *next;

				next = strchr(key, '\n');
				if (next == NULL)
					break;
				next[0] = '\0';
				bufpos += strlcpy(&buf[bufpos], key, sizeof(buf) - bufpos-1);
				bufpos++;
				key = &next[1];
			}
		}
	}

	/* add keys from database */
	for_each_name(name_loop, udev->env_list) {
		bufpos += strlcpy(&buf[bufpos], name_loop->name, sizeof(buf) - bufpos-1);
		bufpos++;
	}
	if (bufpos > sizeof(buf))
		bufpos = sizeof(buf);

	count = udev_emulate_uevent(buf, bufpos);
	if (count < 0)
		err = -1;
}
#else
static void udev_trigger_uevent(const char *devpath, const char *action)
{
	char filename[PATH_SIZE];
	int fd;

	strlcpy(filename, _PATH_SYS, sizeof(filename));
	strlcat(filename, devpath, sizeof(filename));
	strlcat(filename, "/uevent", sizeof(filename));

	fd = open(filename, O_WRONLY);
	if (fd < 0) {
		udev_log(UDEV_LOG_DEBUG, "TRIG: error on opening %s: %s",
			 filename, strerror(errno));
		return;
	}

	if (write(fd, action, strlen(action)) < 0) {
		udev_log(UDEV_LOG_INFO, "TRIG: error writing '%s' to '%s': %s",
			 action, filename, strerror(errno));
	}
	close(fd);
}
#endif

static void udev_trigger_step(void *eloop, void *user)
{
	udev_trigger_t *trigger = (udev_trigger_t *)user;
	udev_trigger_exec(trigger);
}

static void udev_trigger_exec(udev_trigger_t *trigger)
{
	udev_name_t *loop_device;
	udev_name_t *tmp_device;

	for_each_name_safe(loop_device, tmp_device, trigger->trigger_devices) {
		if (udev_delay_device(loop_device->name))
			continue;
		udev_trigger_uevent(loop_device->name, trigger->action);
		list_delete(&loop_device->node);
		free(loop_device);
		eloop_register_timeout(NULL, 0, 0, udev_trigger_step, NULL, trigger);
		return;
	}

	/* trigger remaining delayed devices */
	for_each_name_safe(loop_device, tmp_device, trigger->trigger_devices) {
		udev_trigger_uevent(loop_device->name, trigger->action);
		list_delete(&loop_device->node);
		free(loop_device);
		eloop_register_timeout(NULL, 0, 0, udev_trigger_step, NULL, trigger);
		return;
	}

	if (trigger->scan == UDEV_SCAN_SUBSYSTEM) {
		trigger->scan = UDEV_SCAN_DEVICES;
		if (trigger->subsystem) {
			udev_scan_subsystem(trigger, "subsystem", UDEV_SCAN_DEVICES);
		} else {
			char base[PATH_SIZE];
			struct stat statbuf;

			udev_scan_subsystem(trigger, "bus", UDEV_SCAN_DEVICES);
			udev_scan_class(trigger);

			strlcpy(base, _PATH_SYS, sizeof(base));
			strlcat(base, "/subsystem", sizeof(base));

			/* scan "block" if it isn't a "class" */
			strlcpy(base, _PATH_SYS, sizeof(base));
			strlcat(base, "/class/block", sizeof(base));
			if (stat(base, &statbuf) != 0)
				udev_scan_block(trigger);
		}
		udev_trigger_exec(trigger);
	} else {
		trigger->scan = UDEV_SCAN_DONE;
		udev_trigger_free(trigger);
	}
}

static int udev_subsystem_filtered(udev_trigger_t *trigger, const char *subsystem)
{
	udev_name_t *loop_name;

	/* skip devices matching the listed subsystems */
	for_each_name(loop_name, trigger->filter_nomatch_subsystems)
		if (fnmatch(loop_name->name, subsystem, 0) == 0)
			return 1;

	/* skip devices not matching the listed subsystems */
	if (!list_empty(&trigger->filter_match_subsystems)) {
		for_each_name(loop_name, trigger->filter_match_subsystems)
			if (fnmatch(loop_name->name, subsystem, 0) == 0)
				return 0;
		return 1;
	}

	return 0;
}

static int udev_attr_match(const char *path, const char *attr_value)
{
	char attr[NAME_SIZE];
	char file[PATH_SIZE];
	char *match_value;

	strlcpy(attr, attr_value, sizeof(attr));

	/* separate attr and match value */
	match_value = strchr(attr, '=');
	if (match_value != NULL) {
		match_value[0] = '\0';
		match_value = &match_value[1];
	}

	strlcpy(file, path, sizeof(file));
	strlcat(file, "/", sizeof(file));
	strlcat(file, attr, sizeof(file));

	if (match_value != NULL) {
		/* match file content */
		char value[NAME_SIZE];
		int fd;
		ssize_t size;

		fd = open(file, O_RDONLY);
		if (fd < 0)
			return 0;
		size = read(fd, value, sizeof(value));
		close(fd);
		if (size < 0)
			return 0;
		value[size] = '\0';
		remove_trailing_chars(value, '\n');

		/* match if attribute value matches */
		if (fnmatch(match_value, value, 0) == 0)
			return 1;
	} else {
		/* match if attribute exists */
		struct stat statbuf;

		if (stat(file, &statbuf) == 0)
			return 1;
	}
	return 0;
}

static int udev_attr_filtered(udev_trigger_t *trigger, const char *path)
{
	udev_name_t *loop_name;

	/* skip devices matching the listed sysfs attributes */
	for_each_name(loop_name, trigger->filter_nomatch_attrs)
		if (udev_attr_match(path, loop_name->name))
			return 1;

	/* skip devices not matching the listed sysfs attributes */
	if (!list_empty(&trigger->filter_match_attrs)) {
		for_each_name(loop_name, trigger->filter_match_attrs)
			if (udev_attr_match(path, loop_name->name))
				return 0;
		return 1;
	}
	return 0;
}

static void udev_scan_subsystem(udev_trigger_t *trigger,
				const char *subsys, int scan)
{
	char base[PATH_SIZE];
	DIR *dir;
	struct _dirent *dent;
	const char *subdir;

	if (scan == UDEV_SCAN_DEVICES)
		subdir = "/devices";
	else if (scan == UDEV_SCAN_SUBSYSTEM)
		subdir = "/drivers";
	else
		return;

	strlcpy(base, _PATH_SYS, sizeof(base));
	strlcat(base, "/", sizeof(base));
	strlcat(base, subsys, sizeof(base));

	dir = opendir(base);
	if (dir != NULL) {
		for (dent = readdir(dir); dent != NULL; dent = readdir(dir)) {
			char dirname[PATH_SIZE];
			DIR *dir2;
			struct _dirent *dent2;

			if (dent->d_name[0] == '.')
				continue;

			if (scan == UDEV_SCAN_DEVICES) {
				if (udev_subsystem_filtered(trigger, dent->d_name))
					continue;
			}

			strlcpy(dirname, base, sizeof(dirname));
			strlcat(dirname, "/", sizeof(dirname));
			strlcat(dirname, dent->d_name, sizeof(dirname));

			if (scan == UDEV_SCAN_SUBSYSTEM) {
				if (!udev_subsystem_filtered(trigger, "subsystem"))
					udev_trigger_devices_insert(trigger, dirname);
				if (udev_subsystem_filtered(trigger, "drivers"))
					continue;
			}

			strlcat(dirname, subdir, sizeof(dirname));

			/* look for devices/drivers */
			dir2 = opendir(dirname);
			if (dir2 != NULL) {
				for (dent2 = readdir(dir2); dent2 != NULL; dent2 = readdir(dir2)) {
					char dirname2[PATH_SIZE];

					if (dent2->d_name[0] == '.')
						continue;

					strlcpy(dirname2, dirname, sizeof(dirname2));
					strlcat(dirname2, "/", sizeof(dirname2));
					strlcat(dirname2, dent2->d_name, sizeof(dirname2));
					if (udev_attr_filtered(trigger, dirname2))
						continue;
					udev_trigger_devices_insert(trigger, dirname2);
				}
				closedir(dir2);
			}
		}
		closedir(dir);
	}
}

static void udev_scan_block(udev_trigger_t *trigger)
{
	char base[PATH_SIZE];
	DIR *dir;
	struct _dirent *dent;

	if (udev_subsystem_filtered(trigger, "block"))
		return;

	strlcpy(base, _PATH_SYS, sizeof(base));
	strlcat(base, "/block", sizeof(base));

	dir = opendir(base);
	if (dir != NULL) {
		for (dent = readdir(dir); dent != NULL; dent = readdir(dir)) {
			char dirname[PATH_SIZE];
			DIR *dir2;
			struct _dirent *dent2;

			if (dent->d_name[0] == '.')
				continue;

			strlcpy(dirname, base, sizeof(dirname));
			strlcat(dirname, "/", sizeof(dirname));
			strlcat(dirname, dent->d_name, sizeof(dirname));
			if (udev_attr_filtered(trigger, dirname))
				continue;
			if (udev_trigger_devices_insert(trigger, dirname) != 0)
				continue;

			/* look for partitions */
			dir2 = opendir(dirname);
			if (dir2 != NULL) {
				for (dent2 = readdir(dir2); dent2 != NULL; dent2 = readdir(dir2)) {
					char dirname2[PATH_SIZE];

					if (dent2->d_name[0] == '.')
						continue;

					if (!strcmp(dent2->d_name,"device"))
						continue;

					strlcpy(dirname2, dirname, sizeof(dirname2));
					strlcat(dirname2, "/", sizeof(dirname2));
					strlcat(dirname2, dent2->d_name, sizeof(dirname2));
					if (udev_attr_filtered(trigger, dirname2))
						continue;
					udev_trigger_devices_insert(trigger, dirname2);
				}
				closedir(dir2);
			}
		}
		closedir(dir);
	}
}

static void udev_scan_class(udev_trigger_t *trigger)
{
	char base[PATH_SIZE];
	DIR *dir;
	struct _dirent *dent;

	strlcpy(base, _PATH_SYS, sizeof(base));
	strlcat(base, "/class", sizeof(base));

	dir = opendir(base);
	if (dir != NULL) {
		for (dent = readdir(dir); dent != NULL; dent = readdir(dir)) {
			char dirname[PATH_SIZE];
			DIR *dir2;
			struct _dirent *dent2;

			if (dent->d_name[0] == '.')
				continue;

			if (udev_subsystem_filtered(trigger, dent->d_name))
				continue;

			strlcpy(dirname, base, sizeof(dirname));
			strlcat(dirname, "/", sizeof(dirname));
			strlcat(dirname, dent->d_name, sizeof(dirname));
			dir2 = opendir(dirname);
			if (dir2 != NULL) {
				for (dent2 = readdir(dir2); dent2 != NULL; dent2 = readdir(dir2)) {
					char dirname2[PATH_SIZE];

					if (dent2->d_name[0] == '.')
						continue;

					if (!strcmp(dent2->d_name, "device"))
						continue;

					strlcpy(dirname2, dirname, sizeof(dirname2));
					strlcat(dirname2, "/", sizeof(dirname2));
					strlcat(dirname2, dent2->d_name, sizeof(dirname2));
					if (udev_attr_filtered(trigger, dirname2))
						continue;
					udev_trigger_devices_insert(trigger, dirname2);
				}
				closedir(dir2);
			}
		}
		closedir(dir);
	}
}

void udev_event_trigger(udev_trigger_t *trigger, const char *action)
{
	char base[PATH_SIZE];
	struct stat statbuf;

	if (!action)
		trigger->action = "add";
	else
		trigger->action = action;

	/* if we have /sys/subsystem, forget all the old stuff */
	strlcpy(base, _PATH_SYS, sizeof(base));
	strlcat(base, "/subsystem", sizeof(base));
	trigger->scan = UDEV_SCAN_SUBSYSTEM;
	if (stat(base, &statbuf) == 0) {
		trigger->subsystem = 1;
		udev_scan_subsystem(trigger, "subsystem", UDEV_SCAN_SUBSYSTEM);
	} else {
		trigger->subsystem = 0;
		udev_scan_subsystem(trigger, "bus", UDEV_SCAN_SUBSYSTEM);
	}
	udev_trigger_exec(trigger);
}

udev_trigger_t *udev_trigger_new(void)
{
	udev_trigger_t *trigger = malloc(sizeof (udev_trigger_t));
	if (trigger) {
		memset(trigger, 0, sizeof (udev_trigger_t));
		list_init(&trigger->trigger_devices);
		list_init(&trigger->filter_nomatch_subsystems);
		list_init(&trigger->filter_match_subsystems);
		list_init(&trigger->filter_nomatch_attrs);
		list_init(&trigger->filter_match_attrs);
	}
	return trigger;
}

void udev_trigger_free(udev_trigger_t *trigger)
{
	if (trigger) {
		udev_name_list_cleanup(&trigger->filter_match_subsystems);
		udev_name_list_cleanup(&trigger->filter_nomatch_subsystems);
		udev_name_list_cleanup(&trigger->filter_match_attrs);
		udev_name_list_cleanup(&trigger->filter_nomatch_attrs);
		udev_name_list_cleanup(&trigger->trigger_devices);
		free(trigger);
	}
}

void udev_filter_subsystem(udev_trigger_t *trigger, const char *subsystem, int match)
{
	if (match)
		udev_name_list_add(&trigger->filter_match_subsystems, subsystem, 0);
	else
		udev_name_list_add(&trigger->filter_nomatch_subsystems, subsystem, 0);
}

void udev_filter_attr(udev_trigger_t *trigger, const char *attr, int match)
{
	if (match)
		udev_name_list_add(&trigger->filter_match_attrs, attr, 0);
	else
		udev_name_list_add(&trigger->filter_nomatch_attrs, attr, 0);
}

#ifdef WIN32
char *udev_cold_events[] = {
/* usbdev */
"add@/class/usb_device/usbdev3.2\0\
ACTION=add\0\
DEVPATH=/class/usb_device/usbdev3.2\0\
SUBSYSTEM=usb_device\0\
SEQNUM=1278\0\
PHYSDEVPATH=/devices/pci0000:00/0000:00:1d.7/usb3/3-3\0\
PHYSDEVBUS=usb\0\
PHYSDEVDRIVER=usb\0\
MAJOR=189\0\
MINOR=257\0\0",

/* kmsg */
"add@/class/mem/kmsg\0\
ACTION=add\0\
DEVPATH=/class/mem/kmsg\0\
SUBSYSTEM=mem\0\
SEQNUM=1140\0\
MAJOR=1\0\
MINOR=11\0\0",

/* ptmx */
"add@/class/tty/ptmx\0\
ACTION=add\0\
DEVPATH=/class/tty/ptmx\0\
SUBSYSTEM=tty\0\
SEQNUM=1173\0\
MAJOR=5\0\
MINOR=2\0\0",

/* vitgenio */
"add@/class/misc/vitgenio\0\
ACTION=add\0\
DEVPATH=/class/misc/vitgenio\0\
SUBSYSTEM=misc\0\
SEQNUM=1173\0\
MAJOR=10\0\
MINOR=240\0\0",

/* netdev */
"add@/class/net/eth0\0\
UDEV_LOG=3\0\
ACTION=add\0\
DEVPATH=/class/net/eth0\0\
SUBSYSTEM=net\0\
SEQNUM=1153\0\
PHYSDEVPATH=/devices/pci0000:00/0000:00:1e.0/0000:01:05.0\0\
PHYSDEVBUS=pci\0\
PHYSDEVDRIVER=8139too\0\
INTERFACE=eth0\0\
UDEVD_EVENT=1\0\0",

"add@/class/net/lo\0\
UDEV_LOG=3\0\
ACTION=add\0\
DEVPATH=/class/net/lo\0\
SUBSYSTEM=net\0\
SEQNUM=1154\0\
INTERFACE=lo\0\
UDEVD_EVENT=1\0\
COMMENT=Unknown net device (/class/net/lo)\0\0",
};
int udev_event_num = sizeof (udev_cold_events) / sizeof (char *);
int udev_event_iter = 0;

int udev_event_size(const char *buf)
{
	int i = 0;
	while (1) {
		if (buf[i] == 0 && buf[i+1] == 0)
			break;
		i++;
	}
	return i;
}

void udev_scan_emulate(void *eloop, void *data)
{
	if (udev_event_iter < udev_event_num) {
		udev_emulate_uevent(udev_cold_events[udev_event_iter],
				    udev_event_size(udev_cold_events[udev_event_iter]));
		eloop_register_timeout(NULL, 0, 0, udev_scan_emulate, NULL, NULL);
		udev_event_iter++;
	}
}

void udev_event_emulate(udev_trigger_t *trigger)
{
	eloop_register_timeout(NULL, 0, 0, udev_scan_emulate, NULL, NULL);
}
#endif

int udev_scan_coldplug(void)
{
	udev_trigger_t *trigger = udev_trigger_new();

	if (!trigger) {
		udev_log(UDEV_LOG_CRIT, "TRIG: cannot create uevent trigger");
		return -1;
	}
#ifdef WIN32
	udev_event_emulate(trigger);
#else
	udev_event_trigger(trigger, NULL);
#endif
	return 0;
}

static void udev_scan_timeout(void *eloop, void *user)
{
	udev_scan_coldplug();
}

int udev_cold_start(void)
{
	eloop_register_timeout(NULL, 0, 0, udev_scan_timeout, NULL, NULL);
	return 0;
}
