#include "udev_priv.h"
#include <linux/if.h>
#include <linux/sockios.h>

#define UDEV_EVENT_QUEUED	0
#define UDEV_EVENT_FINISHED	1
#define UDEV_EVENT_FAILED	2

static int udev_event_sock = -1;

/* events get queued */
static DECLARE_LIST(udev_pending_events);
/* events is running */
static DECLARE_LIST(udev_running_events);
static DECLARE_LIST(udev_failed_events);
static int max_childs;

#define for_each_event(event, head)		\
	list_for_each_entry(udev_event_t, event, &head, node)
#define for_each_event_safe(event, tmp, head)	\
	list_for_each_entry_safe(udev_event_t, event, tmp, &head, node)

static void udev_event_run(udev_event_t *msg);
static int udev_event_process(udev_event_t *msg);
static void udev_queue_timeout(void *eloop_data, void *user_data);
static void udev_netlink_event(int fd, void *eloop_data, void *user_data);

static void udev_sync_event_state(udev_event_t *msg, int state)
{
	udev_event_t *msg_loop, *msg_tmp;

	switch (state) {
	case UDEV_EVENT_QUEUED:
		/* delete failed events */
		for_each_event_safe(msg_loop, msg_tmp, udev_failed_events) {
			if (strcmp(msg_loop->devpath, msg->devpath) == 0) {
				list_delete(&msg_loop->node);
				udev_event_free(msg_loop);
			}
		}
		break;
	case UDEV_EVENT_FINISHED:
		if (msg->devpath_old != NULL) {
			/* "move" event */
			/* rename failed events to current name */
			for_each_event(msg_loop, udev_failed_events) {
				if (strcmp(msg_loop->devpath, msg->devpath_old) == 0) {
					/* rename it */
					int old_buf_size = sizeof (udev_event_t) + msg_loop->buf_size;
					int buf_size;

					buf_size = old_buf_size + strlen(msg->devpath_old) + 1;
					msg_loop = realloc(msg_loop, buf_size);
					if (msg_loop) {
						memcpy(msg_loop->devpath+old_buf_size,
						       msg->devpath_old, strlen(msg->devpath_old) + 1);
						msg_loop->devpath = msg_loop->devpath+old_buf_size;
					}
				}
			}
		}
		udev_event_free(msg);
		break;
	case UDEV_EVENT_FAILED:
		/* create failed event */
		list_insert_tail(&msg->node, &udev_failed_events);
		break;
	}
}

static void udev_queue_delete(udev_event_t *msg)
{
	list_delete_init(&msg->node);

	/* mark as failed, if "add" event returns non-zero */
	if (msg->exitstatus && strcmp(msg->action, "add") == 0)
		udev_sync_event_state(msg, UDEV_EVENT_FAILED);
	else
		udev_sync_event_state(msg, UDEV_EVENT_FINISHED);
}

static void udev_queue_insert(udev_event_t *msg)
{
	msg->queue_time = time(NULL);

	udev_sync_event_state(msg, UDEV_EVENT_QUEUED);

	/* run all events with a timeout set immediately */
	if (msg->timeout != 0) {
		list_insert_tail(&msg->node, &udev_running_events);
		udev_event_run(msg);
		return;
	}

	list_insert_tail(&msg->node, &udev_pending_events);
	eloop_register_timeout(NULL, 0, 0, udev_queue_timeout, NULL, NULL);
}

int udev_event_settled(void)
{
	return list_empty(&udev_pending_events) && list_empty(&udev_running_events);
}

static void udev_failed_timeout(void *eloop_data, void *user_data)
{
}

void udev_retry_failed(void)
{
	eloop_register_timeout(NULL, 0, 0, udev_failed_timeout, NULL, NULL);
}

static int compare_devpath(const char *running, const char *waiting)
{
	int i;

	for (i = 0; i < PATH_SIZE; i++) {
		/* identical device event found */
		if (running[i] == '\0' && waiting[i] == '\0')
			return 1;

		/* parent device event found */
		if (running[i] == '\0' && waiting[i] == '/')
			return 2;

		/* child device event found */
		if (running[i] == '/' && waiting[i] == '\0')
			return 3;

		/* no matching event */
		if (running[i] != waiting[i])
			break;
	}

	return 0;
}

/* lookup event for identical, parent, child, or physical device */
static int udev_devpath_busy(udev_event_t *msg, int limit)
{
	udev_event_t *loop_msg;
	int childs_count = 0;

	/* check exec-queue which may still contain delayed events we depend on */
	for_each_event(loop_msg, udev_pending_events) {
		/* skip ourself and all later events */
		if (loop_msg->seqnum >= msg->seqnum)
			break;

		/* check our old name */
		if (msg->devpath_old != NULL)
			if (strcmp(loop_msg->devpath , msg->devpath_old) == 0)
				return 2;

		/* check identical, parent, or child device event */
		if (compare_devpath(loop_msg->devpath, msg->devpath) != 0) {
			udev_log(UDEV_LOG_DEBUG,
				 "EVENT: %llu, device event still pending %llu (%s)",
				 msg->seqnum, loop_msg->seqnum, loop_msg->devpath);
			return 3;
		}

		/* check for our major:minor number */
		if (msg->devt && loop_msg->devt == msg->devt &&
		    strcmp(msg->subsystem, loop_msg->subsystem) == 0) {
			udev_log(UDEV_LOG_DEBUG,
				 "EVENT: %llu, device event still pending %llu (%d:%d)",
				 msg->seqnum, loop_msg->seqnum,
				 major(loop_msg->devt), minor(loop_msg->devt));
			return 4;
		}

		/* check physical device event (special case of parent) */
		if (msg->physdevpath && msg->action && strcmp(msg->action, "add") == 0)
			if (compare_devpath(loop_msg->devpath, msg->physdevpath) != 0) {
				udev_log(UDEV_LOG_DEBUG,
					 "EVENT: %llu, physical device event still pending %llu (%s)",
					 msg->seqnum, loop_msg->seqnum, loop_msg->devpath);
				return 5;
			}
	}

	/* check run queue for still running events */
	for_each_event(loop_msg, udev_running_events) {
		if (limit && childs_count++ > limit) {
			udev_log(UDEV_LOG_DEBUG,
				 "EVENT: %llu, maximum number (%i) of childs reached",
				 msg->seqnum, childs_count);
			return 1;
		}

		/* check our old name */
		if (msg->devpath_old != NULL)
			if (strcmp(loop_msg->devpath , msg->devpath_old) == 0)
				return 2;

		/* check identical, parent, or child device event */
		if (compare_devpath(loop_msg->devpath, msg->devpath) != 0) {
			udev_log(UDEV_LOG_DEBUG,
				 "EVENT: %llu, device event still running %llu (%s)",
				 msg->seqnum, loop_msg->seqnum, loop_msg->devpath);
			return 3;
		}

		/* check for our major:minor number */
		if (msg->devt && loop_msg->devt == msg->devt &&
		    strcmp(msg->subsystem, loop_msg->subsystem) == 0) {
			udev_log(UDEV_LOG_DEBUG,
				 "EVENT: %llu, device event still running %llu (%d:%d)",
				 msg->seqnum, loop_msg->seqnum, major(loop_msg->devt),
				 minor(loop_msg->devt));
			return 4;
		}

		/* check physical device event (special case of parent) */
		if (msg->physdevpath && msg->action && strcmp(msg->action, "add") == 0) {
			if (compare_devpath(loop_msg->devpath, msg->physdevpath) != 0) {
				udev_log(UDEV_LOG_DEBUG,
					 "EVENT: %llu, physical device event still running %llu (%s)",
					 msg->seqnum, loop_msg->seqnum, loop_msg->devpath);
				return 5;
			}
		}
	}
	return 0;
}

static void udev_queue_manager(void)
{
	udev_event_t *loop_msg;
	udev_event_t *tmp_msg;

	if (list_empty(&udev_pending_events))
		return;

	for_each_event_safe(loop_msg, tmp_msg, udev_pending_events) {
		/* serialize and wait for parent or child events */
		if (udev_devpath_busy(loop_msg, max_childs) != 0) {
			continue;
		}

		/* move event to run list */
		list_move_tail(&loop_msg->node, &udev_running_events);
		udev_event_run(loop_msg);
		eloop_register_timeout(NULL, 0, 0, udev_queue_timeout, NULL, NULL);
		return;
	}
}

static void udev_netif_klog(struct ifreq ifr)
{
	int klog;
	FILE *f;

	klog = open("/dev/kmsg", O_WRONLY);
	if (klog < 0)
		return;

	f = fdopen(klog, "w");
	if (f == NULL) {
		close(klog);
		return;
	}

	fprintf(f, "<6>udev: renamed network interface %s to %s\n",
		ifr.ifr_name, ifr.ifr_newname);
	fclose(f);
}

static int udev_netif_rename(udev_device_t *udev)
{
	int sk;
	struct ifreq ifr;
	int retval;

	udev_log(UDEV_LOG_INFO,
		 "NETIF: changing net interface name from '%s' to '%s'",
		 udev->dev->kernel, udev->name);

	sk = socket(PF_INET, SOCK_DGRAM, 0);
	if (sk < 0) {
		udev_log(UDEV_LOG_ERR, "NETIF: socket(PF_INET, SOCK_DGRAM) failure");
		return -1;
	}

	memset(&ifr, 0x00, sizeof(struct ifreq));
	strlcpy(ifr.ifr_name, udev->dev->kernel, IFNAMSIZ);
	strlcpy(ifr.ifr_newname, udev->name, IFNAMSIZ);
	retval = ioctl(sk, SIOCSIFNAME, (unsigned long)&ifr);
	if (retval == 0) {
		udev_netif_klog(ifr);
	} else {
		int loop;

		/* see if the destination interface name already exists */
		if (errno != EEXIST) {
			udev_log(UDEV_LOG_ERR,
				 "NETIF: error changing netif name, old=%s, new=%s",
				 ifr.ifr_name, ifr.ifr_newname);
			goto exit;
		}

		/* free our own name, another process may wait for us */
		strlcpy(ifr.ifr_newname, udev->dev->kernel, IFNAMSIZ);
		strlcat(ifr.ifr_newname, "_rename", IFNAMSIZ);
		retval = ioctl(sk, SIOCSIFNAME, (unsigned long)&ifr);
		if (retval != 0) {
			udev_log(UDEV_LOG_ERR,
				 "NETIF: error changing netif name, old=%s, new=%s",
				 ifr.ifr_name, ifr.ifr_newname);
			goto exit;
		}

		/* wait 30 seconds for our target to become available */
		strlcpy(ifr.ifr_name, ifr.ifr_newname, IFNAMSIZ);
		strlcpy(ifr.ifr_newname, udev->name, IFNAMSIZ);
		loop = 30 * 20;
		while (loop--) {
			retval = ioctl(sk, SIOCSIFNAME, (unsigned long)&ifr);
			if (retval == 0) {
				udev_netif_klog(ifr);
				break;
			}

			if (errno != EEXIST) {
				udev_log(UDEV_LOG_ERR,
					 "NETIF: error changing net interface name, old=%s, new=%s",
					 ifr.ifr_name, ifr.ifr_newname);
				break;
			}
			udev_log(UDEV_LOG_DEBUG,
				 "NETIF: wait for netif '%s' to become free, loop=%i",
				 udev->name, (30 * 20) - loop);
			usleep(1000 * 1000 / 20);
		}
	}

exit:
	close(sk);
	return retval;
}

static int udev_device_event(udev_rules_t *rules, udev_device_t *udev,
			     udev_event_t *msg)
{
	int retval = 0;

	/* add device node */
	if (major(udev->devt) != 0 &&
	    (strcmp(udev->action, "add") == 0 || strcmp(udev->action, "change") == 0)) {
		udev_log(UDEV_LOG_DEBUG,
			 "EVENT: device node add, node=%s", udev->dev->devpath);

		udev_rules_get_name(msg, rules, udev);
		if (udev->ignore_device) {
			udev_log(UDEV_LOG_DEBUG,
				 "EVENT: device event will be ignored");
			goto exit;
		}
		if (udev->name[0] == '\0') {
			udev_log(UDEV_LOG_DEBUG,
				 "EVENT: device node creation supressed");
			goto exit;
		}

		/* create node */
		retval = udev_node_add(udev, msg);
		if (retval != 0)
			goto exit;
		goto exit;
	}

	/* add netif */
	if (strcmp(udev->dev->subsystem, "net") == 0 && strcmp(udev->action, "add") == 0) {
		udev_log(UDEV_LOG_DEBUG, "EVENT: netif add, devpath=%s",
			 udev->dev->devpath);
		udev_rules_get_name(msg, rules, udev);
		if (udev->ignore_device) {
			udev_log(UDEV_LOG_DEBUG,
				 "EVENT: device event will be ignored");
			goto exit;
		}
		if (udev->name[0] == '\0') {
			udev_log(UDEV_LOG_DEBUG,
				 "EVENT: device renaming supressed");
			goto exit;
		}

		/* look if we want to change the name of the netif */
		if (strcmp(udev->name, udev->dev->kernel) != 0) {
			char devpath[PATH_MAX];
			char *pos;

			retval = udev_netif_rename(udev);
			if (retval != 0)
				goto exit;
			udev_log(UDEV_LOG_INFO,
				 "EVENT: renamed netif, name=%s", udev->name);

			/* export old name */
			udev_event_setenv(msg, "INTERFACE_OLD", udev->dev->kernel, 1);

			/* now change the devpath, because the kernel device name has changed */
			strlcpy(devpath, udev->dev->devpath, sizeof(devpath));
			pos = strrchr(devpath, '/');
			if (pos != NULL) {
				pos[1] = '\0';
				strlcat(devpath, udev->name, sizeof(devpath));
				sysfs_device_set_values(udev->dev, devpath, NULL, NULL);
				udev_event_setenv(msg, "DEVPATH", udev->dev->devpath, 1);
				udev_event_setenv(msg, "INTERFACE", udev->name, 1);
				udev_log(UDEV_LOG_INFO,
					 "EVENT: changed devpath, devpath=%s",
					 udev->dev->devpath);
			}
		}
		goto exit;
	}

	/* remove device node */
	if (major(udev->devt) != 0 && strcmp(udev->action, "remove") == 0) {
		udev_log(UDEV_LOG_DEBUG,
			 "EVENT: device node remove, node=%s", udev->dev->devpath);

		udev_rules_get_name(msg, rules, udev);
		if (udev->name[0] == '\0') {
			udev_log(UDEV_LOG_DEBUG,
				 "EVENT: device node deletion supressed");
			strlcpy(udev->name, udev->dev->kernel, sizeof(udev->name));
		}

		udev_rules_get_run(msg, rules, udev);
		if (udev->ignore_device) {
			udev_log(UDEV_LOG_INFO,
				 "EVENT: device event will be ignored");
			goto exit;
		}

		if (udev->ignore_remove) {
			udev_log(UDEV_LOG_INFO,
				 "EVENT: ignore_remove for '%s'", udev->name);
			goto exit;
		}
		/* remove the node */
		retval = udev_node_remove(udev, msg);
		goto exit;
	}

	/* default devices */
	udev_rules_get_run(msg, rules, udev);
	if (udev->ignore_device)
		udev_log(UDEV_LOG_INFO, "EVENT: device event will be ignored");

exit:
	return retval;
}

static void udev_event_run(udev_event_t *msg)
{
	int retval;

	retval = udev_event_process(msg);
	msg->exitstatus = retval;
	udev_queue_delete(msg);
}

static void udev_queue_timeout(void *eloop_data, void *user_data)
{
	udev_queue_manager();
}

static int udev_event_process(udev_event_t *msg)
{
	udev_device_t *udev;
	int retval;

	udev = udev_device_new();
	if (udev == NULL)
		return -1;
	strlcpy(udev->action, msg->action, sizeof(udev->action));
	sysfs_device_set_values(udev->dev, msg->devpath, msg->subsystem, msg->driver);
	udev->devpath_old = msg->devpath_old;
	udev->devt = msg->devt;

	retval = udev_device_event(&udev_rules, udev, msg);

	udev_device_free(udev);
	return retval;
}

void udev_event_free(udev_event_t *msg)
{
	if (msg) {
		udev_event_clearenv(msg);
		free(msg);
	}
}

udev_event_t *udev_event_new(int buf_size)
{
	udev_event_t *msg;

	msg = malloc(sizeof(udev_event_t) + buf_size);
	if (msg == NULL)
		return NULL;
	memset(msg, 0x00, sizeof(udev_event_t) + buf_size);
	msg->buf_size = buf_size;

	return msg;
}

udev_event_t *udev_event_parse(const char *buf, int buf_size)
{
	int bufpos;
	int i;
	udev_event_t *msg;
	char *physdevdriver_key = NULL;
	int maj = 0;
	int min = 0;

	msg = udev_event_new(buf_size);
	if (msg == NULL)
		return NULL;

	/* copy environment buffer and reconstruct envp */
	memcpy(msg->envbuf, buf, buf_size);
	bufpos = 0;
	for (i = 0; (bufpos < buf_size); i++) {
		int keylen;
		char *key;

		key = &msg->envbuf[bufpos];
		keylen = strlen(key);
		udev_event_putenv(msg, key);
		bufpos += keylen + 1;

		/* remember some keys for further processing */
		if (strncmp(key, "ACTION=", 7) == 0)
			msg->action = &key[7];
		else if (strncmp(key, "DEVPATH=", 8) == 0)
			msg->devpath = &key[8];
		else if (strncmp(key, "SUBSYSTEM=", 10) == 0)
			msg->subsystem = &key[10];
		else if (strncmp(key, "DRIVER=", 7) == 0)
			msg->driver = &key[7];
		else if (strncmp(key, "SEQNUM=", 7) == 0)
			msg->seqnum = strtoull(&key[7], NULL, 10);
		else if (strncmp(key, "DEVPATH_OLD=", 12) == 0)
			msg->devpath_old = &key[12];
		else if (strncmp(key, "PHYSDEVPATH=", 12) == 0)
			msg->physdevpath = &key[12];
		else if (strncmp(key, "PHYSDEVDRIVER=", 14) == 0)
			physdevdriver_key = key;
		else if (strncmp(key, "MAJOR=", 6) == 0)
			maj = strtoul(&key[6], NULL, 10);
		else if (strncmp(key, "MINOR=", 6) == 0)
			min = strtoul(&key[6], NULL, 10);
		else if (strncmp(key, "TIMEOUT=", 8) == 0)
			msg->timeout = strtoul(&key[8], NULL, 10);
	}

	msg->devt = (dev_t)makedev(maj, min);
	udev_event_putenv(msg, "UDEV_ENVENT=1");

	if (msg->driver == NULL && msg->physdevpath == NULL &&
	    physdevdriver_key != NULL) {
		/* for old kernels DRIVER is empty for a bus device, export 
		 * PHYSDEVDRIVER as driver
		 */
		udev_event_putenv(msg, &physdevdriver_key[7]);
		msg->driver = &physdevdriver_key[14];
	}

	if (msg->devpath == NULL || msg->action == NULL) {
		udev_log(UDEV_LOG_WARN, 
			 "EVENT: ignore message due to DEVPATH or ACTION missing");
		free(msg);
		return NULL;
	}
	return msg;
}

static udev_event_t *udev_event_get(void)
{
	udev_event_t *event;
	int bufpos;
	ssize_t size;
	static char buffer[UEVENT_BUFFER_SIZE + 512];
	char *pos;

	size = recv(udev_event_sock, buffer, sizeof(buffer), 0);
	if (size < 0) {
		if (errno != EINTR)
			udev_log(UDEV_LOG_ERR, 
				 "EVENT: rece(uevent) failure");
		return NULL;
	}

	if ((size_t) size > sizeof(buffer) - 1)
		size = sizeof(buffer) - 1;
	buffer[size] = '\0';

	bufpos = strlen(buffer) + 1;
	event = udev_event_parse(&buffer[bufpos], size - bufpos);
	if (event == NULL) {
		return NULL;
	}

	pos = strchr(buffer, '@');
	if (pos == NULL) {
		udev_log(UDEV_LOG_ERR,
			 "EVENT: ignore uevent due to '@' missing");
		free(event);
		return NULL;
	}

	pos[0] = '\0';

	if (event->action == NULL) {
		udev_log(UDEV_LOG_WARN, 
			 "EVENT: ignore message due to ACTION missing.");
		free(event);
		return NULL;
	}

	if (strcmp(event->action, buffer) != 0) {
		udev_log(UDEV_LOG_ERR,
			 "EVENT: ignore message due to ACTION mismatch.");
		free(event);
		return NULL;
	}
	return event;
}

static void udev_netlink_event(int fd, void *eloop_data, void *user_data)
{
	udev_event_t *event;

	event = udev_event_get();
	if (event) {
		udev_queue_insert(event);
	}
}

static int udev_event_addenv(udev_event_t *msg, const char *name,
			     const char *value,
			     const char *combined, int replace)
{
	char **ep;
	size_t size;
	const size_t namelen = strlen(name);
	const size_t vallen = value != NULL ? strlen (value) + 1 : 0;
	int rv = -1;
	
	/* we have to get the pointer now that we have the lock and not
	 * earlier since another thread might have created a new
	 * environment
	 */
	ep = msg->envp;
	
	size = 0;
	if (ep != NULL) {
		for (; *ep != NULL; ++ep) {
			if (!strncmp(*ep, name, namelen) && (*ep)[namelen] == '=')
				break;
			else
				++size;
		}
	}
	
	if (ep == NULL || *ep == NULL) {
		char **new_environ;
		
		/* we allocated this space; we can extend it */
		new_environ = (char **)realloc(msg->envp,
					       (size + 2) * sizeof (char *));
		if (new_environ == NULL)
			goto done;
		msg->envp = new_environ;
		
		/* if the whole entry is given add it */
		if (combined != NULL) {
			/* we must not add the string to the search tree since
			 * it belongs to the user
			 */
			new_environ[size] = combined ? strdup(combined) : NULL;
		} else {
			/* see whether the value is already known */
			new_environ[size] = (char *)malloc(namelen + 1 + vallen);
			if (new_environ[size] == NULL) {
				goto done;
			}
			
			memcpy(new_environ[size], name, namelen);
			new_environ[size][namelen] = '=';
			memcpy(&new_environ[size][namelen + 1], value, vallen);
		}
		
		new_environ[size + 1] = NULL;
	} else if (replace) {
		char *np;
		
		/* use the user string if given */
		if (combined != NULL) {
			np = strdup(combined);
		} else {
			np = malloc(namelen + 1 + vallen);
			if (np == NULL) {
				goto done;
			}
			memcpy(np, name, namelen);
			np[namelen] = '=';
			memcpy(&np[namelen + 1], value, vallen);
		}
		*ep = np;
	}
	rv = 0;
done:
	return rv;
}

int udev_event_putenv(udev_event_t *msg, const char *string)
{
	int result;
	char *name_end = strchr(string, '=');
	
	if (name_end != NULL) {
		char *name = strndup(string, name_end - string);
		result = udev_event_addenv(msg, name, NULL, string, 1);
		free(name);
		return result;
	}
	udev_event_unsetenv(msg, string);
	return 0;
}

int udev_event_clearenv(udev_event_t *msg)
{
	char **ep;

	if (msg->envp != NULL) {
		ep = msg->envp;
		if (ep != NULL) {
			for (; *ep != NULL; ++ep) {
				free(*ep);
			}
		}
		/* we allocated this environment so we can free it */
		free(msg->envp);
		/* clear the environment pointer removes the whole
		 * environment
		 */
		msg->envp = NULL;
	}
	return 0;
}

int udev_event_setenv(udev_event_t *msg, const char *name,
		      const char *value, int overwrite)
{
	return udev_event_addenv(msg, name, value, NULL, overwrite);
}

int udev_event_unsetenv(udev_event_t *msg, const char *name)
{
	size_t len;
	char **ep;
	
	if (name == NULL || *name == '\0' || strchr (name, '=') != NULL) {
		return -1;
	}
	
	len = strlen (name);
	ep = msg->envp;
	while (*ep != NULL) {
		if (!strncmp (*ep, name, len) && (*ep)[len] == '=') {
			/* remove found pointer by moving later ones back */
			char **dp = ep;
			do {
				dp[0] = dp[1];
			} while (*dp++);
			/* continue the loop in case NAME appears again */
		} else {
			++ep;
		}
	}
	return 0;
}

char *udev_event_getenv(udev_event_t *msg, const char *var)
{
	int len;
	char **ep;
	
	if (!(ep = msg->envp))
		return NULL;
	len = strlen(var);
	while (*ep) {
		if (memcmp(var, *ep, len) == 0 && (*ep)[len] == '=') {
			return *ep + len + 1;
		}
		ep++;
	}
	return NULL;
}

void udev_append_result(udev_device_t *dev, const char *result)
{
	if (dev) {
		dev->program_result = strredup(dev->program_result, result);
	}
}

#ifdef WIN32
/* emulate udev functions */
static int udev_netlink_init(void)
{
	struct sockaddr_in saddr;
	const int buffsize = 16 * 1024 * 1024;

	udev_event_sock = socket(AF_INET, SOCK_DGRAM, 0);
	if (udev_event_sock < 0) {
		return -1;
	}

	memset(&saddr, 0, sizeof(saddr));
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(UDEV_PORT);
	saddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	/* set receive buffersize */
	setsockopt(udev_event_sock, SOL_SOCKET, SO_RCVBUFFORCE,
		   (const char *)&buffsize, sizeof(buffsize));

	if (bind(udev_event_sock, (struct sockaddr *) &saddr, sizeof(saddr)) < 0) {
		closesocket(udev_event_sock);
		udev_event_sock = -1;
		return -1;
	}

	eloop_register_read_sock(NULL, udev_event_sock, 
				 udev_netlink_event, NULL, NULL);
	return 0;
}
#else
static int udev_netlink_init(void)
{
	struct sockaddr_nl snl;
	const int buffsize = 16 * 1024 * 1024;
	int ret;

	memset(&snl, 0x00, sizeof(struct sockaddr_nl));
	snl.nl_family = AF_NETLINK;
	snl.nl_pid = getpid();
	snl.nl_groups = 1;

	udev_event_sock = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_KOBJECT_UEVENT);
	if (udev_event_sock == -1) {
		udev_log(UDEV_LOG_ERR,
			 "EVENT: socket error - %s", strerror(errno));
		return -1;
	}

	/* set receive buffersize */
	setsockopt(udev_event_sock, SOL_SOCKET, SO_RCVBUFFORCE,
		   (const char *)&buffsize, sizeof(buffsize));
	ret = bind(udev_event_sock, (struct sockaddr *) &snl, 
		   sizeof(struct sockaddr_nl));
	if (ret < 0) {
		udev_log(UDEV_LOG_ERR,
			 "EVENT: bind error - %s", strerror(errno));
		close(udev_event_sock);
		udev_event_sock = -1;
		return -1;
	}
	eloop_register_read_sock(NULL, udev_event_sock, 
				 udev_netlink_event, NULL, NULL);
	return 0;
}
#endif

int udev_event_start(void)
{
	int ret;

	ret = udev_netlink_init();
	if (ret < 0)
		return ret;
	return ret;
}

void udev_event_stop(void)
{
	if (udev_event_sock >= 0)
		closesocket(udev_event_sock);
	udev_event_sock = -1;
}
