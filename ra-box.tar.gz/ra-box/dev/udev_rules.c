#include "udev_priv.h"

/* extract possible {attr} and move str behind it */
static char *get_format_attribute(char **str)
{
	char *pos;
	char *attr = NULL;

	if (*str[0] == '{') {
		pos = strchr(*str, '}');
		if (pos == NULL) {
			udev_log(UDEV_LOG_ERR,
				 "RULE: missing closing brace for format");
			return NULL;
		}
		pos[0] = '\0';
		attr = *str+1;
		*str = pos+1;
		udev_log(UDEV_LOG_DEBUG,
			 "RULE: attribute='%s', str='%s'", attr, *str);
	}
	return attr;
}

/* extract possible format length and move str behind it*/
static int get_format_len(char **str)
{
	int num;
	char *tail;

	if (isdigit(*str[0])) {
		num = (int) strtoul(*str, &tail, 10);
		if (num > 0) {
			*str = tail;
			udev_log(UDEV_LOG_DEBUG,
				 "RULE: format length=%i", num);
			return num;
		} else {
			udev_log(UDEV_LOG_ERR,
				 "RULE: format parsing error '%s'", *str);
		}
	}
	return -1;
}

static int get_key(char **line, char **key, char **value)
{
	char *linepos;
	char *temp;

	linepos = *line;
	if (linepos == NULL)
		return -1;

	/* skip whitespace */
	while (isspace(linepos[0]))
		linepos++;

	/* get the key */
	temp = strchr(linepos, '=');
	if (temp == NULL || temp == linepos)
		return -1;
	temp[0] = '\0';
	*key = linepos;
	linepos = &temp[1];

	/* get a quoted value */
	if (linepos[0] == '"' || linepos[0] == '\'') {
		temp = strchr(&linepos[1], linepos[0]);
		if (temp != NULL) {
			temp[0] = '\0';
			*value = &linepos[1];
			goto out;
		}
	}

	/* get the value*/
	temp = strchr(linepos, '\n');
	if (temp != NULL)
		temp[0] = '\0';
	*value = linepos;
out:
	return 0;
}

static int import_keys_into_env(udev_event_t *msg, udev_device_t *udev,
				const char *buf, size_t bufsize)
{
	char line[LINE_SIZE];
	const char *bufline;
	char *linepos;
	char *variable;
	char *value;
	size_t cur;
	size_t count;
	int lineno;

	/* loop through the whole buffer */
	lineno = 0;
	cur = 0;
	while (cur < bufsize) {
		count = buf_get_line(buf, bufsize, cur);
		bufline = &buf[cur];
		cur += count+1;
		lineno++;

		/* eat the whitespace */
		while ((count > 0) && isspace(bufline[0])) {
			bufline++;
			count--;
		}
		if (count == 0)
			continue;

		/* see if this is a comment */
		if (bufline[0] == COMMENT_CHARACTER)
			continue;

		if (count >= sizeof(line)) {
			udev_log(UDEV_LOG_ERR,
				 "RULE: line too long, line %d", lineno);
			continue;
		}

		memcpy(line, bufline, count);
		line[count] = '\0';

		linepos = line;
		if (get_key(&linepos, &variable, &value) == 0) {
			udev_log(UDEV_LOG_DEBUG,
				 "RULE: import '%s=%s'", variable, value);

			/* handle device, renamed by external tool, returning new path */
			if (strcmp(variable, "DEVPATH") == 0) {
				udev_log(UDEV_LOG_INFO,
					 "RULE: updating devpath from '%s' to '%s'",
					 udev->dev->devpath, value);
				sysfs_device_set_values(udev->dev, value, NULL, NULL);
			} else {
				udev_name_list_key_add(&udev->env_list, variable, value);
			}
			udev_event_setenv(msg, variable, value, 1);
		}
	}

	return 0;
}

static int import_file_into_env(udev_event_t *msg, udev_device_t *udev,
				const char *filename)
{
	char *buf;
	size_t bufsize;

	if (file_map(filename, &buf, &bufsize) != 0) {
		udev_log(UDEV_LOG_ERR,
			 "RULE: can't open import file, file=%s, err=%s",
			 filename, strerror(errno));
		return -1;
	}
	import_keys_into_env(msg, udev, buf, bufsize);
	file_unmap(buf, bufsize);
	return 0;
}

static int import_parent_into_env(udev_event_t *msg, udev_device_t *udev,
				  const char *filter)
{
	sysfs_device_t *dev_parent;
	int rc = -1;

	dev_parent = sysfs_device_get_parent(udev->dev);
	if (dev_parent != NULL) {
		udev_device_t *udev_parent;

		udev_parent = udev_device_new();
		if (udev_parent == NULL)
			return -1;
		udev_device_free(udev_parent);
	}

	return rc;
}

/* handle "[$SUBSYSTEM/$KERNEL]<attribute>" lookup */
static int attr_get_by_subsys_id(const char *attrstr, char *devpath,
				 size_t len, char **attr)
{
	char subsys[NAME_SIZE];
	char *attrib;
	char *id;
	int found = 0;

	if (attrstr[0] != '[')
		goto out;

	strlcpy(subsys, &attrstr[1], sizeof(subsys));

	attrib = strchr(subsys, ']');
	if (attrib == NULL)
		goto out;
	attrib[0] = '\0';
	attrib = &attrib[1];

	id = strchr(subsys, '/');
	if (id == NULL)
		goto out;
	id[0] = '\0';
	id = &id[1];

	if (sysfs_lookup_devpath_by_subsys_id(devpath, len, subsys, id)) {
		if (attr != NULL) {
			if (attrib[0] != '\0')
				*attr = attrib;
			else
				*attr = NULL;
		}
		found = 1;
	}
out:
	return found;
}

static int attr_subst_subdir(char *attr, size_t len)
{
	char *pos;
	int found = 0;

	pos = strstr(attr, "/*/");
	if (pos != NULL) {
		char str[PATH_SIZE];
		DIR *dir;

		pos[1] = '\0';
		strlcpy(str, &pos[2], sizeof(str));
		dir = opendir(attr);
		if (dir != NULL) {
			struct _dirent *dent;

			for (dent = readdir(dir); dent != NULL;
			     dent = readdir(dir)) {
				struct stat stats;

				if (dent->d_name[0] == '.')
					continue;
				strlcat(attr, dent->d_name, len);
				strlcat(attr, str, len);
				if (stat(attr, &stats) == 0) {
					found = 1;
					break;
				}
				pos[1] = '\0';
			}
			closedir(dir);
		}
		if (!found)
			strlcat(attr, str, len);
	}
	return found;
}

void udev_rules_apply_format(udev_event_t *msg, udev_device_t *udev,
			     char *string, size_t maxsize)
{
	char temp[PATH_SIZE];
	char temp2[PATH_SIZE];
	char *head, *tail, *pos, *cpos, *attr, *rest;
	int len;
	int i;
	int count;
	enum subst_type {
		SUBST_UNKNOWN,
		SUBST_DEVPATH,
		SUBST_KERNEL,
		SUBST_KERNEL_NUMBER,
		SUBST_ID,
		SUBST_DRIVER,
		SUBST_MAJOR,
		SUBST_MINOR,
		SUBST_RESULT,
		SUBST_ATTR,
		SUBST_TEMP_NODE,
		SUBST_NAME,
		SUBST_LINKS,
		SUBST_ROOT,
		SUBST_SYS,
		SUBST_ENV,
	};
	static const struct subst_map {
		const char *name;
		const char fmt;
		enum subst_type type;
	} map[] = {
		{ "devpath",	'p',	SUBST_DEVPATH },
		{ "number",	'n',	SUBST_KERNEL_NUMBER },
		{ "kernel",	'k',	SUBST_KERNEL },
		{ "id",		'b',	SUBST_ID },
		{ "driver",	'd',	SUBST_DRIVER },
		{ "major",	'M',	SUBST_MAJOR },
		{ "minor",	'm',	SUBST_MINOR },
		{ "result",	'c',	SUBST_RESULT },
		{ "attr",	's',	SUBST_ATTR },
		{ "sysfs",	's',	SUBST_ATTR },
		{ "tempnode",	'N',	SUBST_TEMP_NODE },
		{ "name",	'D',	SUBST_NAME },
		{ "links",	'L',	SUBST_LINKS },
		{ "root",	'r',	SUBST_ROOT },
		{ "sys",	'S',	SUBST_SYS },
		{ "env",	'E',	SUBST_ENV },
		{ NULL, '\0', 0 }
	};
	enum subst_type type;
	const struct subst_map *subst;

	head = string;
	while (1) {
		len = -1;
		while (head[0] != '\0') {
			if (head[0] == '$') {
				/* substitute named variable */
				if (head[1] == '\0')
					break;
				if (head[1] == '$') {
					strlcpy(temp, head+2, sizeof(temp));
					strlcpy(head+1, temp, maxsize);
					head++;
					continue;
				}
				head[0] = '\0';
				for (subst = map; subst->name; subst++) {
					if (strncasecmp(&head[1], subst->name, strlen(subst->name)) == 0) {
						type = subst->type;
						tail = head + strlen(subst->name)+1;
						udev_log(UDEV_LOG_DEBUG, "RULE: will substitute format name '%s'", subst->name);
						goto found;
					}
				}
				head[0] = '$';
				udev_log(UDEV_LOG_ERR, "RULE: unknown format variable '%s'", head);
			} else if (head[0] == '%') {
				/* substitute format char */
				if (head[1] == '\0')
					break;
				if (head[1] == '%') {
					strlcpy(temp, head+2, sizeof(temp));
					strlcpy(head+1, temp, maxsize);
					head++;
					continue;
				}
				head[0] = '\0';
				tail = head+1;
				len = get_format_len(&tail);
				for (subst = map; subst->name; subst++) {
					if (tail[0] == subst->fmt) {
						type = subst->type;
						tail++;
						udev_log(UDEV_LOG_DEBUG, "RULE: will substitute format char '%c'", subst->fmt);
						goto found;
					}
				}
				head[0] = '%';
				udev_log(UDEV_LOG_ERR, "RULE: unknown format char '%c'", tail[0]);
			}
			head++;
		}
		break;
found:
		attr = get_format_attribute(&tail);
		strlcpy(temp, tail, sizeof(temp));
		udev_log(UDEV_LOG_DEBUG, "RULE: format=%i, string='%s', tail='%s'", type ,string, tail);

		switch (type) {
		case SUBST_DEVPATH:
			strlcat(string, udev->dev->devpath, maxsize);
			udev_log(UDEV_LOG_DEBUG, "RULE: substitute devpath '%s'", udev->dev->devpath);
			break;
		case SUBST_KERNEL:
			strlcat(string, udev->dev->kernel, maxsize);
			udev_log(UDEV_LOG_DEBUG, "RULE: substitute kernel name '%s'", udev->dev->kernel);
			break;
		case SUBST_KERNEL_NUMBER:
			strlcat(string, udev->dev->kernel_number, maxsize);
			udev_log(UDEV_LOG_DEBUG, "RULE: substitute kernel number '%s'", udev->dev->kernel_number);
			break;
		case SUBST_ID:
			if (udev->dev_parent != NULL) {
				strlcat(string, udev->dev_parent->kernel, maxsize);
				udev_log(UDEV_LOG_DEBUG, "RULE: substitute id '%s'", udev->dev_parent->kernel);
			}
			break;
		case SUBST_DRIVER:
			if (udev->dev_parent != NULL) {
				strlcat(string, udev->dev_parent->driver, maxsize);
				udev_log(UDEV_LOG_DEBUG, "RULE: substitute driver '%s'", udev->dev_parent->driver);
			}
			break;
		case SUBST_MAJOR:
			sprintf(temp2, "%d", major(udev->devt));
			strlcat(string, temp2, maxsize);
			udev_log(UDEV_LOG_DEBUG, "RULE: substitute major number '%s'", temp2);
			break;
		case SUBST_MINOR:
			sprintf(temp2, "%d", minor(udev->devt));
			strlcat(string, temp2, maxsize);
			udev_log(UDEV_LOG_DEBUG, "RULE: substitute minor number '%s'", temp2);
			break;
		case SUBST_RESULT:
			if (!udev->program_result ||
			    udev->program_result[0] == '\0')
				break;
			/* get part part of the result string */
			i = 0;
			if (attr != NULL)
				i = strtoul(attr, &rest, 10);
			if (i > 0) {
				udev_log(UDEV_LOG_DEBUG,
					 "RULE: request part #%d of result string", i);
				cpos = udev->program_result;
				while (--i) {
					while (cpos[0] != '\0' && !isspace(cpos[0]))
						cpos++;
					while (isspace(cpos[0]))
						cpos++;
				}
				if (i > 0) {
					udev_log(UDEV_LOG_ERR, "RULE: requested part of result string not found");
					break;
				}
				strlcpy(temp2, cpos, sizeof(temp2));
				/* %{2+}c copies the whole string from the second part on */
				if (rest[0] != '+') {
					cpos = strchr(temp2, ' ');
					if (cpos)
						cpos[0] = '\0';
				}
				strlcat(string, temp2, maxsize);
				udev_log(UDEV_LOG_DEBUG, "RULE: substitute part of result string '%s'", temp2);
			} else {
				strlcat(string, udev->program_result, maxsize);
				udev_log(UDEV_LOG_DEBUG, "RULE: substitute result string '%s'", udev->program_result);
			}
			break;
		case SUBST_ATTR:
			if (attr == NULL)
				udev_log(UDEV_LOG_ERR, "RULE: missing file parameter for attr");
			else {
				char devpath[PATH_SIZE];
				char *attrib;
				const char *value = NULL;
				size_t size;

				if (attr_get_by_subsys_id(attr, devpath, sizeof(devpath), &attrib)) {
					if (attrib != NULL)
						value = sysfs_attr_get_value(devpath, attrib);
					else
						break;
				}

				/* try the current device, other matches may have selected */
				if (value == NULL && udev->dev_parent != NULL && udev->dev_parent != udev->dev)
					value = sysfs_attr_get_value(udev->dev_parent->devpath, attr);

				/* look at all devices along the chain of parents */
				if (value == NULL) {
					sysfs_device_t *dev_parent = udev->dev;

					do {
						udev_log(UDEV_LOG_DEBUG, "RULE: looking at '%s'", dev_parent->devpath);
						value = sysfs_attr_get_value(dev_parent->devpath, attr);
						if (value != NULL) {
							strlcpy(temp2, value, sizeof(temp2));
							break;
						}
						dev_parent = sysfs_device_get_parent(dev_parent);
					} while (dev_parent != NULL);
				}

				if (value == NULL)
					break;

				/* strip trailing whitespace, and replace unwanted characters */
				size = strlcpy(temp2, value, sizeof(temp2));
				if (size >= sizeof(temp2))
					size = sizeof(temp2)-1;
				while (size > 0 && isspace(temp2[size-1]))
					temp2[--size] = '\0';
				count = replace_chars(temp2, ALLOWED_CHARS_INPUT);
				if (count > 0) {
					udev_log(UDEV_LOG_DEBUG,
						 "RULE: character(s) replaced, count=%i" , count);
				}
				strlcat(string, temp2, maxsize);
				udev_log(UDEV_LOG_DEBUG, "RULE: substitute sysfs value '%s'", temp2);
			}
			break;
		case SUBST_TEMP_NODE:
			if (udev->tmp_node[0] == '\0' && major(udev->devt) > 0) {
				udev_log(UDEV_LOG_DEBUG, "RULE: create temp dev for callout");
				snprintf(udev->tmp_node, sizeof(udev->tmp_node), "%s/.tmp-%u-%u",
					 _PATH_DEV, major(udev->devt), minor(udev->devt));
				udev->tmp_node[sizeof(udev->tmp_node)-1] = '\0';
				udev_node_mknod(udev, udev->tmp_node, udev->devt, 0600, 0, 0);
			}
			strlcat(string, udev->tmp_node, maxsize);
			udev_log(UDEV_LOG_DEBUG, "RULE: substitute temporary device node name '%s'", udev->tmp_node);
			break;
		case SUBST_NAME:
			if (udev->name[0] == '\0') {
				strlcat(string, udev->dev->kernel, maxsize);
				udev_log(UDEV_LOG_DEBUG, "RULE: substitute udev->kernel '%s'", udev->name);
			} else {
				strlcat(string, udev->name, maxsize);
				udev_log(UDEV_LOG_DEBUG, "RULE: substitute udev->name '%s'", udev->name);
			}
			break;
		case SUBST_LINKS:
			if (!list_empty(&udev->symlink_list)) {
				udev_name_t *name_loop;
				char symlinks[PATH_SIZE] = "";

				for_each_name(name_loop, udev->symlink_list) {
					strlcat(symlinks, name_loop->name, sizeof(symlinks));
					strlcat(symlinks, " ", sizeof(symlinks));
				}
				remove_trailing_chars(symlinks, ' ');
				strlcat(string, symlinks, maxsize);
			}
			break;
		case SUBST_ROOT:
			strlcat(string, _PATH_DEV, maxsize);
			udev_log(UDEV_LOG_DEBUG, "RULE: substitute _PATH_DEV '%s'", _PATH_DEV);
			break;
		case SUBST_SYS:
			strlcat(string, _PATH_SYS, maxsize);
			udev_log(UDEV_LOG_DEBUG, "RULE: substitute _PATH_SYS '%s'", _PATH_SYS);
			break;
		case SUBST_ENV:
			if (attr == NULL) {
				udev_log(UDEV_LOG_DEBUG, "RULE: missing attribute");
				break;
			}
			pos = udev_event_getenv(msg, attr);
			if (pos == NULL) {
				udev_log(UDEV_LOG_DEBUG, "RULE: env '%s' not available", attr);
				break;
			}
			udev_log(UDEV_LOG_DEBUG, "RULE: substitute env '%s=%s'", attr, pos);
			strlcat(string, pos, maxsize);
			break;
		default:
			udev_log(UDEV_LOG_ERR, "RULE: unknown substitution type=%i", type);
			break;
		}
		/* possibly truncate to format-char specified length */
		if (len >= 0 && len < (int)strlen(head)) {
			head[len] = '\0';
			udev_log(UDEV_LOG_DEBUG, "RULE: truncate to %i chars, subtitution string becomes '%s'", len, head);
		}
		strlcat(string, temp, maxsize);
	}
}

static char *key_val(udev_rule_t *rule, struct key *key)
{
	return rule->buf + key->val_off;
}

static char *key_pair_name(udev_rule_t *rule, struct key_pair *pair)
{
	return rule->buf + pair->key_name_off;
}

static int udev_key_match(const char *key_name, udev_rule_t *rule,
			  struct key *key, const char *val)
{
	char value[PATH_SIZE];
	char *key_value;
	char *pos;
	int match = 0;

	if (key->operation != KEY_OP_MATCH &&
	    key->operation != KEY_OP_NOMATCH)
		return 0;

	/* look for a matching string, parts are separated by '|' */
	strlcpy(value, rule->buf + key->val_off, sizeof(value));
	key_value = value;
	udev_log(UDEV_LOG_DEBUG, "RULE: key %s value='%s'", key_name, key_value);
	while (key_value) {
		pos = strchr(key_value, '|');
		if (pos) {
			pos[0] = '\0';
			pos++;
		}

		udev_log(UDEV_LOG_DEBUG, "RULE: match %s '%s' <-> '%s'", key_name, key_value, val);
		match = (fnmatch(key_value, val, 0) == 0);
		if (match)
			break;

		key_value = pos;
	}

	if (match && (key->operation == KEY_OP_MATCH)) {
		udev_log(UDEV_LOG_DEBUG, "RULE: %s is true (matching value)", key_name);
		return 0;
	}
	if (!match && (key->operation == KEY_OP_NOMATCH)) {
		udev_log(UDEV_LOG_DEBUG, "RULE: %s is true (non-matching value)", key_name);
		return 0;
	}
	return -1;
}

/* match a single rule against a given device and possibly its parent devices */
static int udev_rule_match(udev_event_t *msg, udev_device_t *udev, udev_rule_t *rule)
{
	int i;

	if (udev_key_match("ACTION", rule, &rule->action, udev->action))
		goto nomatch;

	if (udev_key_match("KERNEL", rule, &rule->kernel, udev->dev->kernel))
		goto nomatch;

	if (udev_key_match("SUBSYSTEM", rule, &rule->subsystem, udev->dev->subsystem))
		goto nomatch;

	if (udev_key_match("DEVPATH", rule, &rule->devpath, udev->dev->devpath))
		goto nomatch;

	if (udev_key_match("DRIVER", rule, &rule->driver, udev->dev->driver))
		goto nomatch;

	/* match NAME against a value assigned by an earlier rule */
	if (udev_key_match("NAME", rule, &rule->name, udev->name))
		goto nomatch;

	/* match against current list of symlinks */
	if (rule->symlink_match.operation == KEY_OP_MATCH ||
	    rule->symlink_match.operation == KEY_OP_NOMATCH) {
		udev_name_t *name_loop;
		int match = 0;

		for_each_name(name_loop, udev->symlink_list) {
			if (udev_key_match("SYMLINK", rule, &rule->symlink_match, name_loop->name) == 0) {
				match = 1;
				break;
			}
		}
		if (!match)
			goto nomatch;
	}

	for (i = 0; i < rule->env.count; i++) {
		struct key_pair *pair = &rule->env.keys[i];

		/* we only check for matches, assignments will be handled later */
		if (pair->key.operation == KEY_OP_MATCH ||
		    pair->key.operation == KEY_OP_NOMATCH) {
			const char *key_name = key_pair_name(rule, pair);
			const char *value = udev_event_getenv(msg, key_name);

			if (!value) {
				udev_log(UDEV_LOG_DEBUG, "RULE: ENV{'%s'} is not set, treat as empty", key_name);
				value = "";
			}
			if (udev_key_match("ENV", rule, &pair->key, value))
				goto nomatch;
		}
	}

	/* check for matching sysfs attribute pairs */
	for (i = 0; i < rule->attr.count; i++) {
		struct key_pair *pair = &rule->attr.keys[i];

		if (pair->key.operation == KEY_OP_MATCH ||
		    pair->key.operation == KEY_OP_NOMATCH) {
			const char *key_name = key_pair_name(rule, pair);
			const char *key_value = key_val(rule, &pair->key);
			char devpath[PATH_SIZE];
			char *attrib;
			const char *value = NULL;
			char val[VALUE_SIZE];
			size_t len;

			if (attr_get_by_subsys_id(key_name, devpath, sizeof(devpath), &attrib)) {
				if (attrib != NULL)
					value = sysfs_attr_get_value(devpath, attrib);
				else
					goto nomatch;
			}
			if (value == NULL)
				value = sysfs_attr_get_value(udev->dev->devpath, key_name);
			if (value == NULL)
				goto nomatch;
			strlcpy(val, value, sizeof(val));

			/* strip trailing whitespace of value, if not asked to match for it */
			len = strlen(key_value);
			if (len > 0 && !isspace(key_value[len-1])) {
				len = strlen(val);
				while (len > 0 && isspace(val[len-1]))
					val[--len] = '\0';
				udev_log(UDEV_LOG_DEBUG, "RULE: removed %zi trailing whitespace chars from '%s'", strlen(val)-len, val);
			}

			if (udev_key_match("ATTR", rule, &pair->key, val))
				goto nomatch;
		}
	}

	/* walk up the chain of parent devices and find a match */
	udev->dev_parent = udev->dev;
	while (1) {
		/* check for matching kernel device name */
		if (udev_key_match("KERNELS", rule, &rule->kernels, udev->dev_parent->kernel))
			goto try_parent;

		/* check for matching subsystem value */
		if (udev_key_match("SUBSYSTEMS", rule, &rule->subsystems, udev->dev_parent->subsystem))
			goto try_parent;

		/* check for matching driver */
		if (udev_key_match("DRIVERS", rule, &rule->drivers, udev->dev_parent->driver))
			goto try_parent;

		/* check for matching sysfs attribute pairs */
		for (i = 0; i < rule->attrs.count; i++) {
			struct key_pair *pair = &rule->attrs.keys[i];

			if (pair->key.operation == KEY_OP_MATCH ||
			    pair->key.operation == KEY_OP_NOMATCH) {
				const char *key_name = key_pair_name(rule, pair);
				const char *key_value = key_val(rule, &pair->key);
				const char *value;
				char val[VALUE_SIZE];
				size_t len;

				value = sysfs_attr_get_value(udev->dev_parent->devpath, key_name);
				if (value == NULL)
					value = sysfs_attr_get_value(udev->dev->devpath, key_name);
				if (value == NULL)
					goto try_parent;
				strlcpy(val, value, sizeof(val));

				/* strip trailing whitespace of value, if not asked to match for it */
				len = strlen(key_value);
				if (len > 0 && !isspace(key_value[len-1])) {
					len = strlen(val);
					while (len > 0 && isspace(val[len-1]))
						val[--len] = '\0';
					udev_log(UDEV_LOG_DEBUG, "RULE: removed %zi trailing whitespace chars from '%s'", strlen(val)-len, val);
				}

				if (udev_key_match("ATTRS", rule, &pair->key, val))
					goto try_parent;
			}
		}

		/* found matching device  */
		break;
try_parent:
		/* move to parent device */
		udev_log(UDEV_LOG_DEBUG, "RULE: try parent sysfs device");
		udev->dev_parent = sysfs_device_get_parent(udev->dev_parent);
		if (udev->dev_parent == NULL)
			goto nomatch;
		udev_log(UDEV_LOG_DEBUG, "RULE: looking at dev_parent->devpath='%s'", udev->dev_parent->devpath);
		udev_log(UDEV_LOG_DEBUG, "RULE: looking at dev_parent->kernel='%s'", udev->dev_parent->kernel);
	}

	/* execute external program */
	if (rule->program.operation != KEY_OP_UNSET) {
		char program[PATH_SIZE];

		strlcpy(program, key_val(rule, &rule->program), sizeof(program));
		udev_rules_apply_format(msg, udev, program, sizeof(program));
		if (udev_prog_run(msg, udev, program, udev->dev->subsystem) != 0) {
			udev_log(UDEV_LOG_DEBUG, "RULE: PROGRAM returned failure");
			if (rule->program.operation != KEY_OP_NOMATCH)
				goto nomatch;
		} else {
			udev_log(UDEV_LOG_DEBUG,
				 "RULE: PROGRAM returned success, RESULT=%s",
				 udev->program_result);
			if (rule->program.operation == KEY_OP_NOMATCH)
				goto nomatch;
		}
		udev_log(UDEV_LOG_DEBUG, "RULE: PROGRAM key is true");
	}

	/* check for matching result of external program */
	if (udev_key_match("RESULT", rule, &rule->result, udev->program_result))
		goto nomatch;

	/* import variables returned from program or or file into environment */
	if (rule->import.operation != KEY_OP_UNSET) {
		char import[PATH_SIZE];
		int rc = -1;

		strlcpy(import, key_val(rule, &rule->import), sizeof(import));
		udev_rules_apply_format(msg, udev, import, sizeof(import));
		udev_log(UDEV_LOG_DEBUG, "RULE: check for IMPORT import='%s'", import);
		if (rule->import_type == IMPORT_FILE) {
			udev_log(UDEV_LOG_DEBUG, "RULE: import file import='%s'", import);
			rc = import_file_into_env(msg, udev, import);
		}
		if (rc != 0) {
			udev_log(UDEV_LOG_DEBUG, "RULE: IMPORT failed");
			if (rule->import.operation != KEY_OP_NOMATCH)
				goto nomatch;
		} else
			udev_log(UDEV_LOG_DEBUG, "RULE: IMPORT '%s' imported", key_val(rule, &rule->import));
		udev_log(UDEV_LOG_DEBUG, "RULE: IMPORT key is true");
	}

	/* rule matches, if we have ENV assignments export it */
	for (i = 0; i < rule->env.count; i++) {
		struct key_pair *pair = &rule->env.keys[i];

		if (pair->key.operation == KEY_OP_ASSIGN) {
			char temp_value[NAME_SIZE];
			const char *key_name = key_pair_name(rule, pair);
			const char *value = key_val(rule, &pair->key);

			/* make sure we don't write to the same string we possibly read from */
			strlcpy(temp_value, value, sizeof(temp_value));
			udev_rules_apply_format(msg, udev, temp_value, NAME_SIZE);

			if (temp_value[0] == '\0') {
				udev_name_list_key_remove(&udev->env_list, key_name);
				unsetenv(key_name);
				udev_log(UDEV_LOG_INFO, "RULE: unset ENV '%s'", key_name);
			} else {
				udev_name_t *entry;

				entry = udev_name_list_key_add(&udev->env_list, key_name, temp_value);
				if (entry == NULL)
					break;
				udev_event_putenv(msg, entry->name);
				udev_log(UDEV_LOG_INFO, "RULE: set ENV '%s'", entry->name);
			}
		}
	}

	/* if we have ATTR assignments, write value to sysfs file */
	for (i = 0; i < rule->attr.count; i++) {
		struct key_pair *pair = &rule->attr.keys[i];

		if (pair->key.operation == KEY_OP_ASSIGN) {
			const char *key_name = key_pair_name(rule, pair);
			char devpath[PATH_SIZE];
			char *attrib;
			char attr[PATH_SIZE] = "";
			char value[NAME_SIZE];
			FILE *f;

			if (attr_get_by_subsys_id(key_name, devpath, sizeof(devpath), &attrib)) {
				if (attrib != NULL) {
					strlcpy(attr, _PATH_SYS, sizeof(attr));
					strlcat(attr, devpath, sizeof(attr));
					strlcat(attr, "/", sizeof(attr));
					strlcat(attr, attrib, sizeof(attr));
				}
			}

			if (attr[0] == '\0') {
				strlcpy(attr, _PATH_SYS, sizeof(attr));
				strlcat(attr, udev->dev->devpath, sizeof(attr));
				strlcat(attr, "/", sizeof(attr));
				strlcat(attr, key_name, sizeof(attr));
			}

			attr_subst_subdir(attr, sizeof(attr));

			strlcpy(value, key_val(rule, &pair->key), sizeof(value));
			udev_rules_apply_format(msg, udev, value, sizeof(value));
			udev_log(UDEV_LOG_INFO, "RULE: writing '%s' to sysfs file '%s'", value, attr);
			f = fopen(attr, "w");
			if (f != NULL) {
				if (fprintf(f, "%s", value) <= 0)
					udev_log(UDEV_LOG_ERR, "RULE: error writing ATTR{%s}: %s", attr, strerror(errno));
				fclose(f);
			} else
				udev_log(UDEV_LOG_ERR, "RULE: error opening ATTR{%s} for writing: %s", attr, strerror(errno));
		}
	}
	return 0;

nomatch:
	return -1;
}

int udev_rules_get_name(udev_event_t *msg, udev_rules_t *rules, udev_device_t *udev)
{
	udev_rule_t *rule;
	int name_set = 0;

	/* look for a matching rule to apply */
	udev_rules_iter_init(rules);
	while (1) {
		rule = udev_rules_iter_next(rules);
		if (rule == NULL)
			break;

		if (name_set &&
		    (rule->name.operation == KEY_OP_ASSIGN ||
		     rule->name.operation == KEY_OP_ASSIGN_FINAL /*||
		     rule->name.operation == KEY_OP_ADD*/)) {
			udev_log(UDEV_LOG_DEBUG, "RULE: node name already set, rule ignored");
			continue;
		}

		if (udev_rule_match(msg, udev, rule) == 0) {
			/* apply options */
			if (rule->ignore_device) {
				udev_log(UDEV_LOG_INFO,
					 "RULE: applied rule ignored, dev=%s",
					 udev->dev->kernel);
				udev->ignore_device = 1;
				return 0;
			}
			if (rule->ignore_remove) {
				udev->ignore_remove = 1;
				udev_log(UDEV_LOG_DEBUG, "RULE: remove event should be ignored");
			}
			if (rule->link_priority != 0) {
				udev->link_priority = rule->link_priority;
				udev_log(UDEV_LOG_INFO, "RULE: link_priority=%i", udev->link_priority);
			}
			if (rule->event_timeout >= 0) {
				udev->event_timeout = rule->event_timeout;
				udev_log(UDEV_LOG_INFO, "RULE: event_timeout=%i", udev->event_timeout);
			}
			/* apply all_partitions option only at a main block device */
			if (rule->partitions &&
			    strcmp(udev->dev->subsystem, "block") == 0 && udev->dev->kernel_number[0] == '\0') {
				udev->partitions = rule->partitions;
				udev_log(UDEV_LOG_DEBUG, "RULE: creation of partition nodes requested");
			}

			/* apply permissions */
			if (!udev->mode_final && rule->mode.operation != KEY_OP_UNSET) {
				if (rule->mode.operation == KEY_OP_ASSIGN_FINAL)
					udev->mode_final = 1;
				udev->mode = strtol(key_val(rule, &rule->mode), NULL, 8);
				udev_log(UDEV_LOG_DEBUG, "RULE: applied mode=%#o to '%s'", udev->mode, udev->dev->kernel);
			}
			if (!udev->owner_final && rule->owner.operation != KEY_OP_UNSET) {
				if (rule->owner.operation == KEY_OP_ASSIGN_FINAL)
					udev->owner_final = 1;
				strlcpy(udev->owner, key_val(rule, &rule->owner), sizeof(udev->owner));
				udev_rules_apply_format(msg, udev, udev->owner, sizeof(udev->owner));
				udev_log(UDEV_LOG_DEBUG, "RULE: applied owner='%s' to '%s'", udev->owner, udev->dev->kernel);
			}
			if (!udev->group_final && rule->group.operation != KEY_OP_UNSET) {
				if (rule->group.operation == KEY_OP_ASSIGN_FINAL)
					udev->group_final = 1;
				strlcpy(udev->group, key_val(rule, &rule->group), sizeof(udev->group));
				udev_rules_apply_format(msg, udev, udev->group, sizeof(udev->group));
				udev_log(UDEV_LOG_DEBUG, "RULE: applied group='%s' to '%s'", udev->group, udev->dev->kernel);
			}

			/* collect symlinks */
			if (!udev->symlink_final &&
			    (rule->symlink.operation == KEY_OP_ASSIGN ||
			     rule->symlink.operation == KEY_OP_ASSIGN_FINAL ||
			     rule->symlink.operation == KEY_OP_ADD)) {
				char temp[PATH_SIZE];
				char *pos, *next;
				int count;

				if (rule->symlink.operation == KEY_OP_ASSIGN_FINAL)
					udev->symlink_final = 1;
				if (rule->symlink.operation == KEY_OP_ASSIGN ||
				    rule->symlink.operation == KEY_OP_ASSIGN_FINAL) {
					udev_log(UDEV_LOG_INFO, "RULE: reset symlink list");
					udev_name_list_cleanup(&udev->symlink_list);
				}
				/* allow  multiple symlinks separated by spaces */
				strlcpy(temp, key_val(rule, &rule->symlink), sizeof(temp));
				udev_rules_apply_format(msg, udev, temp, sizeof(temp));
				if (rule->string_escape == ESCAPE_UNSET ||
				    rule->string_escape == ESCAPE_REPLACE) {
					count = replace_chars(temp, ALLOWED_CHARS_FILE " ");
					if (count > 0) {
						udev_log(UDEV_LOG_DEBUG,
							 "RULE: character replaced, count=%i", count);
					}
				}
				pos = temp;
				while (isspace(pos[0]))
					pos++;
				next = strchr(pos, ' ');
				while (next) {
					next[0] = '\0';
					udev_log(UDEV_LOG_INFO, "RULE: add symlink, link=%s", pos);
					udev_name_list_add(&udev->symlink_list, pos, 0);
					while (isspace(next[1]))
						next++;
					pos = &next[1];
					next = strchr(pos, ' ');
				}
				if (pos[0] != '\0') {
					udev_log(UDEV_LOG_INFO, "RULE: add symlink, link=%s", pos);
					udev_name_list_add(&udev->symlink_list, pos, 0);
				}
			}

			/* set name, later rules with name set will be ignored */
			if (rule->name.operation == KEY_OP_ASSIGN ||
			    rule->name.operation == KEY_OP_ASSIGN_FINAL ||
			    rule->name.operation == KEY_OP_ADD) {
				int count;

				name_set = 1;
				strlcpy(udev->name, key_val(rule, &rule->name), sizeof(udev->name));
				udev_rules_apply_format(msg, udev, udev->name, sizeof(udev->name));
				if (rule->string_escape == ESCAPE_UNSET ||
				    rule->string_escape == ESCAPE_REPLACE) {
					count = replace_chars(udev->name, ALLOWED_CHARS_FILE);
					if (count > 0) {
						udev_log(UDEV_LOG_DEBUG,
							 "RULE: character(s) replaced, count=%i", count);
					}
				}

				if (strcmp(udev->dev->subsystem, "net") != 0)
					udev_log(UDEV_LOG_DEBUG, "RULE: name, '%s' is going to have owner='%s', group='%s', mode=%#o partitions=%i",
					    udev->name, udev->owner, udev->group, udev->mode, udev->partitions);
			}
			if (rule->last_rule) {
				udev_log(UDEV_LOG_DEBUG, "RULE: last rule to be applied");
				break;
			}
		}
	}

	if (!name_set) {
		udev_log(UDEV_LOG_DEBUG,
			 "RULE: no node name, use kernel name instead, name=%s",
			 udev->dev->kernel);
		strlcpy(udev->name, udev->dev->kernel, sizeof(udev->name));
	}

	if (udev->tmp_node[0] != '\0') {
		udev_log(UDEV_LOG_DEBUG, "RULE: removing temporary device node");
		udev_unlink_secure(udev->tmp_node);
		udev->tmp_node[0] = '\0';
	}

	return 0;
}

int udev_rules_get_run(udev_event_t *msg, udev_rules_t *rules, udev_device_t *udev)
{
	udev_rule_t *rule;

	/* look for a matching rule to apply */
	udev_rules_iter_init(rules);
	while (1) {
		rule = udev_rules_iter_next(rules);
		if (rule == NULL)
			break;

		if (rule->name.operation == KEY_OP_ASSIGN ||
		    rule->name.operation == KEY_OP_ASSIGN_FINAL ||
		    rule->name.operation == KEY_OP_ADD ||
		    rule->symlink.operation == KEY_OP_ASSIGN ||
		    rule->symlink.operation == KEY_OP_ASSIGN_FINAL ||
		    rule->symlink.operation == KEY_OP_ADD ||
		    rule->mode.operation != KEY_OP_UNSET ||
		    rule->owner.operation != KEY_OP_UNSET || 
		    rule->group.operation != KEY_OP_UNSET) {
#if 0
			udev_log(UDEV_LOG_DEBUG,
				 "RULE: skip rule that names a device");
#endif
			continue;
		}

		if (udev_rule_match(msg, udev, rule) == 0) {
			if (rule->ignore_device) {
				udev_log(UDEV_LOG_INFO,
					 "RULE: applied rule ignored, dev=%s",
					 udev->dev->kernel);
				udev->ignore_device = 1;
				return 0;
			}
			if (rule->ignore_remove) {
				udev->ignore_remove = 1;
				udev_log(UDEV_LOG_DEBUG,
					 "RULE: remove event should be ignored");
			}
			if (rule->last_rule) {
				break;
			}
		}
	}
	return 0;
}
