#include "udev_priv.h"

udev_rules_t udev_rules;

void __exit udev_rule_exit(void)
{
}

int udev_register_rule(const char *rule_line)
{
	char *rule_buf = NULL;
	int res = -1;

	if (rule_line)
		rule_buf = strdup(rule_line);
	res = udev_rule_add(&udev_rules, rule_buf);
	if (rule_buf)
		free(rule_buf);
	return res;
}

void udev_rules_iter_init(udev_rules_t *rules)
{
	rules->current = 0;
}

udev_rule_t *udev_rules_iter_next(udev_rules_t *rules)
{
	static udev_rule_t *rule;

	if (!rules)
		return NULL;

	if (rules->current >= rules->bufsize) {
		return NULL;
	}

	/* get next rule */
	rule = (udev_rule_t *) (rules->buf + rules->current);
	rules->current += sizeof(udev_rule_t) + rule->bufsize;

	return rule;
}

static int udev_rules_get_key(char **line, char **key,
			      enum key_operation *operation, char **value)
{
	char *linepos;
	char *temp;

	linepos = *line;
	if (linepos == NULL && linepos[0] == '\0')
		return -1;

	/* skip whitespace */
	while (isspace(linepos[0]) || linepos[0] == ',')
		linepos++;

	/* get the key */
	if (linepos[0] == '\0')
		return -1;
	*key = linepos;

	while (1) {
		linepos++;
		if (linepos[0] == '\0')
			return -1;
		if (isspace(linepos[0]))
			break;
		if (linepos[0] == '=')
			break;
		if ((linepos[0] == '+') || (linepos[0] == '!') || (linepos[0] == ':'))
			if (linepos[1] == '=')
				break;
	}

	/* remember end of key */
	temp = linepos;

	/* skip whitespace after key */
	while (isspace(linepos[0]))
		linepos++;
	if (linepos[0] == '\0')
		return -1;

	/* get operation type */
	if (linepos[0] == '=' && linepos[1] == '=') {
		*operation = KEY_OP_MATCH;
		linepos += 2;
	} else if (linepos[0] == '!' && linepos[1] == '=') {
		*operation = KEY_OP_NOMATCH;
		linepos += 2;
	} else if (linepos[0] == '+' && linepos[1] == '=') {
		*operation = KEY_OP_ADD;
		linepos += 2;
	} else if (linepos[0] == '=') {
		*operation = KEY_OP_ASSIGN;
		linepos++;
	} else if (linepos[0] == ':' && linepos[1] == '=') {
		*operation = KEY_OP_ASSIGN_FINAL;
		linepos += 2;
	} else
		return -1;

	/* terminate key */
	temp[0] = '\0';

	/* skip whitespace after operator */
	while (isspace(linepos[0]))
		linepos++;
	if (linepos[0] == '\0')
		return -1;

	/* get the value*/
	if (linepos[0] == '"')
		linepos++;
	else
		return -1;
	*value = linepos;

	temp = strchr(linepos, '"');
	if (!temp)
		return -1;
	temp[0] = '\0';
	temp++;

	/* move line to next key */
	*line = temp;

	return 0;
}

/* extract possible KEY{attr} */
static char *udev_rules_get_key_attribute(char *str)
{
	char *pos;
	char *attr;

	attr = strchr(str, '{');
	if (attr != NULL) {
		attr++;
		pos = strchr(attr, '}');
		if (pos == NULL) {
			udev_log(UDEV_LOG_ERR,
				 "RULE: missing closing brace for format");
			return NULL;
		}
		pos[0] = '\0';
		return attr;
	}

	return NULL;
}

static int udev_rules_add_key(udev_rule_t *rule, struct key *key,
			      enum key_operation operation, const char *value)
{
	size_t val_len = strnlen(value, PATH_SIZE);

	key->operation = operation;

	key->val_off = rule->bufsize;
	strlcpy(rule->buf + rule->bufsize, value, val_len+1);
	rule->bufsize += val_len+1;
	return 0;
}

static int udev_rules_add_key_pair(udev_rule_t *rule, struct key_pairs *pairs,
				   enum key_operation operation, const char *key,
				   const char *value)
{
	size_t key_len = strnlen(key, PATH_SIZE);

	if (pairs->count >= PAIRS_MAX) {
		udev_log(UDEV_LOG_ERR,
			 "RULE: skip, too many keys of the same type in a single rule");
		return -1;
	}

	udev_rules_add_key(rule, &pairs->keys[pairs->count].key, operation, value);

	/* add the key-name of the pair */
	pairs->keys[pairs->count].key_name_off = rule->bufsize;
	strlcpy(rule->buf + rule->bufsize, key, key_len+1);
	rule->bufsize += key_len+1;

	pairs->count++;
	return 0;
}

int udev_rule_add(udev_rules_t *rules, char *line)
{
	char buf[sizeof(udev_rule_t) + LINE_SIZE];
	udev_rule_t *rule = NULL;
	size_t rule_size;
	int valid;
	char *linepos;
	char *attr;
	size_t padding;
	int physdev = 0;
	int retval;

	memset(buf, 0x00, sizeof(buf));
	rule = (udev_rule_t *) buf;
	rule->event_timeout = -1;
	linepos = line;
	valid = 0;

	/* get all the keys */
	while (1) {
		char *key;
		char *value;
		enum key_operation operation = KEY_OP_UNSET;

		retval = udev_rules_get_key(&linepos, &key, &operation, &value);
		if (retval)
			break;

		if (strcasecmp(key, "ACTION") == 0) {
			if (operation != KEY_OP_MATCH &&
			    operation != KEY_OP_NOMATCH) {
				udev_log(UDEV_LOG_ERR,
					 "RULE: invalid ACTION operation");
				goto invalid;
			}
			udev_rules_add_key(rule, &rule->action, operation, value);
			valid = 1;
			continue;
		}

		if (strcasecmp(key, "DEVPATH") == 0) {
			if (operation != KEY_OP_MATCH &&
			    operation != KEY_OP_NOMATCH) {
				udev_log(UDEV_LOG_ERR,
					 "RULE: invalid DEVPATH operation");
				goto invalid;
			}
			udev_rules_add_key(rule, &rule->devpath, operation, value);
			valid = 1;
			continue;
		}

		if (strcasecmp(key, "KERNEL") == 0) {
			if (operation != KEY_OP_MATCH &&
			    operation != KEY_OP_NOMATCH) {
				udev_log(UDEV_LOG_ERR,
					 "RULE: invalid KERNEL operation");
				goto invalid;
			}
			udev_rules_add_key(rule, &rule->kernel, operation, value);
			valid = 1;
			continue;
		}

		if (strcasecmp(key, "SUBSYSTEM") == 0) {
			if (operation != KEY_OP_MATCH &&
			    operation != KEY_OP_NOMATCH) {
				udev_log(UDEV_LOG_ERR,
					 "RULE: invalid SUBSYSTEM operation");
				goto invalid;
			}
			/* bus, class, subsystem events should all be the same */
			if (strcmp(value, "subsystem") == 0 ||
			    strcmp(value, "bus") == 0 ||
			    strcmp(value, "class") == 0) {
				if (strcmp(value, "bus") == 0 || strcmp(value, "class") == 0)
					udev_log(UDEV_LOG_ERR,
						 "RULE: not specified as 'subsystem', key=%s",
						 value);
				udev_rules_add_key(rule, &rule->subsystem, operation, "subsystem|class|bus");
			} else
				udev_rules_add_key(rule, &rule->subsystem, operation, value);
			valid = 1;
			continue;
		}

		if (strcasecmp(key, "DRIVER") == 0) {
			if (operation != KEY_OP_MATCH &&
			    operation != KEY_OP_NOMATCH) {
				udev_log(UDEV_LOG_ERR, "RULE: invalid DRIVER operation");
				goto invalid;
			}
			udev_rules_add_key(rule, &rule->driver, operation, value);
			valid = 1;
			continue;
		}

		if (strncasecmp(key, "ATTR{", sizeof("ATTR{")-1) == 0) {
			attr = udev_rules_get_key_attribute(key + sizeof("ATTR")-1);
			if (attr == NULL) {
				udev_log(UDEV_LOG_ERR, "RULE: error parsing ATTR attribute");
				goto invalid;
			}
			if (udev_rules_add_key_pair(rule, &rule->attr, operation, attr, value) != 0)
				goto invalid;
			valid = 1;
			continue;
		}

		if (strcasecmp(key, "KERNELS") == 0 ||
		    strcasecmp(key, "ID") == 0) {
			if (operation != KEY_OP_MATCH &&
			    operation != KEY_OP_NOMATCH) {
				udev_log(UDEV_LOG_ERR, "RULE: invalid KERNELS operation");
				goto invalid;
			}
			udev_rules_add_key(rule, &rule->kernels, operation, value);
			valid = 1;
			continue;
		}

		if (strcasecmp(key, "SUBSYSTEMS") == 0 ||
		    strcasecmp(key, "BUS") == 0) {
			if (operation != KEY_OP_MATCH &&
			    operation != KEY_OP_NOMATCH) {
				udev_log(UDEV_LOG_ERR, "RULE: invalid SUBSYSTEMS operation");
				goto invalid;
			}
			udev_rules_add_key(rule, &rule->subsystems, operation, value);
			valid = 1;
			continue;
		}

		if (strcasecmp(key, "DRIVERS") == 0) {
			if (operation != KEY_OP_MATCH &&
			    operation != KEY_OP_NOMATCH) {
				udev_log(UDEV_LOG_ERR, "RULE: invalid DRIVERS operation");
				goto invalid;
			}
			udev_rules_add_key(rule, &rule->drivers, operation, value);
			valid = 1;
			continue;
		}

		if (strncasecmp(key, "ATTRS{", sizeof("ATTRS{")-1) == 0 ||
		    strncasecmp(key, "SYSFS{", sizeof("SYSFS{")-1) == 0) {
			if (operation != KEY_OP_MATCH &&
			    operation != KEY_OP_NOMATCH) {
				udev_log(UDEV_LOG_ERR, "RULE: invalid ATTRS operation");
				goto invalid;
			}
			attr = udev_rules_get_key_attribute(key + sizeof("ATTRS")-1);
			if (attr == NULL) {
				udev_log(UDEV_LOG_ERR, "RULE: error parsing ATTRS attribute");
				goto invalid;
			}
			if (strncmp(attr, "device/", 7) == 0)
				udev_log(UDEV_LOG_ERR,
					 "RULE: 'device' link is deprecated");
			else if (strstr(attr, "../") != NULL)
				udev_log(UDEV_LOG_ERR,
					 "RULE: not reference parent sysfs directories");
			if (udev_rules_add_key_pair(rule, &rule->attrs, operation, attr, value) != 0)
				goto invalid;
			valid = 1;
			continue;
		}

		if (strncasecmp(key, "ENV{", sizeof("ENV{")-1) == 0) {
			attr = udev_rules_get_key_attribute(key + sizeof("ENV")-1);
			if (attr == NULL) {
				udev_log(UDEV_LOG_ERR, "RULE: error parsing ENV attribute");
				goto invalid;
			}
			if (strncmp(attr, "PHYSDEV", 7) == 0)
				physdev = 1;
			if (udev_rules_add_key_pair(rule, &rule->env, operation, attr, value) != 0)
				goto invalid;
			valid = 1;
			continue;
		}

		if (strcasecmp(key, "PROGRAM") == 0) {
			udev_rules_add_key(rule, &rule->program, operation, value);
			valid = 1;
			continue;
		}

		if (strcasecmp(key, "RESULT") == 0) {
			if (operation != KEY_OP_MATCH &&
			    operation != KEY_OP_NOMATCH) {
				udev_log(UDEV_LOG_ERR, "RULE: invalid RESULT operation");
				goto invalid;
			}
			udev_rules_add_key(rule, &rule->result, operation, value);
			valid = 1;
			continue;
		}

		if (strncasecmp(key, "IMPORT", sizeof("IMPORT")-1) == 0) {
			attr = udev_rules_get_key_attribute(key + sizeof("IMPORT")-1);
			if (attr != NULL && strstr(attr, "file")) {
				udev_log(UDEV_LOG_DEBUG, "RULE: IMPORT will be included as file");
				rule->import_type  = IMPORT_FILE;
			} else {
				udev_log(UDEV_LOG_DEBUG,
					 "RULE: default IMPORT type will be file");
				rule->import_type  = IMPORT_FILE;
			}
			udev_rules_add_key(rule, &rule->import, operation, value);
			valid = 1;
			continue;
		}

		if (strncasecmp(key, "NAME", sizeof("NAME")-1) == 0) {
			attr = udev_rules_get_key_attribute(key + sizeof("NAME")-1);
			if (attr != NULL) {
				if (strstr(attr, "all_partitions") != NULL) {
					udev_log(UDEV_LOG_DEBUG, "RULE: creation of partition nodes requested");
					rule->partitions = DEFAULT_PARTITIONS_COUNT;
				}
				if (strstr(attr, "ignore_remove") != NULL) {
					udev_log(UDEV_LOG_DEBUG, "RULE: remove event should be ignored");
					rule->ignore_remove = 1;
				}
			}
			if (value[0] == '\0')
				udev_log(UDEV_LOG_DEBUG, "RULE: name empty, node creation supressed");
			udev_rules_add_key(rule, &rule->name, operation, value);
			continue;
		}

		if (strcasecmp(key, "SYMLINK") == 0) {
			if (operation == KEY_OP_MATCH ||
			    operation == KEY_OP_NOMATCH)
				udev_rules_add_key(rule, &rule->symlink_match, operation, value);
			else
				udev_rules_add_key(rule, &rule->symlink, operation, value);
			valid = 1;
			continue;
		}

		if (strcasecmp(key, "OWNER") == 0) {
			valid = 1;
			if (rules->resolve_names && (!strchr(value, '$') && !strchr(value, '%'))) {
				char *endptr;
				strtoul(value, &endptr, 10);
				if (endptr[0] != '\0') {
					char owner[32];
					uid_t uid = udev_lookup_user(value);
					udev_log(UDEV_LOG_DEBUG, "RULE: replacing username='%s' by id=%i", value, uid);
					sprintf(owner, "%u", (unsigned int) uid);
					udev_rules_add_key(rule, &rule->owner, operation, owner);
					continue;
				}
			}

			udev_rules_add_key(rule, &rule->owner, operation, value);
			continue;
		}

		if (strcasecmp(key, "GROUP") == 0) {
			valid = 1;
			if (rules->resolve_names && (!strchr(value, '$') && !strchr(value, '%'))) {
				char *endptr;
				strtoul(value, &endptr, 10);
				if (endptr[0] != '\0') {
					char group[32];
					gid_t gid = udev_lookup_group(value);
					udev_log(UDEV_LOG_DEBUG, "RULE: replacing groupname='%s' by id=%i", value, gid);
					sprintf(group, "%u", (unsigned int) gid);
					udev_rules_add_key(rule, &rule->group, operation, group);
					continue;
				}
			}

			udev_rules_add_key(rule, &rule->group, operation, value);
			continue;
		}

		if (strcasecmp(key, "MODE") == 0) {
			udev_rules_add_key(rule, &rule->mode, operation, value);
			valid = 1;
			continue;
		}

		if (strcasecmp(key, "OPTIONS") == 0) {
			const char *pos;

			if (strstr(value, "last_rule") != NULL) {
				rule->last_rule = 1;
			}
			if (strstr(value, "ignore_device") != NULL) {
				rule->ignore_device = 1;
			}
			if (strstr(value, "ignore_remove") != NULL) {
				rule->ignore_remove = 1;
			}
			pos = strstr(value, "link_priority=");
			if (pos != NULL) {
				rule->link_priority = atoi(&pos[strlen("link_priority=")]);
			}
			pos = strstr(value, "event_timeout=");
			if (pos != NULL) {
				rule->event_timeout = atoi(&pos[strlen("event_timeout=")]);
			}
			pos = strstr(value, "string_escape=");
			if (pos != NULL) {
				pos = &pos[strlen("string_escape=")];
				if (strncmp(pos, "none", strlen("none")) == 0)
					rule->string_escape = ESCAPE_NONE;
				else if (strncmp(pos, "replace", strlen("replace")) == 0)
					rule->string_escape = ESCAPE_REPLACE;
			}
			if (strstr(value, "all_partitions") != NULL) {
				rule->partitions = DEFAULT_PARTITIONS_COUNT;
			}
			valid = 1;
			continue;
		}

		udev_log(UDEV_LOG_ERR, "RULE: unknown key, key=%s", key);
	}

	/* skip line if not any valid key was found */
	if (!valid)
		goto invalid;

	/* grow buffer and add rule */
	rule_size = sizeof(udev_rule_t) + rule->bufsize;
	padding = (sizeof(size_t) - rule_size % sizeof(size_t)) % sizeof(size_t);
	rule_size += padding;
	rule->bufsize += padding;

	rules->buf = realloc(rules->buf, rules->bufsize + rule_size);
	if (!rules->buf) {
		udev_log(UDEV_LOG_ERR, "RULE: realloc failed");
		goto exit;
	}
	memcpy(rules->buf + rules->bufsize, rule, rule_size);
	rules->bufsize += rule_size;
exit:
	/* TODO: tbi */
	return 0;

invalid:
	udev_log(UDEV_LOG_ERR, "RULE: invalid rule");
	return -1;
}
