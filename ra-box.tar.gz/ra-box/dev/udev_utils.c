#include "udev_priv.h"

int udev_create_path(const char *path)
{
#ifndef CONFIG_UDEV_EMULATE
	return fs_create_path(path);
#endif
	return 0;
}

int udev_make_device(unsigned int maj, unsigned int min)
{
#ifndef CONFIG_UDEV_EMULATE
	return makedev(maj, min);
#endif
	return 0;
}

int udev_delete_path(const char *path)
{
#ifndef CONFIG_UDEV_EMULATE
	return fs_delete_path(path);
#endif
	return 0;
}

int udev_unlink_file(const char *file)
{
#ifndef CONFIG_UDEV_EMULATE
	unlink(file);
#endif
	return 0;
}

int udev_unlink_secure(const char *file)
{
#ifndef CONFIG_UDEV_EMULATE
	fs_unlink_secure(file);
#endif
	return 0;
}

int udev_rename_file(const char *old, const char *new)
{
#ifndef CONFIG_UDEV_EMULATE
	return rename(old, new);
#endif
	return 0;
}

int udev_make_node(const char *file, mode_t mode, dev_t devt)
{
//#ifdef CONFIG_UDEV_EMULATE
	return mknod(file, mode, devt);
//#endif
	return 0;
}

void udev_name_list_free(list_t *name_list)
{
	udev_name_t *name_loop, *tmp;

	for_each_name_safe(name_loop, tmp, *name_list) {
		list_delete(&name_loop->node);
		free(name_loop);
	}
}

udev_name_t *udev_name_list_add(list_t *name_list,
				const char *name, int sort)
{
	udev_name_t *name_loop;
	udev_name_t *name_new;

	/* avoid duplicate entries */
	for_each_name(name_loop, *name_list) {
		if (strcmp(name_loop->name, name) == 0) {
			udev_log(UDEV_LOG_DEBUG,
				 "NAME: entry is already in the list, name=%s", name);
			return name_loop;
		}
	}

	if (sort) {
		for_each_name(name_loop, *name_list) {
			if (strcmp(name_loop->name, name) > 0)
				break;
		}
	}

	name_new = malloc(sizeof(udev_name_t));
	if (name_new == NULL)
		return NULL;

	strlcpy(name_new->name, name, sizeof(name_new->name));
	list_insert_before(&name_new->node, &name_loop->node);

	return name_new;
}

udev_name_t *udev_name_list_key_add(list_t *name_list,
				    const char *key,
				    const char *value)
{
	udev_name_t *name_loop;
	udev_name_t *name_new;

	for_each_name(name_loop, *name_list) {
		if (strncmp(name_loop->name, key, strlen(key)) == 0) {
			udev_log(UDEV_LOG_DEBUG,
				 "NAME: key already present, replace it, name=%s",
				 name_loop->name);
			snprintf(name_loop->name, sizeof(name_loop->name), "%s=%s", key, value);
			name_loop->name[sizeof(name_loop->name)-1] = '\0';
			return name_loop;
		}
	}

	name_new = malloc(sizeof(udev_name_t));
	if (name_new == NULL)
		return NULL;

	snprintf(name_new->name, sizeof(name_new->name), "%s=%s", key, value);
	name_new->name[sizeof(name_new->name)-1] = '\0';
	list_insert_before(&name_new->node, &name_loop->node);
	return name_new;
}

int udev_name_list_key_remove(list_t *name_list, const char *key)
{
	udev_name_t *name_loop, *tmp;
	size_t keylen = strlen(key);
	int retval = 0;

	for_each_name_safe(name_loop, tmp, *name_list) {
		if (strncmp(name_loop->name, key, keylen) != 0)
			continue;
		if (name_loop->name[keylen] != '=')
			continue;
		list_delete(&name_loop->node);
		free(name_loop);
		retval = 1;
		break;
	}
	return retval;
}

void udev_name_list_cleanup(list_t *name_list)
{
	udev_name_t *name_loop, *tmp;

	for_each_name_safe(name_loop, tmp, *name_list) {
		list_delete(&name_loop->node);
		free(name_loop);
	}
}

uid_t udev_lookup_user(const char *user)
{
	struct passwd *pw;
	uid_t uid = 0;

	errno = 0;
	pw = getpwnam(user);
	if (pw == NULL) {
		if (errno == 0 || errno == ENOENT || errno == ESRCH) {
			udev_log(UDEV_LOG_ERR,
				 "PERM: specified user unknown, user=%s",
				 user);
		} else {
			udev_log(UDEV_LOG_ERR,
				 "PERM: error resolving user, user=%s, err=%s",
				 user, strerror(errno));
		}
	} else {
		uid = pw->pw_uid;
	}
	return uid;
}

gid_t udev_lookup_group(const char *group)
{
	struct group *gr;
	gid_t gid = 0;

	errno = 0;
	gr = getgrnam(group);
	if (gr == NULL) {
		if (errno == 0 || errno == ENOENT || errno == ESRCH) {
			udev_log(UDEV_LOG_ERR,
				 "PERM: specified group unknown, group=%s",
				 group);
		} else {
			udev_log(UDEV_LOG_ERR,
				 "PERM: error resolving group, group=%s, err=%s",
				 group, strerror(errno));
		}
	} else {
		gid = gr->gr_gid;
	}
	return gid;
}
