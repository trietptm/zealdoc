#include "udev_priv.h"

DECLARE_LIST(udev_nodes);
DECLARE_NOTIFY_CHAIN(udev_chain);

#define for_each_node(node)	\
	list_for_each_entry(udev_node_t, node, &udev_nodes, link)

int udev_notify(unsigned long val, void *v)
{
	return call_notify_chain(&udev_chain, val, v);
}

int udev_register_notify(notify_t *nb)
{
	udev_node_t *node, *last;
	int err;

	err = register_notify_chain(&udev_chain, nb);
	if (err)
		goto unlock;
	for_each_node(node) {
		err = nb->call(nb, UDEV_CREATE, node);
		err = notify_to_errno(err);
		if (err)
			goto rollback;
	}
unlock:
	return err;
rollback:
	last = node;
	for_each_node(node) {
		if (node == last)
			break;
		nb->call(nb, UDEV_DELETE, node);
	}
	goto unlock;
}

int udev_unregister_notify(notify_t *nb)
{
	return unregister_notify_chain(&udev_chain, nb);
}

static udev_node_t *udev_node_by_file(const char *filename)
{
	udev_node_t *node;

	for_each_node(node) {
		if (strcasecmp(filename, node->filename) == 0)
			return node;
	}
	return NULL;
}

static void udev_node_deleted(const char *filename)
{
	udev_node_t *node;
	
	BUG_ON(!filename);
	node = udev_node_by_file(filename);
	if (node) {
		udev_notify(UDEV_DELETE, node);

		if (node->filename)
			free(node->filename);
		list_delete(&node->link);
		free(node);
	}
}

static void udev_node_created(const char *filename)
{
	udev_node_t *node;
	
	BUG_ON(!filename);

	node = udev_node_by_file(filename);
	if (node)
		udev_node_deleted(filename);

	node = malloc(sizeof (udev_node_t));
	if (node) {
		memset(node, 0, sizeof (udev_node_t));
		list_init(&node->link);
		node->filename = strdup(filename);
		list_insert_before(&node->link, &udev_nodes);

		udev_notify(UDEV_CREATE, node);
	}
}

int udev_node_mknod(udev_device_t *udev, const char *file,
		    dev_t devt, mode_t mode, uid_t uid, gid_t gid)
{
	struct stat stats;
	int ret = 0;
	
	if (major(devt) != 0 && strcmp(udev->dev->subsystem, "block") == 0)
		mode |= S_IFBLK;
	else
		mode |= S_IFCHR;
	
	if (lstat(file, &stats) == 0) {
		if ((mode_t)(stats.st_mode & S_IFMT) == (mode & S_IFMT) &&
		    (stats.st_rdev == devt)) {
			udev_log(UDEV_LOG_INFO,
				 "NODE: correct dev_t, preserve file, file=%s",
				 file);
			goto perms;
		}
	} else {
		/* node does not exist */
		ret = udev_make_node(file, mode, devt);
		if (ret == 0)
			goto perms;
		else
			goto exit;
	}

perms:
#ifndef CONFIG_UDEV_EMULATE
	if (chmod(file, mode) != 0){
		udev_log(UDEV_LOG_ERR,
			 "NODE: chmod(%s, %#o) failed - %s",
			 file, mode, strerror(errno));
		goto exit;
	}

	if (uid != 0 || gid != 0) {
		if (chown(file, uid, gid) != 0) {
			udev_log(UDEV_LOG_ERR,
				 "NODE: chown(%s, %u, %u) failed - %s",
				 file, uid, gid, strerror(errno));
			goto exit;
		}
	}
#endif
exit:
	return ret;
}

int udev_node_add(udev_device_t *udev, udev_event_t *msg)
{
	char filename[PATH_SIZE];
	uid_t uid;
	gid_t gid;
	int i;
	int ret = 0;

	strlcpy(filename, _PATH_DEV, sizeof(filename));
	if (strlast(filename) != '/')
		strlcat(filename, "/", sizeof(filename));
	strlcat(filename, udev->name, sizeof(filename));
	udev_create_path(filename);

	if (strcmp(udev->owner, "root") == 0) {
		uid = 0;
	} else {
		char *endptr;
		unsigned long id;

		id = strtoul(udev->owner, &endptr, 10);
		if (endptr[0] == '\0')
			uid = (uid_t) id;
		else
			uid = udev_lookup_user(udev->owner);
	}

	if (strcmp(udev->group, "root") == 0) {
		gid = 0;
	} else {
		char *endptr;
		unsigned long id;

		id = strtoul(udev->group, &endptr, 10);
		if (endptr[0] == '\0')
			gid = (gid_t) id;
		else
			gid = udev_lookup_group(udev->group);
	}

	udev_log(UDEV_LOG_INFO,
		 "NODE: create dev, file=%s, major=%d, minor=%d",
		 filename, major(udev->devt), minor(udev->devt));

	if (udev_node_mknod(udev, filename, udev->devt,
			    udev->mode, uid, gid) != 0) {
		ret = -1;
		goto exit;
	}

	udev_node_created(filename);
	udev_event_setenv(msg, "DEVNAME", filename, 1);

	/* create all_partitions if requested */
	if (udev->partitions) {
		char partitionname[PATH_SIZE];
		char *attr;
		int range;

		/* take the maximum registered minor range */
		attr = sysfs_attr_get_value(udev->dev->devpath, "range");
		if (attr != NULL) {
			range = atoi(attr);
			if (range > 1)
				udev->partitions = range-1;
		}
		udev_log(UDEV_LOG_INFO,
			 "NODE: create dev partitions, partition=%s[1-%i]",
			 filename, udev->partitions);
		for (i = 1; i <= udev->partitions; i++) {
			dev_t part_devt;

			snprintf(partitionname, sizeof(partitionname), "%s%d", filename, i);
			partitionname[sizeof(partitionname)-1] = '\0';
			part_devt = udev_make_device(major(udev->devt), minor(udev->devt) + (dev_t)i);
			udev_node_mknod(udev, partitionname, part_devt, udev->mode, uid, gid);

			udev_node_created(partitionname);
		}
	}
exit:
	return ret;
}

int udev_node_remove(udev_device_t *udev, udev_event_t *msg)
{
	char partitionname[PATH_SIZE];
	char filename[PATH_SIZE];
	struct stat stats;
	int ret = 0;
	int num;

	strlcpy(filename, _PATH_DEV, sizeof(filename));
	if (strlast(filename) != '/')
		strlcat(filename, "/", sizeof(filename));
	strlcat(filename, udev->name, sizeof(filename));
	if (stat(filename, &stats) != 0) {
		udev_log(UDEV_LOG_INFO, "device node not found, node=%s", filename);
		return 0;
	}

	if (udev->devt && stats.st_rdev != udev->devt) {
		udev_log(UDEV_LOG_INFO,
			 "NODE: skip removal due to incorrect dev_t, node=%s",
			 filename);
		return -1;
	}

	udev_log(UDEV_LOG_INFO,
		 "NODE: removing device node, node='%s'", filename);

	ret = udev_unlink_secure(filename);
	if (ret)
		return ret;
	udev_node_deleted(filename);

	udev_event_setenv(msg, "DEVNAME", filename, 1);
	num = udev->partitions;
	if (num > 0) {
		int i;

		udev_log(UDEV_LOG_INFO,
			 "NODE: removing all partitions, part=%s[1-%i]",
			 filename, num);
		if (num > 255)
			return -1;
		for (i = 1; i <= num; i++) {
			snprintf(partitionname, sizeof(partitionname), "%s%d", filename, i);
			partitionname[sizeof(partitionname)-1] = '\0';
			udev_unlink_secure(partitionname);

			udev_node_deleted(partitionname);
		}
	}
	udev_delete_path(filename);
	return ret;
}
