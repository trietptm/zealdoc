#ifndef __UDEV_PRIV_H__
#define __UDEV_PRIV_H__

#include <sysdep.h>
#include <logger.h>
#include <list.h>
#include <eloop.h>
#include <strutl.h>
#include <fsserv.h>
#include <net_skb.h>
#include <service.h>
#include <module.h>
#include <notify.h>
#include <panic.h>

#include <linux/netlink.h>
#include <linux/socket.h>
#include <udev.h>

typedef struct _udev_rules_t udev_rules_t;

/* ============================================================ *
 * logging operation
 * ============================================================ */
#define UDEV_LOG_CRIT		LOG_EMERG
#define UDEV_LOG_FAIL		LOG_CRIT
#define UDEV_LOG_ERR		LOG_ERR
#define UDEV_LOG_WARN		LOG_WARNING
#define UDEV_LOG_INFO		LOG_INFO
#define UDEV_LOG_DEBUG		LOG_DEBUG

void udev_log(int level, const char *format, ...);

/* ============================================================ *
 * udev definitions
 * ============================================================ */
#define COMMENT_CHARACTER		'#'
#define LINE_SIZE			512
#define VALUE_SIZE			128

#define ALLOWED_CHARS			"#+-.:=@_"
#define ALLOWED_CHARS_FILE		ALLOWED_CHARS "/"
#define ALLOWED_CHARS_INPUT		ALLOWED_CHARS_FILE " $%?,"

#define DEFAULT_PARTITIONS_COUNT	15

#define UEVENT_BUFFER_SIZE		2048

#define TMP_FILE_EXT			".udev-tmp"

#define DB_DIR				".udev/db"
#define DB_NAME_INDEX_DIR		".udev/names"
#define RULES_DYN_DIR			".udev/rules.d"

struct _udev_device_t {
	/* device event */
	sysfs_device_t *dev;	/* point to dev_local by default */
	sysfs_device_t dev_local;
	sysfs_device_t *dev_parent;/* current parent device used for match */
	char action[NAME_SIZE];
	char *devpath_old;

	/* node */
	char name[PATH_SIZE];
	list_t symlink_list;
	int symlink_final;
	char owner[NAME_SIZE];
	int owner_final;
	char group[NAME_SIZE];
	int group_final;
	mode_t mode;
	int mode_final;
	dev_t devt;
	
	/* event processing */
	list_t env_list;
	char tmp_node[PATH_SIZE];
	int partitions;
	int ignore_device;
	int ignore_remove;
	char *program_result;
	int link_priority;
	int event_timeout;
};

typedef struct _udev_name_t {
	list_t node;
	char name[PATH_SIZE];
	unsigned int ignore_error:1;
} udev_name_t;

#define PAIRS_MAX		5
#define RULESFILE_SUFFIX	".rules"

enum key_operation {
	KEY_OP_UNSET,
	KEY_OP_MATCH,
	KEY_OP_NOMATCH,
	KEY_OP_ADD,
	KEY_OP_ASSIGN,
	KEY_OP_ASSIGN_FINAL,
};

struct key {
	enum key_operation operation;
	size_t val_off;
};

struct key_pair {
	struct key key;
	size_t key_name_off;
};

struct key_pairs {
	int count;
	struct key_pair keys[PAIRS_MAX];
};

enum import_type {
	IMPORT_UNSET,
	IMPORT_FILE,
};

enum escape_type {
	ESCAPE_UNSET,
	ESCAPE_NONE,
	ESCAPE_REPLACE,
};

struct _udev_rule_t {
	struct key action;
	struct key devpath;
	struct key kernel;
	struct key subsystem;
	struct key driver;
	struct key_pairs attr;

	struct key kernels;
	struct key subsystems;
	struct key drivers;
	struct key_pairs attrs;

	struct key_pairs env;
	struct key result;
	struct key program;
	struct key import;
	enum import_type import_type;

	struct key name;
	struct key symlink;
	struct key symlink_match;
	struct key owner;
	struct key group;
	struct key mode;
	enum escape_type string_escape;

	unsigned int link_priority;
	int event_timeout;
	unsigned int partitions;
	unsigned int last_rule:1,
		     ignore_device:1,
		     ignore_remove:1;

	size_t bufsize;
	char buf[];
};

struct _udev_rules_t {
	char *buf;
	size_t bufsize;
	size_t current;
	int resolve_names;
};

typedef struct _udev_prog_t {
	const char *name;
	udev_program_t program;
	list_t link;
} udev_prog_t;

struct _udev_event_t {
	int exitstatus;
	time_t queue_time;
	char *action;
	char *devpath;
	char *subsystem;
	char *driver;
	dev_t devt;
	uint64_t seqnum;
	char *devpath_old;
	char *physdevpath;
	unsigned int timeout;
	list_t node;
	int buf_size;
	char **envp;
	char envbuf[];
};

/* node interfaces */
int udev_node_add(udev_device_t *udev, udev_event_t *msg);
int udev_node_remove(udev_device_t *udev, udev_event_t *msg);
int udev_node_mknod(udev_device_t *udev, const char *file,
		    dev_t devt, mode_t mode, uid_t uid, gid_t gid);
/* ============================================================ *
 * file operation
 * ============================================================ */
int udev_create_path(const char *path);
int udev_delete_path(const char *path);
int udev_unlink_file(const char *path);
int udev_rename_file(const char *old, const char *new);
int udev_unlink_secure(const char *file);
int udev_make_device(unsigned int maj, unsigned int min);
int udev_make_node(const char *file, mode_t mode, dev_t devt);

/* ============================================================ *
 * name list
 * ============================================================ */
#define for_each_name(loop, head)		\
	list_for_each_entry(udev_name_t, loop, &head, node)
#define for_each_name_safe(loop, tmp, head)	\
	list_for_each_entry_safe(udev_name_t, loop, tmp, &head, node)

void udev_name_list_free(list_t *name_list);
udev_name_t *udev_name_list_add(list_t *name_list,
				  const char *name, int sort);
int udev_name_list_key_remove(list_t *name_list, const char *key);
udev_name_t *udev_name_list_key_add(list_t *name_list,
				      const char *key,
				      const char *value);
void udev_name_list_cleanup(list_t *name_list);

uid_t udev_lookup_user(const char *user);
gid_t udev_lookup_group(const char *group);

/* ============================================================ *
 * name database
 * ============================================================ */
int udev_db_get_device(udev_device_t *udev, const char *devpath);

/* ============================================================ *
 * device operation
 * ============================================================ */
udev_device_t *udev_device_new(void);
int udev_add_device(udev_device_t *udev);
void udev_device_free(udev_device_t *udev);

/* ============================================================ *
 * rule operation
 * ============================================================ */
void udev_rules_iter_init(udev_rules_t *rules);
udev_rule_t *udev_rules_iter_next(udev_rules_t *rules);

void udev_rules_apply_format(udev_event_t *msg, udev_device_t *udev,
			     char *string, size_t maxsize);
int udev_rules_get_name(udev_event_t *msg, udev_rules_t *rules, udev_device_t *udev);
int udev_rules_get_run(udev_event_t *msg, udev_rules_t *rules, udev_device_t *udev);
int udev_rule_add(udev_rules_t *rules, char *line);

extern udev_rules_t udev_rules;

/* ============================================================ *
 * scan operation
 * ============================================================ */
int udev_scan_coldplug(void);
int udev_event_settled(void);
void udev_retry_failed(void);

/* ============================================================ *
 * event operation
 * ============================================================ */
void udev_event_free(udev_event_t *msg);
udev_event_t *udev_event_new(int buf_size);
udev_event_t *udev_event_parse(const char *buf, int buf_size);

/* ============================================================ *
 * program operation
 * ============================================================ */
int udev_prog_run(udev_event_t *msg, udev_device_t *dev,
		  const char *command, const char *subsystem);
udev_prog_t *udev_prog_by_name(const char *name);

/* ============================================================ *
 * service operation
 * ============================================================ */
int udev_event_start(void);
void udev_event_stop(void);
int udev_cold_start(void);

/* ============================================================ *
 * notify operation
 * ============================================================ */
int udev_notify(unsigned long val, void *v);

void __exit udev_rule_exit(void);

#endif /*__UDEV_PRIV_H__*/
