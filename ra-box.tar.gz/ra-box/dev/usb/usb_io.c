#include "usb_priv.h"

#ifdef WIN32
extern struct sys_device_ops win_device_ops;
struct sys_device_ops *sys_ops = &win_device_ops;
#else
extern struct sys_device_ops linux_device_ops;
struct sys_device_ops *sys_ops = &linux_device_ops;
#endif

#define for_each_trans_safe(pos, n, intfc)	\
	list_for_each_entry_safe(usb_transfer_t, pos, n, &intfc->transfer_list, link)

static struct usb_transfer *
usb_alloc_transfer(usb_intfc_t *intfc, int iso_packets);

static void __usb_discard_trans_eloop(void *eloop, void *data);
static void usb_stop_trans_to(struct usb_transfer *);
static void usb_start_trans_to(struct usb_transfer *);

/* cancel and free */
static void usb_discard_transfer(struct usb_transfer *transfe, uint8_t op);
static int usb_cancel_transfer(struct usb_transfer *transfer);
static int usb_submit_transfer(struct usb_transfer *transfer);
static int usb_finish_transfer(struct usb_transfer *transfer);
static int usb_free_check(struct usb_transfer *trans);
static void __free_check_timeout(void *e, void *data);
static void usb_free_transfer(struct usb_transfer *transfer);

int usb_set_configuration(usb_intfc_t *intfc, uint8_t config_idx)
{
	int r;

	if (intfc->dev->active_config == config_idx)
		return USB_SUCCESS;	
	if (intfc->claimed) {
		usb_log(USB_LOG_ERR,
			"IO: cannot set configuration on the claimed interface");
		return USB_ERROR_IO;
	}

	r = sys_ops->sys_set_config(intfc, config_idx);
	if (r == USB_SUCCESS) {
		intfc->dev->active_config = config_idx;
		/* FIXME: can do it? */
		intfc->claimed = 1;
	//	intfc->altsetting = USB_INVALID_INTFC;
	}
	return r;
}

int usb_claim_interface(usb_intfc_t *intfc)
{
	int r;

	if(intfc->dev->active_config == USB_INVALID_CONFIG) {
		usb_log(USB_LOG_ERR,
				"IO: cannot claim interface with invalid configuration %d", 
				intfc->dev->active_config);
		return USB_ERROR_IO;
	}

	if (intfc->claimed) {
		usb_log(USB_LOG_DEBUG, "IO: interface has been claimed");
		return USB_SUCCESS;
	}

	r =  sys_ops->sys_claim_intfc(intfc);
	if (r == USB_SUCCESS) {
		intfc->claimed = 1;
	}
	
	return r;
}

int usb_release_interface(usb_intfc_t *intfc, uint8_t intfc_num)
{
	int r;

	if (intfc->claimed == 0)
		return USB_SUCCESS;
	r = sys_ops->sys_release_intfc(intfc);
	if (r == USB_SUCCESS)
		intfc->claimed = 0;

	return r;		
}

static struct usb_transfer *usb_alloc_transfer(usb_intfc_t *intfc, int iso_packets)
{
	int alloc_size;
	struct usb_transfer *transfer;

	alloc_size = sizeof(struct usb_transfer)
		+ (sizeof(struct usb_iso_packet_descriptor) * iso_packets);
	transfer = malloc(alloc_size);
	if (!transfer)
		return NULL;
	memset(transfer, 0, alloc_size);
	if (sys_ops->transfer_priv_size > 0) {
		transfer->os_priv = malloc(sys_ops->transfer_priv_size);
		if (!transfer->os_priv) {
			free(transfer);
			return NULL;
		}
		memset(transfer->os_priv, 0, sys_ops->transfer_priv_size);
	}
	transfer->num_iso_packets = iso_packets;
	transfer->dev_handle = intfc;
	list_insert_tail(&transfer->link, &transfer->dev_handle->transfer_list);

	return transfer;
}

static void usb_free_transfer(struct usb_transfer *transfer)
{
	if (!transfer)
		return;
	usb_log(USB_SHOW, "IO: free trans");
	/* XXX: cancel  */
	eloop_cancel_timeout(NULL, __free_check_timeout, NULL, transfer);

	if (transfer->buffer && 
		(transfer->flag & USB_TRANSFER_FREE_BUFFER))
		free(transfer->buffer);
	if (transfer->os_priv)
		free(transfer->os_priv);

	list_delete(&transfer->link);
	free(transfer);
}

static int usb_urb_transfer(uint8_t trans_type, struct usb_trans_params *param, 
		     usb_bulk_trans_callback cb)
{
	struct usb_transfer *usb_trans;

	if (!param->dev_handle)
		return USB_ERROR_NO_DEVICE;

	usb_trans = usb_alloc_transfer(param->dev_handle, 0);
	if (!usb_trans)
		return USB_ERROR_NO_MEM;

	usb_trans->flag = USB_TRANSFER_FREE_TRANSFER;
	usb_trans->type = trans_type;
	usb_trans->endpoint = param->ep;
	usb_trans->buffer = param->buf;
	usb_trans->length = param->buf_len;
	usb_trans->actual_length = 0;
	usb_trans->callback = cb;
	usb_trans->user_data = param;
	usb_trans->timeout.tv_sec = 1;
	usb_trans->timeout.tv_usec = USB_TRANSFER_TIMEOUT;

	return usb_submit_transfer(usb_trans);
}

int usb_bulk_write(struct usb_trans_params *usb_param, 
		   usb_bulk_trans_callback cb)
{
	return usb_urb_transfer(USB_TRANSFER_TYPE_BULK, usb_param, cb);
}

int usb_bulk_read(struct usb_trans_params *param, usb_bulk_trans_callback cb)
{
	return usb_urb_transfer(USB_TRANSFER_TYPE_BULK, param, cb);
}

int usb_interrupt_write(struct usb_trans_params *param, usb_bulk_trans_callback cb)
{
	return usb_urb_transfer(USB_TRANSFER_TYPE_INTERRUPT, param, cb);
}

int usb_interrupt_read(struct usb_trans_params *param, usb_bulk_trans_callback cb)
{
	return usb_urb_transfer(USB_TRANSFER_TYPE_BULK, param, cb);
}

int usb_control_transfer(struct usb_trans_params *usb_param, usb_bulk_trans_callback cb)
{
	usb_param->ep = USB_ENDPOINT_CONTROL;
	return usb_urb_transfer(USB_TRANSFER_TYPE_CONTROL, usb_param, cb);
}

void usb_intfc_discard_trans(usb_intfc_t *usb_handle)
{
	struct usb_transfer *trans_pos, *trans_n;

	for_each_trans_safe(trans_pos, trans_n, usb_handle) {
		trans_pos->status = USB_TRANSFER_CANCELLED;
		usb_discard_transfer(trans_pos, USB_TRANS_DISCARD);
	}
}

int usb_get_endpoints(struct usb_device *usb_dev, usb_intfc_desc_t *altsetting)
{
	int e;

	/* class driver will check bInterfaceProtocol byself */
#if 0
	if (altsetting->bInterfaceProtocol != 0x00)
		return USB_SUCCESS;
#endif	
	for (e = 0; e < altsetting->bNumEndpoints; e++) {
		const struct usb_endpoint_descriptor *ep;
		
		ep = &altsetting->endpoint[e];

		if ((ep->bmAttributes & USB_TRANSFER_TYPE_MASK)
			== USB_TRANSFER_TYPE_BULK) {			
			if ((ep->bEndpointAddress & USB_ENDPOINT_DIR_MASK) 
				== USB_ENDPOINT_IN) {
				usb_dev->ep_i = ep->bEndpointAddress;
			} else if ((ep->bEndpointAddress & USB_ENDPOINT_DIR_MASK)
				== USB_ENDPOINT_OUT) {
				usb_dev->ep_o = ep->bEndpointAddress;
			}
		} else if ((ep->bmAttributes & USB_TRANSFER_TYPE_MASK)
			== USB_TRANSFER_TYPE_INTERRUPT) {
			usb_dev->ep_intr = ep->bEndpointAddress;
		}
	}
	return 0;
}

void usbi_eloop_handle_cb(int fd, void *eloop_data, void *user_ctx)
{
	usb_intfc_t *dev_handle = (usb_intfc_t *)user_ctx;
	struct usb_transfer *usb_trans = NULL;
	int r;
	
	r = sys_ops->sys_asyn_reap(dev_handle, &usb_trans);

	if (r == USB_SUCCESS) {
		if (usb_trans->status == USB_TRANSFER_REAPING) {
			usb_log(USB_LOG_DEBUG, "IO: there are some more URBs");
			return;
		} else {
			struct usb_trans_params *param = usb_trans->user_data;
			param->rbuf_actual = usb_trans->actual_length;
			usb_discard_transfer(usb_trans, USB_TRANS_DISTYPE_FINISH);
		}
	} else {
		if (r == USB_REAP_AGAIN)
			return;
		usb_log(USB_LOG_ERR, "IO: asyn reap failed=%d", r);
		
		if (!usb_trans) {
			struct usb_transfer *t_pos, *t_n;

			for_each_trans_safe(t_pos, t_n, dev_handle) {
				if (r == USB_ERROR_NO_DEVICE)
					usb_trans->status = USB_TRANSFER_NO_DEVICE;
				else
					usb_trans->status = USB_TRANSFER_REAP_ERROR;
				usb_discard_transfer(usb_trans, USB_TRANS_DISCARD);
			}
			/* restart device */
			usb_device_close(dev_handle);
			usb_device_open(dev_handle);
		} else {
			if (r == USB_ERROR_NO_DEVICE)
				usb_trans->status = USB_TRANSFER_NO_DEVICE;
			else
				usb_trans->status = USB_TRANSFER_REAP_ERROR;
			usb_discard_transfer(usb_trans, USB_TRANS_DISCARD);
		}
	}
}

static void __usb_discard_trans_eloop(void *eloop, void *data)
{
	struct usb_transfer *transfer = (struct usb_transfer *)data;


	/* cancel, notify user and free resource */
	usb_log(USB_LOG_ERR, "IO: transfer timeout, discard it");
	transfer->status = USB_TRANSFER_TIME_OUT;
	
	usb_discard_transfer(transfer, USB_TRANS_DISCARD);
}

static void usb_start_trans_to(struct usb_transfer *transfer)
{
	/* FIXME: not use samll TO */
	eloop_register_timeout(NULL, transfer->timeout.tv_sec, transfer->timeout.tv_usec,
			       __usb_discard_trans_eloop, NULL, transfer);
}

static void usb_stop_trans_to(struct usb_transfer *transfer)
{
	eloop_cancel_timeout(NULL, __usb_discard_trans_eloop, NULL, transfer);
}

static void __free_check_timeout(void *e, void *data)
{
	struct usb_transfer *trans = (struct usb_transfer *)data;

	if (usb_free_check(trans)) {
		usb_finish_transfer(trans);
		usb_free_transfer(trans);
		return;
	}
	
	eloop_register_timeout(NULL, 1, 0, __free_check_timeout, NULL, trans);
	usb_log(USB_SHOW, "IO: __free_check, trans"/* id=%d", trans->id */);
}

/* transfer ending by ourself, not user */
static void usb_discard_transfer(struct usb_transfer *transfer , uint8_t type)
{
	usb_stop_trans_to(transfer);

	if (type & USB_TRANS_DISTYPE_CANCEL)
		usb_cancel_transfer(transfer);

	/* free resource */
	__free_check_timeout(NULL, transfer);
}

static int usb_finish_transfer(struct usb_transfer *transfer)
{
	struct usb_trans_params *param = transfer->user_data;

	switch (transfer->status) {
	case USB_TRANSFER_COMPLETED:
		param->ret = USB_SUCCESS;
		break;
	case USB_TRANSFER_TIME_OUT:
		param->ret = USB_ERROR_TIMEOUT;
		break;
	case USB_TRANSFER_CANCELLED:
		param->ret = USB_ERROR_CANCELLED;
		break;
	case USB_TRANSFER_STALL:
		param->ret = USB_ERROR_PIPE;
		break;
	case USB_TRANSFER_NO_DEVICE:
		param->ret = USB_ERROR_NO_DEVICE;
		break;
	case USB_TRANSFER_OVERFLOW:
		param->ret = USB_ERROR_OVERFLOW;
		break;
	case USB_TRANSFER_ERROR:
		param->ret = USB_ERROR_IO;
		break;
	default:
		param->ret = USB_ERROR_OTHER;
		break;
	}
	/* user must check param->ret */
	transfer->callback(transfer->user_data);
	return 0;
}

static int usb_cancel_transfer(struct usb_transfer *transfer)
{
	sys_ops->sys_cancel_transfer(transfer);
	return 0;
}

static int usb_free_check(struct usb_transfer *trans)
{
	if (sys_ops->free_check)
		return sys_ops->free_check(trans);
	else
		return 1;
}
static int usb_submit_transfer(struct usb_transfer *transfer)
{
	int r;
	
	/* return negative means fail and can free trans directly */
	r = sys_ops->sys_submit_transfer(transfer);
	if (r < 0) {
		transfer->status = USB_TRANSFER_ERROR;
		usb_free_transfer(transfer);
		return -1;
	}
	usb_start_trans_to(transfer);
	return 0;
}
