#include "ccid_priv.h"
#include "ccid_usb.h"

#define CCID_SERVICE_DESC	"Chip/smart card interface devices"

int ccid_logger = 0;
log_source_t ccid_log_source = {
	"ccid"
};

void ccid_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(ccid_logger, level, format, ap);
	va_end(ap);
}

#define DEBUG_BUF_SIZE ((256+20)*3+10)

static int __init ccid_log_init(void)
{
	ccid_logger = log_register_source(&ccid_log_source);
	return !ccid_logger;
}

static void __exit ccid_log_exit(void)
{
	log_unregister_source(ccid_logger);
}


ui_argument_t ccid_filename_args = {
	"filename",
	"reader name",
	NULL,
	UI_TYPE_STRING,

};

ui_argument_t ccid_reader_idx_args = {
	"reader_index",
	"reader index",
	NULL,
	UI_TYPE_STRING,

};

ui_schema_t ccid_schema[] = {
	{ UI_TYPE_CLASS, 
	  UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, 
	  NULL, 
	  NULL,
	  ".ccid", 
	  "ccid", 
	  CCID_SERVICE_DESC },
	
	{ UI_TYPE_NONE },
};

modlinkage int __init ccid_init(void)
{
	ccid_log_init();
	ccid_register_usb_driver();

	return 0;
}

modlinkage void __exit ccid_exit(void)
{
	ccid_unregister_usb_driver();
	ccid_log_exit();
}

subsys_initcall(ccid_init);
subsys_exitcall(ccid_exit);
