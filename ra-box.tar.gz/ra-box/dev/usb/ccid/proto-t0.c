#include "ccid_priv.h"
#include "ccid_usb.h"

int ccid_send_xfr_transfer_t0(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->handle->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		return ccid_usb_send_transfer(ccid_trans);
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}


int ccid_fill_xfr_cmd_t0(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->handle->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		return ccid_usb_fill_cmd(ccid_trans);
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}
