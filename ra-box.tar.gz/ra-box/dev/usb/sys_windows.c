#include "usb_priv.h"
#include <winioctl.h>
#include <setupapi.h>
#include "sys_windows.h"

#define USB_DEFAULT_TIMEOUT 5000
#define USB_DEVICE_NAME "\\\\.\\libusb0-"
#define USB_BUS_NAME "bus-0"
#define USB_MAX_DEVICES 256

struct win_transfer_priv {
	usb_intfc_t *dev_handle;
	usb_request_t req;
	char *bytes;
	int size;
	DWORD control_code;
	OVERLAPPED ol;

	int blocks;
};

const char *usb_win_error_to_string(void)
{
	static char tmp[512];

	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), 
		LANG_USER_DEFAULT, tmp, sizeof(tmp) - 1, NULL);

	return tmp;
}

int usb_win_error_to_errno(void)
{
	switch(GetLastError()) {
	case ERROR_SUCCESS:
		return 0;
	case ERROR_INVALID_PARAMETER:
		return EINVAL;
	case ERROR_SEM_TIMEOUT: 
	case ERROR_OPERATION_ABORTED:
		return ETIMEDOUT;
	case ERROR_NOT_ENOUGH_MEMORY:
		return ENOMEM;
	default:
		return EIO;
	}
}

static int win_usb_io_sync(HANDLE dev, unsigned int code,
			   void *in, int in_size,
			   void *out, int out_size, int *ret)
{
	OVERLAPPED ol;
	DWORD _ret;
	int bytes;

	memset(&ol, 0, sizeof(ol));  
	if (ret) *ret = 0;

	ol.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	if (!ol.hEvent)
		return FALSE;

	if (!DeviceIoControl(dev, code, in, in_size, out,
			     out_size, &bytes, &ol)) {
		if ((_ret = GetLastError()) != ERROR_IO_PENDING) {
			CloseHandle(ol.hEvent);
			return FALSE;
		}
	}

	if (GetOverlappedResult(dev, &ol, &_ret, TRUE)) {
		if (ret) *ret = (int)_ret;
		CloseHandle(ol.hEvent);
		return TRUE;
	}

	CloseHandle(ol.hEvent);
	return FALSE;
}

static int win_usb_control_msg(void *impl_info, int requesttype, int request,
                    int value, int idx, char *bytes, int size, int timeout)
{
	int read = 0;
	usb_request_t req;
	void *in = &req;
	int in_size = sizeof(usb_request_t);
	void *out = bytes;
	int out_size = size;
	int code;

	if(impl_info == INVALID_HANDLE_VALUE) {
		return -EINVAL;
	}

	req.timeout = timeout;

	/* windows doesn't support generic control messages, so it needs to be */
	/* split up */ 
	switch(requesttype & (0x03 << 5)) {
	case USB_REQUEST_TYPE_STANDARD:
		switch(request) {
		case USB_REQUEST_GET_STATUS: 
			req.status.recipient = requesttype & 0x1F;
			req.status.idx = idx;
			code = USB_IOCTL_GET_STATUS;
			break;
			
		case USB_REQUEST_CLEAR_FEATURE:
			req.feature.recipient = requesttype & 0x1F;
			req.feature.feature = value;
			req.feature.idx = idx;
			code = USB_IOCTL_CLEAR_FEATURE;
			break;
			
		case USB_REQUEST_SET_FEATURE:
			req.feature.recipient = requesttype & 0x1F;
			req.feature.feature = value;
			req.feature.idx = idx;
			code = USB_IOCTL_SET_FEATURE;
			break;

		case USB_REQUEST_GET_DESCRIPTOR:
			req.descriptor.recipient = requesttype & 0x1F;
			req.descriptor.type = (value >> 8) & 0xFF;
			req.descriptor.idx = value & 0xFF;
			req.descriptor.language_id = idx;
			code = USB_IOCTL_GET_DESCRIPTOR;
			break;
  
		case USB_REQUEST_SET_DESCRIPTOR:
			req.descriptor.recipient = requesttype & 0x1F;
			req.descriptor.type = (value >> 8) & 0xFF;
			req.descriptor.idx = value & 0xFF;
			req.descriptor.language_id = idx;
			code = USB_IOCTL_SET_DESCRIPTOR;
			break;
  
		case USB_REQUEST_GET_CONFIGURATION:
			code = USB_IOCTL_GET_CONFIGURATION;
			break;

		case USB_REQUEST_SET_CONFIGURATION:	  
			req.configuration.configuration = value;
			code = USB_IOCTL_SET_CONFIGURATION;
			break;

		case USB_REQUEST_GET_INTERFACE:
			req.intfc.intfc = idx;
			code = USB_IOCTL_GET_INTERFACE;	  
			break;

		case USB_REQUEST_SET_INTERFACE:
			req.intfc.intfc = idx;
			req.intfc.altsetting = value;
			code = USB_IOCTL_SET_INTERFACE;	  
			break;

		default:
			return -EINVAL;
		}
		break;

	case USB_REQUEST_TYPE_VENDOR:  
	case USB_REQUEST_TYPE_CLASS:
		req.vendor.type = (requesttype >> 5) & 0x03;
		req.vendor.recipient = requesttype & 0x1F;
		req.vendor.request = request;
		req.vendor.value = value;
		req.vendor.idx = idx;

		if(requesttype & 0x80)
			code = USB_IOCTL_VENDOR_READ;
		else
			code = USB_IOCTL_VENDOR_WRITE;
		break;

	case USB_REQUEST_TYPE_RESERVED:
	default:
		return -EINVAL;
	}

	/* out request? */
	if(!(requesttype & USB_ENDPOINT_IN)) {
		if(!(in = malloc(sizeof(usb_request_t) + size))) {
			return -ENOMEM;
		}

		memcpy(in, &req, sizeof(usb_request_t));
		memcpy((char *)in + sizeof(usb_request_t), bytes, size);
		in_size = sizeof(usb_request_t) + size;
		out = NULL; out_size = 0;
	}

	if(!win_usb_io_sync(impl_info, code, in, in_size, out, out_size, &read)) {
		if(!(requesttype & USB_ENDPOINT_IN)) {
			free(in);
		}
		return -1;
	}

	/* out request? */
	if(!(requesttype & USB_ENDPOINT_IN)) {
		free(in);
		return size;
	} else
		return read;
}

static int win_get_descriptor(void  *impl_info, uint8_t desc_type,
			      uint8_t desc_idx, uint8_t *out, size_t out_len)
{
	return win_usb_control_msg(impl_info, USB_ENDPOINT_IN, 
				   USB_REQUEST_GET_DESCRIPTOR, 
				   (desc_type << 8) + desc_idx, 0, 
				   out, out_len, USB_DEFAULT_TIMEOUT);
	
}

int win_device_init(usb_device_t *dev)
{
	int r;
	uint8_t dev_desc_idx, dev_desc[USB_DT_DEVICE_SIZE];
	uint8_t active_config;
	void *impl_info = INVALID_HANDLE_VALUE;

#if 0
	char *p, name[PATH_MAX];
	p = strstr(dev->filename, "/dev");
	if (!p) {
		strlcpy(name, _PATH_DEV, sizeof(name));
		if (strlast(name) != '/')
			strlcat(name, "/", sizeof(name));
		strlcat(name, dev->filename, sizeof(name));
	}
#endif
	impl_info = CreateFile(dev->filename, 0, 0, 
			       NULL, OPEN_EXISTING, 
			       FILE_FLAG_OVERLAPPED, NULL);
	if (impl_info == INVALID_HANDLE_VALUE)
		return USB_ERROR_IO;
	
	/* Get Device Descriptor*/
	dev->dev_desc = malloc(sizeof(struct usb_device_descriptor));
	if (!dev->dev_desc) {
		r = USB_ERROR_NO_MEM;
		goto err;
	}
	memset(dev->dev_desc, 0, sizeof(struct usb_device_descriptor));
	
	r = win_get_descriptor(impl_info, USB_DT_DEVICE, 0, dev_desc,
			       USB_DT_DEVICE_SIZE);
	if(r < USB_DT_DEVICE_SIZE) {
		r = USB_ERROR_OTHER;
		goto err;
	}
	usbi_parse_descriptor(dev_desc, "bbwbbbbwwwbbbb", dev->dev_desc, 1);

	if (dev->dev_desc->bNumConfigurations > USB_MAX_CONFIG ||
	    dev->dev_desc->bNumConfigurations < 1) {
		r = USB_ERROR_IO;
		goto err;
	}

	/*Get Configuration Descriptor*/
	dev->config_desc = malloc(dev->dev_desc->bNumConfigurations * 
				  sizeof(struct usb_config_descriptor));
	if (!dev->config_desc) {
		r = USB_ERROR_NO_MEM;
		goto err;
	}
	for (dev_desc_idx = 0; dev_desc_idx < dev->dev_desc->bNumConfigurations; dev_desc_idx++) {
		uint8_t tmp[8], *config_buf;
		struct usb_config_descriptor config;

		r = win_get_descriptor(impl_info, USB_DT_CONFIG, dev_desc_idx,	tmp, 8);
		if(r < 8) {
			r = USB_ERROR_OTHER;
			goto err;
		}

		usbi_parse_descriptor(tmp, "bbw",  &config, 1);
		config_buf = malloc(config.wTotalLength);
		if (!config_buf) {
			r = USB_ERROR_NO_MEM;
			goto err;
		}

		r = win_get_descriptor(impl_info, USB_DT_CONFIG, dev_desc_idx,
					config_buf, config.wTotalLength);
		if(r < config.wTotalLength) {
			r = USB_ERROR_OTHER;
			goto err;
		}
		usbi_parse_configuration(&dev->config_desc[dev_desc_idx], config_buf, 1);
		free(config_buf);
	}
	/*Get Active Configuration*/
	r = win_usb_control_msg(impl_info, USB_ENDPOINT_IN, 
				USB_REQUEST_GET_CONFIGURATION, 0, 0, 
				&active_config, 1, USB_DEFAULT_TIMEOUT);
	if(r != 1) {
		r = USB_ERROR_OTHER;
		goto err;
	}
	dev->active_config = active_config;

	CloseHandle(impl_info);
	return USB_SUCCESS;
err:
	if (dev->dev_desc) {
		free(dev->dev_desc);
		dev->dev_desc = NULL;
	}
	if (dev->config_desc) {
		free(dev->config_desc);
		dev->config_desc = NULL;
	}
	
	CloseHandle(impl_info);
	return r;
}

void win_device_release(struct usb_device *dev)
{
	if (dev->config_desc) {
		usbi_clear_configuration(dev->config_desc);
		free(dev->config_desc);
	}
	if (dev->dev_desc)
		free(dev->dev_desc);
}

int win_open(usb_intfc_t *dev_handle)
{
	if (dev_handle->impl_info != INVALID_HANDLE_VALUE &&
	    dev_handle->impl_info != NULL)
		return USB_SUCCESS;
	dev_handle->impl_info = INVALID_HANDLE_VALUE;

	dev_handle->impl_info = CreateFile(dev_handle->dev->filename, 0, 0, 
					   NULL, OPEN_EXISTING, 
					   FILE_FLAG_OVERLAPPED, NULL);
	if (dev_handle->impl_info == INVALID_HANDLE_VALUE) {
		return -ENOENT;
	}
	usb_log(USB_LOG_DEBUG, "DEV OPENED");

	/* only one reader now */
	dev_handle->fd = 1;

	return USB_SUCCESS;
}

static void win_close(usb_intfc_t *dev_handle)
{
	if (dev_handle->impl_info != INVALID_HANDLE_VALUE) {
		if (dev_handle->claimed) {
			usb_release_interface(dev_handle,
				dev_handle->cur_altsetting->bInterfaceNumber);
		}
		usb_log(USB_LOG_DEBUG, "DEV CLOSED");
		CloseHandle(dev_handle->impl_info);
		dev_handle->impl_info = INVALID_HANDLE_VALUE;
		dev_handle->claimed = 0;
	}

	dev_handle->fd = -1;
}

static int win_get_configuration(usb_intfc_t *dev_handle, unsigned int *config_idx)
{
	return USB_ERROR_NOT_SUPPORTED;	
}

static int win_set_configuration(usb_intfc_t *dev_handle,
		       unsigned int config_idx)
{
	usb_request_t req;

	if (dev_handle->impl_info == INVALID_HANDLE_VALUE) {
		return USB_ERROR_IO;
	}

	memset(&req, 0, sizeof(req));
	req.configuration.configuration = config_idx;
	req.timeout = USB_DEFAULT_TIMEOUT;

	if(!win_usb_io_sync(dev_handle->impl_info, USB_IOCTL_SET_CONFIGURATION, 
		&req, sizeof(usb_request_t), NULL, 0, NULL)) {
		return USB_ERROR_IO;
	}
	return USB_SUCCESS;
}

int win_claim_interface(usb_intfc_t *dev_handle)
{
	usb_request_t req;

	if (dev_handle->impl_info == INVALID_HANDLE_VALUE) {
		usb_log(USB_LOG_ERR, "usb_claim_interface: device not open");
		return -EINVAL;
	}

	memset(&req, 0, sizeof(req));
	req.intfc.intfc = dev_handle->cur_altsetting->bInterfaceNumber;

	if (!win_usb_io_sync(dev_handle->impl_info, USB_IOCTL_CLAIM_INTERFACE, 
			&req, sizeof(usb_request_t), NULL, 0, NULL)) {
		usb_log(USB_LOG_ERR, "could not claim intfc %d, ", 
			req.intfc.intfc );
		return -1;
	} 
	return 0;
}

int win_release_interface(usb_intfc_t *dev_handle)
{
	usb_request_t req;

	if (dev_handle->impl_info == INVALID_HANDLE_VALUE) {
		usb_log(USB_LOG_ERR, "usb_release_interface: device not open");
		return -EINVAL;
	}

	if(!dev_handle->dev->active_config) {
		usb_log(USB_LOG_ERR, "usb_release_interface: could not release intfc, "
			"invalid configuration %d", dev_handle->dev->active_config);
		return -EINVAL;
	}

	req.intfc.intfc = dev_handle->cur_altsetting->bInterfaceNumber;

	if(!win_usb_io_sync(dev_handle->impl_info, USB_IOCTL_RELEASE_INTERFACE, 
			&req, sizeof(usb_request_t), NULL, 0, NULL)) {
		usb_log(USB_LOG_ERR, "could not release intfc %d, ", 
			req.intfc.intfc);
		return -1;
	} 

	return 0;
}

static int win_cancel_transfer(struct usb_transfer *transfer)
{
	return 0;
}

static void win_simulate_linux_handle_cb(void *eloop_data, void *user_ctx)
{
	usb_intfc_t *dev_handle = user_ctx;
	int fd = dev_handle->fd;

	usbi_eloop_handle_cb(fd, NULL, dev_handle);
}

static int win_submit_control_transfer(struct usb_transfer *usb_trans)
{
	return USB_ERROR_NOT_SUPPORTED;
}

static int win_submit_bulk_transfer(struct usb_transfer *usb_trans)
{
	struct win_transfer_priv *tpriv = usb_trans->os_priv;
	int request, sbuf_len;
	uint8_t *p;

	memset(tpriv, 0, sizeof(*tpriv));

	tpriv->dev_handle = usb_trans->dev_handle;
	tpriv->req.endpoint.endpoint = usb_trans->endpoint;
	tpriv->req.endpoint.packet_size = 0;
	tpriv->control_code = USB_IOCTL_INTERRUPT_OR_BULK_WRITE;
	tpriv->ol.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	if (!tpriv->ol.hEvent) {
		return -usb_win_error_to_errno();
	}
	tpriv->blocks = 0;

	p = usb_trans->buffer;
	sbuf_len = usb_trans->length;
	do {
		request = (sbuf_len > USB_MAX_READ_WRITE) ? 
				USB_MAX_READ_WRITE : sbuf_len;

		tpriv->ol.Offset = 0;
		tpriv->ol.OffsetHigh = 0;
		tpriv->bytes = p;
		tpriv->size = request;

		ResetEvent(tpriv->ol.hEvent);

		if (!DeviceIoControl(tpriv->dev_handle->impl_info, 
			tpriv->control_code,
			&tpriv->req, sizeof(usb_request_t), 
			tpriv->bytes, 
			tpriv->size, NULL, &tpriv->ol)) {
			if (GetLastError() != ERROR_IO_PENDING) {
				return -usb_win_error_to_errno();
			}
		}
		p += request;
		sbuf_len -= request;
		tpriv->blocks++;

		eloop_register_timeout(NULL, 0, 1000,
				       win_simulate_linux_handle_cb,
				       NULL, usb_trans->dev_handle);

	} while (sbuf_len > 0);

	return 0;
}

static int win_submit_transfer(struct usb_transfer *usb_trans)
{
	switch(usb_trans->type) {
	case USB_TRANSFER_TYPE_CONTROL:
		return win_submit_control_transfer(usb_trans);
	case USB_TRANSFER_TYPE_BULK:
	case USB_TRANSFER_TYPE_INTERRUPT:
		return win_submit_bulk_transfer(usb_trans);
	case USB_TRANSFER_TYPE_ISOCHRONOUS:
		return USB_ERROR_NOT_SUPPORTED;
	default:
		return USB_ERROR_INVALID_PARAM;
	}
}

static int win_asyn_reap(usb_intfc_t *dev_handle, 
		     struct usb_transfer **otransfer)
{
	struct usb_transfer *usb_trans = NULL;
	struct win_transfer_priv *tpriv;
	unsigned long ret;

	list_for_each_entry(struct usb_transfer, usb_trans, 
		&dev_handle->transfer_list, link) {
		break;
	}
	BUG_ON(!usb_trans);
	tpriv = usb_trans->os_priv;	

	if(WaitForSingleObject(tpriv->ol.hEvent, 1000) == WAIT_TIMEOUT) {
		win_cancel_transfer(usb_trans);
		return -ETIMEDOUT;
	}

	if (!GetOverlappedResult(tpriv->dev_handle->impl_info,
				 &tpriv->ol, &ret, TRUE)) {
		return -usb_win_error_to_errno();
	}
	usb_trans->actual_length += ret;

	tpriv->blocks--;
	if (tpriv->blocks == 0) {
		usb_trans->status = USB_TRANSFER_COMPLETED;
	} else {
		usb_trans->status = USB_TRANSFER_REAPING;
	}

	*otransfer = usb_trans;

	return USB_SUCCESS;
}

static int win_ioctl(usb_intfc_t *dev_handle, int intfc_no, 
		     int ioctl_code, void *data)
{
	/* TODO: */
	return USB_ERROR_NOT_SUPPORTED;
}


struct sys_device_ops win_device_ops = {
	win_device_init,
	win_device_release,
	win_open,
	win_close,
	win_get_configuration,
	win_set_configuration,
	win_claim_interface,
	win_release_interface,
	win_submit_transfer,
	win_asyn_reap,
	win_cancel_transfer,
	win_ioctl,
	NULL,	/* force free */
	NULL,	/* free check */
	0,
	sizeof(struct win_transfer_priv),
};
