#ifndef __VTSS_PRIV_H_INCLUDE__
#define __VTSS_PRIV_H_INCLUDE__

#include <logger.h>
#include <vtss.h>
#include <module.h>
#include <netsvc.h>
#include <udev.h>
#include <service.h>
#include <uiserv.h>
#include <panic.h>
#include <eloop.h>
#include <netphy.h>
#include "vtss_switch.h"
#include "vtss_phy.h"

/* Standard headers */
#include <string.h>
#include <linux/vitgenio.h>
#include <linux/ioctl.h> /* ioctl() */

#define VTSS_LOG_CRIT		LOG_EMERG
#define VTSS_LOG_FAIL		LOG_CRIT
#define VTSS_LOG_ERR		LOG_ERR
#define VTSS_LOG_WARN		LOG_WARNING
#define VTSS_LOG_INFO		LOG_INFO
#define VTSS_LOG_DEBUG		LOG_DEBUG

void vtss_log(int level, const char *format, ...);

#include "vtss_cil.h"

#include <vtss_auth.h>
#include <vtss_qos.h>
#include <vtss_acl.h>
#include <vtss_pvlan.h>
#include <vtss_cpu.h>
#include <vtss_led.h>

/* API private headers */
#include "vtss_sparx_reg.h"
#include "vtss_heathrow.h"

extern vtss_config_t vtss_main_config;

struct vtss_port {
	uint phy_addr;       /* Map from vtss_port_no_t to phy add */
	uint miim_controller;/* Map vtss_port to miim controller */
	BOOL unused; /* Port is unused */

	vtss_port_setup_t setup;
	/* port status */
	vtss_port_status_t port_status;
	/* port configuration */
	vtss_port_conf_t port_conf;

	BOOL port_fc_rx; /* Rx flow control (obey pause) */
	BOOL port_fc_tx; /* Tx flow control (gen. pause) */
	BOOL mirror_ingress;
	BOOL mirror_egress;

	int stp_state;

	/* --- Other state --- */
	ulong tx_packets;

	BOOL port_poll;
};

struct vtss_filter_db {
	vtss_mac_table_status_t  mac_status_appl; /* Application status */
};

struct vtss_bridge {
	BOOL jumbo;
	vtss_port_no_t mirror_port;
	struct vtss_filter_db filter_db;
};

/* Structure holding all the state information */
typedef struct {
	/* --- Port state --- */
	vtss_port_map_t          port_map;
	vtss_port_setup_t        setup[VTSS_PORT_EXT_ARRAY_SIZE];   /* Written by vtss_port_setup() only. */
	BOOL                     port_fc_rx[VTSS_PORT_ARRAY_SIZE]; /* Rx flow control (obey pause) */
	BOOL                     port_fc_tx[VTSS_PORT_ARRAY_SIZE]; /* Tx flow control (gen. pause) */
	BOOL                     jumbo;
	vtss_chip_counters_t     port_last_counters[VTSS_PORT_EXT_ARRAY_SIZE];/* Last chip counters */
	vtss_port_big_counters_t poag_big_counters[VTSS_POAG_ARRAY_SIZE]; /* Accumulated counters */
	
	/* --- L2 state --- */
	vtss_pgid_entry_t        pgid_table[VTSS_PGID_ARRAY_SIZE];
	vtss_pgid_no_t           pgid_end;  /* End of PGID table */
	vtss_poag_no_t           port_poag_no[VTSS_PORT_ARRAY_SIZE]; /* Aggregation setup */
	BOOL                     aggr_member[VTSS_PORT_ARRAY_SIZE];  /* Aggregation mask 0 */
	vtss_vlan_entry_t        vlan_table[VTSS_VIDS];
	vtss_vlan_port_mode_t    vlan_port_table[VTSS_PORT_ARRAY_SIZE];
	vtss_mac_table_status_t  mac_status_appl; /* Application status */
	int		         stp_state[VTSS_PORT_ARRAY_SIZE];
	vtss_mstp_entry_t        mstp_table[VTSS_MSTI_ARRAY_SIZE];
	vtss_port_no_t           mirror_port;
	BOOL                     mirror_ingress[VTSS_PORT_ARRAY_SIZE];
	BOOL                     mirror_egress[VTSS_PORT_ARRAY_SIZE];
	
	/* --- Other state --- */
	ulong                    tx_packets[VTSS_PORT_ARRAY_SIZE];

	/* port status */
	vtss_port_status_t port_status[VTSS_PORT_ARRAY_SIZE];
	/* port configuration */
	vtss_port_conf_t port_conf[VTSS_PORT_ARRAY_SIZE];
	BOOL port_poll[VTSS_PORT_ARRAY_SIZE];
} vtss_mac_state_t;

/* ================================================================= *
 * lowest IO
 * ================================================================= */
void vtss_io_start(void);
void vtss_io_stop(void);
int vtss_io_pi_rd(uint block, uint subblock, const uint reg, ulong * const value);
int vtss_io_pi_wr(uint block, uint subblock, const uint reg, const ulong value);

/* ================================================================= *
 * optimize operation
 * ================================================================= */
int vtss_phy_optimize_1sec(const vtss_port_no_t port_no);
int vtss_optimize_1sec(void);
int vtss_ll_optimize_1sec(void);

/* ================================================================= *
 * port/aggregation operations
 * ================================================================= */
int vtss_poag_start(void);

/* ================================================================= *
 * mirroring operations
 * ================================================================= */
int vtss_mirror_start(void);

/* ================================================================= *
 * VLAN operations
 * ================================================================= */
int vtss_vlan_reset(void);
int vtss_vlan_start(void);

BOOL vtss_pgid_member(vtss_pgid_no_t pgid_no, vtss_port_no_t port);

/* ================================================================= *
 * internal states
 * ================================================================= */
extern vtss_mac_state_t vtss_mac_state;
extern vtss_phy_state_t vtss_phy_state;

/* Update source, destination and aggregation masks */
int vtss_update_masks(BOOL src_update, BOOL dest_update, BOOL aggr_update);

int vtss_appl_start(void);
void vtss_appl_stop(void);
void vtss_mac_age_start(void);
void vtss_mac_age_stop(void);

#endif /* __VTSS_PRIV_H_INCLUDE__ */
