/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.

*/


#ifndef __VTSS_GROCX_H_INCLUDE__
#define __VTSS_GROCX_H_INCLUDE__

#ifdef CONFIG_VTSS_GROCX

#include <linux/sockios.h>
#include <linux/star_switch_api.h>

/* Port configuration */
typedef struct {
	BOOL enable;          /* Admin enable/disable */
	BOOL autoneg;         /* Auto negotiation */
	int speed;           /* Forced port speed */
	BOOL fdx;             /* Forced duplex mode */
	BOOL flow_control;    /* Flow control */
	uint maxframelength;  /* Maximum frame length */
} vtss_grocx_port_conf_t;

int vtss_grocx_port_setup(const vtss_port_no_t port_no,
			  const vtss_grocx_port_conf_t * const setup);
int vtss_grocx_router_mac1_control(vtss_grx_mac1_control_t * mac1_control);

#endif

#endif /* __VTSS_GROCX_H_INCLUDE__ */
