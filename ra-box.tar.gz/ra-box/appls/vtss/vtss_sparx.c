/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_sparx.c,v 1.58 2008-12-29 04:40:53 zhenglv Exp $
 $Revision: 1.58 $

*/

#include "vtss_priv.h"
#include "vtss_heathrow.h"

/* ================================================================= *
 *  Port MAC constants and types
 * ================================================================= */

/* Convert from vtss_port_no list to chip port bitfield, */
ulong vtss_port_array2mask(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	vtss_port_no_t port_no;
	ulong bitfield = 0;
	
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		if (member[port_no]) {
			if (vtss_mac_state.port_map.vtss_port_unused[port_no]) {
				vtss_log(VTSS_LOG_ERR,
					 "SPARX: unmapped port enabled, port=%d",
					 port_no);
			} else {
				bitfield |= (1 << port_no);
			}
		}
	}
	return bitfield;
}

/* Convert from vtss_pgid_no to destination index on chip */
uint ht_pgid2chip(const vtss_pgid_no_t pgid_no)
{
	if (pgid_no < VTSS_PGID_UNICAST_END) {
		return pgid_no - 1;
	} else {
		return pgid_no-VTSS_PGID_UNICAST_END+VTSS_CHIP_PORTS;
	}
}

/* Convert from destination index on chip to vtss_pgid_no */
vtss_pgid_no_t ht_chip2pgid(const uint chip_pgid)
{
	if (chip_pgid < VTSS_CHIP_PORTS) {
		return chip_pgid + 1;
	} else {
		return VTSS_PGID_UNICAST_END+chip_pgid-VTSS_CHIP_PORTS;
	}
}

/* ================================================================= *
 * port queues
 * ================================================================= */
static int ht_port_queue_enable(vtss_port_no_t port_no, BOOL enable) 
{
	vtss_log(VTSS_LOG_DEBUG,
		 "SPARX: port on chip enable, port_on_chip=%d, enable=%d",
		 port_no, enable);
	/* Enable/disable Arbiter discard */
	HT_WRF(ARBITER, 0, ARBDISC, port_no, 0x1, enable ? 0 : 1);
	/* Enable/disable MAC Rx */
	HT_WRF(PORT, port_no, MAC_CFG, 16, 0x1, enable ? 1 : 0);
	/* Enable/disable MAC Tx */
	HT_WRF(PORT, port_no, MAC_CFG, 28, 0x1, enable ? 1 : 0);
	return 0;
}

/* Set STP learn mode */
static int ht_port_learn_set(vtss_port_no_t port_no)
{
	int stp_state = vtss_mac_state.stp_state[port_no];
	BOOL learn;
	
	/* Setup STP learning state */
	learn = (stp_state == VTSS_STP_STATE_LEARNING ||
		 stp_state == VTSS_STP_STATE_FORWARDING ||
		 stp_state == VTSS_STP_STATE_ENABLED);
	
	HT_WRF(ANALYZER, 0, LERNMASK, port_no, 0x1, learn ? 1 : 0);
	return 0;
}

/* Enable or disable and flush port queue systems */
int vtss_ll_port_queue_enable(vtss_port_no_t port_no, BOOL enable)
{
	/* Enable/disable queues */
	VTSS_RC(ht_port_queue_enable(port_no, enable));
	return ht_port_learn_set(port_no);
}

/* Setup water marks, drop levels, etc for port */
int vtss_ll_port_queue_setup(vtss_port_no_t port_no)
{
	vtss_port_setup_t *setup = &vtss_mac_state.setup[port_no];
	uchar             *mac;
	BOOL              zero_pause_enable;
	ushort            pause_value;
	BOOL              wfq = 0;
	enum {
		VTSS_NORM_SQ_DROP,
		VTSS_NORM_WFQ_DROP,
		VTSS_JUMBO_SQ_DROP,
		VTSS_JUMBO_WFQ_DROP,
		VTSS_NORM_SQ_FC,
		/* not used: VTSS_NORM_WFQ_FC, */
		VTSS_JUMBO_SQ_FC
		/* not used: VTSS_JUMBO_WFQ_FC */
	} mode;
	
	wfq = vtss_qos_get_wfq();
	
	if (setup->flowcontrol.generate) {
		/* Flow control mode */
		if (setup->maxframelength<=VTSS_MAXFRAMELENGTH_TAGGED) {
			mode = VTSS_NORM_SQ_FC;
		} else {
			mode = VTSS_JUMBO_SQ_FC;
		}
	} else {
		/* Drop mode */
		if (setup->maxframelength<=VTSS_MAXFRAMELENGTH_TAGGED) {
			mode = (wfq ? VTSS_NORM_WFQ_DROP : VTSS_NORM_SQ_DROP);
		} else {
			mode = (wfq ? VTSS_JUMBO_WFQ_DROP : VTSS_JUMBO_SQ_DROP);
		}
	}
	
	switch (mode) {
	case VTSS_NORM_SQ_DROP: 
	case VTSS_JUMBO_SQ_DROP: 
		zero_pause_enable = VTSS_NORM_4S_DROP_ZEROPAUSE; 
		pause_value = VTSS_NORM_4S_DROP_PAUSEVALUE; 
		break;
	case VTSS_NORM_WFQ_DROP: 
	case VTSS_JUMBO_WFQ_DROP: 
		zero_pause_enable = VTSS_NORM_4W_DROP_ZEROPAUSE; 
		pause_value = VTSS_NORM_4W_DROP_PAUSEVALUE; 
		break;
	case VTSS_NORM_SQ_FC:   
	case VTSS_JUMBO_SQ_FC:   
		zero_pause_enable = VTSS_NORM_4S_FC_ZEROPAUSE;   
		pause_value = VTSS_NORM_4S_FC_PAUSEVALUE;   
		break;
	default:
		vtss_log(VTSS_LOG_ERR,
			 "SPARX: unknown mode, mode=%d", mode);
		zero_pause_enable = 0;
		pause_value = 0;
		break;
	}
	
	/* Setup flow control registers */
	mac = &setup->flowcontrol.smac.addr[0];
	HT_WR(PORT, port_no, FCMACHI, (mac[0]<<16) | (mac[1]<<8) | mac[2]);
	HT_WR(PORT, port_no, FCMACLO, (mac[3]<<16) | (mac[4]<<8) | mac[5]);
	HT_WR(PORT, port_no, FCCONF,
	      ((zero_pause_enable ? 1 : 0)<<17) | 
	      ((setup->flowcontrol.obey ? 1 : 0)<<16) | 
	      (pause_value<<0));
	
	{
		ulong mcnf = 0, ewm = 0, iwm[6];
		uint  i;

#define MCNF(mode) \
	((VTSS_NORM_##mode##_IMIN<<16) | \
	 (VTSS_NORM_##mode##_EMIN<<8) | \
	 (VTSS_NORM_##mode##_EARLY_TX<<1))

#define EWM(mode) \
	((VTSS_NORM_##mode##_EMAX3<<24) | \
	 (VTSS_NORM_##mode##_EMAX2<<16) | \
	 (VTSS_NORM_##mode##_EMAX1<<8) | \
	 (VTSS_NORM_##mode##_EMAX0<<0))

#define IWM(mode, i) \
	((VTSS_NORM_##mode##_LOWONLY_##i<<18) | \
	 (VTSS_NORM_##mode##_QMASK_##i<<13) | \
	 (VTSS_NORM_##mode##_ACTION_##i<<11) | \
	 (VTSS_NORM_##mode##_CHKMIN_##i<<10) | \
	 (VTSS_NORM_##mode##_CMPWITH_##i<<8) | \
	 (VTSS_NORM_##mode##_LEVEL_##i<<0))
		
		switch (mode) {
		case VTSS_NORM_SQ_DROP: 
		case VTSS_JUMBO_SQ_DROP: 
			mcnf = MCNF(4S_DROP);
			ewm = EWM(4S_DROP);
			iwm[0] = IWM(4S_DROP, 0);
			iwm[1] = IWM(4S_DROP, 1);
			iwm[2] = IWM(4S_DROP, 2);
			iwm[3] = IWM(4S_DROP, 3);
			iwm[4] = IWM(4S_DROP, 4);
			iwm[5] = IWM(4S_DROP, 5);
			if (vtss_qos_policer_port(port_no) != VTSS_BITRATE_FEATURE_DISABLED) {
				/* Special settings if policer enabled */
				iwm[0] = ((iwm[0] & 0xffffffe0) | (VTSS_NORM_4S_POLICER_LEVEL_0<<0));
				iwm[5] = ((iwm[5] & 0xffffffe0) | (VTSS_NORM_4S_POLICER_LEVEL_5<<0));  
			}
			break;
		case VTSS_NORM_WFQ_DROP: 
		case VTSS_JUMBO_WFQ_DROP: 
			mcnf = MCNF(4W_DROP);
			ewm = EWM(4W_DROP);
			iwm[0] = IWM(4W_DROP, 0);
			iwm[1] = IWM(4W_DROP, 1);
			iwm[2] = IWM(4W_DROP, 2);
			iwm[3] = IWM(4W_DROP, 3);
			iwm[4] = IWM(4W_DROP, 4);
			iwm[5] = IWM(4W_DROP, 5);
			if (vtss_qos_policer_port(port_no) != VTSS_BITRATE_FEATURE_DISABLED) {
				/* Special settings if policer enabled */
				iwm[0] = ((iwm[0] & 0xffffffe0) | (VTSS_NORM_4W_POLICER_LEVEL_0<<0));
				iwm[5] = ((iwm[5] & 0xffffffe0) | (VTSS_NORM_4W_POLICER_LEVEL_5<<0));  
			}
			break;
		case VTSS_NORM_SQ_FC:   
		case VTSS_JUMBO_SQ_FC:   
			mcnf = MCNF(4S_FC);
			ewm = EWM(4S_FC);
			iwm[0] = IWM(4S_FC, 0);
			iwm[1] = IWM(4S_FC, 1);
			iwm[2] = IWM(4S_FC, 2);
			iwm[3] = IWM(4S_FC, 3);
			iwm[4] = IWM(4S_FC, 4);
			iwm[5] = IWM(4S_FC, 5);
			break;
		default:
			vtss_log(VTSS_LOG_ERR,
				 "SPARX: unknown mode, mode=%d", mode);
			return VTSS_UNSPECIFIED_ERROR;
		}
		
#ifndef CONFIG_VTSS_GROCX
		if (setup->interface_mode.speed == VTSS_SPEED_10M && setup->fdx == 0) {
			/* Special settings for 10 Mbps half duplex operation */
			mcnf = ((mcnf & ((0x1f<<16) | (0xf<<1))) | (VTSS_NORM_10_HDX_EMIN<<8));
			ewm = EWM(10_HDX);
		}
#endif
		
		/* Setup queue system drop levels and water marks */
		HT_WR(PORT, port_no, Q_MISC_CONF, mcnf);
		HT_WR(PORT, port_no, Q_EGRESS_WM, ewm);
		
		/* Ingress watermarks */
		for (i = 0; i < 6; i++) {
			HT_WR(PORT, port_no, Q_INGRESS_WM + i, iwm[i]);
		}
	}
	return 0;
}

/* ================================================================= *
 * port MAC
 * ================================================================= */
#define VTSS_ARBITER_WAIT_MAXRETRIES 1000000

/* Reset the MAC and setup the port, watermarks etc. */
static int ht_port_setup(vtss_port_no_t port_no,
			 const vtss_port_setup_t * setup)
{
	ulong macconf, value;
	ulong macconf_speedbits;
	int tx_clock_select;
	int if_type = setup->interface_mode.interface_type;
	BOOL if_loopback = (if_type == VTSS_PORT_INTERFACE_LOOPBACK);
	vtss_frame_gaps_t gaps;
	uint hdx_late_col_pos;
	BOOL powerdown = MAKEBOOL01(setup->powerdown);
	int speed = setup->interface_mode.speed;
	ulong aggr_masks[VTSS_ACS];
	vtss_ac_no_t ac;
	BOOL fifo_not_empty = 1;
	uint fifo_empty_retries = 0;
	
	/* Determine interframe gaps and default clock selection based on speed only */
	gaps.hdx_gap_1   = 0;
	gaps.hdx_gap_2   = 0;
	gaps.fdx_gap     = 0;
	hdx_late_col_pos = 0;
	
	switch (speed) {
	case VTSS_SPEED_10M:
	case VTSS_SPEED_100M:
		tx_clock_select = (speed == VTSS_SPEED_10M ? HT_TX_CLOCK_10M : HT_TX_CLOCK_100M);
		gaps.hdx_gap_1   = 6;
		gaps.hdx_gap_2   = 8;
		gaps.fdx_gap     = 17;
		hdx_late_col_pos = 2;
		break;
	case VTSS_SPEED_1G:
		tx_clock_select = HT_TX_CLOCK_GIGA;
		gaps.fdx_gap     = 6;
		break;
	default:
		vtss_log(VTSS_LOG_ERR,
			 "SPARX: illegal speed, port=%d", port_no);
		return VTSS_INVALID_PARAMETER;
	}
	
	/* Check interface type and determine clock selection */
	switch (if_type) {
	case VTSS_PORT_INTERFACE_NO_CONNECTION:
		tx_clock_select = HT_TX_CLOCK_OFF;
		break;
#ifdef CONFIG_VTSS_GROCX
	case VTSS_PORT_INTERFACE_MII:
		if (speed == VTSS_SPEED_1G) {
			vtss_log(VTSS_LOG_ERR,
				 "SPARX: illegal speed, port=%d", port_no);
			return VTSS_INVALID_PARAMETER;
		}
		if (port_no != 5) /* MII on port 5 only */
			return VTSS_INVALID_PARAMETER;
		tx_clock_select = HT_TX_CLOCK_MISC;
		break;
	case VTSS_PORT_INTERFACE_GMII:
		if (port_no != 5) /* GMII on port 5 only */
			return VTSS_INVALID_PARAMETER;
		if (speed != VTSS_SPEED_1G)
			tx_clock_select = HT_TX_CLOCK_MISC;
		break;
	case VTSS_PORT_INTERFACE_RGMII:
		if (port_no < 5) /* RGMII on port 5 and 6 only */
			return VTSS_INVALID_PARAMETER;
		break;
#endif
	case VTSS_PORT_INTERFACE_INTERNAL:
		tx_clock_select = HT_TX_CLOCK_MISC;
#ifdef CONFIG_VTSS_GROCX
		if (port_no == 4 || port_no == 6)
			tx_clock_select = HT_TX_CLOCK_GIGA;
#else
		return VTSS_INVALID_PARAMETER;
#endif
		break;
	case VTSS_PORT_INTERFACE_LOOPBACK:
		if (tx_clock_select == HT_TX_CLOCK_OFF) { /* Not 10/100/1000 */
			vtss_log(VTSS_LOG_ERR,
				 "SPARX: illegal speed, port=%d", port_no);
			return VTSS_INVALID_PARAMETER;
		}
		break;
	default:
		vtss_log(VTSS_LOG_ERR,
			 "SPARX: illegal speed, port=%d", port_no);
		return VTSS_INVALID_PARAMETER;
	}
	
	/* Read and remove port from aggregation masks to avoid forwarding to port */
	for (ac = VTSS_AC_START; ac < VTSS_AC_END; ac++) {
		HT_RD(ANALYZER, 0, AGGRMSKS + ac - VTSS_AC_START, &value);
		aggr_masks[ac - VTSS_AC_START] = value;
		HT_WR(ANALYZER, 0, AGGRMSKS + ac - VTSS_AC_START,
		      value & ~(1<<port_no));
	}
	
	/* Setup half duplex gaps */
	if (setup->frame_gaps.hdx_gap_1 != VTSS_FRAME_GAP_DEFAULT)
		gaps.hdx_gap_1 = setup->frame_gaps.hdx_gap_1;
	if (setup->frame_gaps.hdx_gap_2 != VTSS_FRAME_GAP_DEFAULT)
		gaps.hdx_gap_2 = setup->frame_gaps.hdx_gap_2;
	if (setup->frame_gaps.fdx_gap != VTSS_FRAME_GAP_DEFAULT)
		gaps.fdx_gap = setup->frame_gaps.fdx_gap;
	HT_WR(PORT, port_no, MACHDXGAP,
	      (7<<16) |
	      (8<<12) | 
	      (hdx_late_col_pos<<8) |
	      (gaps.hdx_gap_2<<4) |
	      (gaps.hdx_gap_1<<0));
	
	macconf = (((setup->fdx ? 1 : 0)<<18) |
		  (gaps.fdx_gap<<6));
	
	macconf |= ((setup->flowcontrol.smac.addr[5]<<19) |
                   ((setup->length_check == VTSS_LENGTH_TAG_DOUBLE ? 1 : 0)<<15) | 
                   ((setup->length_check == VTSS_LENGTH_TAG_NONE ? 0 : 1)<<14));
	macconf_speedbits = (((speed == VTSS_SPEED_10M || speed == VTSS_SPEED_100M ? 0 : 1)<<17) |
		            (tx_clock_select<<0));
	
		/* We need to make sure that the FIFO is not receiving frames
	(from the bus) when it's coming out of reset  */
	
	while(fifo_not_empty) {
		/* Hold MAC Reset */
		value = (macconf | (1<<29) | (1<<27) | (1<<5) | (1<<4));
		/* Don't reset PCS, because that would mess up autonegotiation, 
		if this function is called because autoneg completed */
		value |= ((0<<3) | (0<<2));
		value |= macconf_speedbits;
		HT_WR(PORT, port_no, MAC_CFG, value);
		
		/* Set Arbiter to not discard frames from the port */
		HT_WRF(ARBITER, 0, ARBDISC, port_no, 0x1, 0);
		
		/* Release MAC from Reset and set Seed_Load */
		value = (macconf | (0<<29) | (1<<27) | (0<<5) | (0<<4) | macconf_speedbits);
		value |= ((0<<3) | (0<<2));
		
		HT_WR(PORT, port_no, MAC_CFG, value);
		
		VTSS_NSLEEP(1000);
		/* Clear Seed_Load bit */
		HT_WR(PORT, port_no, MAC_CFG, value & ~(1<<27));
		
		HT_RD(PORT, port_no, FREEPOOL, &value);
		fifo_not_empty = 0;
		if ((value & 0xffff) != 0) {
			/*       vtss_log(VTSS_LOG_ERR, "SPARX: rreepool is not empty after reset:0x%x.",value));  */
			fifo_not_empty = 1;
			fifo_empty_retries++;
			if (fifo_empty_retries > 10)
				break;            
			VTSS_MSLEEP(100);
		} 
	}
	
	/* Restore aggregation masks */
	for (ac = VTSS_AC_START; ac < VTSS_AC_END; ac++) {
		HT_WR(ANALYZER, 0, AGGRMSKS + ac - VTSS_AC_START, aggr_masks[ac - VTSS_AC_START]);
	}
	
	/* Set Advanced Port Mode */
#ifdef CONFIG_VTSS_GROCX
	value = (((setup->exc_col_cont ? 1 : 0)<<6) | /* EXC_COL_CONT */
		((port_no == 4 || if_type == VTSS_PORT_INTERFACE_GMII ? 1 : 0)<<4) | /* INVERT_GTX */
		((port_no > 3 ? 1 : 0)<<3) |    /* ENABLE_GTX */
		((if_type == VTSS_PORT_INTERFACE_RGMII ? 1 : 0)<<2) |    /* DDR_MODE */
		((port_no > 3 ? 1 : 0)<<1) |    /* INV_RXCLK */
		((if_loopback ? 1 : 0)<<0));         /* HOST_LOOPBACK */
#endif
	HT_WR(PORT, port_no, ADVPORTM, value);
	
	if (powerdown) {
		/* Power down MAC */
		value = ((1<<5) | (1<<4));
		value |= ((1<<3) | (1<<2));
		HT_WRM(PORT, port_no, MAC_CFG, value, value);
	}
	
	{
		uint maxlen = setup->maxframelength;
		HT_WR(PORT, port_no, MAXLEN, maxlen);
	}
	return vtss_ll_port_queue_setup(port_no);
}

/* Configure port into gmii modes */
int vtss_ll_port_speed_mode_gmii(vtss_port_no_t port_no,
				 const vtss_port_setup_t * setup)
{
	uint  wait_attempt;
	ulong value;
	BOOL  empty;
	
#ifdef VTSS_FEATURE_EXC_COL_CONT
	{
		vtss_port_no_t port;
		vtss_port_setup_t *ps;
		
		value = HT_TIMECMP_DEFAULT;
		/* Count number of half duplex ports with excessive
		 * collision continuation enabled and setup frame aging
		 * accordingly
		 */
		for (port = VTSS_PORT_NO_START;
		     port < VTSS_PORT_NO_END; port++) {
			ps = &vtss_mac_state.setup[port];
			if (ps->exc_col_cont && !ps->fdx) {
				value = 0; /* Frame aging disabled */
				break; 
			}
		}
		HT_WR(SYSTEM, 0, TIMECMP, value);
	}
#endif
	/* Discard frames from the port, Disable RX and Drop
	 * everything in the FIFOs
	 */
	VTSS_RC(ht_port_queue_enable(port_no, 0));
	
	/* Wait until Arbiter port empty */
	for (wait_attempt = 0;
	     wait_attempt < VTSS_ARBITER_WAIT_MAXRETRIES; wait_attempt++) {
		HT_RD(ARBITER, 0, ARBEMPTY, &value);
		if (value & (1<<port_no))
			break;
	}
	if (wait_attempt>=VTSS_ARBITER_WAIT_MAXRETRIES) {
		/* Timeout */
		vtss_port_no_t port; /* Other ports */
		
		vtss_log(VTSS_LOG_DEBUG,
			 "SPARX: timeout - arbiter does not empty port, reset and setup all ports, port=%d",
			 port_no);
		
		/* Discard frames from all ports, Disable RX and Drop everything in the FIFOs */
		for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
			if (port == port_no) continue;
			VTSS_RC(ht_port_queue_enable(port, 0));
		}
		/* Wait until Arbiter empty for all ports */
		for (wait_attempt=0; wait_attempt<VTSS_ARBITER_WAIT_MAXRETRIES; wait_attempt++) {
			VTSS_RC(ht_arbiter_empty_allports(&empty));
			if (empty)
				break;
		}
		if (wait_attempt>=VTSS_ARBITER_WAIT_MAXRETRIES) {
			/* Timeout */
			vtss_log(VTSS_LOG_ERR,
				 "SPARX: timeout - Arbiter does not empty all ports");
			return VTSS_FATAL_ERROR;
		}
		
		/* Reset and setup all ports, watermarks etc. */
		for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
			if (port == port_no) continue;
			VTSS_RC(ht_port_setup(port, &vtss_mac_state.setup[port]));
			VTSS_RC(ht_port_queue_enable(port, 1));
		}
	}
	
	/* Reset and setup the port, watermarks etc. */
	VTSS_RC(ht_port_setup(port_no, setup));
	
	VTSS_RC(ht_port_queue_enable(port_no, 1));
	
	/* Count number of ports in flow control and setup HOLB */
	value = 0;
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		if (vtss_mac_state.setup[port_no].flowcontrol.obey ||
			vtss_mac_state.setup[port_no].flowcontrol.generate)
			value++;
	}
	HT_WR(ARBITER, 0, ARBHOLBPENAB, value ? 0 : VTSS_CHIP_PORTMASK);
	return 0;
}

#if defined(VTSS_FEATURE_QOS_POLICER_MC_SWITCH) && \
    defined(VTSS_FEATURE_QOS_POLICER_BC_SWITCH)
/* Calculate packet rate register field */
ulong calc_packet_rate(vtss_packet_rate_t rate, ulong *unit)
{
	ulong value;
	
	ulong max;
	/* If the rate is greater than 1000 pps, the unit is kpps */
	max = (rate >= 1000 ? (rate/1000) : rate);
	*unit = (rate >= 1000 ? 0 : 1);
	for (value = 15; value != 0; value--) {
		if (max >= (ulong)(1<<value))
			break;
	}
	return value;
}
#endif

/* Set switch QoS setup */
int vtss_ll_qos_setup_set(const vtss_qos_setup_t *qos)
{
#ifdef VTSS_FEATURE_QOS_DSCP_REMARK
	{
		ulong i, low = 0, high = 0;
		
		for (i = 0; i < 64; i++) {
			if (qos->dscp_remark[i]) {
				if (i < 32)
					low |= (1<<i);
				else
					high |= (1<<(i-32));
			}
		}
		HT_WR(ANALYZER, 0, DSCPSELLOW, low);
		HT_WR(ANALYZER, 0, DSCPSELHIGH, high);
	}
#endif
	
#if defined(VTSS_FEATURE_QOS_POLICER_MC_SWITCH) && \
    defined(VTSS_FEATURE_QOS_POLICER_BC_SWITCH)
	{
		ulong unit_bc, unit_mc, unit_uc;
		
		HT_WRF(ANALYZER, 0, STORMLIMIT, 28, 0xf, 6); /* Burst of 64 frames allowed */
		HT_WRF(ANALYZER, 0, STORMLIMIT, 8, 0xf, calc_packet_rate(qos->policer_bc, &unit_bc));
		HT_WRF(ANALYZER, 0, STORMLIMIT, 4, 0xf, calc_packet_rate(qos->policer_mc, &unit_mc));
		HT_WRF(ANALYZER, 0, STORMLIMIT, 0, 0xf, calc_packet_rate(qos->policer_uc, &unit_uc));
		HT_WRF(ANALYZER, 0, STORMLIMIT_ENA, 2, 0x1,
		       MAKEBOOL01(qos->policer_bc != VTSS_PACKET_RATE_DISABLED));
		HT_WRF(ANALYZER, 0, STORMLIMIT_ENA, 1, 0x1,
		       MAKEBOOL01(qos->policer_mc != VTSS_PACKET_RATE_DISABLED));
		HT_WRF(ANALYZER, 0, STORMLIMIT_ENA, 0, 0x1,
		       MAKEBOOL01(qos->policer_uc != VTSS_PACKET_RATE_DISABLED));
		HT_WRF(ANALYZER, 0, STORMPOLUNIT, 2, 0x1, unit_bc);
		HT_WRF(ANALYZER, 0, STORMPOLUNIT, 1, 0x1, unit_mc);
		HT_WRF(ANALYZER, 0, STORMPOLUNIT, 0, 0x1, unit_uc);
	}
#endif
	
#ifdef VTSS_FEATURE_QOS_POLICER_CPU_SWITCH
	{
		ulong              i, unit;
		vtss_packet_rate_t rate;
		
		for (i = 3; i < 6; i++) {
			rate = (i == 3 ? qos->policer_learn : 
		i == 4 ? qos->policer_cat : qos->policer_mac);
		HT_WRF(ANALYZER, 0, STORMLIMIT, 4*i, 0xf, calc_packet_rate(rate, &unit));
		HT_WRF(ANALYZER, 0, STORMPOLUNIT, i, 0x1, unit);
		HT_WRF(ANALYZER, 0, STORMLIMIT_ENA, i, 0x1, 
			rate == VTSS_PACKET_RATE_DISABLED ? 0 : 1);
		}
	}
#endif
	
	return 0;
}

/* Set aggregation mode */
int vtss_ll_aggr_mode_set(const vtss_aggr_mode_t *mode)
{
#ifdef VTSS_FEATURE_AGGR_MODE_ADV
	ulong          value;
	vtss_port_no_t port_no;
	
	/* Setup analyzer */
	value = (((mode->random ? 1 : 0)<<3) |
		((mode->sip_dip_enable || mode->sport_dport_enable ? 1 : 0)<<2) |
		((mode->dmac_enable ? 1 : 0)<<1) |
		((mode->smac_enable ? 1 : 0)<<0));
	HT_WR(ANALYZER, 0, AGGRCNTL, value);
	/* Setup categorizer */
	value = 0;
	if (mode->sip_dip_enable) {
		/* SIP/DIP included */
		value |= (1<<1);
	}
	if (mode->sport_dport_enable) {
		/* SPORT/DPORT included */
		value |= (1<<0);
	}
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		HT_WRF(PORT, port_no, CAT_OTHER_CFG, 0, 0x3, value);
	}
#else
	HT_WR(ANALYZER, 0, AGGRCNTL, 
	      ((mode->smac_enable ? 1 : 0)<<0) |
	      ((mode->dmac_enable ? 1 : 0)<<1));
#endif
	
	return 0;
}

#ifdef VTSS_FEATURE_LEARN_PORT
/* Set learn port mode */
int vtss_ll_learn_port_mode_set(const vtss_port_no_t      port_no,
				vtss_learn_mode_t * const learn_mode)
{
	HT_WRF(ANALYZER, 0, LEARNDROP, port_no, 0x1, learn_mode->discard);
	HT_WRF(ANALYZER, 0, LEARNAUTO, port_no, 0x1, learn_mode->automatic);
	HT_WRF(ANALYZER, 0, LEARNCPU, port_no, 0x1, learn_mode->cpu);
	
	if (!learn_mode->automatic) {
		/* Flush entries previously learned on port to avoid continous refreshing */
		HT_WRF(ANALYZER, 0, LERNMASK, port_no, 0x1, 0);
		VTSS_RC(vtss_ll_mac_table_flush(1, port_no, 0, 0));
		VTSS_RC(ht_port_learn_set(port_no));
	}
	
	return 0;
}
#endif

#ifdef VTSS_FEATURE_LEARN_SWITCH
/* Set learn mode */
int vtss_ll_learn_mode_set(vtss_learn_mode_t * const learn_mode)
{
	uint cpu_bit;
	
	cpu_bit = 24;
	
	HT_WRM(ANALYZER, 0, ADVLEARN,
	       ((learn_mode->automatic ? 1 : 0)<<31) |
	       ((learn_mode->discard ? 1 : 0)<<30) |
	       ((learn_mode->cpu ? 1 : 0)<<cpu_bit),
	       (1<<31) | (1<<30) | (1<<cpu_bit));
	return 0;
}
#endif

/* Set logical port mapping */
int vtss_ll_pmap_table_write(vtss_port_no_t physical_port, vtss_port_no_t logical_port)
{
	HT_WRF(PORT, physical_port, STACKCFG, 0, 0x1F, logical_port);
	return 0;
}

/* Set VLAN port mode */
int vtss_ll_vlan_port_mode_set(vtss_port_no_t port_no, const vtss_vlan_port_mode_t *vlan_mode)
{
	ulong value, mask;
	vtss_vid_t uvid;
	
	/* Ingress */
	value = vlan_mode->pvid;
	HT_WRF(PORT, port_no, CAT_PORT_VLAN, 0, 0xFFF, value);
	value = (((vlan_mode->aware ? 0 : 1)<<8) |
		((vlan_mode->aware ? 0 : 1)<<7));
#ifdef VTSS_FEATURE_VLAN_TYPE_STAG
	value |= ((vlan_mode->stag ? 1 : 0)<<5);
#endif
	mask = ((1<<8) | (1<<7) | (1<<5));
	HT_WRM(PORT, port_no, CAT_VLAN_MISC, value, mask);
	HT_WRM(PORT, port_no, CAT_DROP, 
	       ((vlan_mode->frame_type == VTSS_VLAN_FRAME_TAGGED ? 1 : 0)<<2) |
	       ((vlan_mode->frame_type == VTSS_VLAN_FRAME_UNTAGGED ? 1 : 0)<<1),
	       (1<<2) | (1<<1));
	
#ifdef VTSS_FEATURE_VLAN_INGR_FILTER_PORT
	HT_WRF(ANALYZER, 0, VLANMASK, port_no, 0x1, vlan_mode->ingress_filter ? 1 : 0);
#endif
	
	/* Egress */
	uvid = vlan_mode->untagged_vid;
	value = (((vlan_mode->untagged_vid & 0xFFF)<<4) |
		((uvid != VTSS_VID_ALL && uvid != VTSS_VID_NULL ? 1 : 0)<<3) |
		(uvid != VTSS_VID_ALL ? 1 : 0)<<0);
	mask = ((0xFFF<<4) | (1<<3) | (1<<0));
	HT_WRM(PORT, port_no, TXUPDCFG, value, mask);
	
	return 0;
}

/* ================================================================= *
 * VLAN table
 * ================================================================= */
/* Set VLAN port members */
int vtss_ll_vlan_table_write(vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	vtss_port_no_t    port_no;
	BOOL              port_member[VTSS_PORT_ARRAY_SIZE], mirror = 0;
	vtss_mstp_entry_t *mstp_entry;
	ulong             value;
	
	/* Lookup MSTP entry */
	mstp_entry = &vtss_mac_state.mstp_table[vtss_mac_state.vlan_table[vid].msti];
	
	/* Enable mirror port if egress mirroring enabled on a member port */
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		port_member[port_no] = (member[port_no] && 
			mstp_entry->state[port_no] == VTSS_MSTP_STATE_FORWARDING);
		if (port_member[port_no] && vtss_mac_state.mirror_egress[port_no])
			mirror = 1;
	}
	value = (vid<<0);
#ifdef VTSS_FEATURE_ISOLATED_PORT
	value |= ((vtss_mac_state.vlan_table[vid].isolated ? 1 : 0)<<15);
#endif
	HT_WR(ANALYZER, 0, VLANTINDX, value);
	
	HT_WR(ANALYZER, 0, VLANACES, 
	      (vtss_port_array2mask(port_member)<<2) |
	      (VLAN_CMD_WRITE<<0));
	
	return ht_vlan_table_idle();
}

/* Set VLAN MSTP instance */
int vtss_ll_vlan_table_mstp_set(vtss_vid_t vid, uint msti)
{
	/* Update VLAN entry */
	return vtss_ll_vlan_table_write(vid,
					vtss_mac_state.vlan_table[vid].member);
}

/* Set MSTP state for port and mstp instance */
int vtss_ll_mstp_table_write(vtss_port_no_t port_no, vtss_msti_t msti, 
                                 vtss_mstp_state_t state)
{
	vtss_vid_t        vid;
	vtss_vlan_entry_t *vlan_entry;
	
	/* Update all VLANs mapping to MSTI */
	for (vid = VTSS_VID_NULL; vid < VTSS_VIDS; vid++) {
		vlan_entry = &vtss_mac_state.vlan_table[vid];
		if (vlan_entry->enabled && vlan_entry->msti == msti)
			VTSS_RC(vtss_ll_vlan_table_write(vid, vlan_entry->member));
	}
	return 0;
}

#ifdef VTSS_FEATURE_ISOLATED_PORT
/* Set isolated ports */
int vtss_ll_isolated_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	vtss_port_no_t port_no;
	BOOL           port_member[VTSS_PORT_ARRAY_SIZE];
	
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
		port_member[port_no] = (member[port_no] ? 0 : 1); 
	
	HT_WR(ANALYZER, 0, PVLAN_MASK, 
	      vtss_port_array2mask(port_member) | (1<<VTSS_CHIP_PORT_CPU));
	
	return 0;
}
#endif

/* ================================================================= *
 * MAC table
 * ================================================================= */
#ifdef VTSS_FEATURE_MAC_AGE_AUTO
/* Set MAC address age time */
int vtss_ll_mac_table_age_time_set(vtss_mac_age_time_t age_time)
{
	vtss_mac_age_time_t atime;
	
	/* Scan two times per age time */
	atime = age_time/2;
	if (atime > 0xfffff)
		atime = 0xfffff;
	HT_WR(ANALYZER, 0, AUTOAGE, atime);
	return 0;
}
#endif

/* Age MAC address table */
int vtss_ll_mac_table_age(BOOL pgid_age, vtss_pgid_no_t pgid_no, 
                          BOOL vid_age, vtss_vid_t vid)
{
	uint pgid = (pgid_age ? ht_pgid2chip(pgid_no) : 0);
	
	HT_WR(ANALYZER, 0, ANAGEFIL,
	      ((pgid_age ? 1 : 0)<<31) | (pgid<<16) |
	      ((vid_age ? 1 : 0)<<15) | (vid<<0));
	HT_WR(ANALYZER, 0, MACACCES, MAC_CMD_TABLE_AGE<<0);
	VTSS_RC(ht_mac_table_idle());
	
	return 0;
}

/* Flush MAC address table */
int vtss_ll_mac_table_flush(BOOL pgid_age, vtss_pgid_no_t pgid_no, 
			    BOOL vid_age, vtss_vid_t vid)
{
	/* Age twice instead of flushing. 
	 * This ensures that sticky bit for aged entries is updated
	 */ 
	VTSS_RC(vtss_ll_mac_table_age(pgid_age, pgid_no, vid_age, vid));
	return vtss_ll_mac_table_age(pgid_age, pgid_no, vid_age, vid);
}

/* Learn (VID, MAC) */
/* Note: Uses pgid_no, doesn't use entry->destination list. */
int vtss_ll_mac_table_learn(const vtss_mac_table_entry_t *entry,
			    vtss_pgid_no_t pgid_no)
{
	ulong mach,macl;
	uint  pgid = 0, locked, aged, fwd_kill = 0, ipv6_mask = 0;
	
	/* Calculate MACH/MACL registers */
	mach = ((entry->vid_mac.vid<<16) |
		(entry->vid_mac.mac.addr[0]<<8) |
		(entry->vid_mac.mac.addr[1]<<0));
	macl = ((entry->vid_mac.mac.addr[2]<<24) |
		(entry->vid_mac.mac.addr[3]<<16) |
		(entry->vid_mac.mac.addr[4]<<8) |
		(entry->vid_mac.mac.addr[5]<<0));
	
	if (pgid_no == VTSS_PGID_NONE) {
		/* IPv4/IPv6 multicast entry */
		ulong mask;
		
		locked = 1;
		aged = 1;
		mask = vtss_port_array2mask(vtss_mac_state.pgid_table[pgid_no].member); 
		if (entry->vid_mac.mac.addr[0] == 0x01) {
			/* IPv4 multicast entry */
			/* Encode port mask directly */
			macl = ((macl & 0x00FFFFFF) | ((mask<<24) & 0xFF000000));
			mach = ((mach & 0xFFFF0000) | ((mask>>8) & 0x0000FFFF));
			pgid = ((mask>>24) & 0xF);
		} else {
			/* IPv6 multicast entry */
			fwd_kill = 1;
			/* Encode port mask directly */
			mach = ((mach & 0xFFFF0000) | (mask & 0x0000FFFF));
			pgid = ((mask>>16) & 0x3F);
			ipv6_mask = ((mask>>22) & 0x3F);
		}
	} else {
		/* Not IP multicast entry */
		pgid = ht_pgid2chip(pgid_no);
		locked = entry->locked;
		aged = 0;
	}
	HT_WR(ANALYZER, 0, MACHDATA,mach);
	HT_WR(ANALYZER, 0, MACLDATA,macl);
	HT_WR(ANALYZER, 0, MACACCES,
	      (ipv6_mask<<16) |
	      (MAKEBOOL01(entry->copy_to_cpu)<<14) |
	      (fwd_kill<<13) |      /* forward kill */
	      (0<<12) |             /* Ignore VLAN */
	      (MAKEBOOL01(aged)<<11) |
	      (1<<10) |             /* Valid */
	      (MAKEBOOL01(locked)<<9) |
	      (pgid<<3) |
	      (MAC_CMD_LEARN<<0));
	return ht_mac_table_idle();
}

/* Unlearn (VID, MAC) */
int vtss_ll_mac_table_unlearn(const vtss_vid_mac_t *vid_mac)
{
	uint locked = 0, aged = 0, fwd_kill = 0;
	
	if (VTSS_MAC_IPV4_MC(vid_mac->mac.addr)) {
		/* IPv4 multicast */
		locked = 1;
	} 
	if (VTSS_MAC_IPV6_MC(vid_mac->mac.addr)) {
		/* IPv6 multicast */
		locked = 1;
		fwd_kill = 1;
	}
	if (locked) {
		aged = 1;
	}
	HT_WR(ANALYZER,0, MACHDATA,
	      (vid_mac->vid        <<16) |
	      (vid_mac->mac.addr[0]<< 8) |
	      (vid_mac->mac.addr[1]<< 0));
	HT_WR(ANALYZER, 0, MACLDATA,
	      (vid_mac->mac.addr[2]<<24) |
	      (vid_mac->mac.addr[3]<<16) |
	      (vid_mac->mac.addr[4]<<8) |
	      (vid_mac->mac.addr[5]<<0));
	HT_WR(ANALYZER, 0, MACACCES, 
	      (fwd_kill<<13) |
	      (MAKEBOOL01(aged)<<11) |
	      (MAKEBOOL01(locked)<<9) |
	      MAC_CMD_FORGET<<0);
	return ht_mac_table_idle();
}

/* Note: Updates pgid_no, doesn't update entry->destination list. */
/* Note: Leaves entry and pgid_no unchanged if result not valid. */
static int ht_get_mac_table_result(vtss_mac_table_entry_t * const entry,
				   vtss_pgid_no_t * const pgid_no)
{
	ulong value, mach, macl;
	uint  pgid;
	
	HT_RD(ANALYZER, 0, MACACCES, &value);
	
	/* Check if entry is valid */
	if (!(value & (1<<10))) 
		return VTSS_ENTRY_NOT_FOUND;
	
	entry->copy_to_cpu = MAKEBOOL01(value & (1<<14));
	entry->aged        = MAKEBOOL01(value & (1<<11));
	entry->locked      = MAKEBOOL01(value & (1<<9));
	pgid = ((value>>3) & 0x3F);
	
	HT_RD(ANALYZER, 0, MACHDATA, &mach);
	HT_RD(ANALYZER, 0, MACLDATA, &macl);
	
	if (entry->locked && 
		entry->aged) {
		/* IPv4/IPv6 multicast address */
		ulong          mask;
		vtss_port_no_t port_no;
		
		*pgid_no = VTSS_PGID_NONE;
		
		/* Read encoded port mask and update address registers */
		if (value & (1<<13)) {
			/* IPv6 entry (FWD_KILL set) */
			mask = ((((value>>16) & 0x3F)<<22) | (pgid<<16) | (mach & 0xFFFF));
			mach = ((mach & 0xFFFF0000) | 0x00003333);
		} else {
			/* IPv4 entry */
			mask = ((pgid<<24) | ((mach<<8) & 0xFFFF00) | ((macl>>24) & 0xFF));
			mach = ((mach & 0xFFFF0000) | 0x00000100);
			macl = ((macl & 0x00FFFFFF) | 0x5E000000);
		}    
		
		/* Convert port mask */
		for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
			vtss_mac_state.pgid_table[*pgid_no].member[port_no] = 
				MAKEBOOL01(mask & (1 << port_no));
		}
	} else {
		*pgid_no = ht_chip2pgid(pgid);
	}
	entry->vid_mac.vid = ((mach>>16) & 0xFFF);
	entry->vid_mac.mac.addr[0] = (uchar)((mach>>8) & 0xFF);
	entry->vid_mac.mac.addr[1] = (uchar)((mach>>0) & 0xFF);
	entry->vid_mac.mac.addr[2] = (uchar)((macl>>24) & 0xFF);
	entry->vid_mac.mac.addr[3] = (uchar)((macl>>16) & 0xFF);
	entry->vid_mac.mac.addr[4] = (uchar)((macl>>8) & 0xFF);
	entry->vid_mac.mac.addr[5] = (uchar)((macl>>0) & 0xFF);
	
	return 0;
}

/* Note: Updates pgid_no, doesn't update entry->destination list. */
/* Note: index is different than in datasheet. The API uses the
 *       two LSBits for bucket and the MSBits for line in the MAC table. */
static int ht_mac_table_read(uint index_on_chip,
                                 vtss_mac_table_entry_t * const entry,
                                 vtss_pgid_no_t * const pgid_no,
                                 BOOL shadow)
{
	HT_WR(ANALYZER, 0, MACTINDX,
	      (shadow                        <<13) |
	      ((index_on_chip&0x3)/*bucket*/ <<11) |
	      ((index_on_chip>>2)/*index*/   << 0) );
	HT_WR(ANALYZER, 0, MACACCES, MAC_CMD_READ<<0);
	VTSS_RC(ht_mac_table_idle());
	return ht_get_mac_table_result(entry, pgid_no);
}

/* Lookup (VID, MAC) */
/* Note: Updates pgid_no, doesn't update entry->destination list. */
int vtss_ll_mac_table_lookup(vtss_mac_table_entry_t *entry, vtss_pgid_no_t *pgid_no)
{
	uint                   vid = entry->vid_mac.vid;
	uchar                  *mac = &entry->vid_mac.mac.addr[0];
	uint                   bucket;
	vtss_mac_table_entry_t try_entry;
	vtss_pgid_no_t         try_pgid_no;
	
	ulong mach = (((vid & 0x3F)<<16) | (mac[0]<<8) | (mac[1]<<0));
	ulong macl = ((mac[2]<<24) | (mac[3]<<16) | (mac[4]<<8) | mac[5]);
	uint hash4 = 4*(((mach>>12) & 0x7FF) ^
		     ((mach>>1) & 0x7FF) ^
		     (((mach<<10) & 0x400) | ((macl>>22) & 0x3FF)) ^
		     ((macl>>11) & 0x7FF) ^
		     (macl & 0x7FF));
	
	for (bucket = 0; bucket < 4; bucket++) {
		/* Note: idx is different than in datasheet. The API uses
		 *       the two LSBits for bucket and the MSBits for line
		 *       in the MAC table.
		 */
		VTSS_RC(ht_mac_table_read(hash4 | bucket, &try_entry, &try_pgid_no, 1));
		if (try_entry.vid_mac.vid == vid &&
		    try_entry.vid_mac.mac.addr[0] == mac[0] &&
		    try_entry.vid_mac.mac.addr[1] == mac[1] &&
		    try_entry.vid_mac.mac.addr[2] == mac[2] &&
		    try_entry.vid_mac.mac.addr[3] == mac[3] &&
		    try_entry.vid_mac.mac.addr[4] == mac[4] &&
		    try_entry.vid_mac.mac.addr[5] == mac[5]) {
			*entry = try_entry;
			*pgid_no = try_pgid_no;
			return 0;
		}
	}
	return VTSS_ENTRY_NOT_FOUND;
}

/* Direct MAC read */
/* Note: index is different than in datasheet. The API uses the
 *       two LSBits for bucket and the MSBits for line in the MAC table. */
int vtss_ll_mac_table_read(uint idx, vtss_mac_table_entry_t *entry, 
			   vtss_pgid_no_t *pgid_no)
{
	return ht_mac_table_read(idx-VTSS_MAC_ADDR_START,
				 entry, pgid_no, 0/*shadow*/);
}

/* Get next */
int vtss_ll_mac_table_get_next(const vtss_vid_mac_t *vid_mac,
			       vtss_mac_table_entry_t *entry,
			       vtss_pgid_no_t *pgid_no)
{
	HT_WR(ANALYZER, 0, ANAGEFIL, 0);
	HT_WR(ANALYZER, 0, MACHDATA,
	      (vid_mac->vid<<16) |
	      (vid_mac->mac.addr[0]<<8) |
	      (vid_mac->mac.addr[1]<<0));
	HT_WR(ANALYZER, 0, MACLDATA,
	      (vid_mac->mac.addr[2]<<24) |
	      (vid_mac->mac.addr[3]<<16) |
	      (vid_mac->mac.addr[4]<<8) |
	      (vid_mac->mac.addr[5]<<0));
	HT_WR(ANALYZER, 0, MACACCES, MAC_CMD_GET_NEXT<<0);
	VTSS_RC(ht_mac_table_idle());
	VTSS_RC(ht_get_mac_table_result(entry, pgid_no));
	return 0;
}

/* Get MAC table status */
int vtss_ll_mac_table_status_get(vtss_mac_table_status_t *status) 
{
	ulong value;
	
	/* Read and clear sticky register */
	HT_RD(ANALYZER, 0, ANEVENTS, &value);
	HT_WR(ANALYZER, 0, ANEVENTS, value & ((1<<15) | (1<<16) | (1<<17) | (1<<20)));
	
	/* Detect learn events */
	status->learned = ((value & (1<<16)) ? 1 : 0);
	
	/* Detect replace events */
	status->replaced = ((value & (1<<17)) ? 1 : 0);
	
	/* Detect port move events */
	status->moved = ((value & (1<<15)) ? 1 : 0);
	
	/* Detect age events */
	status->aged = ((value & (1<<20)) ? 1 : 0);
	return 0;
}

/* Write PGID entry */
int vtss_ll_pgid_table_write(vtss_pgid_no_t pgid_no, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	vtss_port_no_t port_no;
	BOOL port_member[VTSS_PORT_ARRAY_SIZE], mirror = 0;
	ulong mask;
	uint pgid;
	
	/* Enable mirror port if egress mirroring enabled on a member port */
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		port_member[port_no] = member[port_no];
		if (member[port_no] && vtss_mac_state.mirror_egress[port_no])
			mirror = 1;
	}
	mask = vtss_port_array2mask(port_member);
	pgid = ht_pgid2chip(pgid_no);
	HT_WR(ANALYZER, 0, DSTMASKS + pgid, mask);
	
	return 0;
}

/* Write source port entry */
int vtss_ll_src_table_write(vtss_port_no_t port_no, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	ulong value, mask;
	
	mask = (VTSS_CHIP_PORTMASK<<0);
	mask |= (1<<(VTSS_CHIP_PORTS + 2)); /* Remove CPU copy flag */
	value = vtss_port_array2mask(member);
	HT_WRM(ANALYZER, 0, SRCMASKS + port_no, value, mask);
	return 0;
}

/* Set monitor port for mirroring */
int vtss_ll_mirror_port_set(vtss_port_no_t port_no)
{
	BOOL member[VTSS_PORT_ARRAY_SIZE];
	vtss_port_no_t port;
	
	/* Calculate mirror ports */
	for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
		member[port] = (port == port_no ? 1 : 0);
	}
	HT_WR(ANALYZER, 0, MIRRORPORTS, vtss_port_array2mask(member));
	return 0;
}

/* Enable/disable egress mirroring of port */
int vtss_ll_dst_mirror_set(vtss_port_no_t port_no, BOOL enable)
{
	HT_WRF(ANALYZER, 0, EMIRRORMASK, port_no, 0x1, enable ? 1 : 0);
	return 0;
}

/* Enable/disable ingress mirroring of port */
int vtss_ll_src_mirror_set(vtss_port_no_t port_no, BOOL enable)
{
	ulong offset;
	offset = (VTSS_CHIP_PORTS + 1);
	HT_WRF(ANALYZER, 0, SRCMASKS + port_no, offset, 0x1, enable ? 1 : 0);
	return 0;
}

/* Write aggregation entry */
int vtss_ll_aggr_table_write(vtss_ac_no_t ac, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	ulong mask = vtss_port_array2mask(member);
	
	HT_WR(ANALYZER, 0, AGGRMSKS + ac - VTSS_AC_START, mask);
	return 0;
}

static int ht_ipmc_flood_mask_set(ulong mask)
{
	HT_WR(ANALYZER, 0, IFLODMSK, mask);
	return 0;
}

/* Set IP Multicast flooding ports */
int vtss_ll_ipmc_flood_mask_set(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	return ht_ipmc_flood_mask_set(vtss_port_array2mask(member));
}

/* Get chip ID and revision */
/* Note: Use chipid=NULL for checking CPU access to the switch chip. */
int vtss_ll_chipid_get(vtss_chipid_t *chipid)
{
	ulong value = 0;
	
	HT_RD(SYSTEM, 0, CHIPID, &value);
	
	if (value >= 1 && value < 8) {
		/* Heathrow-II */
		if (chipid) {
			chipid->part_number = 0x7301;
			chipid->revision = value;
		}
	} else if (((value>>1) & 0x7FF)==0x74) {
		if (chipid) {
			chipid->part_number = (ushort)((value>>12) & 0xFFFF);
			chipid->revision = (value>>28)+1; /* Start at revision 1. */
			/* Map SparX-G5/SparX-G5e rev 2 to SparX-G5m */
			if (chipid->part_number == 0x7395 && chipid->revision == 3) {
				chipid->part_number = 0x7396;
			}
		}
	} else if (value == 0x00000000 || value == 0xFFFFFFFF) {
		vtss_log(VTSS_LOG_ERR,
			 "SPARX: CPU interface error, chipid=0x%08lx", value);
		return VTSS_DATA_NOT_READY;
	} else {
		vtss_log(VTSS_LOG_ERR,
			 "SPARX: CPU interface error, chipid=0x%08lx", value);
		return VTSS_UNSPECIFIED_ERROR;
	}
	return 0;
}

/* - Runtime Optimisations ----------------------------------------- */
/* Optimization function called every second */
int vtss_ll_optimize_1sec(void)
{
	vtss_port_no_t port_no;
	vtss_port_setup_t *ps;
	ulong value;
	
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		/* Skip ports not running 10fdx or down */
		ps = &vtss_mac_state.setup[port_no];
		if (ps->fdx || ps->interface_mode.speed != VTSS_SPEED_10M ||
		    !VTSS_STP_UP(vtss_mac_state.stp_state[port_no]))
			continue;
		
		/* Read Tx packet counter, skip port if changed */
		HT_WR(PORT, port_no, C_CNTADDR, (1<<31) | (0x3042<<0));
		HT_RD(PORT, port_no, C_CNTDATA, &value);
		if (vtss_mac_state.tx_packets[port_no] != value) {
			vtss_mac_state.tx_packets[port_no] = value;
			continue;
		}
		
		/* Read egress FIFO used slices */
		HT_RD(PORT, port_no, FREEPOOL, &value);
		HT_RDF(PORT, port_no, FREEPOOL, 0, 0x1f, &value);
		if (value == 0)
			continue;
		
		/* No Tx activity and FIFO not empty, restart port */
		vtss_log(VTSS_LOG_DEBUG, "SPARX: optimizing port, port=%d", port_no);
		VTSS_RC(vtss_ll_port_speed_mode_gmii(port_no, ps));
	}
	return 0;
}

/* ================================================================= *
 *  Chip Reset, polarity/endian Setup and Interrupts
 * ================================================================= */

static int ht_reset_memories(void)
{
	uint i, memid;
	
	for (i = 0; i < 2; i++) {
		for (memid = 0; memid <= MEMINIT_MAXID; memid++) {
			/* Skip certain blocks */
			if (memid >= MEMID_SKIP_MIN && memid <= MEMID_SKIP_MAX) 
				continue; 
			
			if (i == 0) {
				/* First round: Memory initialization */
				HT_WR(MEMINIT, S_MEMINIT, MEMINIT,(MEMINIT_CMD_INIT<<8) | memid);
				VTSS_MSLEEP(1);
			} else {
				/* Second round: Memory check */
				/* Skip this for SparX */
				break;
			}
		}
		if (i == 0)
			VTSS_MSLEEP(30);
	}
	
	HT_WR(ANALYZER, 0, MACACCES, MAC_CMD_TABLE_CLEAR<<0);  /* Clear MAC table */
	HT_WR(ANALYZER, 0, VLANACES, VLAN_CMD_TABLE_CLEAR<<0); /* Clear VLAN table */

	vtss_acl_enable();
	
	VTSS_MSLEEP(40);
	return 0;
}

/* Setup SI/PI CPU Inteface */
static int ht_setup_cpu_if(void)
{
	ulong value;
	
	/* Setup endianness. PI depends on CPU endianness */
	value = 0x01020304; /* Endianness test value used in next line */
	value = (*((uchar *)&value) == 0x01) ? 0x99999999 : 0x81818181;
	HT_WR(SYSTEM, 0, CPUMODE, value);
	return 0;
}

int vtss_ll_reset(void)
{
	ulong value;
	vtss_chipid_t chipid;
	
	VTSS_RC(ht_setup_cpu_if());
	
	/* Write to RESET register */
	value = (1<<0);
#ifdef CONFIG_VTSS_GROCX
	HT_WR(SYSTEM, 0, GLORESET, (1<<4)|(1<<3)|(1<<2)); /* Lock iCPU and MEM locks */
	VTSS_NSLEEP(VTSS_T_RESET);
#endif
	HT_WR(SYSTEM, 0, GLORESET, value);
	VTSS_NSLEEP(VTSS_T_RESET);
	
	VTSS_RC(ht_setup_cpu_if()); /* Setup again after reset */
	
	HT_WR(SYSTEM, 0, TIMECMP, HT_TIMECMP_DEFAULT);
	/* Improve clock for single ended ref clock mode */
	HT_WRM(SYSTEM, 0, MACRO_CTRL, (1 << 3), (1 << 3));
	VTSS_RC(vtss_ll_chipid_get(&chipid));
	vtss_log(VTSS_LOG_DEBUG,
		 "SPARX: found chip, chip=VSC%04x_%d",
		 chipid.part_number, chipid.revision);
	VTSS_RC(ht_reset_memories());     /* Reset the memories. */
	
	VTSS_RC(ht_cpu_frame_reset());
	
	VTSS_RC(ht_vlan_table_clear());
#ifdef CONFIG_VTSS_GROCX
	/* Release internal PHYs from reset */
	HT_WRM(SYSTEM, 0, GLORESET, (1<<1), (1<<1));
#endif
	{
		uint port_on_chip;
		
		/* Setup all used chip ports */
		for (port_on_chip = 0; port_on_chip <= VTSS_CHIP_PORTS; port_on_chip++) {
			if (
				(VTSS_CHIP_PORTMASK & (1<<port_on_chip)) == 0)
				continue;
			
			/* Allow zero SMAC/DMAC, discard multicast SMAC */
			HT_WRM(PORT, port_on_chip, CAT_DROP, (1<<6) | (0<<0), (1<<6) | (1<<0));
			/* Clear counters */
			HT_WR(PORT, port_on_chip, C_CLEAR, 0);
			
			/* Enable ACLs and physical port in IFH for LACP frames */
#ifdef CONFIG_VTSS_GROCX
			if (port_on_chip != 4) /* ACL disabled on internal port */
#endif
				HT_WR(PORT, port_on_chip, MISCCFG, (1<<3) | (1<<2));
			VTSS_RC(ht_acl_reset_port(port_on_chip));
		}
		/* E-StaX: 32/16 kB for Q0/Q1. G-RocX: 16/8 kB for Q0/Q1 */
		HT_WR(PORT, VTSS_CHIP_PORT_CPU, Q_EGRESS_WM, (0<<24) | (0<<16) | (8<<8) | (16<<0));
		HT_WR(PORT, VTSS_CHIP_PORT_CPU, MISCCFG, 1<<1); /* Enable dropping */
	}
	{
		vtss_ac_no_t ac;
		ulong        mask = VTSS_CHIP_PORTMASK;
		
		/* Enable all ports in IP MC flood mask */
		VTSS_RC(ht_ipmc_flood_mask_set(mask));
		
		/* Ignore SMAC flags to avoid frames from own MAC addresses
		 * to be looped back when injected via CPU device
		 */
		HT_WRF(ANALYZER, 0, AGENCNTL, 13, 0x1, 1);
		mask |= (1<<VTSS_CHIP_PORT_CPU);
		/* Enable all ports in RECVMASK */
		HT_WR(ANALYZER, 0, RECVMASK, mask);
		
		/* Clear aggregation masks */
		for (ac = VTSS_AC_START; ac < VTSS_AC_END; ac++) {
			HT_WR(ANALYZER, 0, AGGRMSKS + ac - VTSS_AC_START, 0);
		}
	}
	
	/* Disable learning for frames discarded by VLAN ingress filtering */
	HT_WRF(ANALYZER, 0, ADVLEARN, 29, 0x1, 0x1);
	/* Disable learning */
	HT_WR(ANALYZER, 0, LERNMASK, 0);
	return 0;
}

/* Initialize low level layer */
int vtss_ll_start(void)
{
	/* I/O Layer */
	vtss_io_start();
	
	if (vtss_ll_reset())
		return -1;
	return 0;
}

void vtss_ll_stop(void)
{
	vtss_io_stop();
}
