#include "vtss_priv.h"

#define VTSS_SERVICE_DESC	"Vitesse appliance"

log_source_t vtss_log_source = {
	"vtss",
};

int vtss_logger = 0;
notify_t vtss_udev_notify;
handle_t vtss_handle = NULL;
vtss_config_t vtss_main_config = {
	VTSS_MAC_AGE_DEFAULT,
};

string_map_t vtss_interface_types[] = {
	{ "N/C", VTSS_PORT_INTERFACE_NO_CONNECTION, },
	{ "LOOPBACK", VTSS_PORT_INTERFACE_LOOPBACK, },
	{ "INTERNAL", VTSS_PORT_INTERFACE_INTERNAL, },
	{ "MII", VTSS_PORT_INTERFACE_MII, },
	{ "GMII", VTSS_PORT_INTERFACE_GMII, },
	{ "RGMII", VTSS_PORT_INTERFACE_RGMII, },
	{ "TBI", VTSS_PORT_INTERFACE_TBI, },
	{ "RTBI", VTSS_PORT_INTERFACE_RTBI, },
	{ "SGMII", VTSS_PORT_INTERFACE_SGMII, },
	{ "SERDES", VTSS_PORT_INTERFACE_SERDES, },
	{ "VAUI", VTSS_PORT_INTERFACE_VAUI, },
	{ "XGMII", VTSS_PORT_INTERFACE_XGMII, },
	{ "Undefined", VTSS_PORT_INTERFACE_UNDEFINED, },
};

const char *vtss_iftype2name(int mac_if)
{
	return int2name(vtss_interface_types, mac_if, "Unknown");
}

/* Return code interpretation */
const char *vtss_error_string(int rc)
{
	const char *txt;
	switch (rc) {
	case 0:
		txt = "0";
		break;
	case VTSS_WARNING:
		txt = "VTSS_WARNING";
		break;
	case VTSS_INCOMPLETE:
		txt = "VTSS_INCOMPLETE";
		break;
	case VTSS_UNSPECIFIED_ERROR:
		txt = "VTSS_UNSPECIFIED_ERROR";
		break;
	case VTSS_NOT_IMPLEMENTED:
		txt = "VTSS_NOT_IMPLEMENTED";
		break;
	case VTSS_INVALID_PARAMETER:
		txt = "VTSS_INVALID_PARAMETER";
		break;
	case VTSS_DATA_NOT_READY:
		txt = "VTSS_DATA_NOT_READY";
		break;
	case VTSS_ENTRY_NOT_FOUND:
		txt = "VTSS_ENTRY_NOT_FOUND";
		break;
	case VTSS_TIMEOUT_RETRYLATER:
		txt = "VTSS_TIMEOUT_RETRYLATER";
		break;
	case VTSS_FATAL_ERROR:
		txt = "VTSS_FATAL_ERROR";
		break;
	case VTSS_PHY_NOT_MAPPED:
		txt = "VTSS_PHY_NOT_MAPPED";
		break;
	case VTSS_PHY_READ_ERROR:
		txt = "VTSS_PHY_READ_ERROR";
		break;
	case VTSS_PHY_TIMEOUT:
		txt = "VTSS_PHY_TIMEOUT";
		break;
	case VTSS_PACKET_BUF_SMALL:
		txt = "VTSS_PACKET_BUF_SMALL";
		break;
	case VTSS_IO_READ_ERROR:
		txt = "VTSS_IO_READ_ERROR";
		break;
	case VTSS_IO_WRITE_ERROR:
		txt = "VTSS_IO_WRITE_ERROR";
		break;
	default:
		txt = "VTSS_UNKNOWN_ERROR";
		break;
	}
	return txt;
}

void vtss_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(vtss_logger, level, format, ap);
	va_end(ap);
}

static int vtss_udev_event(notify_t *nb,
			   unsigned long event, void *data)
{
	udev_node_t *node = (udev_node_t *)data;

	if (strcmp(node->filename, _PATH_VITGENIO) != 0)
		return 0;
	switch (event) {
	case UDEV_CREATE:
		vtss_appl_start();
		break;
	case UDEV_DELETE:
		vtss_appl_stop();
		break;
	}
	return 0;
}

static int vtss_switch_next_mac(mac_entry_t *mac, mac_entry_t *next)
{
	vtss_vid_mac_t search_mac;
	vtss_mac_table_entry_t return_mac;
	int rc;

	memset(&search_mac, 0, sizeof(search_mac));
	if (mac) {
		memcpy(search_mac.mac.addr, mac->mac, sizeof (search_mac.mac));
		search_mac.vid = mac->vid;
	}

	rc = vtss_mac_table_get_next(&search_mac, &return_mac);
	/* end iteration */
	if (rc != 0)
		return TRUE;

	memcpy(next->mac, return_mac.vid_mac.mac.addr, sizeof (next->mac));
	next->vid = return_mac.vid_mac.vid;
	if (return_mac.aged)
		next->state = SWITCH_MAC_AGED;
	else
		next->state = SWITCH_MAC_LEARNED;
	return FALSE;
}

static void vtss_switch_mac_aging(unsigned long timeout)
{
	vtss_main_config.mac_aging = timeout;
	if (vtss_main_config.mac_aging)
		vtss_mac_age_start();
	else
		vtss_mac_age_stop();
}

static int vtss_start(void)
{
	vtss_udev_notify.call = vtss_udev_event;
	vtss_udev_notify.next = NULL;
	vtss_udev_notify.priority = 9;
	udev_register_notify(&vtss_udev_notify);
	return 0;
}

static void vtss_stop(void)
{
	udev_unregister_notify(&vtss_udev_notify);
}

service_t vtss_service = {
	VTSS_SERVICE_NAME,
	VTSS_SERVICE_DESC,
	SERVICE_UP_ALWAYS,
	SERVICE_FLAG_SYSTEM,
	LIST_HEAD_INIT(vtss_service.depends),
	vtss_start,
	vtss_stop,
};

static int vtss_get_mib_counter(net_port_t *port, int mib, void *counters)
{
	vtss_poag_counters_t cnts;
	int rc;

	rc = vtss_poag_counters_get(port->phys_port_no, &cnts);
	if (rc != 0) {
		log_kern(LOG_ERR, "VTSS: failed to get port counter, port=%d, mib=%s",
			 port->port_no, net_mib2name(mib));
		return -1;
	}

	switch (mib) {
	case NET_MIB_RMON:
	{
		net_mib_rmon_t *rmon = (net_mib_rmon_t *)counters;
#define VTSS_COPY_RMON_COUNTER(counter)				\
		do {						\
			rmon->counter = cnts.rmon.counter;	\
		} while (0)

		/* Rx counters */
		VTSS_COPY_RMON_COUNTER(rx_etherStatsDropEvents);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsOctets);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsPkts);
#ifdef VTSS_FEATURE_PORT_CNT_PKT_CAST
		VTSS_COPY_RMON_COUNTER(rx_etherStatsBroadcastPkts);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsMulticastPkts);
#endif
#ifdef VTSS_FEATURE_PORT_CNT_RMON_ADV
		VTSS_COPY_RMON_COUNTER(rx_etherStatsCRCAlignErrors);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsUndersizePkts);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsOversizePkts);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsFragments);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsJabbers);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsPkts64Octets);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsPkts65to127Octets);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsPkts128to255Octets);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsPkts256to511Octets);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsPkts512to1023Octets);
		VTSS_COPY_RMON_COUNTER(rx_etherStatsPkts1024to1518Octets);
#endif
#ifdef VTSS_FEATURE_PORT_CNT_JUMBO
		VTSS_COPY_RMON_COUNTER(rx_etherStatsPkts1519toMaxOctets);
#endif
		/* Tx counters */
		VTSS_COPY_RMON_COUNTER(tx_etherStatsDropEvents);
		VTSS_COPY_RMON_COUNTER(tx_etherStatsOctets);
		VTSS_COPY_RMON_COUNTER(tx_etherStatsPkts);
#ifdef VTSS_FEATURE_PORT_CNT_PKT_CAST
		VTSS_COPY_RMON_COUNTER(tx_etherStatsBroadcastPkts);
		VTSS_COPY_RMON_COUNTER(tx_etherStatsMulticastPkts);
#endif
		VTSS_COPY_RMON_COUNTER(tx_etherStatsCollisions);
#ifdef VTSS_FEATURE_PORT_CNT_RMON_ADV
		VTSS_COPY_RMON_COUNTER(tx_etherStatsPkts64Octets);
		VTSS_COPY_RMON_COUNTER(tx_etherStatsPkts65to127Octets);
		VTSS_COPY_RMON_COUNTER(tx_etherStatsPkts128to255Octets);
		VTSS_COPY_RMON_COUNTER(tx_etherStatsPkts256to511Octets);
		VTSS_COPY_RMON_COUNTER(tx_etherStatsPkts512to1023Octets);
		VTSS_COPY_RMON_COUNTER(tx_etherStatsPkts1024to1518Octets);
#endif
#ifdef VTSS_FEATURE_PORT_CNT_JUMBO
		VTSS_COPY_RMON_COUNTER(tx_etherStatsPkts1519toMaxOctets);
#endif
		break;
	}
	case NET_MIB_IFGRP:
	{
		net_mib_ifgrp_t *if_group = (net_mib_ifgrp_t *)counters;
#define VTSS_COPY_IFGRP_COUNTER(counter)				\
		do {							\
			if_group->counter = cnts.if_group.counter;	\
		} while (0)

		/* Rx counters */
		VTSS_COPY_IFGRP_COUNTER(ifInOctets);
#ifdef VTSS_FEATURE_PORT_CNT_PKT_CAST
		VTSS_COPY_IFGRP_COUNTER(ifInUcastPkts);
		VTSS_COPY_IFGRP_COUNTER(ifInMulticastPkts);
		VTSS_COPY_IFGRP_COUNTER(ifInBroadcastPkts);
		VTSS_COPY_IFGRP_COUNTER(ifInNUcastPkts);
#endif
		VTSS_COPY_IFGRP_COUNTER(ifInDiscards);
		VTSS_COPY_IFGRP_COUNTER(ifInErrors);
		/* Tx counters */
		VTSS_COPY_IFGRP_COUNTER(ifOutOctets);
#ifdef VTSS_FEATURE_PORT_CNT_PKT_CAST
		VTSS_COPY_IFGRP_COUNTER(ifOutUcastPkts);
		VTSS_COPY_IFGRP_COUNTER(ifOutMulticastPkts);
		VTSS_COPY_IFGRP_COUNTER(ifOutBroadcastPkts);
		VTSS_COPY_IFGRP_COUNTER(ifOutNUcastPkts);
#endif
		VTSS_COPY_IFGRP_COUNTER(ifOutDiscards);
		VTSS_COPY_IFGRP_COUNTER(ifOutErrors);
		break;
	}
	case NET_MIB_BRIDGE:
	{
		net_mib_bridge_t *bridge = (net_mib_bridge_t *)counters;
#define VTSS_COPY_BRIDGE_COUNTER(counter)			\
		do {						\
			bridge->counter = cnts.bridge.counter;	\
		} while (0)

		VTSS_COPY_BRIDGE_COUNTER(dot1dTpPortInDiscards);
		break;
	}
	default:
		log_kern(LOG_ERR, "VTSS: unsupported mib type, mib=%s",
			 net_mib2name(mib));
		return -1;
	}
	return 0;
}

static int vtss_get_port_status(net_port_t *port)
{
	vtss_port_status_t status;
	int rc = vtss_port_status_get(port->phys_port_no, &status);

	if (rc == 0) {
		port->full_duplex = status.fdx;
		port->link_state = status.link ? NET_LINK_UP : NET_LINK_DOWN;
		port->port_speed = status.speed;
	}
	return 0;
}

net_physic_t vtss_physic = {
	"vtss",
	"Vitesse MAC port",
	vtss_get_mib_counter,
	vtss_get_port_status,
};

modlinkage int __init appl_vtss_init(void)
{
	vtss_logger = log_register_source(&vtss_log_source);
	if (!vtss_logger)
		return -1;

	net_register_physic(&vtss_physic);

	/* vtss switch depends on /dev/vitgenio */
	service_register_depend(VTSS_SERVICE_NAME, UDEV_SERVICE_NAME);
	service_register_depend(VTSS_SERVICE_NAME, NET_SERVICE_NAME);
	vtss_handle = register_service(&vtss_service);

	return vtss_handle ? 0 : -1;
}

modlinkage void __exit appl_vtss_exit(void)
{
	unregister_service(vtss_handle);

	net_unregister_physic(&vtss_physic);

	log_unregister_source(vtss_logger);
}

module_init(appl_vtss_init);
module_exit(appl_vtss_exit);
