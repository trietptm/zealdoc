#include "vtss_priv.h"

int vtss_vlan_port_members_set(const vtss_vid_t vid,
			       BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	vtss_port_no_t port_no;
	
	VTSS_RC(vtss_ll_vlan_table_write(vid, member));
	
	memcpy(vtss_mac_state.vlan_table[vid].member, member, VTSS_PORT_ARRAY_SIZE*sizeof(BOOL)); 
	for (port_no = VTSS_PORT_NO_START;
	     port_no < VTSS_PORT_NO_END; port_no++) {
		if (member[port_no])
			break;
	}
	vtss_mac_state.vlan_table[vid].enabled = (port_no != VTSS_PORT_NO_END);
	return 0;
}

int vtss_vlan_reset(void)
{
	vtss_port_no_t port_no;
	vtss_vlan_port_mode_t vlan_mode;
	BOOL member[VTSS_PORT_ARRAY_SIZE];
    
	/* Setup in VLAN unaware mode including all ports in VLAN 1 with PVID 1 */
	vlan_mode.aware = 0;
	vlan_mode.pvid = VTSS_VID_DEFAULT;
	vlan_mode.frame_type = VTSS_VLAN_FRAME_ALL;
	vlan_mode.untagged_vid = VTSS_VID_DEFAULT;
#ifdef VTSS_FEATURE_VLAN_INGR_FILTER_PORT
	vlan_mode.ingress_filter = 0;
#endif
#ifdef VTSS_FEATURE_VLAN_TYPE_STAG
	vlan_mode.stag = 0;
#endif
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		VTSS_RC(vtss_vlan_port_mode_set(port_no, &vlan_mode));
		member[port_no] = 1;
	}

	if (vtss_vlan_port_members_set(VTSS_VID_DEFAULT, member) != 0) {
		vtss_log(VTSS_LOG_ERR, "VLAN: failed to set port member, vid=%d",
			 VTSS_VID_DEFAULT);
		return -1;
	}
	return 0;
}

int vtss_vlan_start(void)
{
	vtss_port_no_t port_no;
	vtss_msti_t msti;
	vtss_vid_t vid;
	vtss_pgid_no_t pgid_no;
	vtss_pgid_entry_t *pgid_entry;

	/* Initialize MSTP to VLAN mapping */
	for (vid = 0; vid < VTSS_VIDS; vid++) {
		vtss_mac_state.vlan_table[vid].msti = VTSS_MSTI_START;
	}
	
	/* Initialize MSTP table */
	for (msti = VTSS_MSTI_START; msti < VTSS_MSTI_END; msti++) {
		for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
			vtss_mac_state.mstp_table[msti].state[port_no] = (msti==VTSS_MSTI_START ? 
			VTSS_MSTP_STATE_FORWARDING: 
			VTSS_MSTP_STATE_DISCARDING);
		}
	}

	/* Initialize PGID table */
	vtss_mac_state.pgid_end = VTSS_PGID_END;
	for (pgid_no = VTSS_PGID_START; pgid_no < vtss_mac_state.pgid_end; pgid_no++) {
		pgid_entry = &vtss_mac_state.pgid_table[pgid_no];
		switch (pgid_no) {
		case VTSS_PGID_KILL:
			/* Kill entry */
			pgid_entry->references = 1;
			break;
		case VTSS_PGID_BC:
			/* Broadcast entry */
			for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
				pgid_entry->member[port_no] = MAKEBOOL01(1);
			}
			pgid_entry->references = 1;
			break;
		default:
			if (pgid_no<VTSS_PGID_UNICAST_END) {
				/* Unicast entries */
				pgid_entry->member[pgid_no] = MAKEBOOL01(1);
				pgid_entry->references = 1;
			} else {
				/* Multicast entries */
			}
			break;
		}
	}

	/* Initialize STP and Authentication state */
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		vtss_mac_state.stp_state[port_no] = VTSS_STP_STATE_DISABLED;
	}
	return 0;
}

/* - PGID functions -------------------------------------------------------- */
/* Determine whether a port number is PGID member considering aggregations */
BOOL vtss_pgid_member(vtss_pgid_no_t pgid_no, vtss_port_no_t port)
{
	vtss_pgid_entry_t *pgid_entry;
	vtss_poag_no_t    poag_no;
	vtss_port_no_t    port_no;
	BOOL              member;
	
	pgid_entry = &vtss_mac_state.pgid_table[pgid_no];
	member = pgid_entry->member[port];
	
	if ((poag_no = vtss_mac_state.port_poag_no[port]) != port) {
		/* Port is aggregated, check aggregated ports */
		for (port_no = VTSS_PORT_NO_START;
		     port_no < VTSS_PORT_NO_END; port_no++) {
			if (vtss_mac_state.port_poag_no[port_no] == poag_no &&
			    pgid_entry->member[port_no])
				member = 1;
		}
	}
	return member;
}

/* Write PGID member to chip */
int vtss_pgid_table_write(const vtss_pgid_no_t pgid_no)
{
	vtss_port_no_t port_no;
	BOOL member[VTSS_PORT_ARRAY_SIZE];
	
	/* Avoid updating unicast entries for unmapped ports */
	if (pgid_no<VTSS_PGID_UNICAST_END &&
	    vtss_mac_state.port_map.vtss_port_unused[pgid_no]) {
		vtss_log(VTSS_LOG_DEBUG,
			"SWITCH: skipping unmapped pgid, pgid=%d", pgid_no);
		return 0;
	}
	
	for (port_no = VTSS_PORT_NO_START;
	     port_no < VTSS_PORT_NO_END; port_no++) {
		member[port_no] = vtss_pgid_member(pgid_no, port_no);
		
		/* Ensure that unmapped ports are not included */
		if (vtss_mac_state.port_map.vtss_port_unused[port_no])
			member[port_no] = 0;
	}
	
	/* Update PGID table */
	return vtss_ll_pgid_table_write(pgid_no, member);
}

/* Allocate PGID */
int vtss_pgid_alloc(vtss_pgid_no_t *pgid_no, BOOL resv,
		    const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	vtss_pgid_no_t pgid, pgid_start, pgid_free;
	vtss_pgid_entry_t *pgid_entry;
	vtss_port_no_t port_no;
	
	/* Search for matching or unused entry in PGID table */
	pgid_free = vtss_mac_state.pgid_end;
	pgid_start = VTSS_PGID_START;
	for (pgid = pgid_start; pgid < vtss_mac_state.pgid_end; pgid++)  {
		pgid_entry = &vtss_mac_state.pgid_table[pgid];
		
		if (pgid_entry->references == 0) {
			/* Check if the first unused entry is found */
			if (pgid_free == vtss_mac_state.pgid_end)
				pgid_free = pgid;
		} else if (!resv && !pgid_entry->resv) {
			/* Check if an existing entry matches */
			for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
				if (member[port_no] != pgid_entry->member[port_no])
					break;
				if (port_no == VTSS_PORT_NO_END) {
					pgid_entry->references++;
					vtss_log(VTSS_LOG_DEBUG,
						 "SWITCH: reusing pgid, pgid=%d", pgid);
					*pgid_no = pgid;
					return 0;
				}
		}
	}
	
	/* No pgid found */
	if (pgid_free == vtss_mac_state.pgid_end)
		return VTSS_ENTRY_NOT_FOUND;
	
	/* Unused PGID found */
	*pgid_no = pgid_free;
	vtss_log(VTSS_LOG_DEBUG,
		 "SWITCH: using pgid, pgid=%d", *pgid_no);

	pgid_entry = &vtss_mac_state.pgid_table[*pgid_no];
	pgid_entry->resv = resv;
	pgid_entry->references = 1;
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
		pgid_entry->member[port_no] = member[port_no];
	return vtss_pgid_table_write(*pgid_no);
}

/* Free PGID */
int vtss_pgid_free(const vtss_pgid_no_t pgid_no)
{
	vtss_pgid_entry_t *pgid_entry;
	
	pgid_entry = &vtss_mac_state.pgid_table[pgid_no];
	if (pgid_entry->references == 0) {
		vtss_log(VTSS_LOG_ERR,
			 "SWITCH: pgid already freed, pgid=%d", pgid_no);
		return VTSS_INVALID_PARAMETER;
	}
	pgid_entry->resv = 0;
	pgid_entry->references--;
	return 0;
}
