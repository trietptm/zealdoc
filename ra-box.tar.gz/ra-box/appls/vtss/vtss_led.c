#include "vtss_priv.h"
#include <vtss_led.h>

#ifdef CONFIG_VTSS_BOARD_GROCX_REF
#define NUM_ACT_STATUS	4
#endif

/* - Serial LED ---------------------------------------------------- */
#ifdef VTSS_FEATURE_SERIAL_LED
int vtss_led_set(const uint port, const ulong mode[3])
{
	return vtss_ll_led_set(port, mode);
}

int vtss_ll_led_set(const uint port,  const ulong mode[3])
{
	ulong value, val0, i;
	
	if (port > 29) {
		vtss_log(VTSS_LOG_ERR,
			 "SPARX: illegal port, port=%d", port);
		return VTSS_INVALID_PARAMETER;
	}
	
	/* Set shared LED/GPIO pins to LED mode */
	HT_WRM(SYSTEM, 0, GPIOCTRL, (0<<11) | (0<<10), (1<<11) | (1<<10));
	
	/* Select port */
	HT_WR(SYSTEM, 0, LEDTIMER,
	      (0<<31) | (port<<26) | (178<<16) | (25000<<0));
	
	/* Setup LED mode */
	value = 0;
	for (i = 0; i < 3; i++) {
		switch (mode[i]) {
		case VTSS_LED_MODE_DISABLED:
			val0 = 7;
			break;
		case VTSS_LED_MODE_OFF:
			val0 = 0;
			break;
		case VTSS_LED_MODE_ON:
			val0 = 1;
			break;
		case VTSS_LED_MODE_2_5:
			val0 = 2;
			break;
		case VTSS_LED_MODE_5:
			val0 = 3;
			break;
		case VTSS_LED_MODE_10:
			val0 = 4;
			break;
		case VTSS_LED_MODE_20:
			val0 = 5;
			break;
		default:
			val0 = 0;
			break;
		}
		value |= (val0 << (3*i));
	}
	HT_WR(SYSTEM, 0, LEDMODES, value);
	
	return 0;
}

void vtss_led_update_port(vtss_port_no_t port_no,
			  vtss_port_status_t *port_status,
			  BOOL act_update)
{   
#ifdef CONFIG_VTSS_BOARD_GROCX_REF
	static BOOL is_init = 0;
	static uint64_t port_counter[4];
	static BOOL act_status[NUM_ACT_STATUS] = {0,0,0,0};
	
	/* BOARD_GROCX_REF LED hardware spec(configuration B).
	 *
	 * Logical port number       LED port number
	 * =======================================
	 * P5/P4/P3/P2 ACT ---> LED0/1/2/3.0
	 * P5/P4/P3/P2 10/100 mode --> LED0/1/2/3.1
	 * P5/P4/P3/P2 GIGA mode --> LED0/1/2/3.2 
	 */   
	vtss_port_no_t port_maps[8] = {3,2,1,0,0xff,0xff,0xff,0xff}; /* Logic port map to LED port(Config B) */
	uint led_port;
	ulong led_mode[3];
	vtss_poag_counters_t counters;
	uint64_t current_counter;
	BOOL is_act = 0;
	
	if (is_init == 0) {
		memset(port_counter, 0, sizeof(port_counter));
		is_init = 1;
	}
	
	led_port = port_maps[port_no];
	if (led_port == 0xff) {
		return;
	}
	
	if (act_status[led_port] == 1 && act_update == 1) {
		return; /* don't change LED status too fast */
	} else if (act_update == 1) {
		vtss_poag_counters_get(port_no, &counters);
		current_counter = (counters.if_group.ifInOctets + counters.if_group.ifOutOctets);
		if (current_counter != port_counter[port_no]) {
			is_act = 1;
			act_status[led_port] = 1;
			port_counter[port_no] = current_counter;
		}
	}
        
	if (port_status->link) {
		/* Link up */
		if (!is_act) {
			led_mode[0] = VTSS_LED_MODE_OFF;
		} else {
			led_mode[0] = VTSS_LED_MODE_5;   
		}    
		if (port_status->speed == VTSS_SPEED_1G)
		{   /* Giga mode*/
			led_mode[1] = VTSS_LED_MODE_OFF;
			led_mode[2] = VTSS_LED_MODE_ON;
		} else {
			/* 10/100 mode */
			led_mode[1] = VTSS_LED_MODE_ON;
			led_mode[2] = VTSS_LED_MODE_OFF;
		}
		vtss_led_set(led_port, &led_mode[0]);
	} else {
		/* Link down */
		led_mode[0] = VTSS_LED_MODE_OFF;
		led_mode[1] = VTSS_LED_MODE_OFF;
		led_mode[2] = VTSS_LED_MODE_OFF;
		vtss_led_set(led_port, &led_mode[0]);
	}
#endif
}

int vtss_led_start(void)
{
#ifdef CONFIG_VTSS_BOARD_GROCX_REF /* LED init for GROCX_REF Board */
	uint led_port; 
	ulong led_mode[3];
	
	led_mode[0] = VTSS_LED_MODE_OFF;
	led_mode[1] = VTSS_LED_MODE_OFF;
	led_mode[2] = VTSS_LED_MODE_OFF;
	/* set the first four ports to "off" mode */
	for (led_port = 0; led_port <= 3; led_port++) {
		vtss_led_set(led_port, &led_mode[0]);
	}    
	
	led_mode[0] = VTSS_LED_MODE_DISABLED;
	led_mode[1] = VTSS_LED_MODE_DISABLED;
	led_mode[2] = VTSS_LED_MODE_DISABLED;
	/* set the rest ports to "disable" mode */
	for (led_port = 4; led_port <= 15; led_port++) {
		vtss_led_set(led_port, &led_mode[0]);
	}
	
	/* use enhanced led mode for VSC8601 */
	vtss_phy_write(1, 31, 0x1);
	vtss_phy_write(1, 17, 0x10);
	vtss_phy_write(1, 16, 0x61a);
	vtss_phy_write(1, 17, 0x14d6);
	vtss_phy_write(1, 31, 0x0);
#endif
	return 0;
}
#endif
