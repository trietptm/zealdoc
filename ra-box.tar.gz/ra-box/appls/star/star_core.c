#include "star_priv.h"

static int star_dev_event(notify_t *nb, unsigned long event, void *data);

static int star_ioctl_ready = 0;
static char star_lan_dev[IFNAMSIZ];
static char star_wan_dev[IFNAMSIZ];
handle_t star_handle = NULL;
notify_t star_dev_notify = {
	NULL,
	star_dev_event,
	9,
};

DECLARE_LIST(star_lan_vlans);
DECLARE_LIST(star_wan_vlans);

static int __star_packet_control(int s,
				 const vtss_grx_packet_control_t * ctl)
{
	struct ifreq ifr;
	
	if (!star_ioctl_ready)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	strcpy(ifr.ifr_name, star_lan_dev);
	
	ifr.ifr_data = (caddr_t)ctl;
	return ioctl(s, SIOCDEVPRIVATE, (unsigned long)&ifr);
}

int star_set_packet_control(uint port_no, unsigned long rx_flags)
{
	vtss_grx_packet_control_t ctl;
	int s = -1;
	int res = -1;

	if ((s = __net_config_open()) < 0)
		goto err;

	ctl.cmd = VTSS_GRX_IOCTL_PACKET_CONTROL;
	ctl.port = port_no;
	ctl.unknown_packet = rx_flags & STAR_GSW_PACKET_UNKNOWN;
	ctl.multicast_packet = rx_flags & STAR_GSW_PACKET_MULTICAST;
	ctl.broadcast_packet = rx_flags & STAR_GSW_PACKET_BROADCAST;
	res = __star_packet_control(s, &ctl);

	__net_config_close(s);
err:
	return res;
}

int star_get_packet_control(uint port_no, unsigned long *rx_flags)
{
	vtss_grx_packet_control_t ctl;
	int s = -1;
	int res = -1;

	if ((s = __net_config_open()) < 0)
		goto err;

	ctl.cmd = VTSS_GRX_IOCTL_PACKET_CONTROL_GET;
	ctl.port = port_no;
	res = __star_packet_control(s, &ctl);

	if (res == 0 && rx_flags) {
		*rx_flags = 0;
		if (ctl.unknown_packet)
			*rx_flags |= STAR_GSW_PACKET_UNKNOWN;
		if (ctl.multicast_packet)
			*rx_flags |= STAR_GSW_PACKET_MULTICAST;
		if (ctl.broadcast_packet)
			*rx_flags |= STAR_GSW_PACKET_BROADCAST;
	}

	__net_config_close(s);
err:
	return res;
}

static int __start_clear_port_counter(int s,
				      const vtss_grx_port_counter_t * ctl)
{
	struct ifreq ifr;

	if (!star_ioctl_ready)
		return -1;
	
	memset(&ifr, 0, sizeof(ifr));
	strcpy(ifr.ifr_name, star_lan_dev);
	
	ifr.ifr_data = (caddr_t)ctl;
	return ioctl(s, SIOCDEVPRIVATE, (unsigned long)&ifr);
}

int star_clear_port_counter(uint port_no)
{
	vtss_grx_port_counter_t ctl;
	int s = -1;
	int res = -1;

	if ((s = __net_config_open()) < 0)
		goto err;

	ctl.cmd = VTSS_GRX_IOCTL_COUNTER_CLEAR;
	ctl.port = port_no;
	res = __start_clear_port_counter(s, &ctl);

	__net_config_close(s);
err:
	return res;
}

static int __star_get_port_counter(int s,
				   const vtss_grx_port_counter_t * ctl)
{
	struct ifreq ifr;

	if (!star_ioctl_ready)
		return -1;
	
	memset(&ifr, 0, sizeof(ifr));
	strcpy(ifr.ifr_name, star_lan_dev);
	
	ifr.ifr_data = (caddr_t)ctl;
	return ioctl(s, SIOCDEVPRIVATE, (unsigned long)&ifr);
}

int star_get_port_counter(uint port_no, star_counter_t *cnts)
{
	vtss_grx_port_counter_t ctl;
	int s = -1;
	int res = -1;

	if ((s = __net_config_open()) < 0)
		goto err;

	ctl.cmd = VTSS_GRX_IOCTL_COUNTER_GET;
	ctl.port = port_no;
	res = __star_get_port_counter(s, &ctl);

	if (cnts) {
#define STAR_COPY_COUNTER(counter)		\
	do {					\
		cnts->counter = ctl.counter;	\
	} while (0)
		if (port_no == STAR_GSW_PORT_CPU) {
			STAR_COPY_COUNTER(ts_ok_pkt);
			STAR_COPY_COUNTER(ts_ok_byte);
			STAR_COPY_COUNTER(ts_no_dest_drop_pkt);
			STAR_COPY_COUNTER(ts_arl_drop_pkt);
			STAR_COPY_COUNTER(ts_vlan_ingress_drop_pkt);
			STAR_COPY_COUNTER(fs_ok_pkt);
			STAR_COPY_COUNTER(fs_ok_byte);
		} else {
			STAR_COPY_COUNTER(rx_ok_pkt);
			STAR_COPY_COUNTER(rx_ok_byte);
			STAR_COPY_COUNTER(rx_runt_pkt);
			STAR_COPY_COUNTER(rx_over_size_pkt);
			STAR_COPY_COUNTER(rx_no_buffer_drop_pkt);
			STAR_COPY_COUNTER(rx_crc_err_pkt);
			STAR_COPY_COUNTER(rx_arl_drop_pkt);
			STAR_COPY_COUNTER(rx_vlan_ingress_drop_pkt);
			STAR_COPY_COUNTER(rx_csum_err_pkt);
			STAR_COPY_COUNTER(rx_pause_frame_pkt);
			STAR_COPY_COUNTER(tx_ok_pkt);
			STAR_COPY_COUNTER(tx_ok_byte);
		}
	}
#undef STAR_COPY_COUNTER

	__net_config_close(s);
err:
	return res;
}

static int star_find_device_name(const char *type, char ifname[IFNAMSIZ])
{
	FILE *fh;
	char *buffer = NULL, *p;
	int size = 0;
	int length;
	int found = 0;

	fh = fopen(_PATH_STAR_GSW_DEV, "rb");
	if (!fh) {
		log_kern(LOG_ERR, "GSW: failed to open proc, file=%s",
			 _PATH_STAR_GSW_DEV);
		return -1;
	}

	while (!feof(fh)) {
		length = getline(&buffer, &size, fh);
		if (length > 0) {
			chomp(buffer);
			buffer[3] = 0;

			p = &buffer[5];
			if (strcasecmp(buffer, type) == 0) {
				strlcpy(ifname, p, IFNAMSIZ);
				found = 1;
				break;
			}
		}
	}

	if (buffer) free(buffer);
	if (fh) fclose(fh);
	return found;
}

const char *star_get_wan_device(void)
{
	static char ifname[IFNAMSIZ];

	if (!star_find_device_name(STAR_WAN_DEVICE, ifname)) {
		log_kern(LOG_ERR, "GSW: no wan device registered");
		return NULL;
	}
	log_kern(LOG_INFO, "GSW: wan device registered, dev=%s", ifname);
	return ifname;
}

const char *star_get_lan_device(void)
{
	static char ifname[IFNAMSIZ];

	if (!star_find_device_name(STAR_LAN_DEVICE, ifname)) {
		log_kern(LOG_ERR, "GSW: no lan device registered");
		return NULL;
	}
	log_kern(LOG_INFO, "GSW: lan device registered, dev=%s", ifname);
	return ifname;
}

#if 0
int star_wan_control_port(vtss_grx_mac1_control_t * mac1_control)
{
	struct ifreq ifr;
	int err;
	
	memset(&ifr, 0, sizeof(ifr));
	strcpy(ifr.ifr_name, vtss_ioctl_dev);
	
	ifr.ifr_data = (caddr_t)mac1_control;
	
	err = ioctl(vtss_grx_ioctl_fd, SIOCDEVPRIVATE, (unsigned long)&ifr);
	if (err < 0) {
		vtss_log(VTSS_LOG_ERR,
			 "GROCX: ioctl(SIOCDEVPRIVATE - mac1) failed");
		return VTSS_FATAL_ERROR;
	}
	return 0;
}
#endif

#if 0
static int star_wan_port_setup(void)
{
	vtss_grx_mac1_control_t ctl;
	
#if defined(CONFIG_VTSS_GROCX) && (VTSS_ROUTER_PORT_WAN == 0)
	if (vtss_port_no == 1) {
		vtss_grocx_port_conf_t grocx_port_setup;
		
		grocx_port_setup.enable = 1;
		grocx_port_setup.speed = setup.interface_mode.speed;
		grocx_port_setup.fdx = setup.fdx;
		grocx_port_setup.flow_control = setup.flowcontrol.obey;
		
		vtss_grocx_port_setup(vtss_port_no, &grocx_port_setup);
		return;
	}
#endif
	
	ctl.an = setup->autoneg;
	switch (setup->speed) {
        case VTSS_SPEED_10M:
		ctl.force_speed = FORCE_10;
		ctl.giga_mode = MODE_10_100;
		break;
	case VTSS_SPEED_100M:
		ctl.force_speed = FORCE_100;
		ctl.giga_mode = MODE_10_100;
		break;
	case VTSS_SPEED_1G:
		ctl.force_speed = FORCE_1000;
		ctl.giga_mode = MODE_10_100_1000;
		break;
	default:
		break;
	}
	
	ctl.force_fc_tx = setup->flow_control;
	ctl.force_fc_rx = setup->flow_control;
	
	
	ctl.cmd = VTSS_GRX_IOCTL_MAC1_CONTROL;
	
	if (setup->fdx == 1)
		ctl.force_duplex = FULL_DUPLEX;
	else
		ctl.force_duplex = HALF_DUPLEX;
	
	vtss_grocx_router_mac1_control(&ctl);
	return 0;
}
#endif

static int star_get_port_status(net_port_t *port)
{
	return 0;
}

static int star_get_mib_counter(net_port_t *port, int mib, void *counters)
{
	star_counter_t cnts;
	int phys_port = port->phys_port_no;

	if (star_get_port_counter(phys_port, &cnts) != 0) {
		log_kern(LOG_ERR, "STAR: failed to get port counter, port=%d, mib=%s",
			 port->port_no, net_mib2name(mib));
		return -1;
	}

	switch (mib) {
	case NET_MIB_RMON:
	{
		net_mib_rmon_t *rmon = (net_mib_rmon_t *)counters;

    		rmon->rx_etherStatsDropEvents = cnts.rx_no_buffer_drop_pkt +
						cnts.rx_arl_drop_pkt +
						cnts.rx_vlan_ingress_drop_pkt;
		rmon->rx_etherStatsOctets = cnts.rx_ok_byte;
		/* + ctl.rx_pause_frame_pkt; need the pause frame */
		rmon->rx_etherStatsPkts = cnts.rx_ok_pkt +
					  cnts.rx_over_size_pkt +
					  cnts.rx_crc_err_pkt + 
					  cnts.rx_csum_err_pkt; 
		rmon->rx_etherStatsCRCAlignErrors = cnts.rx_crc_err_pkt;
		rmon->rx_etherStatsUndersizePkts = cnts.rx_runt_pkt;
		rmon->rx_etherStatsOversizePkts = cnts.rx_over_size_pkt;
		rmon->tx_etherStatsOctets = cnts.tx_ok_byte;
		rmon->tx_etherStatsPkts = cnts.tx_ok_pkt;

		rmon->rx_etherStatsBroadcastPkts = -1;
		rmon->rx_etherStatsMulticastPkts = -1;
		rmon->rx_etherStatsFragments = -1;
		rmon->rx_etherStatsJabbers = -1;
		rmon->rx_etherStatsPkts64Octets = -1;
		rmon->rx_etherStatsPkts65to127Octets = -1;
		rmon->rx_etherStatsPkts128to255Octets = -1;
		rmon->rx_etherStatsPkts256to511Octets = -1;
		rmon->rx_etherStatsPkts512to1023Octets = -1;
		rmon->rx_etherStatsPkts1024to1518Octets = -1;
		rmon->rx_etherStatsPkts1519toMaxOctets = -1;  /* Proprietary */
		rmon->tx_etherStatsDropEvents = -1;
		rmon->tx_etherStatsBroadcastPkts = -1;
		rmon->tx_etherStatsMulticastPkts = -1;
		rmon->tx_etherStatsCollisions = -1;
		rmon->tx_etherStatsPkts64Octets = -1;
		rmon->tx_etherStatsPkts65to127Octets = -1;
		rmon->tx_etherStatsPkts128to255Octets = -1;
		rmon->tx_etherStatsPkts256to511Octets = -1;
		rmon->tx_etherStatsPkts512to1023Octets = -1;
		rmon->tx_etherStatsPkts1024to1518Octets = -1;
		rmon->tx_etherStatsPkts1519toMaxOctets = -1;  /* Proprietary */

		break;
	}
	case NET_MIB_IFGRP:
	{
		net_mib_ifgrp_t *if_group = (net_mib_ifgrp_t *)counters;

		/* Rx counters */
		if_group->ifInOctets = -1;
		if_group->ifInUcastPkts = -1;
		if_group->ifInMulticastPkts = -1;
		if_group->ifInBroadcastPkts = -1;
		if_group->ifInNUcastPkts = -1;
		if_group->ifInDiscards = -1;
		if_group->ifInErrors = -1;

		/* Tx counters */
		if_group->ifOutOctets = -1;
		if_group->ifOutUcastPkts = -1;
		if_group->ifOutMulticastPkts = -1;
		if_group->ifOutBroadcastPkts = -1;
		if_group->ifOutNUcastPkts = -1;
		if_group->ifOutDiscards = -1;
		if_group->ifOutErrors = -1;

		break;
	}
	case NET_MIB_BRIDGE:
	{
		net_mib_bridge_t *bridge = (net_mib_bridge_t *)counters;

		bridge->dot1dTpPortInDiscards = -1;
		break;
	}
	default:
		log_kern(LOG_ERR, "STAR: unsupported mib type, mib=%s",
			 net_mib2name(mib));
		return -1;
	}
	return 0;
}

static int star_dev_start(void)
{
	const char *ifname = NULL;

	ifname = star_get_lan_device();
	if (ifname)
		strlcpy(star_lan_dev, ifname, IFNAMSIZ);
	else
		return -1;
	ifname = star_get_wan_device();
	if (ifname)
		strlcpy(star_wan_dev, ifname, IFNAMSIZ);
	else
		return -1;
	return 0;
}

static void star_wan_notify_device(unsigned long event, net_device_t *dev)
{
	switch (event) {
	case NET_DEVICE_CHANGEADDR:
		break;
	case NET_DEVICE_CHANGEMTU:
		break;
	case NET_DEVICE_UP:
		break;
	case NET_DEVICE_GOING_DOWN:
		break;
	case NET_DEVICE_DOWN:
		break;
	case NET_DEVICE_ADD:
		if (STAR_MAC1_LOG_PORT) {
			net_register_port(STAR_MAC1_LOG_PORT, STAR_GSW_PORT_MAC1, "star");
		}
		break;
	case NET_DEVICE_REMOVE:
		if (STAR_MAC1_LOG_PORT)
			net_unregister_port(STAR_MAC1_LOG_PORT);
		break;
	}
}

static void star_lan_notify_device(unsigned long event, net_device_t *dev)
{
	switch (event) {
	case NET_DEVICE_CHANGEADDR:
		break;
	case NET_DEVICE_CHANGEMTU:
		break;
	case NET_DEVICE_UP:
		break;
	case NET_DEVICE_GOING_DOWN:
		break;
	case NET_DEVICE_DOWN:
		break;
	case NET_DEVICE_ADD:
		star_ioctl_ready = 1;
		if (STAR_MAC0_LOG_PORT)
			net_register_port(STAR_MAC0_LOG_PORT, STAR_GSW_PORT_MAC0, "star");
		break;
	case NET_DEVICE_REMOVE:
		star_ioctl_ready = 0;
		if (STAR_MAC0_LOG_PORT)
			net_unregister_port(STAR_MAC0_LOG_PORT);
		break;
	}
}

static int star_dev_event(notify_t *nb, unsigned long event, void *data)
{
	net_device_t *dev = (net_device_t *)data;

	/* check demand NICs */
	if (strcasecmp(star_wan_dev, dev->ifname) == 0) {
		star_wan_notify_device(event, dev);
	}
	if (strcasecmp(star_lan_dev, dev->ifname) == 0) {
		star_lan_notify_device(event, dev);
	}
	return NOTIFY_OK;
}

static int star_port_start(void)
{
	net_register_notify(&star_dev_notify);
	return 0;
}

static void star_port_stop(void)
{
	net_unregister_notify(&star_dev_notify);
}

static int star_start(void)
{
	if (star_dev_start() ||
	    star_port_start())
		return -1;
	return 0;
}

static void star_stop(void)
{
	star_port_stop();
}

service_t star_service = {
	STAR_SERVICE_NAME,
	STAR_SERVICE_DESC,
	SERVICE_UP_ALWAYS,
	SERVICE_FLAG_SYSTEM,
	LIST_HEAD_INIT(star_service.depends),
	star_start,
	star_stop,
};

net_physic_t star_physic = {
	"star",
	"Starsemi MAC port",
	star_get_mib_counter,
	star_get_port_status,
};

modlinkage int __init appl_star_init(void)
{
	net_register_physic(&star_physic);
	/* star switch depends on /proc/grocx/gsw_devices */
	service_register_depend(STAR_SERVICE_NAME, ROOTFS_SERVICE_NAME);
	star_handle = register_service(&star_service);
	return star_handle ? 0 : -1;
}

modlinkage void __exit appl_star_exit(void)
{
	unregister_service(star_handle);
}

module_init(appl_star_init);
module_exit(appl_star_exit);
