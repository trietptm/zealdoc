#include "ui_priv.h"

typedef enum _ui_token_t {
	T_INVALID = 0,                  /* invalid token */
	T_EOL,                          /* end of line */
	T_LCBRACE,			/* { */
	T_RCBRACE,			/* } */
	T_LBRACE,			/* ( */
	T_RBRACE,			/* ) */
	T_COMMA,			/* , */
	T_SEMICOLON,			/* ; */

	T_OP_EQ,			/* = */

	T_HASH,                         /* # */
	T_BARE_WORD,			/* bare word */
	T_DOUBLE_QUOTED_STRING,         /* "foo" */
	T_SINGLE_QUOTED_STRING,         /* 'foo' */
	T_BACK_QUOTED_STRING,		/* `foo` */
	T_TOKEN_LAST
} ui_token_t;

#define T_EQSTART	T_OP_EQ
#define	T_EQEND		(T_OP_EQ + 1)

static const string_map_t tokens[] = {
	{ "{",	T_LCBRACE,	},
	{ "}",	T_RCBRACE,	},
	{ "(",	T_LBRACE,	},
	{ ")",	T_RBRACE,	},
	{ ",",	T_COMMA,	},
	{ "=",	T_OP_EQ,	},
	{ "#",	T_HASH,		},
	{ ";",	T_SEMICOLON,	},
	{ NULL, 0,		},
};

ui_entry_t ui_object_tree = {
	UI_TYPE_INSTANCE,
	UI_VALID_ALL,
	NULL,
	NULL,
	NULL,
	&ui_schema_tree,
	LIST_HEAD_INIT(ui_object_tree.sibling),
	ATOMIC_INIT(0),		/* hold forever */
	LIST_HEAD_INIT(ui_object_tree.children),
};

#define UI_TOKEN_MATCH(bptr, tptr)			\
	((tptr)[0] == (bptr)[0] &&			\
	((tptr)[1] == (bptr)[1] || (tptr)[1] == 0))

static ui_token_t ui_conf_advance(char **ptr, char *buf, int buflen, int tok,
				  const string_map_t *tokenlist);
static ui_token_t ui_conf_token(char **ptr, char *buf, int buflen);
int ui_conf_word(char **ptr, char *buf, int buflen);

static ui_entry_t *ui_conf_load(const char *fromfile, int fromline,
				const char *conffile, ui_entry_t *parent);
static int ui_conf_read(const char *cf, int *lineno, FILE *fp, 
			const char *name, const char *value, 
			ui_entry_t *parent, ui_entry_t **child);

const char *ui_conf_file = UI_DEF_CONF_FILE;

int ui_is_conf_token(const char *tok)
{
	const string_map_t *t;

	for (t = tokens; t->name; t++) {
		if (UI_TOKEN_MATCH(tok, t->name)) {
			return 1;
		}
	}
	return 0;
}

void ui_set_conf_file(const char *file)
{
	if (file)
		ui_conf_file = file;
	else
		ui_conf_file = UI_DEF_CONF_FILE;
}

/* read the next word, use tokens as delimiters */
static ui_token_t ui_conf_token(char **ptr, char *buf, int buflen)
{
	return ui_conf_advance(ptr, buf, buflen, 1, tokens);
}

/*
 * Read a "word" - this means we don't honor
 * tokens as delimiters.
 */
int ui_conf_word(char **ptr, char *buf, int buflen)
{
	return ui_conf_advance(ptr, buf, buflen, 0, tokens) == T_EOL ? 0 : 1;
}

/* Read a word from a buffer and advance pointer.
 * This function knows about escapes and quotes.
 *
 * At end-of-line, buf[0] is set to '\0'.
 * Returns 0 or special token value.
 */
static ui_token_t ui_conf_advance(char **ptr, char *buf, int buflen, int tok,
				  const string_map_t *tokenlist)
{
	char *s, *p;
	int quote;
	int escape;
	int x;
	const string_map_t *t;
	ui_token_t rcode;

	buf[0] = 0;

	/* skip whitespace */
	p = *ptr;
	while (*p && isspace((int)*p))
		p++;

	if (*p == 0) {
		*ptr = p;
		return T_EOL;
	}

	/* might be a 1 or 2 character token */
	if (tok) 
		for (t = tokenlist; t->name; t++) {
			if (UI_TOKEN_MATCH(p, t->name)) {
				strcpy(buf, t->name);
				p += strlen(t->name);
				while (isspace((int)*p))
					p++;
				*ptr = p;
				return (ui_token_t) t->number;
			}
	}

	/* Read word. */
	quote = 0;
	if ((*p == '"') ||
	    (*p == '\'') ||
	    (*p == '`')) {
		quote = *p;
		p++;
	}
	s = buf;
	escape = 0;

	while (*p && buflen-- > 1) {
		if (escape) {
			escape = 0;
			switch(*p) {
				case 'r':
					*s++ = '\r';
					break;
				case 'n':
					*s++ = '\n';
					break;
				case 't':
					*s++ = '\t';
					break;
				case '"':
					*s++ = '"';
					break;
				case '\'':
					*s++ = '\'';
					break;
				case '`':
					*s++ = '`';
					break;
				default:
					if (*p >= '0' && *p <= '9' &&
					    sscanf(p, "%3o", &x) == 1) {
						*s++ = x;
						p += 2;
					} else
						*s++ = *p;
					break;
			}
			p++;
			continue;
		}
		if (*p == '\\') {
			p++;
			escape = 1;
			continue;
		}
		if (quote && (*p == quote)) {
			p++;
			break;
		}
		if (!quote) {
			if (isspace((int) *p))
				break;
			if (tok) {
				for (t = tokenlist; t->name; t++)
					if (UI_TOKEN_MATCH(p, t->name))
						break;
				if (t->name != NULL)
					break;
			}
		}
		*s = *p, p++, s++;
	}
	*s++ = 0;

	/* skip whitespace again. */
	while (*p && isspace((int) *p))
		p++;
	*ptr = p;

	/* we got SOME form of output string, even if it is empty */
	switch (quote) {
	default:
		rcode = T_BARE_WORD;
		break;
		
	case '\'':
		rcode = T_SINGLE_QUOTED_STRING;
		break;
		
	case '"':
		rcode = T_DOUBLE_QUOTED_STRING;
		break;
		
	case '`':
		rcode = T_BACK_QUOTED_STRING;
		break;
	}

	return rcode;
}

/* read the config file */
static ui_entry_t *ui_conf_load(const char *fromfile, int fromline,
				   const char *conffile, ui_entry_t *parent)
{
	int res = 0;
	FILE *fp;
	int lineno = 0;
	ui_entry_t *instance = NULL;

	if ((fp = fopen(conffile, "r")) == NULL) {
		if (fromfile) {
			log_kern(LOG_ERR,
				 "UI: open config failure, from=%s[%d], conf=%s",
				 fromfile, fromline, conffile);
		} else {
			log_kern(LOG_ERR,
				 "UI: open config failure, conf=%s",
				 conffile);
		}
		return NULL;
	}
	
	assert(parent);
	res = ui_conf_read(conffile, &lineno, fp, ".", NULL, parent, &instance);
	fclose(fp);
	if (res && instance) {
		assert(!instance);
		return NULL;
	}
	return instance;
}

static int ui_conf_read(const char *cf, int *lineno, FILE *fp, 
			const char *name, const char *value, 
			ui_entry_t *parent, ui_entry_t **child)
{
	int res = 0;
	ui_entry_t *ins, *inss;
	char *ptr;
	char buf[8192];
	char buf1[8192];
	char buf2[8192];
	char buf3[8192];
	int t1, t2, t3;
	char *cbuf = buf;
	int len;

	/* allocate new section */
	if (parent)
		ins = ui_entry_alloc(parent, UI_TYPE_INSTANCE,
				     name, value);
	else
		ins = NULL;

	/* read, checking for line continuations ('\\' at EOL) */
	for (; ; ) {
		int eof;

		eof = (fgets(cbuf, sizeof(buf) - (cbuf - buf), fp) == NULL);
		(*lineno)++;

		len = strlen(cbuf);

		if ((len == sizeof(buf)) &&
		    (cbuf[len - 1] != '\n')) {
			log_kern(LOG_ERR,
				 "UI: line too long, conf=%s[%d]",
				 cf, *lineno);
			ui_entry_free(ins);
			return -1;
		}
		if (cbuf[len - 1] == '\n') len--;

		if ((len > 0) && (cbuf[len - 1] == '\\')) {
			cbuf[len - 1] = '\0';
			cbuf += len - 1;
			continue;
		}

		if (eof && (cbuf == buf)) {
			break;
		}

		ptr = cbuf = buf;
		t1 = ui_conf_token(&ptr, buf1, sizeof(buf1));

		if ((*buf1 == '#') || (*buf1 == '\0')) {
			continue;
		}

		/* allow for $INCLUDE files */
		if (strcasecmp(buf1, "$INCLUDE") == 0) {
			ui_entry_t *is;

			t2 = ui_conf_word(&ptr, buf2, sizeof(buf2));
			if (buf2 == NULL) {
				ui_entry_free(ins);
				return -1;
			}
			log_kern(LOG_DEBUG, "UI: including file, file=%s", buf2);
			if ((is = ui_conf_load(cf, *lineno, buf2, ins)) == NULL) {
				ui_entry_free(ins);
				return -1;
			}
			if (is != NULL) {
				ui_entry_t *pos, *n;

				/* Re-write the parent of the moved children
				 * to be the upper-layer
				 */
				for_each_ui_inst_safe(is, pos, n) {
					pos->parent = ins;
					list_delete_init(&pos->sibling);
					list_insert_before(&pos->sibling, &ins->children);
				}
				ui_entry_free(is);
			}
			continue;
		}

		/* No '=': must be a section or sub-section */
		if (strchr(ptr, '=') == NULL) {
			t2 = ui_conf_token(&ptr, buf2, sizeof(buf2));
			t3 = ui_conf_token(&ptr, buf3, sizeof(buf3));
		} else {
			t2 = ui_conf_token(&ptr, buf2, sizeof(buf2));
			t3 = ui_conf_word(&ptr, buf3, sizeof(buf3));
		}

		/* see if it's the end of a section */
		if (t1 == T_RCBRACE) {
			if (name == NULL || buf2[0]) {
				log_kern(LOG_ERR, "UI: unexpected end of instance, conf=%s[%d]",
					 cf, *lineno);
				ui_entry_free(ins);
				return -1;
			}
			*child = ins;
			return 0;
		}

		/* perhaps a subsection */
		if (t2 == T_LCBRACE || t3 == T_LCBRACE) {
			res = ui_conf_read(cf, lineno, fp, buf1,
					   t2 == T_LCBRACE ? NULL : buf2,
					   ins, &inss);
			if (res) {
				ui_entry_free(ins);
				return -1;
			}
			continue;
		}

		/* ignore semi-colons */
		if (*buf2 == ';')
			*buf2 = '\0';

		/* must be a normal attr = value line */
		if (buf1[0] != 0 && buf2[0] == 0 && buf3[0] == 0) {
			t2 = T_OP_EQ;
		} else if (buf1[0] == 0 || buf2[0] == 0 ||
			   (t2 < T_EQSTART || t2 > T_EQEND)) {
			/* TODO: do not simply fail here!!! */
			log_kern(LOG_ERR, "UI: line is not attribute/value pair, conf=%s[%d]",
				 cf, *lineno);
			ui_entry_free(ins);
			return -1;
		}

		/* ensure that the user can't add CONF_PAIRs
		 * with 'internal' names;
		 */
		if (buf1[0] == '_') {
			log_kern(LOG_ERR,
				 "UI: illegal attribute name, conf=%s[%d], attr=%s",
				 cf, *lineno, buf1);
			ui_entry_free(ins);
			return -1;
		}

		if (buf3[0] == 0) {
			ui_entry_free(ins);
			return -1;
		}

		if (ins) {
			/* add this value to the instance */
			ui_entry_alloc(ins, UI_TYPE_VALUE,
				       buf1, buf3);
		}
	}

	if (strcmp(name, ".")) {
		log_kern(LOG_ERR,
			 "UI: unexpected end of file, conf=%s[%d]",
			 cf, *lineno);
		ui_entry_free(ins);
		return -1;
	}
	*child = ins;
	return 0;
}

int ui_conf_start(void)
{
	ui_entry_t *entry;
	
	entry = ui_conf_load(NULL, 0, ui_conf_file, &ui_object_tree);
	return entry ? 0 : -1;
}

void ui_conf_stop(void)
{
	ui_inst_delete_conf(&ui_object_tree);
	ui_inst_delete_conf(&ui_object_tree);
}

static void ui_conf_dump_one(FILE *fp,
			     const char *tab, ui_entry_t *inst)
{
	if (inst) {
		ui_entry_t *pos;
		ui_entry_t *iter = NULL;
		for_each_ui_inst(inst, pos) {
			if (UI_VALID_USER & pos->valid) {
				char tmp[128] = {0};
				fprintf(fp, "%s%s %s {\n",
					tab,
					pos->node->schema->name, 
				        (pos->node->schema->flags & UI_FLAG_SINGLE) ?
					"" : ui_get_user_value(pos));
				sprintf(tmp, "%s\t", tab);
				ui_conf_dump_one(fp, tmp, pos);
				fprintf(fp, "%s}\n", tab);
			}
		}
		for_each_ui_value(inst, iter) {
			fprintf(fp, "%s%s = %s\n",
				tab, iter->node->schema->name,
				iter->user_value);
		}
	}
}

void ui_conf_dump(ui_entry_t *ins)
{
	char tab[128] = { 0 };
	ui_conf_dump_one(stdout, tab, ins);
}

void ui_conf_dump_root(void)
{
	ui_conf_dump(&ui_object_tree);
}
