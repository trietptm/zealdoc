#include "cli_priv.h"
#ifdef CONFIG_CLI_HISTORY

/* Variables exported to other files in the readline library. */
char *_rl_isearch_terminators = (char *)NULL;

_rl_search_cxt *_rl_iscxt = 0;

/* Variables imported from other files in the readline library. */
extern HIST_ENTRY *_rl_saved_line_for_history;

static void rl_search_history_init(cli_session_t *, int, int);
static int rl_search_history_exit(cli_session_t *sess);

static _rl_search_cxt *_rl_isearch_init(cli_session_t *, int);
static void _rl_isearch_fini(cli_session_t *, _rl_search_cxt *);
static int _rl_isearch_cleanup(cli_session_t *, _rl_search_cxt *, int);

/* Last line found by the current incremental search, so we don't `find'
   identical lines many times in a row.  Now part of isearch context. */
/* static char *prev_line_found; */

/* Last search string and its length. */
static char *last_isearch_string;
static int last_isearch_string_len;

static const char *default_isearch_terminators = "\033\012";

_rl_search_cxt *_rl_scxt_alloc(int type, int flags)
{
	_rl_search_cxt *cxt;
	
	cxt = (_rl_search_cxt *)malloc(sizeof(_rl_search_cxt));
	
	cxt->type = type;
	cxt->sflags = flags;
	
	cxt->search_string = 0;
	cxt->search_string_size = cxt->search_string_index = 0;
	
	cxt->lines = 0;
	cxt->allocated_line = 0;
	cxt->hlen = cxt->hindex = 0;
	
	cxt->save_line = where_history();
	cxt->last_found_line = cxt->save_line;
	cxt->prev_line_found = 0;
	
	cxt->save_undo_list = 0;
	
	cxt->history_pos = 0;
	cxt->direction = 0;
	
	cxt->lastc = 0;
	
	cxt->sline = 0;
	cxt->sline_len = cxt->sline_index = 0;
	
	cxt->search_terminators = 0;
	
	return cxt;
}

void _rl_scxt_dispose(_rl_search_cxt *cxt, int flags)
{
	xfree(cxt->search_string);
	xfree(cxt->allocated_line);
	xfree(cxt->lines);
	
	free(cxt);
}

/* Search backwards through the history looking for a string which is typed
   interactively.  Start with the current line. */
int cli_reverse_search_history(cli_session_t *sess, int sign, int key)
{
	rl_search_history_init(sess, -sign, key);
	sess->do_isearch = 1;
	return 0;
}

/* Search forwards through the history looking for a string which is typed
   interactively.  Start with the current line. */
int cli_forward_search_history(cli_session_t *sess, int sign, int key)
{
	rl_search_history_init(sess, sign, key);
	sess->do_isearch = 1;
	return 0;
}

/* Display the current state of the search in the echo-area.
   SEARCH_STRING contains the string that is being searched for,
   DIRECTION is zero for forward, or non-zero for reverse,
   WHERE is the history list number of the current line.  If it is
   -1, then this line is the starting one. */
static void rl_display_search(cli_session_t *sess,
			      char *search_string, int reverse_p, int where)
{
	char *message;
	int msglen, searchlen;
	
	searchlen = (search_string && *search_string) ? strlen(search_string) : 0;
	
	message = (char *)malloc(searchlen + 33);
	msglen = 0;
	
#if defined (NOTDEF)
	if (where != -1) {
		sprintf(message, "[%d]", where + history_base);
		msglen = strlen(message);
	}
#endif /* NOTDEF */
	
	message[msglen++] = '(';

	if (reverse_p) {
		strcpy(message + msglen, "reverse-");
		msglen += 8;
	}
	
	strcpy(message + msglen, "i-search)`");
	msglen += 10;
	
	if (search_string) {
		strcpy(message + msglen, search_string);
		msglen += searchlen;
	}
	
	strcpy(message + msglen, "': ");
	
	rl_message(sess, "%s", message);
	free(message);
	rl_redisplay(sess);
}

static _rl_search_cxt *_rl_isearch_init(cli_session_t *sess, int direction)
{
	_rl_search_cxt *cxt;
	register int i;
	HIST_ENTRY **hlist;
	
	cxt = _rl_scxt_alloc(RL_SEARCH_ISEARCH, 0);

	/* set save point & save mark */
	cxt->save_point = sess->point;
	cxt->save_mark = sess->mark;

	if (direction < 0)
		cxt->sflags |= SF_REVERSE;
	
	cxt->search_terminators = _rl_isearch_terminators ? _rl_isearch_terminators
		: default_isearch_terminators;
	
	/* Create an arrary of pointers to the lines that we want to search. */
	hlist = history_list();
	rl_maybe_replace_line(sess);
	i = 0;
	if (hlist)
		for (i = 0; hlist[i]; i++);
		
		/* Allocate space for this many lines, +1 for the current input line,
		   and remember those lines. */
		cxt->lines = (char **)malloc((1 + (cxt->hlen = i)) * sizeof(char *));
		for (i = 0; i < cxt->hlen; i++)
			cxt->lines[i] = hlist[i]->line;
		
		if (_rl_saved_line_for_history)
			cxt->lines[i] = _rl_saved_line_for_history->line;
		else {
			/* Keep track of this so we can free it. */
			cxt->allocated_line = (char *)malloc(1 + strlen(sess->line_buffer));
			strcpy(cxt->allocated_line, &sess->line_buffer[0]);
			cxt->lines[i] = cxt->allocated_line;
		}
		
		cxt->hlen++;
		
		/* The line where we start the search. */
		cxt->history_pos = cxt->save_line;
		
		rl_save_prompt(sess);
		
		/* Initialize search parameters. */
		cxt->search_string = (char *)malloc(cxt->search_string_size = 128);
		cxt->search_string[cxt->search_string_index = 0] = '\0';
		
		/* Normalize DIRECTION into 1 or -1. */
		cxt->direction = (direction >= 0) ? 1 : -1;
		
		cxt->sline = sess->line_buffer;
		cxt->sline_len = strlen(cxt->sline);
		cxt->sline_index = sess->point;
		
		_rl_iscxt = cxt;		/* save globally */
		
		return cxt;
}

static void _rl_isearch_fini(cli_session_t *sess, _rl_search_cxt *cxt)
{
	/* First put back the original state. */
	strcpy(sess->line_buffer, cxt->lines[cxt->save_line]);
	
	rl_restore_prompt(sess);
	
	/* Save the search string for possible later use. */
	xfree(last_isearch_string);
	last_isearch_string = cxt->search_string;
	last_isearch_string_len = cxt->search_string_index;
	cxt->search_string = 0;
	
	if (cxt->last_found_line < cxt->save_line)
		cli_get_previous_history(sess, cxt->save_line - cxt->last_found_line, 0);
	else
		cli_get_next_history(sess, cxt->last_found_line - cxt->save_line, 0);
	
	/* If the string was not found, put point at the end of the last matching
	   line.  If last_found_line == orig_line, we didn't find any matching
	   history lines at all, so put point back in its original position. */
	if (cxt->sline_index < 0) {
		if (cxt->last_found_line == cxt->save_line)
			cxt->sline_index = cxt->save_point;
		else
			cxt->sline_index = strlen(sess->line_buffer);
		sess->mark = cxt->save_mark;
	}
	
	sess->point = cxt->sline_index;
	/* Don't worry about where to put the mark here; rl_get_previous_history
	   and rl_get_next_history take care of it. */
	
	rl_clear_message(sess);
}

int _rl_search_getchar(cli_session_t *sess, _rl_search_cxt *cxt)
{
	int c;
	
	/* Read a key and decide how to proceed. */
	RL_SETSTATE(sess, RL_STATE_MOREINPUT);
	c = cxt->lastc = rl_read_key(sess);
	RL_UNSETSTATE(sess, RL_STATE_MOREINPUT);
	return c;
}

/* Process just-read character C according to isearch context CXT.  Return
   -1 if the caller should just free the context and return, 0 if we should
   break out of the loop, and 1 if we should continue to read characters. */
int _rl_isearch_dispatch(cli_session_t *sess, _rl_search_cxt *cxt, int c)
{
	int n, wstart, wlen, limit, cval;
	cli_command_fn *f;
	
	f = (cli_command_fn *)NULL;
	
	/* Translate the keys we do something with to opcodes. */
	if (c >= 0 && sess->keymap[c].type == ISFUNC) {
		f = sess->keymap[c].function;
		
		if (f == cli_reverse_search_history)
			cxt->lastc = (cxt->sflags & SF_REVERSE) ? -1 : -2;
		else if (f == cli_forward_search_history)
			cxt->lastc = (cxt->sflags & SF_REVERSE) ? -2 : -1;
		else if (f == cli_rubout)
			cxt->lastc = -3;
		else if (c == CTRL('G'))
			cxt->lastc = -4;
		else if (c == CTRL('W'))	/* XXX */
			cxt->lastc = -5;
		else if (c == CTRL('Y'))	/* XXX */
			cxt->lastc = -6;
	}

	  /* The characters in isearch_terminators (set from the user-settable
	     variable isearch-terminators) are used to terminate the search but
	     not subsequently execute the character as a command.  The default
	     value is "\033\012" (ESC and C-J). */
	if (strchr(cxt->search_terminators, cxt->lastc)) {
		if (cxt->lastc == ESC && _rl_input_available(sess))
			rl_execute_next(sess, ESC);
		return (0);
	}

#define ENDSRCH_CHAR(c)		((CTRL_CHAR(c) || META_CHAR(c) || (c) == RUBOUT) && ((c) != CTRL('G')))

	if (cxt->lastc >= 0 && ENDSRCH_CHAR(cxt->lastc)) {
		/* This sets rl_pending_input to LASTC; it will be picked up the next
		   time rl_read_key is called. */
		rl_execute_next(sess, cxt->lastc);
		return (0);
	}

	/* Now dispatch on the character.  `Opcodes' affect the search string or
	   state.  Other characters are added to the string.  */
	switch (cxt->lastc) {
		/* search again */
	case -1:
		if (cxt->search_string_index == 0) {
			if (last_isearch_string) {
				cxt->search_string_size = 64 + last_isearch_string_len;
				cxt->search_string = (char *)realloc(cxt->search_string, cxt->search_string_size);
				strcpy (cxt->search_string, last_isearch_string);
				cxt->search_string_index = last_isearch_string_len;
				rl_display_search(sess, cxt->search_string, (cxt->sflags & SF_REVERSE), -1);
				break;
			}
			return (1);
		}
		else if (cxt->sflags & SF_REVERSE)
			cxt->sline_index--;
		else if (cxt->sline_index != cxt->sline_len)
			cxt->sline_index++;
		else
			cli_ding(sess);
		break;
		
		/* switch directions */
	case -2:
		cxt->direction = -cxt->direction;
		if (cxt->direction < 0)
			cxt->sflags |= SF_REVERSE;
		else
			cxt->sflags &= ~SF_REVERSE;
		break;
		
		/* delete character from search string. */
	case -3:	/* C-H, DEL */
		/* This is tricky.  To do this right, we need to keep a
		   stack of search positions for the current search, with
		   sentinels marking the beginning and end.  But this will
		   do until we have a real isearch-undo. */
		if (cxt->search_string_index == 0)
			cli_ding(sess);
		else
			cxt->search_string[--cxt->search_string_index] = '\0';
		break;
		
	case -4:	/* C-G, abort */
		rl_replace_line(sess, cxt->lines[cxt->save_line], 0);
		sess->point = cxt->save_point;
		sess->mark = cxt->save_mark;
		rl_restore_prompt(sess);
		rl_clear_message(sess);
		
		return -1;
		
	case -5:	/* C-W */
		/* skip over portion of line we already matched and yank word */
		wstart = sess->point + cxt->search_string_index;
		if (wstart >= sess->end) {
			cli_ding(sess);
			break;
		}
		
		/* if not in a word, move to one. */
		cval = _rl_char_value(sess->line_buffer, wstart);
		if (_rl_walphabetic(cval) == 0) {
			cli_ding(sess);
			break;
		}
		n = MB_NEXTCHAR(sess->line_buffer, wstart, 1, MB_FIND_NONZERO);;
		while (n < sess->end) {
			cval = _rl_char_value(sess->line_buffer, n);
			if (_rl_walphabetic(cval) == 0)
				break;
			n = MB_NEXTCHAR(sess->line_buffer, n, 1, MB_FIND_NONZERO);;
		}
		wlen = n - wstart + 1;
		if (cxt->search_string_index + wlen + 1 >= cxt->search_string_size) {
			cxt->search_string_size += wlen + 1;
			cxt->search_string = (char *)realloc(cxt->search_string, cxt->search_string_size);
		}
		for (; wstart < n; wstart++)
			cxt->search_string[cxt->search_string_index++] = sess->line_buffer[wstart];
		cxt->search_string[cxt->search_string_index] = '\0';
		break;
		
	case -6:	/* C-Y */
		/* skip over portion of line we already matched and yank rest */
		wstart = sess->point + cxt->search_string_index;
		if (wstart >= sess->end) {
			cli_ding(sess);
			break;
		}
		n = sess->end - wstart + 1;
		if (cxt->search_string_index + n + 1 >= cxt->search_string_size) {
			cxt->search_string_size += n + 1;
			cxt->search_string = (char *)realloc(cxt->search_string, cxt->search_string_size);
		}
		for (n = wstart; n < sess->end; n++)
			cxt->search_string[cxt->search_string_index++] = sess->line_buffer[n];
		cxt->search_string[cxt->search_string_index] = '\0';
		break;
		
		/* Add character to search string and continue search. */
	default:
		if (cxt->search_string_index + 2 >= cxt->search_string_size) {
			cxt->search_string_size += 128;
			cxt->search_string = (char *)realloc(cxt->search_string, cxt->search_string_size);
		}
		cxt->search_string[cxt->search_string_index++] = c;
		cxt->search_string[cxt->search_string_index] = '\0';
		break;
	}
	
	for (cxt->sflags &= ~(SF_FOUND|SF_FAILED);; ) {
		limit = cxt->sline_len - cxt->search_string_index + 1;
		
		/* Search the current line. */
		while ((cxt->sflags & SF_REVERSE) ? (cxt->sline_index >= 0) : (cxt->sline_index < limit)) {
			if (STREQN(cxt->search_string, cxt->sline + cxt->sline_index, 
				cxt->search_string_index)) {
				cxt->sflags |= SF_FOUND;
				break;
			} else
				cxt->sline_index += cxt->direction;
		}
		if (cxt->sflags & SF_FOUND)
			break;
		do {
			/* Move to the next line. */
			cxt->history_pos += cxt->direction;
			
			/* At limit for direction? */
			if ((cxt->sflags & SF_REVERSE) ? 
				(cxt->history_pos < 0) : (cxt->history_pos == cxt->hlen)) {
				cxt->sflags |= SF_FAILED;
				break;
			}
			
			/* We will need these later. */
			cxt->sline = cxt->lines[cxt->history_pos];
			cxt->sline_len = strlen (cxt->sline);
		} while ((cxt->prev_line_found && \
			 STREQ(cxt->prev_line_found, cxt->lines[cxt->history_pos])) ||
			 (cxt->search_string_index > cxt->sline_len));
		
		if (cxt->sflags & SF_FAILED)
			break;
		
		/* Now set up the line for searching... */
		cxt->sline_index = \
			(cxt->sflags & SF_REVERSE) ? \
			cxt->sline_len - cxt->search_string_index : 0;
	}
	
	if (cxt->sflags & SF_FAILED) {
		/* We cannot find the search string.  Ding the bell. */
		cli_ding(sess);
		cxt->history_pos = cxt->last_found_line;
		return 1;
	}
	
	/* We have found the search string.  Just display it.  But don't
	 * actually move there in the history list until the user accepts
	 * the location.
	 */
	if (cxt->sflags & SF_FOUND) {
		cxt->prev_line_found = cxt->lines[cxt->history_pos];
		rl_replace_line(sess, cxt->lines[cxt->history_pos], 0);
		sess->point = cxt->sline_index;
		cxt->last_found_line = cxt->history_pos;
		rl_display_search(sess, cxt->search_string, (cxt->sflags & SF_REVERSE), 
			(cxt->history_pos == cxt->save_line) ? -1 : cxt->history_pos);
	}
	
	return 1;
}

static int _rl_isearch_cleanup(cli_session_t *sess, _rl_search_cxt *cxt, int r)
{
	if (r >= 0)
		_rl_isearch_fini(sess, cxt);
	_rl_scxt_dispose(cxt, 0);
	_rl_iscxt = 0;
	
	RL_UNSETSTATE(sess, RL_STATE_ISEARCH);
	
	return (r != 0);
}

/* Search through the history looking for an interactively typed string.
   This is analogous to i-search.  We start the search in the current line.
   DIRECTION is which direction to search; >= 0 means forward, < 0 means
   backwards. */
static void rl_search_history_init(cli_session_t *sess,
				   int direction, int invoking_key)
{
	_rl_search_cxt *cxt;		/* local for now, but saved globally */
	
	RL_SETSTATE(sess, RL_STATE_ISEARCH);
	cxt = _rl_isearch_init(sess, direction);
	
	rl_display_search(sess, cxt->search_string, (cxt->sflags & SF_REVERSE), -1);
}

int cli_isearch_internal(cli_session_t *sess)
{	
	int c, r;

	r = -1;
	c = _rl_search_getchar(sess, _rl_iscxt);
	/* We might want to handle EOF here (c == 0) */
	r = _rl_isearch_dispatch(sess, _rl_iscxt, _rl_iscxt->lastc);
	if (r <= 0) {
		sess->do_isearch = 0;
		return rl_search_history_exit(sess);
	}
	return 0;
}

static int rl_search_history_exit(cli_session_t *sess)
{
	/* The searching is over.  The user may have found the string that she
	   was looking for, or else she may have exited a failing search.  If
	   LINE_INDEX is -1, then that shows that the string searched for was
	   not found.  We use this to determine where to place point. */
	return (_rl_isearch_cleanup(sess, _rl_iscxt, 0));
}
#endif
