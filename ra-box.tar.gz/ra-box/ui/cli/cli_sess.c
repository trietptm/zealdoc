#include "cli_priv.h"
#include <netsvc.h>

struct cli_complete_param {
	cli_matches_t *list;
	const char *text;
};

struct cli_process_result {
	/* see CLI_MATCH_xxx */
	int last_match;
	int cmd_index;
	ui_entry_t *inst;
	ui_node_t *node;
	ui_entry_t *entry;
	ui_command_t *cmd;
};

typedef struct _cli_ioterm_t {
	int state;
#define CLI_INPUT_STOPPED	0x00
#define CLI_INPUT_STARTED	0x01
#define CLI_INPUT_STOPPING	0x02
#define CLI_INPUT_STARTING	0x03
	cli_stream_t *io;
	list_t link;
} cli_ioterm_t;

DECLARE_LIST(cli_streams);

#define for_each_stream(s)	\
	list_for_each_entry(cli_ioterm_t, s, &cli_streams, link)

static int cli_process_argcv(cli_session_t *sess, int silent,
			     int argc, char *argv[CLI_MAX_ARGC],
			     struct cli_process_result *result);

static int cli_is_quote_char(char ch);
static int cli_skip_single_quoted(char *string, size_t slen, int sind);
static int cli_skip_double_quoted(char *string, size_t slen, int sind);
static int cli_char_is_quoted(char *string, int eindex);

static int cli_process_choice(ui_choice_t *choice,
			      const void *iter, void *data);
static int cli_process_arg(ui_node_t *node, ui_argument_t *arg, void *data);
static int cli_process_node(ui_node_t *node, void *data);
static int cli_process_entry(ui_entry_t *parent, ui_node_t *node, void *data);
static int cli_process_node_cmd(ui_node_t *node, void *data);
static int cli_process_entry_cmd(ui_node_t *node, void *data);

static void cli_execute_internal(cli_session_t *sess, char *str)
{
	int res = 0;
	char *argv[CLI_MAX_ARGC], **nargv;
	int argc, nargc;
	struct cli_process_result result;

	if (str[0] == '#') return;

	memset(argv, 0x00, sizeof (argv));
	argc = cli_buffer_to_argv(str, str + strlen(str),
				  &argv[0], CLI_MAX_ARGC);
	if (argc <= 0) return;

	cli_crlf(sess);

	if (cli_process_argcv(sess, 0, argc, argv, &result))
		goto end;

	if (!result.cmd || result.cmd_index < 0 || result.cmd_index > argc) {
		cli_printf_eol(&sess->ui, "No command matched");
		goto end;
	}

	if (!result.cmd->execute_fn) {
		cli_printf_eol(&sess->ui, "No \"%s\" command",
			       result.cmd->name);
		goto end;
	}

	nargc = argc - (result.cmd_index+1);
	nargv = &argv[result.cmd_index+1];

	if (nargc < result.cmd->n_args) {
		cli_printf_eol(&sess->ui, "Command \"%s\" argument missing",
			       result.cmd->name);
		goto end;
	}

	sess->ui.result_table = NULL;
	sess->ui.sort_column = NULL;

	if (result.cmd->type & UI_CMD_SCHEMA_NODE) {
		res = result.cmd->execute_fn((ui_session_t *)sess, result.inst,
					     result.node, nargc, nargv);
	}
	if (result.cmd->type & UI_CMD_OBJECT_ENTRY) {
		res = result.cmd->execute_fn((ui_session_t *)sess, result.inst,
					     result.entry, nargc, nargv);
	}
#ifdef CONFIG_CLI_HISTORY
	add_history(str);
#endif
	if (res) {
		cli_printf_eol(&sess->ui, "Command \"%s\" failure",
			       result.cmd->name);
	} else {
		if (sess->ui.result_table) {
			int rows = ui_table_rows(sess->ui.result_table);
			if (rows) {
				if (sess->ui.sort_column) {
					ui_qsort_table(sess->ui.result_table,
						       sess->ui.sort_column,
						       (ui_compare_fn)strcasecmp);
				}
				cli_print_table(&sess->ui, sess->ui.result_table);
				cli_crlf(sess);
				cli_printf_eol(&sess->ui, "Total %d record(s) matched",
					       rows);
			} else {
				cli_printf_eol(&sess->ui, "No record available",
					       result.cmd->name);
			}
		} else {
			cli_printf_eol(&sess->ui, "Command \"%s\" success",
				       result.cmd->name);
		}
	}
end:
	cli_crlf(sess);
	rl_on_new_line(sess);
	for (nargc = 0; nargc < argc; nargc++)
		free(argv[nargc]);
}

static int cli_describe_internal(cli_session_t *sess, int ignore, int invoking_key)
{
	sess->display_help = 1;
	rl_complete_internal(sess, '?');
	rl_on_new_line(sess);
	sess->display_help = 0;
	return 0;
}

static char **cli_complete_attempt(cli_session_t *sess,
				    const char *text,
				    int start, int end)
{
	char *argv[CLI_MAX_ARGC];
	int argc;
	int i;
	cli_matches_t *match_list = NULL;
	char **matches = NULL;
	struct cli_complete_param param;
	int arg_index;
	struct cli_process_result result;

	if (sess->display_help)
		cli_crlf(sess);

	argc = cli_buffer_to_argv(&sess->line_buffer[0],
				  &sess->line_buffer[end], 
				  &argv[0], CLI_MAX_ARGC);


	if (cli_process_argcv(sess, 1, argc - 1, argv, &result))
		goto end;

	match_list = cli_matches_init(sess->display_help);
	param.list = match_list;
	param.text = text;

	/* complete */
	switch (result.last_match) {
	case CLI_MATCH_SCHEMA:
		cli_process_entry(result.inst, result.node, &param);
		if (result.node->schema->type == UI_TYPE_CLASS &&
		    !ui_is_multiple_node(result.node)) {
			cli_process_node(result.node, &param);
		}
		cli_process_node_cmd(result.node, &param);
		break;
	case CLI_MATCH_ENTRY:
		if (result.node->schema->type == UI_TYPE_CLASS)
			cli_process_node(result.node, &param);
		cli_process_entry_cmd(result.node, &param);
		break;
	case CLI_MATCH_COMMAND:
		/* arg_index:
		 * change cmd_index to number = cmd_index + 1
		 * change number to index = argc - number - 1
		 */
		arg_index = argc - (result.cmd_index + 1) - 1;
		if (arg_index >= result.cmd->n_args)
			break;

		cli_process_arg(result.node,
				&result.cmd->args[arg_index], &param);
		break;
	}
	matches = cli_matches_done(sess, match_list, text);
end:
	for (i = 0; i < argc; i++) free(argv[i]);
	return matches;
}

int cli_set_prompt(cli_session_t *sess, const char *prompt)
{
	char *new_prompt;
	static const char *hint = "> ";

	if (!prompt) prompt = CONFIG_PRODUCT_SHORT;

	new_prompt = malloc(strlen(prompt) + 1 + strlen(hint));
	sprintf(new_prompt, "%s%s", prompt, hint);
	rl_set_prompt(sess, new_prompt);
	free(new_prompt);

	rl_reset_line_state(sess);
	rl_on_new_line(sess);
	rl_clear_message(sess);
	rl_forced_update_display(sess);
	return 0;
}

static int cli_process_choice(ui_choice_t *choice, const void *iter, void *data)
{
	struct cli_complete_param *param = (struct cli_complete_param *)data;

	if (param) {
		const char *name = NULL;
		const char *desc = NULL;
		
		if (choice->get_name)
			name = (*(choice->get_name))(iter);
		if (choice->get_desc)
			desc = (*(choice->get_desc))(iter);
		if (name && !strncmp(name, param->text, strlen(param->text)))
			cli_matches_push(param->list, name, CLI_MATCH_ENTRY, desc);
	}
	return 0;
}

static void cli_describe_boolean(struct cli_complete_param *param)
{
	cli_matches_push(param->list, "yes", CLI_MATCH_ENTRY, "Enable option");
	cli_matches_push(param->list, "no", CLI_MATCH_ENTRY, "Disable option");
}

static void cli_describe_choice(const char *name, const char *type_name,
				struct cli_complete_param *param)
{
	ui_choice_t *choice = ui_choice_by_name(type_name);
	if (choice) {
		ui_foreach_choice(choice, cli_process_choice, param);
	} else {
		if (param->list->do_describe)
			cli_matches_push(param->list, "choice", CLI_MATCH_ENTRY, name);
	}
}

static void cli_describe_range(const char *name, const char *type_name,
			       struct cli_complete_param *param)
{
	int i;
	char range_desc[100];
	ui_range_t *range = ui_range_by_name(type_name);

	if (param->list->do_describe) {
		if (range) {
			for (i = 0; i < range->from_to_count; i++) {
				snprintf(range_desc, 100, "%s ~ %s",
					 range->from_to_pairs[i].from,
					 range->from_to_pairs[i].to);
				cli_matches_push(param->list, range_desc, CLI_MATCH_ENTRY, name);
			}
		} else {
			cli_matches_push(param->list, "range", CLI_MATCH_ENTRY, name);
		}
	}
}

static void cli_describe_iftype(net_driver_t *m, struct cli_complete_param *param)
{
	int i;

	if (m->prefix) {
		if (m->index_format == NET_FORMAT_NONE) {
			if (m->prefix &&
			    strncasecmp(param->text, m->prefix,
					strlen(param->text)) == 0) {
				cli_matches_push(param->list, m->prefix,
						 CLI_MATCH_ENTRY, m->desc);
			}
		} else {
			for (i = 0; i < m->max_index; i++) {
				char ifname[IFNAMSIZ];

				sprintf(ifname, "%s%d", m->prefix, i);
				if (ifname &&
				    strncasecmp(param->text, ifname, strlen(param->text)) == 0) {
					cli_matches_push(param->list, ifname,
							 CLI_MATCH_ENTRY, m->desc);
				}
			}
		}
	}
}

static void cli_describe_ifname(const char *name, struct cli_complete_param *param)
{
	net_driver_t *m = NULL;

	if (name)
		m = net_driver_by_name(name);
	if (m) {
		cli_describe_iftype(m, param);
	} else {
		while ((m = net_iterate_driver(m)) != NULL) {
			cli_describe_iftype(m, param);
		}
	}
}

static void __cli_proccess_arg(int type, const char *desc,
			       const char *type_name,
			       struct cli_complete_param *param)
{
	switch (type) {
	case UI_TYPE_CHOICE:
		cli_describe_choice(desc, type_name, param);
		break;
	case UI_TYPE_BOOLEAN:
		cli_describe_boolean(param);
		break;
	case UI_TYPE_RANGE:
		cli_describe_range(desc, type_name, param);
		break;
	case UI_TYPE_IFNAME:
		cli_describe_ifname(type_name, param);
		break;
	default:
		if (param->list->do_describe) {
			cli_matches_push(param->list, ui_node_type_name(type),
					 CLI_MATCH_ENTRY, desc);
		}
		break;
	}
}

static int cli_process_arg(ui_node_t *node, ui_argument_t *arg, void *data)
{
	struct cli_complete_param *param = (struct cli_complete_param *)data;

	switch (arg->type) {
	case UI_TYPE_VALUE:
	case UI_TYPE_INSTANCE:
		__cli_proccess_arg(node->schema->val_type,
				   node->schema->desc,
				   node->schema->type_name,
				   param);
		break;
	default:
		__cli_proccess_arg(arg->type, arg->desc, arg->type_name, param);
		break;
	}
	return 0;
}

static int cli_process_node(ui_node_t *node, void *data)
{
	struct cli_complete_param *param = (struct cli_complete_param *)data;

	if (param) {
		ui_node_t *iter = NULL;
		while ((iter = ui_node_iterate(node->oid, iter, 1)) != NULL) {
			if (!strncmp(iter->schema->name,
				     param->text, strlen(param->text)))
				cli_matches_push(param->list,
						 iter->schema->name,
						 CLI_MATCH_SCHEMA,
						 iter->schema->desc);
		}
	}
	return 0;
}

static int cli_process_entry(ui_entry_t *inst, ui_node_t *node, void *data)
{
	struct cli_complete_param *param = (struct cli_complete_param *)data;

	if (param) {
		ui_entry_t *iter = NULL;

		if (!ui_is_multiple_node(node)) {
			iter = ui_entry_by_user(inst, ui_node_entry_type(node),
						node->schema->name, NULL);
			if (iter && !strncmp(ui_get_user_value(iter), param->text,
					     strlen(param->text))) {
				cli_matches_push(param->list,
						 ui_get_user_value(iter),
						 CLI_MATCH_ENTRY,
						 iter->node->schema->desc);
			}
		} else {
			while ((iter = ui_multiple_entry_iterate_user(inst,
								      ui_node_entry_type(node),
								      node->schema->name,
								      iter)) != NULL) {
				if (!strncmp(ui_get_user_value(iter),
					     param->text, strlen(param->text))) {
					cli_matches_push(param->list,
							 ui_get_user_value(iter),
							 CLI_MATCH_ENTRY,
							 iter->node->schema->desc);
				}
			}
		}
	}
	return 0;
}

static int cli_process_node_cmd(ui_node_t *node, void *data)
{
	struct cli_complete_param *param = (struct cli_complete_param *)data;

	if (param) {
		ui_command_t *iter = NULL;
		while ((iter = ui_command_iterate_schema(node, iter)) != NULL) {
			if (!strncmp(iter->name, param->text, strlen(param->text)))
				cli_matches_push(param->list,
						 iter->name, CLI_MATCH_COMMAND, iter->desc);
		}
	}
	return 0;
}

static int cli_process_entry_cmd(ui_node_t *node, void *data)
{
	struct cli_complete_param *param = (struct cli_complete_param *)data;
	if (param) {
		ui_command_t *iter = NULL;
		while ((iter = ui_command_iterate_object(node, iter)) != NULL) {
			if (!strncmp(iter->name, param->text, strlen(param->text)))
				cli_matches_push(param->list,
						 iter->name, CLI_MATCH_COMMAND, iter->desc);
		}
	}
	return 0;
}

static int cli_advance_node(cli_session_t *sess, const char *text,
			    struct cli_process_result *result)
{
	ui_node_t *node;
	ui_entry_t *entry;
	int not_found = 0;

	node = ui_node_by_name(result->node, text);
	if (node) {
		/* class or attribute */
		result->last_match = CLI_MATCH_SCHEMA;
		result->node = node;

		/* if single class, advance to entry
		 * if single entry is not exist,
		 * try to create it
		 */
		if (node->schema->type == UI_TYPE_CLASS &&
		    !ui_is_multiple_node(node)) {
			entry = ui_inst_create_user(result->inst,
						    node->schema->name,
						    NULL);
			if (entry) {
				result->last_match = CLI_MATCH_ENTRY;
				result->inst = entry;
				result->entry = entry;
			} else {
				not_found = 1;
			}
		}
	} else {
		/* instance or value */
		entry = ui_entry_by_user(result->inst,
					 ui_node_entry_type(result->node),
					 result->node->schema->name,
					 text);
		if (entry) {
			result->last_match = CLI_MATCH_ENTRY;
			result->inst = entry;
			result->entry = entry;
		} else {
			not_found = 1;
		}
	}
	return not_found;
}

int cli_process_argcv(cli_session_t *sess, int silent,
		      int argc, char *argv[CLI_MAX_ARGC],
		      struct cli_process_result *result)
{
	int i;
	int not_found = 0;
	ui_argument_t *arg;
	int arg_index;
	const void *data;

	assert(result);

	result->last_match = CLI_MATCH_SCHEMA;
	result->cmd_index = 0;
	result->inst = sess->ui.root_object;
	result->node = sess->ui.root_schema;
	result->cmd = NULL;
	result->entry = NULL;

	for (i = 0; i < argc; i++) {
		switch (result->last_match) {
		case CLI_MATCH_SCHEMA:
			assert(result->inst && result->node);
			result->cmd = ui_command_by_flag(result->node->oid,
							 argv[i],
							 UI_CMD_SCHEMA_NODE);
			if (result->cmd) {
				result->last_match = CLI_MATCH_COMMAND;
				result->cmd_index = i;
			} else {
				not_found = cli_advance_node(sess, argv[i], result);
			}
			break;
		case CLI_MATCH_ENTRY:
			assert(result->inst && result->node && result->entry);
			result->cmd = ui_command_by_flag(result->node->oid,
							 argv[i],
							 UI_CMD_OBJECT_ENTRY);
			if (result->cmd) {
				result->last_match = CLI_MATCH_COMMAND;
				result->cmd_index = i;
			} else {
				not_found = cli_advance_node(sess, argv[i], result);
			}
			break;
		case CLI_MATCH_COMMAND:
			assert(result->cmd);
			arg_index = i - (result->cmd_index) - 1;
			if (arg_index >= result->cmd->n_args) {
				if (!silent) {
					silent = 1;
					cli_printf_eol(&sess->ui,
						       "Too many command \"%s\" arguments",
						       result->cmd->name);
				}
				not_found = 1;
			}
			arg = &result->cmd->args[arg_index];
			if (!arg) {
				not_found = 1;
			} else {
				if (arg->type == UI_TYPE_VALUE ||
				    arg->type == UI_TYPE_INSTANCE)
					data = result->node;
				else
					data = arg->type_name;
				if (ui_validate_syntax(result->inst, arg->type,
						       argv[i], data)) {
					not_found = 1;
				}
			}
			break;
		}
		if (not_found) break;
	}
	if (not_found) {
		if (!silent) {
			cli_printf_eol(&sess->ui,
				       "Syntax validation error on text \"%s\"",
				       argv[i]);
		}
		return -1;
	}
	return 0;
}

/* Strip whitespace from the start and end of STRING.  Return a pointer
 * into STRING.
 */
static char *stripwhite(char *string)
{
	char *s, *t;
     
	for (s = string; whitespace(*s); s++) ;
	if (*s == 0)
		return s;
	t = s + strlen(s) - 1;
	while ((t > s) && whitespace(*t))
		t--;
	*++t = '\0';
	return s;
}

/* Read a string and execute it */
void cli_session_input(cli_session_t *sess)
{
	char *str = NULL;
	char *line = NULL;

	line = cli_read_line(sess);
	if (!sess->done || line == NULL) {
		goto out;
	}
	
	/* Remove leading and trailing whitespace from the line.
	 * Then, if there is anything left, add it to the history list
	 * and execute it.
	 */
	str = stripwhite(line);
     
	if (*str)
		cli_execute_internal(sess, str);
	if (sess->done) {
		cli_line_start(sess);
	}
out:
	if (line) {
		free(line);
		line = NULL;
	}
}

void cli_clear_history(void)
{
	clear_history();
	stifle_history(0);
}

void cli_clear_display()
{
	rl_clear_display();
}

const char *cli_banner = "";

void cli_banner_start(cli_session_t *sess)
{
	const char copyright[] = \
		"Copyright (C) 2008 " CONFIG_VENDOR_LONG ".\n\n";

	if (!sess->banner_done) {
		cli_write(sess, cli_banner, strlen(cli_banner));
		cli_crlf(sess);
		cli_write(sess, copyright, strlen(copyright));
		cli_crlf(sess);
		sess->banner_done = 1;
	}
}

cli_session_t *cli_session_start(cli_params_t *param)
{
	cli_session_t *sess;

	sess = malloc(sizeof (cli_session_t));

	memset(sess, 0, sizeof (cli_session_t));
	sess->rl_instream = param->instream;
	sess->rl_outstream = param->outstream;

	sess->logger = log_register_output(LOG_MECH_STREAM, sess->rl_outstream);
	sess->debugging = 0;
	if (sess->logger) {
		log_set_level(sess->logger, LOG_INFO);
	}

	sess->insert_mode = RL_IM_DEFAULT;
	
	/* Override the effect of any `set keymap' assignments in the
	   inputrc file. */
	sess->keymap = cli_keymap_copy(cli_standard_keymap);

	/* The character that can generate an EOF.  Really read from
	   the terminal driver... just defaulted here. */
	sess->eof_char = CTRL('D');
	sess->display_help = 0;

	memcpy(&sess->ops, param->ops, sizeof (cli_session_ops));

	cli_bind_key_map(sess->keymap, '?', cli_describe_internal);
	sess->attempted_completion = cli_complete_attempt;
	/* Don't append space after completion. It will be appended in
	 * the new_completion() function explicitly
	 */
	sess->completion_append_character = ' ';
	rl_completer_quote_characters = "'\"";
	sess->char_is_quoted_p = cli_char_is_quoted;

	cli_set_prompt(sess, cli_main_config.prompt);
	cli_line_start(sess);

	ui_begin_session((ui_session_t *)sess);
	return sess;
}

void cli_session_stop(cli_session_t *sess)
{
	char *val = cli_line_stop(sess, 0);
	cli_clear_history();
	cli_clear_display();

	if (val) free(val);
	if (sess) {
		if (sess->logger)
			log_unregister_output(sess->logger);
		if (sess->keymap)
			cli_keymap_free(sess->keymap);
		if (sess->the_prompt)
			free(sess->the_prompt);
		if (sess->line_buffer)
			free(sess->line_buffer);
		if (sess->vis_lbreaks)
			free(sess->vis_lbreaks);
		if (sess->inv_lbreaks)
			free(sess->inv_lbreaks);
		ui_end_session((ui_session_t *)sess);
		free(sess);
	}
}

static int cli_is_quote_char(char ch)
{
	const char *wbc = rl_completer_quote_characters;

	while (*wbc) {
		if (ch == *wbc) {
			return 1;
		}
		wbc++;
	}
	return 0;
}

static int cli_skip_single_quoted(char *string, size_t slen, int sind)
{
	register int c;

	c = sind;
	while (string[c] && string[c] != '\'')
		c++;

	if (string[c])
		c++;
	return c;
}

static int cli_skip_double_quoted(char *string, size_t slen, int sind)
{
	int c, i;
	int pass_next, backquote;

	pass_next = backquote = 0;
	i = sind;
	while ((c = string[i])) {
		if (pass_next) {
			pass_next = 0;
			i++;
			continue;
		} else if (c == '\\') {
			pass_next++;
			i++;
			continue;
		} else if (backquote) {
			if (c == '`')
				backquote = 0;
			i++;
			continue;
		} else if (c == '`') {
			backquote++;
			i++;
			continue;
		} else if (c != '"') {
			i++;
			continue;
		} else {
			break;
		}
	}

	if (c) i++;
	return i;
}

/* Return 1 if the portion of STRING ending at EINDEX is quoted (there
 * is an unclosed quoted string), or if the character at EINDEX is
 * quoted by a backslash. The characters that this recognizes need to
 * be the same as the contents of rl_completer_quote_characters. 
 */
static int cli_char_is_quoted(char *string, int eindex)
{
	int i, pass_next, c;
	size_t slen;

	slen = strlen (string);
	i = pass_next = 0;
	while (i <= eindex) {
		c = string[i];

		if (pass_next) { 
			pass_next = 0;
			if (i >= eindex)	/* XXX was if (i >= eindex - 1) */
				return 1;
			i++;
			continue;
		} else if (c == '\\') {
			pass_next = 1;
			i++;
			continue;
		} else if (c == '\'' || c == '"') {
			i = (c == '\'') ? cli_skip_single_quoted (string, slen, ++i)
				: cli_skip_double_quoted (string, slen, ++i);
			if (i > eindex)
				return 1;
			/* no increment, the skip_xxx functions go one past end */
		} else {
			i++;
		}
	}
	return 0;
}

int cli_buffer_to_argv(char *start, char *end, char *argv[], int argv_len)
{
	char *c;
	char buf[100];
	int i = 0;
	int argc = 0;
	int arg;
	int in_break = 0;
	int close_char = '\0';

	if (start == NULL)
		goto out;

	if ((start[0] == ' ') || (start[0] == '\t'))
		in_break = 1;
	if (start[0] == '#')
		goto out;

	for (c = start; c < end; c++) {
		if (cli_is_quote_char(*c)) {
			if (close_char == *c)
				close_char = '\0';
			else
				close_char = *c;
		}
		if (((*c == ' ') || (*c == '\t')) && (close_char == '\0')) {
			if (!in_break) {
				buf[i] = '\0';
				argv[argc++] = strdup(buf);
				i = 0;
			}
			in_break = 1;
		} else {
			buf[i++] = *c;
			in_break = 0;
			if (i == (sizeof(buf) - 1))
				break;
		}
	}
	buf[i] = '\0';
	argv[argc++] = strdup(buf);

out:
	if (close_char != '\0') {
		for (arg = 0; arg < argc; arg++)
			free(argv[arg]);
		return -EAGAIN;
	}
	return argc;
}

static cli_ioterm_t *cli_stream_by_name(const char *name)
{
	cli_ioterm_t *s;

	for_each_stream(s) {
		if (s && strcasecmp(name, s->io->name) == 0)
			return s;
	}
	return NULL;
}

int cli_register_stream(cli_stream_t *stream)
{
	cli_ioterm_t *io;

	if (cli_stream_by_name(stream->name))
		return -1;

	io = malloc(sizeof (cli_ioterm_t));
	if (io) {
		memset(io, 0, sizeof (cli_ioterm_t));
		io->io = stream;
		io->state = CLI_INPUT_STOPPED;
		list_init(&io->link);
		list_insert_before(&io->link, &cli_streams);
		return 0;
	}
	return -1;
}

void cli_unregister_stream(cli_stream_t *stream)
{
	cli_ioterm_t *io;

	io = cli_stream_by_name(stream->name);
	if (io) {
		list_delete_init(&io->link);
		free(io);
	}
}

int cli_term_start(void)
{
	cli_ioterm_t *s;

	for_each_stream(s) {
		if (s->state == CLI_INPUT_STOPPED && s->io->start) {
			s->state = CLI_INPUT_STARTING;
			if (s->io->start()) {
				s->state = CLI_INPUT_STOPPED;
			} else {
				s->state = CLI_INPUT_STARTED;
			}
		}
	}
	return 0;
}

void cli_term_stop(void)
{
	cli_ioterm_t *s;

	for_each_stream(s) {
		if (s->state == CLI_INPUT_STARTED && s->io->stop) {
			s->state = CLI_INPUT_STOPPING;
			s->io->stop();
			s->state = CLI_INPUT_STOPPED;
		}
	}
}
