#include "cli_priv.h"

#define _rl_find_prev_mbchar(b, i, f)		(((i) == 0) ? (i) : ((i) - 1))
#define _rl_find_next_mbchar(b, i1, i2, f)	((i1) + (i2))

/* **************************************************************** */
/*			Insert and Delete			    */
/* **************************************************************** */

/* Insert a string of text into the line at point.  This is the only
   way that you should do insertion.  _rl_insert_char () calls this
   function.  Returns the number of characters inserted. */
int rl_insert_text(cli_session_t *sess, const char *string)
{
	register int i, l;
	
	l = (string && *string) ? strlen (string) : 0;
	if (l == 0)
		return 0;
	
	if (sess->end + l >= sess->line_buffer_len)
		rl_extend_line_buffer(sess, sess->end + l);
	
	for (i = sess->end; i >= sess->point; i--)
		sess->line_buffer[i + l] = sess->line_buffer[i];
	strncpy(sess->line_buffer + sess->point, string, l);
	
	/* Remember how to undo this if we aren't undoing something. */
	if (sess->doing_an_undo == 0) {
		/* If possible and desirable, concatenate the undos. */
		if ((l == 1) &&
			sess->undo_list &&
			(sess->undo_list->what == CLI_UNDO_INSERT) &&
			(sess->undo_list->end == sess->point) &&
			(sess->undo_list->end - sess->undo_list->start < 20))
			sess->undo_list->end++;
		else
			rl_add_undo(sess, CLI_UNDO_INSERT, sess->point,
				    sess->point + l, (char *)NULL);
	}
	sess->point += l;
	sess->end += l;
	sess->line_buffer[sess->end] = '\0';
	return l;
}

/* Delete the string between FROM and TO.  FROM is inclusive, TO is not.
 * Returns the number of characters deleted.
 */
int rl_delete_text(cli_session_t *sess, int from, int to)
{
	register char *text;
	register int diff, i;
	
	/* Fix it if the caller is confused. */
	if (from > to)
		SWAP(from, to);
	
	/* fix boundaries */
	if (to > sess->end) {
		to = sess->end;
		if (from > to)
			from = to;
	}
	if (from < 0)
		from = 0;
	
	text = rl_copy_text(sess, from, to);
	
	/* Some versions of strncpy() can't handle overlapping arguments. */
	diff = to - from;
	for (i = from; i < sess->end - diff; i++)
		sess->line_buffer[i] = sess->line_buffer[i + diff];
	
	/* Remember how to undo this delete. */
	if (sess->doing_an_undo == 0)
		rl_add_undo(sess, CLI_UNDO_DELETE, from, to, text);
	else
		free(text);
	
	sess->end -= diff;
	sess->line_buffer[sess->end] = '\0';
	return (diff);
}

/* Fix up point so that it is within the line boundaries after killing
 * text.  If FIX_MARK_TOO is non-zero, the mark is forced within line
 * boundaries also.
 */
#define _RL_FIX_POINT(x, e)		\
	do {				\
		if (x > e)		\
			x = e;	\
		else if (x < 0)		\
			x = 0;		\
	} while (0)

void _rl_fix_point(cli_session_t *sess, int fix_mark_too)
{
	_RL_FIX_POINT(sess->point, sess->end);
	if (fix_mark_too)
		_RL_FIX_POINT(sess->mark, sess->end);
}
#undef _RL_FIX_POINT

/* Replace the contents of the line buffer between START and END with
   TEXT.  The operation is undoable.  To replace the entire line in an
   undoable mode, use _rl_replace_text(text, 0, end); */
int _rl_replace_text(cli_session_t *sess, const char *text, int start, int end)
{
	int n;
	
	rl_begin_undo_group(sess);
	rl_delete_text(sess, start, end + 1);
	sess->point = start;
	n = rl_insert_text(sess, text);
	rl_end_undo_group(sess);
	return n;
}

/* Replace the current line buffer contents with TEXT.  If CLEAR_UNDO is
   non-zero, we free the current undo list. */
void rl_replace_line(cli_session_t *sess, const char *text, int clear_undo)
{
	int len;
	
	len = strlen(text);
	if (len >= sess->line_buffer_len)
		rl_extend_line_buffer(sess, len);
	strcpy(sess->line_buffer, text);
	sess->end = len;
	
	if (clear_undo)
		rl_free_undo_list(sess);
	
	_rl_fix_point(sess, 1);
}

/* **************************************************************** */
/*			Readline character functions		    */
/* **************************************************************** */

/* This is not a gap editor, just a stupid line input routine.  No hair
   is involved in writing any of the functions, and none should be. */

/* Note that:

   end is the place in the string that we would place '\0';
   i.e., it is always safe to place '\0' there.

   point is the place in the string where the cursor is.  Sometimes
   this is the same as end.

   Any command that is called interactively receives two arguments.
   The first is a count: the numeric arg pased to this command.
   The second is the key which invoked this command.
*/

/* **************************************************************** */
/*			Movement Commands			    */
/* **************************************************************** */

/* Note that if you `optimize' the display for these functions, you cannot
   use said functions in other functions which do not do optimizing display.
   I.e., you will have to update the data base for rl_redisplay, and you
   might as well let rl_redisplay do that job. */

/* Move forward COUNT bytes. */
int cli_forward_byte(cli_session_t *sess, int count, int key)
{
	if (count < 0)
		return (cli_backward_byte(sess, -count, key));
	
	if (count > 0) {
		int end = sess->point + count;
		int lend = sess->end;
		if (end > lend) {
			sess->point = lend;
			cli_ding(sess);
		} else {
			sess->point = end;
		}
	}
	
	if (sess->end < 0)
		sess->end = 0;
	return 0;
}

int cli_forward_char(cli_session_t *sess, int count, int key)
{
	return (cli_forward_byte(sess, count, key));
}

/* Move backward COUNT bytes. */
int cli_backward_byte(cli_session_t *sess, int count, int key)
{
	if (count < 0)
		return (cli_forward_byte(sess, -count, key));
	
	if (count > 0) {
		if (sess->point < count) {
			sess->point = 0;
			cli_ding(sess);
		}
		else
			sess->point -= count;
	}
	
	if (sess->point < 0)
		sess->point = 0;
	return 0;
}

int cli_backward_char(cli_session_t *sess, int count, int key)
{
	return (cli_backward_byte(sess, count, key));
}

/* Move to the beginning of the line. */
int cli_beg_of_line(cli_session_t *sess, int count, int key)
{
	sess->point = 0;
	return 0;
}

/* Move to the end of the line. */
int cli_end_of_line(cli_session_t *sess, int count, int key)
{
	sess->point = sess->end;
	return 0;
}

/* Move forward a word.  We do what Emacs does.  Handles multibyte chars. */
int cli_forward_word(cli_session_t *sess, int count, int key)
{
	int c;
	
	if (count < 0)
		return (cli_backward_word(sess, -count, key));
	
	while (count) {
		if (sess->point == sess->end)
			return 0;
		
		/* If we are not in a word, move forward until we are in one.
		   Then, move forward until we hit a non-alphabetic character. */
		c = _rl_char_value(sess->line_buffer, sess->point);
		
		if (_rl_walphabetic (c) == 0) {
			sess->point = MB_NEXTCHAR(sess->line_buffer,
						     sess->point, 1,
						     MB_FIND_NONZERO);
			while (sess->point < sess->end) {
				c = _rl_char_value(sess->line_buffer, sess->point);
				if (_rl_walphabetic(c))
					break;
				sess->point = MB_NEXTCHAR(sess->line_buffer,
							     sess->point, 1,
							     MB_FIND_NONZERO);
			}
		}
		
		if (sess->point == sess->end)
			return 0;
		
		sess->point = MB_NEXTCHAR(sess->line_buffer, sess->point, 1,
					     MB_FIND_NONZERO);
		while (sess->point < sess->end) {
			c = _rl_char_value(sess->line_buffer, sess->point);
			if (_rl_walphabetic(c) == 0)
				break;
			sess->point = MB_NEXTCHAR(sess->line_buffer,
						     sess->point, 1,
						     MB_FIND_NONZERO);
		}
		
		--count;
	}
	
	return 0;
}

/* Move backward a word.  We do what Emacs does.  Handles multibyte chars. */
int cli_backward_word(cli_session_t *sess, int count, int key)
{
	int c, p;
	
	if (count < 0)
		return (cli_forward_word(sess, -count, key));
	
	while (count) {
		if (sess->point == 0)
			return 0;
		
		/* Like cli_forward_word (), except that we look at the characters
		   just before point. */
		
		p = MB_PREVCHAR(sess->line_buffer, sess->point, MB_FIND_NONZERO);
		c = _rl_char_value(sess->line_buffer, p);
		
		if (_rl_walphabetic(c) == 0) {
			sess->point = p;
			while (sess->point > 0) {
				p = MB_PREVCHAR(sess->line_buffer,
						sess->point, MB_FIND_NONZERO);
				c = _rl_char_value(sess->line_buffer, p);
				if (_rl_walphabetic(c))
					break;
				sess->point = p;
			}
		}
		
		while (sess->point) {
			p = MB_PREVCHAR(sess->line_buffer, sess->point,
					MB_FIND_NONZERO);
			c = _rl_char_value(sess->line_buffer, p);	  
			if (_rl_walphabetic(c) == 0)
				break;
			else
				sess->point = p;
		}
		
		--count;
	}
	
	return 0;
}

/* C-l typed to a line without quoting clears the screen, and then reprints
   the prompt and the current input line.  Given a numeric arg, redraw only
   the current line. */
int cli_clear_screen(cli_session_t *sess, int count, int key)
{
	_rl_clear_screen(sess);		/* calls termcap function to clear screen */
	rl_forced_update_display(sess);
	rl_display_fixed = 1;
	
	return 0;
}

/* **************************************************************** */
/*			Text commands				    */
/* **************************************************************** */

/* Insert the character C at the current location, moving point forward.
   If C introduces a multibyte sequence, we read the whole sequence and
   then insert the multibyte char into the line buffer. */
int _rl_insert_char(cli_session_t *sess, int count, int c)
{
	register int i;
	char *string;

	if (count <= 0)
		return 0;
	
	/* If we can optimize, then do it.  But don't let people crash
	   readline because of extra large arguments. */
	if (count > 1 && count <= 1024) {
		string = (char *)malloc(1 + count);
		
		for (i = 0; i < count; i++)
			string[i] = c;
		string[i] = '\0';
		rl_insert_text(sess, string);
		free(string);
		
		return 0;
	}
	
	if (count > 1024) {
		int decreaser;
		char str[1024+1];
		
		for (i = 0; i < 1024; i++)
			str[i] = c;
		
		while (count) {
			decreaser = (count > 1024 ? 1024 : count);
			str[decreaser] = '\0';
			rl_insert_text(sess, str);
			count -= decreaser;
		}
		
		return 0;
	}
	
	if (_rl_any_typein())
		_rl_insert_typein(sess, c);
	else {
		/* Inserting a single character. */
		char str[2];
		
		str[1] = '\0';
		str[0] = c;
		rl_insert_text(sess, str);
	}

	return 0;
}

/* Overwrite the character at point (or next COUNT characters) with C.
   If C introduces a multibyte character sequence, read the entire sequence
   before starting the overwrite loop. */
int _rl_overwrite_char(cli_session_t *sess, int count, int c)
{
	int i;
	
	rl_begin_undo_group(sess);
	for (i = 0; i < count; i++) {
		_rl_insert_char(sess, 1, c);
		if (sess->point < sess->end)
			cli_delete(sess, 1, c);
	}
	rl_end_undo_group(sess);
	return 0;
}

int cli_insert(cli_session_t *sess, int count, int c)
{
	return (sess->insert_mode == \
		RL_IM_INSERT ? _rl_insert_char(sess, count, c) : \
		_rl_overwrite_char(sess, count, c));
}

/* Insert a tab character. */
int cli_tab_insert(cli_session_t *sess, int count, int key)
{
	return (_rl_insert_char(sess, count, '\t'));
}

/* What to do when a NEWLINE is pressed.  We accept the whole line.
   KEY is the key that invoked this command.  I guess it could have
   meaning in the future. */
int cli_newline(cli_session_t *sess, int count, int key)
{
	sess->done = 1;

#ifdef CONFIG_CLI_HISTORY
	if (_rl_history_preserve_point)
		_rl_history_saved_point = \
			(sess->point == sess->end) ? -1 : sess->point;
#endif
	
	RL_SETSTATE(sess, RL_STATE_DONE);
	
	/* If we've been asked to erase empty lines, suppress the final
	 * update, since _rl_update_final calls cli_crlf().
	 */
	if (sess->erase_empty_line && sess->point == 0 && sess->end == 0)
		return 0;
	
	if (sess->echoing_p)
		_rl_update_final(sess);
	return 0;
}

/* This is different from what vi does, so the code's not shared.  Emacs
   rubout in overwrite mode has one oddity:  it replaces a control
   character that's displayed as two characters (^X) with two spaces. */
int _rl_overwrite_rubout(cli_session_t *sess, int count, int key)
{
	int opoint;
	int i, l;
	
	if (sess->point == 0) {
		cli_ding(sess);
		return 1;
	}
	
	opoint = sess->point;
	
	/* L == number of spaces to insert */
	for (i = l = 0; i < count; i++) {
		cli_backward_char(sess, 1, key);
		l += rl_character_len(sess,
				      sess->line_buffer[sess->point],
				      sess->point);	/* not exactly right */
	}
	
	rl_begin_undo_group(sess);
	
	if (count > 1)
		cli_kill_text(sess, opoint, sess->point);
	else
		rl_delete_text(sess, opoint, sess->point);
	
	/* Emacs puts point at the beginning of the sequence of spaces. */
	if (sess->point < sess->end) {
		opoint = sess->point;
		_rl_insert_char(sess, l, ' ');
		sess->point = opoint;
	}
	
	rl_end_undo_group(sess);
	
	return 0;
}
  
/* Rubout the character behind point. */
int cli_rubout(cli_session_t *sess, int count, int key)
{
	if (count < 0)
		return (cli_delete(sess, -count, key));
	
	if (!sess->point) {
		cli_ding(sess);
		return -1;
	}
	
	if (sess->insert_mode == RL_IM_OVERWRITE)
		return (_rl_overwrite_rubout(sess, count, key));
	
	return (_rl_rubout_char(sess, count, key));
}

int _rl_rubout_char(cli_session_t *sess, int count, int key)
{
	int orig_point;
	unsigned char c;
	
	/* Duplicated code because this is called from other parts of the library. */
	if (count < 0)
		return (cli_delete(sess, -count, key));
	
	if (sess->point == 0) {
		cli_ding(sess);
		return -1;
	}
	
	orig_point = sess->point;
	if (count > 1) {
		cli_backward_char(sess, count, key);
		cli_kill_text(sess, orig_point, sess->point);
	} else {
		c = sess->line_buffer[--sess->point];
		rl_delete_text(sess, sess->point, orig_point);
		/* The erase-at-end-of-line hack is of questionable merit now. */
		if (sess->point == sess->end && ISPRINT(c) && _rl_last_c_pos) {
			int l;
			l = rl_character_len(sess, c, sess->point);
			_rl_erase_at_end_of_line(sess, l);
		}
	} 
	
	return 0;
}

/* Delete the character under the cursor.  Given a numeric argument,
 * kill that many characters instead.
 */
int cli_delete(cli_session_t *sess, int count, int key)
{
	int xpoint;
	
	if (count < 0)
		return (_rl_rubout_char(sess, -count, key));
	
	if (sess->point == sess->end) {
		cli_ding(sess);
		return -1;
	}
	
	if (count > 1) {
		xpoint = sess->point;
		cli_forward_byte(sess, count, key);
		
		cli_kill_text(sess, xpoint, sess->point);
		sess->point = xpoint;
	} else {
		xpoint = MB_NEXTCHAR(sess->line_buffer, sess->point, 1,
				     MB_FIND_NONZERO);
		rl_delete_text(sess, sess->point, xpoint);
	}
	return 0;
}

/* Add TEXT to the kill ring, allocating a new kill ring slot as necessary.
   This uses TEXT directly, so the caller must not free it.  If APPEND is
   non-zero, and the last command was a kill, the text is appended to the
   current kill ring slot, otherwise prepended. */
static int cli_kill_ring_append(cli_session_t *sess, char *text, int append)
{
	char *old, *new;
	int slot;
	
	/* First, find the slot to work with. */
	if (sess->last_command_was_kill == 0) {
		/* Get a new slot.  */
		if (sess->kill_ring == 0) {
			/* If we don't have any defined, then make one. */
			sess->kill_ring = (char **)
				malloc(((sess->kill_ring_length = 1) + 1) * sizeof (char *));
			sess->kill_ring[slot = 0] = (char *)NULL;
		} else {
			/* We have to add a new slot on the end, unless we have
			   exceeded the max limit for remembering kills. */
			slot = sess->kill_ring_length;
			if (slot == cli_main_config.max_kills) {
				int i;
				free(sess->kill_ring[0]);
				for (i = 0; i < slot; i++)
					sess->kill_ring[i] = sess->kill_ring[i + 1];
			} else {
				slot = sess->kill_ring_length += 1;
				sess->kill_ring = (char **)realloc(sess->kill_ring, slot * sizeof (char *));
			}
			sess->kill_ring[--slot] = (char *)NULL;
		}
	} else {
		slot = sess->kill_ring_length - 1;
	}
	
	/* If the last command was a kill, prepend or append. */
	if (sess->last_command_was_kill) {
		old = sess->kill_ring[slot];
		new = (char *)malloc(1 + strlen (old) + strlen (text));
		
		if (append) {
			strcpy(new, old);
			strcat(new, text);
		} else {
			strcpy(new, text);
			strcat(new, old);
		}
		free(old);
		free(text);
		sess->kill_ring[slot] = new;
	} else
		sess->kill_ring[slot] = text;
	
	sess->kill_index = slot;
	return 0;
}

/* The way to kill something.  This appends or prepends to the last
   kill, if the last command was a kill command.  if FROM is less
   than TO, then the text is appended, otherwise prepended.  If the
   last command was not a kill command, then a new slot is made for
   this kill. */
int cli_kill_text(cli_session_t *sess, int from, int to)
{
	char *text;
	
	/* Is there anything to kill? */
	if (from == to) {
		sess->last_command_was_kill++;
		return 0;
	}
	
	text = rl_copy_text(sess, from, to);
	
	/* Delete the copied text from the line. */
	rl_delete_text(sess, from, to);
	
	cli_kill_ring_append(sess, text, from < to);
	
	sess->last_command_was_kill++;
	return 0;
}

/* Delete the word at point, saving the text in the kill ring. */
int cli_kill_word(cli_session_t *sess, int count, int key)
{
	int orig_point;
	
	if (count < 0)
		return (cli_backward_kill_word(sess, -count, key));
	else {
		orig_point = sess->point;
		cli_forward_word(sess, count, key);
		
		if (sess->point != orig_point)
			cli_kill_text(sess, orig_point, sess->point);
		
		sess->point = orig_point;
		sess->mark = sess->point;
	}
	return 0;
}

/* Rubout the word before point, placing it on the kill ring. */
int cli_backward_kill_word(cli_session_t *sess, int count, int ignore)
{
	int orig_point;
	
	if (count < 0)
		return (cli_kill_word(sess, -count, ignore));
	else {
		orig_point = sess->point;
		cli_backward_word(sess, count, ignore);
		
		if (sess->point != orig_point)
			cli_kill_text(sess, orig_point, sess->point);
		
		sess->mark = sess->point;
	}
	return 0;
}

/* Kill from here to the end of the line.  If DIRECTION is negative, kill
   back to the line start instead. */
int cli_kill_line(cli_session_t *sess, int direction, int ignore)
{
	int orig_point;
	
	if (direction < 0)
		return (cli_backward_kill_line(sess, 1, ignore));
	else {
		orig_point = sess->point;
		cli_end_of_line(sess, 1, ignore);
		if (orig_point != sess->point)
			cli_kill_text(sess, orig_point, sess->point);
		sess->point = orig_point;
		sess->mark = sess->point;
	}
	return 0;
}

/* Kill backwards to the start of the line.  If DIRECTION is negative, kill
   forwards to the line end instead. */
int cli_backward_kill_line(cli_session_t *sess, int direction, int ignore)
{
	int orig_point;
	
	if (direction < 0)
		return (cli_kill_line(sess, 1, ignore));
	else {
		if (!sess->point)
			cli_ding(sess);
		else {
			orig_point = sess->point;
			cli_beg_of_line(sess, 1, ignore);
			if (sess->point != orig_point)
				cli_kill_text(sess, orig_point, sess->point);
			sess->mark = sess->point;
		}
	}
	return 0;
}

/* The next two functions mimic unix line editing behaviour, except they
   save the deleted text on the kill ring.  This is safer than not saving
   it, and since we have a ring, nobody should get screwed. */

/* This does what C-w does in Unix.  We can't prevent people from
   using behaviour that they expect. */
int cli_unix_word_rubout(cli_session_t *sess, int count, int key)
{
	int orig_point;
	
	if (sess->point == 0)
		cli_ding(sess);
	else {
		orig_point = sess->point;
		if (count <= 0)
			count = 1;
		
		while (count--) {
			while (sess->point && whitespace(sess->line_buffer[sess->point - 1]))
				sess->point--;
			
			while (sess->point && (whitespace(sess->line_buffer[sess->point - 1]) == 0))
				sess->point--;
		}
		
		cli_kill_text(sess, orig_point, sess->point);
		sess->mark = sess->point;
	}
	
	return 0;
}

/* Here is C-u doing what Unix does.  You don't *have* to use these
   key-bindings.  We have a choice of killing the entire line, or
   killing from where we are to the start of the line.  We choose the
   latter, because if you are a Unix weenie, then you haven't backspaced
   into the line at all, and if you aren't, then you know what you are
   doing. */
int cli_unix_line_discard(cli_session_t *sess, int count, int key)
{
	if (sess->point == 0)
		cli_ding(sess);
	else {
		cli_kill_text(sess, sess->point, 0);
		sess->point = 0;
		sess->mark = sess->point;
	}
	return 0;
}

static cli_undo_t *alloc_undo_entry(int what, int start, int end, char *text)
{
	cli_undo_t *temp;
	
	temp = (cli_undo_t *)malloc(sizeof(cli_undo_t));
	temp->what = what;
	temp->start = start;
	temp->end = end;
	temp->text = text;
	
	temp->next = (cli_undo_t *)NULL;
	return temp;
}

/* Remember how to undo something.  Concatenate some undos if that
   seems right. */
void rl_add_undo(cli_session_t *sess, int what,
		 int start, int end, char *text)
{
	cli_undo_t *temp;
	
	temp = alloc_undo_entry(what, start, end, text);
	temp->next = sess->undo_list;
	sess->undo_list = temp;
}

/* Free the existing undo list. */
void rl_free_undo_list(cli_session_t *sess)
{
	cli_undo_t *release, *orig_list;
	
	orig_list = sess->undo_list;
	while (sess->undo_list) {
		release = sess->undo_list;
		sess->undo_list = sess->undo_list->next;
		
		if (release->what == CLI_UNDO_DELETE)
			free(release->text);
		
		free(release);
	}
	sess->undo_list = (cli_undo_t *)NULL;
#ifdef CONFIG_CLI_HISTORY
	replace_history_data(-1, (histdata_t *)orig_list, (histdata_t *)NULL);
#endif
}

cli_undo_t *_rl_copy_undo_entry(cli_undo_t *entry)
{
	cli_undo_t *new;
	
	new = alloc_undo_entry(entry->what, entry->start, entry->end, (char *)NULL);
	new->text = entry->text ? savestring(entry->text) : 0;
	return new;
}

cli_undo_t *_rl_copy_undo_list(cli_undo_t *head)
{
	cli_undo_t *list, *new, *roving, *c;
	
	list = head;
	new = 0;
	roving = 0;
	while (list) {
		c = _rl_copy_undo_entry(list);
		if (new == 0)
			roving = new = c;
		else {
			roving->next = c;
			roving = roving->next;
		}
		list = list->next;
	}
	
	roving->next = 0;
	return new;
}

/* Undo the next thing in the list.  Return 0 if there
   is nothing to undo, or non-zero if there was. */
int rl_do_undo(cli_session_t *sess)
{
	cli_undo_t *release;
	int waiting_for_begin, start, end;
	
#define TRANS(s, i) ((i) == -1 ? s->point : ((i) == -2 ? s->end : (i)))

	start = end = waiting_for_begin = 0;
	do {
		if (!sess->undo_list)
			return (0);
		
		sess->doing_an_undo = 1;
		RL_SETSTATE(sess, RL_STATE_UNDOING);
		
		/* To better support vi-mode, a start or end value of -1
		 * means point, and a value of -2 means rl_end.
		 */
		if (sess->undo_list->what == CLI_UNDO_DELETE ||
		    sess->undo_list->what == CLI_UNDO_INSERT) {
			start = TRANS(sess, sess->undo_list->start);
			end = TRANS(sess, sess->undo_list->end);
		}
		
		switch (sess->undo_list->what) {
			/* Undoing deletes means inserting some text. */
			case CLI_UNDO_DELETE:
				sess->point = start;
				rl_insert_text(sess, sess->undo_list->text);
				free(sess->undo_list->text);
				break;
				
			/* Undoing inserts means deleting some text. */
			case CLI_UNDO_INSERT:
				rl_delete_text(sess, start, end);
				sess->point = start;
				break;
				
			/* Undoing an END means undoing everything 'til we get to a BEGIN. */
			case CLI_UNDO_END:
				waiting_for_begin++;
				break;
				
			/* Undoing a BEGIN means that we are done with this group. */
			case CLI_UNDO_BEGIN:
				if (waiting_for_begin)
					waiting_for_begin--;
				else
					cli_ding(sess);
				break;
		}
		
		sess->doing_an_undo = 0;
		RL_UNSETSTATE(sess, RL_STATE_UNDOING);
		
		release = sess->undo_list;
		sess->undo_list = sess->undo_list->next;
#ifdef CONFIG_CLI_HISTORY
		replace_history_data(-1, (histdata_t *)release, (histdata_t *)sess->undo_list);
#endif
		free(release);
	}
	while (waiting_for_begin);
	
	return (1);
}
#undef TRANS

/* Begin a group.  Subsequent undos are undone as an atomic operation. */
int rl_begin_undo_group(cli_session_t *sess)
{
	rl_add_undo(sess, CLI_UNDO_BEGIN, 0, 0, 0);
	sess->undo_group_level++;
	return 0;
}

/* End an undo group started with rl_begin_undo_group (). */
int rl_end_undo_group(cli_session_t *sess)
{
	rl_add_undo(sess, CLI_UNDO_END, 0, 0, 0);
	sess->undo_group_level--;
	return 0;
}

/* Revert the current line to its previous state. */
int cli_revert_line(cli_session_t *sess, int count, int key)
{
	if (!sess->undo_list)
		cli_ding(sess);
	else {
		while (sess->undo_list)
			rl_do_undo(sess);
	}
	return 0;
}

/* Do some undoing of things that were done. */
int cli_undo_command(cli_session_t *sess, int count, int key)
{
	if (count < 0)
		return 0;	/* Nothing to do. */
	
	while (count) {
		if (rl_do_undo(sess))
			count--;
		else {
			cli_ding(sess);
			break;
		}
	}
	return 0;
}

void _rl_set_insert_mode(cli_session_t *sess, int im, int force)
{
	sess->insert_mode = im;
}
