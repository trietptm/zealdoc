#define READLINE_LIBRARY

#include "cli_priv.h"

/* What kind of non-blocking I/O do we have? */
#if !defined (O_NDELAY) && defined(O_NONBLOCK)
#  define O_NDELAY O_NONBLOCK	/* Posix style */
#endif

static int ibuffer_space(void);
static int rl_get_char(int *);
#if 0
static int rl_gather_tyi(cli_session_t *sess);
#endif

/* **************************************************************** */
/*								    */
/*			Character Input Buffering       	    */
/*								    */
/* **************************************************************** */

static int pop_index, push_index;
static unsigned char ibuffer[512];
static int ibuffer_len = sizeof(ibuffer) - 1;

#define any_typein	(push_index != pop_index)

int _rl_any_typein(void)
{
	return any_typein;
}

/* Return the amount of space available in the buffer for stuffing
   characters. */
static int ibuffer_space(void)
{
	if (pop_index > push_index)
		return(pop_index - push_index - 1);
	else
		return(ibuffer_len - (push_index - pop_index));
}

/* Get a key from the buffer of characters to be read.
   Return the key in KEY.
   Result is KEY if there was a key, or 0 if there wasn't. */
static int rl_get_char(int *key)
{
	if (push_index == pop_index)
		return (0);
	
	*key = ibuffer[pop_index++];
	
	if (pop_index >= ibuffer_len)
		pop_index = 0;
	
	return (1);
}

/* Stuff KEY into the *front* of the input buffer.
   Returns non-zero if successful, zero if there is
   no space left in the buffer. */
int _rl_unget_char(int key)
{
	if (ibuffer_space()) {
		pop_index--;
		if (pop_index < 0)
			pop_index = ibuffer_len - 1;
		ibuffer[pop_index] = key;
		return (1);
	}
	return (0);
}

#ifndef WIN32
#if 0
/* If a character is available to be read, then read it and stuff it into
   IBUFFER.  Otherwise, just return.  Returns number of characters read
   (0 if none available) and -1 on error (EIO). */
static int rl_gather_tyi(cli_session_t *sess)
{
	int tty;
	register int tem, result;
	int chars_avail, k;
	char input;

	tty = sess->rl_instream;
	result = -1;
#if defined(FIONREAD)
	errno = 0;
	result = ioctl(tty, FIONREAD, &chars_avail);
	if (result == -1 && errno == EIO)
		return -1;
#endif

#if defined(O_NDELAY)
	if (result == -1) {
		tem = fcntl(tty, F_GETFL, 0);
		
		fcntl(tty, F_SETFL, (tem | O_NDELAY));
		chars_avail = read(tty, &input, 1);
		
		fcntl(tty, F_SETFL, tem);
		if (chars_avail == -1 && errno == EAGAIN)
			return 0;
		if (chars_avail == 0) {	/* EOF */
			cli_stuff_char(sess, EOF);
			return (0);
		}
	}
#endif /* O_NDELAY */

	/* If there's nothing available, don't waste time trying to read
	   something. */
	if (chars_avail <= 0)
		return 0;
	
	tem = ibuffer_space();
	
	if (chars_avail > tem)
		chars_avail = tem;
	
	/* One cannot read all of the available input.  I can only read a single
	   character at a time, or else programs which require input can be
	   thwarted.  If the buffer is larger than one character, I lose.
	   Damn! */
	if (tem < ibuffer_len)
		chars_avail = 0;
	
	if (result != -1) {
		while (chars_avail--) {
			k = rl_getc(sess->rl_instream);
			cli_stuff_char(sess, k);
			if (k == NEWLINE || k == RETURN)
				break;
		}
	} else {
		if (chars_avail)
			cli_stuff_char(sess, input);
	}
	
	return 1;
}
#endif

int _rl_input_available(cli_session_t *sess)
{
	int chars_avail;
	int tty;
	
	tty = sess->rl_instream;
	
#if defined(FIONREAD)
	if (ioctl(tty, FIONREAD, &chars_avail) == 0)
		return (chars_avail);
#endif
	
	return 0;
}
#else
static int rl_gather_tyi(cli_session_t *sess)
{
	int count = 0;
	while (isatty(sess->rl_instream) && kbhit() && ibuffer_space()) {
		cli_stuff_char(sess, rl_getc(sess->rl_instream));
		count++;
	}
	return count;
}

int _rl_input_available(cli_session_t *sess)
{
	if (isatty(sess->rl_instream))
		return (kbhit());
	return 0;
}
#endif

void _rl_insert_typein(cli_session_t *sess, int c)
{    	
	int key, t, i;
	char *string;
	
	i = key = 0;
	string = (char *)malloc(ibuffer_len + 1);
	string[i++] = (char)c;
	
	while ((t = rl_get_char(&key)) &&
		sess->keymap[key].type == ISFUNC &&
		sess->keymap[key].function == cli_insert)
		string[i++] = key;
	
	if (t)
		_rl_unget_char(key);
	
	string[i] = '\0';
	rl_insert_text(sess, string);
	free(string);
}

/* Add KEY to the buffer of characters to be read.  Returns 1 if the
   character was stuffed correctly; 0 otherwise. */
int cli_stuff_char(cli_session_t *sess, int key)
{
	if (ibuffer_space() == 0)
		return 0;
	
	if (key == EOF) {
		key = NEWLINE;
		sess->pending_input = EOF;
		RL_SETSTATE(sess, RL_STATE_INPUTPENDING);
	}
	ibuffer[push_index++] = key;
	if (push_index >= ibuffer_len)
		push_index = 0;
	
	return 1;
}

/* Make C be the next command to be executed. */
int rl_execute_next(cli_session_t *sess, int c)
{
	sess->pending_input = c;
	RL_SETSTATE(sess, RL_STATE_INPUTPENDING);
	return 0;
}

/* Clear any pending input pushed with rl_execute_next() */
int rl_clear_pending_input(cli_session_t *sess)
{
	sess->pending_input = 0;
	RL_UNSETSTATE(sess, RL_STATE_INPUTPENDING);
	return 0;
}

/* **************************************************************** */
/*								    */
/*			     Character Input			    */
/*								    */
/* **************************************************************** */

/* Read a key, including pending input. */
int rl_read_key(cli_session_t *sess)
{
	int c;
	
	sess->key_sequence_length++;
	
	if (sess->pending_input) {
		c = sess->pending_input;
		rl_clear_pending_input(sess);
	} else {
		/* If the user has an event function, then call it periodically. */
		if (rl_get_char(&c) == 0)
			c = rl_getc(sess->rl_instream);
	}
	
	return (c);
}

#ifndef WIN32
int rl_getc(int stream)
{
	int result;
	unsigned char c;
	
	while (1) {
		result = read(stream, &c, sizeof(unsigned char));
		
		if (result == sizeof(unsigned char))
			return (c);
		
		/* If zero characters are returned, then the file that we are
		   reading from is empty!  Return EOF in that case. */
		if (result == 0)
			return (EOF);
#if defined(EWOULDBLOCK)
#  define X_EWOULDBLOCK EWOULDBLOCK
#else
#  define X_EWOULDBLOCK -99
#endif
		
#if defined(EAGAIN)
#  define X_EAGAIN EAGAIN
#else
#  define X_EAGAIN -99
#endif
		
		if (errno == X_EWOULDBLOCK || errno == X_EAGAIN) {
			if (sh_unset_nodelay_mode(stream) < 0)
				return (EOF);
			continue;
		}
		
#undef X_EWOULDBLOCK
#undef X_EAGAIN
		
		/* If the error that we received was SIGINT, then try again,
		   this is simply an interrupted system call to read ().
		   Otherwise, some error ocurred, also signifying EOF. */
		if (errno != EINTR)
			return (EOF);
	}
}
#else
int rl_getc(int stream)
{
	int result;
	unsigned char c;
	
	while (1) {
		result = recv(stream, &c, sizeof(unsigned char), 0);
		if (result == sizeof(unsigned char)) {
			return (c);
		}
		
		/* If zero characters are returned, then the file that we are
		   reading from is empty!  Return EOF in that case. */
		if (result == 0)
			return (EOF);
#if defined(EWOULDBLOCK)
#  define X_EWOULDBLOCK EWOULDBLOCK
#else
#  define X_EWOULDBLOCK -99
#endif
		
#if defined(EAGAIN)
#  define X_EAGAIN EAGAIN
#else
#  define X_EAGAIN -99
#endif
		
		if (errno == X_EWOULDBLOCK || errno == X_EAGAIN) {
			if (sh_unset_nodelay_mode(stream) < 0)
				return (EOF);
			continue;
		}
		
#undef X_EWOULDBLOCK
#undef X_EAGAIN
		
		/* If the error that we received was SIGINT, then try again,
		   this is simply an interrupted system call to read ().
		   Otherwise, some error ocurred, also signifying EOF. */
		if (errno != EINTR)
			return (EOF);
	}
}
#endif
