#include "cli_priv.h"

#define CLI_SERVICE_NAME	"cli"
#define CLI_SERVICE_DESC	"Command line interface"

ui_entry_t *cli_main_section = NULL;

static void cli_conf_str2bell(const char *str, void *data);

static ui_parser_t cli_config_parser[] = {
	{ ".cli.prompt", NULL,
	  offsetof(cli_config_t, prompt), },
	{ ".cli.max_kills", NULL,
	  offsetof(cli_config_t, max_kills), },
	{ ".cli.mark_modified_lines", NULL,
	  offsetof(cli_config_t, mark_modified_lines), },
	{ ".cli.convert_meta_chars", NULL,
	  offsetof(cli_config_t, convert_meta_chars), },
	{ ".cli.bell_type", cli_conf_str2bell,
	  offsetof(cli_config_t, bell_type), },
	{ NULL },
};

static ui_schema_t cli_schema[] = {
	/* .cli */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE,
	  UI_TYPE_STRING, NULL, NULL,
	  ".cli", "cli",
	  CLI_SERVICE_DESC },
	{ UI_TYPE_ATTRIBUTE, UI_FLAG_SINGLE,
	  UI_TYPE_STRING, NULL, CONFIG_PRODUCT_SHORT,
	  ".cli.prompt", "prompt",
	  "Prompt name" },
	{ UI_TYPE_ATTRIBUTE, UI_FLAG_SINGLE,
	  UI_TYPE_INT, NULL, "10",
	  ".cli.max_kills", "max_kills",
	  "Maximum kills" },
	{ UI_TYPE_ATTRIBUTE, UI_FLAG_SINGLE,
	  UI_TYPE_BOOLEAN, NULL, "no",
	  ".cli.mark_modified_lines", "mark_modified_lines",
	  "Mark modified lines" },
	{ UI_TYPE_ATTRIBUTE, UI_FLAG_SINGLE,
	  UI_TYPE_BOOLEAN, NULL, "yes",
	  ".cli.convert_meta_chars", "convert_meta_chars",
	  "Convert META characters to ASCii" },
	{ UI_TYPE_ATTRIBUTE, UI_FLAG_SINGLE,
	  UI_TYPE_CHOICE, "cli_bells", "audible",
	  ".cli.bell_type", "bell_type",
	  "Preferred bell type" },	
	{ UI_TYPE_NONE },
};

cli_config_t cli_main_config;
int cli_logger = 0;

string_map_t cli_bell_types[] = {
	{ "no", NO_BELL, "No bell" },
	{ "audible", AUDIBLE_BELL, "Audible bell" },
	{ "visible", VISIBLE_BELL, "Visible bell" },
	{ NULL, 0, },
};

static int cli_name2bell(const char *str)
{
	return name2int(cli_bell_types, str, AUDIBLE_BELL);
}

static void cli_conf_str2bell(const char *str, void *data)
{
	int *bell = (int *)data;
	*bell = cli_name2bell(str);
}

void cli_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(cli_logger, level, format, ap);
	va_end(ap);
}

log_source_t cli_log_source = {
	"cli",
};

static int __init cli_log_init(void)
{
	cli_logger = log_register_source(&cli_log_source);
	return !cli_logger;
}

static void __exit cli_log_exit(void)
{
	log_unregister_source(cli_logger);
}

static void cli_conf_stop(void)
{
	if (cli_main_section) {
		ui_inst_delete_conf(cli_main_section);
		cli_main_section = NULL;
	}
}

static int cli_conf_start(void)
{
	int rc = 0;
	ui_entry_t *cs;
	const char *oid = "cli";

	if (cli_main_section) return 0;

	memset(&cli_main_config, 0, sizeof(cli_config_t));

	cs = ui_inst_lookup_conf(NULL, oid, NULL);
	if (!cs) {
		cli_log(CLI_LOG_ERR,
			"CONF: cannot find instance, oid=%s", oid);
		return -1;
	}
	rc = ui_load_single_values(cs, &cli_main_config, cli_config_parser);
	if (rc) {
		ui_inst_delete_conf(cs);
		cli_log(CLI_LOG_ERR,
			"CONF: cannot load instance, oid=%s", oid);
		return -1;
	}

	cli_main_section = cs;
	return 0;
}

static int cli_start(void)
{
	cli_conf_start();
	cli_term_start();
	return 0;
}

static void cli_stop(void)
{
	cli_term_stop();
	cli_conf_stop();
}

ui_choice_t cli_bell_choice = {
	"cli_bells",
	cli_bell_types,
	string_map_foreach,
	string_map_name,
	string_map_desc,
};

ui_service_t cli_service = {
	CLI_SERVICE_NAME,
	CLI_SERVICE_DESC,
	cli_start,
	cli_stop,
	cli_printf,
	cli_print_table,
};

#define CLI_OPT_DEBUGGING	0x01
string_map_t cli_options[] = {
	{ "debugging", CLI_OPT_DEBUGGING, "Enable console debugging" },
	{ NULL, 0, },
};

ui_choice_t cli_option_choice = {
	"cli_options",
	cli_options,
	string_map_foreach,
	string_map_name,
	string_map_desc,
};

static int cli_name2option(const char *name)
{
	return name2int(cli_options, name, 0);
}

static int cli_cmd_switch(ui_session_t *s, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int res = 0;
	cli_session_t *sess = (cli_session_t *)s;
	int opt = cli_name2option(argv[0]);

	switch (opt) {
	case CLI_OPT_DEBUGGING:
		if (sess->logger) {
			sess->debugging = !sess->debugging;
			log_set_level(sess->logger, sess->debugging ? LOG_DEBUG : LOG_INFO);
		}
		break;
	default:
		res = -1;
		break;
	}
	return res;
}

ui_argument_t cli_switch_args[] = {
	{ "option",
	  "Command line option",
	  "cli_options",
	  UI_TYPE_CHOICE, },
};

ui_command_t cli_switch_command = {
	"switch",
	"Turn on/off CLI options",
	".cli",
	UI_CMD_SINGLE_INST,
	cli_switch_args,
	1,
	LIST_HEAD_INIT(cli_switch_command.link),
	cli_cmd_switch,
};

static int __init cli_user_init(void)
{
	ui_register_choice(&cli_bell_choice);
	ui_register_choice(&cli_option_choice);
	ui_register_schema(cli_schema);
	ui_register_service(&cli_service);
	ui_register_command(&cli_switch_command);
	return 0;
}

static void __exit cli_user_exit(void)
{
	ui_unregister_command(&cli_switch_command);
	ui_unregister_service(&cli_service);
	ui_unregister_schema(cli_schema);
	ui_unregister_choice(&cli_option_choice);
	ui_unregister_choice(&cli_bell_choice);
}

modlinkage int __init cli_init(void)
{
	cli_log_init();
	cli_user_init();
	return 0;
}

modlinkage void __exit cli_exit(void)
{
	cli_user_exit();
	cli_log_exit();
}

subsys_initcall(cli_init);
subsys_exitcall(cli_exit);
