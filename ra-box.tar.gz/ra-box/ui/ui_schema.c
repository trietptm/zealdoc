#include "ui_priv.h"

typedef struct _ui_range_val_t {
	int r_sign;
	char *r_decimal;
	char *r_integer;
	int r_n_integer;
	int r_n_decimal;
} ui_range_val_t;

/* a flexible object manageability scheme comparing to the ASN.1
 */
ui_schema_t ui_schema_root = {
	UI_TYPE_CLASS, UI_FLAG_SINGLE,
	UI_TYPE_STRING, NULL, NULL,
	".", "", "",
};

ui_node_t ui_schema_tree = {
	(char *)".",
	NOTIFY_HEAD_INIT(ui_schema_tree.oid_chain),
	&ui_schema_root,
	UI_STATE_REGISTERED,
	UI_USAGE_SCHEMA,
	NULL,
	LIST_HEAD_INIT(ui_schema_tree.sibling),
	LIST_HEAD_INIT(ui_schema_tree.children),
};

static ui_node_t *__ui_node_iterate(ui_node_t *node, ui_node_t *iter, 
				    unsigned char forward, int type);
static ui_node_t *ui_node_by_oid_root(ui_node_t *root, const char *oid,
				      int create, int remove);
static void ui_node_free(ui_node_t *node);
static ui_node_t *ui_node_alloc(ui_node_t *parent, const char *oid);\

static int ui_validate_string(ui_entry_t *parent, int type,
			      const char *in, const void *data);
static int ui_validate_instance(ui_entry_t *parent, int type,
				const char *in, const void *data);
static int ui_validate_value(ui_entry_t *parent, int type,
			     const char *in, const void *data);
static int ui_validate_entry(ui_entry_t *parent,
			     const char *in, const void *data);
#if 0
static int ui_validate_nothing(ui_entry_t *parent, int type,
			       const char *in, const void *data);
#endif
static int ui_validate_choice(ui_entry_t *parent, int type,
			      const char *in, const void *name);
static int ui_validate_range(ui_entry_t *parent, int type,
			     const char *in, const void *name);
static int ui_validate_float(ui_entry_t *parent, int type,
			     const char *in, const void *unused);
static int ui_validate_double(ui_entry_t *parent, int type,
			      const char *in, const void *unused);
static int ui_validate_uint8(ui_entry_t *parent, int type,
			     const char *in, const void *unused);
static int ui_validate_uint16(ui_entry_t *parent, int type,
			      const char *in, const void *unused);
static int ui_validate_uint32(ui_entry_t *parent, int type,
			      const char *in, const void *unused);
static int ui_validate_int8(ui_entry_t *parent, int type,
			    const char *in, const void *unused);
static int ui_validate_int16(ui_entry_t *parent, int type,
			     const char *in, const void *unused);
static int ui_validate_int32(ui_entry_t *parent, int type,
			     const char *in, const void *unused);

DECLARE_LIST(ui_syntaxes);
DECLARE_LIST(ui_choices);
DECLARE_LIST(ui_ranges);

#define for_each_choice(c)		\
	list_for_each_entry(ui_choice_t, c, &ui_choices, link)
#define for_each_range(r)		\
	list_for_each_entry(ui_range_t, r, &ui_ranges, link)
#define for_each_syntax(s)		\
	list_for_each_entry(ui_syntax_t, s, &ui_syntaxes, link)

ui_schema_t *ui_schema_by_oid(const char *oid)
{
	ui_node_t *node = ui_node_by_oid_root(&ui_schema_tree, oid, 0, 0);
	if (node->schema) return node->schema;
	return NULL;
}

ui_node_t *ui_node_by_oid(const char *oid)
{
	ui_node_t *node = ui_node_by_oid_root(&ui_schema_tree, oid, 0, 0);
	if (node && node->state == UI_STATE_REGISTERED) return node;
	return NULL;
}

static ui_node_t *ui_node_by_oid_root(ui_node_t *root, const char *oid,
				      int create, int remove)
{
	ui_node_t *n, *pos;

	if (!root || !oid || *oid != '.') return NULL;
	if (!create && (!remove && root->state == UI_STATE_UNREGISTERED))
		return NULL;
	if (!strcmp(root->oid, oid)) return root;
	list_for_each_entry_safe(ui_node_t, pos, n, &root->children, sibling) {
		if (!strcmp(pos->oid, oid)) return pos;
		if (strlen(pos->oid) < strlen(oid)
		    && oid[strlen(pos->oid)] == '.'
		    && !strncmp(pos->oid, oid, strlen(pos->oid))) {
			return ui_node_by_oid_root(pos, oid, create, remove);
		}
	}
	/* do not find, will create a new one */
	if (create) {
		unsigned int i;
		char *oid_string = strdup(oid);
		char *parent_oid = strdup(root->oid);
		ui_node_t *new_node = NULL;

		for (i = strlen(parent_oid) + 1; i < strlen(oid_string); i++) {
			if (oid_string[i] == '.') {
				oid_string[i] = '\0';
				new_node = ui_node_alloc(root, oid_string);
				oid_string[i] = '.';
				break;
			}
		}
		if (i == strlen(oid_string)) {/* do not find '.' */
			new_node = ui_node_alloc(root, oid_string);
			if (oid_string) free(oid_string);
			if (parent_oid) free(parent_oid);
			return new_node;
		}
		if (oid_string) free(oid_string);
		if (parent_oid) free(parent_oid);
		return ui_node_by_oid_root(new_node, oid, create, remove);
	}
	return NULL;
}

static void ui_node_free(ui_node_t *node)
{
	if (node && node != &ui_schema_tree) {
		node->state = UI_STATE_UNREGISTERED;
		node->schema = NULL;
		
		if (list_empty(&node->children)) {
			ui_node_t *parent = node->parent;

			list_delete(&node->sibling);
			if (node->oid) free(node->oid);
			if (node) free(node);
			if (parent->state == UI_STATE_UNREGISTERED)
				ui_node_free(parent);
		}
	}
}

static ui_node_t *ui_node_alloc(ui_node_t *parent, const char *oid)
{
	ui_node_t *node = (ui_node_t *)malloc(sizeof(ui_node_t));

	if (node) {
		memset(node, 0x00, sizeof(ui_node_t));
		node->oid = strdup(oid);
		INIT_NOTIFY_HEAD(node->oid_chain);
		node->usage = UI_USAGE_USER;
		node->state = UI_STATE_UNREGISTERED;
		list_init(&node->children);
		list_init(&node->sibling);
		node->parent = parent;
		if (parent)
			list_insert_before(&node->sibling, &parent->children);
	}
	return node;
}

ui_node_t *__ui_node_iterate(ui_node_t *node, ui_node_t *iter, 
			     unsigned char forward, int type)
{
	list_t *t;

	if (!iter) t = &node->children;
	else t = &iter->sibling;
	if (node) {
		list_t *pos;
		if (forward) {
			pos = t->next;
		} else {
			pos = t->prev;
		}
		while (pos != &node->children) {
			ui_node_t *tmp = list_entry(pos, ui_node_t, sibling);
			if (!tmp->schema || tmp->state == UI_STATE_UNREGISTERED) {
				pos = forward ? pos->next : pos->prev;
				continue;
			}
			if (tmp->schema->type & 3 & type)
				return tmp;
		}
	}
	return NULL;
}

ui_node_t *ui_node_iterate(const char *oid, ui_node_t *iter,
			   unsigned char forward)
{
	ui_node_t *node = ui_node_by_oid_root(&ui_schema_tree, oid, 0, 0);

	return __ui_node_iterate(node, iter, forward, UI_TYPE_CLASS | UI_TYPE_ATTRIBUTE);
}

ui_node_t *ui_class_iterate(const char *oid, ui_node_t *iter,
			    unsigned char forward)
{
	ui_node_t *node = ui_node_by_oid_root(&ui_schema_tree, oid, 0, 0);

	return __ui_node_iterate(node, iter, forward, UI_TYPE_CLASS);
}

ui_node_t *ui_attrib_iterate(const char *oid, ui_node_t *iter, 
			     unsigned char forward, int filter)
{
	ui_node_t *node = ui_node_by_oid_root(&ui_schema_tree, oid, 0, 0);
	ui_node_t *t = __ui_node_iterate(node, iter, forward, UI_TYPE_ATTRIBUTE);

	while (t) {
		if (t->usage & filter) 
			return t;
		t = __ui_node_iterate(node, iter, forward, UI_TYPE_ATTRIBUTE);
	}
	return NULL;
}

/* match function */
ui_node_t *ui_node_by_name(ui_node_t *node, const char *name)
{
	ui_node_t *n, *pos;
	list_for_each_entry_safe(ui_node_t, pos, n, &node->children, sibling) {
		if (pos->schema && !strcmp(name, pos->schema->name))
			return pos;
	}
	return NULL;
}

ui_node_t *ui_register_node(ui_schema_t *schema)
{
	ui_node_t *new_node = NULL;

	assert(schema);
	new_node = ui_node_by_oid_root(&ui_schema_tree, schema->oid, 1, 0);
	if (new_node) {
		new_node->state = UI_STATE_REGISTERED;
		new_node->schema = schema;
	}
	return new_node;
}

void ui_unregister_node(ui_schema_t *schema)
{
	ui_node_t *old_node = NULL;

	assert(schema);
	old_node = ui_node_by_oid_root(&ui_schema_tree, schema->oid, 0, 1);
	if (old_node) {
		ui_node_free(old_node);
	}
}

int ui_register_schema(ui_schema_t *schema)
{
	ui_schema_t *t =  schema;

	while (t->type != UI_TYPE_NONE) {
		if (!ui_register_node(t))
			return -1;
		t++;
	}
	return 0;
}

void ui_unregister_schema(ui_schema_t *schema)
{
	ui_schema_t *t =  schema;

	while (t->type != UI_TYPE_NONE) {
		ui_unregister_node(t);
		t++;
	}
}

static void ui_dump_schema_node(char *tab, ui_node_t *node)
{
	if (node) {
		ui_node_t *n, *pos;
		list_for_each_entry_safe(ui_node_t, pos, n,
					 &node->children, sibling) {
			if (pos->schema->type == UI_TYPE_CLASS) {
				char tmp[128] = {0};
				printf("%s%s {\n", tab, pos->schema->name);
				sprintf(tmp, "%s\t", tab);
				ui_dump_schema_node(tmp, pos);
				printf("%s}\n", tab);
				
			} else {
				printf("%s%s = %d\n", tab, pos->schema->name,
				       pos->usage);
			}
		}
	}
}

void ui_dump_schema(void)
{
	char tab[128] = {0};
	ui_dump_schema_node(tab, &ui_schema_tree);
}

ui_syntax_t *ui_syntax_by_type(int type)
{
	ui_syntax_t *syntax;

	for_each_syntax(syntax) {
		if (syntax->type == type)
			return syntax;
	}
	return NULL;
}

void ui_register_syntax(ui_syntax_t *syntax)
{
	if (syntax) {
		if (ui_syntax_by_type(syntax->type))
			return;
		list_init(&syntax->link);
		list_insert_head(&(syntax->link), &ui_syntaxes);
	}
}

void ui_unregister_syntax(ui_syntax_t *syntax)
{
	ui_syntax_t *found;

	if (syntax) {
		assert(syntax->type);
		found = ui_syntax_by_type(syntax->type);
		if (found) {
			list_delete(&(syntax->link));
		}
	}
}

static int ui_validate_string(ui_entry_t *parent, int type,
			      const char *in, const void *data)
{
	if (!in || !in[0])
		return UI_ERROR_SYNTAX;
	return UI_ERROR_SUCCESS;
}

#if 0
static int ui_validate_nothing(ui_entry_t *parent, int type,
			       const char *in, const void *data)
{
	return UI_ERROR_SUCCESS;
}
#endif

static ui_syntax_t ui_syntax_defs[] = {
	/* an extension for fixed strings which may form a list */
	{ UI_TYPE_CHOICE, ui_validate_choice },
	/* an extension for integers which may have set of ranges */
	{ UI_TYPE_RANGE, ui_validate_range },
	{ UI_TYPE_UINT8, ui_validate_uint8 },
	{ UI_TYPE_INT8, ui_validate_int8 },
	{ UI_TYPE_UINT16, ui_validate_uint16 },
	{ UI_TYPE_UINT32, ui_validate_uint32 },
	{ UI_TYPE_INT16, ui_validate_int16 },
	{ UI_TYPE_INT32, ui_validate_int32 },
	{ UI_TYPE_FLOAT, ui_validate_float },
	{ UI_TYPE_DOUBLE, ui_validate_double },
	{ UI_TYPE_STRING, ui_validate_string },

	{ UI_TYPE_INSTANCE, ui_validate_instance },
	{ UI_TYPE_VALUE, ui_validate_value },

	{ UI_TYPE_NONE, NULL },
};

int ui_validate_syntax(ui_entry_t *parent, int type,
		       const char *in, const void *data)
{
	ui_syntax_t *syntax;

	syntax = ui_syntax_by_type(type);
	if (syntax && syntax->validate) {
		return syntax->validate(parent, type, in, data);
	}
	return UI_ERROR_SUCCESS;
}

static void ui_range_init(ui_range_val_t *range)
{
	if (range) {
		range->r_sign = UI_RANGE_SIGN_UNKNOWN;
		range->r_decimal = NULL;
		range->r_integer = NULL;
	}
}

static void ui_range_free(ui_range_val_t *range)
{
	if (range) {
		if (range->r_decimal) {
			free(range->r_decimal);
			range->r_decimal = NULL;
		}
		if (range->r_integer) {
			free(range->r_integer);
			range->r_integer = NULL;
		}
	}
}

static int ui_range_parse_value(const char *v, ui_range_val_t *range) 
{
	char *value, *store = NULL;
	int n, i, first_digit = 0, do_digit = 0;
	int rc = UI_ERROR_SUCCESS;
	
	assert(range);
	ui_range_init(range);

	if (!v) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	store = strdup(v);
	if (!store) {
		rc = UI_ERROR_MEMORY;
		goto end;
	}

	value = store;
	range->r_n_decimal = 0;
	range->r_n_integer = -1;
	/* general validation */
	for (i = 0; value[i]; i++) {
		if (!isdigit(value[i])) {
			if (value[i] == '.') {
				if (range->r_decimal) {
					rc = UI_ERROR_SYNTAX;
					goto end;
				}
				value[i] = 0;
				range->r_decimal = strdup(value+i+1);
				range->r_n_decimal = strlen(value+i+1);
				range->r_n_integer = i - first_digit;
			} else if (value[i] == '-' || value[i] == '+') {
				if (i != 0) {
					rc = UI_ERROR_SYNTAX;
					goto end;
				}
				range->r_sign = (value[i] == '+') ? UI_RANGE_SIGN_PLUS : UI_RANGE_SIGN_MINUS;
			} else {
				rc = UI_ERROR_SYNTAX;
				goto end;
			}
		} else {
			if (!do_digit) {
				first_digit = i;
				do_digit = 1;
			}
		}
	}
	if (range->r_n_integer < 0)
		range->r_n_integer = i - first_digit;

	/* check signed / unsigned */
	if (range->r_sign != UI_RANGE_SIGN_UNKNOWN)
		value++;
	n = (range->r_sign == UI_RANGE_SIGN_MINUS) ? 1 : 0;

	/* skip leading '0's */
	while (*value == '0' && *(value+1) != '.' && *(value+1) != 0) 
		value++;
	
	range->r_integer = strdup(value);
end:
	if (store) {
		free(store), store = NULL;
	}
	if (rc != UI_ERROR_SUCCESS) {
		ui_range_free(range);
	}
	return rc;
}

static int ui_range_compare(ui_range_val_t *range1, ui_range_val_t *range2)
{
	int sign1, sign2, _abs, res = 0, i;
	assert(range1 && range2);

	/* check sign */
	sign1 = (range1->r_sign == UI_RANGE_SIGN_MINUS ? UI_RANGE_SIGN_MINUS : UI_RANGE_SIGN_PLUS);
	sign2 = (range2->r_sign == UI_RANGE_SIGN_MINUS ? UI_RANGE_SIGN_MINUS : UI_RANGE_SIGN_PLUS);
	if (sign1 != sign2) {
		return sign1 == UI_RANGE_SIGN_MINUS ? -1 : 1;
	}
	_abs = (sign1 == UI_RANGE_SIGN_PLUS ? 1 : -1);

	/* check decimal part */
	if (!range1->r_integer && range2->r_integer) {
		res = -1;
		goto end;
	}
	if (range1->r_integer && !range2->r_integer) {
		res = 1;
		goto end;
	}

	if (range1->r_integer && range2->r_integer) {
		sign1 = strlen(range1->r_integer);
		sign2 = strlen(range2->r_integer);

		if (sign1 != sign2) {
			res = sign1 - sign2;
			goto end;
		}
		for (i = 0; i < sign1; i++) {
			if (range1->r_integer[i] != range2->r_integer[i]) {
				res = range1->r_integer[i] - range2->r_integer[i];
				goto end;
			}
		}
	}

	/* check float part */
	if (!range1->r_decimal && range2->r_decimal) {
		res = -1;
		goto end;
	}
	if (range1->r_decimal && !range2->r_decimal) {
		res = 1;
		goto end;
	}
	if (range1->r_decimal && range2->r_decimal) {
		int min_sign;
		sign1 = strlen(range1->r_decimal);
		sign2 = strlen(range2->r_decimal);
		min_sign = sign1 < sign2 ? sign1 : sign2;
		for (i = 0; i <= min_sign; i++) {
			if (range1->r_decimal[i] != range2->r_decimal[i]) {
				res = range1->r_decimal[i] - range2->r_decimal[i];
				goto end;
			}
		}
	}
end:
	return _abs * res;
}

ui_range_t *ui_range_by_name(const char *name)
{
	ui_range_t *range;

	if (!name) return NULL;
	for_each_range(range) {
		if (strcmp(name, range->name) == 0)
			return range;
	}
	return NULL;
}

int ui_register_range(ui_range_t *range)
{
	if (range) {
		if (ui_range_by_name(range->name))
			return -1;
		list_init(&range->link);
		list_insert_head(&(range->link), &ui_ranges);
	}
	return 0;
}

void ui_unregister_range(ui_range_t *range)
{
	ui_range_t *found;

	if (range) {
		found = ui_range_by_name(range->name);
		if (found) {
			list_delete(&(range->link));
		}
	}
}

static int ui_validate_range(ui_entry_t *parent, int type,
			     const char *in, const void *name)
{
	int rc = UI_ERROR_SUCCESS;
	int idx;
	const char *from, *to;
	ui_range_t *range = ui_range_by_name(name);
	ui_range_val_t value, check;

	if (!range) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}

	ui_range_init(&value);
	ui_range_init(&check);

	rc = ui_range_parse_value(in, &value);
	if (rc != UI_ERROR_SUCCESS) goto end;

	if (!range->allow_sign && value.r_sign != UI_RANGE_SIGN_UNKNOWN) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	if (!range->allow_float && value.r_decimal) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}

	for (idx = 0; idx < range->from_to_count; idx++) {
		from = range->from_to_pairs[idx].from;
		to = range->from_to_pairs[idx].to;

		if ((from && from[0]) && strcmp(from, UI_RANGE_VALUE_INFINITE) != 0) {
			rc = ui_range_parse_value(from, &check);
			if (rc != UI_ERROR_SUCCESS) {
				rc = UI_ERROR_SYNTAX;
				goto end;
			}
			if (ui_range_compare(&value, &check) < 0)
				continue;
		}
		ui_range_free(&check);

		if ((to && to[0]) && strcmp(to, UI_RANGE_VALUE_INFINITE) != 0) {
			rc = ui_range_parse_value(to, &check);
			if (rc != UI_ERROR_SUCCESS) {
				rc = UI_ERROR_SYNTAX;
				goto end;
			}
			if (ui_range_compare(&value, &check) > 0)
				continue;
		}
		ui_range_free(&check);

		/* its OK in this range */
		assert(rc == UI_ERROR_SUCCESS);
		goto end;
	}
	rc = UI_ERROR_SYNTAX;
end:
	ui_range_free(&value);
	ui_range_free(&check);
	return rc;
}

struct ui_validate_param {
	const char *text;
	int case_cmp;
	int found;
};

static int ui_compare_choice(ui_choice_t *choice, const void *iter, void *data)
{
	struct ui_validate_param *param = (struct ui_validate_param *)data;
	const char *name;

	assert(param && choice->get_name);

	name = choice->get_name(iter);
	if (name && param->text) {
		if (param->case_cmp) {
			if (strcasecmp(name, param->text) == 0) {
				param->found++;
			}
		} else {
			if (strcmp(name, param->text) == 0) {
				param->found++;
			}
		}
	}
	return 0;
}

static int ui_validate_choice(ui_entry_t *parent, int type,
			      const char *in, const void *name)
{
	struct ui_validate_param param;
	ui_choice_t *choice = ui_choice_by_name(name);

	param.text = in;
	param.case_cmp = 1;
	param.found = 0;

	if (choice) {
		ui_foreach_choice(choice, ui_compare_choice, &param);
	}
	return param.found ? UI_ERROR_SUCCESS : UI_ERROR_SYNTAX;
}

static int ui_validate_uint8(ui_entry_t *parent, int type,
			     const char *in, const void *unused)
{
	int rc = UI_ERROR_SUCCESS;
	ui_range_val_t value, check;

	ui_range_init(&value);
	ui_range_init(&check);

	rc = ui_range_parse_value(in, &value);
	if (rc != UI_ERROR_SUCCESS) goto end;
	if (value.r_sign != UI_RANGE_SIGN_UNKNOWN || value.r_decimal) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	rc = ui_range_parse_value("255", &check);
	assert(rc == UI_ERROR_SUCCESS);
	if (ui_range_compare(&value, &check) > 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
end:
	ui_range_free(&value);
	ui_range_free(&check);
	return rc;
}

static int ui_validate_uint16(ui_entry_t *parent, int type,
			      const char *in, const void *unused)
{
	int rc = UI_ERROR_SUCCESS;
	ui_range_val_t value, check;

	ui_range_init(&value);
	ui_range_init(&check);

	rc = ui_range_parse_value(in, &value);
	if (rc != UI_ERROR_SUCCESS) goto end;
	if (value.r_sign != UI_RANGE_SIGN_UNKNOWN || value.r_decimal) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	rc = ui_range_parse_value("65535", &check);
	assert(rc == UI_ERROR_SUCCESS);
	if (ui_range_compare(&value, &check) > 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
end:
	ui_range_free(&value);
	ui_range_free(&check);
	return rc;
}

static int ui_validate_uint32(ui_entry_t *parent, int type,
			      const char *in, const void *unused)
{
	int rc = UI_ERROR_SUCCESS;
	ui_range_val_t value, check;

	ui_range_init(&value);
	ui_range_init(&check);

	rc = ui_range_parse_value(in, &value);
	if (rc != UI_ERROR_SUCCESS) goto end;
	if (value.r_sign != UI_RANGE_SIGN_UNKNOWN || value.r_decimal) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	rc = ui_range_parse_value("4294967295", &check);
	assert(rc == UI_ERROR_SUCCESS);
	if (ui_range_compare(&value, &check) > 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
end:
	ui_range_free(&value);
	ui_range_free(&check);
	return rc;
}

static int ui_validate_int8(ui_entry_t *parent, int type,
			    const char *in, const void *unused)
{
	int rc = UI_ERROR_SUCCESS;
	ui_range_val_t value, check;

	ui_range_init(&value);
	ui_range_init(&check);

	rc = ui_range_parse_value(in, &value);
	if (rc != UI_ERROR_SUCCESS) goto end;
	if (value.r_decimal) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	rc = ui_range_parse_value("127", &check);
	assert(rc == UI_ERROR_SUCCESS);
	if (ui_range_compare(&value, &check) > 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	check.r_sign = UI_RANGE_SIGN_MINUS;
	if (ui_range_compare(&value, &check) < 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
end:
	ui_range_free(&value);
	ui_range_free(&check);
	return rc;
}

static int ui_validate_int16(ui_entry_t *parent, int type,
			     const char *in, const void *unused)
{
	int rc = UI_ERROR_SUCCESS;
	ui_range_val_t value, check;

	ui_range_init(&value);
	ui_range_init(&check);

	rc = ui_range_parse_value(in, &value);
	if (rc != UI_ERROR_SUCCESS) goto end;
	if (value.r_decimal) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	rc = ui_range_parse_value("32767", &check);
	assert(rc == UI_ERROR_SUCCESS);
	if (ui_range_compare(&value, &check) > 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	check.r_sign = UI_RANGE_SIGN_MINUS;
	if (ui_range_compare(&value, &check) < 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
end:
	ui_range_free(&value);
	ui_range_free(&check);
	return rc;
}

static int ui_validate_int32(ui_entry_t *parent, int type,
			     const char *in, const void *unused)
{
	int rc = UI_ERROR_SUCCESS;
	ui_range_val_t value, check;

	ui_range_init(&value);
	ui_range_init(&check);

	rc = ui_range_parse_value(in, &value);
	if (rc != UI_ERROR_SUCCESS) goto end;
	if (value.r_decimal) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	rc = ui_range_parse_value("2147483647", &check);
	assert(rc == UI_ERROR_SUCCESS);
	if (ui_range_compare(&value, &check) > 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	check.r_sign = UI_RANGE_SIGN_MINUS;
	if (ui_range_compare(&value, &check) < 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
end:
	ui_range_free(&value);
	ui_range_free(&check);
	return rc;
}

/*
 * NOTE: format is length.decimal style
 * if decimal is not specified or decimal is 0,
 * check on decimal will not be performed
 */
static int ui_validate_float(ui_entry_t *parent, int type,
			     const char *in, const void *prec)
{
	int rc = UI_ERROR_SUCCESS;
	ui_range_val_t value, check;
	int decimal = 0;

	ui_range_init(&value);
	ui_range_init(&check);

	rc = ui_range_parse_value(in, &value);
	if (rc != UI_ERROR_SUCCESS) goto end;

	if (prec) {
		decimal = atoi((const char *)prec);
		if (value.r_n_decimal > decimal) {
			rc = UI_ERROR_SYNTAX;
			goto end;
		}
	}
	rc = ui_range_parse_value("34028200183756560000000000000000"
				  "0000000", &check);
	assert(rc == UI_ERROR_SUCCESS);
	if (ui_range_compare(&value, &check) > 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	check.r_sign = UI_RANGE_SIGN_MINUS;
	if (ui_range_compare(&value, &check) < 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
end:
	ui_range_free(&value);
	ui_range_free(&check);
	return rc;
}

static int ui_validate_double(ui_entry_t *parent, int type,
			      const char *in, const void *prec)
{
	int rc = UI_ERROR_SUCCESS;
	ui_range_val_t value, check;
	int decimal = 0;

	ui_range_init(&value);
	ui_range_init(&check);

	rc = ui_range_parse_value(in, &value);
	if (rc != UI_ERROR_SUCCESS) goto end;

	if (prec) {
		decimal = atoi((const char *)prec);
		if (value.r_n_decimal > decimal) {
			rc = UI_ERROR_SYNTAX;
			goto end;
		}
	}
	rc = ui_range_parse_value("17976900000000001000000000000000"
				  "00000000000000000000000000000000"
				  "00000000000000000000000000000000"
				  "00000000000000000000000000000000"
				  "00000000000000000000000000000000"
				  "00000000000000000000000000000000"
				  "00000000000000000000000000000000"
				  "00000000000000000000000000000000"
				  "00000000000000000000000000000000"
				  "000000000000000000000", &check);
	assert(rc == UI_ERROR_SUCCESS);
	if (ui_range_compare(&value, &check) > 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
	check.r_sign = UI_RANGE_SIGN_MINUS;
	if (ui_range_compare(&value, &check) < 0) {
		rc = UI_ERROR_SYNTAX;
		goto end;
	}
end:
	ui_range_free(&value);
	ui_range_free(&check);
	return rc;
}

static int ui_validate_instance(ui_entry_t *parent, int type,
				const char *in, const void *data)
{
	return ui_validate_entry(parent, in, data);
}

static int ui_validate_value(ui_entry_t *parent, int type,
			     const char *in, const void *data)
{
	return ui_validate_entry(parent, in, data);
}

static int ui_validate_entry(ui_entry_t *parent,
			     const char *in, const void *data)
{
	ui_command_t *cmd;
	ui_node_t *node = (ui_node_t *)data;

	if (!in || !*in) return UI_ERROR_SYNTAX;

	if (ui_is_conf_token(in))
		return UI_ERROR_SYNTAX;

	cmd = ui_command_by_name(parent->node->oid, in);
	if (cmd) {
		if (parent->type == UI_TYPE_INSTANCE) {
			if (ui_is_multiple_entry(parent) && (cmd->type & UI_CMD_MULTI_INST))
				return UI_ERROR_SYNTAX;
			if (!ui_is_multiple_entry(parent) && (cmd->type & UI_CMD_SINGLE_INST))
				return UI_ERROR_SYNTAX;
		} else {
			if (ui_is_multiple_entry(parent) && (cmd->type & UI_CMD_MULTI_VALUE))
				return UI_ERROR_SYNTAX;
			if (!ui_is_multiple_entry(parent) && (cmd->type & UI_CMD_SINGLE_VALUE))
				return UI_ERROR_SYNTAX;
		}
	}
	cmd = ui_command_by_name(node->oid, in);
	if (cmd) {
		if (node->schema->type == UI_TYPE_CLASS) {
			if (ui_is_multiple_node(node) && (cmd->type & UI_CMD_MULTI_CLASS))
				return UI_ERROR_SYNTAX;
			if (!ui_is_multiple_node(node) && (cmd->type & UI_CMD_SINGLE_INST))
				return UI_ERROR_SYNTAX;
		} else {
			if (ui_is_multiple_node(node) && (cmd->type & UI_CMD_MULTI_ATTR))
				return UI_ERROR_SYNTAX;
			if (!ui_is_multiple_node(node) && (cmd->type & UI_CMD_SINGLE_ATTR))
				return UI_ERROR_SYNTAX;
		}
	}

	if (ui_is_multiple_node(node)) {
		if (ui_entry_by_user(parent, ui_node_entry_type(node),
				     node->schema->name, in)) {
			return UI_ERROR_SYNTAX;
		}
	}
	return ui_validate_syntax(parent, node->schema->val_type,
				  in, node->schema->type_name);
}

ui_choice_t *ui_choice_by_name(const char *name)
{
	ui_choice_t *choice = NULL;

	if (!name) return NULL;
	for_each_choice(choice) {
		if (strcmp(name, choice->name) == 0)
			return choice;
	}
	return NULL;
}

int ui_register_choice(ui_choice_t *choice)
{
	if (choice) {
		if (ui_choice_by_name(choice->name))
			return -1;
		list_init(&choice->link);
		list_insert_head(&(choice->link), &ui_choices);
	}
	return 0;
}

void ui_unregister_choice(ui_choice_t *choice)
{
	ui_choice_t *found;

	if (choice) {
		found = ui_choice_by_name(choice->name);
		if (found) {
			list_delete(&(choice->link));
		}
	}
}

void ui_foreach_choice(ui_choice_t *choice, ui_iterate_fn func, void *data)
{
	assert(choice && choice->foreach);
	choice->foreach(choice, func, data);
}

ui_fromto_t ui_retry_fromto[] = {
	{ "0", "10" },
};

ui_range_t ui_retry_range = {
	"retry_times",
	UI_TYPE_INT,
	0,
	0,
	1,
	ui_retry_fromto,
};

int __init ui_schema_init(void)
{
	ui_syntax_t *syntax;

	ui_register_node(&ui_schema_root);
	for (syntax = &ui_syntax_defs[0]; syntax->type; syntax++) {
		ui_register_syntax(syntax);
	}
	ui_register_range(&ui_retry_range);
	return 0;
}

void __exit ui_schema_exit(void)
{
	ui_syntax_t *syntax;

	ui_unregister_range(&ui_retry_range);
	for (syntax = &ui_syntax_defs[0]; syntax->type; syntax++) {
		ui_unregister_syntax(syntax);
	}
	ui_unregister_node(&ui_schema_root);
}
