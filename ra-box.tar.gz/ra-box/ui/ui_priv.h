#ifndef __UI_PRIV_H_INCLUDE__
#define __UI_PRIV_H_INCLUDE__

#include <strutl.h>
#include <fsserv.h>
#include <uiserv.h>
#include <syslog.h>
#include <logger.h>
#include <service.h>

#define UI_ENTRY_SET_VALID(e, f)	((e)->valid |= f)
#define UI_ENTRY_UNSET_VALID(e, f)	((e)->valid &= ~f)
#define UI_ENTRY_IS_VALID(e, f)		(((e)->valid & (f)) == (f))
ui_node_t *ui_node_by_oid(const char *oid);

ui_entry_t *ui_entry_alloc(ui_entry_t *parent, int type,
			   const char *name, const char *value);
void ui_entry_free(ui_entry_t *entry);

#define for_each_ui_entry(p, t, i)					\
	list_for_each_entry(ui_entry_t, i, &p->children, sibling)	\
		if (i->type == t)
#define for_each_ui_entry_safe(p, t, i, n)				\
	list_for_each_entry_safe(ui_entry_t, i, n,			\
				 &p->children, sibling)			\
		if (i->type == t)
#define for_each_ui_multiple_entry(p, t, i)				\
	list_for_each_entry(ui_entry_t, i, &p->children, sibling)	\
		if (i->type == t && ui_is_multiple_entry(i))
#define for_each_ui_inst(p, t)						\
	for_each_ui_entry(p, UI_TYPE_INSTANCE, t)			\
		if (t->type == UI_TYPE_INSTANCE)
#define for_each_ui_value(p, t)						\
	list_for_each_entry(ui_entry_t, t, &p->children, sibling)	\
		if (t->type == UI_TYPE_VALUE)

#define for_each_ui_inst_safe(p, t, n)					\
	for_each_ui_entry_safe(p, UI_TYPE_INSTANCE, t, n)
#define for_each_ui_value_safe(p, t, n)					\
	for_each_ui_entry_safe(p, UI_TYPE_VALUE, t, n)

extern ui_entry_t ui_object_tree;
extern ui_node_t ui_schema_tree;

int __init ui_user_init(void);
void __exit ui_user_exit(void);
int __init ui_schema_init(void);
void __exit ui_schema_exit(void);

/* ============================================================
 * schema syntax
 * ============================================================ */
/* error indicators */
#define UI_IS_SYNTAX_ERROR(rc)		(rc >= UI_ERROR_REQUIRED && \
					 rc <= UI_ERROR_SYNTAX)
int ui_is_conf_token(const char *tok);

#endif
