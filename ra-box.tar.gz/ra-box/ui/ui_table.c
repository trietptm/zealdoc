/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2006
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@gmail.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)envarg.c: environment based UI routines
 * $Id: ui_table.c,v 1.12 2009-02-25 05:32:25 zhenglv Exp $
 */

#include "ui_priv.h"

#define for_each_table_safe(t, n, s)		\
	list_for_each_entry_safe(ui_table_t, t, n, &s->tables, list)

void ui_tables_free(ui_session_t *sess)
{
	ui_table_t *table, *n;

	for_each_table_safe(table, n, sess) {
		ui_table_delete(table);
	}
}

ui_table_t *ui_table_create(ui_session_t *sess, const char *name)
{
	ui_table_t *list = malloc(sizeof (ui_table_t));

	if (list) {
		list->title = create_vector((DESTROYER)free,
					    (COMPARER)strcasecmp);
		if (!list->title) goto failure;
		list->table = create_vector((DESTROYER)destroy_vector,
					    (COMPARER)compare_vector);
		if (!list->table) goto failure;
		if (name) list->name = strdup(name);
		list_init(&list->list);
		list_insert_before(&list->list, &sess->tables);
	}
	return list;

failure:
	ui_table_delete(list);
	return NULL;
}

void ui_table_delete(ui_table_t *list)
{
	if (list) {
		if (list->title)
			destroy_vector(list->title);
		if (list->table)
			destroy_vector(list->table);
		if (list->name)
			free(list->name);
		list_delete(&list->list);
		free(list);
	}
}

ui_table_t *ui_table_by_name(ui_session_t *sess, const char *name)
{
	list_t *pos, * n;
	ui_table_t *entry;

	list_iterate_forward(pos, n, &sess->tables) {
		entry = list_entry(pos, ui_table_t, list);
		if (strcasecmp(entry->name, name) == 0)
			return entry;
	}
	return NULL;
}

int ui_table_rows(ui_table_t *list)
{
	if (list)
		return element_count(list->table);
	return 0;
}

int ui_table_columns(ui_table_t *list)
{
	if (list)
		return element_count(list->title);
	return 0;
}

typedef struct _ui_qsort_t {
	ui_compare_fn compare;
	int index;
} ui_qsort_t;

static ui_qsort_t *ui_sorter = NULL;
static int ui_compare_column(vector_t *line1, vector_t *line2)
{
	char *str1, *str2;

	if (!ui_sorter)
		return 0;
	str1 = get_element((vector_t *)line1, ui_sorter->index);
	str2 = get_element((vector_t *)line2, ui_sorter->index);
	return ui_sorter->compare(str1, str2);
}

void ui_qsort_table(ui_table_t *list, const char *title,
		    ui_compare_fn compare)
{
	ui_qsort_t sort;
	int idx;

	idx = ui_column_by_title(list, title);
	if (idx >= 0) {
		/* TODO: lock globally */
		sort.index = idx;
		sort.compare = compare;
		ui_sorter = &sort;

		sort_elements(list->table, (COMPARER)ui_compare_column);
		ui_sorter = NULL;
	}
}

const char *ui_value_by_title(ui_table_t *list, const char *title, int current)
{
	int found = 0, i;
	int count;
	vector_t *line = NULL;

	if (current < 0 || current > ui_table_rows(list))
		current = 0;
	line = get_element(list->table, current);
	if (line) {
		count = element_count(line);
		for (i = 0; i < count; i++) {
			char *name = get_element(list->title, i);
			if (name && strcasecmp(name, title) == 0) {
				found = 1;
				break;
			}
		}
		if (found)
			return get_element(line, i);
	}
	return NULL;
}

const char *ui_value_by_index(ui_table_t *list, int idx, int current)
{
	vector_t *line = NULL;

	line = get_element(list->table, current);
	if (line)
		return get_element(line, idx);
	return NULL;
}

const char *ui_value_by_refer(ui_session_t *sess,
			      const char *list, const char *locate_title,
			      const char *locate_value, const char *title)
{
	int idx;
	ui_table_t *object = ui_table_by_name(sess, list);
	if (!object)
		return NULL;
	idx = ui_row_by_value(object, locate_title, locate_value);
	if (idx < 0)
		return NULL;
	return ui_value_by_title(object, title, idx);
}

int ui_column_by_title(ui_table_t *list, const char *title)
{
	int col = -1;
	int i, count;
	vector_t *vector = NULL;
	
	if (!list || !title)
		return -1;
	vector = list->title;
	count = element_count(vector);
	for (i = 0; i < count; i++) {
		char *element = get_element(vector, i);
		if (element && strcasecmp(element, title) == 0) {
			col = i;
			break;
		}
	}
	return col;
}

int ui_row_by_value(ui_table_t *list, const char *title, const char *value)
{
	int i, count;
	int col;
	
	if (!list)
		return -1;
	col = ui_column_by_title(list, title);

	if (col > -1) {
		count = ui_table_rows(list);
		for (i = 0; i < count; i++) {
			const char *element = ui_value_by_index(list, col, i);
			if (element && value && strcasecmp(element, value) == 0)
				return i;
		}
	}
	return -1;
}

void ui_set_title(ui_table_t *list, int idx, const char *title)
{
}

void ui_add_title(ui_table_t *list, int idx, const char *title)
{
	set_element(list->title, idx, title ? strdup(title) : NULL);
}

void ui_set_value(ui_table_t *list, const char *title,
		  int current, const char *value)
{
	int found = 0, i;
	int count;
	vector_t *line = NULL;

	line = get_element(list->table, current);
	if (line) {
		count = element_count(list->title);
		for (i = 0; i < count; i++) {
			char *name = get_element(list->title, i);
			if (strcasecmp(name, title) == 0) {
				found = 1;
				break;
			}
		}
		if (found)
			set_element(line, i, value ? strdup(value) : NULL);
	}
}

void ui_add_value(ui_table_t *list, const char *title,
		  int idx, const char *value)
{
	int i;
	int count, found = 0;
	vector_t *line = NULL;

	if (idx < 0)
		idx = element_count(list->table);
	else
		line = get_element(list->table, idx);
	if (!line) {
		if (idx != element_count(list->table))
			idx = element_count(list->table);
		line = create_vector((DESTROYER)free,
				     (COMPARER)strcmp);
		if (line)
			set_element(list->table, idx, line);
	}
	if (line) {
		count = element_count(list->title);
		for (i = 0; i < count; i++) {
			char *name = get_element(list->title, i);
			if (strcasecmp(name, title) == 0) {
				found = 1;
				break;
			}
		}
		if (!found) {
			/* create a new column */
			set_element(list->title, i, strdup(title));
		}
		set_element(line, i, value ? strdup(value) : NULL);
	}
}

void ui_index_set_value(ui_table_t *list, int idx, int current, const char *value)
{
	vector_t *line = NULL;

	line = get_element(list->table, current);
	if (line) {
		set_element(line, idx, value ? strdup(value) : NULL);
		return;
	}
	return;
}

void ui_refer_set_value(ui_session_t *sess,
			const char *list, const char *locate_title,
			const char *locate_value, const char *title,
			const char *value)
{
	int idx;
	ui_table_t *object = ui_table_by_name(sess, list);

	if (!object)
		return;
	if (value == ui_value_by_refer(sess, list, locate_title,
				       locate_value, title))
		return;
	idx = ui_row_by_value(object, locate_title, locate_value);
	if (idx < 0)
		return;
	ui_add_value(object, title, idx, value);
}
