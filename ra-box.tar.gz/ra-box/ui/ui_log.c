#include <sysdep.h>
#include <logger.h>
#include <stdio.h>
#include <stdlib.h>
#include <strutl.h>
#include <module.h>

static int log_index = 1;

typedef struct _log_registry_t {
	int logger;
	log_source_t *source;
	list_t link;
} log_registry_t;

struct _log_output_t {
	log_method_t *method;
	unsigned long param;
	int level;
	list_t link;
};

DECLARE_LIST(log_sources);
DECLARE_LIST(log_outputs);
DECLARE_LIST(log_methods);

int log_logger = 0;
log_source_t log_source = {
	"kern",
};

#define for_each_method(d)			\
	list_for_each_entry(log_method_t, d, &log_methods, link)
#define for_each_output(d)			\
	list_for_each_entry(log_output_t, d, &log_outputs, link)
#define for_each_source(d)			\
	list_for_each_entry(log_registry_t, d, &log_sources, link)

#ifdef CONFIG_LOG_SEVERITY
static unsigned char log_level2char(int level)
{
	switch (level) {
	case LOG_WARNING:
		return 'W';
	case LOG_ERR:
		return 'E';
	case LOG_INFO:
		return 'I';
	case LOG_EMERG:
		return 'C';
	case LOG_DEBUG:
	default:
		return 'D';
	}
}
#endif

static log_registry_t *log_registry_by_logger(int logger)
{
	log_registry_t *c;

	for_each_source(c) {
		if (c->logger == logger)
			return c;
	}
	return NULL;
}

int log_register_source(log_source_t *src)
{
	log_registry_t *reg;

	/* can not register any more */
	if (!log_index) return 0;
	
	reg = malloc(sizeof (log_registry_t));
	if (reg) {
		reg->logger = log_index++;
		reg->source = src;
		list_init(&reg->link);
		list_insert_before(&reg->link, &log_sources);
		
		return reg->logger;
	}
	return 0;
}

void log_unregister_source(int logger)
{
	log_registry_t *reg;

	reg = log_registry_by_logger(logger);
	if (reg) {
		list_delete(&reg->link);
		free(reg);
	}
}

log_method_t *log_method_by_mech(int mech)
{
	log_method_t *meth;

	for_each_method(meth) {
		if (meth->mech == mech)
			return meth;
	}
	return NULL;
}

int log_register_method(log_method_t *meth)
{
	if (meth) {
		if (log_method_by_mech(meth->mech)) {
			log_kern(LOG_ERR,
				 "LOG: already registered method: mech=%s",
				 meth->mech);
			return -1;
		}
		list_init(&meth->link);
		list_insert_before(&meth->link, &log_methods);
	}
	return 0;
}

void log_unregister_method(log_method_t *meth)
{
	if (meth) {
		if (log_method_by_mech(meth->mech))
			list_delete_init(&meth->link);
	}
}

log_output_t *log_register_output(int mech, unsigned long param)
{
	log_output_t *out = malloc(sizeof (log_output_t));
	if (out) {
		memset(out, 0, sizeof (log_output_t));
		out->method = log_method_by_mech(mech);
		if (!out->method) {
			free(out);
			return NULL;
		}
		out->level = LOG_LEVEL_DEFAULT;
		out->param = param;
		list_init(&out->link);
		list_insert_before(&out->link, &log_outputs);
	}
	return out;
}

void log_unregister_output(log_output_t *out)
{
	if (out) {
		list_delete(&out->link);
		free(out);
	}
}

void log_set_level(log_output_t *out, int level)
{
	if (out)
		out->level = level;
}

unsigned long log_get_param(log_output_t *out)
{
	return out ? out->param : 0;
}

int log_mech_by_name(const char *name)
{
	log_method_t *m;

	for_each_method(m) {
		if (strcasecmp(name, m->name) == 0)
			return m->mech;
	}
	return LOG_MECH_NOTDEF;
}

#define MAX_ERRSTR	256
#define MAX_TIMESTR	17

#ifdef CONFIG_LOG
static void log_output_all(int level, const char *string)
{
	log_output_t *out;

	for_each_output(out) {
		if (out->method && out->method->output && level <= out->level)
			out->method->output(out, level, string);
	}
}

void loggingv(int logger, int level, const char *fmt, va_list args)
{
	char my_errstr[MAX_ERRSTR+1], *ptr = my_errstr;
	int len = MAX_ERRSTR;
	log_registry_t *reg;

	reg = log_registry_by_logger(logger);
	if (reg && reg->source) {
		int tag_len = strlen(reg->source->tag);

		*ptr = '[';
		ptr++, len--;

		memcpy(ptr, reg->source->tag, tag_len);
		ptr += tag_len, len -= tag_len;

		*ptr = ']';
		ptr++, len--;

		*ptr = ' ';
		ptr++, len--;
	}

	vsnprintf(ptr, len, fmt, args);
	log_output_all(level, my_errstr);
}

void logging(int logger, int level, const char *fmt, ...)
{
	va_list ap;

	va_start(ap, fmt);
	loggingv(logger, level, fmt, ap);
	va_end(ap);
}

void log_kern(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(log_logger, level, format, ap);
	va_end(ap);
}
#endif

static void log_output_stream(log_output_t *out, int level, const char *string)
{
	time_t now;
	char *err = NULL, *ptr;
	int slen = string ? strlen(string) : 0;
	int len = slen + 2; /* \r\n */

	if (!len || !out) return;

#ifdef CONFIG_LOG_SEVERITY
	len += 3;	/* <L> */
#endif
#ifdef CONFIG_LOG_TIMESTAMP
	len += MAX_TIMESTR + 1;
#endif

	err = calloc(1, len);
	if (!err) return;

	ptr = err;

#ifdef CONFIG_LOG_SEVERITY
	*ptr = '<';
	ptr++;
	*ptr = log_level2char(level);
	ptr++;
	*ptr = '>';
	ptr++;
#endif

	time(&now);

#ifdef CONFIG_LOG_TIMESTAMP
	memcpy(ptr, time_string(0, now), MAX_TIMESTR);
	ptr += MAX_TIMESTR;
	/* change zero end to space */
	*ptr = ' ';
	ptr++;
#endif

	memcpy(ptr, string, slen);
	ptr += slen;
	*ptr = '\r';
	ptr++;
	*ptr = '\n';
	ptr++;

	assert((ptr - err) == len);

	write(out->param, err, len);
	free(err);
}

log_method_t log_stream_method = {
	"descriptor",
	LOG_MECH_STREAM,
	log_output_stream,
};

static log_output_t *log_early_logger = NULL;

static int __init log_base_init(void)
{
	log_register_method(&log_stream_method);
	log_logger = log_register_source(&log_source);
	return !log_logger;
}

int __init log_early_init(void)
{
	log_base_init();
	log_early_logger = log_register_output(LOG_MECH_STREAM, STDOUT_FILENO);
	if (log_early_logger) {
		log_set_level(log_early_logger, LOG_DEBUG);
	}
	return 0;
}

void __exit log_early_exit(void)
{
	if (log_early_logger) {
		log_unregister_output(log_early_logger);
		log_early_logger = 0;
	}
}

void __exit log_exit(void)
{
	log_unregister_source(log_logger);
	log_unregister_method(&log_stream_method);
}
