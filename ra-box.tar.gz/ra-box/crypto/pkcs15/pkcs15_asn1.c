#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

static const uint8_t *pkcs15_asn1_skip_tag(const uint8_t **buf, size_t *buflen,
				    unsigned int tag_in, size_t *taglen_out);

void pkcs15_format_asn1_entry(struct pkcs15_asn1_entry *entry, void *param, 
			      void *arg, int set_present)
{
	entry->param = param;
	entry->arg = arg;
	if (set_present)
		entry->flags = PKCS15_ASN1_PRESENT;
}

void pkcs15_copy_asn1_entry (const struct pkcs15_asn1_entry *src,
			    struct pkcs15_asn1_entry *dest)
{
	while (src->name != NULL) {
		*dest = *src;
		dest++;
		src++;
	}
	dest->name = NULL;
}

static int asn1_encode_integer(int in, uint8_t **obj, size_t *objsize)
{
	int i = sizeof(in) * 8, skip = 1;
	uint8_t *p, b;

	*obj = p = (uint8_t *)malloc(sizeof(in));
	if (*obj == NULL)
		return PKCS15_ERR_NO_MEM;
	do {
		i -= 8;
		b = in >> i;
		if (b == 0 && skip)
			continue;
		skip = 0;
		*p++ = b;
	} while (i > 0);
	*objsize = p - *obj;
	if (*objsize == 0) {
		*objsize = 1;
		(*obj)[0] = 0;
	}

	return 0;
}

static int encode_bit_string (const uint8_t *inbuf, size_t bits_left, 
			      uint8_t **outbuf, size_t *outlen, int invert)
{
	const uint8_t *in = inbuf;
	uint8_t *out;
	size_t bytes;
	int skipped = 0;

	bytes = (bits_left + 7) / 8 + 1;
	*outbuf = out = (uint8_t *)malloc(bytes);
	if (out == NULL)
		return PKCS15_ERR_NO_MEM;
	*outlen = bytes;
	out += 1;
	while (bits_left) {
		int i, bits_to_go = 8;

		*out = 0;
		if (bits_left < 8) {
			bits_to_go = bits_left;
			skipped = 8 - bits_left;
		}
		if (invert) {
			for (i = 0; i < bits_to_go; i++) 
				*out |= ((*in >> 1) & 1) << (7 - i);
		} else {
			*out = *in;
			if (bits_left < 8)
				return PKCS15_ERR_NOT_SUPPORTED;
		}
		bits_left -= bits_to_go;
		out++, in++;
	}
	out = *outbuf;
	out[0] = skipped;
	return 0;
}

static int encode_bit_field(const uint8_t *inbuf, size_t inlen,
			    uint8_t **outbuf, size_t *outlen)
{
	uint8_t		data[sizeof(unsigned int)];
	unsigned int	field = 0;
	size_t		i, bits;

	if (inlen != sizeof(data))
		return PKCS15_ERR_INSUF_BUFFER;

	/* count the bits */
	memcpy(&field, inbuf, inlen);
	for (bits = 0; field; bits++)
		field >>= 1;

	memcpy(&field, inbuf, inlen);
	for (i = 0; i < bits; i += 8)
		data[i/8] = field >> i;

	return encode_bit_string(data, bits, outbuf, outlen, 1);
}


static int pkcs15_asn1_encode_object_id(uint8_t **buf, size_t *buflen,
			     const struct icc_object_id *id)
{
	uint8_t temp[ICC_OBJECT_ID_OCTETS_MAX * 5], *p = temp;
	size_t	count = 0;
	int	i;
	const int *value = (const int *) id->value;

	for (i = 0; value[i] > 0 && i < ICC_OBJECT_ID_OCTETS_MAX; i++) {
		unsigned int k, shift;

		k = value[i];
		switch (i) {
		case 0:
			if (k > 2)
				return PKCS15_ERR_INVALID_ARGS;
			*p = k * 40;
			break;
		case 1:
			if (k > 39)
				return PKCS15_ERR_INVALID_ARGS;
			*p++ += k;
			break;
		default:
			shift = 28;
			while (shift && (k >> shift) == 0)
				shift -= 7;
			while (shift) {
				*p++ = 0x80 | ((k >> shift) & 0x7f);
				shift -= 7;
			}
			*p++ = k & 0x7F;
			break;
		}
	}
	if (i == 1) 
		/* an OID must have at least two components */
		return PKCS15_ERR_INVALID_ARGS;
	*buflen = count = p - temp;
	*buf = (uint8_t *) malloc(count);
	if (!*buf)
		return PKCS15_ERR_NO_MEM;
	memcpy(*buf, temp, count);
	return 0;
}

static const struct pkcs15_asn1_entry c_asn1_path[4] = {
	{ "path",   PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_OCTET_STRING, 0, NULL, NULL },
	{ "index",  PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "length", PKCS15_ASN1_INTEGER, PKCS15_ASN1_CTX | 0, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static int asn1_encode_path(const struct icc_path *path,
			    uint8_t **buf, size_t *bufsize, int depth)
{
	int r;
 	struct pkcs15_asn1_entry asn1_path[4];
	struct icc_path tpath = *path;

	pkcs15_copy_asn1_entry(c_asn1_path, asn1_path);
	pkcs15_format_asn1_entry(asn1_path + 0, (void *) &tpath.value,
				(void *) &tpath.len, 1);
	if (path->count > 0) {
		pkcs15_format_asn1_entry(asn1_path + 1, (void *) &tpath.idx, NULL, 1);
		pkcs15_format_asn1_entry(asn1_path + 2, (void *) &tpath.count, NULL, 1);
	}
	r = asn1_encode(asn1_path, buf, bufsize, depth + 1);
	return r;	
}

static const struct pkcs15_asn1_entry c_asn1_com_obj_attr[6] = {
	{ "label", PKCS15_ASN1_UTF8STRING, PKCS15_ASN1_TAG_UTF8STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "flags", PKCS15_ASN1_BIT_FIELD, PKCS15_ASN1_TAG_BIT_STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "authId", PKCS15_ASN1_PKCS15_ID, PKCS15_ASN1_TAG_OCTET_STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "userConsent", PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "accessControlRules", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_p15_obj[5] = {
	{ "commonObjectAttributes", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "classAttributes", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "subClassAttributes", PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 0 | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "typeAttributes", PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 1 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static int asn1_encode_p15_object(const struct asn1_pkcs15_object *obj,
				  uint8_t **buf, size_t *bufsize, int depth)
{
	int r;
	struct pkcs15_object p15_obj = *obj->p15_obj;
	struct pkcs15_asn1_entry asn1_c_attr[6], asn1_p15_obj[5];
	size_t label_len = strlen(p15_obj.label);
	size_t flags_len;

	pkcs15_copy_asn1_entry(c_asn1_com_obj_attr, asn1_c_attr);
	pkcs15_copy_asn1_entry(c_asn1_p15_obj, asn1_p15_obj);
	if (label_len != 0)
		pkcs15_format_asn1_entry(asn1_c_attr + 0, 
				(void *) p15_obj.label, &label_len, 1);
	if (p15_obj.flags) {
		flags_len = sizeof(p15_obj.flags);
		pkcs15_format_asn1_entry(asn1_c_attr + 1, 
				(void *) &p15_obj.flags, &flags_len, 1);
	}
	if (p15_obj.auth_id.len)
		pkcs15_format_asn1_entry(asn1_c_attr + 2, 
				(void *) &p15_obj.auth_id, NULL, 1);
	if (p15_obj.user_consent)
		pkcs15_format_asn1_entry(asn1_c_attr + 3, 
					(void *) &p15_obj.user_consent, 
					NULL, 1);
	/* FIXME: decode accessControlRules */
	pkcs15_format_asn1_entry(asn1_p15_obj + 0, asn1_c_attr, NULL, 1);
	pkcs15_format_asn1_entry(asn1_p15_obj + 1, obj->asn1_class_attr, 
				NULL, 1);
	if (obj->asn1_subclass_attr != NULL)
		pkcs15_format_asn1_entry(asn1_p15_obj + 2, 
					obj->asn1_subclass_attr, NULL, 1);
	pkcs15_format_asn1_entry(asn1_p15_obj + 3, 
				obj->asn1_type_attr, NULL, 1);

	r = asn1_encode(asn1_p15_obj, buf, bufsize, depth + 1);
	return r;
}


static const struct pkcs15_asn1_entry c_asn1_alg_id[6] = {
	{ "algorithm",  PKCS15_ASN1_OBJECT, PKCS15_ASN1_TAG_OBJECT, 0, NULL, NULL },
	{ "nullParam",  PKCS15_ASN1_NULL, PKCS15_ASN1_TAG_NULL, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

int pkcs15_asn1_encode_algorithm_id(uint8_t **buf, size_t *len,
				   const struct icc_algorithm_id *id,
				   int depth)
{
	struct asn1_pkcs15_algorithm_info *alg_info;
	struct icc_algorithm_id temp_id;
	struct pkcs15_asn1_entry asn1_alg_id[3];
	uint8_t *obj = NULL;
	size_t obj_len = 0;
	int r;
	uint8_t *tmp;

	alg_info = pkcs15_asn1_get_algorithm_info(id);
	if (alg_info == NULL) {
		return PKCS15_ERR_INVALID_ARGS;
	}

	/* Set the oid if not yet given */
	if (id->obj_id.value[0] <= 0) {
		temp_id = *id;
		temp_id.obj_id = alg_info->oid;
		id = &temp_id;
	}

	pkcs15_copy_asn1_entry(c_asn1_alg_id, asn1_alg_id);
	pkcs15_format_asn1_entry(asn1_alg_id + 0, (void *) &id->obj_id, NULL, 1);

	/* no parameters, write NULL tag */
	if (!id->params || !alg_info->encode)
		asn1_alg_id[1].flags |= PKCS15_ASN1_PRESENT;

	r = asn1_encode(asn1_alg_id, buf, len, depth + 1);
	if (r < 0)
		return r;

	/* Encode any parameters */
	if (id->params && alg_info->encode) {
		r = alg_info->encode(id->params, &obj, &obj_len, depth+1);
		if (r < 0) {
			if (obj)
				free(obj);
			return r;
		}
	}

	if (obj_len) {
		tmp = (uint8_t *) realloc(*buf, *len + obj_len);
		if (!tmp) {
			free(*buf);
			*buf = NULL;
			free(obj);
			return PKCS15_ERR_NO_MEM;
		}
		*buf = tmp;
		memcpy(*buf + *len, obj, obj_len);
		*len += obj_len;
		free(obj);
	}

	return 0;
}


static int asn1_write_element(unsigned int tag, const uint8_t *data, 
			      size_t datalen, uint8_t **out, size_t *outlen)
{
	uint8_t t;
	uint8_t *buf, *p;
	int c = 0;
	
	t = tag & 0x1F;
	if (t != (tag & PKCS15_ASN1_TAG_MASK)) {
		return PKCS15_ERR_INVALID_ARGS;
	}
	switch (tag & PKCS15_ASN1_CLASS_MASK) {
	case PKCS15_ASN1_UNI:
		break;
	case PKCS15_ASN1_APP:
		t |= ICC_ASN1_TAG_APPLICATION;
		break;
	case PKCS15_ASN1_CTX:
		t |= ICC_ASN1_TAG_CONTEXT;
		break;
	case PKCS15_ASN1_PRV:
		t |= ICC_ASN1_TAG_PRIVATE;
		break;
	}
	if (tag & PKCS15_ASN1_CONS)
		t |= ICC_ASN1_TAG_CONSTRUCTED;
	if (datalen > 127) {
		c = 1;
		while (datalen >> (c << 3))
			c++;
	}
	*outlen = 2 + c + datalen;
	buf = (uint8_t *) malloc(*outlen);
	if (buf == NULL)
		return PKCS15_ERR_NO_MEM;
	*out = p = buf;
	*p++ = t;
	if (c) {
		*p++ = 0x80 | c;
		while (c--)
			*p++ = (datalen >> (c << 3)) & 0xFF;
	} else
		*p++ = datalen & 0x7F;
	memcpy(p, data, datalen);
	
	return 0;
}

static int asn1_encode_entry(const struct pkcs15_asn1_entry *entry, uint8_t **obj,
			     size_t *objlen, int depth)
{
	void *param = entry->param;
	int (*callback_fun)(void *arg, uint8_t **nobj, size_t *nobjlen, int ndepth);
	const size_t *len = (const size_t *)entry->arg;
	int r = 0;
	uint8_t *buf = NULL;
	size_t buflen = 0;

	*(void **)(&callback_fun) = param;

	if (!(entry->flags & PKCS15_ASN1_PRESENT))
		goto no_obj;

	if (entry->type == PKCS15_ASN1_CHOICE) {
		const struct pkcs15_asn1_entry *list, *choice = NULL;

		list = (const struct pkcs15_asn1_entry *) param;
		while (list->name != NULL) {
			if (list->flags & PKCS15_ASN1_PRESENT) {
				if (choice) {
					pkcs15_log(P15_LOG_ERR, 
						"ASN.1 problem: more than "
						"one CHOICE when encoding %s: "
						"%s and %s both present",
						entry->name, 
						choice->name,
						list->name);
					return PKCS15_ERR_INVALID_ASN1_OBJ;
				}
				choice = list;
			}
			list++;
		}
		if (choice == NULL)
			goto no_obj;
		return asn1_encode_entry(choice, obj, objlen, depth + 1);
	}

	if (entry->type != PKCS15_ASN1_NULL && param == NULL)
		return PKCS15_ERR_INVALID_ASN1_OBJ;

	switch (entry->type) {
	case PKCS15_ASN1_STRUCT:
		r = asn1_encode((const struct pkcs15_asn1_entry *)param, 
				&buf, &buflen, depth + 1);
		break;
	case PKCS15_ASN1_NULL:
		buf = NULL;
		buflen = 0;
		break;
	case PKCS15_ASN1_BOOLEAN:
		buf = (uint8_t *)malloc(1);
		if (buf == NULL) {
			r = PKCS15_ERR_NO_MEM;
			break;
		}
		buf[0] = *((int *)param) ? 0xFF: 0;
		buflen = 1;
		break;
	case PKCS15_ASN1_INTEGER:
	case PKCS15_ASN1_ENUMERATED:
		r = asn1_encode_integer(*((int *)entry->param), &buf, &buflen);
		break;
	case PKCS15_ASN1_BIT_STRING_NI:
	case PKCS15_ASN1_BIT_STRING:
		if (entry->type == PKCS15_ASN1_BIT_STRING)
			r = encode_bit_string((const uint8_t *)param, *len, 
						&buf, &buflen, 1);
		else 
			r = encode_bit_string((const uint8_t *)param, *len,
						&buf, &buflen, 0);
		break;
	case PKCS15_ASN1_BIT_FIELD:
		r = encode_bit_field((const uint8_t *)param, *len, &buf, &buflen);
		break;
	case PKCS15_ASN1_PRINTABLESTRING:
	case PKCS15_ASN1_OCTET_STRING:
	case PKCS15_ASN1_UTF8STRING:
		buf = (uint8_t *)malloc(*len + 1);
		if (!buf) {
			r = PKCS15_ERR_NO_MEM;
			break;
		}
		buflen = 0;
		/* If the integer is supported to be unsigned, insert
		 * a padding byte if the MSB is one */
		if ((entry->flags & PKCS15_ASN1_UNSIGNED) 
			&&(((uint8_t *)param)[0] & 0x80)) {
			buf[buflen++] = 0x00;
		}
		memcpy(buf + buflen, param, *len);
		buflen += *len;
		break;
	case PKCS15_ASN1_GENERALIZEDTIME:
		buf = (uint8_t *)malloc(*len);
		if (!buf) {
			r = PKCS15_ERR_NO_MEM;
			break;
		}
		memcpy(buf, param, *len);
		buflen = *len;
		break;
	case PKCS15_ASN1_OBJECT:
		r = pkcs15_asn1_encode_object_id(&buf, &buflen, 
						(struct icc_object_id *) param);
		break;
	case PKCS15_ASN1_PATH:
		r = asn1_encode_path((const struct icc_path *)param, &buf,
					&buflen, depth);
		break;
	case PKCS15_ASN1_PKCS15_ID:
		{
			const struct pkcs15_id *id = 
				(const struct pkcs15_id *)param;

			buf = (uint8_t *)malloc(id->len);
			if (!buf) {
				r = PKCS15_ERR_NO_MEM;
				break;
			}
			memcpy(buf, id->value, id->len);
			buflen = id->len;
		}
		break;
	case PKCS15_ASN1_PKCS15_OBJECT:
		r = asn1_encode_p15_object((const struct asn1_pkcs15_object *) param,
					   &buf, &buflen, depth);
		break;
	case PKCS15_ASN1_ALGORITHM_ID:
		r = pkcs15_asn1_encode_algorithm_id(&buf, &buflen, 
				(const struct icc_algorithm_id *)param,
				depth);
		break;
	case PKCS15_ASN1_CALLBACK:
		r = callback_fun(entry->arg, &buf, &buflen, depth);
		break;
	default:
		return PKCS15_ERR_INVALID_ASN1_OBJ;
	}
	if (r) {
		pkcs15_log(P15_LOG_ERR, "encoding of ASN.1 object '%s' failed: %d",
			entry->name, r);
		if (buf) free(buf);
		return r;
	}

	/* Treatment of OPTIONAL elements:
	 *  -	if the encoding has 0 length, and the element is OPTIONAL,
	 *	we don't write anything (unless it's an ASN1 NULL and the
	 *      PKCS15_ASN1_PRESENT flag is set).
	 *  -	if the encoding has 0 length, but the element is non-OPTIONAL,
	 *	constructed, we write a empty element (e.g. a SEQUENCE of
	 *      length 0). In case of an ASN1 NULL just write the tag and
	 *      length (i.e. 0x05,0x00).
	 *  -	any other empty objects are considered bogus
	 */
	
no_obj:
	if (!buflen && entry->flags &PKCS15_ASN1_OPTIONAL 
		&& !(entry->flags & PKCS15_ASN1_PRESENT)) {
		/* This happens when we try to encode e.g. 
		 * the subClassAttributes , which may be empty */
		*obj = NULL;
		*objlen = 0;
		r = PKCS15_SUCCESS;
	} else if (buflen || entry->type == PKCS15_ASN1_NULL
		|| entry->tag & PKCS15_ASN1_CONS) {
		r = asn1_write_element(entry->tag, buf, buflen, obj, objlen);
	} else if (!(entry->flags & PKCS15_ASN1_PRESENT)) {
		r = PKCS15_ERR_INVALID_ASN1_OBJ;
	} else {
		r = PKCS15_ERR_INVALID_ASN1_OBJ;
	}
	if (buf) free(buf);

	return r;	
}

int asn1_encode(const struct pkcs15_asn1_entry *asn1, uint8_t **ptr, 
		      size_t *size, int depth)
{
	int idx, r;
	uint8_t *obj = NULL, *buf = NULL, *tmp;
	size_t total = 0, objsize;

	for (idx = 0; asn1[idx].name != NULL; idx++) {
		r = asn1_encode_entry(&asn1[idx], &obj, &objsize, depth);
		if (r) {
			if (obj) free(obj);
			if (buf) free(buf);
			return r;
		}
		/* in case of an empty (optinal) element continue with 
		 * the next asn1 element */
		if (objsize == 0) continue;

		tmp = (uint8_t *)realloc(buf, total + objsize);
		if (!tmp) {
			if (obj) free(obj);
			if (buf) free(buf);
			return PKCS15_ERR_NO_MEM;
		}
		buf = tmp;
		memcpy(buf + total, obj, objsize);
		free(obj);
		obj = NULL;
		total += objsize;
	}
	*ptr = buf;
	*size = total;

	return PKCS15_SUCCESS;
}

int pkcs15_asn1_encode(const struct pkcs15_asn1_entry *asn1, uint8_t **ptr, 
		      size_t *size)
{
	return asn1_encode(asn1, ptr, size, 0);
}

static const uint8_t *pkcs15_asn1_skip_tag(const uint8_t **buf, size_t *buflen,
				    unsigned int tag_in, size_t *taglen_out)
{
	const uint8_t *p = *buf;
	size_t len = *buflen, taglen;
	unsigned int cla, tag;

	if (icc_asn1_read_tag((const uint8_t **) &p, len, &cla, &tag, &taglen)
		!= ICC_SUCCESS)
		return NULL;
	switch (cla & 0xC0) {
	case ICC_ASN1_TAG_UNIVERSAL:
		if ((tag_in & PKCS15_ASN1_CLASS_MASK) != PKCS15_ASN1_UNI)
			return NULL;
		break;
	case ICC_ASN1_TAG_APPLICATION:
		if ((tag_in & PKCS15_ASN1_CLASS_MASK) != PKCS15_ASN1_APP)
			return NULL;
		break;
	case ICC_ASN1_TAG_CONTEXT:
		if ((tag_in & PKCS15_ASN1_CLASS_MASK) != PKCS15_ASN1_CTX)
			return NULL;
		break;
	case ICC_ASN1_TAG_PRIVATE:
		if ((tag_in & PKCS15_ASN1_CLASS_MASK) != PKCS15_ASN1_PRV)
			return NULL;
		break;
	}
	if (cla & ICC_ASN1_TAG_CONSTRUCTED) {
		if ((tag_in & PKCS15_ASN1_CONS) == 0)
			return NULL;
	} else {
		if (tag_in & PKCS15_ASN1_CONS)
			return NULL;
	}
	if ((tag_in & PKCS15_ASN1_TAG_MASK) != tag)
		return NULL;
	len -= (p - *buf); /* header size */
	if (taglen > len)
		return NULL;
	*buflen -= (p - *buf) + taglen;
	*buf = p + taglen; /* Point to next tag */
	*taglen_out = taglen;

	return p;
}

int pkcs15_asn1_decode_integer(const uint8_t * inbuf, size_t inlen, int *out)
{
	int    a = 0;
	size_t i;

	if (inlen > sizeof(int))
		return PKCS15_ERR_INVALID_ASN1_OBJ;
	for (i = 0; i < inlen; i++) {
		a <<= 8;
		a |= *inbuf++;
	}
	*out = a;
	return 0;
}

static int decode_bit_string(const uint8_t * inbuf, size_t inlen, void *outbuf,
			     size_t outlen, int invert)
{
	const uint8_t *in = inbuf;
	uint8_t *out = (uint8_t *) outbuf;
	int zero_bits = *in & 0x07;
	size_t octets_left = inlen - 1;
	int i, count = 0;

	memset(outbuf, 0, outlen);
	in++;
	if (outlen < octets_left)
		return PKCS15_ERR_INSUF_BUFFER;
	if (inlen < 1)
		return PKCS15_ERR_INVALID_ASN1_OBJ;
	while (octets_left) {
		/* 1st octet of input:  ABCDEFGH, where A is the MSB */
		/* 1st octet of output: HGFEDCBA, where A is the LSB */
		/* first bit in bit string is the LSB in first resulting octet */
		int bits_to_go;

		*out = 0;
		if (octets_left == 1)
			bits_to_go = 8 - zero_bits;
		else
			bits_to_go = 8;
		if (invert)
			for (i = 0; i < bits_to_go; i++) {
				*out |= ((*in >> (7 - i)) & 1) << i;
			}
		else {
			*out = *in;
		}
		out++;
		in++;
		octets_left--;
		count++;
	}
	return (count * 8) - zero_bits;
}

/*
 * Bitfields are just bit strings, stored in an unsigned int
 * (taking endianness into account)
 */
static int decode_bit_field(const uint8_t * inbuf, size_t inlen, 
			    void *outbuf, size_t outlen)
{
	uint8_t		data[sizeof(unsigned int)];
	unsigned int	field = 0;
	int		i, n;

	if (outlen != sizeof(data))
		return PKCS15_ERR_INSUF_BUFFER;

	n = decode_bit_string(inbuf, inlen, data, sizeof(data), 1);
	if (n < 0)
		return n;

	for (i = 0; i < n; i += 8) {
		field |= (data[i/8] << i);
	}
	memcpy(outbuf, &field, outlen);
	return 0;
}

int pkcs15_asn1_decode_object_id(const uint8_t * inbuf, size_t inlen,
				 struct icc_object_id *id)
{
	int i, a;
	const uint8_t *p = inbuf;
	int *octet;
	
	if (inlen == 0 || inbuf == NULL || id == NULL)
		return PKCS15_ERR_INVALID_ARGS;
	octet = id->value;
	for (i = 0; i < ICC_OBJECT_ID_OCTETS_MAX; i++)
		id->value[i] = -1;
	a = *p;
	*octet++ = a / 40;
	*octet++ = a % 40;
	inlen--;
	
	while (inlen) {
		p++;
		a = *p & 0x7F;
		inlen--;
		while (inlen && *p & 0x80) {
			p++;
			a <<= 7;
			a |= *p & 0x7F;
			inlen--;
		}
		*octet++ = a;
		if (octet - id->value >= ICC_OBJECT_ID_OCTETS_MAX - 1)
			return PKCS15_ERR_INVALID_ASN1_OBJ;
	};
	
	return 0;
}

static int pkcs15_asn1_decode_utf8string(const uint8_t *inbuf, size_t inlen,
					 uint8_t *out, size_t *outlen)
{
	if (inlen+1 > *outlen)
		return PKCS15_ERR_INSUF_BUFFER;
	*outlen = inlen+1;
	memcpy(out, inbuf, inlen);
	out[inlen] = 0;
	return 0;
}


static int asn1_decode_path(const uint8_t *in, size_t len,
			    struct icc_path *path, int depth)
{
	int idx, count, r;
	struct pkcs15_asn1_entry asn1_path[4];
	
	pkcs15_copy_asn1_entry(c_asn1_path, asn1_path);
	pkcs15_format_asn1_entry(asn1_path + 0, &path->value, &path->len, 0);
	pkcs15_format_asn1_entry(asn1_path + 1, &idx, NULL, 0);
	pkcs15_format_asn1_entry(asn1_path + 2, &count, NULL, 0);
	path->len = ICC_PATH_MAX;
	r = asn1_decode(asn1_path, in, len, NULL, NULL, 0, depth + 1);
	if (r)
		return r;
	if (path->len == 2)
		path->type = ICC_PATH_TYPE_FILE_ID;
	else
		path->type = ICC_PATH_TYPE_PATH;
	if ((asn1_path[1].flags & PKCS15_ASN1_PRESENT)
	 && (asn1_path[2].flags & PKCS15_ASN1_PRESENT)) {
		path->idx = idx;
		path->count = count;
	} else {
		path->idx = 0;
		path->count = -1;
	}

	return 0;
}

static int asn1_decode_p15_object(const uint8_t *in, size_t len, 
				  struct asn1_pkcs15_object *obj, int depth)
{
	int r;
	struct pkcs15_object *p15_obj = obj->p15_obj;
	struct pkcs15_asn1_entry asn1_c_attr[6], asn1_p15_obj[5];
	size_t flags_len = sizeof(p15_obj->flags);
	size_t label_len = sizeof(p15_obj->label);

	pkcs15_copy_asn1_entry(c_asn1_com_obj_attr, asn1_c_attr);
	pkcs15_copy_asn1_entry(c_asn1_p15_obj, asn1_p15_obj);
	pkcs15_format_asn1_entry(asn1_c_attr + 0, p15_obj->label, &label_len, 0);
	pkcs15_format_asn1_entry(asn1_c_attr + 1, &p15_obj->flags, &flags_len, 0);
	pkcs15_format_asn1_entry(asn1_c_attr + 2, &p15_obj->auth_id, NULL, 0);
	pkcs15_format_asn1_entry(asn1_c_attr + 3, &p15_obj->user_consent, NULL, 0);
	/* FIXME: encode accessControlRules */
	pkcs15_format_asn1_entry(asn1_c_attr + 4, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_p15_obj + 0, asn1_c_attr, NULL, 0);
	pkcs15_format_asn1_entry(asn1_p15_obj + 1, obj->asn1_class_attr, NULL, 0);
	pkcs15_format_asn1_entry(asn1_p15_obj + 2, obj->asn1_subclass_attr, NULL, 0);
	pkcs15_format_asn1_entry(asn1_p15_obj + 3, obj->asn1_type_attr, NULL, 0);

	r = asn1_decode(asn1_p15_obj, in, len, NULL, NULL, 0, depth + 1);
	return r;
}

int pkcs15_asn1_decode_algorithm_id(const uint8_t *in, size_t len, 
				    struct icc_algorithm_id *id, int depth)
{
	struct asn1_pkcs15_algorithm_info *alg_info;
	struct pkcs15_asn1_entry asn1_alg_id[3];
	int r;

	pkcs15_copy_asn1_entry(c_asn1_alg_id, asn1_alg_id);
	pkcs15_format_asn1_entry(asn1_alg_id + 0, &id->obj_id, NULL, 0);

	memset(id, 0, sizeof(*id));
	r = asn1_decode(asn1_alg_id, in, len, &in, &len, 0, depth + 1);
	if (r < 0)
		return r;

	/* See if we understand the algorithm, and if we do, check
	 * whether we know how to decode any additional parameters */
	id->algorithm = (unsigned int ) -1;
	if ((alg_info = pkcs15_asn1_get_algorithm_info(id)) != NULL) {
		id->algorithm = alg_info->id;
		if (alg_info->decode) {
			if (asn1_alg_id[1].flags & PKCS15_ASN1_PRESENT)
				return PKCS15_ERR_INVALID_ASN1_OBJ;
			r = alg_info->decode(&id->params, in, len, depth);
		}
	}

	return r;
}

static const struct pkcs15_asn1_entry c_asn1_se_info[4] = {
	{ "se",     PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, 0, NULL, NULL },
	{ "owner",  PKCS15_ASN1_OBJECT,  PKCS15_ASN1_TAG_OBJECT,  PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "aid",    PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_OCTET_STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};


static int asn1_decode_se_info(const uint8_t *obj, size_t objlen,
                               struct pkcs15_sec_env_info ***se, size_t *num,
			       int depth)
{
	struct pkcs15_sec_env_info **ses;
	const unsigned char *p;
	size_t plen, idx = 0, size = 8, left = size;
	int ret = PKCS15_SUCCESS;

	p = icc_asn1_find_tag(obj, objlen, 0x30, &plen);
	if (p == NULL) 
		return PKCS15_ERR_INVALID_ASN1_OBJ;

	ses = calloc(size, sizeof(struct pkcs15_sec_env_info *));
	if (ses == NULL)
		return PKCS15_ERR_NO_MEM;

	while (plen != 0) {
		struct pkcs15_asn1_entry asn1_se_info[4];

		struct pkcs15_sec_env_info *si = 
			calloc(1, sizeof(struct pkcs15_sec_env_info));
		if (si == NULL) {
			ret = PKCS15_ERR_NO_MEM;
			goto err;
		}

		si->aid_len = sizeof(si->aid);
		pkcs15_copy_asn1_entry(c_asn1_se_info, asn1_se_info);
		pkcs15_format_asn1_entry(asn1_se_info + 0, &si->sec, NULL, 0);
		pkcs15_format_asn1_entry(asn1_se_info + 1, &si->owner, NULL, 0);
		pkcs15_format_asn1_entry(asn1_se_info + 2, &si->aid, &si->aid_len, 0);
		ret = asn1_decode(asn1_se_info, p, plen, &p, &plen, 0, depth+1);
		if (ret != PKCS15_SUCCESS) {
			free(si);
			ret = PKCS15_ERR_INVALID_ASN1_OBJ;
			goto err;
		}
		if (--left == 0) {
			struct pkcs15_sec_env_info **np;
			size <<= 1;
			np = realloc(ses, sizeof(struct pkcs15_sec_env_info *) * size);
			if (np == NULL) {
				free(si);
				ret = PKCS15_ERR_NO_MEM;
				goto err;
			}
			ses  = np;
			left = size >> 1;
		}
		ses[idx++] = si;
	}
err:
	if (ret == PKCS15_SUCCESS) {
		*se  = ses;
		*num = idx;
	} else {
		size_t i;
		for (i = 0; i < idx; i++)
			free(ses[i]);
		free(ses);
	} 

	return ret;	
}


static int asn1_decode_entry (struct pkcs15_asn1_entry *entry, 
			      const uint8_t *obj, size_t objlen, int depth)
{
	void *param = entry->param;
	int (*callback_func)(void *arg, const uint8_t *nobj,
			     size_t nobjlen, int ndepth); 
	size_t *len = (size_t *) entry->arg;
	int r = 0;

	*(void **)(&callback_func) = param;

	switch (entry->type) {
	case PKCS15_ASN1_STRUCT:
		if (param != NULL)
			r = asn1_decode((struct pkcs15_asn1_entry *) param, obj, 
					objlen, NULL, NULL, 0, depth + 1);
		break;
	case PKCS15_ASN1_NULL:
		break;
	case PKCS15_ASN1_BOOLEAN:
		if (param != NULL) {
			if (objlen != 1) {
				r = PKCS15_ERR_INVALID_ASN1_OBJ;
			} else
				*((int *) param) = obj[0] ? 1 : 0;
		}
		break;
	case PKCS15_ASN1_INTEGER:
	case PKCS15_ASN1_ENUMERATED:
		if (param != NULL)
			r = pkcs15_asn1_decode_integer(obj, objlen, 
					(int *) entry->param);
		break;
	case PKCS15_ASN1_BIT_STRING_NI:
	case PKCS15_ASN1_BIT_STRING:
		if (param != NULL) {
			int invert = (entry->type == PKCS15_ASN1_BIT_STRING) ? 1 : 0;
			if (objlen < 1) {
				r = PKCS15_ERR_INVALID_ASN1_OBJ;
				break;
			}
			if (entry->flags & PKCS15_ASN1_ALLOC) {
				uint8_t **buf = (uint8_t **) param;
				*buf = (uint8_t *) malloc(objlen-1);
				if (*buf == NULL) {
					r = PKCS15_ERR_NO_MEM;
					break;
				}
				*len = objlen-1;
				param = *buf;
			}
			r = decode_bit_string(obj, objlen, (uint8_t *) param, 
					      *len, invert);
			if (r >= 0) {
				*len = r;
				r = 0;
			}
		}
		break;
	case PKCS15_ASN1_BIT_FIELD:
		if (param != NULL)
			r = decode_bit_field(obj, objlen, (uint8_t *) param, *len);
		break;
	case PKCS15_ASN1_OCTET_STRING:
		if (param != NULL) {
			size_t c;

			/* Strip off padding zero */
			if ((entry->flags & PKCS15_ASN1_UNSIGNED)
			 && obj[0] == 0x00 && objlen > 1) {
				objlen--;
				obj++;
			}

			/* Allocate buffer if needed */
			if (entry->flags & PKCS15_ASN1_ALLOC) {
				uint8_t **buf = (uint8_t **) param;
				*buf = (uint8_t *) malloc(objlen);
				if (*buf == NULL) {
					r = PKCS15_ERR_NO_MEM;
					break;
				}
				c = *len = objlen;
				param = *buf;
			} else
				c = objlen > *len ? *len : objlen;

			memcpy(param, obj, c);
			*len = c;
		}
		break;
	case PKCS15_ASN1_GENERALIZEDTIME:
		if (param != NULL) {
			size_t c;
			assert(len != NULL);
			if (entry->flags & PKCS15_ASN1_ALLOC) {
				uint8_t **buf = (uint8_t **) param;
				*buf = (uint8_t *) malloc(objlen);
				if (*buf == NULL) {
					r = PKCS15_ERR_NO_MEM;
					break;
				}
				c = *len = objlen;
				param = *buf;
			} else
				c = objlen > *len ? *len : objlen;

			memcpy(param, obj, c);
			*len = c;
		}
		break;
	case PKCS15_ASN1_OBJECT:
		if (param != NULL)
			r = pkcs15_asn1_decode_object_id(obj, objlen, (struct icc_object_id *) param);
		break;
	case PKCS15_ASN1_PRINTABLESTRING:
	case PKCS15_ASN1_UTF8STRING:
		if (param != NULL) {
			assert(len != NULL);
			if (entry->flags & PKCS15_ASN1_ALLOC) {
				uint8_t **buf = (uint8_t **) param;
				*buf = (uint8_t *) malloc(objlen+1);
				if (*buf == NULL) {
					r = PKCS15_ERR_NO_MEM;
					break;
				}
				*len = objlen+1;
				param = *buf;
			}
			r = pkcs15_asn1_decode_utf8string(obj, objlen, (uint8_t *) param, len);
			if (entry->flags & PKCS15_ASN1_ALLOC) {
				*len -= 1;
			}
		}
		break;
	case PKCS15_ASN1_PATH:
		if (entry->param != NULL)
			r = asn1_decode_path(obj, objlen, (struct icc_path *) param, depth);
		break;
	case PKCS15_ASN1_PKCS15_ID:
		if (entry->param != NULL) {
			struct pkcs15_id *id = (struct pkcs15_id *) param;
			size_t c = objlen > sizeof(id->value) ? sizeof(id->value) : objlen;
			
			memcpy(id->value, obj, c);
			id->len = c;
		}
		break;
	case PKCS15_ASN1_PKCS15_OBJECT:
		if (entry->param != NULL)
			r = asn1_decode_p15_object(obj, objlen, (struct asn1_pkcs15_object *) param, depth);
		break;
	case PKCS15_ASN1_ALGORITHM_ID:
		if (entry->param != NULL)
			r = pkcs15_asn1_decode_algorithm_id(obj, objlen, (struct icc_algorithm_id *) param, depth);
		break;
	case PKCS15_ASN1_SE_INFO:
		if (entry->param != NULL)
			r = asn1_decode_se_info(obj, objlen, (struct pkcs15_sec_env_info ***)entry->param, len, depth);
		break;
	case PKCS15_ASN1_CALLBACK:
		if (entry->param != NULL)
			r = callback_func(entry->arg, obj, objlen, depth);
		break;
	default:
		return PKCS15_ERR_INVALID_ASN1_OBJ;
	}
	if (r) {
		return r;
	}
	entry->flags |= PKCS15_ASN1_PRESENT;
	return 0;	
}

int asn1_decode(struct pkcs15_asn1_entry *asn1, const uint8_t *in, size_t len,
		const uint8_t **newp, size_t *len_left, int choice, int depth)
{
	int r, idx = 0;
	const uint8_t *p = in, *obj;
	struct pkcs15_asn1_entry *entry = asn1;
	size_t left = len, objlen;

	if (left < 2) {
		while (asn1->name && (asn1->flags & PKCS15_ASN1_OPTIONAL))
			asn1++;
		/* If all elements were optional, there is nothing to 
		 * complain about */
		if (asn1->name == NULL)
			return 0;
		return PKCS15_ERR_ASN1_OBJ_NOT_FOUND;
	}
	if (p[0] == 0 || p[0] == 0xFF || len == 0)
		return PKCS15_ERR_ASN1_END_OF_CONTENTS;
	for (idx = 0; asn1[idx].name != NULL; idx++) {
		entry = &asn1[idx];
		r = 0;

		/* Special case CHOICE has no tag */
		if (entry->type == PKCS15_ASN1_CHOICE) {
			r = asn1_decode((struct pkcs15_asn1_entry *)entry->param,
				p, left, &p, &left, 1, depth + 1);
			if (r >= 0)
				r = 0;
			goto decode_ok;
		}

		obj = pkcs15_asn1_skip_tag(&p, &left, entry->tag, &objlen);
		if (obj == NULL) {
			if (choice)
				continue;
			if (entry->flags & PKCS15_ASN1_OPTIONAL)
				continue;
			return PKCS15_ERR_ASN1_OBJ_NOT_FOUND;
		}
		r = asn1_decode_entry(entry, obj, objlen, depth);
decode_ok:
		if (r) return r;
		if (choice) break;
	}
	if (choice && asn1[idx].name == NULL) /* No match */
		return PKCS15_ERR_ASN1_OBJ_NOT_FOUND;
	if (newp != NULL)
		*newp = p;
	if (len_left != NULL)
		*len_left = left;
	if (choice)
		return idx;
	return 0;
}

int pkcs15_asn1_decode(struct pkcs15_asn1_entry *asn1, const uint8_t *in, 
		       size_t len, const uint8_t **newp, size_t *len_left)
{
	return asn1_decode(asn1, in, len, newp, len_left, 0, 0);
}

int pkcs15_asn1_decode_choice(struct pkcs15_asn1_entry *asn1, const uint8_t *in, 
			  size_t len, const uint8_t **newp, size_t *len_left)
{
	return asn1_decode(asn1, in, len, newp, len_left, 1, 0);
}
