#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

DECLARE_LIST(p15_cards);

#define for_each_card(e)			\
	list_for_each_entry(struct p15_card, e, &p15_cards, link)
#define for_each_card_safe(e, n)		\
	list_for_each_entry_safe(struct p15_card, e, n, &p15_cards, link)


static int pkcs15_free_object(struct pkcs15_object *obj);

void p15_app_count_inc(struct p15_card *hd)
{
	if (hd)
		hd->app_count++;
}

void p15_app_count_dec(struct p15_card *hd)
{
	if (hd)
		hd->app_count--;
}

int p15_app_count(struct p15_card *hd)
{
	return hd->app_count;
}

int p15_app_is_exist(struct p15_card *hd, struct icc_app_info *app)
{
	struct icc_app_info *apps = hd->app[0];
	int i;

	for (i = 0; apps; i++) {
		if ((0 == memcmp(apps->aid, app->aid, app->aid_len)) &&
	    	    (0 == memcmp(apps->path.value, app->path.value, app->path.len)))
				return 1;
		apps = hd->app[i];
	}
	return 0;
}

struct icc_app_info **p15_app_poniter(struct p15_card *hd)
{
	return hd->app;
}

struct p15_card *pkcs15_card_new(void)
{
	struct p15_card *card;

	card = malloc(sizeof(struct p15_card));
	if (!card)
		return NULL;
	memset(card, 0, sizeof(struct p15_card));

	list_init(&card->df_list);
	list_init(&card->obj_list);

	list_init(&card->link);
	list_insert_before(&card->link, &p15_cards);

	return card;
}

void pkcs15_card_free(struct p15_card *p15_card)
{
	struct pkcs15_df *pos_df, *n_df;
	struct pkcs15_object *pos_obj, *n_obj;

	if (!p15_card) return;
	/* TODO: free members */

	list_for_each_entry_safe(struct pkcs15_df, pos_df, n_df,
				 &p15_card->df_list, link) {
		list_delete(&pos_df->link);
		if (pos_df->filp)
			icc_file_free(pos_df->filp);
		free(pos_df);
	}
	list_for_each_entry_safe(struct pkcs15_object, pos_obj, n_obj,
				 &p15_card->obj_list, link) {
		list_delete(&pos_obj->link);
		pkcs15_free_object(pos_obj);
	}
	
	if (p15_card->app_root)
		icc_file_free(p15_card->app_root);
	if (p15_card->odf)
		icc_file_free(p15_card->odf);
	if (p15_card->ef_dir)
		icc_file_free(p15_card->ef_dir);
	if (p15_card->tif)
		icc_file_free(p15_card->tif);
	if (p15_card->unused)
		icc_file_free(p15_card->unused);
	if (p15_card->tokeninfo.serial_num)
		free(p15_card->tokeninfo.serial_num);
	if (p15_card->tokeninfo.manufacturer_id)
		free(p15_card->tokeninfo.manufacturer_id);
	if (p15_card->tokeninfo.label)
		free(p15_card->tokeninfo.label);
	if (p15_card->tokeninfo.last_update)
		free(p15_card->tokeninfo.last_update);
	if (p15_card->tokeninfo.prefered_lang)
		free(p15_card->tokeninfo.prefered_lang);
	if (p15_card->tokeninfo.sec_info) {
		size_t i;

		for (i = 0; i < p15_card->tokeninfo.sec_info_num; i++)
			free(p15_card->tokeninfo.sec_info[i]);
		free(p15_card->tokeninfo.sec_info);
	}
	if (p15_card->app_count > 0) {
		int i = 0;
		for(; i < p15_card->app_count; i++)
			free(p15_card->app[i]);
	}
	list_delete(&p15_card->link);
	free(p15_card);
}

static int pkcs15_free_object(struct pkcs15_object *obj)
{
	return PKCS15_SUCCESS;
}

/* lets take over the PKCS#15 app */
int p15_card_start(struct p15_card *hd)
{
	return -1;
}

static int p15card_dump(ui_session_t *sess, ui_entry_t *inst,
			     void *ctx, int argc, char **argv)
{
	ui_table_t *table = ui_table_by_name(sess, "p15card_list");
	int i = 0;
	char buf[3 * ICC_PATH_MAX];
	struct p15_card *card;

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "p15card_list");
	if (!table)
		return -1;

	ui_add_title(table, 0, "index");
	ui_add_title(table, 1, "EF(DIR)");
	ui_add_title(table, 2, "app_root");
	ui_add_title(table, 3, "ODF");
	ui_add_title(table, 4, "TIF");
	ui_add_title(table, 5, "Unused");

#define _TMP_BUILD_BUF(file)						\
		r = icc_fetch_file_path(file, buf, sizeof (buf));	\
		if (r)	snprintf(buf, sizeof(buf), "not found");	\

	i = 0;
	for_each_card(card) {
		int r;
		if (card->binded == 0)
			continue;

		snprintf(buf, sizeof(buf), "%04x", card->idx);
		ui_add_value(table, "index", i, buf);

		_TMP_BUILD_BUF(card->ef_dir);
		ui_add_value(table, "EF(DIR)", i, buf);

		_TMP_BUILD_BUF(card->app_root);
		ui_add_value(table, "app_root", i, buf);

		_TMP_BUILD_BUF(card->odf);
		ui_add_value(table, "ODF", i, buf);

		_TMP_BUILD_BUF(card->tif);
		ui_add_value(table, "TIF", i, buf);

		_TMP_BUILD_BUF(card->unused);
		ui_add_value(table, "Unused", i, buf);
		i++;
	}
	sess->result_table = table;
	return 0;
}

ui_schema_t p15_card_scheme[] = {
	/* .pcsc.icc */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".pkcs15.card", "card", "PKCS#15 cards" },

	{ UI_TYPE_NONE },
};

ui_command_t p15_card_command = {
	"dump",
	"dump card",
	".pkcs15.card",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(p15_card_command.link),
	p15card_dump,
};

int __init pkcs15_card_init(void)
{
	ui_register_schema(p15_card_scheme);

	ui_register_command(&p15_card_command);

	return 0;
}

void __exit pkcs15_card_exit(void)
{
	ui_unregister_command(&p15_card_command);

	ui_unregister_schema(p15_card_scheme);
}
