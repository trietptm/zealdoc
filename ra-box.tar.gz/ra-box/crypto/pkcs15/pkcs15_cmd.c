#include "pkcs15_priv.h"

static struct scard_handle *card_handle = NULL;
static struct pkcs15_handle *p15_handle = NULL;

static void tool_connect_complete(void *user_data, int ret)
{
	if (ret == SCARD_SUCCESS) {
		pkcs15_log(PKCS15_LOG_DEBUG, "tool_connect_complete success");
	} else {
		pkcs15_log(PKCS15_LOG_ERR, "tool_connect_complete failed: %d", ret);	
	}
}

int pkcs15_tool_connect(ui_session_t *sess, ui_entry_t *inst,
			void *ctx, int argc, char **argv)
{
	int reader_idx, slot_idx = 0;
	int r;

	reader_idx = atoi(argv[0]);

	r = scard_connect(reader_idx, slot_idx, &card_handle, 
			  tool_connect_complete, NULL);
	if (r != SCARD_SUCCESS) {
		pkcs15_log(PKCS15_LOG_ERR, "pkcs15_connect failed: %d", r);
	} else {
		pkcs15_log(PKCS15_LOG_ERR, "pkcs15_connect success");
	}
	return r;
}

int pkcs15_tool_disconnect(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int r;

	if (!card_handle) {
		pkcs15_log(PKCS15_LOG_ERR, "There is no card connected.");
		return SCARD_ERR_NO_CARD;
	}

	r = scard_disconnect(card_handle);
	if (r != SCARD_SUCCESS) {
		pkcs15_log(PKCS15_LOG_ERR, "pkcs15_disconnect failed: %d", r);
	} else {
		card_handle = NULL;
		pkcs15_log(PKCS15_LOG_ERR, "pkcs15_disconnect success");
	}
	return r;
}

static void tool_bind_complete(void *user_data, int ret)
{
	if (ret == SCARD_SUCCESS) {
		pkcs15_log(PKCS15_LOG_DEBUG, "tool_bind_complete success");
	} else {
		pkcs15_log(PKCS15_LOG_ERR, "tool_bind_complete failed: %d", ret);	
	}
}

int pkcs15_tool_bind(ui_session_t *sess, ui_entry_t *inst,
		     void *ctx, int argc, char **argv)
{
	int r;

	if (!card_handle) {
		pkcs15_log(PKCS15_LOG_ERR, "Please first connect.");
		return PKCS15_ERR_OTHER;
	}
	
	if (!scard_handle_check_valid(card_handle)) {
		pkcs15_log(PKCS15_LOG_ERR, "Handle is invalid");
		return PKCS15_ERR_OTHER;
	}

	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		pkcs15_log(PKCS15_LOG_ERR, "icc not present or powered: %d", r);
		return PKCS15_ERR_OTHER;
	}

	r = pkcs15_bind(card_handle, &p15_handle, tool_bind_complete, NULL);
	if (r != PKCS15_SUCCESS) {
		pkcs15_log(PKCS15_LOG_ERR, "pkcs15_bind failed: %d", r);	
	}

	return r;
}

int pkcs15_tool_unbind(ui_session_t *sess, ui_entry_t *inst,
		     void *ctx, int argc, char **argv)
{
	if (!p15_handle) {
		pkcs15_log(PKCS15_LOG_ERR, "Not even bind");
		return PKCS15_ERR_INVALID_HANDLE;
	}

	pkcs15_unbind(p15_handle);
	p15_handle = NULL;

	return PKCS15_SUCCESS;
}