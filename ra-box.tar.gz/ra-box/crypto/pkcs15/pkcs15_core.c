#include "pkcs15_priv.h"

#define PKCS15_SERVICE_DESC	"Public-key cryptography standards 15"

int pkcs15_logger = 0;
log_source_t pkcs15_log_source = {
	"pkcs15"
};

void pkcs15_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(pkcs15_logger, level, format, ap);
	va_end(ap);
}

static int __init pkcs15_log_init(void)
{
	pkcs15_logger = log_register_source(&pkcs15_log_source);
	return !pkcs15_logger;
}

static void __exit pkcs15_log_exit(void)
{
	log_unregister_source(pkcs15_logger);
}

static void __bind_test(void *user_data, int ret)
{
	if (ret == 0) {
		pkcs15_log(PKCS15_LOG_WARN, "P15: bind test succ");
	} else
		pkcs15_log(PKCS15_LOG_WARN, "P15: bind test fail");
}

struct pkcs15_bind_trans *g_trans = NULL;

int pkcs15_bind_test(ui_session_t *sess, ui_entry_t *inst,
			void *ctx, int argc, char **argv)
{
	uint16_t reader_idx;

	reader_idx = atoi(argv[0]);
	g_trans = pkcs15_bind(reader_idx, NULL, __bind_test, NULL);

	if (!g_trans) {
		pkcs15_log(PKCS15_LOG_WARN, "P15: die at bring up");
		return -1;
	}
	return 0;
}


ui_argument_t pkcs15_reader_args = {
	"idex",
	"reader index",
	NULL,
	UI_TYPE_INT,
};

ui_command_t pkcs15_bind_cmd = {
	"bind",
	"bind stm test",
	".pkcs15",
	UI_CMD_SINGLE_INST,
	&pkcs15_reader_args,
	1,
	LIST_HEAD_INIT(pkcs15_bind_cmd.link),
	pkcs15_bind_test,
};

ui_schema_t pkcs15_schema[] = {
	{ UI_TYPE_CLASS, 
	  UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, 
	  NULL, 
	  NULL,
	  ".pkcs15", 
	  "pkcs15", 
	  PKCS15_SERVICE_DESC},
	
	{ UI_TYPE_NONE },
};

static int p15_pcsc_event(notify_t *nb,
			  unsigned long event, void *data)
{
	switch(event) {
	case PCSC_ICC_REMOVE:
		if (g_trans)
			pkcs15_close_trans(g_trans);
		break;
	default:
		break;
	}
	return 0;
}

static notify_t p15_pcsc_notify = {
	NULL,
	p15_pcsc_event,
	9,
};

modlinkage int __init pkcs15_init(void)
{
	pkcs15_log_init();
	ui_register_schema(pkcs15_schema);
	ui_register_command(&pkcs15_bind_cmd);
	
	pcsc_register_notify(&p15_pcsc_notify);
	return 0;
}

modlinkage void __exit pkcs15_exit(void)
{
	pcsc_unregister_notify(&p15_pcsc_notify);

	ui_unregister_command(&pkcs15_bind_cmd);
	ui_unregister_schema(pkcs15_schema);
	pkcs15_log_exit();
}

subsys_initcall(pkcs15_init);
subsys_exitcall(pkcs15_exit);
