#ifndef __PKCS15_PRIV_H__
#define __PKCS15_PRIV_H__

#include <sysdep.h>
#include <logger.h>
#include <panic.h>
#include <module.h>
#include <strutl.h>
#include <dfastm.h>
#include <eloop.h>
#include <service.h>
#include <list.h>
#include <pkcs15.h>

#define P15_LOG_CRIT		LOG_EMERG
#define P15_LOG_FAIL		LOG_CRIT
#define P15_LOG_ERR		LOG_ERR
#define P15_LOG_WARN		LOG_WARNING
#define P15_LOG_INFO		LOG_INFO
#define P15_LOG_DEBUG		LOG_DEBUG

#define P15_BIND_LOG	P15_LOG_INFO

void p15_log(int level, const char *format, ...);

int parse_dir_record(struct p15_card *card_handle, 
		     uint8_t **rbuf, size_t *rbuf_len, int rec_nr);

int parse_ddo(struct p15_card *p15_handle, const uint8_t * buf, 
	      size_t buflen);
int parse_odf(const uint8_t * buf, size_t buflen, 
	      struct p15_card *p15_handle);
int pkcs15_parse_tokeninfo(struct pkcs15_tokeninfo *ti,
			   const uint8_t *buf, size_t blen);
static inline int icc_same_path(const uint8_t *s1, const uint8_t *s2, size_t len)
{
	return memcmp(s1, s2, len) ? 0 : 1;
}

int pkcs15_add_df(struct p15_card *p15_handle,
		  unsigned int type, const struct icc_path *path,
		  const struct icc_file *filp);
void pkcs15_remove_df(struct p15_card *p15_handle,
		      struct pkcs15_df *obj);

int __init pkcs15_bind_init(void);
void __exit pkcs15_bind_exit(void);

int __init pkcs15_card_init(void);
void __exit pkcs15_card_exit(void);

int p15_app_count(struct p15_card *hd);
int p15_app_is_exist(struct p15_card *hd, struct icc_app_info *app);
void p15_app_count_inc(struct p15_card *hd);
void p15_app_count_dec(struct p15_card *hd);
struct icc_app_info *p15_get_app(struct p15_card *hd);
struct icc_app_info **p15_app_poniter(struct p15_card *hd);

struct p15_card *pkcs15_card_new(void);
void pkcs15_card_free(struct p15_card *);
int p15_card_start(struct p15_card *hd);

#endif /* __PKCS15_PRIV_H__ */

