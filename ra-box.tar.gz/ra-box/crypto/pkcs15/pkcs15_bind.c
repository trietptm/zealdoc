#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

#define P15_MF_PATH	"3F00"		/* DF */
#define P15_DIR_PATH	"3F002F00"	/* EF */
#define P15_ROOT_PATH	"3F005018"	/* DF, APP_AID is "\xA0\x00\x00\x00\x63PKCS-15" */

#define P15_MF_ID	P15_MF_PATH
#define P15_DIR_ID	"2F00"
#define P15_ODF_ID	"5031"

DECLARE_LIST(p15_trans_list);

#define for_each_trans(e)		\
	list_for_each_entry(struct p15_bind_trans, e, &p15_trans_list, link)
#define for_each_trans_safe(e, n)		\
	list_for_each_entry_safe(struct p15_bind_trans, e, n, &p15_trans_list, link)

struct p15_bind_trans {
	stm_instance_t *fsmi;
	
	uint8_t rec_nr;
	size_t	rec_size;

	uint8_t *sbuf;
	size_t	sbuf_len;
	uint8_t *rbuf;
	size_t	rbuf_len;
	size_t	rbuf_actual;
	
	struct p15_card *p15_handle;
	pcsc_appcmd_complete callback;
	void *user_data;

	int ret;
	int select_fail;

	list_t link;
};

static void p15_bind_trans_free(void *eloop, void *user_ctx);
static struct p15_bind_trans *
pkcs15_bind(uint16_t idx, struct p15_card **p15_hd_out,
	    pcsc_appcmd_complete cb, void *data);
static void pkcs15_close_bind_trans(void *);

static void pkcs15_bind_stm_log(const stm_instance_t *fsmi,
				int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

#define PKCS15_BIND_STATE_INIT		0
#define PKCS15_BIND_STATE_SELECT_DIR	1
#define PKCS15_BIND_STATE_READ_DIR	2
#define PKCS15_BIND_STATE_PARSE_DIR	3
#define PKCS15_BIND_STATE_SELECT_ROOT	4
#define PKCS15_BIND_STATE_SELECT_ODF	5
#define PKCS15_BIND_STATE_READ_ODF	6
#define PKCS15_BIND_STATE_PARSE_ODF	7
#define PKCS15_BIND_STATE_SELECT_INFO	8
#define PKCS15_BIND_STATE_READ_INFO	9
#define PKCS15_BIND_STATE_PARSE_INFO	10
#define PKCS15_BIND_STATE_EXIT		11

#define PKCS15_BIND_STATE_COUNT		12

#define PKCS15_BIND_STATE_NAMES {	\
	"INIT",				\
	"SELECT_DIR",			\
	"READ_DIR",			\
	"PARSE_DIR",			\
	"SELECT_ROOT",			\
	"SELECT_ODF",			\
	"READ_ODF",			\
	"PARSE_ODF",			\
	"SELECT_INFO",			\
	"READ_INFO",			\
	"PARSE_INFO",			\
	"EXIT",				\
}

#define PKCS15_BIND_EVENT_AG		0	/* again */
#define PKCS15_BIND_EVENT_GO		1	/* go on next step */
#define PKCS15_BIND_EVENT_ERR		2	/* common error */
#define PKCS15_BIND_EVENT_COUNT		3

#define PKCS15_BIND_EVENT_NAMES {	\
	"AG",				\
	"GO",				\
	"ERR",				\
}

static void pkcs15_bind_raise_event(struct p15_bind_trans *p15_bind_trans,
				    int event)
{
	eloop_schedule_event(NULL, p15_bind_trans->fsmi, event, p15_bind_trans);
}

static void pkcs15_bind_raise_err(struct p15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_ERR);
}

static void pkcs15_bind_raise_ag(struct p15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_AG);
}

static void pkcs15_bind_raise_go(struct p15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_GO);
}

static int pkcs15_bind_action_null(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static int pkcs15_bind_action_itc(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)data;
	struct p15_card *p15_handle = p15_bind_trans->p15_handle;

	p15_handle->app_root = icc_file_new();
	if (p15_handle->app_root == NULL) {
		p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
		pkcs15_bind_raise_err(p15_bind_trans);
	}

	return 1;
}

static int pkcs15_bind_action_etc(stm_instance_t *fsmi, void *data)
{
	eloop_register_timeout(NULL, 0, 0, p15_bind_trans_free, NULL, data);

	return 1;
}

static void select_dir_complete(void *user_data, int ret)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)user_data;

	if (ret == ICC_SUCCESS) {
		pkcs15_bind_raise_go(p15_bind_trans);
		p15_bind_trans->rec_nr = 1;
	} else if (ret ==  ICC_ERR_FILE_NOT_FOUND){
		pkcs15_bind_raise_ag(p15_bind_trans);
	} else {
		pkcs15_bind_raise_err(p15_bind_trans);
	}
}

static int pkcs15_bind_action_select_dir(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)data;
	struct icc_path dir_path;
	struct icc_file **file;
	int r;
	pcsc_slot_t *card_hd = p15_bind_trans->p15_handle->slot;

	memset(&dir_path, 0, sizeof (struct icc_path));

	p15_log(P15_BIND_LOG, "select_dir");
	file = &p15_bind_trans->p15_handle->ef_dir;
	if (*file) {
		p15_log(P15_LOG_WARN, "file have been selected before");
	}

	icc_format_path(P15_DIR_PATH, &dir_path);
	dir_path.type = ICC_PATH_TYPE_PATH;

	r = pcsc_select_file(card_hd, &dir_path, file, select_dir_complete, p15_bind_trans);
	if (r != ICC_SUCCESS) {
		p15_bind_trans->ret = r;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
	return 1;
}

static void read_dir_complete(void *user_data, int ret)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)user_data;
	
	p15_log(P15_LOG_DEBUG, "P15: read dir comp=%d", ret);

	if (ret == ICC_ERR_RECORD_NOT_FOUND) {
		pkcs15_bind_raise_go(p15_bind_trans);
	} else if (ret >= 0) {
		p15_bind_trans->rbuf_actual = ret;
		pkcs15_bind_raise_go(p15_bind_trans);
	} else {
		p15_bind_trans->ret = ret;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
}

static int pkcs15_bind_action_read_dir(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)data;
	pcsc_slot_t *card_handle = 
			p15_bind_trans->p15_handle->slot;
	struct icc_file *ef_dir = p15_bind_trans->p15_handle->ef_dir;
	uint8_t *rbuf;
	size_t rbuf_len;
	int r;

	p15_log(P15_BIND_LOG, "read_dir");
	if (!ef_dir)
		goto srdf;

	if (ef_dir->ef_structure == ICC_FILE_EF_TRANSPARENT) {
		rbuf_len = ef_dir->size;
		rbuf = malloc(rbuf_len);
		if (rbuf == NULL) {
			p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
			goto srdf;
		}
		memset(rbuf, 0, rbuf_len);
		p15_bind_trans->rbuf = rbuf;
		p15_bind_trans->rbuf_len = rbuf_len;
		r = pcsc_read_binary(card_handle, 0, rbuf, rbuf_len, 0,
			read_dir_complete, p15_bind_trans);
		if (r != ICC_SUCCESS) {
			p15_bind_trans->ret = r;
			free(rbuf);
			goto srdf;
		}
	} else {
		rbuf_len = ef_dir->record_length;
		rbuf = malloc(rbuf_len);
		if (rbuf == NULL) {
			p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
			goto srdf;
		}
		memset(rbuf, 0, rbuf_len);
		p15_bind_trans->rbuf = rbuf;
		p15_bind_trans->rbuf_len = rbuf_len;
		
		BUG();
		/* TODO */
		r = -1;
#ifdef TODO
		r = scard_read_record(card_handle, p15_bind_trans->rec_nr++,
				      rbuf, rbuf_len, ICC_RECORD_BY_REC_NR, 
				      read_dir_complete, p15_bind_trans);
#endif
		if (r != ICC_SUCCESS) {
			p15_bind_trans->ret = r;
			free(rbuf);
			goto srdf;
		}
	}
	return 1;
srdf:
	pkcs15_bind_raise_err(p15_bind_trans);
	return 1;
}

static int pkcs15_bind_action_parse_dir(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)data;
	struct p15_card *card_handle = p15_bind_trans->p15_handle;
	struct icc_file *ef_dir = p15_bind_trans->p15_handle->ef_dir;
	uint8_t *p, *rbuf = p15_bind_trans->rbuf;
	size_t rbuf_actual = p15_bind_trans->rbuf_actual;
	int r;

	p15_log(P15_BIND_LOG, "parse_dir");
	p = rbuf;
	if (ef_dir->ef_structure == ICC_FILE_EF_TRANSPARENT) {
		while (rbuf_actual > 0) {
			if (p15_app_count(card_handle) == ICC_APP_MAX) 
				goto pds;

			r = parse_dir_record(card_handle, &p, &rbuf_actual, -1);
			if (r != ICC_SUCCESS)
				break;
		}
		p15_log(P15_LOG_INFO, "P15: app count=%d", p15_app_count(card_handle));
		goto pds;
	} else {
		if (p15_bind_trans->ret == ICC_ERR_RECORD_NOT_FOUND) {
			p15_bind_trans->ret = ICC_SUCCESS;
			goto pds;
		}
		if (p15_app_count(card_handle) == ICC_APP_MAX)
			goto pds;
		parse_dir_record(card_handle, &p, &rbuf_actual, 
				(int)rbuf_actual);
		goto rnr;/* read next app record */
	}

rnr:
	free(rbuf);
	pkcs15_bind_raise_ag(p15_bind_trans);
	return 1;
pds:
	if (rbuf) free(rbuf);
	pkcs15_bind_raise_go(p15_bind_trans);
	return 1;
}

/* set app root path (all app and default path) */
/* TODO: how to select app root if ICC has several ones?
 * now the ICC only has one available app so this fun() can work.
 * If its need user tell us app root or number, does the PKCS#15 necessary?
 */
static int pkcs15_bind_action_sar(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *trans = 
			(struct p15_bind_trans *)data;
	struct p15_card *p15_handle = trans->p15_handle;
	uint8_t *value;
	size_t len;

	p15_log(P15_BIND_LOG, "sar, now path=%02x %02x %02x %02x",
			p15_handle->app_root->path.value[0],
			p15_handle->app_root->path.value[1],
			p15_handle->app_root->path.value[2],
			p15_handle->app_root->path.value[3]);

	if (p15_app_count(p15_handle) > 0) {
		struct icc_app_info *info;
		/* traverse all pkcs15 app */
		info = p15_get_app(p15_handle);

		if (info) {
			if (info->path.len)
				p15_handle->app_root->path = info->path;
			if (info->ddo)
				parse_ddo(p15_handle, info->ddo, info->ddo_len);
			goto out;
		}
	}
	value = p15_handle->app_root->path.value;
	len = p15_handle->app_root->path.len;

	/* Reach here means we cannot get EF(dir) or no available app,
	 * so use default root path or at last use MF and set select fail */
	if (!icc_same_path(P15_MF_PATH, value, len) &&
	    !icc_same_path(P15_ROOT_PATH, value, len)) {
		icc_format_path(P15_ROOT_PATH, &p15_handle->app_root->path);
		goto out;
	} else if (icc_same_path(P15_ROOT_PATH, value, len)) {
		icc_format_path(P15_MF_PATH, &p15_handle->app_root->path);
		goto out;
	} else if (icc_same_path(P15_MF_PATH, value, len)) {
		trans->select_fail = 1;
		goto out;
	}
	BUG();
out:
	return 1;
}

static void select_root_complete(void *user_data, int ret)
{
	struct p15_bind_trans *trans = 
			(struct p15_bind_trans *)user_data;

	p15_log(P15_BIND_LOG, "select_root, ret=%d", ret);

	if (ret == ICC_SUCCESS) {
		pkcs15_bind_raise_go(trans);
	} else if (ret == ICC_ERR_FILE_NOT_FOUND) {
		if (trans->select_fail == 1)
			pkcs15_bind_raise_err(trans);
		else
			pkcs15_bind_raise_ag(trans);
	} else {
		pkcs15_bind_raise_err(trans);
	}
}
struct icc_file *groot;

static int pkcs15_bind_action_select_root(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)data;
	struct icc_file *app_root = p15_bind_trans->p15_handle->app_root;
	pcsc_slot_t *card_handle = p15_bind_trans->p15_handle->slot;
	int r;

	p15_log(P15_BIND_LOG, "select_root=%02x %02x %02x %02x",
			app_root->path.value[0], app_root->path.value[1],
			app_root->path.value[2], app_root->path.value[3]);

	r = pcsc_select_file(card_handle, &app_root->path, &groot,//NULL, 
				select_root_complete, p15_bind_trans);
	if (r != ICC_SUCCESS) {
		p15_bind_trans->ret = r;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
	return 1;
}

static void select_odf_complete(void *user_data, int ret)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)user_data;

	p15_log(P15_LOG_INFO, "P15: select_odf ret=%d", ret);

	if (ret == ICC_SUCCESS) {
		pkcs15_bind_raise_go(p15_bind_trans);
	} else {
		pkcs15_bind_raise_err(p15_bind_trans);
	}
}

static int pkcs15_bind_action_select_odf(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)data;
	struct p15_card *p15_handle = p15_bind_trans->p15_handle;
	pcsc_slot_t *card_handle = p15_handle->slot;
	struct icc_path tmppath;
	int r;

	memset(&tmppath, 0, sizeof (struct icc_path));

	if (p15_handle->odf) {
		tmppath = p15_handle->odf->path;
		icc_file_free(p15_handle->odf);
		p15_handle->odf = NULL;
	} else {
		tmppath = p15_handle->app_root->path;
		/* 3F005031 or 3F0050185031 */
		icc_append_path_id(&tmppath, (const uint8_t *) "\x50\x31", 2);
	}

	p15_log(P15_BIND_LOG, "select_odf=%02x %02x %02x %02x",
			tmppath.value[0], tmppath.value[1],
			tmppath.value[2], tmppath.value[3]);
	
	r = pcsc_select_file(card_handle, &tmppath, &p15_handle->odf, 
				select_odf_complete, p15_bind_trans);
	if (r != ICC_SUCCESS) {
		p15_bind_trans->ret = r;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
	
	return 1;
}

static void read_odf_complete(void *user_data, int ret)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)user_data;
	
	p15_log(P15_LOG_INFO, "P15: read_odf, ret=%d", ret);

	if (ret >= 0) {
		p15_bind_trans->rbuf_actual = ret;
		pkcs15_bind_raise_go(p15_bind_trans);
	} else {
		p15_bind_trans->ret = PKCS15_ERR_OTHER;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
}

static int pkcs15_bind_action_read_odf(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)data;
	struct p15_card *p15_handle = p15_bind_trans->p15_handle;
	pcsc_slot_t *card_handle = p15_handle->slot;
	struct icc_file *app_odf = p15_handle->odf;
	uint8_t *rbuf;
	size_t rbuf_len;
	int r;

	p15_log(P15_BIND_LOG, "read_odf, size=%d", app_odf->size);
	if (app_odf->size <= 0)
		goto srof;

	rbuf_len = app_odf->size;
	rbuf = malloc(rbuf_len);
	if (rbuf == NULL) {
		p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
		goto srof;
	}
	memset(rbuf, 0, rbuf_len);
	p15_bind_trans->rbuf = rbuf;
	p15_bind_trans->rbuf_len = rbuf_len;
	r = pcsc_read_binary(card_handle, 0, rbuf, rbuf_len, 0,
		read_odf_complete, p15_bind_trans);
	if (r != ICC_SUCCESS) {
		p15_bind_trans->ret = r;
		free(rbuf);
		goto srof;
	}
	return 1;
srof:
	pkcs15_bind_raise_err(p15_bind_trans);
	return 1;
}

static int pkcs15_bind_action_parse_odf(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)data;
	struct p15_card *p15_handle = p15_bind_trans->p15_handle;
	int r;

	p15_log(P15_BIND_LOG, "parse_odf");
	r = parse_odf(p15_bind_trans->rbuf, p15_bind_trans->rbuf_actual, p15_handle);
	if (r == PKCS15_SUCCESS)
		pkcs15_bind_raise_go(p15_bind_trans);
	else 
		pkcs15_bind_raise_err(p15_bind_trans);

	return 1;
}

static void select_tokeninfo_complete(void *user_data, int ret)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)user_data;

	p15_log(P15_LOG_INFO, "select tokeninfo comp=%d", ret);
	if (ret == ICC_SUCCESS) {
		pkcs15_bind_raise_go(p15_bind_trans);
	} else {
		pkcs15_bind_raise_err(p15_bind_trans);	
	}
}

static int pkcs15_bind_action_select_info(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)data;
	struct p15_card *p15_handle = p15_bind_trans->p15_handle;
	pcsc_slot_t *card_handle = p15_handle->slot;
	struct icc_path tmppath;
	int r;

	memset(&tmppath, 0, sizeof (struct icc_path));
	p15_log(P15_BIND_LOG, "select_info");
	if (p15_handle->tif) {
		tmppath = p15_handle->tif->path;
		icc_file_free(p15_handle->tif);
		p15_handle->tif = NULL;
	} else {
		tmppath = p15_handle->app_root->path;
		icc_append_path_id(&tmppath, (const uint8_t *) "\x50\x32", 2);
	}
	/* tokeninfo and the odf are in the same DF, sure? */
	/* but do not set that type now */
	//tmppath.type = ICC_PATH_TYPE_FROM_CURRENT;

	r = pcsc_select_file(card_handle, &tmppath, &p15_handle->tif, 
				select_tokeninfo_complete, p15_bind_trans);
	if (r != ICC_SUCCESS) {
		p15_bind_trans->ret = r;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
	return 1;
}

static void read_tokeninfo_complete(void *user_data, int ret)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)user_data;
	if (ret >= 0) {
		p15_bind_trans->rbuf_actual = ret;
		pkcs15_bind_raise_go(p15_bind_trans);
	} else {
		free(p15_bind_trans->rbuf);
		p15_bind_trans->ret = PKCS15_ERR_OTHER;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
}

static int pkcs15_bind_action_read_info(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)data;
	struct p15_card *p15_handle = p15_bind_trans->p15_handle;
	pcsc_slot_t *card_handle = p15_handle->slot;
	struct icc_file *app_tokeninfo = p15_handle->tif;
	uint8_t *rbuf;
	size_t rbuf_len;
	int r;

	p15_log(P15_BIND_LOG, "read_info");
	rbuf_len = app_tokeninfo->size;
	rbuf = malloc(rbuf_len);
	if (rbuf == NULL) {
		p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
		goto srif;
	}
	memset(rbuf, 0, rbuf_len);
	p15_bind_trans->rbuf = rbuf;
	p15_bind_trans->rbuf_len = rbuf_len;
	r = pcsc_read_binary(card_handle, 0, rbuf, rbuf_len, 0,
		read_tokeninfo_complete, p15_bind_trans);
	if (r != ICC_SUCCESS) {
		p15_bind_trans->ret = r;
		free(rbuf);
		goto srif;
	}

	return 1;
srif:
	pkcs15_bind_raise_err(p15_bind_trans);
	return 1;
}

static int pkcs15_bind_action_parse_info(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *p15_bind_trans = 
			(struct p15_bind_trans *)data;
	struct pkcs15_tokeninfo *tokeninfo = 
			&p15_bind_trans->p15_handle->tokeninfo;
	int r;
	
	p15_log(P15_BIND_LOG, "parse_info");
	memset(tokeninfo, 0, sizeof(struct pkcs15_tokeninfo));
	r = pkcs15_parse_tokeninfo(tokeninfo, p15_bind_trans->rbuf,
				   p15_bind_trans->rbuf_actual);
	if (r != PKCS15_SUCCESS)
		pkcs15_bind_raise_err(p15_bind_trans);
	else 
		pkcs15_bind_raise_go(p15_bind_trans);		

	free(p15_bind_trans->rbuf);
	return 1;
}

static int pkcs15_bind_action_init_handle(stm_instance_t *fsmi, void *data)
{
	struct p15_bind_trans *p15_trans = (struct p15_bind_trans *)data;

	if (p15_trans && p15_trans->p15_handle)
		p15_trans->p15_handle->binded = 1;
	return 1;
}

static const stm_action_fn pkcs15_bind_act_null [] = {
	pkcs15_bind_action_null,
};

static const stm_action_fn pkcs15_bind_act_itc_select_dir[] = {
	pkcs15_bind_action_itc,
	pkcs15_bind_action_select_dir,
};

static const stm_action_fn pkcs15_bind_act_etc[] = {
	pkcs15_bind_action_etc,
};

static const stm_action_fn pkcs15_bind_act_read_dir[] = {
	pkcs15_bind_action_read_dir,
};

static const stm_action_fn pkcs15_bind_act_parse_dir[] = {
	pkcs15_bind_action_parse_dir,
};

static const stm_action_fn pkcs15_bind_act_sar_select_root[] = {
	pkcs15_bind_action_sar,
	pkcs15_bind_action_select_root,
};

static const stm_action_fn pkcs15_bind_act_select_odf[] = {
	pkcs15_bind_action_select_odf,
};

static const stm_action_fn pkcs15_bind_act_read_odf[] = {
	pkcs15_bind_action_read_odf,
};

static const stm_action_fn pkcs15_bind_act_parse_odf[] = {
	pkcs15_bind_action_parse_odf,
};

static const stm_action_fn pkcs15_bind_act_select_info[] = {
	pkcs15_bind_action_select_info,
};

static const stm_action_fn pkcs15_bind_act_read_info[] = {
	pkcs15_bind_action_read_info,
};

static const stm_action_fn pkcs15_bind_act_parse_info[] = {
	pkcs15_bind_action_parse_info,
};

static const stm_action_fn pkcs15_bind_act_init_handle_etc[] = {
	pkcs15_bind_action_init_handle,
	pkcs15_bind_action_etc,
};

#define STATE(state)	PKCS15_BIND_STATE_##state
#define EVENT(event)	PKCS15_BIND_EVENT_##event
#define ACTION(stem)	pkcs15_bind_act_##stem, \
		sizeof(pkcs15_bind_act_##stem) / sizeof(stm_action_fn) 

static const stm_entry_t pkcs15_bind_stm_entries[] = {
	/* state		event		action				new_state */
	{STATE(INIT),		EVENT(GO),	ACTION(itc_select_dir),		STATE(SELECT_DIR),},

	{STATE(SELECT_DIR),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(SELECT_DIR),	EVENT(GO),	ACTION(read_dir),		STATE(READ_DIR),},
	{STATE(SELECT_DIR),	EVENT(AG),	ACTION(sar_select_root),	STATE(SELECT_ROOT),},
	{STATE(SELECT_DIR),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(READ_DIR),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(READ_DIR),	EVENT(GO),	ACTION(parse_dir),		STATE(PARSE_DIR),},
	{STATE(READ_DIR),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(PARSE_DIR),	EVENT(AG),	ACTION(read_dir),		STATE(READ_DIR),},
	{STATE(PARSE_DIR),	EVENT(GO),	ACTION(sar_select_root),	STATE(SELECT_ROOT),},
	{STATE(PARSE_DIR),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	
	{STATE(SELECT_ROOT),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(SELECT_ROOT),	EVENT(GO),	ACTION(select_odf),		STATE(SELECT_ODF),},
	{STATE(SELECT_ROOT),	EVENT(AG),	ACTION(sar_select_root),	STATE(SELECT_ROOT),},
	{STATE(SELECT_ROOT),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(SELECT_ODF),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(SELECT_ODF),	EVENT(GO),	ACTION(read_odf),		STATE(READ_ODF),},
	{STATE(SELECT_ODF),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(READ_ODF),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(READ_ODF),	EVENT(GO),	ACTION(parse_odf),		STATE(PARSE_ODF),},
	{STATE(READ_ODF),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(PARSE_ODF),	EVENT(GO),	ACTION(select_info),		STATE(SELECT_INFO),},
	{STATE(PARSE_ODF),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(SELECT_INFO),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(SELECT_INFO),	EVENT(GO),	ACTION(read_info),		STATE(READ_INFO),},
	{STATE(SELECT_INFO),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(READ_INFO),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(READ_INFO),	EVENT(GO),	ACTION(parse_info),		STATE(PARSE_INFO),},
	{STATE(READ_INFO),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(PARSE_INFO),	EVENT(GO),	ACTION(init_handle_etc),	STATE(EXIT),},
	{STATE(PARSE_INFO),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(EXIT),		EVENT(ERR),	ACTION(null),			STATE(EXIT),},
	{0,			0,		NULL,					0,},
};

static const char *pkcs15_bind_state_names[] = PKCS15_BIND_STATE_NAMES;
static const char *pkcs15_bind_event_names[] = PKCS15_BIND_EVENT_NAMES;

const stm_table_t pkcs15_bind_stm_table = {
	"p15",
	pkcs15_bind_stm_log,
	PKCS15_BIND_STATE_COUNT,
	&pkcs15_bind_state_names[0],
	PKCS15_BIND_EVENT_COUNT,
	&pkcs15_bind_event_names[0],
	pkcs15_bind_stm_entries,	
};

#undef STATE
#undef EVENT
#undef ACTION

static struct p15_bind_trans *pkcs15_bind(uint16_t idx, struct p15_card **p15_handle_out,
		pcsc_appcmd_complete cb, void *user_data)
{
	struct p15_card *p15_handle = pkcs15_card_new();
	struct p15_bind_trans *p15_trans = NULL;

	if (!p15_handle)
		goto err;

	p15_handle->slot = pcsc_slot_lock_get_by_idx(idx);
	if (!p15_handle->slot)
		goto err;
	p15_handle->idx = idx;

	p15_trans = malloc(sizeof(struct p15_bind_trans));
	if (!p15_trans)
		goto err;
	memset(p15_trans, 0, sizeof (struct p15_bind_trans));

	p15_trans->callback = cb;
	p15_trans->user_data = user_data ? user_data : p15_trans;
	p15_trans->p15_handle = p15_handle;
	list_init(&p15_trans->link);

	p15_trans->fsmi = eloop_create_automaton(&pkcs15_bind_stm_table,
						 "P15_BIND",
						 PKCS15_BIND_STATE_INIT);
	if (!p15_trans->fsmi)
		goto err;
	list_insert_before(&p15_trans->link, &p15_trans_list);
	pkcs15_bind_raise_go(p15_trans);
	
	return p15_trans;
err:
	if (p15_handle && p15_handle->slot)
		pcsc_slot_lock_put(p15_handle->slot);
	if (p15_handle)
		pkcs15_card_free(p15_handle);
	if (p15_trans)
		free(p15_trans);
	return NULL;
}

static void p15_bind_trans_free(void *e, void *user)
{
	struct p15_bind_trans *trans = (struct p15_bind_trans *)user;

	if (trans && trans->callback) {
		trans->callback(trans->user_data, trans->ret);
		trans->callback = NULL;
	}
	if (trans->fsmi) {
		eloop_delete_automaton(trans->fsmi);
		trans->fsmi = NULL;
	}

	/* if not bind success, free handle
	 * or let handle manage the p15_app */
	if (trans->p15_handle) {
		if (trans->p15_handle->binded == 0) {
			if (trans->p15_handle->slot)
				pcsc_slot_lock_put(trans->p15_handle->slot);
			pkcs15_card_free(trans->p15_handle);
		} else {
			/* TODO: do the p15 things */

			/* XXX: now dont free trans as it as a contrainer of p15_handle 
			 * when ICC_REMOVE the trans can be found and will notify the handle to free.
			 * at that time lets free both of them.
			 */
			p15_card_start(trans->p15_handle);
			return;
		}
	}
	
	list_delete(&trans->link);
	free(trans);
}

static const unsigned int odf_indexes[] = {
	PKCS15_PRKDF,
	PKCS15_PUKDF,
	PKCS15_PUKDF_TRUSTED,
	PKCS15_SKDF,
	PKCS15_CDF,
	PKCS15_CDF_TRUSTED,
	PKCS15_CDF_USEFUL,
	PKCS15_DODF,
	PKCS15_AODF,
};

static int p15_pcsc_event(notify_t *nb,
			  unsigned long event, void *data)
{
	switch(event) {
	case PCSC_ICC_REMOVE:
		pkcs15_close_bind_trans(data);
		break;
	default:
		break;
	}
	return 0;
}

static notify_t p15_pcsc_notify = {
	NULL,
	p15_pcsc_event,
	9,
};

static void pkcs15_close_bind_trans(void *data)
{
	struct p15_bind_trans *trans, *node;
	
	for_each_trans_safe(trans, node) {
		if (trans->p15_handle->slot == data) {
			/* since maybe closed but not free before */
			if (trans->fsmi)
				pkcs15_bind_raise_err(trans);
			else {
				/* FIXME: force set? */
				/* p15_handle_stop(trans->p15_handle); */								
				trans->p15_handle->binded = 0;
				p15_bind_trans_free(NULL, trans);
		
			}
		}
	}
}

static void pkcs15_bind_finish(void *data, int ret)
{
	struct p15_bind_trans *t = (struct p15_bind_trans *)data;

	if (ret == 0 && t->p15_handle->binded == 1)
		p15_log(P15_LOG_INFO, "BIND: success bind pkcs15");
	else
		p15_log(P15_LOG_INFO, "BIND: faliure bind pkcs15");
}

static int pkcs15_binder_bind(uint16_t idx)
{
	struct p15_bind_trans *trans;

	if (idx == 0xFFFF)
		return -1;

	trans = pkcs15_bind(idx, NULL, pkcs15_bind_finish, NULL);

	if (!trans) {
		p15_log(P15_LOG_WARN, "P15: die at bring up");
		return -1;
	}

	return 0;
}

static int pkcs15_binder_unbind(void)
{
	return -1;
}

static pcsc_binder_t p15_binder = {
	"PKCS15",
	pkcs15_binder_bind,
	pkcs15_binder_unbind,
};

int __init pkcs15_bind_init(void)
{
	pcsc_register_notify(&p15_pcsc_notify);

	return pcsc_register_binder(&p15_binder);
}

void __exit pkcs15_bind_exit(void)
{
	pcsc_unregister_binder(&p15_binder);
	pcsc_unregister_notify(&p15_pcsc_notify);
}

/* BIND 
 * select dir -> read dir -> parse dir
 *   select root
 *      select odf -> read odf -> parse odf
 *	  select info -> read info -> parse info
 *
 */
