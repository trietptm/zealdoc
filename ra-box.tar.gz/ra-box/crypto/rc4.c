#include <rc4.h>

#define buf_size 1024

#define swap_byte(x, y)		\
	do {			\
		*(x) ^= *(y);	\
		*(y) ^= *(x);	\
		*(x) ^= *(y);	\
	} while (0)

void rc4_key(rc4_t *ctx, uint8_t *key, size_t length)
{
	uint8_t index1, index2;
	uint8_t* state;
	uint16_t counter;
	
	state = &ctx->state[0];
	for (counter = 0; counter < 256; counter++)
		state[counter] = (uint8_t)counter;

	ctx->x = ctx->y = 0;
	index1 = index2 = 0;

	for (counter = 0; counter < 256; counter++) {
		index2 = (key[index1] + state[counter] + index2) % 256;
		swap_byte(&state[counter], &state[index2]);
		index1 = (index1 + 1) % length;
	}
}

void rc4(rc4_t *key, uint8_t *buffer, size_t length)
{
	uint8_t x;
	uint8_t y;
	uint8_t* state;
	uint8_t xorIndex;
	size_t counter;
	
	x = key->x;
	y = key->y;
	state = &key->state[0];
	for (counter = 0; counter < length; counter++) {
		x = (x + 1) % 256;
		y = (state[x] + y) % 256;
		swap_byte(&state[x], &state[y]);
		xorIndex = (state[x] + state[y]) % 256;
		buffer[counter] ^= state[xorIndex];
	}
	key->x = x;
	key->y = y;
}
