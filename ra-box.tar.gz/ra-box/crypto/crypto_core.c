#include "crypto_priv.h"

#define CRYPTO_SERVICE_DESC	"Cryptographic service"

int crypto_logger = 0;

void crypto_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(crypto_logger, level, format, ap);
	va_end(ap);
}

log_source_t crypto_log_source = {
	"crypto",
};

static int __init crypto_log_init(void)
{
	crypto_logger = log_register_source(&crypto_log_source);
	return !crypto_logger;
}

static void __exit crypto_log_exit(void)
{
	log_unregister_source(crypto_logger);
}

service_t crypto_service = {
	CRYPTO_SERVICE_NAME,
	CRYPTO_SERVICE_DESC,
	SERVICE_UP_ALWAYS,
	SERVICE_FLAG_SYSTEM,
	LIST_HEAD_INIT(crypto_service.depends),
	crypto_start,
	crypto_stop,
};

handle_t crypto_handle = NULL;

static int __init crypto_serv_init(void)
{
	service_register_depend(CRYPTO_SERVICE_NAME, NET_SERVICE_NAME);
	service_register_depend(CRYPTO_SERVICE_NAME, UDEV_SERVICE_NAME);
	crypto_handle = register_service(&crypto_service);
	return crypto_handle ? 0 : 1;
}

static void __exit crypto_serv_exit(void)
{
	unregister_service(crypto_handle);
}

modlinkage int __init crypto_init(void)
{
	crypto_log_init();
	return crypto_serv_init();
}

modlinkage void __exit crypto_exit(void)
{
	crypto_serv_exit();
	crypto_log_exit();
}

subsys_initcall(crypto_init);
subsys_exitcall(crypto_exit);
