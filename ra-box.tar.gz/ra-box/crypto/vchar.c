#include <sysdep.h>
#include <vchar.h>

vchar_t *vmalloc(size_t size)
{
	vchar_t *var;

	if ((var = (vchar_t *)malloc(sizeof(*var))) == NULL)
		return NULL;

	var->l = size;
	if (size == 0) {
		var->v = NULL;
	} else {
		var->v = (caddr_t)calloc(1, size);
		if (var->v == NULL) {
			(void)free(var);
			return NULL;
		}
	}
	return var;
}

vchar_t *vrealloc(vchar_t *ptr, size_t size)
{
	caddr_t v;
	
	if (ptr != NULL) {
		if (ptr->l == 0) {
			(void)vfree(ptr);
			return vmalloc(size); /* zero-fill it? */
		}

		if ((v = (caddr_t)realloc(ptr->v, size)) == NULL) {
			(void)vfree(ptr);
			return NULL;
		}

		if (size > ptr->l)
			memset(v + ptr->l, 0, size - ptr->l);
		ptr->v = v;
		ptr->l = size;
	} else {
		if ((ptr = vmalloc(size)) == NULL)
			return NULL;
	}
	return ptr;
}

void vfree(vchar_t *var)
{
	if (var == NULL)
		return;
	if (var->v)
		(void)free(var->v);
	(void)free(var);
	return;
}

vchar_t *vdup(vchar_t *src)
{
	vchar_t *new;

	if (src == NULL) {
		return NULL;
	}
	if ((new = vmalloc(src->l)) == NULL)
		return NULL;
	memcpy(new->v, src->v, src->l);
	return new;
}

/*
 * exchange a value to a hex string.
 * must free buffer allocated later.
 */
caddr_t val2str(const char *buf, size_t mlen)
{
	caddr_t new;
	size_t len = (mlen * 2) + mlen / 8 + 10;
	size_t i, j;

	if ((new = malloc(len)) == 0) return(0);

	for (i = 0, j = 0; i < mlen; i++) {
		snprintf(&new[j], len - j, "%02x", (u_char)buf[i]);
		j += 2;
		if (i % 8 == 7) {
			new[j++] = ' ';
			new[j] = '\0';
		}
	}
	new[j] = '\0';
	return(new);
}

/*
 * exchange a string based "base" to a value.
 */
char *str2val(const char *str, int base, size_t *len)
{
	int f;
	size_t i;
	char *dst;
	char *rp;
	const char *p;
	char b[3];

	i = 0;
	for (p = str; *p != '\0'; p++) {
		if (isxdigit((int)*p))
			i++;
		else if (isspace((int)*p))
			;
		else
			return NULL;
	}
	if (i == 0 || (i % 2) != 0)
		return NULL;
	i /= 2;

	if ((dst = malloc(i)) == NULL)
		return NULL;

	i = 0;
	f = 0;
	for (rp = dst, p = str; *p != '\0'; p++) {
		if (isxdigit((int)*p)) {
			if (!f) {
				b[0] = *p;
				f = 1;
			} else {
				b[1] = *p;
				b[2] = '\0';
				*rp++ = (char)strtol(b, NULL, base);
				i++;
				f = 0;
			}
		}
	}

	*len = i;
	return(dst);
}
