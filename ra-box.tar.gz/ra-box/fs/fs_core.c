#include "fs_priv.h"

static ui_schema_t fs_schema[] = {
	/* .fs */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".fs", "fs", "Filesystem manager" },
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".fs.type", "type", "Filesystem types" },
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".fs.file", "file", "Filesystem file" },
	{ UI_TYPE_NONE },
};

#define for_each_fs_type(fs, head)		\
	list_for_each_entry(fs_type_t, fs, head, link)
#define for_each_fs_type_safe(fs, n, head)	\
	list_for_each_entry_safe(fs_type_t, fs, n, head, link)

static char *get_chunk_from_file(FILE * file, int *end)
{
	int ch;
	int idx = 0;
	char *linebuf = NULL;
	int linebufsz = 0;

	while ((ch = getc(file)) != EOF) {
		/* grow the line buffer as necessary */
		if (idx > linebufsz - 2) {
			linebufsz += 80;
			linebuf = (char *)realloc(linebuf, linebufsz);
		}
		linebuf[idx++] = (char) ch;
		if (!ch || (end && ch == '\n'))
			break;
	}
	if (end)
		*end = idx;
	if (linebuf) {
		if (ferror(file)) {
			free(linebuf);
			return NULL;
		}
		linebuf[idx] = 0;
	}
	return linebuf;
}

static char *get_chomped_line_from_file(FILE * file)
{
	int i;
	char *c = get_chunk_from_file(file, &i);

	if (i && c[--i] == '\n')
		c[i] = 0;

	return c;
}

void fs_type_dump(list_t *flist, int block_backed)
{
	char *fs, *buf;
	const char *filesystems[] = {"/proc/filesystems", 0};
	int i;
	fs_type_t *tmp;
	FILE *f;

	for (i = 0; filesystems[i]; i++) {
		if(!(f = fopen(filesystems[i], "r"))) continue;

		for (fs = buf = 0; 
		     (fs = buf = get_chomped_line_from_file(f)); free(buf)) {
			int nodev = 0;
			if (!strncmp(buf, "nodev", 5) && isspace(buf[5])) {
				nodev = 1;
				if (block_backed)
					continue;
				fs = buf+5;
			}

			while (isspace(*fs)) fs++;
			if (*fs=='#' || *fs=='*') continue;
			if (!*fs) continue;
			tmp = (fs_type_t *)malloc(sizeof(fs_type_t));
			tmp->type = strdup(fs);
			tmp->nodev = nodev;
			list_init(&tmp->link);
			list_insert_tail(&tmp->link, flist);
		}
		fclose(f);
	}
}

void fs_type_free(list_t *flist)
{
	fs_type_t *tmp, *n;

	for_each_fs_type_safe(tmp, n, flist) {
		list_delete_init(&tmp->link);
		if (tmp->type)
			free(tmp->type);
		free(tmp);
	}
}

static int fs_cmd_types(ui_session_t *sess, ui_entry_t *inst,
			void *ctx, int argc, char **argv)
{
	ui_table_t *table = ui_table_by_name(sess, "fs_types");
	DECLARE_LIST(flist);
	fs_type_t *fs;
	int i = 0;

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "fs_types");
	if (!table)
		return -1;

	fs_type_dump(&flist, 0);

	ui_add_title(table, 0, "type");
	ui_add_title(table, 1, "nodev");

	for_each_fs_type(fs, &flist) {
		ui_add_value(table, "type", i, fs->type);
		ui_add_value(table, "nodev", i, fs->nodev ? "nodev" : "");
		i++;
	}

	sess->result_table = table;
	return 0;
}

ui_command_t fs_types_command = {
	"dump",
	"Dump filesystem types",
	".fs.type",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(fs_types_command.link),
	fs_cmd_types,
};

static int fs_cmd_list(ui_session_t *sess, ui_entry_t *inst,
		       void *ctx, int argc, char **argv)
{
	FILE *fh = NULL;
	const char *file = argv[0];
	char *buffer = NULL;
	int size = 0;
	int length;
	struct stat sb;
	DIR *dirp;

	if (lstat(file, &sb) < 0) {
		log_kern(LOG_ERR, "FILE: no such file, file=%s", file);
		return 0;
	}

	if (S_ISDIR(sb.st_mode)) {
		dirp = opendir(file);
		if (!dirp) {
			log_kern(LOG_ERR, "FILE: cannot open directory, file=%s",
				 file);
			return 0;
		}
		for (; ; ) {
			struct _dirent *dp = readdir(dirp);
			if (!dp)
				break;

			/* skip . and .. */
			if (strcmp(dp->d_name, ".") == 0 ||
			    strcmp(dp->d_name, "..") == 0)
				continue;

			cli_printf(sess, "%s\r\n", dp->d_name);
		}
		closedir(dirp);
	} else {
		fh = fopen(file, "r");
		if (fh) {
			while (!feof(fh)) {
				length = getline(&buffer, &size, fh);
				chomp(buffer);
				if (length > 0) {
					cli_printf(sess, "%s\r\n", buffer);
				}
			}
			fclose(fh);
		} else {
			log_kern(LOG_ERR, "FILE: unable to dump file, file=%s", file);
		}
		if (buffer) free(buffer);
	}
	return 0;
}

ui_argument_t fs_file_arg[] = {
	{ "file", "File path", NULL, UI_TYPE_STRING, },
};

ui_command_t fs_list_command = {
	"dump",
	"Dump file content",
	".fs.file",
	UI_CMD_SINGLE_INST,
	fs_file_arg,
	1,
	LIST_HEAD_INIT(fs_list_command.link),
	fs_cmd_list,
};

modlinkage int __init fs_init(void)
{
	ui_register_schema(fs_schema);
	ui_register_command(&fs_types_command);
#ifdef CONFIG_DEBUG
	ui_register_command(&fs_list_command);
#endif
	fs_rootfs_init();
	return 0;
}

modlinkage void __exit fs_exit(void)
{
	fs_rootfs_exit();
#ifdef CONFIG_DEBUG
	ui_unregister_command(&fs_list_command);
#endif
	ui_unregister_command(&fs_types_command);
	ui_unregister_schema(fs_schema);
}

core_initcall(fs_init);
core_exitcall(fs_exit);
