#include "fs_priv.h"

#define ROOTFS_SERVICE_DESC		"Root filesystem mounts"

/* Make sure we have all the new mount flags we actually try to use. */
#ifndef MS_BIND
#define MS_BIND        (1<<12)
#endif
#ifndef MS_MOVE
#define MS_MOVE        (1<<13)
#endif
#ifndef MS_RECURSIVE
#define MS_RECURSIVE   (1<<14)
#endif
#ifndef MS_SILENT
#define MS_SILENT      (1<<15)
#endif

/* The shared subtree stuff, which went in around 2.6.15. */
#ifndef MS_UNBINDABLE
#define MS_UNBINDABLE  (1<<17)
#endif
#ifndef MS_PRIVATE
#define MS_PRIVATE     (1<<18)
#endif
#ifndef MS_SLAVE
#define MS_SLAVE       (1<<19)
#endif
#ifndef MS_SHARED
#define MS_SHARED      (1<<20)
#endif

static ui_schema_t fs_mount_schema[] = {
	/* .fs.mount */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".fs.mount", "mount", "Filesystem mounts" },
	{ UI_TYPE_NONE },
};

static const int32_t mount_options[] = {
	// MS_FLAGS set a bit.  ~MS_FLAGS disable that bit.  0 flags are NOPs.

	/* loop */
	/* "loop" */ 0,

	/* fstab */
	/* "defaults" */ 0,
	/* "quiet" 0 - do not filter out, vfat wants to see it */

	/* flags */
	/* vfs flags */
	/* "nosuid"      */ MS_NOSUID,
	/* "suid"        */ ~MS_NOSUID,
	/* "dev"         */ ~MS_NODEV,
	/* "nodev"       */ MS_NODEV,
	/* "exec"        */ ~MS_NOEXEC,
	/* "noexec"      */ MS_NOEXEC,
	/* "sync"        */ MS_SYNCHRONOUS,
	/* "async"       */ ~MS_SYNCHRONOUS,
	/* "atime"       */ ~MS_NOATIME,
	/* "noatime"     */ MS_NOATIME,
	/* "diratime"    */ ~MS_NODIRATIME,
	/* "nodiratime"  */ MS_NODIRATIME,
	/* "loud"        */ ~MS_SILENT,
	/* action flags */
	/* "bind"        */ MS_BIND,
	/* "move"        */ MS_MOVE,
	/* "shared"      */ MS_SHARED,
	/* "slave"       */ MS_SLAVE,
	/* "private"     */ MS_PRIVATE,
	/* "unbindable"  */ MS_UNBINDABLE,
	/* "rshared"     */ MS_SHARED|MS_RECURSIVE,
	/* "rslave"      */ MS_SLAVE|MS_RECURSIVE,
	/* "rprivate"    */ MS_SLAVE|MS_RECURSIVE,
	/* "runbindable" */ MS_UNBINDABLE|MS_RECURSIVE,

	/* Always understood. */
	/* "ro"      */ MS_RDONLY,  // vfs flag
	/* "rw"      */ ~MS_RDONLY, // vfs flag
	/* "remount" */ MS_REMOUNT  // action flag
};

static const char mount_option_str[] =
	/* loop */
	"loop" "\0"

	/* fstab */
	"defaults" "\0"
	/* "quiet" "\0" - do not filter out, vfat wants to see it */

	/* flags */
	/* vfs flags */
	"nosuid" "\0"
	"suid" "\0"
	"dev" "\0"
	"nodev" "\0"
	"exec" "\0"
	"noexec" "\0"
	"sync" "\0"
	"async" "\0"
	"atime" "\0"
	"noatime" "\0"
	"diratime" "\0"
	"nodiratime" "\0"
	"loud" "\0"
	/* action flags */
	"bind" "\0"
	"move" "\0"
	"shared" "\0"
	"slave" "\0"
	"private" "\0"
	"unbindable" "\0"
	"rshared" "\0"
	"rslave" "\0"
	"rprivate" "\0"
	"runbindable" "\0"

	/* Always understood. */
	"ro" "\0"        // vfs flag
	"rw" "\0"        // vfs flag
	"remount" "\0"   // action flag
;

// Perform actual mount of specific filesystem at specific location.
// NB: mp->xxx fields may be trashed on exit
static int mount_it_now(fs_mntent_t *mp, int vfsflags, char *filteropts)
{
	int rc = 0;

	/* Mount, with fallback to read-only if necessary. */
	for (;;) {
		rc = mount(mp->mnt_fsname, mp->mnt_dir, mp->mnt_type,
				vfsflags, filteropts);
		if (!rc || (vfsflags & MS_RDONLY) || (errno != EACCES && errno != EROFS))
			break;
		if (!(vfsflags & MS_SILENT)) {
			log_kern(LOG_ERR,
				 "MOUNT: write-protected, mounting read-only, dev=%s",
				 mp->mnt_fsname);
		}
		vfsflags |= MS_RDONLY;
	}

	/* Abort entirely if permission denied. */
	if (rc && errno == EPERM) {
		log_kern(LOG_ERR, "MOUNT: permission denied, dev=%s, dir=%s",
			 mp->mnt_fsname, mp->mnt_dir);
	}
	return rc;
}

/* Use the mount_options list to parse options into flags.
 * Also return list of unrecognized options if unrecognized!=NULL */
static int fs_mount_parse_opts(char *options, char **unrecognized)
{
	int flags = MS_SILENT;

	BUG_ON(!options || !unrecognized);
	for (;;) {
		int i;
		char *comma = strchr(options, ',');
		const char *option_str = mount_option_str;

		if (comma) *comma = '\0';

		/* find this option in mount_options */
		for (i = 0; i < ARRAY_SIZE(mount_options); i++) {
			if (!strcasecmp(option_str, options)) {
				long fl = mount_options[i];
				if (fl < 0) flags &= fl;
				else flags |= fl;
				break;
			}
			option_str += strlen(option_str) + 1;
		}
		/* if unrecognized not NULL, append unrecognized mount options */
		if (unrecognized && i == ARRAY_SIZE(mount_options)) {
			/* add it to strflags, to pass on to kernel */
			i = *unrecognized ? strlen(*unrecognized) : 0;
			*unrecognized = realloc(*unrecognized, i+strlen(options)+2);

			/* comma separated if it's not the first one */
			if (i) (*unrecognized)[i++] = ',';
			strcpy((*unrecognized)+i, options);
		}

		if (!comma)
			break;
		/* advance to next option */
		*comma = ',';
		options = ++comma;
	}

	return flags;
}

#define for_each_fs_type(fs, head)	\
	list_for_each_entry(fs_type_t, fs, &head, link)

static int fs_mount_one(fs_mntent_t *mp, int ignore_busy)
{
	int rc = -1, vfsflags;
	struct stat st;
	DECLARE_LIST(fl);
	fs_type_t *tmp;
	char *loopdev = NULL;
	char *mntopts = NULL, *extopts = NULL;

	if (mp->mnt_opts)
		mntopts = strdup(mp->mnt_opts);
	else
		mntopts = strdup("");
	if (!mntopts)
		return -1;

	vfsflags = fs_mount_parse_opts(mntopts, &extopts);

	/* treat "auto" as unspecified */
	if (mp->mnt_type && strcmp(mp->mnt_type, "auto") == 0)
		mp->mnt_type = 0;

	/* XXX: Look at the File
	 * not found isn't a failure for remount, or for a synthetic
	 * filesystem like proc or sysfs
	 * we use stat, not lstat, in order to allow mount
	 * symlink_to_file_or_blkdev dir
	 */
	if (!stat(mp->mnt_fsname, &st) &&
	    !(vfsflags & (MS_REMOUNT | MS_BIND | MS_MOVE))) {
		/* do we need to allocate a loopback device for it? */
		if (S_ISREG(st.st_mode)) {
			rc = fs_loop_set(&loopdev, mp->mnt_fsname, 0);
			if (rc < 0) {
				if (errno == EPERM || errno == EACCES) {
					log_kern(LOG_ERR, "MOUNT: permission denied, dev=%s, dir=%s",
						 mp->mnt_fsname, mp->mnt_dir);
				} else {
					log_kern(LOG_ERR,
						 "MOUNT: cannot setup loop device, dev=%s, dir=%s",
						 mp->mnt_fsname, mp->mnt_dir);
				}
				goto err;
			}
		} else if (S_ISDIR(st.st_mode) && !mp->mnt_type) {
			/* autodetect bind mounts */
			vfsflags |= MS_BIND;
		}
	}

	/* If we know the fstype (or don't need to), jump straight
	 * to the actual mount.
	 */
	if (mp->mnt_type || (vfsflags & (MS_REMOUNT | MS_BIND | MS_MOVE))) {
		rc = mount_it_now(mp, vfsflags, extopts);
	} else {
		/* Loop through filesystem types until mount succeeds
		 * or we run out
		 */
		/* Initialize list of block backed filesystems.  This has to
		 * be done here so that during "mount -a", mounts after /proc
		 * shows up can autodetect.
		 */
		if (list_empty(&fl))
			fs_type_dump(&fl, 1);
		
		for_each_fs_type(tmp, fl) {
			mp->mnt_type = tmp->type;
			rc = mount_it_now(mp, vfsflags, extopts);
			if (!rc) break;
			mp->mnt_type = 0;
		}

		fs_type_free(&fl);
	}

err:
	/* if mount failed, clean up loop file (if any) */
	if (rc && loopdev)
		fs_loop_unset(loopdev);
	if (loopdev)
		free(loopdev);
	if (extopts)
		free(extopts);
	if (mntopts)
		free(mntopts);
	if (errno == EBUSY && ignore_busy)
		return 0;
	if (rc < 0) {
		log_kern(LOG_ERR, "MOUNT: mounting failed, dev=%s, dir=%s",
			 mp->mnt_fsname, mp->mnt_dir);
	}
	return rc;
}

static int fs_mount_found(fs_mntent_t *mp)
{
	FILE *mount_table;
	fs_mntent_t *tmp;
	int found = 0;

	mount_table = fs_mntent_begin("/proc/mounts", "r");
	if (mount_table) {
		tmp = fs_mntent_get(mount_table);
		while (tmp) {
			if (streq(tmp->mnt_type, mp->mnt_type) &&
			    streq(tmp->mnt_dir, mp->mnt_dir)) {
				found = 1;
				break;
			}
			tmp = fs_mntent_get(mount_table);
		}
		fs_mntent_end(mount_table);
	}
	return found;
}

int fs_mount_single(const char *dev, const char *dir,
		    const char *fstype, const char *cmdopts)
{
	fs_mntent_t me;

	me.mnt_fsname = (char *)dev;
	me.mnt_dir = (char *)dir;
	me.mnt_type = (char *)fstype;
	me.mnt_opts = (char *)cmdopts;

	if (!fs_mount_found(&me))
		return fs_mount_one(&me, 0);
	return 0;
}

static int fs_mount_sysfs(void)
{
	fs_create_dir(_PATH_SYS);
	return fs_mount_single("none", _PATH_SYS, "sysfs", NULL);
}

static int fs_mount_procfs(void)
{
	fs_create_dir(_PATH_PROC);
	return fs_mount_single("none", _PATH_PROC, "proc", NULL);
}

static int fs_mount_tmpfs(void)
{
	char tmp_path[] = _PATH_DEVSHM "/tmp";
	fs_create_dir(tmp_path);
	return fs_mount_single(tmp_path, tmp_path, "tmpfs", "bind");
}

static int fs_mount_devfs(void)
{
	fs_create_dir(_PATH_DEV);
	return fs_mount_single("udev", "/dev", "tmpfs", "");
}

static int fs_mount_devshm(void)
{
	fs_create_dir(_PATH_DEVSHM);
	return fs_mount_single("tmpfs", _PATH_DEVSHM, "tmpfs",
			       "size=512K,nosuid,nodev,mode=1777");
}

static int fs_mount_devpts(void)
{
	fs_create_dir(_PATH_DEVPTS);
	return fs_mount_single("none", _PATH_DEVPTS, "devpts", NULL);
}

static int fs_cmd_mounts(ui_session_t *sess, ui_entry_t *inst,
			 void *ctx, int argc, char **argv)
{
	int i = 0;
	ui_table_t *table = ui_table_by_name(sess, "fs_mounts");
	FILE *mount_table;
	fs_mntent_t *mp;

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "fs_mounts");
	if (!table)
		return -1;

	ui_add_title(table, 0, "spec");
	ui_add_title(table, 1, "file");
	ui_add_title(table, 2, "type");
	ui_add_title(table, 3, "opts");

	mount_table = fs_mntent_begin("/proc/mounts", "r");

	if (mount_table) {
		mp = fs_mntent_get(mount_table);
		while (mp) {
			ui_add_value(table, "spec", i, mp->mnt_fsname);
			ui_add_value(table, "file", i, mp->mnt_dir);
			ui_add_value(table, "type", i, mp->mnt_type);
			ui_add_value(table, "opts", i, mp->mnt_opts);
			i++;
			mp = fs_mntent_get(mount_table);
		}
		fs_mntent_end(mount_table);
	}

	sess->result_table = table;
	return 0;
}

ui_command_t fs_mounts_command = {
	"dump",
	"Dump filesystem mounts",
	".fs.mount",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(fs_mounts_command.link),
	fs_cmd_mounts,
};

static int rootfs_start(void)
{
	/* mount kernel filesystems */
	fs_mount_procfs();
	fs_mount_sysfs();
	fs_mount_devfs();
	fs_mount_devshm();
	fs_mount_tmpfs();
	fs_mount_devpts();
	return 0;
}

static void rootfs_stop(void)
{
	fs_sysfs_stop();
}

service_t rootfs_service = {
	ROOTFS_SERVICE_NAME,
	ROOTFS_SERVICE_DESC,
	SERVICE_UP_ALWAYS,
	SERVICE_FLAG_SYSTEM,
	LIST_HEAD_INIT(rootfs_service.depends),
	rootfs_start,
	rootfs_stop,
};

handle_t rootfs_handle;

static int __init rootfs_serv_init(void)
{
	rootfs_handle = register_service(&rootfs_service);
	return rootfs_handle ? 0 : -1;
}

static void __exit rootfs_serv_exit(void)
{
	unregister_service(rootfs_handle);
}

int __init fs_rootfs_init(void)
{
	ui_register_schema(fs_mount_schema);
	ui_register_command(&fs_mounts_command);
	rootfs_serv_init();
	return 0;
}

void __exit fs_rootfs_exit(void)
{
	rootfs_serv_exit();
	ui_unregister_command(&fs_mounts_command);
	ui_unregister_schema(fs_mount_schema);
}
