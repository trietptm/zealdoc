#include "fs_priv.h"

#ifndef _O_BINARY
#define _O_BINARY	0
#endif

int fs_path_isdir(const char *file)
{
	struct stat sb;
	
	if (stat(file, &sb) < 0)
		return (0);
	return (S_ISDIR(sb.st_mode));
}

int fs_path_islink(const char *file)
{
#ifdef S_ISLNK
	struct stat sb;
	
	if (lstat(file, &sb) < 0)
		return 0;
	return (S_ISLNK(sb.st_mode));
#else
	return 0;
#endif
}

int fs_copy_dir(const char *src, const char *dst)
{
	DIR *dirp;
	struct stat sb;

	if (lstat(src, &sb) < 0)
		return 1;

	/* src is a file */
	if (!S_ISDIR(sb.st_mode)) {
		if (lstat(dst, &sb) == 0 && S_ISDIR(sb.st_mode)) {
			char path[PATH_MAX];
			const char *p = strrchr(src, '/');
			/* src => dst/src */
			sprintf(path, "%s/%s", dst, (p ? p + 1 : src));
			return fs_copy_dir(src, path);
		}

		/* src => dst */
		fs_copy_file(src, dst);
		return 0;
	}

	/* src is a directory */
	if (lstat(dst, &sb) < 0) {
		if (fs_make_dir(dst))
			return 1;
	} else if (!S_ISDIR(sb.st_mode)) {
		if (remove(dst) < 0 || fs_make_dir(dst) < 0)
			return 1;
	}
	dirp = opendir(src);
	if (!dirp)
		return 1;
	for (;;) {
		char path[PATH_MAX], path2[PATH_MAX];
		struct _dirent *dp = readdir(dirp);
		if (!dp)
			break;

		/* do not copy hidden files */
		if (dp->d_name[0] == '.')
			continue;

		sprintf(path, "%s/%s", src, dp->d_name);
		sprintf(path2, "%s/%s", dst, dp->d_name);
		if (fs_copy_dir(path, path2) != 0)
			return 1;
	}
	closedir(dirp);

	return 0;
}

int fs_create_path(const char *path)
{
	char p[PATH_MAX];
	char *pos;
	struct stat stats;
	
	strlcpy(p, path, sizeof(p));
	pos = strrchr(p, '/');
	if (pos == p || pos == NULL)
		return 0;
	
	while (pos[-1] == '/')
		pos--;
	pos[0] = '\0';
	
	if (stat(p, &stats) == 0 && (stats.st_mode & S_IFMT) == S_IFDIR)
		return 0;
	
	if (fs_create_path(p) != 0)
		return -1;
	if (mkdir(p, 0755) == 0)
		return 0;
	if (errno == EEXIST) {
		if (stat(p, &stats) == 0 && (stats.st_mode & S_IFMT) == S_IFDIR)
			return 0;
	}
	return -1;
}

int fs_delete_path(const char *path)
{
	char p[PATH_MAX];
	char *pos;
	int ret;
	
	strcpy(p, path);
	pos = strrchr(p, '/');
	if (pos == p || pos == NULL)
		return 0;
	
	while (1) {
		*pos = '\0';
		pos = strrchr(p, '/');
		
		/*don't remove the last one*/
		if ((pos == p) || (pos == NULL))
			break;
		
		/*remove if empty*/
		ret = rmdir(p);
		if (errno == ENOENT)
			ret = 0;
		if (ret) {
			if (errno == ENOTEMPTY)
				return 0;
			break;
		}
	}
	return 0;
}

/*Reset permissions on the device mode, before unlinking it to make sure,
 * that permission of possible hard links will be removed too.*/
int fs_unlink_secure(const char *filename)
{
	int ret;

	(void)chown(filename, 0, 0);
	(void)chmod(filename, 0000);

	ret = unlink(filename);
	if (errno == ENOENT)
		ret = 0;
	return ret;
}

int file_map(const char *filename, char **buf, size_t *bufsize)
{
	struct stat stats;
	int fd;

	fd = open(filename, O_RDONLY);
	if (fd < 0) {
		return -1;
	}

	if (fstat(fd, &stats) < 0) {
		close(fd);
		return -1;
	}

	*buf = mmap(NULL, stats.st_size, PROT_READ, MAP_SHARED, fd, 0);
	if (*buf == MAP_FAILED) {
		close(fd);
		return -1;
	}
	*bufsize = stats.st_size;
	close(fd);
	return 0;
}

int fs_copy_file(const char *from, const char *to)
{
	struct stat sb;
	int fdin, fdout;
	int status = 0;
	
	if ((fdin = open(from, O_RDONLY | _O_BINARY,0)) < 0)
		return -1;
	if (fstat(fdin, &sb) < 0) {
		close(fdin);
		return -1;
	}
	if ((fdout = open(to, O_CREAT | O_TRUNC | O_RDWR | _O_BINARY,
		(int) sb.st_mode & 07777)) < 0) {
		close(fdin);
		return -1;
	}
	if (sb.st_size > 0) {
		char buf[4096];
		int n;
		
		for (;;) {
			n = read(fdin, buf, sizeof(buf));
			if (n == -1) {
#ifdef EINTR
				if (errno == EINTR)
					continue;
#endif
				status = -1;
			}
			else if (n == 0) 
				break;
			
			if (write(fdout, buf, n) != n) {
				status = -1;
			}
		}
		
	}
	
	if (close(fdin) < 0) 
		status = -1;
	if (close(fdout) < 0)
		status = -1;
	
	return status;
}

void file_unmap(void *buf, size_t bufsize)
{
	munmap(buf, bufsize);
}

/* return number of chars until the next newline, skip escaped newline */
size_t buf_get_line(const char *buf, size_t buflen, size_t cur)
{
	int escape = 0;
	size_t count;

	for (count = cur; count < buflen; count++) {
		if (!escape && buf[count] == '\n')
			break;

		if (buf[count] == '\\')
			escape = 1;
		else
			escape = 0;
	}

	return count - cur;
}

int lock_file(const char *file, FILE **pfp)
{
	int rc = 0;
	FILE *fp = fopen(file, "w");

	if (fp == NULL) {
		rc = -1;
		goto end;
	}
#ifndef WIN32
	if (flock(fileno(fp), LOCK_EX) == 0) {
#else
	/* TODO: unsafe implementation, use mutex instead */
	if (locking(fileno(fp), LK_NBLCK, -1L) == 0) {
#endif
		*pfp = fp;
		goto end;
	} else {
		rc = -1;
		goto end;
	}
end:
	if (rc != 0) {
		if (fp)
			fclose(fp);
	}
	return rc;
}

void unlock_file(FILE *fp)
{
	if (fp == NULL)
		return;
#ifndef WIN32
	flock(fileno(fp), LOCK_UN);
#else
	locking(fileno(fp), LK_UNLCK, -1L);
#endif
	fclose(fp);
}

int fs_make_dir(const char *dir)
{
	if (dir && access(dir, 00) != 0) {
		if (0 != mkdir(dir, 0777)) {
			return -1;
		}
	}
	return 0;
}

int fs_create_dir(const char *dir)
{
	fs_create_path(dir);
	return fs_make_dir(dir);
}

static int is_dot_or_dotdot(const char *p)
{
	return (p[0] == '.' && (p[1] == '\0' || (p[1] == '.' && p[2] == '\0')));
}

static char *new_name(const char *path, const char *name)
{
	char *path_buf;
	
	path_buf = (char *)malloc(strlen(path) + strlen(name) + 2);
	if (path_buf == 0) {
		return NULL;
	}
	(void) sprintf(path_buf, "%s/%s", path, name);
	return path_buf;
}

int fs_remove_dir(const char *path)
{
	struct stat sbuf;
	DIR *dirp;
	struct _dirent *dp;
	char *path_buf;
	/* int path_len; */
	
	
	if (lstat(path, &sbuf) < 0)
		return 1;
	if (S_ISDIR(sbuf.st_mode)) {
		
		/* path_len=strlen(path); */
		dirp = opendir (path);
		if (dirp == 0)
			return 1;
		while (NULL != (dp = readdir(dirp))) {
			if (is_dot_or_dotdot(dp->d_name))
				continue;
			path_buf = new_name(path, dp->d_name);
			if (fs_remove_dir(path_buf)) {
				free (path_buf);
				closedir (dirp);
				return 1;
			}
			free (path_buf);
		}
		closedir(dirp);
		
		if (rmdir(path) < 0)
			return 1;
		return 0;
	}
	if (unlink(path) < 0)
		return 1;
	return 0;
}

int fs_touch_file(const char *file)
{
	FILE *fp = NULL;

	if (file && access(file, 00) != 0) {
		int rc = lock_file(file, &fp);
		if (rc != 0)
			return -1;
		unlock_file(fp);
	}
	return 0;
}

/* path_to_procfs - find the path to the proc file system mount point */
static char proc_path[MAXPATHLEN];
static int proc_path_len;

char *path_to_procfs(const char *tail)
{
	fs_mntent_t *mntent;
	FILE *fp;
	
	if (proc_path_len == 0) {
		/* Default the mount location of /proc */
		strlcpy(proc_path, "/proc", sizeof(proc_path));
		proc_path_len = 5;
		fp = fopen(MOUNTED, "r");
		if (fp != NULL) {
			while ((mntent = fs_mntent_get(fp)) != NULL) {
				if (strcmp(mntent->mnt_type, MNTTYPE_IGNORE) == 0)
					continue;
				if (strcmp(mntent->mnt_type, "proc") == 0) {
					strlcpy(proc_path, mntent->mnt_dir, sizeof(proc_path));
					proc_path_len = strlen(proc_path);
					break;
				}
			}
			fclose (fp);
		}
	}
	
	strlcpy(proc_path + proc_path_len, tail,
		sizeof(proc_path) - proc_path_len);
	return proc_path;
}
