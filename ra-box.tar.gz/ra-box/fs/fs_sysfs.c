#include "fs_priv.h"

static DECLARE_LIST(sysfs_devices);
static DECLARE_LIST(sysfs_attrs);

typedef struct _sysfs_attr_t {
	list_t node;
	char path[PATH_SIZE];
	char *value;			/*points to value_local if value is cached*/
	char value_local[NAME_SIZE];
} sysfs_attr_t;

#define for_each_device(dev_loop)		\
	list_for_each_entry(sysfs_device_t, dev_loop, &sysfs_devices, node)
#define for_each_device_safe(dev_loop, tmp)	\
	list_for_each_entry_safe(sysfs_device_t, dev_loop, tmp, &sysfs_devices, node)
#define for_each_attr(attr_loop)		\
	list_for_each_entry(sysfs_attr_t, attr_loop, &sysfs_attrs, node)
#define for_each_attr_safe(attr_loop, tmp)	\
	list_for_each_entry_safe(sysfs_attr_t, attr_loop, tmp, &sysfs_attrs, node)

const char *sysfs_resolve_path(const char *relative_path)
{
	static char abs_path[PATH_SIZE];

	strlcpy(abs_path, _PATH_SYS, sizeof (abs_path));
	strlcat(abs_path, relative_path, sizeof (abs_path));
	return abs_path;
}

void fs_sysfs_stop(void)
{
	sysfs_attr_t *attr_loop, *attr_temp;
	sysfs_device_t *dev_loop, *dev_temp;
	
	for_each_attr_safe(attr_loop, attr_temp) {
		list_delete(&attr_loop->node);
		free(attr_loop);
	}
	for_each_device_safe(dev_loop, dev_temp) {
		list_delete(&dev_loop->node);
		free(dev_loop);
	}
}

/* set sysfs_device devpath, subsystem, driver, 
 * and get the kernel name and kernel number
 */
void sysfs_device_set_values(sysfs_device_t *dev, const char *devpath,
			     const char *subsystem, const char *driver)
{
	char *pos;
	strlcpy(dev->devpath, devpath, sizeof(dev->devpath));
	if (subsystem != NULL)
		strlcpy(dev->subsystem, subsystem, sizeof(dev->subsystem));
	if (driver != NULL)
		strlcpy(dev->driver, driver, sizeof(dev->driver));

	/*set kernel name*/
	pos = strrchr(dev->devpath, '/');
	if (pos == NULL)
		return;
	strlcpy(dev->kernel, &pos[1], sizeof(dev->kernel));

	/*some device have '!' in their name, change that to '/'*/
	pos = dev->kernel;
	while (pos[0] != '\0') {
		if (pos[0] == '!')
			pos[0] = '/';
		pos++;
	}

	/*get kernel number*/
	pos = &dev->kernel[strlen(dev->kernel)];
	while (isdigit(pos[-1]))
		pos--;
	strlcpy(dev->kernel_number, pos, sizeof(dev->kernel_number));
}

char *sysfs_attr_get_value(const char *devpath, const char *attr_name)
{
	char path_full[PATH_SIZE];
	const char *path;
	char value[NAME_SIZE];
	sysfs_attr_t *attr_loop;
	sysfs_attr_t *attr;
	struct stat statbuf;
	int fd;
	ssize_t size;
	size_t sysfs_len;

	strlcpy(path_full, _PATH_SYS, sizeof(path_full));
	sysfs_len = strlen(path_full);
	if (sysfs_len >= sizeof(path_full))
		sysfs_len = sizeof(path_full) - 1;
	path = &path_full[sysfs_len];
	strlcat(path_full, devpath, sizeof(path_full));
	strlcat(path_full, "/", sizeof(path_full));
	strlcat(path_full, attr_name, sizeof(path_full));

	/*look for attribute in cache*/
	for_each_attr(attr_loop) {
		if (strcmp(attr_loop->path, path) == 0)
			return attr_loop->value;
	}

	attr =(sysfs_attr_t*)malloc(sizeof(sysfs_attr_t));
	if (attr == NULL)
		return NULL;
	memset(attr, 0x00, sizeof(sysfs_attr_t));
	strlcpy(attr->path, path, sizeof(attr->path));
	list_insert_head(&attr->node, &sysfs_attrs);

	if (lstat(path_full, &statbuf) != 0) {
		goto out;
	}

	if (S_ISLNK(statbuf.st_mode)) {
		char link_target[PATH_SIZE];
		int len;
		const char *pos;

		len = readlink(path_full, link_target, sizeof(link_target));
		if (len > 0) {
			link_target[len] = '\0';
			pos = strrchr(link_target, '/');
			if (pos != NULL) {
				strlcpy(attr->value_local, &pos[1], 
					sizeof(attr->value_local));
				attr->value = attr->value_local;
			}
		}
		goto out;
	}

	if (S_ISDIR(statbuf.st_mode))
		goto out;
	/*skip non-readable files*/
	if ((statbuf.st_mode & S_IRUSR) == 0)
		goto out;
	fd = open(path_full, O_RDONLY);
	if (fd < 0) {
		goto out;
	}
	size = read(fd, value, sizeof(value));
	close(fd);
	if (size < 0)
		goto out;
	if (size == sizeof(value))
		goto out;
	
	value[size] = '\0';
	remove_trailing_chars(value, '\n');
	strlcpy(attr->value_local, value, sizeof(attr->value_local));
	attr->value = attr->value_local;
out:
	return attr->value;
}

int sysfs_resolve_link(char *devpath, size_t size)
{
	char link_path[PATH_SIZE];
	char link_target[PATH_SIZE];
	int len;
	int i;
	int back;

	strlcpy(link_path, _PATH_SYS, sizeof(link_path));
	strlcat(link_path, devpath, sizeof(link_path));
	len = readlink(link_path, link_target, sizeof(link_target));
	if (len <= 0)
		return -1;
	link_target[len] = '\0';

	for (back = 0; strncmp(&link_target[back * 3], "../", 3) == 0; back++)
		;
	for (i = 0; i <= back; i++) {
		char *pos = strrchr(devpath, '/');

		if (pos == NULL)
			return -1;
		pos[0] = '\0';
	}
	strlcat(devpath, "/", size);
	strlcat(devpath, &link_target[back * 3], size);
	return 0;
}

sysfs_device_t *sysfs_device_get(const char *devpath)
{
	char path[PATH_SIZE];
	char devpath_real[PATH_SIZE];
	sysfs_device_t *dev;
	sysfs_device_t *dev_loop;
	struct stat statbuf;
	char link_path[PATH_SIZE];
	char link_target[PATH_SIZE];
	int len;
	char *pos;

	/* we handle only these devpathes */
	if (devpath != NULL &&
	    strncmp(devpath, "/devices/", 9) != 0 &&
	    strncmp(devpath, "/subsystem/", 11) != 0 &&
	    strncmp(devpath, "/module/", 8) != 0 &&
	    strncmp(devpath, "/bus/", 5) != 0 &&
	    strncmp(devpath, "/class/", 7) != 0 &&
	    strncmp(devpath, "/block/", 7) != 0)
		return NULL;

	strlcpy(devpath_real, devpath, sizeof(devpath_real));
	remove_trailing_chars(devpath_real, '/');
	if (devpath[0] == '\0' )
		return NULL;

	/* look for device already in cache (we never put an untranslated path in the cache) */
	for_each_device(dev_loop) {
		if (strcmp(dev_loop->devpath, devpath_real) == 0) {
			return dev_loop;
		}
	}

	/* if we got a link, resolve it to the real device */
	strlcpy(path, _PATH_SYS, sizeof(path));
	strlcat(path, devpath_real, sizeof(path));
	if (lstat(path, &statbuf) != 0) {
		return NULL;
	}
	if (S_ISLNK(statbuf.st_mode)) {
		if (sysfs_resolve_link(devpath_real, sizeof(devpath_real)) != 0)
			return NULL;

		/* now look for device in cache after path translation */
		for_each_device(dev_loop) {
			if (strcmp(dev_loop->devpath, devpath_real) == 0) {
				return dev_loop;
			}
		}
	}

	/* it is a new device */
	dev = malloc(sizeof(sysfs_device_t));
	if (dev == NULL)
		return NULL;
	memset(dev, 0x00, sizeof(sysfs_device_t));

	sysfs_device_set_values(dev, devpath_real, NULL, NULL);

	/* get subsystem name */
	strlcpy(link_path, _PATH_SYS, sizeof(link_path));
	strlcat(link_path, dev->devpath, sizeof(link_path));
	strlcat(link_path, "/subsystem", sizeof(link_path));
	len = readlink(link_path, link_target, sizeof(link_target));
	if (len > 0) {
		/* get subsystem from "subsystem" link */
		link_target[len] = '\0';
		pos = strrchr(link_target, '/');
		if (pos != NULL)
			strlcpy(dev->subsystem, &pos[1], sizeof(dev->subsystem));
	} else if (strstr(dev->devpath, "/drivers/") != NULL) {
		strlcpy(dev->subsystem, "drivers", sizeof(dev->subsystem));
	} else if (strncmp(dev->devpath, "/module/", 8) == 0) {
		strlcpy(dev->subsystem, "module", sizeof(dev->subsystem));
	} else if (strncmp(dev->devpath, "/subsystem/", 11) == 0) {
		pos = strrchr(dev->devpath, '/');
		if (pos == &dev->devpath[10])
			strlcpy(dev->subsystem, "subsystem", sizeof(dev->subsystem));
	} else if (strncmp(dev->devpath, "/class/", 7) == 0) {
		pos = strrchr(dev->devpath, '/');
		if (pos == &dev->devpath[6])
			strlcpy(dev->subsystem, "subsystem", sizeof(dev->subsystem));
	} else if (strncmp(dev->devpath, "/bus/", 5) == 0) {
		pos = strrchr(dev->devpath, '/');
		if (pos == &dev->devpath[4])
			strlcpy(dev->subsystem, "subsystem", sizeof(dev->subsystem));
	}

	/* get driver name */
	strlcpy(link_path, _PATH_SYS, sizeof(link_path));
	strlcat(link_path, dev->devpath, sizeof(link_path));
	strlcat(link_path, "/driver", sizeof(link_path));
	len = readlink(link_path, link_target, sizeof(link_target));
	if (len > 0) {
		link_target[len] = '\0';
		pos = strrchr(link_target, '/');
		if (pos != NULL)
			strlcpy(dev->driver, &pos[1], sizeof(dev->driver));
	}

	list_insert_before(&dev->node, &sysfs_devices);
	return dev;
}

sysfs_device_t *sysfs_device_get_parent(sysfs_device_t *dev)
{
	char parent_devpath[PATH_SIZE];
	char *pos;

	/* look if we already know the parent */
	if (dev->parent != NULL)
		return dev->parent;

	strlcpy(parent_devpath, dev->devpath, sizeof(parent_devpath));

	/* strip last element */
	pos = strrchr(parent_devpath, '/');
	if (pos == NULL || pos == parent_devpath)
		return NULL;
	pos[0] = '\0';

	if (strncmp(parent_devpath, "/class", 6) == 0) {
		pos = strrchr(parent_devpath, '/');
		if (pos == &parent_devpath[6] || pos == parent_devpath) {
			goto device_link;
		}
	}
	if (strcmp(parent_devpath, "/block") == 0) {
		goto device_link;
	}

	/* are we at the top level? */
	pos = strrchr(parent_devpath, '/');
	if (pos == NULL || pos == parent_devpath)
		return NULL;

	/* get parent and remember it */
	dev->parent = sysfs_device_get(parent_devpath);
	return dev->parent;

device_link:
	strlcpy(parent_devpath, dev->devpath, sizeof(parent_devpath));
	strlcat(parent_devpath, "/device", sizeof(parent_devpath));
	if (sysfs_resolve_link(parent_devpath, sizeof(parent_devpath)) != 0)
		return NULL;

	/* get parent and remember it */
	dev->parent = sysfs_device_get(parent_devpath);
	return dev->parent;
}

sysfs_device_t *sysfs_device_get_parent_with_subsystem(sysfs_device_t *dev, const char *subsystem)
{
	sysfs_device_t *dev_parent;

	dev_parent = sysfs_device_get_parent(dev);
	while (dev_parent != NULL) {
		if (strcmp(dev_parent->subsystem, subsystem) == 0)
			return dev_parent;
		dev_parent = sysfs_device_get_parent(dev_parent);
	}
	return NULL;
}

int sysfs_lookup_devpath_by_subsys_id(char *devpath_full, size_t len, const char *subsystem, const char *id)
{
	size_t sysfs_len;
	char path_full[PATH_SIZE];
	char *path;
	struct stat statbuf;

	sysfs_len = strlcpy(path_full, _PATH_SYS, sizeof(path_full));
	path = &path_full[sysfs_len];

	if (strcmp(subsystem, "subsystem") == 0) {
		strlcpy(path, "/subsystem/", sizeof(path_full) - sysfs_len);
		strlcat(path, id, sizeof(path_full) - sysfs_len);
		if (stat(path_full, &statbuf) == 0)
			goto found;

		strlcpy(path, "/bus/", sizeof(path_full) - sysfs_len);
		strlcat(path, id, sizeof(path_full) - sysfs_len);
		if (stat(path_full, &statbuf) == 0)
			goto found;
		goto out;

		strlcpy(path, "/class/", sizeof(path_full) - sysfs_len);
		strlcat(path, id, sizeof(path_full) - sysfs_len);
		if (stat(path_full, &statbuf) == 0)
			goto found;
	}

	if (strcmp(subsystem, "module") == 0) {
		strlcpy(path, "/module/", sizeof(path_full) - sysfs_len);
		strlcat(path, id, sizeof(path_full) - sysfs_len);
		if (stat(path_full, &statbuf) == 0)
			goto found;
		goto out;
	}

	if (strcmp(subsystem, "drivers") == 0) {
		char subsys[NAME_SIZE];
		char *driver;

		strlcpy(subsys, id, sizeof(subsys));
		driver = strchr(subsys, ':');
		if (driver != NULL) {
			driver[0] = '\0';
			driver = &driver[1];
			strlcpy(path, "/subsystem/", sizeof(path_full) - sysfs_len);
			strlcat(path, subsys, sizeof(path_full) - sysfs_len);
			strlcat(path, "/drivers/", sizeof(path_full) - sysfs_len);
			strlcat(path, driver, sizeof(path_full) - sysfs_len);
			if (stat(path_full, &statbuf) == 0)
				goto found;

			strlcpy(path, "/bus/", sizeof(path_full) - sysfs_len);
			strlcat(path, subsys, sizeof(path_full) - sysfs_len);
			strlcat(path, "/drivers/", sizeof(path_full) - sysfs_len);
			strlcat(path, driver, sizeof(path_full) - sysfs_len);
			if (stat(path_full, &statbuf) == 0)
				goto found;
		}
		goto out;
	}

	strlcpy(path, "/subsystem/", sizeof(path_full) - sysfs_len);
	strlcat(path, subsystem, sizeof(path_full) - sysfs_len);
	strlcat(path, "/devices/", sizeof(path_full) - sysfs_len);
	strlcat(path, id, sizeof(path_full) - sysfs_len);
	if (stat(path_full, &statbuf) == 0)
		goto found;

	strlcpy(path, "/bus/", sizeof(path_full) - sysfs_len);
	strlcat(path, subsystem, sizeof(path_full) - sysfs_len);
	strlcat(path, "/devices/", sizeof(path_full) - sysfs_len);
	strlcat(path, id, sizeof(path_full) - sysfs_len);
	if (stat(path_full, &statbuf) == 0)
		goto found;

	strlcpy(path, "/class/", sizeof(path_full) - sysfs_len);
	strlcat(path, subsystem, sizeof(path_full) - sysfs_len);
	strlcat(path, "/", sizeof(path_full) - sysfs_len);
	strlcat(path, id, sizeof(path_full) - sysfs_len);
	if (stat(path_full, &statbuf) == 0)
		goto found;
out:
	return 0;
found:
	if (S_ISLNK(statbuf.st_mode))
		sysfs_resolve_link(path, sizeof(path_full) - sysfs_len);
	strlcpy(devpath_full, path, len);
	return 1;
}
