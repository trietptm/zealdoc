#ifndef __FS_PRIV_H_INCLUDE__
#define __FS_PRIV_H_INCLUDE__

#include <fsserv.h>
#include <logger.h>
#include <uiserv.h>
#include <panic.h>
#include <list.h>
#ifdef WIN32
#include <sys/locking.h>
#else
#include <sys/file.h>
#endif
#include <linux/fs.h>
#include <linux/loop.h>
#include <service.h>
#include <getline.h>
#include <cli_api.h>

void fs_type_dump(list_t *flist, int block_backed);
void fs_type_free(list_t *flist);

void fs_sysfs_stop(void);

int __init fs_rootfs_init(void);
void __exit fs_rootfs_exit(void);

#endif /* __FS_PRIV_H_INCLUDE__ */
