#include "fs_priv.h"

#define LOOP_FORMAT	"/dev/loop/%d"
#define LOOP_NAMESIZE	(sizeof("/dev/loop/") + sizeof(int)*3 + 1)
#define LOOP_NAME	"/dev/loop/"

/* Returns 0 if mounted RW, 1 if mounted read-only, <0 for error.
 * *device is loop device to use, or if *device==NULL finds a loop device to
 * mount it on and sets *device to a strdup of that loop device name.  This
 * search will re-use an existing loop device already bound to that
 * file/offset if it finds one.
 */
int fs_loop_set(char **device, const char *file, uint64_t offset)
{
	char dev[LOOP_NAMESIZE];
	char *try;
	struct loop_info64 loopinfo;
	struct stat statbuf;
	int i, dfd, ffd, mode, rc = -1;

	/* barf if cannot be opened */
	mode = O_RDWR;
	ffd = open(file, mode);
	if (ffd < 0) {
		mode = O_RDONLY;
		ffd = open(file, mode);
		if (ffd < 0)
			return -errno;
	}

	/* find a loop device */
	try = *device ? *device : dev;
	for (i = 0; rc; i++) {
		sprintf(dev, LOOP_FORMAT, i);

		/* ran out of block devices, return failure */
		if (stat(try, &statbuf) || !S_ISBLK(statbuf.st_mode)) {
			rc = -ENOENT;
			break;
		}

		/* open the sucker and check its loopiness */
		dfd = open(try, mode);
		if (dfd < 0 && errno == EROFS) {
			mode = O_RDONLY;
			dfd = open(try, mode);
		}
		if (dfd < 0)
			goto try_again;

		rc = ioctl(dfd, LOOP_GET_STATUS64, (unsigned long)&loopinfo);

		/* if device is free, claim it */
		if (rc && errno == ENXIO) {
			memset(&loopinfo, 0, sizeof(loopinfo));
			strlcpy((char *)loopinfo.lo_file_name, file, LO_NAME_SIZE);
			loopinfo.lo_offset = offset;
			/* associate free loop device with file */
			if (!ioctl(dfd, LOOP_SET_FD, (unsigned long)ffd)) {
				if (!ioctl(dfd, LOOP_SET_STATUS64, (unsigned long)&loopinfo))
					rc = 0;
				else
					ioctl(dfd, LOOP_CLR_FD, 0);
			}
		} else if (strcmp(file, (char *)loopinfo.lo_file_name) != 0 ||
			   offset != loopinfo.lo_offset) {
			/* if this block device already set up right, re-use it.
			 * (Yes this is racy, but associating two loop devices with
			 * the same file isn't pretty either.  In general, mounting
			 * the same file twice without using losetup manually is
			 * problematic.)
			 */
			rc = -1;
		}
		close(dfd);
try_again:
		if (*device) break;
	}
	close(ffd);
	if (!rc) {
		if (!*device)
			*device = strdup(dev);
		return (mode == O_RDONLY); /* 1:ro, 0:rw */
	}
	return rc;
}

int fs_loop_unset(const char *device)
{
	int fd, rc;

	fd = open(device, O_RDONLY);
	if (fd < 0) return 1;
	rc = ioctl(fd, LOOP_CLR_FD, 0);
	close(fd);
	return rc;
}
