/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2007
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@gmail.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)main.c: network service daemon entry
 * $Id: main.c,v 1.99 2009-02-25 04:01:42 zhenglv Exp $
 */

#include "main.h"

#define NETSVC_VERSION	"1.0"
#ifdef WIN32
#define NETSVC_SYSTEM	"win32"
#else
#define NETSVC_SYSTEM	"unix"
#endif

const char *netsvc_version = CONFIG_VENDOR_SHORT " NETSVC " \
			     NETSVC_VERSION "." NETSVC_SYSTEM " " \
			     __DATE__ " " __TIME__;
int netsvc_pid = -1;
log_output_t *netsvc_output = NULL;
const char *netsvc_prog = CONFIG_PRODUCT_SHORT;
const char *netsvc_conf = UI_DEF_CONF_FILE;

static void version(void)
{
	printf("%s: %s\n", netsvc_prog, netsvc_version);
	printf("Copyright (C) 2008 " CONFIG_VENDOR_LONG ".\n");
	exit(0);
}

static void usage(int status)
{
	FILE *output = status?stderr:stdout;

	fprintf(output, "Usage: %s [-f config] [-h] [-v]\n", netsvc_prog);
	fprintf(output, "Options:\n");
	fprintf(output, "  -f  config      Load settings from <config> file.\n");
	fprintf(output, "  -h              Print this help message.\n");
	fprintf(output, "  -v              Print server version information.\n");
	exit(status);
}

static void wsa_startup(void)
{
#ifdef WIN32
	static int wsa_started = 0;
	WSADATA data;

	if (!wsa_started) {
		if (WSAStartup(MAKEWORD(2, 2), &data) != 0)
			return;
		wsa_started = 1;
	}
#endif
}

static void wsa_cleanup(void)
{
#ifdef WIN32
	WSACleanup();
#endif
}

static int netsvc_argcv(int argc, char **argv)
{
	int argval;

	/* process the options */
	while ((argval = getopt(argc, argv, "f:vh")) != EOF) {
		switch (argval) {
		case 'f':
			netsvc_conf = optarg;
			break;
		case 'h':
			usage(0);
			break;
		case 'v':
			version();
			break;
		default:
			usage(1);
			break;
		}
	}
	
	/* get our PID */
	netsvc_pid = getpid();
	return 0;
}

static void netsvc_terminate(int sig, void *eloop_ctx, void *signal_ctx)
{
	//eloop_terminate(NULL);
}

#ifdef SIGCHLD
static void netsvc_reapchild(int sig, void *eloop_ctx, void *signal_ctx)
{
	int saved_errno = errno;
	union wait status;

	while (wait3(&status, WNOHANG, NULL) > 0)
		;
	errno = saved_errno;
}
#endif

static void netsvc_reconfig(int sig, void *eloop_ctx, void *signal_ctx)
{
	/* TODO: call eloop_timeout -> services_stop / service_start */
}

#if 0
#ifdef CONFIG_IPSEC
static int ipsec_acquire_test(void)
{
	nic_t *dev;
	struct sockaddr_in dst, src;

	dev = nic_by_name("eth0");
	if (!dev) return -1;
	memset(&dst, 0, sizeof (struct sockaddr_in));
	memset(&src, 0, sizeof (struct sockaddr_in));

	src.sin_family = dst.sin_family = AF_INET;
	src.sin_port = dst.sin_port = htons(ISAKMP_PORT);
	src.sin_addr.s_addr = dev->attrs.address;
	dst.sin_addr.s_addr = inet_addr("192.168.100.2");
	ipsec_acquire((struct sockaddr *)&dst, (struct sockaddr *)&src);
	return 0;
}
#else
static int ipsec_acquire_test(void) { return 0; }
#endif
#endif

static void ui_exit_main_step(void *eloop, void *user)
{
#if 0
	if (services_stopped())
		eloop_terminate(NULL);
#endif
}

static int ui_exit_main_loop(ui_session_t *sess, ui_entry_t *inst,
			     void *ctx, int argc, char **argv)
{
	eloop_terminate(NULL);
	return 0;
}

static ui_command_t main_exit_command = {
	"exit",
	"Exit main loop",
	".cli",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(main_exit_command.link),
	ui_exit_main_loop,
};

static int __init netsvc_startup(void)
{
	wsa_startup();

	early_begin();
	system_init();
	modules_start();
	ui_conf_start();
	services_start();
	eloop_register_signal_terminate(netsvc_terminate, NULL);
	eloop_register_signal_reconfig(netsvc_reconfig, NULL);
#ifdef SIGCHLD
	eloop_register_signal(SIGCHLD, netsvc_reapchild, NULL);
#endif
	ui_register_command(&main_exit_command);
	ui_user_start();
	early_end();
	return 0;
}

static void __exit netsvc_cleanup(void)
{
	ui_user_stop();
	services_stop();
	ui_conf_stop();
	modules_stop();
	system_exit();
	wsa_cleanup();
}

int main(int argc, char **argv)
{
	netsvc_argcv(argc, argv);

	ui_set_conf_file(netsvc_conf);
	if (netsvc_startup())
		exit(1);

	/* ipsec_acquire_test(); */

	/* main loop begins here */
	eloop_context_run(NULL);
	netsvc_cleanup();
}
