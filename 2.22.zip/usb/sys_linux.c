#include "usb_priv.h"
#include "sys_linux.h"


/* sysfs vs usbfs
 * opening a usbfs node causes the device to be resumed, so we attempt to
 * avoid this during enumeration.
 *
 * sysfs allows us to read the kernel's in-memory copies of device descriptors
 * and so forth, avoiding the need to open the device:
 *	- The binary "descriptors" file was added in 2.6.23.
 *	- The "busnum" file was added in 2.6.22
 *	- The "devnum" file has been present since pre-2.6.18
 *	- The "bConfigurationValue" file has been present since pre-2.6.18
 *
 * If we have bConfigurationValue, busnum, and devnum, then we can determine
 * the active configuration without having to open the usbfs node in RDWR mode.
 * We assume this the case if we see the busnum file (indicate 2.6.22+).
 * The busnum file is important as that is the only way we can relate sysfs
 * device to usbfs nodes.
 *
 * If we also have descriptors, we can obtain the device descriptor and active
 * configuration without touching usbfs at all.
 *
 * The descriptor file originally only contained the active configuration
 * descriptor alongside the device descriptor, but all configuration are 
 * included as the linux 2.6.22
 */

enum reap_action {
	NORMAL = 0,
	/* submission failed after the first URB, so await 
	 * cancellation/completion of all the others*/
	SUBMIT_FAILED, 
	/* cancelled by user or timeout */
	CANCELLED,
	/* completed multi-URB transfer in non-final URB*/
	COMPLETED_EARLY,
};

struct linux_transfer_priv {
	union {
		struct usbfs_urb *urbs;
		struct usbfs_urb **iso_urbs;
	};
	enum reap_action reap_action;
	int num_urbs;
	unsigned int awaiting_reap;
	unsigned int awaiting_discard;

	/*next iso packet in user-supplied transfer to be populated */
	int iso_packet_offset;
};

static int check_usb_vfs(const char *dirname)
{
	DIR *dir;
#ifdef WIN32
	struct direct *entry = NULL;
#else
	struct dirent *entry = NULL;
#endif
	int found = 0;

	dir = opendir(dirname);
	if (!dir)
		return 0;

	while ((entry = readdir(dir)) != NULL) {
		if (entry->d_name[0] == '.')
			continue;
		found = 1;
		break;
	}

	closedir(dir);
	return found;
}

static const char *find_usbfs_path(void)
{
	const char *path = "/dev/bus/usb";
	const char *ret = NULL;

	if (check_usb_vfs(path)) {
		ret = path;
	} else {
		path = "/proc/bus/usb";
		if (check_usb_vfs(path))
			ret = path;
	}

	return ret;
}

static int sysfs_device_init(struct usb_device *dev)
{
	return USB_ERROR_NOT_SUPPORTED;
}

static int sysfs_device_release(usb_device_t *dev)
{
	return USB_ERROR_NOT_SUPPORTED;
}

static int usbfs_get_active_config(struct usb_device *dev, int fd, 
				   int *active_config)
{
	int r;

	struct usbfs_ctrltransfer ctrl = {
		USB_ENDPOINT_IN,
		USB_REQUEST_GET_CONFIGURATION,
		0,
		0,
		1,
		1000,
		active_config		
	};
	r = ioctl(fd, IOCTL_USBFS_CONTROL, (unsigned long)&ctrl);
	if (r < 0) {
		if (errno == ENODEV)
			return USB_ERROR_NO_DEVICE;
		return USB_ERROR_IO;
	}

	return USB_SUCCESS;
}

/* FIXME: when we faster than udevd? cannot open the file */
static int usbfs_device_init(struct usb_device *dev)
{
	int fd = -1;
	uint8_t *dev_desc = NULL;
	int i, r, ret;
	char *p, name[PATH_MAX];

	dev->active_config = USB_DEACTIVE_CONFIG;


	p = strstr(dev->filename, "/dev");
	if (!p) {
		strlcpy(name, _PATH_DEV, sizeof(name));
		if (strlast(name) != '/')
			strlcat(name, "/", sizeof(name));
		strlcat(name, dev->filename, sizeof(name));
	}

	usb_log(USB_LOG_DEBUG, "LNX: init device=%s", name);
	fd = open(name, O_RDWR);
	if (fd < 0) {
		usb_log(USB_LOG_DEBUG, "LNX: 1st open=%s fail", name);
		if (errno == EACCES) {
			fd = open(name, O_RDONLY);
			usb_log(USB_LOG_DEBUG, "LNX: 2nd open fail");
			if (fd < 0) {
				return USB_ERROR_OTHER;
			}
			dev->active_config = USB_INVALID_CONFIG;
		} else
			return USB_ERROR_IO;
	}

	dev->dev_desc = malloc(sizeof(struct usb_device_descriptor));
	if (!dev->dev_desc) {
		ret = USB_ERROR_NO_MEM;
		goto fail;
	}

	dev_desc = malloc(USB_DT_DEVICE_SIZE);
	if (!dev_desc) {
		ret = USB_ERROR_NO_MEM;
		goto fail;
	}

	r = read(fd, dev_desc, USB_DT_DEVICE_SIZE);
	if (r < USB_DT_DEVICE_SIZE) {
		free(dev_desc);
		ret = USB_ERROR_IO;
		goto fail;
	}
	
	usbi_parse_descriptor(dev_desc, "bbwbbbbwwwbbbb", dev->dev_desc, 1);
	free(dev_desc);

	if (dev->dev_desc->bNumConfigurations > USB_MAX_CONFIG || 
	    dev->dev_desc->bNumConfigurations < 1) {
		ret = USB_ERROR_IO;
		goto fail;
	}

	dev->config_desc = malloc(dev->dev_desc->bNumConfigurations * 
				  sizeof(struct usb_config_descriptor));
	if (!dev->config_desc) {
		ret = USB_ERROR_NO_MEM;
		goto fail;
	}
	for (i = 0; i < dev->dev_desc->bNumConfigurations; i++) {
		uint8_t tmp[8], *config_buf;
		struct usb_config_descriptor config;
		
		r = read(fd, tmp, 8);
		if (r < 8) {
			ret = USB_ERROR_NO_MEM;
			goto fail;
		}
		usbi_parse_descriptor(tmp, "bbw",  &config, 1);
		
		config_buf = malloc(config.wTotalLength);
		if (!config_buf) {
			ret = USB_ERROR_NO_MEM;
			goto fail;
		}
		memcpy(config_buf, tmp, 8);
		
		r = read(fd, config_buf + 8, config.wTotalLength - 8);
		if ( r < config.wTotalLength - 8) {
			free(config_buf);
			ret = USB_ERROR_NO_MEM;
			goto fail;
	
		}
		usbi_parse_configuration(&dev->config_desc[i], config_buf, 1);
		free(config_buf);
	}
	
	/* Get active config*/
	if (dev->active_config == USB_INVALID_CONFIG) {
		/* FIXME: need free dev->config ? */
		usb_log(USB_LOG_WARN, "LNX: access to %s is read only; cannot"
			"determine active config desc", dev->filename);
	} else {
		ret = usbfs_get_active_config(dev, fd, &dev->active_config);
		if (ret != USB_SUCCESS)
			goto fail;

		if (dev->active_config > dev->dev_desc->bNumConfigurations) {
			ret = USB_ERROR_IO;
			goto fail;
		}
	}
	
	ret = USB_SUCCESS;
	goto succ;

fail:
	if (dev->dev_desc) free(dev->dev_desc);
	if (dev->config_desc) free(dev->config_desc);
succ:
	if (fd >= 0)
		close(fd);
	return ret;
}

static void usbfs_device_release(struct usb_device *dev)
{
	if (dev->config_desc) {
		usbi_clear_configuration(dev->config_desc);
		free(dev->config_desc);
	}
	if (dev->dev_desc)
		free(dev->dev_desc);
}

static int linux_dev_init(struct usb_device *dev)
{
	int r;

	r = sysfs_device_init(dev);
	if (r != USB_SUCCESS)	
		r = usbfs_device_init(dev);
	return r;
}

static void linux_dev_release(usb_device_t *dev)
{
	int r;

	r = sysfs_device_release(dev);
	if (r != USB_SUCCESS)
		usbfs_device_release(dev);
}

static int linux_open(usb_intfc_t *dev_handle)
{
	char name[PATH_MAX];
	char *p;
	BUG_ON(!dev_handle);
	
	if (dev_handle->fd > 0)
		return 0;

	p = strstr(dev_handle->dev->filename, "/dev");
	if (!p) {
		strlcpy(name, _PATH_DEV, sizeof(name));
		if (strlast(name) != '/')
			strlcat(name, "/", sizeof(name));
		strlcat(name, dev_handle->dev->filename, sizeof(name));
	}

	dev_handle->fd = open(name, O_RDWR);
	if (dev_handle->fd < 0) {
		if (errno == EACCES)
			return USB_ERROR_ACCESS;
		else if (errno == ENOENT)
			return USB_ERROR_NO_DEVICE;
		else 
			return USB_ERROR_IO;
	}

	eloop_register_sock(NULL, dev_handle->fd, EVENT_TYPE_WRITE, 
			usbi_eloop_handle_cb, NULL, dev_handle);
	return 0;
}

static void linux_close(usb_intfc_t *dev_handle)
{
	if (dev_handle->fd >= 0) {

		eloop_unregister_sock(NULL, dev_handle->fd, EVENT_TYPE_WRITE);
		usb_log(USB_LOG_DEBUG, "LNX: close device");
		close(dev_handle->fd);
		dev_handle->fd = -1;
	}
}

static int linux_get_config(usb_intfc_t *dev, 
			    unsigned int *config_idx)
{	
	return USB_ERROR_NOT_SUPPORTED;	
}

static int linux_set_config(usb_intfc_t *intfc,
			    unsigned int config_idx)
{
	int ret;

	ret = ioctl(intfc->fd, IOCTL_USBFS_SETCONFIG,
		    (unsigned long)&config_idx);
	if (ret < 0) {
		if (errno == ENOENT)
			return USB_ERROR_NOT_FOUND;
		else if (errno == EBUSY)
			return USB_ERROR_BUSY;
		else if (errno == ENODEV)
			return USB_ERROR_NO_DEVICE;

		return USB_ERROR_OTHER;
	}

	return USB_SUCCESS;
}

#if 0
static int linux_setintf(usb_intfc_t *intfc, int intfno, int altset)
{
	int r;
	struct usb_setintf {
		unsigned int intfc;
		unsigned int altsetting;
	} setintf;

	setintf.intfc = intfno;
	setintf.altsetting = altset;

	/* this will set interface and claim it */
	r = ioctl(intfc->fd, IOCTL_USBFS_SETINTF, (unsigned long)&setintf);
	if (r < 0) {
		usb_log(USB_LOG_ERR, "LINUX: SETINTF error");
		return -1;
	} else {
		usb_log(USB_LOG_INFO, "LINUX: SETINTF success");
		return 0;
	}
}
#endif

static int linux_claim_intfc(usb_intfc_t *dev_handle)
{
	int ret, i;

	i = dev_handle->cur_altsetting->bInterfaceNumber;

	ret = ioctl(dev_handle->fd, IOCTL_USBFS_CLAIMINTF, (unsigned long)&i);
	if (ret) {
		usb_log(USB_LOG_ERR, "LNX: CLAIMINTF fail, intno=%d",
			dev_handle->cur_altsetting->bInterfaceNumber);
		if (errno == ENOENT)
			return USB_ERROR_NOT_FOUND;
		else if (errno == EBUSY)
			return USB_ERROR_BUSY;
		else if (errno == ENODEV)
			return USB_ERROR_NO_DEVICE;

		return USB_ERROR_OTHER;
	}
	usb_log(USB_LOG_INFO, "LNX: CLAIMINTF succ");

	return USB_SUCCESS;
}

static int linux_release_intfc(usb_intfc_t *dev_handle)
{
	int r;

	r = ioctl(dev_handle->fd, IOCTL_USBFS_RELEASEINTF,
		  (unsigned long)&dev_handle->cur_altsetting->bInterfaceNumber);
	if (r) {
		if (errno == ENODEV)
			return USB_ERROR_NO_DEVICE;

		return USB_ERROR_OTHER;
	}

	return USB_SUCCESS;		
}

static int submit_control_transfer(struct usb_transfer *usb_trans)
{
	struct linux_transfer_priv *tpriv ;
	struct usbfs_urb *urb;
	int r;

	tpriv = usb_trans->os_priv;
	
	if (usb_trans->length - USB_CONTROL_SETUP_SIZE > MAX_CTRL_BUFFER_LENGTH)
		return USB_ERROR_INVALID_PARAM;
	urb = malloc(sizeof(struct usbfs_urb));
	if (!urb)
		return USB_ERROR_NO_MEM;
	memset(urb, 0, sizeof(struct usbfs_urb));
	tpriv->urbs = urb;
	tpriv->reap_action = NORMAL;

	urb->usercontext = usb_trans;
	urb->type = USBFS_URB_TYPE_CONTROL;
	urb->endpoint = usb_trans->endpoint;
	urb->buffer = usb_trans->buffer;
	urb->buffer_length = usb_trans->length;

	r = ioctl(usb_trans->dev_handle->fd, IOCTL_USBFS_SUBMITURB,
		  (unsigned long)urb);
	if (r < 0) {
		free(urb);
		if (errno == ENODEV)
			return USB_ERROR_NO_DEVICE;
		return USB_ERROR_IO;
	}

	return 0;
}

static int submit_bulk_transfer(struct usb_transfer *usb_trans, 
				unsigned char urb_type)
{
	struct linux_transfer_priv *tpriv ;
	struct usbfs_urb *urbs;
	int r, i;
	size_t alloc_size;
	/* urbfs place a 16kb limit on bulk URBs, we divideup larger
	 * requests into smaller units to meet such restriction, then
	 * fire off all the units at once. it would be simpler if we
	 * just fired one unit at a time, but there is a big performance
	 * gain through doing it this way.
	 */
	int num_urbs;
	int last_urb_partial = 0;

	BUG_ON(!usb_trans || !usb_trans->os_priv);

	tpriv = usb_trans->os_priv;

	num_urbs = usb_trans->length / MAX_BULK_BUFFER_LENGTH;

	if ((usb_trans->length % MAX_BULK_BUFFER_LENGTH) > 0) {
		last_urb_partial = 1;
		num_urbs++;
	}

	alloc_size = num_urbs * sizeof(struct usbfs_urb);
	urbs = malloc(alloc_size);
	if (!urbs)
		return USB_ERROR_NO_MEM;
	memset(urbs, 0, alloc_size);

	tpriv->urbs = urbs;
	tpriv->num_urbs = num_urbs;
	tpriv->awaiting_discard = 0;
	tpriv->awaiting_reap = 0;
	tpriv->reap_action = NORMAL;

	for (i = 0; i < num_urbs; i++) {
		struct usbfs_urb *urb = &urbs[i];
		
		urb->usercontext = usb_trans;
		urb->type = urb_type;
		urb->endpoint = usb_trans->endpoint;
		urb->buffer = usb_trans->buffer + (i * MAX_BULK_BUFFER_LENGTH);
		if (i == num_urbs - 1 && last_urb_partial)
			urb->buffer_length = 
				usb_trans->length % MAX_BULK_BUFFER_LENGTH;
		else
			urb->buffer_length = MAX_BULK_BUFFER_LENGTH;
	
		r = ioctl(usb_trans->dev_handle->fd, IOCTL_USBFS_SUBMITURB,
			  (unsigned long)urb);
		if (r < 0) {
			int j;

			usb_log(USB_LOG_ERR, "LINUX: SUBMITURB fail");
		
			if (errno == ENODEV)
				r = USB_ERROR_NO_DEVICE;
			else
				r = USB_ERROR_IO;
			if (i == 0) {
				free(urbs);
				return r;
			}
			tpriv->reap_action = SUBMIT_FAILED;

			for (j = 0; j < i; j++) {
				int tmp;

				tmp = ioctl(usb_trans->dev_handle->fd, IOCTL_USBFS_DISCARDURB,
					    (unsigned long)&urbs[j]);
				if (tmp == 0)
					tpriv->awaiting_discard++;
				else if (errno == EINVAL)
					tpriv->awaiting_reap++;
				else {
					usb_log(USB_LOG_WARN, "LNX: DISCARDURB return unknown code=%d", tmp);
				}
			}
			return 0;
		}
	}
	usb_log(USB_SHOW, "LNX: submit trans");
	return 0;
}

static int linux_submit_transfer(struct usb_transfer *usb_trans)
{
	switch(usb_trans->type) {
	case USB_TRANSFER_TYPE_CONTROL:
		return submit_control_transfer(usb_trans);
	case USB_TRANSFER_TYPE_BULK:
		return submit_bulk_transfer(usb_trans, USBFS_URB_TYPE_BULK);
	case USB_TRANSFER_TYPE_INTERRUPT:
		return submit_bulk_transfer(usb_trans, USBFS_URB_TYPE_INTERRUPT);
	case USB_TRANSFER_TYPE_ISOCHRONOUS:
		return USB_ERROR_NOT_SUPPORTED;
	default:
		return USB_ERROR_INVALID_PARAM;
	}
}

static int parse_control_reap(struct usb_transfer *usb_trans, 
				     struct usbfs_urb *urb)
{
	struct linux_transfer_priv *tpriv;
	
	tpriv = usb_trans->os_priv;
	
	if (urb->status == 0)
		usb_trans->actual_length += urb->actual_length;
	if (tpriv->reap_action == CANCELLED) {
		if (urb->status != 0 && urb->start_frame != -ENOENT)
			usb_log(USB_LOG_WARN, 
				   "cancel: unrecognised urb status %d",
				   urb->status);
		if (usb_trans->status != USB_TRANSFER_TIME_OUT)
			usb_trans->status = USB_TRANSFER_CANCELLED;
		goto done;
	}
	
	if (urb->status == -EPIPE) {
		usb_log(USB_LOG_ERR, "unregcognised urb status %d",
			     urb->status);
		usb_trans->status = USB_TRANSFER_ERROR;
		goto done;
	}

	usb_trans->actual_length = urb->actual_length;
	usb_trans->status = USB_TRANSFER_COMPLETED;
done:
	free(tpriv->urbs);
	return USB_SUCCESS;
}

static int parse_bulk_reap(struct usb_transfer *usb_trans,
			struct usbfs_urb *urb)
{
	struct linux_transfer_priv *tpriv = usb_trans->os_priv;
	int num_urbs = tpriv->num_urbs;
	int urb_idx = urb - tpriv->urbs;

	if (urb_idx < 0 || urb_idx > tpriv->num_urbs) {
		usb_log(USB_LOG_ERR, "LNX: unnormal urb idx, maybe some wrong");
		usb_trans->status = USB_TRANSFER_ERROR;
		goto done;
	}

	if (urb->status == 0 ||
	    (urb->status == -EOVERFLOW && urb->actual_length > 0))
		usb_trans->actual_length += urb->actual_length;

	if (tpriv->reap_action != NORMAL) {
		/* cancelled, submit_fail, or completed early */
		if (urb->status == -ENOENT) {
			usb_log(USB_LOG_DEBUG,
				"LNX: detected a cancelled URB");
			if (tpriv->awaiting_discard == 0)
				usb_log(USB_LOG_ERR,
					"LNX: cancellled URB but not "
					"awaiting discards ?");
			else
				tpriv->awaiting_discard--;
		} else if (urb->status == 0) {
			/* FIXME we could solve this extream corner case with
			 * a memmove or something */
			if (tpriv->reap_action == COMPLETED_EARLY) 
				usb_log(USB_LOG_WARN, "LNX: some data lost! "
					"(completed early but remaining urb "
					"completed)");

			if (tpriv->awaiting_reap == 0)
				usb_log(USB_LOG_ERR, 
					"LNX: completed URB but no awaiting "
					"reap");
			else
				tpriv->awaiting_reap--;
		} else if (urb->status == -EPIPE ||
			   urb->status == -EOVERFLOW) {
			if (tpriv->awaiting_reap == 0)
				usb_log(USB_LOG_ERR,
					"LNX: completed URB but no awaiting "
					"reap");
			else
				tpriv->awaiting_reap--;
		} else {
			usb_log(USB_LOG_ERR, 
				"LNX: unhandled CANCEL urb status %d", urb->status);
		}

		if (tpriv->awaiting_reap == 0 &&
		    tpriv->awaiting_discard == 0) {
			if (tpriv->reap_action == CANCELLED) {
				/* usb_trans->status has been set before. */
			} else if (tpriv->reap_action == COMPLETED_EARLY) {
				usb_trans->status = USB_TRANSFER_COMPLETED;
			} else {
				usb_trans->status = USB_TRANSFER_ERROR;
			}
			goto done;
		}
		/* need reap again */
		usb_trans->status = USB_TRANSFER_REAPING;
		return USB_SUCCESS;
	}
	/* reap action is NORMAL */
	if (urb->status == -EPIPE) {
		usb_trans->status = USB_TRANSFER_STALL;
		goto done;
	} else if (urb->status == -EOVERFLOW) {
		usb_trans->status = USB_TRANSFER_OVERFLOW;
		goto done;
	} else if (urb->status != 0) {
		usb_log(USB_LOG_WARN, "LNX: unrecognised urb status %d",
			urb->status);
	}

	/* If we are the last urb or we got less data than requested then we
	 * are done. */
	if (urb_idx == num_urbs - 1) {
		usb_trans->status = USB_TRANSFER_COMPLETED;
		goto done;
	} else if (urb->actual_length < urb->buffer_length) {
		int i;

		/* We have to cancel the remaining urbs and wait for their 
		 * completion before reporting results. */
		tpriv->reap_action = COMPLETED_EARLY;
		for (i = urb_idx + 1; i < tpriv->num_urbs; i++) {
			int r;

			r = ioctl(usb_trans->dev_handle->fd, IOCTL_USBFS_DISCARDURB, 
				  (unsigned long)&tpriv->urbs[i]);
			if (r == 0)
				tpriv->awaiting_discard++;
			else if (errno == EINVAL)
				tpriv->awaiting_reap++;
			else 
				usb_log(USB_LOG_WARN, 
					"LNX: unrecognised discard return %d", errno);
		}
		usb_trans->status = USB_TRANSFER_REAPING;
		goto out;

	} else {
		usb_trans->status = USB_TRANSFER_REAPING;
		goto out;
	}

done:
	usb_log(USB_SHOW, "LNX: reap trans done"/*, id=%d", usb_trans->id */);
	if (tpriv && tpriv->urbs) free(tpriv->urbs);
	usb_trans->reaped = 1;
out:
	return USB_SUCCESS;
}

static int linux_asyn_reap(usb_intfc_t *dev_handle, 
		     struct usb_transfer **otransfer)
{
	struct usb_transfer *usb_trans;
	struct usbfs_urb *urb;
	int r = USB_SUCCESS;

	r = ioctl(dev_handle->fd, 
		  IOCTL_USBFS_REAPURBNDELAY,
		  (unsigned long)&urb);

	if (r < 0) {
		usb_log(USB_LOG_ERR,
			"LNX: REAPURBNDELAY fail=%d", r);

		if (errno == EAGAIN)
			/* not an error */
			return USB_REAP_AGAIN;
		else if (errno == ENODEV)
			return USB_ERROR_NO_DEVICE;
		else
			return USB_ERROR_IO;
	}

	*otransfer = usb_trans = urb->usercontext;
	switch (usb_trans->type) {
	case USB_TRANSFER_TYPE_CONTROL:
		return parse_control_reap(usb_trans, urb);
	case USB_TRANSFER_TYPE_BULK:
	case USB_TRANSFER_TYPE_INTERRUPT:
		return  parse_bulk_reap(usb_trans, urb);
	case USB_TRANSFER_TYPE_ISOCHRONOUS:
		return USB_ERROR_NOT_SUPPORTED;
	default:
		usb_log(USB_LOG_ERR, "LNX: unrecognised endpoint type=%x",
				usb_trans->type);
		return  USB_ERROR_NOT_SUPPORTED;
	}
}

static int cancel_control_transfer(struct usb_transfer *usb_trans)
{
	struct linux_transfer_priv *tpriv ;
	int r;

	tpriv = usb_trans->os_priv;
	
	r = ioctl(usb_trans->dev_handle->fd, IOCTL_USBFS_DISCARDURB,
		  (unsigned long)tpriv->urbs);
	if (r) {
		if (errno == EINVAL) {
			return 0;
		} else {
			return USB_ERROR_OTHER;
		}		
	}

	return 0;
}

static void cancel_bulk_transfer(struct usb_transfer *usb_trans)
{
	struct linux_transfer_priv *tpriv ;
	int i;

	tpriv = usb_trans->os_priv;
	tpriv->awaiting_reap = 0;
	tpriv->awaiting_discard = 0;
	for (i = 0; i < tpriv->num_urbs; i++) {
		int tmp = ioctl(usb_trans->dev_handle->fd, 
				IOCTL_USBFS_DISCARDURB, 
				(unsigned long)&tpriv->urbs[i]);
		if (tmp == 0)
			tpriv->awaiting_discard++;
		else if (errno == EINVAL) {
			tpriv->awaiting_reap++;
		} else {
			BUG();
		}
	}
}

static int linux_cancel_transfer(struct usb_transfer *usb_trans)
{
	struct linux_transfer_priv *tpriv = usb_trans->os_priv;
	
	/* submit_fail have discard submitted urbs */
	if (tpriv->reap_action != NORMAL)
		return 0;
	
	tpriv->reap_action = CANCELLED;
	
	usb_log(USB_SHOW, "LNX: cancel trans");

	switch (usb_trans->type) {
	case USB_TRANSFER_TYPE_CONTROL:
		return cancel_control_transfer(usb_trans);
	case USB_TRANSFER_TYPE_BULK:
	case USB_TRANSFER_TYPE_INTERRUPT:
		cancel_bulk_transfer(usb_trans);
		return 0;
	case USB_TRANSFER_TYPE_ISOCHRONOUS:
		return USB_ERROR_NOT_SUPPORTED;
	default:
		return USB_ERROR_INVALID_PARAM;
	}	
}

static int linux_ioctl(usb_intfc_t *dev_handle, int intfc_no, 
		       int ioctl_code, void *data)
{
	struct usbfs_ioctl command;
		
	command.ifno = intfc_no;
	command.ioctl_code = ioctl_code;
	command.data = data;

	if (ioctl(dev_handle->fd, IOCTL_USBFS_IOCTL, (unsigned long)&command))
		return USB_ERROR_IO;
	else 
		return USB_SUCCESS;
}

static int linux_free_check(struct usb_transfer *t)
{
	struct linux_transfer_priv *tpriv ;

	if (!t)
		return 0;

	tpriv = t->os_priv;
	if (tpriv->awaiting_discard || tpriv->awaiting_reap ||
	    t->reaped != 1)
		return 0;
	else
		return 1;
}

static int linux_force_free(struct usb_transfer *t)
{
	struct linux_transfer_priv *tpriv ;

	if (!t)
		return 0;

	tpriv = t->os_priv;
	free(tpriv->urbs);
	return 0;
}

struct sys_device_ops linux_device_ops = {
	linux_dev_init,
	linux_dev_release,
	linux_open,
	linux_close,
	linux_get_config,
	linux_set_config,
	linux_claim_intfc,
	linux_release_intfc,
	linux_submit_transfer,
	linux_asyn_reap,
	linux_cancel_transfer,
	linux_ioctl,
	linux_force_free,
	linux_free_check,
	0,
	sizeof(struct linux_transfer_priv),
};
