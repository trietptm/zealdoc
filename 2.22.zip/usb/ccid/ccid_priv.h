#ifndef  __CCID_PRIV_H__
#define	 __CCID_PRIV_H__

#include <sysdep.h>
#include <logger.h>
#include <panic.h>
#include <module.h>
#include <strutl.h>
#include <dfastm.h>
#include <eloop.h>
#include <usb.h>
#include <ccid.h>

/*Logging operations*/
#define CCID_LOG_CRIT	LOG_EMERG
#define CCID_LOG_FAIL	LOG_CRIT
#define CCID_LOG_ERR	LOG_ERR
#define CCID_LOG_WARN	LOG_WARNING
#define CCID_LOG_INFO	LOG_INFO
#define CCID_LOG_DEBUG	LOG_DEBUG

void ccid_log(int level, const char *format, ...);

#define CCID_PARAM_TYPE_GET_SLOT_STATUS		0x01
#define CCID_PARAM_TYPE_POWERON			0x02
#define CCID_PARAM_TYPE_POWEROFF		0x03
#define CCID_PARAM_TYPE_XFR			0x04
#define CCID_PARAM_TYPE_SECURE			0x05
#define CCID_PARAM_TYPE_CTRL			0x06

enum ccid_bulk_cmd {
	/* bulk out */
	PC_TO_RDR_SETPARAMETERS		= 0x61,
	PC_TO_RDR_ICCPOWERON		= 0x62,
	PC_TO_RDR_ICCPOWEROFF		= 0x63,
	PC_TO_RDR_GETSLOTSTATUS		= 0x65,
	PC_TO_RDR_SECURE		= 0x69,
	PC_TO_RDR_T0APDU		= 0x6A,
	PC_TO_RDR_ESCAPE		= 0x6B,
	PC_TO_RDR_GETPARAMETERS		= 0x6C,
	PC_TO_RDR_RESETPARAMETERS	= 0x6D,
	PC_TO_RDR_ICCCLOCK		= 0x6E,
	PC_TO_RDR_XFRBLOCK		= 0x6F,
	PC_TO_RDR_MECHANICAL		= 0x71,
	PC_TO_RDR_ABORT			= 0x72,
	PC_TO_RDR_SETDATARATEANDCLOCK	= 0x73,
	/* bulk in */
	RDR_TO_PC_DATABLOCK		= 0x80,
	RDR_TO_PC_SLOTSTATUS		= 0x81,	
	RDR_TO_PC_PARAMETERS		= 0x82,	
	RDR_TO_PC_ESCAPE		= 0x83,	
	RDR_TO_PC_DATARATEANDCLOCKFREQUENCY	= 0x84,	
};

enum CCID_CONTROL_REQUEST {
	ICC_POWER_ON		= 0x62,
	ICC_POWER_OFF		= 0x63,
	XFR_BLOCK		= 0x65,
	DATA_BLOCK		= 0x6F,
	GET_ICC_STATUS		= 0xA0,/*control A*/
	SLOT_STATUS		= 0x81,/*control B*/
};

enum level_param_ext_apdu {
	EXT_APDU_LEVEL_SHORT	= 0x0000,
	EXT_APDU_LEVEL_BEGIN	= 0x0001,
	EXT_APDU_LEVEL_END	= 0x0002,
	EXT_APDU_LEVEL_MID	= 0x0003,
	EXT_APDU_LEVEL_EMPTY	= 0x0010,
};

enum chain_param {
	CHAIN_PARAM_SHORT	= 0x00,
	CHAIN_PARAM_FIRST	= 0x01,
	CHAIN_PARAM_LAST	= 0x02,
	CHAIN_PARAM_MID		= 0x03,
	CHAIN_PARAM_EMPTY	= 0x10,
};

enum reap_status_offset {
	CCID_OFFSET_STATUS		= 7,
	CCID_OFFSET_ERROR		= 8,
	CCID_OFFSET_CHAIN_PARAMETER	= 9,
};

enum ccid_icc_status {
	CCID_ICC_STATUS_PRESENT_ACTIVE	= 0x00,
	CCID_ICC_STATUS_PRESENT_DEACTIVE= 0x01,
	CCID_ICC_STATUS_ABSENT		= 0x02,
	CCID_ICC_STATUS_MASK		= 0x03,
};

enum ccid_cmd_status {
	CCID_CMD_STATUS_SUCCESS		= 0x00,
	CCID_CMD_STATUS_FAILED		= 0x40,
	CCID_CMD_STATUS_TIME_EXT	= 0x80,
	CCID_CMD_STATUS_MASK		= 0xC0,
};

enum ccid_transfer_error {
	CCID_TRANS_ERR_CMD_ABORTED	= 0xFF,
	CCID_TRANS_ERR_ICC_MUTE		= 0xFE,
	CCID_TRANS_ERR_XFR_PARITY	= 0xFD,
	CCID_TRANS_ERR_XFR_OVERRUN	= 0xFC,
	CCID_TRANS_ERR_HW		= 0xFB,
	CCID_TRANS_ERR_BAD_ATR_TS	= 0xF8,
	CCID_TRANS_ERR_BAD_ATR_TCK	= 0xF7,
	CCID_TRANS_ERR_ICC_PROT_NOSUP	= 0xF6,/* ICC Protocol not supported */
	CCID_TRANS_ERR_ICC_CLASS_NOSUP	= 0xF5,/* ICC Class not supported */
	CCID_TRANS_ERR_BAD_PROC_BYTE	= 0xF4,/* Procedure byte conflict*/
	CCID_TRANS_ERR_DEACTIVATED_PROT	= 0xF3,
	CCID_TRANS_ERR_BUSY_AUTO_SEQ	= 0xF2,
	CCID_TRANS_ERR_PIN_TIMEOUT	= 0xF0,
	CCID_TRANS_ERR_PIN_CANCELLED	= 0xEF,
	CCID_TRANS_ERR_SLOT_BUSY	= 0xE0,
	CCID_TRANS_ERR_MSG_TYPE		= 0x00,/* cmd not supported */
	CCID_TRANS_ERR_SLOT		= 0x05,/* invalid slot */
};

enum ccid_transfer_state {
	IDLE		= 0x00,
	SENDING		= 0x01,
	RECEIVING	= 0x02,
	CONFUSED	= 0x03
};

typedef struct ccid_trans_param {
	int reader_idx;
	
	const uint8_t *sbuf;
	size_t sbuf_len;

	uint8_t *rbuf;
	size_t rbuf_len;
	size_t rbuf_actual;
	uint8_t card_status;
	int ret;
	
	ccid_trans_param_comp callback;
	void *user_data;

	int type;	/* param type for complete action */
} ccid_trans_param_t;

typedef void (*ccid_transfer_complete)(struct ccid_trans_param *ccid_trans);

typedef struct ccid_transfer {
	char *name;

	ccid_reader_t *handle;
	uint32_t protocol;
	const struct timeval *timeout;
	uint8_t state;

	uint8_t cmd_in; /*card --> host*/
	uint8_t cmd_out;/*host --> card*/

	uint8_t cmd_buf [10 + CMD_BUF_SIZE];
	size_t cmd_buf_len;
	size_t cmd_buf_actual;

	/* Support Extended APDU*/
	uint16_t wLevelParameter;
	uint8_t bChainParameter;
	size_t sbuf_transmited;

	ccid_transfer_complete callback;
	struct ccid_trans_param *param;

	uint8_t bmICCStatus;
	uint8_t bmCommandStatus;
	uint8_t bError;
} ccid_trans_t;

/* Protocol T0*/
int ccid_send_xfr_transfer_t0(struct ccid_transfer *ccid_trans);

/* trans param can free directly, no need a API */
void ccid_destroy_trans(ccid_trans_t *);
ccid_trans_t *ccid_build_trans(uint8_t cmd_out, uint8_t cmd_in,
			       const char *name, ccid_reader_t *handle,
			       ccid_transfer_complete cb, ccid_trans_param_t *param);
ccid_trans_param_t *ccid_build_trans_param(const uint8_t *sbuf, int slen, 
				       uint8_t *rbuf, int rlen,
				       ccid_trans_param_comp cb, void *user_data,
				       int param_type);


int ccid_fill_cmd(struct ccid_transfer *ccid_trans);
int ccid_fill_xfr_cmd_t0(struct ccid_transfer *ccid_trans);

int ccid_send_transfer(struct ccid_transfer *ccid_trans);
int ccid_reap_transfer(struct ccid_transfer *ccid_trans);
void ccid_parse_reap(struct ccid_transfer *ccid_trans);


int ccid_tool_open(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int ccid_tool_close(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int ccid_tool_poweron(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int ccid_tool_poweroff(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int ccid_tool_icc_status(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int ccid_tool_list(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int ccid_tool_select(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int ccid_tool_get_config(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);



int ccid_parse_ccid_descriptor(const uint8_t *src, size_t len,
			       struct ccid_descriptor *ccid_desc);

/* reader manager(USB -> ccid_usb.c) will trigger these,
 * @hd store manager data.
 */
ccid_reader_t *
ccid_reader_open(int type, const char *rdr_name, void *hd);
void ccid_reader_close(int type, const char *name, void *hd);

/* name form original STM */
int ccid_cmd_submit(struct ccid_transfer *);
int ccid_cmd_ctr(struct ccid_transfer *);
int ccid_cmd_rtr(struct ccid_transfer *);
int ccid_cmd_etc(struct ccid_transfer *);

void ccid_common_trans_cb(ccid_trans_param_t *ccid_param);

#endif /*__CCID_PRIV_H__*/
