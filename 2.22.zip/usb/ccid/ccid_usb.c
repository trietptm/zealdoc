#include "ccid_usb.h"
#include <pcsc.h>

#define CCID_SHOW	CCID_LOG_ERR
//#define CCID_SHOW	CCID_LOG_INFO

uint16_t ccid_usb_dev_idVendor(ccid_reader_t *rdr)
{
	usb_intfc_t *intfc = (usb_intfc_t *)rdr->upper;
	return intfc->dev->dev_desc->idVendor;
}

uint16_t ccid_usb_dev_idProduct(ccid_reader_t *rdr)
{
	usb_intfc_t *intfc = (usb_intfc_t *)rdr->upper;
	return intfc->dev->dev_desc->idProduct;
}

static int ccid_usb_claim_intfc(usb_intfc_t *intfc)
{
	return usb_claim_interface(intfc);
}

static void ccid_usb_release_intfc(usb_intfc_t *intfc)
{
	usb_release_interface(intfc, 
		intfc->cur_altsetting->bInterfaceNumber);
}

static int ccid_usb_set_config(usb_intfc_t *intfc)
{
	uint8_t active_config = intfc->dev->active_config;
	return usb_set_configuration(intfc, active_config);
}

static int ccid_usb_get_endpoints(usb_device_t *usb_dev, usb_intfc_desc_t *altsetting)
{
	/* SPEC 4.3 */
	if (altsetting->bInterfaceProtocol != 0x00)
		return -1;

	usb_get_endpoints(usb_dev, altsetting);
	return CCID_SUCCESS;
}

static void __i2dw(int value, unsigned char buffer[])
{
	buffer[0] = value & 0xFF;
	buffer[1] = (value >> 8) & 0xFF;
	buffer[2] = (value >> 16) & 0xFF;
	buffer[3] = (value >> 24) & 0xFF;
}

static int __select_voltage(ccid_reader_t *rdr, uint8_t *voltage)
{
	/* FIXME: how to comfirm the voltage ? 
	 * ccid->desc->bVoltageSupported ? */
	*voltage = CCID_VOLTAGE_5V;

	return CCID_SUCCESS;
}

/* ============================================================ *
 * fill command routine
 * ============================================================ */
static int usb_fill_xfrblock(uint8_t *cmd_buf, size_t dwLength, 
			     uint8_t bSlot, uint8_t bSeq, 
			     uint16_t wLevelParameter, const uint8_t *data)
{
	cmd_buf[0] = PC_TO_RDR_XFRBLOCK;
	__i2dw(dwLength, cmd_buf + 1);
	cmd_buf[5] = bSlot;
	cmd_buf[6] = bSeq;
	cmd_buf[7] = 0x00;
	cmd_buf[8] = wLevelParameter & 0xFF;
	cmd_buf[9] = (wLevelParameter >> 8) & 0xFF;
	memcpy(cmd_buf + 10, data, dwLength);
	
	return CCID_SUCCESS;
}

static int usb_fill_poweron(uint8_t *cmd_buf,uint8_t bSlot, 
			    uint8_t bSeq, uint8_t bPowerSelect)
{
	cmd_buf[0] = PC_TO_RDR_ICCPOWERON;
	cmd_buf[1] = 0x00;
	cmd_buf[2] = 0x00;
	cmd_buf[3] = 0x00;
	cmd_buf[4] = 0x00;
	cmd_buf[5] = bSlot;
	cmd_buf[6] = bSeq;
	cmd_buf[7] = bPowerSelect;
	cmd_buf[8] = 0x00;
	cmd_buf[9] = 0x00;
	
	return CCID_SUCCESS;
}

static int usb_fill_poweroff(uint8_t *cmd_buf, uint8_t bSlot, uint8_t bSeq)
{
	cmd_buf[0] = PC_TO_RDR_ICCPOWEROFF;
	cmd_buf[1] = 0x00;
	cmd_buf[2] = 0x00;
	cmd_buf[3] = 0x00;
	cmd_buf[4] = 0x00;
	cmd_buf[5] = bSlot;
	cmd_buf[6] = bSeq;
	cmd_buf[7] = 0x00;
	cmd_buf[8] = 0x00;
	cmd_buf[9] = 0x00;
	
	return CCID_SUCCESS;
}

static int usb_fill_getslotstatus(uint8_t *cmd_buf, uint8_t bSlot,
			          uint8_t bSeq)
{
	cmd_buf[0] = PC_TO_RDR_GETSLOTSTATUS;
	cmd_buf[1] = 0x00;
	cmd_buf[2] = 0x00;
	cmd_buf[3] = 0x00;
	cmd_buf[4] = 0x00;
	cmd_buf[5] = bSlot;
	cmd_buf[6] = bSeq;
	cmd_buf[7] = 0x00;
	cmd_buf[8] = 0x00;
	cmd_buf[9] = 0x00;
	
	return CCID_SUCCESS;
}

static int usb_fill_secure(uint8_t *cmd_buf, size_t dwLength, 
			   uint8_t bSlot, uint8_t bSeq, 
			   uint16_t wLevelParameter, const uint8_t *data)
{
	cmd_buf[0] = PC_TO_RDR_SECURE;
	__i2dw(dwLength, cmd_buf + 1);
	cmd_buf[5] = bSlot;
	cmd_buf[6] = bSeq;
	cmd_buf[7] = 0x00;
	cmd_buf[8] = wLevelParameter & 0xFF;
	cmd_buf[9] = (wLevelParameter >> 8) & 0xFF;
	memcpy(cmd_buf + 10, data, dwLength);
	
	return CCID_SUCCESS;
}

static int usb_fill_bulk_cmd(struct ccid_transfer *ccid_trans)
{
	size_t max_len;
	struct ccid_descriptor *ccid_desp;
	uint8_t voltage;
	
	ccid_desp = &ccid_trans->handle->ccid_desc;

	/* FIXME: It should check the len before alloc transfer. */
	max_len = (ccid_desp->dwMaxCCIDMessageLength - 10) < CMD_BUF_SIZE ?
		  (ccid_desp->dwMaxCCIDMessageLength - 10) : CMD_BUF_SIZE;
	memset(ccid_trans->cmd_buf, 0, sizeof(ccid_trans->cmd_buf));
	switch (ccid_trans->cmd_out) {
	case PC_TO_RDR_XFRBLOCK:
		if (ccid_trans->param->sbuf_len > max_len)
			return CCID_ERROR_COMMUNICATION;
		
		usb_fill_xfrblock(ccid_trans->cmd_buf, 
			ccid_trans->param->sbuf_len, 
			ccid_trans->handle->bslot, (ccid_trans->handle->bseq)++,
			ccid_trans->wLevelParameter, 
			ccid_trans->param->sbuf);
		ccid_trans->cmd_buf_len = 10 + ccid_trans->param->sbuf_len;
		break;
	case PC_TO_RDR_ICCPOWERON:
		__select_voltage(ccid_trans->handle, &voltage);
		usb_fill_poweron(ccid_trans->cmd_buf, 
				 ccid_trans->handle->bslot, 
				 (ccid_trans->handle->bseq)++, voltage);
		ccid_trans->cmd_buf_len = 10;
		break;
	case PC_TO_RDR_ICCPOWEROFF:
		usb_fill_poweroff(ccid_trans->cmd_buf, 
				  ccid_trans->handle->bslot,
				  (ccid_trans->handle->bseq)++);
		ccid_trans->cmd_buf_len = 10;
		break;
	case PC_TO_RDR_GETSLOTSTATUS:
		usb_fill_getslotstatus(ccid_trans->cmd_buf, 
				       ccid_trans->handle->bslot,
				       (ccid_trans->handle->bseq)++);
		ccid_trans->cmd_buf_len = 10;
		break;
	case PC_TO_RDR_SECURE:
		usb_fill_secure(ccid_trans->cmd_buf,
				ccid_trans->param->sbuf_len,
				ccid_trans->handle->bslot,
				(ccid_trans->handle->bseq)++,
				ccid_trans->wLevelParameter,
				ccid_trans->param->sbuf);
		ccid_trans->cmd_buf_len = 10 + ccid_trans->param->sbuf_len;
		break;
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}

	return CCID_SUCCESS;
}

int ccid_usb_fill_cmd(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->handle->intfc_proto) {
	case CCID_INTFC_PROTO_BULK:
		return usb_fill_bulk_cmd(ccid_trans);
	case CCID_INTFC_PROTO_CTRL_A:
	case CCID_INTFC_PROTO_CTRL_B:
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}
int ccid_usb_fill_control(uint8_t request_class, uint8_t request, 
			  uint8_t *data, size_t data_len,
			  struct ccid_usb_control_param *control_param)
{
	switch (request_class) {
	case USB_REQUEST_TYPE_STANDARD:
		control_param->bmRequestType = USB_REQUEST_TYPE_STANDARD;
		switch (request){
		case USB_REQUEST_GET_CONFIGURATION:
			if (data_len != 1)
				return CCID_ERROR_INVALID_ARG;
			control_param->bmRequestType |= 
				USB_ENDPOINT_IN | USB_RECIPIENT_DEVICE;
			control_param->bRequest = USB_REQUEST_GET_CONFIGURATION;
			control_param->wValue = 0x0000;
			control_param->wIndex = 0x0000;
			control_param->wLength = 0x0001;
			control_param->data = data;
			break;
		default:
			return CCID_ERROR_NOT_SUPPORTED;
		}
		break;
	case USB_REQUEST_TYPE_CLASS:
		return CCID_ERROR_NOT_SUPPORTED;
	case USB_REQUEST_TYPE_VENDOR:
		return CCID_ERROR_NOT_SUPPORTED;
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}

	return CCID_SUCCESS;
}

static struct usb_trans_params *
__build_usb_param(usb_intfc_t *dev_handle, 
		  uint8_t *buf, size_t buf_len,
		  uint8_t ep, void *user_data)
{
	struct usb_trans_params *usb_param;
	
	usb_param = malloc(sizeof(struct usb_trans_params));
	if (!usb_param)
		return NULL;

	memset(usb_param, 0, sizeof(struct usb_trans_params));
	
	usb_param->dev_handle = dev_handle;
	usb_param->buf = buf;
	usb_param->buf_len = buf_len;
	usb_param->ep = ep;
	usb_param->user_data = user_data;

	return usb_param;
}

static void usb_bulk_write_callback(struct usb_trans_params *usb_param)
{
	struct ccid_transfer *ccid_trans = 
			(struct ccid_transfer *)usb_param->user_data;

	switch (usb_param->ret) {
	case USB_SUCCESS:
		ccid_trans->param->ret = CCID_SUCCESS;
		break;
	case USB_ERROR_PIPE:
		ccid_trans->param->ret = CCID_ERROR_STALL;
		break;
	case USB_ERROR_NO_DEVICE:
		ccid_trans->param->ret = CCID_ERROR_NO_DEVICE;
		break;
	case USB_ERROR_TIMEOUT:
		ccid_trans->param->ret = CCID_ERROR_TIMEOUT;
		break;
	case USB_ERROR_CANCELLED:
		ccid_trans->param->ret = CCID_ERROR_CANCELLED;
		break;
	case USB_ERROR_OVERFLOW:
		ccid_trans->param->ret = CCID_ERROR_OVERFLOW;
		break;
	default:
		ccid_trans->param->ret = CCID_ERROR_GENERIC;
		break;
	}
	if (usb_param->ret ==  USB_SUCCESS)
		ccid_cmd_rtr(ccid_trans);
	else
		ccid_cmd_etc(ccid_trans);
	free(usb_param);
}

static int ccid_usb_bulk_write(struct ccid_transfer *ccid_trans)
{
	struct usb_trans_params *usb_param;
	int r;
	char out_debug[(10 + CMD_BUF_SIZE) * 3];
	size_t i;
	
	usb_param = __build_usb_param(ccid_trans->handle->upper,
				      ccid_trans->cmd_buf, ccid_trans->cmd_buf_len,
				      ((usb_intfc_t *)ccid_trans->handle->upper)->dev->ep_o,
				      ccid_trans);
	if (!usb_param)
		return CCID_ERROR_GENERIC;

	memset(out_debug, 0, sizeof(out_debug));
	for (i = 0; i < usb_param->buf_len; i++) {
		sprintf(out_debug + 3 * i, "%02X ", usb_param->buf[i]);
	}
	ccid_log(CCID_SHOW, "---> %s", out_debug);

	r = usb_bulk_write(usb_param, usb_bulk_write_callback);
	if (r != USB_SUCCESS) {
		free(usb_param);
		return CCID_ERROR_GENERIC;
	}
	return CCID_SUCCESS;
}

static void usb_bulk_read_callback(struct usb_trans_params *usb_param)
{
	struct ccid_transfer *ccid_trans = 
			(struct ccid_transfer *)usb_param->user_data;
	char out_debug[(10 + CMD_BUF_SIZE) * 3];
	size_t i;

	switch (usb_param->ret) {
	case USB_SUCCESS:
		memset(out_debug, 0, sizeof(out_debug));
		for (i = 0; i < usb_param->rbuf_actual; i++) {
			sprintf(out_debug + 3 * i, "%02X ", usb_param->buf[i]);
		}
		ccid_log(CCID_SHOW, "<--- %s", out_debug);
		
		ccid_trans->cmd_buf_actual += usb_param->rbuf_actual;
		ccid_trans->param->ret = CCID_SUCCESS;
		break;
	case USB_ERROR_PIPE:
		ccid_trans->param->ret = CCID_ERROR_STALL;
		break;
	case USB_ERROR_NO_DEVICE:
		ccid_trans->param->ret = CCID_ERROR_NO_DEVICE;
		break;
	case USB_ERROR_TIMEOUT:
		ccid_trans->param->ret = CCID_ERROR_TIMEOUT;
		break;
	case USB_ERROR_CANCELLED:
		ccid_trans->param->ret = CCID_ERROR_CANCELLED;
		break;
	case USB_ERROR_OVERFLOW:
		ccid_trans->param->ret = CCID_ERROR_OVERFLOW;
		break;
	default:
		ccid_trans->param->ret = CCID_ERROR_GENERIC;
		break;
	}

	if (usb_param->ret ==  USB_SUCCESS)
		ccid_cmd_ctr(ccid_trans);
	else
		ccid_cmd_etc(ccid_trans);
	free(usb_param);
}

static int ccid_usb_bulk_read(struct ccid_transfer *ccid_trans)
{
	struct usb_trans_params *usb_param;
	int r;
	
	usb_param = __build_usb_param(ccid_trans->handle->upper,
				      ccid_trans->cmd_buf, sizeof(ccid_trans->cmd_buf),
				      ((usb_intfc_t *)ccid_trans->handle->upper)->dev->ep_i,
				      ccid_trans);
	if (!usb_param)
		return CCID_ERROR_GENERIC;

	r = usb_bulk_read(usb_param, usb_bulk_read_callback);
	if (r != USB_SUCCESS) {
		free(usb_param);
		return CCID_ERROR_GENERIC;
	}
	return CCID_SUCCESS;
}

int ccid_usb_send_transfer(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->handle->intfc_proto) {
	case CCID_INTFC_PROTO_BULK:
		return ccid_usb_bulk_write(ccid_trans);
	case CCID_INTFC_PROTO_CTRL_A:
	case CCID_INTFC_PROTO_CTRL_B:
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}

int ccid_usb_reap_transfer(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->handle->intfc_proto) {
	case CCID_INTFC_PROTO_BULK:
		return ccid_usb_bulk_read(ccid_trans);
	case CCID_INTFC_PROTO_CTRL_A:
	case CCID_INTFC_PROTO_CTRL_B:
		return CCID_ERROR_NOT_SUPPORTED;
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}



static void control_trans_callback(struct usb_trans_params *usb_param)
{
	struct ccid_usb_control_param *control_param = usb_param->user_data;
	struct ccid_trans_param *ccid_param = 
			(struct ccid_trans_param *)control_param->user_data;

	if (usb_param->ret == USB_SUCCESS) {
		ccid_param->ret = CCID_SUCCESS;
		memcpy(control_param->data, 
			usb_param->buf + sizeof(struct usb_control_setup),
			usb_param->buf_len - sizeof(struct usb_control_setup));
	} else {
		ccid_param->ret = CCID_ERROR_COMMUNICATION;
	}

	control_param->callback(ccid_param);

	free(control_param);
	free(usb_param->buf);
	free(usb_param);
}

int ccid_usb_control_transfer(usb_intfc_t *intfc, 
			      struct ccid_usb_control_param *control_param)
{

	struct usb_control_setup *setup;
	struct usb_trans_params *usb_param;
	uint8_t *cmd_buf;
	size_t cmd_len;
	int r;

	cmd_len = sizeof(struct usb_control_setup) + control_param->wLength;
	cmd_buf = malloc(cmd_len);
	if (!cmd_buf)
		return CCID_ERROR_NO_MEM;
	memset(cmd_buf, 0, cmd_len);

	setup = (struct usb_control_setup *)cmd_buf;
	setup->bmRequestType = control_param->bmRequestType;
	setup->bRequest = control_param->bRequest;
	setup->wValue = usb_cpu_to_le16(control_param->wValue);
	setup->wIndex = usb_cpu_to_le16(control_param->wIndex);
	setup->wLength = usb_cpu_to_le16(control_param->wLength);
	if (control_param->wLength)
		memcpy(setup->data, control_param->data, control_param->wLength);

	usb_param = __build_usb_param(intfc,
				      cmd_buf, cmd_len,
				      USB_ENDPOINT_CONTROL,
				      control_param);
	if (!usb_param) {
		free(cmd_buf);
		return USB_ERROR_NO_MEM;
	}
	
	r = usb_control_transfer(usb_param, control_trans_callback);
	if (r != USB_SUCCESS) {
		free(cmd_buf);
		free(usb_param);
	}

	return r;
}

int ccid_usb_cancel(ccid_reader_t *hccid)
{
	usb_intfc_discard_trans(hccid->upper);
	return CCID_SUCCESS;
}

int ccid_usb_claim(ccid_reader_t *rdr)
{
	struct usb_interface_descriptor *altsetting;
	usb_intfc_t *intfc;
	int r;
	
	intfc = (usb_intfc_t *)rdr->upper;

	BUG_ON(!intfc || !intfc->cur_altsetting);

	usb_device_open(intfc);

	if (intfc->fd < 0)
		return CCID_ERROR_NO_DEVICE;

	altsetting = intfc->cur_altsetting;

	r = ccid_parse_ccid_descriptor(altsetting->extra, 
			altsetting->extra_length,
			&rdr->ccid_desc);
	if (r != 0)
		return CCID_ERROR_NO_DEVICE;

	/* Don't touch the device configuration if it's the one and only.
	 * The reason for this is that in multi purpose devices(e.g. keyboards,
	 * with and integrated reader) some interfaces might already be in use.
	 * Trying to change the device configuration in such a case will 
	 * produce this kernel message on Linux:
	 *	usbfs: interface X claimed while 'ifdhandler' sets config #N
	 *
	 * FIXME: On windows, you should first set config before claim intfc.
	 */
#ifdef WIN32
	/* FIXME: get the value */
	r = ccid_usb_set_config(intfc);
	if (r != USB_SUCCESS)
		return r;
#endif

	switch (altsetting->bInterfaceProtocol) {
	case 0x00:
		rdr->intfc_proto = CCID_INTFC_PROTO_BULK;
		r = ccid_usb_get_endpoints(intfc->dev, altsetting);
		break;
	case 0x01:
		rdr->intfc_proto = CCID_INTFC_PROTO_CTRL_A;
		break;
	case 0x02:
		rdr->intfc_proto = CCID_INTFC_PROTO_CTRL_B;
		break;
	default:
		r = CCID_ERROR_NOT_SUPPORTED;
		break;
	}

	/* can do this at last ? */
	r = ccid_usb_claim_intfc(intfc);
	if (r != USB_SUCCESS) {
		ccid_log(CCID_LOG_ERR, 
			"CCID: cannot claim intfc=%s/%d",
			 intfc->dev->filename, r);
		return r;
	}
	return CCID_SUCCESS;
}

int ccid_usb_release(ccid_reader_t *rdr)
{
	usb_intfc_t *intfc;
	
	intfc = (usb_intfc_t *)rdr->upper;
	
	ccid_usb_release_intfc(intfc);

	usb_device_close(intfc);
	return CCID_SUCCESS;
}

/* @intfc: ccid interface */
/* USB manager give our needed interface(class == 0x0Bh)
 * when a reader comes up.
 */
static int ccid_usb_open(usb_intfc_t *intfc)
{
	if (ccid_reader_open(CCID_DEVICE_TYPE_USB,
			     intfc->dev->filename, intfc)) {
		return 0;
	}
	/* failure */
	return 1;
}

static void ccid_usb_close(usb_intfc_t *intfc)
{
	ccid_log(CCID_LOG_DEBUG, "USB: remove CCID, ifnum=%d",
			intfc->cur_altsetting->bInterfaceNumber);

	ccid_reader_close(CCID_DEVICE_TYPE_USB, intfc->dev->filename, intfc);	
	usb_intfc_down(intfc);
}

/* soliton ccid driver match id table */
#define CCID_MATCH_ID_FLAGS	\
		(USB_DEVICE_ID_MATCH_INT_CLASS | \
		 USB_DEVICE_ID_MATCH_INT_SUBCLASS | \
		 USB_DEVICE_ID_MATCH_INT_PROTOCOL)

static usb_dev_id_t ccid_id_table[] = {
	{
		CCID_MATCH_ID_FLAGS,
		0,	/* idVendor */
		0,	/* idProduct */
		0,	/* bcdDevice_lo */
		0,	/* bcdDevice_hi */
			
		0,	/* bDeviceClass */
		0,	/* bDeviceSubClass */
		0,	/* bDeviceProtocol */
			
		0x0b,	/* bInterfaceClass: Smart Card Device Class */
		0,	/* bInterfaceSubClass */
		0,	/* bInterfaceProtocol: CCID; */
			
		0,	/* driver_info; */
	},

	{0}		/* terminating entry */
};

static usb_driver_t ccid_usb_driver = {
	"ccid",
	ccid_usb_open,	/* ccid usb interface come up */
	ccid_usb_close,
	ccid_id_table,
};

int ccid_register_usb_driver(void)
{
	usb_register_driver(&ccid_usb_driver);
	return 0;
}

void ccid_unregister_usb_driver(void)
{
	usb_unregister_driver(&ccid_usb_driver);
}


