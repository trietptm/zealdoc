#include "ccid_priv.h"
#include "ccid_usb.h"

static struct ccid_transfer *ccid_alloc_transfer(uint8_t cmd_out, uint8_t cmd_in);
static void ccid_free_transfer_delay(void *eloop, void *user_ctx);
static void ccid_cmd_rtr_delay(void *eloop, void *user_ctx);
static void ccid_do_rtr_delay(struct ccid_transfer *ccid_trans);
static void ccid_free_transfer(struct ccid_transfer *ccid_trans);
static void ccid_parse_rdr_to_pc_datablock(struct ccid_transfer *ccid_trans);
static void ccid_parse_rdr_to_pc_slotstatus(struct ccid_transfer *ccid_trans);
static void ccid_parse_bulk_reap(struct ccid_transfer *ccid_trans);
static int ccid_fill_xfr_cmd(struct ccid_transfer *ccid_trans);
static int ccid_fill_ctrl_cmd(struct ccid_transfer *ccid_trans);
static int ccid_check_response(const char *cmb_buf);


static void ccid_free_transfer_delay(void *eloop, void *user_ctx) 
{
	ccid_free_transfer((struct ccid_transfer *)user_ctx);
}

static void ccid_cmd_rtr_delay(void *eloop, void *user_ctx)
{
	struct ccid_transfer *ccid_trans = (struct ccid_transfer *)user_ctx;
	ccid_cmd_rtr(ccid_trans);
}

static void ccid_do_rtr_delay(struct ccid_transfer *ccid_trans) 
{
	eloop_register_timeout(NULL, 0, 0, ccid_cmd_rtr_delay, NULL, ccid_trans);
}

/* exit transfer context */
int ccid_cmd_etc(struct ccid_transfer *c)
{
	c->callback(c->param);
	eloop_register_timeout(NULL, 0, 0, ccid_free_transfer_delay, NULL, c);
	return 0;
}

/* read transfer response */
int ccid_cmd_rtr(struct ccid_transfer *ccid_trans)
{
	int r = ccid_reap_transfer(ccid_trans);
	if (r != CCID_SUCCESS) {
		ccid_trans->param->ret = r;
		ccid_cmd_etc(ccid_trans);
	}
	return r;
}

/* check transfer response */
int ccid_cmd_ctr(struct ccid_transfer *ccid_trans)
{
	ccid_parse_reap(ccid_trans);

	switch (ccid_trans->param->ret) {
	case CCID_TIME_EXTENSION:
		ccid_do_rtr_delay(ccid_trans);
		break;
	case CCID_SUCCESS:
	default:
		ccid_log(CCID_LOG_DEBUG, "CMD: ctr param ret=%d", ccid_trans->param->ret);
		ccid_cmd_etc(ccid_trans);
		break;
	}
	return 1;
}

/* submit transfer */
int ccid_cmd_submit(struct ccid_transfer *ccid_trans)
{
	int r = ccid_send_transfer(ccid_trans);

	if (r != CCID_SUCCESS) {
		ccid_trans->param->ret = r;
		ccid_cmd_etc(ccid_trans);
	}

	return r;	
}

static struct ccid_transfer *ccid_alloc_transfer(uint8_t cmd_out, uint8_t cmd_in)
{
	struct ccid_transfer *ccid_trans = NULL;

	ccid_trans = malloc(sizeof(*ccid_trans));
	if (!ccid_trans)
		return NULL;
	memset(ccid_trans, 0, sizeof(*ccid_trans));
	ccid_trans->state = IDLE;
	ccid_trans->cmd_out = cmd_out;
	ccid_trans->cmd_in = cmd_in;
	ccid_trans->wLevelParameter = EXT_APDU_LEVEL_SHORT;
	ccid_trans->bChainParameter = CHAIN_PARAM_SHORT;
	
	return ccid_trans;
}

static void ccid_free_transfer(struct ccid_transfer *ccid_trans)
{
	if (!ccid_trans)
		return;
	if (ccid_trans->name)
		free(ccid_trans->name);
	free(ccid_trans);
}

static int ccid_fill_xfr_cmd(struct ccid_transfer *ccid_trans)
{
	struct ccid_descriptor *ccid_desp;
	
	ccid_desp = &ccid_trans->handle->ccid_desc;

	switch (ccid_desp->dwFeatures & CCID_CLASS_EXCHANGE_MASK) {
	case CCID_CLASS_CHARACTER:
		return CCID_ERROR_NOT_SUPPORTED;
	case CCID_CLASS_TPDU:
		if (ccid_trans->protocol == CCID_PROTOCOL_T0) {
			return ccid_fill_xfr_cmd_t0(ccid_trans);
		} else if (ccid_trans->protocol == CCID_PROTOCOL_T1) {
			return CCID_ERROR_NOT_SUPPORTED;
		} else {
			return CCID_ERROR_NOT_SUPPORTED;
		}
	case CCID_CLASS_SHORT_APDU:
		return ccid_fill_xfr_cmd_t0(ccid_trans);
	case CCID_CLASS_EXTENDED_APDU:
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}	
}

static int ccid_fill_ctrl_cmd(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->handle->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		return ccid_usb_fill_cmd(ccid_trans);
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}

int ccid_fill_cmd(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->cmd_out) {
	case PC_TO_RDR_XFRBLOCK:
		return ccid_fill_xfr_cmd(ccid_trans);
	case PC_TO_RDR_ICCPOWERON:
	case PC_TO_RDR_ICCPOWEROFF:
	case PC_TO_RDR_GETSLOTSTATUS:
	case PC_TO_RDR_SECURE:
		return ccid_fill_ctrl_cmd(ccid_trans);
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}

int ccid_send_transfer(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->handle->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		return ccid_usb_send_transfer(ccid_trans);
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}

int ccid_reap_transfer(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->handle->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		return ccid_usb_reap_transfer(ccid_trans);
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}

static void ccid_parse_rdr_to_pc_datablock(struct ccid_transfer *ccid_trans)
{
	struct ccid_trans_param *param = ccid_trans->param;
	uint32_t data_len;

	switch (ccid_trans->param->ret) {
	case CCID_SUCCESS:
		data_len = dw2i(ccid_trans->cmd_buf, 1);
		param->rbuf_actual = (data_len > param->rbuf_len) 
					? param->rbuf_len : data_len;		
		memcpy(param->rbuf, ccid_trans->cmd_buf + 10, 
		       param->rbuf_actual);
		return;
	case CCID_ERROR_USER_ABORT:
		if (param->rbuf_len < 2) {
			param->ret = CCID_ERROR_OVERFLOW;
		} else {
			param->rbuf[0] = 0x64;
			param->rbuf[1] = 0x01;
			param->rbuf_actual = 2;
		}
		return;
	case CCID_ERROR_USER_TIMEOUT:
		if (param->rbuf_len < 2) {
			param->ret = CCID_ERROR_OVERFLOW;
		} else {
			param->rbuf[0] = 0x64;
			param->rbuf[1] = 0x00;
			param->rbuf_actual = 2;
		}
		return;
	default:
		return;
	}
}

static void ccid_parse_rdr_to_pc_slotstatus(struct ccid_transfer *ccid_trans)
{
	uint8_t icc_status;

	icc_status = ccid_trans->cmd_buf[CCID_OFFSET_STATUS] & CCID_ICC_STATUS_MASK;

	switch (ccid_trans->param->ret) {
	case CCID_ERROR_NO_CARD:
	case CCID_SUCCESS:
		switch (icc_status) {
		case CCID_ICC_STATUS_PRESENT_ACTIVE:
			ccid_trans->param->card_status =
				ccid_trans->handle->card_status = 
				CCID_CARD_PRESENT_ACTIVE;
			return;
		case CCID_ICC_STATUS_PRESENT_DEACTIVE:
			ccid_trans->param->card_status =
				ccid_trans->handle->card_status = 
				CCID_CARD_PRESENT_DEACTIVE;
			return;
		case CCID_ICC_STATUS_ABSENT:
			ccid_trans->param->card_status =
				ccid_trans->handle->card_status = 
				CCID_CARD_ABSENT;
			return;
		default:
			ccid_trans->param->ret = CCID_ERROR_COMMUNICATION;
			return;
		}
	default:
		return;
	}
}

static int ccid_check_response(const char *cmb_buf)
{
	uint8_t cmd_status, slot_err;

	cmd_status = cmb_buf[CCID_OFFSET_STATUS] & CCID_CMD_STATUS_MASK;
	slot_err = cmb_buf[CCID_OFFSET_ERROR];

	if (cmd_status == CCID_CMD_STATUS_SUCCESS)
		return CCID_SUCCESS;
	if (cmd_status == CCID_CMD_STATUS_TIME_EXT)
		return CCID_TIME_EXTENSION;

	switch (slot_err) {
	case CCID_TRANS_ERR_ICC_MUTE:
		return CCID_ERROR_NO_CARD;
	case CCID_TRANS_ERR_XFR_PARITY:
	case CCID_TRANS_ERR_XFR_OVERRUN:
		return CCID_ERROR_COMM_ERR;
	case CCID_TRANS_ERR_BAD_ATR_TS:
	case CCID_TRANS_ERR_BAD_ATR_TCK:
		return CCID_ERROR_NO_ATR;
	case CCID_TRANS_ERR_ICC_PROT_NOSUP:
	case CCID_TRANS_ERR_ICC_CLASS_NOSUP:
		return CCID_ERROR_INCOMPATIBLE_DEV;
	case CCID_TRANS_ERR_BAD_PROC_BYTE:
		return CCID_ERROR_INVALID_ARG;
	case CCID_TRANS_ERR_BUSY_AUTO_SEQ:
	case CCID_TRANS_ERR_SLOT_BUSY:
		return CCID_ERROR_TIMEOUT;
	case CCID_TRANS_ERR_PIN_TIMEOUT:
		return CCID_ERROR_USER_TIMEOUT;
	case CCID_TRANS_ERR_PIN_CANCELLED:
		return CCID_ERROR_USER_ABORT;
	case CCID_TRANS_ERR_MSG_TYPE:
		return CCID_ERROR_NOT_SUPPORTED;
	case CCID_TRANS_ERR_SLOT:
		return CCID_ERROR_INVALID_SLOT;
	case CCID_TRANS_ERR_DEACTIVATED_PROT:
	case CCID_TRANS_ERR_CMD_ABORTED:
	case CCID_TRANS_ERR_HW:
	default:
		return CCID_ERROR_GENERIC;
	}
}

static void ccid_parse_bulk_reap(struct ccid_transfer *ccid_trans)
{
	uint8_t cmd_type;

	cmd_type = ccid_trans->cmd_buf[0];

	if (ccid_trans->cmd_in != cmd_type) {
		ccid_log(CCID_LOG_ERR, "cmd type invalid. cmd_type: %X", cmd_type);
		ccid_trans->param->ret = CCID_ERROR_COMMUNICATION;
		return;
	}

	if (ccid_trans->cmd_buf_actual < CCID_OFFSET_STATUS + 1) {
		ccid_log(CCID_LOG_DEBUG, "not enough data received: %d bytes", 
			ccid_trans->cmd_buf_actual);
		ccid_trans->param->ret = CCID_ERROR_COMMUNICATION;
		return;
	}

	ccid_trans->param->ret = ccid_check_response(ccid_trans->cmd_buf);
	if (ccid_trans->param->ret == CCID_TIME_EXTENSION)
		return;
	
	switch (cmd_type) {
	case RDR_TO_PC_DATABLOCK:
		ccid_parse_rdr_to_pc_datablock(ccid_trans);
		break;
	case RDR_TO_PC_SLOTSTATUS:
		ccid_parse_rdr_to_pc_slotstatus(ccid_trans);
		break;
	default:
		ccid_trans->param->ret = CCID_ERROR_NOT_SUPPORTED;
		break;
	}
}

void ccid_parse_reap(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->handle->intfc_proto) {
	case CCID_INTFC_PROTO_BULK:
		ccid_parse_bulk_reap(ccid_trans);
		break;
	case CCID_INTFC_PROTO_CTRL_A:
	case CCID_INTFC_PROTO_CTRL_B:
		ccid_trans->param->ret = CCID_ERROR_NOT_SUPPORTED;
		break;
	}
}

ccid_trans_param_t *ccid_build_trans_param(const uint8_t *sbuf, int slen, 
				       uint8_t *rbuf, int rlen,
				       ccid_trans_param_comp cb, void *user_data, int type)
{
	ccid_trans_param_t *tp;

	tp = malloc(sizeof (ccid_trans_param_t));
	if (!tp)
		return NULL;
	memset(tp, 0, sizeof (ccid_trans_param_t));
	
	tp->reader_idx = -1;	/* none */
	tp->sbuf = sbuf;
	tp->sbuf_len = slen;
	tp->rbuf = rbuf;
	tp->rbuf_len = rlen;
	tp->rbuf_actual = -1;	/* none */
	tp->card_status = -1;	/* none */
	tp->ret = -1;		/* none */
	tp->callback = cb;
	tp->user_data = user_data;
	tp->type = type;

	return tp;
}

ccid_trans_t *ccid_build_trans(uint8_t cmd_out, uint8_t cmd_in,
			       const char *name, ccid_reader_t *handle,
			       ccid_transfer_complete cb, ccid_trans_param_t *param)
{
	ccid_trans_t *ct;

	ct = ccid_alloc_transfer(cmd_out, cmd_in);
	if (!ct)
		return NULL;
	ct->name = strdup(name);
	ct->handle = handle;
	if (!cb)
		ct->callback = ccid_common_trans_cb;
	else
		ct->callback = cb;
	ct->param = param;
	return ct;
}

void ccid_destroy_trans(ccid_trans_t *ct)
{
	ccid_free_transfer(ct);
}
