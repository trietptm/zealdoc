#include "ccid_usb.h"	/* now its usb reader */

DECLARE_LIST(ccid_readers);
DECLARE_NOTIFY_CHAIN(ccid_chain);

#define for_each_reader(r)	\
	list_for_each_entry(ccid_reader_t, r, &ccid_readers, link)

static ccid_reader_t *ccid_reader_get(ccid_reader_t *r);
static void ccid_reader_put(ccid_reader_t *r);
static ccid_reader_t *ccid_reader_exist_get(const char *name, int type, void* upper);
static ccid_reader_t *ccid_reader_new(int dev_type, const char *reader_name);
static void ccid_reader_free(ccid_reader_t *r);

static ccid_reader_t *ccid_reader_get(ccid_reader_t *r)
{
	atomic_inc(&r->refcnt);
	return r;
}

static void ccid_reader_put(ccid_reader_t *r)
{
	atomic_dec(&r->refcnt);
}

static ccid_reader_t *ccid_reader_exist_get(const char *name, int type, void* hd)
{
	ccid_reader_t *r;

	for_each_reader(r) {
		if (0 == strcasecmp(name, r->name) &&
		    type == r->dev_type &&
		    hd == r->upper)
			return ccid_reader_get(r);
	}
	return NULL;
}

static inline int ccid_unsupport_devtype(int type)
{
	return !(type == CCID_DEVICE_TYPE_USB);
}

int ccid_register_notify(notify_t *nb)
{
	ccid_reader_t *rdr;
	ccid_reader_t *last;
	int err;

	err = register_notify_chain(&ccid_chain, nb);
	if (err)
		goto unlock;

	for_each_reader(rdr) {
		err = nb->call(nb, CCID_RDR_REGISTER, rdr);
		err = notify_to_errno(err);
		if (err)
			goto rollback;
	}
unlock:
	return err;
rollback:
	last = rdr;
	for_each_reader(rdr) {
		if (rdr == last)
			break;
		nb->call(nb, CCID_RDR_UNREGISTER, rdr);
	}
	goto unlock;
}

void ccid_unregister_notify(notify_t *nb)
{
	unregister_notify_chain(&ccid_chain, nb);
}

int ccid_notify(unsigned long val, void *v)
{
	return call_notify_chain(&ccid_chain, val, v);
}

static void ccid_reader_bind(ccid_reader_t *rdr, void *upper)
{
	rdr->upper = upper;
}

static ccid_reader_t *ccid_reader_new(int dev_type, const char *reader_name)
{
	ccid_reader_t *rdr = malloc(sizeof (ccid_reader_t));

	if (!rdr) {
		ccid_log(CCID_LOG_ERR, "RDR: out of memory");
		return NULL;
	}

	memset(rdr, 0, sizeof (ccid_reader_t));

	list_init(&rdr->link);
	atomic_set(&rdr->refcnt, 1);

	rdr->bseq = 0;
	rdr->bslot = 0;
	rdr->intfc_proto = CCID_INTFC_PROTO_BULK;
	rdr->card_status = CCID_CARD_ABSENT;
	rdr->dev_type = dev_type;
	rdr->name = strdup(reader_name);

	list_insert_before(&rdr->link, &ccid_readers);
	return rdr;
}

static void ccid_reader_free(ccid_reader_t *r)
{
	if (atomic_dec_and_test(&r->refcnt)) {
		if (r->name) 
			free(r->name);
		list_delete(&r->link);
		free(r);
	}
}

static void ccid_reader_up(ccid_reader_t *r)
{
	switch(r->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		usb_intfc_up(r->upper);
	default:
		break;
	}		
}

static int ccid_reader_start(ccid_reader_t *rdr)
{
	switch(rdr->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		/* will open usb device */
		return ccid_usb_claim(rdr);
	default:
		break;
	}
	return -1;
}

static int ccid_reader_stop(ccid_reader_t *rdr)
{
	switch(rdr->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		/* will close usb device */
		ccid_usb_release(rdr);
		break;
	default:
		break;
	}

	return -1;
}

ccid_reader_t *ccid_reader_open(int dev_type, const char *reader_name,
			     void *upper/* usb_intfc_t now */)
{
	int ret;
	ccid_reader_t *reader;
	
	if (ccid_unsupport_devtype(dev_type)) {
		ccid_log(CCID_LOG_INFO,
			 "CCID: not support device type=%d",
			 dev_type);
		return NULL;
	}

	reader = ccid_reader_new(dev_type, reader_name);
	if (!reader)
		return NULL;
	
	ccid_reader_bind(reader, upper);

	/* open device and claim intfc */
	ret = ccid_reader_start(reader);
	if (ret != CCID_SUCCESS) {
		ccid_log(CCID_LOG_ERR, "RDR: claim reader fail");
		/* TODO: not free, need __xx() */
		ccid_reader_free(reader);
		return NULL;
	}

	ccid_reader_up(reader);

	ccid_log(CCID_LOG_INFO, "RDR: create ccid reader, name/type=%s/%d",
		 reader_name, dev_type);

	/* pcsc IFD will up now */
	ccid_notify(CCID_RDR_INSERT, reader);

	return reader;
}

void ccid_reader_close(int type, const char *name, void *hd/* usb_intfc_t now */)
{
	ccid_reader_t *rdr = ccid_reader_exist_get(name, type, hd);

	if (!rdr)
		return;
	/* pcsc IFD will down */
	ccid_notify(CCID_RDR_REMOVE, rdr);

	ccid_reader_stop(rdr);
	ccid_reader_put(rdr);
	ccid_reader_free(rdr);
}

/* smart card device class descriptor */
int ccid_parse_ccid_descriptor(const uint8_t *src, size_t len,
			       struct ccid_descriptor *ccid_desc)
{
	/* SEPC 5.1 */
	if (len != USB_CCID_DESCRIPTOR_LENGTH)
		return -1;

	ccid_desc->bLength = src[0];
	ccid_desc->bDescriptorType = src[1];
	ccid_desc->bcdCCID = (src[3] << 8) & src[2];
	ccid_desc->bMaxSlotIndex = src[4];
	ccid_desc->bVoltageSupport = src[5];
	ccid_desc->dwProtocols = 
		src[9] << 24 | src[8] << 16 | src[7] << 8 | src[6];
	ccid_desc->dwDefaultClock = 
		src[13] << 24 | src[12] << 16 | src[11] << 8 | src[10];
	ccid_desc->dwMaximumClock = 
		src[17] << 24 | src[16] << 16 | src[15] << 8 | src[14];
	ccid_desc->bNumClockSupported = src[18];
	ccid_desc->dwDataRate = 
		src[22] << 24 | src[21] << 16 | src[20] << 8 | src[19];
	ccid_desc->dwMaxDataRate = 
		src[26] << 24 | src[25] << 16 | src[24] << 8 | src[23];
	ccid_desc->bNumDataRatesSupported = src[27];
	ccid_desc->dwMaxIFSD = 
		src[31] << 24 | src[30] << 16 | src[29] << 8 | src[28];
	ccid_desc->dwSynchProtocols = 
		src[35] << 24 | src[34] << 16 | src[33] << 8 | src[32];
	ccid_desc->dwMechanical = 
		src[39] << 24 | src[38] << 16 | src[37] << 8 | src[36];
	ccid_desc->dwFeatures = 
		src[43] << 24 | src[42] << 16 | src[41] << 8 | src[40];
	ccid_desc->dwMaxCCIDMessageLength = 
		src[47] << 24 | src[46] << 16 | src[45] << 8 | src[44];
	ccid_desc->bClassGetResponse = src[48];
	ccid_desc->bClassEnvelope = src[49];
	ccid_desc->wLcdLayout = src[51] << 8 | src[50];
	ccid_desc->bPINSupport = src[52];
	ccid_desc->bMaxCCIDBusySlots = src[53];

	return 0;
}

uint16_t ccid_dev_idVendor(void *data, int dev_type)
{
	ccid_reader_t *rdr = (ccid_reader_t *)data;

	switch(rdr->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		return ccid_usb_dev_idVendor(rdr);
	default:
		break;
	}
	return -1;
}

uint16_t ccid_dev_idProduct(void *data, int dev_type)
{
	ccid_reader_t *rdr = (ccid_reader_t *)data;

	switch(rdr->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		return ccid_usb_dev_idProduct(rdr);
	default:
		break;
	}
	return -1;
}

/* call from PCSC/ccid handle */
ccid_desc_t *ccid_desc_get(void *data)
{
	ccid_reader_t *rdr = (ccid_reader_t *)data;
	if (!rdr)
		return NULL;

	ccid_reader_get(rdr);
	return &rdr->ccid_desc;
}

/* call from PCSC/ccid handle */
void ccid_desc_put(void *data)
{
	ccid_reader_t *rdr = (ccid_reader_t *)data;
	if (!rdr)
		return;
	ccid_reader_put(rdr);
}
