#ifndef __CCID_USB_H__
#define __CCID_USB_H__
#include "ccid_priv.h"

enum ccid_usb_intfc_protocol {
	CCID_USB_INTFC_PROTO_BULK	= 0x00,
	CCID_USB_INTFC_PROTO_CTRL_A	= 0x01,
	CCID_USB_INTFC_PROTO_CTRL_B	= 0x02,
};

struct ccid_usb_control_param {
	uint8_t		bmRequestType;
	uint8_t		bRequest;
	uint16_t	wValue;
	uint16_t	wIndex;
	uint16_t	wLength;
	uint8_t		*data;

	ccid_transfer_complete callback;
	void *user_data;
};

int ccid_usb_cancel(ccid_reader_t *hccid);

int ccid_usb_fill_cmd(struct ccid_transfer *ccid_trans);

int ccid_usb_send_transfer(struct ccid_transfer *ccid_trans);
int ccid_usb_reap_transfer(struct ccid_transfer *ccid_trans);

int ccid_usb_fill_control(uint8_t request_class, uint8_t request, 
			  uint8_t *data, size_t data_len,
			  struct ccid_usb_control_param *control_param);
int ccid_usb_control_transfer(usb_intfc_t *intfc, 
			      struct ccid_usb_control_param *control_param);

int ccid_register_usb_driver(void);
void ccid_unregister_usb_driver(void);

int ccid_usb_claim(ccid_reader_t *rdr);
int ccid_usb_release(ccid_reader_t *rdr);

uint16_t ccid_usb_dev_idVendor(ccid_reader_t *rdr);
uint16_t ccid_usb_dev_idProduct(ccid_reader_t *rdr);

#endif /*__CCID_USB_H__*/
