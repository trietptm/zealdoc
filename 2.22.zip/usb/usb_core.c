#include "usb_priv.h"

int usb_logger = 0;

log_source_t usb_log_source = {
	"usb"
};

void usb_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(usb_logger, level, format, ap);
	va_end(ap);
}

static int __init usb_log_init(void)
{
	usb_logger = log_register_source(&usb_log_source);

	return !usb_logger;
}

static void __exit usb_log_exit(void)
{
	log_unregister_source(usb_logger);
}


ui_argument_t usb_filename_args = {
	"filename",
	"reader name",
	NULL,
	UI_TYPE_STRING,
};

ui_argument_t usb_reader_args = {
	"reader",
	"reader index",
	NULL,
	UI_TYPE_STRING,
};

ui_argument_t usb_claim_intfc_args[] = {
	{ "reader",
	  "reader index",
	  NULL,
	  UI_TYPE_STRING,},
	{ "config",
	  "config index",
	  NULL, 
	  UI_TYPE_STRING,},
	{ "intfc",
	  "interface index",
	  NULL, 
	  UI_TYPE_STRING,},
};

ui_argument_t usb_trans_args[] = {
	{"reader",
	"USB smartcard reader",
	NULL,
	UI_TYPE_STRING,},
	{"transfer",
	"transfer index",
	NULL,
	UI_TYPE_STRING,},
};

modlinkage int usb_init(void)
{
	usb_log_init();
	usb_dev_init();
	return 0;
}

modlinkage void usb_exit(void)
{
	usb_dev_exit();
	usb_log_exit();
}

subsys_initcall(usb_init);
subsys_exitcall(usb_exit);
