#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

static void pkcs15_bind_stm_exit_delay(void *eloop, void *user_ctx);

struct pkcs15_handle *pkcs15_handle_new(void)
{
	struct pkcs15_handle *p15_handle;

	p15_handle = malloc(sizeof(struct pkcs15_handle));
	if (!p15_handle)
		return NULL;
	memset(p15_handle, 0, sizeof(struct pkcs15_handle));

	list_init(&p15_handle->df_list);
	list_init(&p15_handle->obj_list);

	return p15_handle;
}

void pkcs15_handle_free(struct pkcs15_handle *p15_handle)
{
	struct pkcs15_df *pos_df, *n_df;
	struct pkcs15_object *pos_obj, *n_obj;

	if (!p15_handle) return;
	/* TODO: free members */

	list_for_each_entry_safe(struct pkcs15_df, pos_df, n_df,
				 &p15_handle->df_list, link) {
		list_delete(&pos_df->link);
		if (pos_df->filp)
			icc_file_free(pos_df->filp);
		free(pos_df);
	}
	list_for_each_entry_safe(struct pkcs15_object, pos_obj, n_obj,
				 &p15_handle->obj_list, link) {
		list_delete(&pos_obj->link);
		pkcs15_free_object(pos_obj);
	}
	
	if (p15_handle->app_root)
		icc_file_free(p15_handle->app_root);
	if (p15_handle->odf)
		icc_file_free(p15_handle->odf);
	if (p15_handle->tif)
		icc_file_free(p15_handle->tif);
	if (p15_handle->unused)
		icc_file_free(p15_handle->unused);
	if (p15_handle->tokeninfo.serial_num)
		free(p15_handle->tokeninfo.serial_num);
	if (p15_handle->tokeninfo.manufacturer_id)
		free(p15_handle->tokeninfo.manufacturer_id);
	if (p15_handle->tokeninfo.label)
		free(p15_handle->tokeninfo.label);
	if (p15_handle->tokeninfo.last_update)
		free(p15_handle->tokeninfo.last_update);
	if (p15_handle->tokeninfo.prefered_lang)
		free(p15_handle->tokeninfo.prefered_lang);
	if (p15_handle->tokeninfo.sec_info) {
		size_t i;

		for (i = 0; i < p15_handle->tokeninfo.sec_info_num; i++) {
			free(p15_handle->tokeninfo.sec_info[i]);
		}
		free(p15_handle->tokeninfo.sec_info);
	}
	free(p15_handle);
}

int pkcs15_free_object(struct pkcs15_object *obj)
{
	return PKCS15_SUCCESS;
}

struct pkcs15_bind_trans {
	const char	*name;
	stm_instance_t *fsmi;
	
	uint8_t rec_nr;
	size_t	rec_size;

	uint8_t *sbuf;
	size_t	sbuf_len;
	uint8_t *rbuf;
	size_t	rbuf_len;
	size_t	rbuf_actual;
	
	/* whats handle_out */
	struct pkcs15_handle **handle_out, *p15_handle;
	pcsc_appcmd_complete callback;
	void *user_data;

	int ret;
};

static void pkcs15_bind_stm_log(const stm_instance_t *fsmi,
				int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

#define PKCS15_BIND_STATE_INIT		0
#define PKCS15_BIND_STATE_SELECT_DIR	1
#define PKCS15_BIND_STATE_READ_DIR	2
#define PKCS15_BIND_STATE_PARSE_DIR	3
#define PKCS15_BIND_STATE_SELECT_ROOT	4
#define PKCS15_BIND_STATE_SELECT_ODF	5
#define PKCS15_BIND_STATE_READ_ODF	6
#define PKCS15_BIND_STATE_PARSE_ODF	7
#define PKCS15_BIND_STATE_SELECT_INFO	8
#define PKCS15_BIND_STATE_READ_INFO	9
#define PKCS15_BIND_STATE_PARSE_INFO	10
#define PKCS15_BIND_STATE_EXIT		11

#define PKCS15_BIND_STATE_COUNT		12

#define PKCS15_BIND_STATE_NAMES {	\
	"INIT",				\
	"SELECT_DIR",			\
	"READ_DIR",			\
	"PARSE_DIR",			\
	"SELECT_ROOT",			\
	"SELECT_ODF",			\
	"READ_ODF",			\
	"PARSE_ODF",			\
	"SELECT_INFO",			\
	"READ_INFO",			\
	"PARSE_INFO",			\
	"EXIT",				\
}

#define PKCS15_BIND_EVENT_AG		0	/* again */
#define PKCS15_BIND_EVENT_GO		1	/* go on next step */
#define PKCS15_BIND_EVENT_ERR		2	/* common error */
#define PKCS15_BIND_EVENT_COUNT		3

#define PKCS15_BIND_EVENT_NAMES {	\
	"AG",				\
	"GO",				\
	"ERR",				\
}

static void pkcs15_bind_raise_event(struct pkcs15_bind_trans *p15_bind_trans,
				    int event)
{
	eloop_schedule_event(NULL, p15_bind_trans->fsmi, event, p15_bind_trans);
}

static void pkcs15_bind_raise_err(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_ERR);
}

static void pkcs15_bind_raise_ag(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_AG);
}

static void pkcs15_bind_raise_go(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_GO);
}

static int pkcs15_bind_action_null(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static int pkcs15_bind_action_itc(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;

	p15_handle->app_root = icc_file_new();
	if (p15_handle->app_root == NULL) {
		p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
		pkcs15_bind_raise_err(p15_bind_trans);
	}

	return 1;
}

static int pkcs15_bind_action_etc(stm_instance_t *fsmi, void *data)
{
	eloop_register_timeout(NULL, 0, 0, pkcs15_bind_stm_exit_delay, NULL, data);

	return 1;
}

static void select_dir_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;

	pkcs15_log(PKCS15_LOG_ERR, "P15: select dir comp=%d", ret);
	if (ret == ICC_SUCCESS) {
		pkcs15_bind_raise_go(p15_bind_trans);
		p15_bind_trans->rec_nr = 1;
	} else if (ret ==  ICC_ERR_FILE_NOT_FOUND){
		icc_format_path("3F005015", 
			&p15_bind_trans->p15_handle->app_root->path);
		pkcs15_bind_raise_ag(p15_bind_trans);
	} else {
		pkcs15_bind_raise_err(p15_bind_trans);
	}
}

static int pkcs15_bind_action_select_dir(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct icc_path dir_path;
	struct icc_file **file;
	int r;
	pcsc_slot_t *card_hd = p15_bind_trans->p15_handle->card_handle;

	file = pcsc_app_ef_dir(card_hd);

	icc_format_path("3F002F00", &dir_path);
	dir_path.type = ICC_PATH_TYPE_PATH;

	r = pcsc_select_file(card_hd, &dir_path, file, select_dir_complete, p15_bind_trans);
	if (r != ICC_SUCCESS) {
		p15_bind_trans->ret = r;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
	return 1;
}

static void read_dir_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;
	
	pkcs15_log(PKCS15_LOG_ERR, "P15: read dir comp=%d", ret);

	if (ret == ICC_ERR_RECORD_NOT_FOUND) {
		pkcs15_bind_raise_go(p15_bind_trans);
	} else if (ret >= 0) {
		p15_bind_trans->rbuf_actual = ret;
		pkcs15_bind_raise_go(p15_bind_trans);
	} else {
		p15_bind_trans->ret = ret;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
}

static int pkcs15_bind_action_read_dir(stm_instance_t *fsmi, void *data)
{
#if 1
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	pcsc_slot_t *card_handle = 
			p15_bind_trans->p15_handle->card_handle;
	struct icc_file **dir = pcsc_app_ef_dir(card_handle);
	struct icc_file *ef_dir = *dir;
	uint8_t *rbuf;
	size_t rbuf_len;
	int r;

	if (!ef_dir)
		goto srdf;

	if (ef_dir->ef_structure == ICC_FILE_EF_TRANSPARENT) {
		rbuf_len = ef_dir->size;
		rbuf = malloc(rbuf_len);
		if (rbuf == NULL) {
			p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
			goto srdf;
		}
		memset(rbuf, 0, rbuf_len);
		p15_bind_trans->rbuf = rbuf;
		p15_bind_trans->rbuf_len = rbuf_len;
		r = pcsc_read_binary(card_handle, 0, rbuf, rbuf_len, 0,
			read_dir_complete, p15_bind_trans);
		if (r != ICC_SUCCESS) {
			p15_bind_trans->ret = r;
			free(rbuf);
			goto srdf;
		}
	} else {
		rbuf_len = ef_dir->record_length;
		rbuf = malloc(rbuf_len);
		if (rbuf == NULL) {
			p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
			goto srdf;
		}
		memset(rbuf, 0, rbuf_len);
		p15_bind_trans->rbuf = rbuf;
		p15_bind_trans->rbuf_len = rbuf_len;
		
		BUG();
		/* TODO */
		r = -1;
#ifdef TODO
		r = scard_read_record(card_handle, p15_bind_trans->rec_nr++,
				      rbuf, rbuf_len, ICC_RECORD_BY_REC_NR, 
				      read_dir_complete, p15_bind_trans);
#endif
		if (r != ICC_SUCCESS) {
			p15_bind_trans->ret = r;
			free(rbuf);
			goto srdf;
		}
	}
	return 1;
srdf:
	pkcs15_bind_raise_err(p15_bind_trans);
#endif
	return 1;
}

static int pkcs15_bind_action_parse_dir(stm_instance_t *fsmi, void *data)
{
#if 1
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	pcsc_slot_t *card_handle = p15_bind_trans->p15_handle->card_handle;
	struct icc_file **dir = pcsc_app_ef_dir(card_handle);
	struct icc_file *ef_dir = *dir;
	uint8_t *p, *rbuf = p15_bind_trans->rbuf;
	size_t rbuf_actual = p15_bind_trans->rbuf_actual;
	int r;

	pkcs15_log(PKCS15_LOG_ERR, "P15: parse dir");

	p = rbuf;
	if (ef_dir->ef_structure == ICC_FILE_EF_TRANSPARENT) {
		while (rbuf_actual > 0) {
			if (pcsc_app_count(card_handle) == ICC_APP_MAX) 
				goto pds;

			/* TODO */
			r = parse_dir_record(card_handle, &p, &rbuf_actual, -1);
			if (r != ICC_SUCCESS)
				break;
		}
		goto pds;
	} else {
		if (p15_bind_trans->ret == ICC_ERR_RECORD_NOT_FOUND) {
			p15_bind_trans->ret = ICC_SUCCESS;
			goto pds;
		}
		if (pcsc_app_count(card_handle) == ICC_APP_MAX)
			goto pds;
		parse_dir_record(card_handle, &p, &rbuf_actual, 
				(int)rbuf_actual);
		goto rnr;/* read next app record */
	}

rnr:
	free(rbuf);
	pkcs15_bind_raise_ag(p15_bind_trans);
	return 1;
pds:
	if (rbuf) free(rbuf);
	pkcs15_bind_raise_go(p15_bind_trans);
#endif
	return 1;
}

static int pkcs15_bind_action_find_app(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;

	icc_format_path("3F005015", &p15_handle->app_root->path);
	if (pcsc_app_count(p15_handle->card_handle) > 0) {
		struct icc_app_info *info;

		info = pkcs15_find_app(p15_handle->card_handle);
		if (info) {
			if (info->path.len)
				p15_handle->app_root->path = info->path;
			if (info->ddo)
				parse_ddo(p15_handle, info->ddo, info->ddo_len);
		}
	}
	return 1;
}

/* Set App Root path*/
static int pkcs15_bind_action_sar(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static void select_root_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;

	pkcs15_log(PKCS15_LOG_ERR, "P15: select_root ret=%d", ret);

	if (ret == ICC_SUCCESS) {
		pkcs15_bind_raise_go(p15_bind_trans);
	} else if (ret == ICC_ERR_FILE_NOT_FOUND) {
		icc_format_path("3F00", 
			&p15_bind_trans->p15_handle->app_root->path);
		pkcs15_bind_raise_ag(p15_bind_trans);
	} else {
		pkcs15_bind_raise_err(p15_bind_trans);
	}
}

static int pkcs15_bind_action_select_root(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct icc_file *app_root = p15_bind_trans->p15_handle->app_root;
	pcsc_slot_t *card_handle = p15_bind_trans->p15_handle->card_handle;
	int r;

	pkcs15_log(PKCS15_LOG_ERR, "P15: select_root");

	r = pcsc_select_file(card_handle, &app_root->path, NULL, 
				select_root_complete, p15_bind_trans);
	if (r != ICC_SUCCESS) {
		p15_bind_trans->ret = r;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
	return 1;
}

static void select_odf_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;

	pkcs15_log(PKCS15_LOG_ERR, "P15: select_odf ret=%d", ret);

	if (ret == ICC_SUCCESS) {
		pkcs15_bind_raise_go(p15_bind_trans);
	} else {
		pkcs15_bind_raise_err(p15_bind_trans);
	}
}

static int pkcs15_bind_action_select_odf(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;
	pcsc_slot_t *card_handle = p15_handle->card_handle;
	struct icc_path tmppath;
	int r;

	pkcs15_log(PKCS15_LOG_ERR, "P15: select_odf");

	if (p15_handle->odf) {
		tmppath = p15_handle->odf->path;
		icc_file_free(p15_handle->odf);
		p15_handle->odf = NULL;
	} else {
		tmppath = p15_handle->app_root->path;
		icc_append_path_id(&tmppath, (const uint8_t *) "\x50\x31", 2);
	}
	
	r = pcsc_select_file(card_handle, &tmppath, &p15_handle->odf, 
				select_odf_complete, p15_bind_trans);
	if (r != ICC_SUCCESS) {
		p15_bind_trans->ret = r;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
	
	return 1;
}

static void read_odf_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;
	
	pkcs15_log(PKCS15_LOG_ERR, "P15: read_odf, ret=%d", ret);

	if (ret >= 0) {
		p15_bind_trans->rbuf_actual = ret;
		pkcs15_bind_raise_go(p15_bind_trans);
	} else {
		p15_bind_trans->ret = PKCS15_ERR_OTHER;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
}

static int pkcs15_bind_action_read_odf(stm_instance_t *fsmi, void *data)
{

	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;
	pcsc_slot_t *card_handle = p15_handle->card_handle;
	struct icc_file *app_odf = p15_handle->odf;
	uint8_t *rbuf;
	size_t rbuf_len;
	int r;

	pkcs15_log(PKCS15_LOG_ERR, "P15: read_odf");

	rbuf_len = app_odf->size;
	rbuf = malloc(rbuf_len);
	if (rbuf == NULL) {
		p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
		goto srof;
	}
	memset(rbuf, 0, rbuf_len);
	p15_bind_trans->rbuf = rbuf;
	p15_bind_trans->rbuf_len = rbuf_len;
	r = pcsc_read_binary(card_handle, 0, rbuf, rbuf_len, 0,
		read_odf_complete, p15_bind_trans);
	if (r != ICC_SUCCESS) {
		p15_bind_trans->ret = r;
		free(rbuf);
		goto srof;
	}
	return 1;
srof:
	pkcs15_bind_raise_err(p15_bind_trans);
	return 1;
}

static int pkcs15_bind_action_parse_odf(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;
	int r;

	r = parse_odf(p15_bind_trans->rbuf, p15_bind_trans->rbuf_actual, p15_handle);
	if (r == PKCS15_SUCCESS)
		pkcs15_bind_raise_go(p15_bind_trans);
	else 
		pkcs15_bind_raise_err(p15_bind_trans);

	return 1;
}

static void select_tokeninfo_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;

	if (ret == ICC_SUCCESS) {
		pkcs15_bind_raise_go(p15_bind_trans);
	} else {
		pkcs15_bind_raise_err(p15_bind_trans);	
	}
}

static int pkcs15_bind_action_select_info(stm_instance_t *fsmi, void *data)
{
#ifdef TODO
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;
	struct scard_handle *card_handle = p15_handle->card_handle;
	struct icc_path tmppath;
	int r;

	if (p15_handle->tif) {
		tmppath = p15_handle->tif->path;
		scard_file_free(p15_handle->tif);
		p15_handle->odf = NULL;
	} else {
		tmppath = p15_handle->app_root->path;
		scard_append_path_id(&tmppath, (const uint8_t *) "\x50\x32", 2);
	}
		
	r = scard_select_file(card_handle, &tmppath, &p15_handle->tif, 
				select_tokeninfo_complete, p15_bind_trans);
	if (r != ICC_SUCCESS) {
		p15_bind_trans->ret = r;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
#endif	
	return 1;
}

static void read_tokeninfo_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;
	if (ret >= 0) {
		p15_bind_trans->rbuf_actual = ret;
		pkcs15_bind_raise_go(p15_bind_trans);
	} else {
		free(p15_bind_trans->rbuf);
		p15_bind_trans->ret = PKCS15_ERR_OTHER;
		pkcs15_bind_raise_err(p15_bind_trans);
	}
}

static int pkcs15_bind_action_read_info(stm_instance_t *fsmi, void *data)
{
#ifdef TODO
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;
	struct scard_handle *card_handle = p15_handle->card_handle;
	struct scard_file *app_tokeninfo = p15_handle->tif;
	uint8_t *rbuf;
	size_t rbuf_len;
	int r;

	rbuf_len = app_tokeninfo->size;
	rbuf = malloc(rbuf_len);
	if (rbuf == NULL) {
		p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
		goto srif;
	}
	memset(rbuf, 0, rbuf_len);
	p15_bind_trans->rbuf = rbuf;
	p15_bind_trans->rbuf_len = rbuf_len;
	r = scard_read_binary(card_handle, 0, rbuf, rbuf_len, 0,
		read_tokeninfo_complete, p15_bind_trans);
	if (r != ICC_SUCCESS) {
		p15_bind_trans->ret = r;
		free(rbuf);
		goto srif;
	}

	return 1;
srif:
	pkcs15_bind_raise_err(p15_bind_trans);
#endif
	return 1;
}

static int pkcs15_bind_action_parse_info(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_tokeninfo *tokeninfo = 
			&p15_bind_trans->p15_handle->tokeninfo;
	int r;
	
	memset(tokeninfo, 0, sizeof(struct pkcs15_tokeninfo));
	r = pkcs15_parse_tokeninfo(tokeninfo, p15_bind_trans->rbuf,
				   p15_bind_trans->rbuf_actual);
	if (r != PKCS15_SUCCESS)
		pkcs15_bind_raise_err(p15_bind_trans);
	else 
		pkcs15_bind_raise_go(p15_bind_trans);		

	free(p15_bind_trans->rbuf);
	return 1;
}

static int pkcs15_bind_action_init_handle(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	
	*p15_bind_trans->handle_out = p15_bind_trans->p15_handle;

	return 1;
}

static const stm_action_fn pkcs15_bind_act_null [] = {
	pkcs15_bind_action_null,
};

static const stm_action_fn pkcs15_bind_act_itc_select_dir[] = {
	pkcs15_bind_action_itc,
	pkcs15_bind_action_select_dir,
};

static const stm_action_fn pkcs15_bind_act_etc[] = {
	pkcs15_bind_action_etc,
};

static const stm_action_fn pkcs15_bind_act_read_dir[] = {
	pkcs15_bind_action_read_dir,
};

static const stm_action_fn pkcs15_bind_act_parse_dir[] = {
	pkcs15_bind_action_parse_dir,
};

static const stm_action_fn pkcs15_bind_act_sar_select_root[] = {
	pkcs15_bind_action_sar,
	pkcs15_bind_action_select_root,
};

static const stm_action_fn pkcs15_bind_act_find_app_sar_select_root[] = {
	pkcs15_bind_action_find_app,
	pkcs15_bind_action_sar,
	pkcs15_bind_action_select_root,
};

static const stm_action_fn pkcs15_bind_act_select_odf[] = {
	pkcs15_bind_action_select_odf,
};

static const stm_action_fn pkcs15_bind_act_read_odf[] = {
	pkcs15_bind_action_read_odf,
};

static const stm_action_fn pkcs15_bind_act_parse_odf[] = {
	pkcs15_bind_action_parse_odf,
};

static const stm_action_fn pkcs15_bind_act_select_info[] = {
	pkcs15_bind_action_select_info,
};

static const stm_action_fn pkcs15_bind_act_read_info[] = {
	pkcs15_bind_action_read_info,
};

static const stm_action_fn pkcs15_bind_act_parse_info[] = {
	pkcs15_bind_action_parse_info,
};

static const stm_action_fn pkcs15_bind_act_init_handle_etc[] = {
	pkcs15_bind_action_init_handle,
	pkcs15_bind_action_etc,
};

#define STATE(state)	PKCS15_BIND_STATE_##state
#define EVENT(event)	PKCS15_BIND_EVENT_##event
#define ACTION(stem)	pkcs15_bind_act_##stem, \
		sizeof(pkcs15_bind_act_##stem) / sizeof(stm_action_fn) 
static const stm_entry_t pkcs15_bind_stm_entries[] = {
	/* state		event		action				new_state */
	{STATE(INIT),		EVENT(GO),	ACTION(itc_select_dir),		STATE(SELECT_DIR),},

	{STATE(SELECT_DIR),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(SELECT_DIR),	EVENT(GO),	ACTION(read_dir),		STATE(READ_DIR),},
	{STATE(SELECT_DIR),	EVENT(AG),	ACTION(sar_select_root),	STATE(SELECT_ROOT),},
	{STATE(SELECT_DIR),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(READ_DIR),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(READ_DIR),	EVENT(GO),	ACTION(parse_dir),		STATE(PARSE_DIR),},
	{STATE(READ_DIR),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(PARSE_DIR),	EVENT(AG),	ACTION(read_dir),		STATE(READ_DIR),},
	{STATE(PARSE_DIR),	EVENT(GO),	ACTION(find_app_sar_select_root),STATE(SELECT_ROOT),},
	{STATE(PARSE_DIR),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	
	{STATE(SELECT_ROOT),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(SELECT_ROOT),	EVENT(GO),	ACTION(select_odf),		STATE(SELECT_ODF),},
	{STATE(SELECT_ROOT),	EVENT(AG),	ACTION(sar_select_root),	STATE(SELECT_ROOT),},
	{STATE(SELECT_ROOT),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(SELECT_ODF),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(SELECT_ODF),	EVENT(GO),	ACTION(read_odf),		STATE(READ_ODF),},
	{STATE(SELECT_ODF),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(READ_ODF),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(READ_ODF),	EVENT(GO),	ACTION(parse_odf),		STATE(PARSE_ODF),},
	{STATE(READ_ODF),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(PARSE_ODF),	EVENT(GO),	ACTION(select_info),		STATE(SELECT_INFO),},
	{STATE(PARSE_ODF),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(SELECT_INFO),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(SELECT_INFO),	EVENT(GO),	ACTION(read_info),		STATE(READ_INFO),},
	{STATE(SELECT_INFO),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(READ_INFO),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},
	{STATE(READ_INFO),	EVENT(GO),	ACTION(parse_info),		STATE(PARSE_INFO),},
	{STATE(READ_INFO),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{STATE(PARSE_INFO),	EVENT(GO),	ACTION(init_handle_etc),	STATE(EXIT),},
	{STATE(PARSE_INFO),	EVENT(ERR),	ACTION(etc),			STATE(EXIT),},

	{0,			0,		NULL,					0,},
};

static const char *pkcs15_bind_state_names[] = PKCS15_BIND_STATE_NAMES;
static const char *pkcs15_bind_event_names[] = PKCS15_BIND_EVENT_NAMES;

const stm_table_t pkcs15_bind_stm_table = {
	"pkcs15",
	pkcs15_bind_stm_log,
	PKCS15_BIND_STATE_COUNT,
	&pkcs15_bind_state_names[0],
	PKCS15_BIND_EVENT_COUNT,
	&pkcs15_bind_event_names[0],
	pkcs15_bind_stm_entries,	
};

#undef STATE
#undef EVENT
#undef ACTION

struct pkcs15_bind_trans *pkcs15_bind(uint16_t idx, struct pkcs15_handle **p15_handle_out,
		pcsc_appcmd_complete cb, void *user_data)
{
	struct pkcs15_handle *p15_handle = pkcs15_handle_new();
	struct pkcs15_bind_trans *p15_trans = NULL;

	if (!p15_handle)
		goto err;
	p15_handle->card_handle = pcsc_handle_lock_get_by_idx(idx);
	if (!p15_handle->card_handle)
		goto err;

	p15_trans = malloc(sizeof(struct pkcs15_bind_trans));
	if (!p15_trans)
		goto err;
	memset(p15_trans, 0, sizeof (struct pkcs15_bind_trans));

	p15_trans->name = "P15_test";
	p15_trans->handle_out = p15_handle_out;
	p15_trans->callback = cb;
	p15_trans->user_data = user_data;
	p15_trans->p15_handle = p15_handle;

	p15_trans->fsmi = eloop_create_automaton(&pkcs15_bind_stm_table,
						 p15_trans->name,
						 PKCS15_BIND_STATE_INIT);
	if (!p15_trans->fsmi)
		goto err;
	pkcs15_bind_raise_go(p15_trans);
	
	return p15_trans;
err:
	if (p15_handle && p15_handle->card_handle)
		pcsc_handle_lock_put(p15_handle->card_handle);
	if (p15_handle)
		pkcs15_handle_free(p15_handle);
	if (p15_trans)
		free(p15_trans);
	return NULL;
}

static void pkcs15_bind_stm_exit(struct pkcs15_bind_trans *p15_bind_trans)
{
	if (p15_bind_trans && p15_bind_trans->callback)
		p15_bind_trans->callback(p15_bind_trans->user_data, 
					 p15_bind_trans->ret);

	if (p15_bind_trans->fsmi) {
		eloop_delete_automaton(p15_bind_trans->fsmi);
		p15_bind_trans->fsmi = NULL;
	}

	if (p15_bind_trans->p15_handle) {
		if (p15_bind_trans->p15_handle->card_handle)
			pcsc_handle_lock_put(p15_bind_trans->p15_handle->card_handle);
		pkcs15_handle_free(p15_bind_trans->p15_handle);
	}

	free(p15_bind_trans);
}

static void pkcs15_bind_stm_exit_delay(void *eloop, void *user_ctx) 
{
	pkcs15_bind_stm_exit((struct pkcs15_bind_trans *)user_ctx);
}

int pkcs15_unbind(struct pkcs15_handle *p15_handle)
{
	pkcs15_handle_free(p15_handle);

	return ICC_SUCCESS;
}

static const unsigned int odf_indexes[] = {
	PKCS15_PRKDF,
	PKCS15_PUKDF,
	PKCS15_PUKDF_TRUSTED,
	PKCS15_SKDF,
	PKCS15_CDF,
	PKCS15_CDF_TRUSTED,
	PKCS15_CDF_USEFUL,
	PKCS15_DODF,
	PKCS15_AODF,
};

struct pkcs15_bind_trans *g_trans = NULL;

void pkcs15_close_trans(void)
{
	if (g_trans)
		pkcs15_bind_raise_err(g_trans);
	g_trans = NULL;
}

static void __bind_test(void *user_data, int ret)
{
	if (ret == 0) {
		pkcs15_log(PKCS15_LOG_WARN, "P15: bind test succ");
	} else
		pkcs15_log(PKCS15_LOG_WARN, "P15: bind test fail");
}

static int pkcs15_bind_test(uint16_t index)
{
	if (index == 0xFFFF)
		return -1;

	g_trans = pkcs15_bind(index, NULL, __bind_test, NULL);

	if (!g_trans) {
		pkcs15_log(PKCS15_LOG_WARN, "P15: die at bring up");
		return -1;
	}
	return 0;
}

static pcsc_binder_t p15_binder = {
	"PKCS15",
	pkcs15_bind_test,
};

int __init pkcs15_bind_init(void)
{
	return pcsc_register_binder(&p15_binder);
}

void __exit pkcs15_bind_exit(void)
{
	pcsc_unregister_binder(&p15_binder);
}
