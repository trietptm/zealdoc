#include "pcsc_priv.h"

int pcsc_logger = 0;
log_source_t pcsc_log_source = {
	"pcsc"
};

void pcsc_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(pcsc_logger, level, format, ap);
	va_end(ap);
}

static int __init pcsc_log_init(void)
{
	pcsc_logger = log_register_source(&pcsc_log_source);
	return !pcsc_logger;
}

static void __exit pcsc_log_exit(void)
{
	log_unregister_source(pcsc_logger);
}

/* test cmd */
static void __select_dir_complete(void *user_data, int ret)
{
	if (ret == 0) {
		pcsc_log(PCSC_LOG_INFO, "CORE: test select file succ");
	} else
		pcsc_log(PCSC_LOG_INFO, "CORE: test select file fail");
}

static int __select_dir(ui_session_t *sess, ui_entry_t *inst,
			     void *ctx, int argc, char **argv)
{
	struct icc_path dir_path;
	int r;

	icc_format_path("3F002F00", &dir_path);
	dir_path.type = ICC_PATH_TYPE_PATH;

	r = pcsc_select_file(0x00, &dir_path, NULL, 
				__select_dir_complete, NULL);
	if (r != 0) {
		pcsc_log(PCSC_LOG_INFO, "CORE: cannot test select file");
	}		
	return 1;
}

ui_command_t pscs_sd_command = {
	"select_cmd",
	"test select dir",
	".pcsc",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(pscs_sd_command.link),
	__select_dir,
};

ui_schema_t pscs_scheme[] = {
	/* .pcsc */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE,
	  UI_TYPE_STRING, NULL, NULL,
	  ".pcsc", "pcsc", PCSC_SERVICE_DESC },

	{ UI_TYPE_NONE },
};


modlinkage int __init pcsc_init(void)
{
	ui_register_schema(pscs_scheme);
	ui_register_command(&pscs_sd_command);

	pcsc_log_init();

	pcsc_handle_init();
	pcsc_ifd_init();
	pcsc_icc_init();
	return 0;
}

modlinkage void __exit pcsc_exit(void)
{
	pcsc_icc_exit();
	pcsc_ifd_exit();
	pcsc_handle_exit();

	pcsc_log_exit();

	ui_unregister_command(&pscs_sd_command);
	ui_unregister_schema(pscs_scheme);
}

subsys_initcall(pcsc_init);
subsys_exitcall(pcsc_exit);
