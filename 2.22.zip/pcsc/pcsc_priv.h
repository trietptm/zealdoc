#ifndef __PCSC_PRIV_H__
#define __PCSC_PRIV_H__

#include <sysdep.h>
#include <logger.h>
#include <panic.h>
#include <module.h>
#include <strutl.h>
#include <dfastm.h>
#include <eloop.h>
#include <service.h>
#include <list.h>
#include <pcsc.h>
#include <bitops.h>

/*Logging operations*/
#define PCSC_LOG_CRIT	LOG_EMERG
#define PCSC_LOG_FAIL	LOG_CRIT
#define PCSC_LOG_ERR	LOG_ERR
#define PCSC_LOG_WARN	LOG_WARNING
#define PCSC_LOG_INFO	LOG_INFO
#define PCSC_LOG_DEBUG	LOG_DEBUG

//#define LOG_CALL_CHAIN	PCSC_LOG_WARN
#define LOG_CALL_CHAIN	PCSC_LOG_DEBUG

void pcsc_log(int level, const char *format, ...);

struct pcsc_atr_info {
	uint8_t TS;
	uint8_t T0;
	uint8_t history_len;

	int supported_protos;
	int default_proto;	
};

typedef struct _pcsc_ifd_t pcsc_ifd_t;

typedef void (*pcsc_trans_cb)(pcsc_transfer_t *trans);
typedef void (*pcsc_slot_cb)(pcsc_slot_t *hd);

#include "pcsc_ifd.h"
#include "pcsc_icc.h"

struct _pcsc_slot_t {
	uint16_t idx;	/* XXYY: XX - IFD idx, YY IFD_SLOT idx */
	pcsc_ifd_t *ifd;
	pcsc_icc_t *icc;

	int locked;
	/* FIXME: ICC insert times, need? */
	uint32_t icc_seq;
	uint16_t old_icc_status;	/* for detect ICC state change */

	pcsc_slot_cb cb;
	int ret;
	stm_instance_t *fsmi;

	/* from scard handle */
	uint8_t cla;
	size_t max_send;
	size_t max_recv;

	atomic_t refcnt;
	list_t link;
};

typedef struct _pcsc_trans_param {
	uint8_t *sbuf;
	size_t sbuf_len;
	size_t sbuf_transmitted;

	/* icc trans */
	struct icc_apdu *apdu;
	struct icc_path *path;
	struct icc_file **file_out;
#define ICC_CARD_PARAM_FLAG_NOT_FREE_APDU	0x00000001
	uint32_t flags;

	pcsc_trans_cb callback;
	int ret;
} pcsc_trans_param;

typedef struct _pcsc_trans_param pcsc_icc_trans_param;
typedef struct _pcsc_trans_param pcsc_ifd_trans_param;

struct _pcsc_transfer_t {

	pcsc_slot_t *handle;
	uint32_t ioctl;

	uint32_t card_status;

	pcsc_icc_trans_param *icc_trans;
	pcsc_ifd_trans_param *ifd_trans;

	/* IFD/ICC shared it as APDU(R) is same as TPDU(R)  */
	uint8_t *rbuf;
	size_t rbuf_len;
	size_t rbuf_actual;

	/* application data */
	pcsc_appcmd_complete callback;
	void *user_data;
	/* by app/icc/ifd */
	int ret;
};

int pcsc_parse_atr(const char *atr, size_t atr_len, struct pcsc_atr_info *atr_info);
int pcsc_default_proto(const uint8_t *atr, size_t atr_len, int *def_pro);
int pcsc_support_proto(const uint8_t *atr, size_t atr_len, int *supp_proto);
void icc_detect_apdu_cse(pcsc_slot_t *handle, struct icc_apdu *apdu);
int icc_check_apdu(pcsc_slot_t *handle, struct icc_apdu *apdu);
size_t icc_apdu_get_length(const struct icc_apdu *apdu, unsigned int proto);
int icc_apdu2tpdu(const struct icc_apdu *apdu, uint32_t proto,
			 uint8_t *out, size_t outlen);
int pcsc_update_tpdu(pcsc_transfer_t *trans);

int __init pcsc_handle_init(void);
void __exit pcsc_handle_exit(void);
int __init pcsc_ifd_init(void);
void __exit pcsc_ifd_exit(void);

int __init pcsc_icc_init(void);
void __exit pcsc_icc_exit(void);

/* handle API start*/
pcsc_slot_t *pcsc_slot_new(pcsc_ifd_t *ifd, int idx);
void pcsc_slot_free_all(pcsc_ifd_t *ifd);
void pcsc_stop_by_ifd(pcsc_ifd_t *ifd);
void pcsc_start_by_ifd(pcsc_ifd_t *ifd);
void ifd_get_feature(pcsc_ifd_t *ifd);

uint16_t pcsc_idx_by_iccidx(uint16_t iccidx);
pcsc_slot_t *pcsc_get_handle_by_ifd(pcsc_ifd_t *ifd);
pcsc_slot_t *pcsc_get_handle_by_icc(pcsc_icc_t *icc);
pcsc_slot_t *pcsc_slot_get(pcsc_slot_t *hd);
void pcsc_slot_put(pcsc_slot_t *hd);
pcsc_slot_t *pcsc_handle_get_by_idx(uint16_t idx);

int pcsc_transmit(pcsc_transfer_t *trans);
int pcsc_transmit_from_icc(pcsc_transfer_t *trans, pcsc_trans_cb cb);
int pcsc_fetch_sw(pcsc_transfer_t *card_param);

/* handle API stop */
int pcsc_select_file(pcsc_slot_t *hd, struct icc_path *path,
		      	    struct icc_file **file_out,
		      	    pcsc_appcmd_complete cb, void *user_data);
#endif /*__PCSC_PRIV_H__*/
