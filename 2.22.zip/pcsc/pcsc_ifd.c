#include "pcsc_priv.h"

DECLARE_BITMAP(pcsc_reader_idx, PCSC_MAX_READERS);

DECLARE_LIST(pcsc_ifd_list);

#define for_each_ifd(e)		\
	list_for_each_entry(pcsc_ifd_t, e, &pcsc_ifd_list, link)

#define for_each_ifd_hd(hd, ifd)	\
	list_for_each_entry(pcsc_handle_t, hd, &ifd->handles, link)
#define for_each_ifd_hd_safe(hd, n, ifd)	\
	list_for_each_entry_safe(pcsc_handle_t, hd, n, &ifd->handles, link)

static pcsc_ifd_t *ifd_find(const char *name, int type);

static void ifd_free(pcsc_ifd_t *rdr);
static pcsc_ifd_t *ifd_new(const char *name, int type, int slot_num,
			   void *lower, ifd_driver_t *ops);

static int ifd_idx_inuse(int idx);
static int ifd_idx_alloc(void);
static void ifd_idx_free(int idx);

static int ifd_idx_inuse(int id)
{
	return test_bit(id, pcsc_reader_idx);
}

static int ifd_idx_alloc(void)
{
	int i = __find_first_zero_bit(pcsc_reader_idx, PCSC_MAX_READERS);
	if (i >= PCSC_MAX_READERS) {
		pcsc_log(PCSC_LOG_ERR, "IFD: too many reader index allocated");
		return -1;
	}
	__set_bit(i, pcsc_reader_idx);
	return (i);
}

static void ifd_idx_free(int unit)
{
	if (unit >= 0 && unit < PCSC_MAX_READERS)
		__clear_bit(unit, pcsc_reader_idx);
}

pcsc_ifd_t *pcsc_ifd_get(pcsc_ifd_t *rdr)
{
	atomic_inc(&rdr->refcnt);
	return rdr;
}

void pcsc_ifd_put(pcsc_ifd_t *rdr)
{
	atomic_dec(&rdr->refcnt);
}

static pcsc_ifd_t *ifd_find(const char *name, int type)
{
	pcsc_ifd_t *rdr;

	for_each_ifd(rdr) {
		if (strcasecmp(rdr->name, name) == 0 &&
		    rdr->type == type)
		    return rdr;
	}
	return NULL;
}




/*
 * create/initial ifd 
 * and its handler(s) which number depends on slot_num.
 */
static pcsc_ifd_t *ifd_new(const char *name, int type, int slot_num,
			   void *lower, ifd_driver_t *ops)
{
	pcsc_ifd_t *rdr;
	int i;

	rdr = malloc(sizeof (pcsc_ifd_t));
	if (!rdr)
		goto err;

	memset(rdr, 0, sizeof (pcsc_ifd_t));

	rdr->ifd_status = PCSC_IFD_STATUS_PRESENT;
	rdr->nslots = slot_num;
	rdr->type = type;
	rdr->name = strdup(name);
	rdr->ifd_ops = ops;
	/* bind thing? */
	rdr->lower = lower;

	list_init(&rdr->link);
	list_insert_before(&rdr->link, &pcsc_ifd_list);

	atomic_set(&rdr->refcnt, 1);

	rdr->idx = ifd_idx_alloc();
	if (rdr->idx == -1) {
		pcsc_log(PCSC_LOG_WARN, "IFD: most IFD number arrive");
		goto err;
	}
	for (i = 0; i < slot_num; i++) {
		/* new handle will be added to IFD->handle list */
		if (NULL == pcsc_handle_new(rdr, i))
			goto err;
	}

	pcsc_log(PCSC_LOG_DEBUG, 
		 "IFD: new IFD=%d, slot num=%d", rdr->idx, rdr->nslots);
	return rdr;
err:
	ifd_free(rdr);
	return NULL;
}

static void ifd_free(pcsc_ifd_t *rdr)
{
	/* TODO: do not clear STM directly */
	pcsc_handle_free(rdr);

	if (atomic_dec_and_test(&rdr->refcnt)) {
		pcsc_log(PCSC_LOG_DEBUG, 
			 "IFD: free IFD=%d", rdr->idx);
		if (rdr->name) 
			free(rdr->name);
		ifd_idx_free(rdr->idx);
		list_delete(&rdr->link);
		free(rdr);
	}
}

/* lower reader up */
int pcsc_ifd_up(const char *name, int type, void *lower, ifd_driver_t *ops)
{
	pcsc_ifd_t *rdr = ifd_find(name, type);
	int slot_num, ret;

	if (rdr) {
		pcsc_log(PCSC_LOG_INFO, "IFD: ifd=%s/%d has up before",
			name, type);
		BUG();
	}
	if (ops->get_desc_attr) {
		ret = ops->get_desc_attr(lower, PCSC_GET_ATTR_NSLOT, (void *)&slot_num);
		pcsc_log(PCSC_LOG_INFO, "IFD: has %d slot(s)", slot_num);
	} else
		slot_num = 1;	/* force set */

	/* create ifd, icc and ifd_hd */
	rdr = ifd_new(name, type, slot_num, lower, ops);
	
	if (rdr) {
		ifd_hd_get_feature(rdr);
		ifd_hd_start_by_ifd(rdr);
		ifd_hd_detect_icc_loop(rdr);
	}

	return 0;
}

int pcsc_ifd_down(const char *name, int type, void *lower)
{
	pcsc_ifd_t *rdr = ifd_find(name, type);
	
	if (rdr) {
		ifd_hd_detect_icc_loop_stop(rdr);
		ifd_hd_stop_by_ifd(rdr);
		ifd_free(rdr);
	}
	return 0;
}



ui_schema_t pscs_ifd_scheme[] = {
	/* .pcsc.ifd */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".pcsc.ifd", "ifd", "PCSC readers" },

	{ UI_TYPE_NONE },
};


static int pcsc_ifd_cmd_dump(ui_session_t *sess, ui_entry_t *inst,
			     void *ctx, int argc, char **argv)
{
	pcsc_ifd_t *ifd;
	ui_table_t *table = ui_table_by_name(sess, "pcsc_ifd_list");
	char buf[25] = "";
	int i = 0;

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "pcsc_ifd_list");
	if (!table)
		return -1;

	ui_add_title(table, 0, "name");
	ui_add_title(table, 1, "index");
	ui_add_title(table, 2, "nslot");
	ui_add_title(table, 3, "driver");
	OBJ_UI_TABLE_TITLE(table, 4);

	i = 0;

	for_each_ifd(ifd) {
		ui_add_value(table, "name", i, "whichname");
		snprintf(buf, sizeof(buf), "%d", ifd->idx);
		ui_add_value(table, "index", i, buf);
		snprintf(buf, sizeof(buf), "%d", ifd->nslots);
		ui_add_value(table, "nslot", i, buf);
		ui_add_value(table, "driver", i, ifd->ifd_ops->name);
		OBJ_UI_TABLE_VALUE(table, ifd, i, "x");
		i++;
	}
	sess->result_table = table;
	return 0;
}

ui_command_t pscs_ifd_command = {
	"dump",
	"Dump all ifd on the system",
	".pcsc.ifd",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(pscs_ifd_command.link),
	pcsc_ifd_cmd_dump,
};

int __init pcsc_ifd_init(void)
{
	ui_register_schema(pscs_ifd_scheme);
	ui_register_command(&pscs_ifd_command);

	ifd_ccid_init();
	return 0;
}

void __exit pcsc_ifd_exit(void)
{
	ifd_ccid_exit();
	ui_unregister_command(&pscs_ifd_command);
	ui_unregister_schema(pscs_ifd_scheme);
}
