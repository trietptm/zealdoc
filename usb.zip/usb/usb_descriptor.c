#include "usb_priv.h"

#define DESC_HEADER_LENGTH		2
#define DEVICE_DESC_LENGTH		18
#define CONFIG_DESC_LENGTH		9
#define INTERFACE_DESC_LENGTH		9
#define ENDPOINT_DESC_LENGTH		7
#define ENDPOINT_AUDIO_DESC_LENGTH	9

int usbi_parse_descriptor(unsigned char *source, const char *descriptor, 
			  void *dest, int host_endian)
{
	unsigned char *sp = source, *dp = dest;
	uint16_t w;
	const char *cp;

	for (cp = descriptor; *cp; cp++) {
		switch (*cp) {
		case 'b':
			*dp++ = *sp++;
			break;
		case 'w':
			dp += ((unsigned long) dp & 1);/*Align to word boundary*/
			
			if (host_endian) {
				memcpy(dp, sp, 2);
			} else {
				w = (sp[1] << 8) | sp [0];
				*((uint16_t *)dp) = w;
			}
			sp += 2;
			dp += 2;
			break;
		}
	}

	return sp - source;
}

static void clear_endpoint(struct usb_endpoint_descriptor *endpoint)
{
	if (endpoint->extra)
		free((unsigned char *)endpoint->extra);
}

static int parse_endpoint(struct usb_endpoint_descriptor *endpoint,
			  unsigned char *buffer, int size, int host_endian)
{
	struct usb_descriptor_header header;
	unsigned char *extra;
	unsigned char *begin;
	int parsed = 0;
	int len;
	
	usbi_parse_descriptor(buffer, "bb", &header, 0);
	/* Everything should be fine being parsed into here, but we sanity
	 * check JIC*/
	if (header.bLength > size) return -1;
	if (header.bDescriptorType != USB_DT_ENDPOINT)  return parsed;

	if (header.bLength >= ENDPOINT_AUDIO_DESC_LENGTH)
		usbi_parse_descriptor(buffer, "bbbbwbbb", endpoint, host_endian);
	else if (header.bLength >= ENDPOINT_DESC_LENGTH)
		usbi_parse_descriptor(buffer, "bbbbwb", endpoint, host_endian);
	buffer += header.bLength;
	parsed += header.bLength;
	size -= header.bLength;

	begin = buffer;
	while (size >= DESC_HEADER_LENGTH) {
		usbi_parse_descriptor(buffer, "bb", &header, 0);

		if (header.bLength < 2) return -1;

		if ((header.bDescriptorType == USB_DT_INTERFACE)
			|| (header.bDescriptorType == USB_DT_ENDPOINT)
			|| (header.bDescriptorType == USB_DT_CONFIG)
			|| (header.bDescriptorType == USB_DT_DEVICE))
			break;
		
		buffer += header.bLength;
		parsed += header.bLength;
		size -= header.bLength;
	}

	len = (int)(buffer - begin);
	if (!len) {
		endpoint->extra = NULL;
		endpoint->extra_length = 0;
		return parsed;
	}
	extra = malloc(len);
	endpoint->extra = extra;
	if (!extra) {
		endpoint->extra_length = 0;
		return USB_ERROR_NO_MEM;
	}
	memcpy(extra, begin, len);
	endpoint->extra_length = len;

	return parsed;
}

static void clear_interface(struct usb_interface *intfc)
{
	int i, j;

	if (intfc->altsetting) {
		for (i = 0; i < intfc->num_altsetting; i++) {
			struct usb_interface_descriptor *ifp =
				(struct usb_interface_descriptor *)
				intfc->altsetting + i;
			if (ifp->extra)
				free((void *)ifp->extra);
			if (ifp->endpoint) {
				for (j = 0; j < ifp->bNumEndpoints; j++) {
					clear_endpoint((struct usb_endpoint_descriptor *)
						ifp->endpoint + j);
				}
				free((void *)ifp->endpoint);
			}
		}
		free((void *) intfc->altsetting);
	}
}

static int parse_interface(struct usb_interface *intfc, 
			   unsigned char *buffer, int size,
			   int host_endian)
{
	int i, len, r, tmp, parsed = 0;
	struct usb_descriptor_header header;
	struct usb_interface_descriptor *ifp;
	unsigned char *begin;

	intfc->num_altsetting = 0;

	while (size >= INTERFACE_DESC_LENGTH) {
		struct usb_interface_descriptor *altsetting =
			(struct usb_interface_descriptor *) intfc->altsetting;
		altsetting = realloc(altsetting, 
				sizeof(struct usb_interface_descriptor) *
				(intfc->num_altsetting + 1));
		if (!altsetting) {
			r = USB_ERROR_NO_MEM;
			goto err;
		}
		intfc->altsetting = altsetting;

		ifp = altsetting + intfc->num_altsetting;
		intfc->num_altsetting++;
		usbi_parse_descriptor(buffer, "bbbbbbbbb", ifp, 0);
		ifp->extra = NULL;
		ifp->extra_length = 0;
		ifp->endpoint = NULL;

		/*Skip over the interface*/
		buffer += ifp->bLength;
		parsed += ifp->bLength;
		size -= ifp->bLength;

		begin = buffer;

		while (size >= DESC_HEADER_LENGTH) {
			usbi_parse_descriptor(buffer, "bb", &header, 0);
			if (header.bLength < 2) {
				r = USB_ERROR_IO;
				goto err;
			}

			/* If we find another "proper" descriptor then we're done*/
			if ((header.bDescriptorType == USB_DT_INTERFACE)
				|| (header.bDescriptorType == USB_DT_ENDPOINT)
				|| (header.bDescriptorType == USB_DT_CONFIG)
				|| (header.bDescriptorType == USB_DT_DEVICE))
				break;
			buffer += header.bLength;
			parsed += header.bLength;
			size -= header.bLength;
		}
		
		/* Copy any unknow descriptor into a storage area for 
		 * driver to later parse*/
		len = (int) (buffer - begin);
		if (len) {
			ifp->extra = malloc(len);
			if (!ifp->extra) {
				r = USB_ERROR_NO_MEM;
				goto err;
			}
			memcpy((unsigned char *)ifp->extra, begin, len);
			ifp->extra_length = len;
		}

		/*Did we hit an unexpected descriptor?*/
		usbi_parse_descriptor(buffer, "bb", &header, 0);
		if ((size >= DESC_HEADER_LENGTH) &&
			((header.bDescriptorType == USB_DT_CONFIG) ||
			 (header.bDescriptorType == USB_DT_CONFIG)))
			 return parsed;

		if (ifp->bNumEndpoints > USB_MAX_ENDPOINTS) {
			r = USB_ERROR_IO;
			goto err;
		}
		if (ifp->bNumEndpoints > 0) {
			struct usb_endpoint_descriptor *endpoint;

			tmp = ifp->bNumEndpoints * sizeof(struct usb_endpoint_descriptor);
			endpoint = malloc(tmp);
			if (!endpoint) {
				r = USB_ERROR_NO_MEM;
				goto err;
			}
			memset(endpoint, 0, tmp);
			ifp->endpoint = endpoint;
			for (i = 0; i < ifp->bNumEndpoints; i++) {
				usbi_parse_descriptor(buffer, "bb", &header, 0);

				if (header.bLength > size) {
					r = USB_ERROR_IO;
					goto err;
				}

				r = parse_endpoint(endpoint + i, buffer, size,
						   host_endian);
				if (r < 0)
					goto err;
				buffer += r;
				parsed += r;
				size -= r;
			}
		}
		
		/* We check to see if it is an alternate to this one */
		ifp = (struct usb_interface_descriptor *)buffer;
		if (size < USB_DT_INTERFACE_SIZE ||
			ifp->bDescriptorType != USB_DT_INTERFACE ||
			!ifp->bAlternateSetting)
			return parsed;
	}
	return parsed;
err:
	clear_interface(intfc);
	return r;
}

void usbi_clear_configuration(struct usb_config_descriptor *config)
{
	if (config->intfc) {
		int i;
		for (i = 0; i < config->bNumInterfaces; i++) {
			clear_interface((struct usb_interface *)
				config->intfc + i);
			free((void *) config->intfc);
		}
	}
	if (config->extra)
		free((void *)config->extra);
}

int usbi_parse_configuration(struct usb_config_descriptor *config,
			     unsigned char *buffer, int host_endian)
{
	int i;
	int r;
	int size;
	int tmp;
	struct usb_descriptor_header header;
	struct usb_interface *intfc;

	usbi_parse_descriptor(buffer, "bbwbbbbb", config, host_endian);
	size = config->wTotalLength;

	if (config->bNumInterfaces > USB_MAX_INTERFACES)
		return USB_ERROR_IO;

	tmp = config->bNumInterfaces * sizeof(struct usb_interface);
	intfc = malloc(tmp);
	if (!intfc) 
		return USB_ERROR_NO_MEM;
	config->intfc = intfc;

	memset(intfc, 0, tmp);
	buffer += config->bLength;
	size -= config->bLength;

	config->extra = NULL;
	config->extra_length = 0;

	for (i = 0; i < config->bNumInterfaces; i++) {
		int len;
		unsigned char *begin;

		/* Skip over the rest of the class specific or vendor*/
		/* Specific descriptors*/
		begin = buffer;
		while (size >= DESC_HEADER_LENGTH) {
			usbi_parse_descriptor(buffer, "bb", &header, 0);

			if ((header.bLength > size) ||
				(header.bLength < DESC_HEADER_LENGTH)) {
				r = USB_ERROR_IO;
				goto err;
			}

			/* If we find another "proper" descriptor then we're done*/
			if ((header.bDescriptorType == USB_DT_ENDPOINT) 
			     || (header.bDescriptorType == USB_DT_INTERFACE)
			     || (header.bDescriptorType == USB_DT_CONFIG) 
			     ||	(header.bDescriptorType == USB_DT_DEVICE))
				break;
			buffer += header.bLength;
			size -= header.bLength;
		}

		/* Copy any unknow descriptors into a storage area for 
		 * drivers to later parse*/
		len = (int)(buffer - begin);
		if (len) {
			/*FIXME: We should realloc and append here*/
			if (!config->extra_length) {
				config->extra = malloc(len);
				if (!config->extra) {
					r = USB_ERROR_NO_MEM;
					goto err;
				}
				memcpy((unsigned char *)config->extra, begin, len);
				config->extra_length = len;
			}
		}

		r = parse_interface(intfc + i, buffer, size, host_endian);
		if (r < 0)
			goto err;
		buffer += r;
		size -= r;
	}

	return size;

err:
	usbi_clear_configuration(config);
	return r;
}
