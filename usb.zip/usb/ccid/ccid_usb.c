#include "ccid_usb.h"

static const struct usb_interface_descriptor *
	get_ccid_usb_interface(struct usb_device *usb_dev,
			       uint8_t *config_value)
{
	int c, i, s;
	
	if (usb_dev->active_config == -1)
		return NULL;
#if 0
	/* some buggy devices have a configuration 0, but we're
	 * reaching into the corner of a corner case here, so let's
	 * not support buggy devices in these circumstances.
	 * stick to the specs: a configuration value of 0 means
	 * unconfigured. */
	if (usb_dev->active_config == 0)
		return NULL;
#endif
	for(c = 0; c < usb_dev->dev_desc->bNumConfigurations; c++) {
		const struct usb_config_descriptor *config_desc;

		config_desc = &usb_dev->config_desc[c];
#if 0
		if (config_desc->bConfigurationValue != usb_dev->active_config)
			continue;
#endif
		for (i = 0; i < config_desc->bNumInterfaces; i++) {
			const struct usb_interface *intfc;
			
			intfc = &config_desc->intfc[i];
			for (s = 0; s < intfc->num_altsetting; s++) {
				const struct usb_interface_descriptor *altsetting;

				altsetting = &intfc->altsetting[s];
				if (altsetting->bInterfaceClass == USB_CLASS_SMART_CARD) {
					*config_value = config_desc->bConfigurationValue;
					return altsetting;
				}
			}
		}
	}

	return NULL;
}

static int get_endpoints(struct usb_device *usb_dev,
			 const struct usb_interface_descriptor *altsetting)
{
	int e;

	if (altsetting->bInterfaceProtocol != 0x00)
		return CCID_SUCCESS;
	
	for (e = 0; e < altsetting->bNumEndpoints; e++) {
		const struct usb_endpoint_descriptor *ep;
		
		ep = &altsetting->endpoint[e];

		if ((ep->bmAttributes & USB_TRANSFER_TYPE_MASK)
			== USB_TRANSFER_TYPE_BULK) {			
			if ((ep->bEndpointAddress & USB_ENDPOINT_DIR_MASK)
				== USB_ENDPOINT_IN)
				usb_dev->ep_i = ep->bEndpointAddress;
			else if ((ep->bEndpointAddress & USB_ENDPOINT_DIR_MASK)
				== USB_ENDPOINT_OUT)
				usb_dev->ep_o = ep->bEndpointAddress;
		} else if ((ep->bmAttributes & USB_TRANSFER_TYPE_MASK)
			== USB_TRANSFER_TYPE_INTERRUPT) {
			usb_dev->ep_intr = ep->bEndpointAddress;
		} 
	}
	return CCID_SUCCESS;
}

static int usb_parse_ccid_descriptor(const uint8_t *src, size_t len,
				 struct ccid_descriptor *ccid_desc)
{
	ccid_desc->bLength = src[0];
	if (ccid_desc->bLength < USB_CCID_DESCRIPTOR_LENGTH)
		return -1;
	ccid_desc->bDescriptorType = src[1];
	ccid_desc->bcdCCID = (src[3] << 8) & src[2];
	ccid_desc->bMaxSlotIndex = src[4];
	ccid_desc->bVoltageSupport = src[5];
	ccid_desc->dwProtocols = 
		src[9] << 24 | src[8] << 16 | src[7] << 8 | src[6];
	ccid_desc->dwDefaultClock = 
		src[13] << 24 | src[12] << 16 | src[11] << 8 | src[10];
	ccid_desc->dwMaximumClock = 
		src[17] << 24 | src[16] << 16 | src[15] << 8 | src[14];
	ccid_desc->bNumClockSupported = src[18];
	ccid_desc->dwDataRate = 
		src[22] << 24 | src[21] << 16 | src[20] << 8 | src[19];
	ccid_desc->dwMaxDataRate = 
		src[26] << 24 | src[25] << 16 | src[24] << 8 | src[23];
	ccid_desc->bNumDataRatesSupported = src[27];
	ccid_desc->dwMaxIFSD = 
		src[31] << 24 | src[30] << 16 | src[29] << 8 | src[28];
	ccid_desc->dwSynchProtocols = 
		src[35] << 24 | src[34] << 16 | src[33] << 8 | src[32];
	ccid_desc->dwMechanical = 
		src[39] << 24 | src[38] << 16 | src[37] << 8 | src[36];
	ccid_desc->dwFeatures = 
		src[43] << 24 | src[42] << 16 | src[41] << 8 | src[40];
	ccid_desc->dwMaxCCIDMessageLength = 
		src[47] << 24 | src[46] << 16 | src[45] << 8 | src[44];
	ccid_desc->bClassGetResponse = src[48];
	ccid_desc->bClassEnvelope = src[49];
	ccid_desc->wLcdLayout = src[51] << 8 | src[50];
	ccid_desc->bPINSupport = src[52];
	ccid_desc->bMaxCCIDBusySlots = src[53];

	return 0;
}

int ccid_usb_open(const char *file_name, struct ccid_handle *hccid)
{
	usb_device_t *usb_dev;
	const struct usb_interface_descriptor *altsetting;
	usb_intfc_t *intfc;
	int r;
	uint8_t active_config;
	
	usb_dev = usb_get_device(file_name);
	if (!usb_dev)
		return CCID_ERROR_GENERIC;

	r = usb_open(usb_dev);
	if (r != USB_SUCCESS) {
		usb_put_device(usb_dev);
		if (r == USB_ERROR_NO_DEVICE)
			return CCID_ERROR_NO_DEVICE;
		else if (r == USB_ERROR_HAS_OPENED) 
			return CCID_ERROR_BUSY;
		else if (r == USB_ERROR_INVALID_HANLDE)
			return CCID_ERROR_NO_DEVICE;
		else 
			return CCID_ERROR_GENERIC;
	}
	
	altsetting = get_ccid_usb_interface(usb_dev, &active_config);
	if (!altsetting) {
		usb_close(usb_dev);
		return CCID_ERROR_NO_DEVICE;
	}
	
	r = usb_parse_ccid_descriptor(altsetting->extra, altsetting->extra_length, 
				  &hccid->ccid_desc);
	if (r != 0) {
		usb_close(usb_dev);
		return CCID_ERROR_NO_DEVICE;
	}

	/* Don't touch the device configuration if it's the one and only.
	 * The reason for this is that in multi purpose devices(e.g. keyboards,
	 * with and integrated reader) some interfaces might already be in use.
	 * Trying to change the device configuration in such a case will 
	 * produce this kernel message on Linux:
	 *	usbfs: interface X claimed while 'ifdhandler' sets config #N
	 *
	 * FIXME: On windows, you should first set config before claim intfc.
	 */
#ifdef WIN32
	r = usb_set_configuration(usb_dev, active_config);
	if (r != USB_SUCCESS) {
		usb_close(usb_dev);
		return r;
	} else {
		ccid_log(CCID_LOG_DEBUG, "set config %d success", 
				usb_dev->active_config);
	}
#endif

	intfc = usb_get_intfc_by_altsetting(usb_dev, altsetting);

	r = usb_claim_interface(intfc);
	if (r != USB_SUCCESS) {
		ccid_log(CCID_LOG_DEBUG, "Can't claim intfc: %s: %d", 
			 usb_dev->filename, r);
		usb_close(usb_dev);
		return r;
	}

	switch (altsetting->bInterfaceProtocol) {
	case 0x00:
		hccid->intfc_proto = CCID_INTFC_PROTO_BULK;
		r = get_endpoints(usb_dev, altsetting);
		break;
	case 0x01:
		hccid->intfc_proto = CCID_INTFC_PROTO_CTRL_A;
		break;
	case 0x02:
		hccid->intfc_proto = CCID_INTFC_PROTO_CTRL_B;
		break;
	default:
		r = CCID_ERROR_NOT_SUPPORTED;
		break;
	}
	if (r != CCID_SUCCESS) {
		usb_release_interface(usb_dev, altsetting->bInterfaceNumber);
		usb_close(usb_dev);
		return r;
	}
	
	hccid->handle.usb_handle = usb_dev;

	return CCID_SUCCESS;	
}

void ccid_usb_close(struct ccid_handle *hccid)
{
	/* FIXME: 0 is just for now */
	usb_release_interface(hccid->handle.usb_handle, 0);
	usb_put_device(hccid->handle.usb_handle);
	usb_close(hccid->handle.usb_handle);
}


int ccid_usb_cancel(struct ccid_handle *hccid)
{
	if (usb_cancel(hccid->handle.usb_handle) != USB_SUCCESS)
		return CCID_ERROR_COMMUNICATION;
	else
		return CCID_SUCCESS;
}

static void i2dw(int value, unsigned char buffer[])
{
	buffer[0] = value & 0xFF;
	buffer[1] = (value >> 8) & 0xFF;
	buffer[2] = (value >> 16) & 0xFF;
	buffer[3] = (value >> 24) & 0xFF;
}

static int ccid_select_voltage(struct ccid_handle *handle, uint8_t *voltage)
{
	/* FIXME: how to comfirm the voltage ? ccid->desc->bVoltageSupported ? */
	*voltage = CCID_VOLTAGE_5V;

	return CCID_SUCCESS;
}

static int usb_fill_xfrblock(uint8_t *cmd_buf, size_t dwLength, 
				   uint8_t bSlot, uint8_t bSeq, 
				   uint16_t wLevelParameter, const uint8_t *data)
{
	cmd_buf[0] = PC_TO_RDR_XFRBLOCK;
	i2dw(dwLength, cmd_buf + 1);
	cmd_buf[5] = bSlot;
	cmd_buf[6] = bSeq;
	cmd_buf[7] = 0x00;
	cmd_buf[8] = wLevelParameter & 0xFF;
	cmd_buf[9] = (wLevelParameter >> 8) & 0xFF;
	memcpy(cmd_buf + 10, data, dwLength);
	
	return CCID_SUCCESS;
}

static int usb_fill_poweron(uint8_t *cmd_buf,uint8_t bSlot, 
					 uint8_t bSeq, uint8_t bPowerSelect)
{
	cmd_buf[0] = PC_TO_RDR_ICCPOWERON;
	cmd_buf[1] = 0x00;
	cmd_buf[2] = 0x00;
	cmd_buf[3] = 0x00;
	cmd_buf[4] = 0x00;
	cmd_buf[5] = bSlot;
	cmd_buf[6] = bSeq;
	cmd_buf[7] = bPowerSelect;
	cmd_buf[8] = 0x00;
	cmd_buf[9] = 0x00;
	
	return CCID_SUCCESS;
}

static int usb_fill_poweroff(uint8_t *cmd_buf, uint8_t bSlot,
					  uint8_t bSeq)
{
	cmd_buf[0] = PC_TO_RDR_ICCPOWEROFF;
	cmd_buf[1] = 0x00;
	cmd_buf[2] = 0x00;
	cmd_buf[3] = 0x00;
	cmd_buf[4] = 0x00;
	cmd_buf[5] = bSlot;
	cmd_buf[6] = bSeq;
	cmd_buf[7] = 0x00;
	cmd_buf[8] = 0x00;
	cmd_buf[9] = 0x00;
	
	return CCID_SUCCESS;
}

static int usb_fill_getslotstatus(uint8_t *cmd_buf, uint8_t bSlot,
					       uint8_t bSeq)
{
	cmd_buf[0] = PC_TO_RDR_GETSLOTSTATUS;
	cmd_buf[1] = 0x00;
	cmd_buf[2] = 0x00;
	cmd_buf[3] = 0x00;
	cmd_buf[4] = 0x00;
	cmd_buf[5] = bSlot;
	cmd_buf[6] = bSeq;
	cmd_buf[7] = 0x00;
	cmd_buf[8] = 0x00;
	cmd_buf[9] = 0x00;
	
	return CCID_SUCCESS;
}

static int usb_fill_secure(uint8_t *cmd_buf, size_t dwLength, 
				   uint8_t bSlot, uint8_t bSeq, 
				   uint16_t wLevelParameter, const uint8_t *data)
{
	cmd_buf[0] = PC_TO_RDR_SECURE;
	i2dw(dwLength, cmd_buf + 1);
	cmd_buf[5] = bSlot;
	cmd_buf[6] = bSeq;
	cmd_buf[7] = 0x00;
	cmd_buf[8] = wLevelParameter & 0xFF;
	cmd_buf[9] = (wLevelParameter >> 8) & 0xFF;
	memcpy(cmd_buf + 10, data, dwLength);
	
	return CCID_SUCCESS;
}

static int usb_fill_bulk_cmd(struct ccid_transfer *ccid_trans)
{
	size_t max_len;
	struct ccid_descriptor *ccid_desp;
	uint8_t voltage;
	
	ccid_desp = &ccid_trans->handle->ccid_desc;

	/* FIXME: It should check the len before alloc transfer. */
	max_len = (ccid_desp->dwMaxCCIDMessageLength - 10) < CMD_BUF_SIZE ?
		  (ccid_desp->dwMaxCCIDMessageLength - 10) : CMD_BUF_SIZE;
	memset(ccid_trans->cmd_buf, 0, sizeof(ccid_trans->cmd_buf));
	switch (ccid_trans->cmd_out) {
	case PC_TO_RDR_XFRBLOCK:
		if (ccid_trans->param->sbuf_len > max_len)
			return CCID_ERROR_COMMUNICATION;
		
		usb_fill_xfrblock(ccid_trans->cmd_buf, 
			ccid_trans->param->sbuf_len, 
			ccid_trans->handle->bslot, (ccid_trans->handle->bseq)++,
			ccid_trans->wLevelParameter, 
			ccid_trans->param->sbuf);
		ccid_trans->cmd_buf_len = 10 + ccid_trans->param->sbuf_len;
		break;
	case PC_TO_RDR_ICCPOWERON:
		ccid_select_voltage(ccid_trans->handle, &voltage);
		usb_fill_poweron(ccid_trans->cmd_buf, 
				 ccid_trans->handle->bslot, 
				 (ccid_trans->handle->bseq)++, voltage);
		ccid_trans->cmd_buf_len = 10;
		break;
	case PC_TO_RDR_ICCPOWEROFF:
		usb_fill_poweroff(ccid_trans->cmd_buf, 
				  ccid_trans->handle->bslot,
				  (ccid_trans->handle->bseq)++);
		ccid_trans->cmd_buf_len = 10;
		break;
	case PC_TO_RDR_GETSLOTSTATUS:
		usb_fill_getslotstatus(ccid_trans->cmd_buf, 
				       ccid_trans->handle->bslot,
				       (ccid_trans->handle->bseq)++);
		ccid_trans->cmd_buf_len = 10;
		break;
	case PC_TO_RDR_SECURE:
		usb_fill_secure(ccid_trans->cmd_buf,
				ccid_trans->param->sbuf_len,
				ccid_trans->handle->bslot,
				(ccid_trans->handle->bseq)++,
				ccid_trans->wLevelParameter,
				ccid_trans->param->sbuf);
		ccid_trans->cmd_buf_len = 10 + ccid_trans->param->sbuf_len;

	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}

	return CCID_SUCCESS;
}

int ccid_usb_fill_cmd(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->handle->intfc_proto) {
	case CCID_INTFC_PROTO_BULK:
		return usb_fill_bulk_cmd(ccid_trans);
	case CCID_INTFC_PROTO_CTRL_A:
	case CCID_INTFC_PROTO_CTRL_B:
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}

static void usb_bulk_write_callback(struct usb_trans_params *usb_param)
{
	struct ccid_transfer *ccid_trans = 
			(struct ccid_transfer *)usb_param->user_data;

	switch (usb_param->ret) {
	case USB_SUCCESS:
		ccid_trans->param->ret = CCID_SUCCESS;
		break;
	case USB_ERROR_PIPE:
		ccid_trans->param->ret = CCID_ERROR_STALL;
		break;
	case USB_ERROR_NO_DEVICE:
		ccid_trans->param->ret = CCID_ERROR_NO_DEVICE;
		break;
	case USB_ERROR_TIMEOUT:
		ccid_trans->param->ret = CCID_ERROR_TIMEOUT;
		break;
	case USB_ERROR_CANCELLED:
		ccid_trans->param->ret = CCID_ERROR_CANCELLED;
		break;
	case USB_ERROR_OVERFLOW:
		ccid_trans->param->ret = CCID_ERROR_OVERFLOW;
		break;
	default:
		ccid_trans->param->ret = CCID_ERROR_GENERIC;
		break;
	}
	if (usb_param->ret ==  USB_SUCCESS)
		ccid_stm_raise_sts(ccid_trans);
	else
		ccid_stm_raise_stf(ccid_trans);

	free(usb_param);
}

static int ccid_usb_bulk_write(struct ccid_transfer *ccid_trans)
{
	struct usb_trans_params *usb_param;
	int r;
	char out_debug[(10 + CMD_BUF_SIZE) * 3];
	size_t i;
	
	usb_param = malloc(sizeof(struct usb_trans_params));
	if (!usb_param)
		return CCID_ERROR_NO_MEM;
	memset(usb_param, 0, sizeof(struct usb_trans_params));

	usb_param->dev_handle = ccid_trans->handle->handle.usb_handle;
	usb_param->ep = ccid_trans->handle->handle.usb_handle->dev->ep_o;
	usb_param->buf = ccid_trans->cmd_buf;
	usb_param->buf_len = ccid_trans->cmd_buf_len;
	usb_param->user_data = ccid_trans;

	memset(out_debug, 0, sizeof(out_debug));
	for (i = 0; i < usb_param->buf_len; i++) {
		sprintf(out_debug + 3 * i, "%02X ", usb_param->buf[i]);
	}
	ccid_log(CCID_LOG_DEBUG, "---> %s", out_debug);

	r = usb_bulk_write(usb_param, usb_bulk_write_callback);
	if (r != USB_SUCCESS) {
		free(usb_param);
		return CCID_ERROR_GENERIC;
	}
	return CCID_SUCCESS;
}

int ccid_usb_send_transfer(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->handle->intfc_proto) {
	case CCID_INTFC_PROTO_BULK:
		return ccid_usb_bulk_write(ccid_trans);
	case CCID_INTFC_PROTO_CTRL_A:
	case CCID_INTFC_PROTO_CTRL_B:
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}

static void usb_bulk_read_callback(struct usb_trans_params *usb_param)
{
	struct ccid_transfer *ccid_trans = 
			(struct ccid_transfer *)usb_param->user_data;
	char out_debug[(10 + CMD_BUF_SIZE) * 3];
	size_t i;

	switch (usb_param->ret) {
	case USB_SUCCESS:
		memset(out_debug, 0, sizeof(out_debug));
		for (i = 0; i < usb_param->rbuf_actual; i++) {
			sprintf(out_debug + 3 * i, "%02X ", usb_param->buf[i]);
		}
		ccid_log(CCID_LOG_DEBUG, "<--- %s", out_debug);
		
		ccid_trans->cmd_buf_actual += usb_param->rbuf_actual;
		ccid_trans->param->ret = CCID_SUCCESS;
		break;
	case USB_ERROR_PIPE:
		ccid_trans->param->ret = CCID_ERROR_STALL;
		break;
	case USB_ERROR_NO_DEVICE:
		ccid_trans->param->ret = CCID_ERROR_NO_DEVICE;
		break;
	case USB_ERROR_TIMEOUT:
		ccid_trans->param->ret = CCID_ERROR_TIMEOUT;
		break;
	case USB_ERROR_CANCELLED:
		ccid_trans->param->ret = CCID_ERROR_CANCELLED;
		break;
	case USB_ERROR_OVERFLOW:
		ccid_trans->param->ret = CCID_ERROR_OVERFLOW;
		break;
	default:
		ccid_trans->param->ret = CCID_ERROR_GENERIC;
		break;
	}
	if (usb_param->ret ==  USB_SUCCESS)
		ccid_stm_raise_rrs(ccid_trans);
	else
		ccid_stm_raise_rrf(ccid_trans);	

	free(usb_param);
}

static int ccid_usb_bulk_read(struct ccid_transfer *ccid_trans)
{
	struct usb_trans_params *usb_param;
	int r;
	
	usb_param = malloc(sizeof(struct usb_trans_params));
	if (!usb_param)
		return CCID_ERROR_NO_MEM;

	usb_param->dev_handle = ccid_trans->handle->handle.usb_handle;
	usb_param->ep = ccid_trans->handle->handle.usb_handle->dev->ep_i;
	usb_param->buf = ccid_trans->cmd_buf;
	usb_param->buf_len = sizeof(ccid_trans->cmd_buf);
	usb_param->user_data = ccid_trans;

	r = usb_bulk_read(usb_param, usb_bulk_read_callback);
	if (r != USB_SUCCESS) {
		free(usb_param);
		return CCID_ERROR_GENERIC;
	}
	return CCID_SUCCESS;
}

int ccid_usb_reap_transfer(struct ccid_transfer *ccid_trans)
{
	switch (ccid_trans->handle->intfc_proto) {
	case CCID_INTFC_PROTO_BULK:
		return ccid_usb_bulk_read(ccid_trans);
	case CCID_INTFC_PROTO_CTRL_A:
	case CCID_INTFC_PROTO_CTRL_B:
		return CCID_ERROR_NOT_SUPPORTED;
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}

int ccid_usb_fill_control(uint8_t request_class, uint8_t request, 
			  uint8_t *data, size_t data_len,
			  struct ccid_usb_control_param *control_param)
{
	switch (request_class) {
	case USB_REQUEST_TYPE_STANDARD:
		control_param->bmRequestType = USB_REQUEST_TYPE_STANDARD;
		switch (request){
		case USB_REQUEST_GET_CONFIGURATION:
			if (data_len != 1)
				return CCID_ERROR_INVALID_ARG;
			control_param->bmRequestType |= 
				USB_ENDPOINT_IN | USB_RECIPIENT_DEVICE;
			control_param->bRequest = USB_REQUEST_GET_CONFIGURATION;
			control_param->wValue = 0x0000;
			control_param->wIndex = 0x0000;
			control_param->wLength = 0x0001;
			control_param->data = data;
			break;
		default:
			return CCID_ERROR_NOT_SUPPORTED;
		}
		break;
	case USB_REQUEST_TYPE_CLASS:
		return CCID_ERROR_NOT_SUPPORTED;
	case USB_REQUEST_TYPE_VENDOR:
		return CCID_ERROR_NOT_SUPPORTED;
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}

	return CCID_SUCCESS;
}

static void control_trans_callback(struct usb_trans_params *usb_param)
{
	struct ccid_usb_control_param *control_param = usb_param->user_data;
	struct ccid_trans_param *ccid_param = 
			(struct ccid_trans_param *)control_param->user_data;

	if (usb_param->ret == USB_SUCCESS) {
		ccid_param->ret = CCID_SUCCESS;
		memcpy(control_param->data, 
			usb_param->buf + sizeof(struct usb_control_setup),
			usb_param->buf_len - sizeof(struct usb_control_setup));
	} else {
		ccid_param->ret = CCID_ERROR_COMMUNICATION;
	}

	control_param->callback(ccid_param);

	free(control_param);
	free(usb_param->buf);
	free(usb_param);
}

int ccid_usb_control_transfer(usb_device_t *usb_handle, 
			      struct ccid_usb_control_param *control_param)
{

	struct usb_control_setup *setup;
	struct usb_trans_params *usb_param;
	uint8_t *cmd_buf;
	size_t cmd_len;
	int r;

	cmd_len = sizeof(struct usb_control_setup) + control_param->wLength;
	cmd_buf = malloc(cmd_len);
	if (!cmd_buf)
		return CCID_ERROR_NO_MEM;
	memset(cmd_buf, 0, cmd_len);

	setup = (struct usb_control_setup *)cmd_buf;
	setup->bmRequestType = control_param->bmRequestType;
	setup->bRequest = control_param->bRequest;
	setup->wValue = usb_cpu_to_le16(control_param->wValue);
	setup->wIndex = usb_cpu_to_le16(control_param->wIndex);
	setup->wLength = usb_cpu_to_le16(control_param->wLength);
	if (control_param->wLength)
		memcpy(setup->data, control_param->data, control_param->wLength);

	usb_param = malloc(sizeof(struct usb_trans_params));
	if (!usb_param) {
		free(cmd_buf);
		return USB_ERROR_NO_MEM;
	}
	memset(usb_param, 0, sizeof(struct usb_trans_params));

	usb_param->dev_handle = usb_handle;
	usb_param->ep = USB_ENDPOINT_CONTROL;
	usb_param->buf = cmd_buf;
	usb_param->buf_len = cmd_len;
	usb_param->user_data = control_param;

	r = usb_control_transfer(usb_param, control_trans_callback);
	if (r != USB_SUCCESS) {
		free(cmd_buf);
		free(usb_param);
	}

	return r;
}