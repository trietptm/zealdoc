#ifndef __CCID_USB_H__
#define __CCID_USB_H__
#include "ccid_priv.h"

enum ccid_usb_intfc_protocol {
	CCID_USB_INTFC_PROTO_BULK	= 0x00,
	CCID_USB_INTFC_PROTO_CTRL_A	= 0x01,
	CCID_USB_INTFC_PROTO_CTRL_B	= 0x02,
};

struct ccid_usb_control_param {
	uint8_t		bmRequestType;
	uint8_t		bRequest;
	uint16_t	wValue;
	uint16_t	wIndex;
	uint16_t	wLength;
	uint8_t		*data;

	ccid_transfer_complete callback;
	void *user_data;
};


int ccid_usb_open(const char *file_name, struct ccid_handle *hccid);
void ccid_usb_close(struct ccid_handle *hccid);
int ccid_usb_cancel(struct ccid_handle *hccid);

int ccid_usb_fill_cmd(struct ccid_transfer *ccid_trans);

int ccid_usb_send_transfer(struct ccid_transfer *ccid_trans);
int ccid_usb_reap_transfer(struct ccid_transfer *ccid_trans);

int ccid_usb_fill_control(uint8_t request_class, uint8_t request, 
			  uint8_t *data, size_t data_len,
			  struct ccid_usb_control_param *control_param);
int ccid_usb_control_transfer(usb_device_t *usb_handle, 
			      struct ccid_usb_control_param *control_param);

#endif /*__CCID_USB_H__*/
