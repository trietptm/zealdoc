#include "ccid_priv.h"

int ccid_logger = 0;
log_source_t ccid_log_source = {
	"ccid"
};

void ccid_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(ccid_logger, level, format, ap);
	va_end(ap);
}

#define DEBUG_BUF_SIZE ((256+20)*3+10)

void ccid_log_xxd(int level, const char *msg, const unsigned char *buffer,
	const int len)
{
	char DebugBuffer[DEBUG_BUF_SIZE];
	int i;
	char *c, *debug_buf_end;

	debug_buf_end = DebugBuffer + DEBUG_BUF_SIZE - 5;
	
	strncpy(DebugBuffer, msg, sizeof(DebugBuffer)-1);
	c = DebugBuffer + strlen(DebugBuffer);
	for (i = 0; (i < len) && (c < debug_buf_end); ++i) {
		sprintf(c, "%02X ", (unsigned char)buffer[i]);
		c += strlen(c);
	}
	ccid_log(level, "%s", DebugBuffer);
}

static int __init ccid_log_init(void)
{
	ccid_logger = log_register_source(&ccid_log_source);
	return !ccid_logger;
}

static void __exit ccid_log_exit(void)
{
	log_unregister_source(ccid_logger);
}


#define CCID_TOOLS_DESP	"ccid"

ui_argument_t ccid_filename_args = {
	"filename",
	"reader name",
	NULL,
	UI_TYPE_STRING,

};

ui_argument_t ccid_reader_idx_args = {
	"reader_index",
	"reader index",
	NULL,
	UI_TYPE_STRING,

};

ui_command_t ccid_open_command = {
	"open",
	"open smartcard reader",
	".ccid",
	UI_CMD_SINGLE_INST,
	&ccid_filename_args,
	1,
	LIST_HEAD_INIT(ccid_open_command.link),
	ccid_tool_open,
};


ui_command_t ccid_close_command = {
	"close",
	"close smartcard reader",
	".ccid",
	UI_CMD_SINGLE_INST,
	&ccid_reader_idx_args,
	1,
	LIST_HEAD_INIT(ccid_close_command.link),
	ccid_tool_close,
};

ui_command_t ccid_poweron_command = {
	"poweron",
	"poweron smartcard",
	".ccid",
	UI_CMD_SINGLE_INST,
	&ccid_reader_idx_args,
	1,
	LIST_HEAD_INIT(ccid_poweron_command.link),
	ccid_tool_poweron,
};

ui_command_t ccid_poweroff_command = {
	"poweroff",
	"poweroff smartcard",
	".ccid",
	UI_CMD_SINGLE_INST,
	&ccid_reader_idx_args,
	1,
	LIST_HEAD_INIT(ccid_poweroff_command.link),
	ccid_tool_poweroff,
};

ui_command_t ccid_icc_status_command = {
	"icc_status",
	"icc status",
	".ccid",
	UI_CMD_SINGLE_INST,
	&ccid_reader_idx_args,
	1,
	LIST_HEAD_INIT(ccid_icc_status_command.link),
	ccid_tool_icc_status,
};

ui_command_t ccid_select_command = {
	"select",
	"select 3f00",
	".ccid",
	UI_CMD_SINGLE_INST,
	&ccid_reader_idx_args,
	1,
	LIST_HEAD_INIT(ccid_select_command.link),
	ccid_tool_select,
};

ui_command_t ccid_list_command = {
	"list",
	"list all opened card",
	".ccid",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(ccid_list_command.link),
	ccid_tool_list,
};

ui_command_t ccid_get_config_command = {
	"get_config",
	"get active config",
	".ccid",
	UI_CMD_SINGLE_INST,
	&ccid_reader_idx_args,
	1,
	LIST_HEAD_INIT(ccid_get_config_command.link),
	ccid_tool_get_config,
};

ui_schema_t ccid_schema[] = {
	{ UI_TYPE_CLASS, 
	  UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, 
	  NULL, 
	  NULL,
	  ".ccid", 
	  "ccid", 
	  CCID_TOOLS_DESP },
	
	{ UI_TYPE_NONE },
};

static int __init ccid_cmd_init(void)
{
	ui_register_schema(ccid_schema);
	ui_register_command(&ccid_open_command);
	ui_register_command(&ccid_close_command);
	ui_register_command(&ccid_poweron_command);
	ui_register_command(&ccid_poweroff_command);
	ui_register_command(&ccid_icc_status_command);
	ui_register_command(&ccid_list_command);
	ui_register_command(&ccid_select_command);
	ui_register_command(&ccid_get_config_command);

	return 0;
}
	
static void __exit ccid_cmd_exit(void)
{
	ui_unregister_command(&ccid_get_config_command);
	ui_unregister_command(&ccid_select_command);
	ui_unregister_command(&ccid_list_command);
	ui_unregister_command(&ccid_open_command);
	ui_unregister_command(&ccid_close_command);
	ui_unregister_command(&ccid_poweron_command);
	ui_unregister_command(&ccid_poweroff_command);
	ui_unregister_command(&ccid_icc_status_command);
	ui_unregister_schema(ccid_schema);
}

modlinkage int __init ccid_init(void)
{
	ccid_log_init();
	ccid_cmd_init();

	return 0;
}

modlinkage void __exit ccid_exit(void)
{
	ccid_cmd_exit();
	ccid_log_exit();
}

subsys_initcall(ccid_init);
subsys_exitcall(ccid_exit);
