#include "usb_priv.h"

static void print_endpoint(const struct usb_endpoint_descriptor *endpoint)
{
	printf("      bEndpointAddress: %02xh\n", endpoint->bEndpointAddress);
	printf("      bmAttributes:     %02xh\n", endpoint->bmAttributes);
	printf("      wMaxPacketSize:   %d\n", endpoint->wMaxPacketSize);
	printf("      bInterval:        %d\n", endpoint->bInterval);
	printf("      bRefresh:         %d\n", endpoint->bRefresh);
	printf("      bSynchAddress:    %d\n", endpoint->bSynchAddress);
}

static inline void add_endpoint_line(ui_table_t *table, int i, const char *item, int value)
{
	char buf[25];

	ui_add_value(table, "devname", i, " ");
	ui_add_value(table, "configuration", i, " ");
	ui_add_value(table, "interface", i, " ");
	ui_add_value(table, "endpoint", i, item);
	sprintf(buf, "%d", value);
	ui_add_value(table, "value", i, buf);
}

static int print_endpoint_list(ui_table_t *table, int j, const struct usb_endpoint_descriptor *endpoint)
{
	add_endpoint_line(table, j++, "bmAttributes", endpoint->bmAttributes);
	add_endpoint_line(table, j++, "bmAttributes", endpoint->bmAttributes);
	add_endpoint_line(table, j++, "wMaxPacketSize", endpoint->wMaxPacketSize);
	add_endpoint_line(table, j++, "bInterval", endpoint->bInterval);
	add_endpoint_line(table, j++, "bRefresh", endpoint->bRefresh);
	add_endpoint_line(table, j++, "bSynchAddress", endpoint->bSynchAddress);
	add_endpoint_line(table, j++, "bEndpointAddress", endpoint->bEndpointAddress);
	return j;
}

static void print_altsetting(const struct usb_interface_descriptor *intfc)
{
	int i;

	printf("    bInterfaceNumber:   %d\n", intfc->bInterfaceNumber);
	printf("    bAlternateSetting:  %d\n", intfc->bAlternateSetting);
	printf("    bNumEndpoints:      %d\n", intfc->bNumEndpoints);
	printf("    bInterfaceClass:    %d\n", intfc->bInterfaceClass);
	printf("    bInterfaceSubClass: %d\n", intfc->bInterfaceSubClass);
	printf("    bInterfaceProtocol: %d\n", intfc->bInterfaceProtocol);
	printf("    iInterface:         %d\n", intfc->iInterface);

	for (i = 0; i < intfc->bNumEndpoints; i++)
		print_endpoint(&intfc->endpoint[i]);
}

static inline void add_intfc_line(ui_table_t *table, int i, const char *item, int value)
{
	char buf[25];

	ui_add_value(table, "devname", i, " ");
	ui_add_value(table, "configuration", i, " ");
	ui_add_value(table, "interface", i, item);
	ui_add_value(table, "endpoint", i, " ");
	sprintf(buf, "%d", value);
	ui_add_value(table, "value", i, buf);
}

static int print_altsetting_list(ui_table_t *table, int start,
				  const struct usb_interface_descriptor *intfc)
{
	int i, j = start;

	add_intfc_line(table, j++, "bInterfaceNumber", intfc->bInterfaceNumber);
	add_intfc_line(table, j++, "bAlternateSetting", intfc->bAlternateSetting);
	add_intfc_line(table, j++, "bInterfaceClass", intfc->bInterfaceClass);
	add_intfc_line(table, j++, "bInterfaceSubClass", intfc->bInterfaceSubClass);
	add_intfc_line(table, j++, "bInterfaceProtocol", intfc->bInterfaceProtocol);
	add_intfc_line(table, j++, "iInterface", intfc->iInterface);
	add_intfc_line(table, j++, "bNumEndpoints", intfc->bNumEndpoints);

	for (i = 0; i < intfc->bNumEndpoints; i++) {
		j = print_endpoint_list(table, j, &intfc->endpoint[i]);
	}
	return j;
}

static void print_interface(const struct usb_interface *intfc)
{
	int i;

	for (i = 0; i < intfc->num_altsetting; i++)
		print_altsetting(&intfc->altsetting[i]);
}

static int print_interface_list(ui_table_t *table, int start, 
				 const struct usb_interface *intfc)
{
	int i, j = start;

	for (i = 0; i < intfc->num_altsetting; i++)
		j = print_altsetting_list(table, j, &intfc->altsetting[i]);
	return j;
}

static inline void add_configuration_line(ui_table_t *table, int i, const char *item, int value)
{
	char buf[25];

	ui_add_value(table, "devname", i, " ");
	ui_add_value(table, "configuration", i, item);
	ui_add_value(table, "interface", i, " ");
	ui_add_value(table, "endpoint", i, " ");
	sprintf(buf, "%d", value);
	ui_add_value(table, "value", i, buf);
}

static int print_configuration_list(ui_table_t *table, int start,
				     const struct usb_config_descriptor *config)
{
	int i = start;
	int j;

	add_configuration_line(table, i++, "wTotalLength", config->wTotalLength);
	add_configuration_line(table, i++, "bConfigurationValue", config->bConfigurationValue);
	add_configuration_line(table, i++, "iConfiguration", config->iConfiguration);
	add_configuration_line(table, i++, "bmAttributes", config->bmAttributes);
	add_configuration_line(table, i++, "MaxPower", config->bmaxPower);
	add_configuration_line(table, i++, "bNumInterfaces", config->bNumInterfaces);

	for (j = 0; j < config->bNumInterfaces; j++)
		i = print_interface_list(table, i, &config->intfc[j]);
	return i;
}

static void print_configuration(const struct usb_config_descriptor *config)
{
	int i;

	printf("  wTotalLength:         %d\n", config->wTotalLength);
	printf("  bNumInterfaces:       %d\n", config->bNumInterfaces);
	printf("  bConfigurationValue:  %d\n", config->bConfigurationValue);
	printf("  iConfiguration:       %d\n", config->iConfiguration);
	printf("  bmAttributes:         %02xh\n", config->bmAttributes);
	printf("  MaxPower:             %d\n", config->bmaxPower);

	for (i = 0; i < config->bNumInterfaces; i++)
		print_interface(&config->intfc[i]);
}

static int print_device(struct usb_device *dev, int level)
{
	int i;

	for (i = 0; i < dev->dev_desc->bNumConfigurations; i++)
		print_configuration(&dev->config_desc[i]);

	return 0;
}

#ifdef WIN32
static void win_find_devices(void)
{
	char dev_name[PATH_MAX];
	int i;

	for(i = 1; i < 256; i++) {
		struct usb_device *dev;

		snprintf(dev_name, sizeof(dev_name) - 1,"\\\\.\\libusb0-%04d", i);
		dev = usb_get_device(dev_name);
		if (!dev) continue;
			print_device(dev, 1);
	
		usb_put_device(dev);
	}
}
#endif

static inline void add_devname_line(ui_table_t *table, int i, 
		   const char *name)
{
	ui_add_value(table, "devname", i, name);
	ui_add_value(table, "configuration", i, "");
	ui_add_value(table, "interface", i, " ");
	ui_add_value(table, "endpoint", i, " ");
	ui_add_value(table, "value", i, " ");
}

static int print_device_list(ui_session_t *sess, struct usb_device *dev)
{
	int j, i = 0;
	ui_table_t *table = ui_table_by_name(sess, "usbdev_lists");

	if (table) {
		ui_table_delete(table);
	}

	table = ui_table_create(sess, "usbdev_lists");
	if (!table)
		return -1;

	ui_add_title(table, 0, "devname");
	ui_add_title(table, 1, "configuration");
	ui_add_title(table, 2, "interface");
	ui_add_title(table, 3, "endpoint");
	ui_add_title(table, 4, "value");
	
	j = 0;
	add_devname_line(table, j++, dev->filename);

	for (i = 0; i < dev->dev_desc->bNumConfigurations; i++)
		j = print_configuration_list(table, j, &dev->config_desc[i]);
	sess->result_table = table;
}

static void linux_find_devices(ui_session_t *sess)
{
	const char *usbfs_path = "/dev/bus/usb";
	char bus_dir_name[PATH_MAX], file_name[PATH_MAX];
	DIR *bus_dir, *dev_dir;
	uint16_t bus_num, dev_num;
#ifdef WIN32
	struct direct *bus_entry = NULL, *dev_entry = NULL;
#else
	struct dirent *bus_entry = NULL, *dev_entry = NULL;
#endif

  	bus_dir = opendir(usbfs_path);
	if (!bus_dir) {
		return ;
	}
	while ((bus_entry = readdir(bus_dir))) {
		bus_num = atoi(bus_entry->d_name);
		if (bus_num == 0)
			continue;
		memset(bus_dir_name, 0, PATH_MAX);
		snprintf(bus_dir_name, PATH_MAX, "%s/%03d", usbfs_path, bus_num);
		dev_dir = opendir(bus_dir_name);
		if (!dev_dir) {
			closedir(bus_dir);
			return ;
		}
		while((dev_entry = readdir(dev_dir))) {
			struct usb_device *dev;

			dev_num = atoi(dev_entry->d_name);
			if (dev_num == 0)
				continue;
			memset(file_name, 0, PATH_MAX);
			snprintf(file_name, PATH_MAX, "%s/%03d/%03d", 
				usbfs_path, bus_num, dev_num);
			usb_log(USB_LOG_DEBUG, "get usb config %s", file_name);
			dev = usb_get_device(file_name);
			if (!dev) continue;
			print_device_list(sess, dev);
			usb_put_device(dev);
		}
		closedir(dev_dir);
	}
	closedir(bus_dir);
}


int usb_tool_list(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
#ifdef WIN32
	win_find_devices();
#else
	linux_find_devices(sess);
#endif

	return 0;
}


int usb_tool_open(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	const char *file_name;
	struct usb_device *dev;
	int r;

	file_name = argv[0];

	dev = usb_get_device(file_name);
	if (!dev)
		return -1;
	
	r = usb_open(dev);
	if (r != USB_SUCCESS)
		return r;

	return r;
}
