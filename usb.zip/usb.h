#ifndef __RA_BOX_USB_H__
#define __RA_BOX_USB_H__

#include <sysdep.h>
#include <list.h>
#include <atomic.h>
#include <dfastm.h>
#include <service.h>
#include <notify.h>

/* add to net_devices */
#define USB_DEVICE_REGISTER	0x01
/* remove from net_devices */
#define USB_DEVICE_UNREGISTER	0x02
/* add to devfs */
#define USB_DEVICE_ADD		0x03
/* remove from sysfs */
#define USB_DEVICE_REMOVE	0x04
#define USB_DEVICE_UP		0x05
#define USB_DEVICE_GOING_DOWN	0x06
#define USB_DEVICE_DOWN		0x07

typedef struct sys_device_ops sys_device_ops_t;
typedef struct usb_transfer usb_transfer_t;

typedef struct usb_interface usb_intfc_t;
typedef struct usb_device usb_device_t;
typedef struct usb_config_descriptor usb_config_t;

#define bswap16(x) (((x & 0xff) << 8) | (x >> 8))
#if __BYTE_ORDER == __LITTLE_ENDIAN
#define usb_cpu_to_le16(x)	(x)
#define usb_le16_to_cpu(x)	(x)
#elif __BYTE_ORDER == __BIG_ENDIAN
#define usb_cpu_to_le16(x)	bswap16(x)
#define usb_le16_to_cpu(x)	bswap16(x)
#else
#error "Unrecognized endianness"
#endif

#define USB_INVALID_INTFC	0xFF
#define USB_INVALID_CONFIG	0xFF
#define USB_DEACTIVE_CONFIG	0x00

#define USB_ENDPOINT_CONTROL	0

/* Some useful macros to use to create struct usb_device_id */
#define USB_DEVICE_ID_MATCH_VENDOR		0x0001
#define USB_DEVICE_ID_MATCH_PRODUCT		0x0002
#define USB_DEVICE_ID_MATCH_DEV_LO		0x0004
#define USB_DEVICE_ID_MATCH_DEV_HI		0x0008
#define USB_DEVICE_ID_MATCH_DEV_CLASS		0x0010
#define USB_DEVICE_ID_MATCH_DEV_SUBCLASS	0x0020
#define USB_DEVICE_ID_MATCH_DEV_PROTOCOL	0x0040
#define USB_DEVICE_ID_MATCH_INT_CLASS		0x0080
#define USB_DEVICE_ID_MATCH_INT_SUBCLASS	0x0100
#define USB_DEVICE_ID_MATCH_INT_PROTOCOL	0x0200
typedef struct _usb_device_id_t {
	/* which fields to match against? */
	__u16		match_flags;

	/* Used for product specific matches; range is inclusive */
	__u16		idVendor;
	__u16		idProduct;
	__u16		bcdDevice_lo;
	__u16		bcdDevice_hi;

	/* Used for device class matches */
	__u8		bDeviceClass;
	__u8		bDeviceSubClass;
	__u8		bDeviceProtocol;

	/* Used for interface class matches */
	__u8		bInterfaceClass;
	__u8		bInterfaceSubClass;
	__u8		bInterfaceProtocol;

	__u32		driver_info;
} usb_dev_id_t;

typedef struct _usb_dynids_t {
	list_t list;
} usb_dynids_t;

typedef struct _usb_dynid_t {
	list_t node;
	usb_dev_id_t id;
} usb_dynid_t;

typedef struct _usb_driver_t {
	const char *name;
	
	int (*probe)(usb_intfc_t *intfc);
	void (*remove)(usb_intfc_t *intfc);

	const usb_dev_id_t *id_table;
	usb_dynids_t dynids;
	unsigned int no_dynamic_id:1;

	list_t link;
} usb_driver_t;

struct usb_device {
	char *filename;
	char *name;	/* alias name */
	atomic_t refcnt;
	
	int closing;
	struct usb_device_descriptor *dev_desc;
	struct usb_config_descriptor *config_desc;

	int active_config;/* == 0: NOT configured, -1: */

	uint8_t ep_o;
	uint8_t ep_i;
	uint8_t ep_intr;

	list_t link;
};

enum usb_class_code {
	USB_CLASS_PER_INTERFACE	= 0,
	USB_CLASS_AUDIO			= 1,
	USB_CLASS_COMM			= 2,
	USB_CLASS_HID			= 3,
	USB_CLASS_PHYSICAL		= 5,
	/** Picture transfer protocol class */
	USB_CLASS_PTP			= 6,
	USB_CLASS_PRINTER		= 7,
	USB_CLASS_MASS_STORAGE		= 8,
	USB_CLASS_HUB			= 9,
	USB_CLASS_DATA			= 10,
	USB_CLASS_SMART_CARD		= 0x0B,
	USB_CLASS_VENDOR_SPEC		= 0xff,
};

#define USB_ENDPOINT_ADDRESS_MASK	0x0F	/*in bEndpointAddress*/
#define USB_ENDPOINT_DIR_MASK		0x80

enum usb_endpoint_direction {
	USB_ENDPOINT_IN = 0x80,
	USB_ENDPOINT_OUT = 0x00,
};

#define USB_TRANSFER_TYPE_MASK		0x03	/*in bmAttributes of endpoint*/
enum usb_transfer_type {
	USB_TRANSFER_TYPE_CONTROL	= 0x00,
	USB_TRANSFER_TYPE_ISOCHRONOUS	= 0x01,
	USB_TRANSFER_TYPE_BULK		= 0x02,
	USB_TRANSFER_TYPE_INTERRUPT	= 0x03,
};

struct usb_control_setup {
	uint8_t		bmRequestType;
	uint8_t		bRequest;
	uint16_t	wValue;
	uint16_t	wIndex;
	uint16_t	wLength;
	uint8_t		data[0];
};

#define USB_CONTROL_SETUP_SIZE (sizeof(struct usb_control_setup))

enum usb_request_type {
	USB_REQUEST_TYPE_STANDARD	= (0x00 << 5),
	USB_REQUEST_TYPE_CLASS		= (0x01 << 5),
	USB_REQUEST_TYPE_VENDOR		= (0x02 << 5),
	USB_REQUEST_TYPE_RESERVED	= (0x03 << 5),
};

enum usb_standard_request {
	USB_REQUEST_GET_STATUS		= 0x00,
	USB_REQUEST_CLEAR_FEATURE	= 0x01,
	/* 0x02 is reserved */
	USB_REQUEST_SET_FEATURE		= 0x03,
	/* 0x04 is reserved */
	USB_REQUEST_SET_ADDRESS		= 0x05,
	USB_REQUEST_GET_DESCRIPTOR	= 0x06,
	USB_REQUEST_SET_DESCRIPTOR	= 0x07,
	USB_REQUEST_GET_CONFIGURATION	= 0x08,
	USB_REQUEST_SET_CONFIGURATION	= 0x09,
	USB_REQUEST_GET_INTERFACE	= 0x0A,
	USB_REQUEST_SET_INTERFACE	= 0x0B,
	USB_REQUEST_SYNCH_FRAME		= 0x0C,	
};

enum usb_request_recipient {
	USB_RECIPIENT_DEVICE		= 0x00,
	USB_RECIPIENT_INTERFACE		= 0x01,
	USB_RECIPIENT_ENDPOINT		= 0x02,
	USB_RECIPIENT_OTHER		= 0x03,
};

enum usb_descriptor_type {
	USB_DT_DEVICE			= 0x01,
	USB_DT_CONFIG			= 0x02,
	USB_DT_STRING			= 0x03,
	USB_DT_INTERFACE		= 0x04,
	USB_DT_ENDPOINT			= 0x05,

	USB_DT_HID			= 0x21,
	USB_DT_REPORT			= 0x22,
	USB_DT_PHYSICAL			= 0x23,
	USB_DT_HUB			= 0x29,
};

/* Descriptor sizes per descriptor type */
#define USB_DT_DEVICE_SIZE		18
#define USB_DT_CONFIG_SIZE		9
#define USB_DT_INTERFACE_SIZE		9
#define USB_DT_ENDPOINT_SIZE		7
#define USB_DT_ENDPOINT_AUDIO_SIZE	9	/* Audio extension */
#define USB_DT_HUB_NONVAR_SIZE	7

#define USB_MAX_ENDPOINTS	32
struct usb_endpoint_descriptor {
	uint8_t		bLength;
	uint8_t		bDescriptorType;
	uint8_t		bEndpointAddress;
	uint8_t		bmAttributes;
	uint16_t	wMaxPacketSize;
	uint8_t		bInterval;

	/* For audio devices only: the rate at which synchronization feedback
	 * is provided. */
	uint8_t		bRefresh;
	/** For audio devices only: the address if the synch endpoint */
	uint8_t		bSynchAddress;

	/* Extra descriptors. If libusb encounters unknown endpoint descriptors,
	 * it will store them here, should you wish to parse them. */
	const unsigned char *extra;
	int extra_length;		
};

#define USB_MAX_INTERFACES	32
/* correspond with struct usb_host_interface */
struct usb_interface_descriptor {
	uint8_t		bLength;
	uint8_t		bDescriptorType;
	uint8_t		bInterfaceNumber;
	uint8_t		bAlternateSetting;
	uint8_t		bNumEndpoints;
	uint8_t		bInterfaceClass;
	uint8_t		bInterfaceSubClass;
	uint8_t		bInterfaceProtocol;
	uint8_t		iInterface;
	
	/*Array of endpoint descriptors.*/
	const struct usb_endpoint_descriptor *endpoint;
	
	/* Extra descriptors. If libusb encounters unknown interface descriptors,
	 * it will store them here, should you wish to parse them. */
	const unsigned char *extra;
	int extra_length;
};

#define USB_MAX_ALTSETTING	128	/* Hard limit */

struct usb_interface {
	const struct usb_interface_descriptor *altsetting;
	int num_altsetting;
	struct usb_interface_descriptor *cur_altsetting;
	uint8_t claimed;

	int fd;
	usb_device_t *dev;	/* parenet usb device */
	int has_kernel_drv;	/* 1 means has kernel drv, otherwise 0 */
	int bind_drv;		/* whether bind to a userland driver, must has_kernel_drv == 0 */

#ifdef WIN32
	/* Added by RMT so implementations can store other per-open-device
	 * data */
	void *impl_info;
#endif
	list_t transfer_list;
};

#define USB_MAX_CONFIG		8
struct usb_config_descriptor {
	uint8_t		bLength;
	uint8_t		bDescriptorType;
	uint16_t	wTotalLength;
	uint8_t		bNumInterfaces;
	uint8_t		bConfigurationValue;
	uint8_t		iConfiguration;
	uint8_t		bmAttributes;
	uint8_t		bmaxPower;

	const struct usb_interface *intfc;

	const unsigned char *extra;
	int extra_length;	
};

struct usb_device_descriptor {
	uint8_t		bLength;
	uint8_t		bDescriptorType;
	uint16_t	bcdUSB;
	uint8_t		bDeviceClass;
	uint8_t		bDeviceSubClass;
	uint8_t		bDeviceProtocol;
	uint8_t		bMaxPacketSize0;
	uint16_t	idVendor;
	uint16_t	idProduct;
	uint16_t	bcdDevice;
	uint8_t		iManufacturer;
	uint8_t		iProduct;
	uint8_t		iSerialNumber;
	uint8_t		bNumConfigurations;
};


#define USB_ISO_SYNC_TYPE_MASK	0x0C
enum usb_iso_sync_type {
	USB_ISO_SYNC_TYPE_NONE	= 0,
	USB_ISO_SYNC_TYPE_ASYNC	= 1,
	USB_ISO_SYNC_TYPE_ADAPTIVE = 2,
	USB_ISO_SYNC_TYPE_SYNC	= 3,
};

#define USB_ISO_USAGE_TYPE_MASK	0x30
enum usb_iso_usage_type {
	USB_ISO_USAGE_TYPE_DATA	= 0,
	USB_ISO_USAGE_TYPE_FREEDBACK	= 1,
	USB_ISO_USAGE_TYPE_IMPLICIT	= 2,
};

/*isochronous packet descriptor.*/
struct usb_iso_packet_descriptor {
	unsigned int length;
	unsigned int actural_length;
	uint32_t status;
	
	/* additional bytes for os_priv for each iso packet.
	 * Can your backend use this ?*/
	/* FIXME: linux can not use this any more. if other OS's cannot either, then 
	 * remove this
	 */
	void *os_priv; /**/
};

enum usb_error {
	USB_REAP_AGAIN		= 1,
	USB_SUCCESS		= 0,
	USB_ERROR_IO		= -1,
	USB_ERROR_INVALID_PARAM	= -2,
	USB_ERROR_ACCESS	= -3,
	USB_ERROR_NO_DEVICE	= -4,
	USB_ERROR_NOT_FOUND	= -5,
	USB_ERROR_BUSY		= -6,
	USB_ERROR_TIMEOUT	= -7,
	USB_ERROR_CANCELLED	= -8,
	USB_ERROR_OVERFLOW	= -9,
	USB_ERROR_PIPE		= -10,
	USB_ERROR_INTERRUPTED	= -11,
	USB_ERROR_NO_MEM	= -12,
	USB_ERROR_NOT_SUPPORTED	= -13,
	USB_ERROR_HAS_OPENED	= -14,
	USB_ERROR_INVALID_HANLDE = -15,
	USB_ERROR_OTHER		= -99,
};

usb_device_t *usb_get_device(const char *file_name);
void usb_put_device(usb_device_t *usb_dev);

int usb_open(usb_intfc_t *dev);
int usb_close(usb_intfc_t *dev);

int usb_set_configuration(usb_intfc_t *intfc, uint8_t config_idx);
int usb_claim_interface(usb_intfc_t *intfc);
int usb_release_interface(usb_intfc_t *intfc, uint8_t intfc_idx);

/* Asynchronous transfer*/
struct usb_trans_params {
	usb_intfc_t *dev_handle;
	uint8_t ep;
	uint8_t *buf;
	size_t buf_len;
	size_t rbuf_actual;
	/* const struct timeval *timeout; */
	
	int ret;
	void *user_data; /*you may store ccid_transfer point in it.*/
};

typedef void (*usb_bulk_trans_callback)(struct usb_trans_params *params);


int usb_bulk_write(struct usb_trans_params *param, usb_bulk_trans_callback cb);
int usb_bulk_read(struct usb_trans_params *param, usb_bulk_trans_callback cb);

int usb_interrupt_write(struct usb_trans_params *param, usb_bulk_trans_callback cb);
int usb_interrupt_read(struct usb_trans_params *param, usb_bulk_trans_callback cb);

int usb_control_transfer(struct usb_trans_params *param, usb_bulk_trans_callback cb);

int usb_cancel(usb_intfc_t *dev_handle);

/* XXX: This is a synchronicity function */
int usb_ioctl(usb_intfc_t *dev_handle, int intfc_no, 
	      int ioctl_code, void *data);

usb_intfc_t *usb_get_intfc_by_altsetting(usb_device_t *dev, 
					 struct usb_interface_descriptor *alts);

int usb_unregister_notify(notify_t *nb, int type);
int usb_register_notify(notify_t *nb);
int usb_register_driver(usb_driver_t *drv);
void usb_unregister_driver(usb_driver_t *drv);
#endif /*__RA_BOX_USB_H__*/
