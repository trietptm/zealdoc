#ifndef __BRIDGE_PRIV_H_INCLUDE__
#define __BRIDGE_PRIV_H_INCLUDE__

#include <bridge.h>
#include <bitops.h>
#include <logger.h>
#include <eloop.h>
#include <panic.h>
#include <module.h>
#include <service.h>

#ifdef CONFIG_BRIDGE_DEVICES
#define BRIDGE_DEVICE	CONFIG_BRIDGE_DEVICES
#else
#define BRIDGE_DEVICE	1
#endif

#define BRIDGE_SERVICE_DESC	"MAC bridging (802.1D)"

#define SYSFS_CLASS_NET		"/sys/class/net/"

/* ============================================================ *
 * logging handlers
 * ============================================================ */
#define BR_LOG_CRIT		LOG_EMERG
#define BR_LOG_FAIL		LOG_CRIT
#define BR_LOG_ERR		LOG_ERR
#define BR_LOG_WARN		LOG_WARNING
#define BR_LOG_INFO		LOG_INFO
#define BR_LOG_DEBUG		LOG_DEBUG

void br_log(int level, const char *format, ...);

#endif /* __BRIDGE_PRIV_H_INCLUDE__ */
