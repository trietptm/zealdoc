#include "bridge_priv.h"

DECLARE_BITMAP(bridge_dev_no, BRIDGE_DEVICE);

list_head(br_bridges);
list_head(br_bridges_gc);
/* no ports list, its in bridge and no refcnt */
list_head(br_profiles);
list_head(br_profiles_gc);
notify_head(br_chain);


#define for_each_profile(d)			\
	list_for_each_entry(br_profile_t, d, &br_profiles, link)
#define for_each_profile_safe(d, n)		\
	list_for_each_entry_safe(br_profile_t, d, n, &br_profiles, link)

#define for_each_bridge(d)			\
	list_for_each_entry(bridge_t, d, &br_bridges, link)
#define for_each_bridge_safe(d, n)		\
	list_for_each_entry_safe(bridge_t, d, n, &br_bridges, link)
#define for_each_bridge_gc(d)			\
	list_for_each_entry(bridge_t, d, &br_bridges_gc, link)
#define for_each_bridge_gc_safe(d, n)		\
	list_for_each_entry_safe(bridge_t, d, n, &br_bridges_gc, link)

#define for_each_port_on_bridge(br, i)			\
	list_for_each_entry(bridge_port_t, i, &br->port_list, link)
#define for_each_port_on_bridge_safe(br, i, n)		\
	list_for_each_entry_safe(bridge_port_t, i, n, &br->port_list, link)

int br_logger = 0;
handle_t br_handle = NULL;
ui_entry_t *br_main_section = NULL;
notify_t br_dev_notify;

log_source_t br_log_source = {
	"bridge",
};

ui_parser_t br_profile_parser[] = {
	{ ".bridge.profile.stp", NULL,
	  offsetof(br_profile_t, stp), },

	{ NULL },
};

ui_parser_t br_port_parser[] = {
	{ ".bridge.profile.port_ifname", NULL,
	  offsetof(bridge_port_t, ifname), },

	{ NULL },
};

ui_schema_t bridge_schema[] = {
	/* .bridge */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE,
	  UI_TYPE_STRING, NULL, NULL,
	  ".bridge", "bridge", BRIDGE_SERVICE_DESC },

	/* .bridge.device */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".bridge.device", "device", "BRIDGE devices" },

	/* .bridge.profile */
	{ UI_TYPE_CLASS, 0,
	  UI_TYPE_STRING, NULL, NULL,
	  ".bridge.profile", "profile", "BRIDGE device profile" },
	{ UI_TYPE_ATTRIBUTE, UI_FLAG_SINGLE,
	  UI_TYPE_BOOLEAN, NULL, "yes",
	  ".bridge.profile.stp", "stp",
	  "Enable/Disable bridge stp", },

	/* TODO: ports belong to bridge */
	{ UI_TYPE_ATTRIBUTE, 0,	/* multiple value */
	  UI_TYPE_STRING, "br_bridges", NULL,
	  ".bridge.profile.port_ifname", "port_ifname",
	  "Bridge port list", },

	/* .net.device */
	{ UI_TYPE_ATTRIBUTE, UI_FLAG_SINGLE,
	  UI_TYPE_CHOICE, ".bridge.profile", NULL,
	  ".net.device.bridge_profile", "bridge_profile",
	  "BRIDGE profile name", },

	{ UI_TYPE_NONE },
};

void br_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(br_logger, level, format, ap);
	va_end(ap);
}

#if 0
static int br_no_inuse(uint16_t dev_no)
{
	return test_bit(dev_no, bridge_dev_no);
}
#endif

static uint16_t br_no_alloc(void)
{
	uint16_t i = (uint16_t)__find_first_zero_bit(bridge_dev_no, BRIDGE_DEVICE);
	if (i >= BRIDGE_DEVICE) {
		return BRIDGE_DEVICE;
	}
	__set_bit(i, bridge_dev_no);
	return i;
}

static void br_no_free(int dev_no)
{
	if (dev_no >= 0 && dev_no < BRIDGE_DEVICE)
		__clear_bit(dev_no, bridge_dev_no);
}

static const char *br_no2name(int no)
{
	bridge_t *br;
	for_each_bridge(br) {
		if (br->brno == no)
			return br->dev->ifname;
	}
	return NULL;
}

static void br_ports_delete(bridge_t *br);
static int br_port_exist(bridge_t *br);
static int __br_add_bridge(const char *brname);
static int __br_del_bridge(const char *brname);
static void __br_port_free(bridge_port_t *port);
static int __br_add_bridge(const char *brname)
{
	int ret = -1, s;

	if ((s = __net_config_open()) < 0)
		goto err;

	ret = ioctl(s, SIOCBRADDBR, (unsigned long)brname);
	if (ret < 0)
	{
		char _br[IFNAMSIZ];
		unsigned long arg[3]
			= { BRCTL_ADD_BRIDGE, (unsigned long) _br };

		strncpy(_br, brname, IFNAMSIZ);
		ret = ioctl(s, SIOCSIFBR, (unsigned long)arg);
	}
err:
	__net_config_close(s);
	return ret;
}

static int __br_del_bridge(const char *brname)
{
	int ret = -1, s;

	if ((s = __net_config_open()) < 0)
		goto err;
	{
		char _br[IFNAMSIZ];
		unsigned long arg[3]
			= { BRCTL_DEL_BRIDGE, (unsigned long) _br };

		strncpy(_br, brname, IFNAMSIZ);
		ret = ioctl(s, SIOCSIFBR, (unsigned long)arg);
	}

err:
	__net_config_close(s);
	return ret;
}

int br_add_bridge(int brno)
{
	int ret;
	const char *brname = br_no2name(brno);

	if (!brname)
		return -1;

	ret = __br_add_bridge(brname);

	if (ret < 0) {
		br_log(BR_LOG_ERR,  "DEVICE: add bridge <%s> failure", brname);
	} else
		br_log(BR_LOG_INFO, "DEVICE: add bridge <%s> success.", brname);
	return ret;
}

static int __br_add_interface(const char *brname, int ifindex)
{
	struct ifreq ifr;
	int err = -1, s;

	if ((s = __net_config_open()) < 0)
		goto err;
	
	strncpy(ifr.ifr_name, brname, IFNAMSIZ);
	ifr.ifr_ifindex = ifindex;

	err = ioctl(s, SIOCBRADDIF, (unsigned long)&ifr);
	if (err < 0)
	{
		unsigned long args[4] = 
			{ BRCTL_ADD_IF, ifindex, 0, 0 };
					  
		ifr.ifr_data = (char *) args;
		err = ioctl(s, SIOCDEVPRIVATE, (unsigned long)&ifr);
	}
err:
	__net_config_close(s);
	return err;
}

static int __br_del_interface(const char *brname, int ifindex)
{
	struct ifreq ifr;
	int err = -1, s;

	if (ifindex == 0) 
		return ENODEV;
	
	strncpy(ifr.ifr_name, brname, IFNAMSIZ);
	ifr.ifr_ifindex = ifindex;

	if ((s = __net_config_open()) < 0)
		goto err;

	err = ioctl(s, SIOCBRDELIF, (unsigned long)&ifr);
	if (err < 0)
	{
		unsigned long args[4] = { BRCTL_DEL_IF, ifindex, 0, 0 };
					  
		ifr.ifr_data = (char *) args;
		err = ioctl(s, SIOCDEVPRIVATE, (unsigned long)&ifr);
	}
err:
	__net_config_close(s);
	return err;
}

#if 0
static int __br_get_bridge_info(const char *brname, struct __bridge_info *info)
{
	int s, err = -1;
	struct ifreq ifr;
	unsigned long args[4] = { BRCTL_GET_BRIDGE_INFO,
				  (unsigned long)info, 0, 0 };

	memset(info, 0, sizeof(struct __bridge_info));
	strncpy(ifr.ifr_name, brname, IFNAMSIZ);
	ifr.ifr_data = (char *) &args;

	if ((s = __net_config_open()) < 0)
		goto err;

	err = ioctl(s, SIOCDEVPRIVATE, (unsigned long)&ifr);

	if (err < 0) {
		br_log(BR_LOG_ERR, "bridge <%s> get info failure", brname);
	} else
		br_log(BR_LOG_ERR, "bridge <%s> get info success", brname);
err:
	__net_config_close(s);
	return err;
}
#endif

/* TODO: bridge states */
static int __br_set(const char *bridge, const char *name,
		  unsigned long value, unsigned long oldcode)
{
	int ret = -1, s;

	struct ifreq ifr;
	unsigned long args[4] = { oldcode, value, 0, 0 };
	
	if ((s = __net_config_open()) < 0)
		goto err;

	strncpy(ifr.ifr_name, bridge, IFNAMSIZ);
	ifr.ifr_data = (char *) &args;
	ret = ioctl(s, SIOCDEVPRIVATE, (unsigned long)&ifr);
err:
	__net_config_close(s);
	return ret;
}

void br_del_bridge(int brno)
{
	int ret;
	const char *brname = br_no2name(brno);

	if (!brname)
		return;

	ret = __br_del_bridge(brname);
	if (ret < 0) {
		br_log(BR_LOG_ERR, "DEVICE: del bridge <%s> failure",
		       brname);
	} else 
		br_log(BR_LOG_INFO, "DEVICE: del bridge <%s> success.",
		       brname);
}

int br_add_interface(int brno, bridge_port_t *port)
{
	int ret;
	const char *brname = br_no2name(brno);

	if (!brname)
		return -1;

	ret = __br_add_interface(brname, port->dev->ifindex);
	if (ret < 0) {
		br_log(BR_LOG_ERR, "DEVICE: bridge <%s> add port <%s> failure",
		       brname, port->dev->ifname);

		port->in_kernel = 0;
	} else {
		br_log(BR_LOG_INFO, "DEVICE: bridge <%s> add port <%s> success.",
		       brname, port->dev->ifname);

		port->in_kernel = 1;
	}
	return ret;
}

void br_del_interface(int brno, bridge_port_t *port)
{
	int ret;
	const char *brname = br_no2name(brno);

	if (!brname)
		return;

	ret = __br_del_interface(brname, port->dev->ifindex);
	if (ret < 0) {
		br_log(BR_LOG_ERR, "DEVICE: <%s> del port=%s failure",
		       brname, port->dev->ifname);
	} else {
		br_log(BR_LOG_INFO, "DEVICE: <%s> del port=%s success.",
		       brname, port->dev->ifname);
		port->in_kernel = 0;
	}
}

int br_enable_bridge_stp(int brno)
{
	const char *brname = br_no2name(brno);
	if (!brname)
		return -1;

	return __br_set(brname, "stp_state", TRUE, 
		        BRCTL_SET_BRIDGE_STP_STATE);
}

int br_disable_bridge_stp(int brno)
{
	const char *brname = br_no2name(brno);
	if (!brname)
		return -1;
	
	return __br_set(brname, "stp_state", FALSE, 
		        BRCTL_SET_BRIDGE_STP_STATE);
}

static br_profile_t *br_profile_by_name(const char *name)
{
	br_profile_t *prof;

	for_each_profile(prof) {
		if (strcasecmp(prof->name, name) == 0)
			return prof;
	}
	return NULL;
}

static br_profile_t *br_profile_by_dev(ui_entry_t *fcs)
{
	ui_entry_t *cp;

	cp = ui_value_by_conf(fcs, "bridge_profile", NULL);
	if (!cp)
		return NULL;

	return br_profile_by_name(ui_get_conf_value(cp));
}

static br_profile_t *br_profile_get_by_dev(ui_entry_t *cs)
{
	br_profile_t *p = br_profile_by_dev(cs);
	if (p)
		return br_profile_get(p);
	return NULL;
}

static br_profile_t *br_profile_new(const char *name)
{
	br_profile_t *c;

	c = calloc(1, sizeof(br_profile_t));
	if (!c) {
		br_log(BR_LOG_ERR, "PROF: out of memory");
		return NULL;
	}
	atomic_set(&c->refcnt, 1);
	list_init(&c->link);
	list_insert_before(&c->link, &br_profiles);
	c->name = name;
	return c;
}

static void br_profile_free(br_profile_t *prof)
{
	if (prof) {
		if (atomic_dec_and_test(&prof->refcnt)) {
			if (prof->cs)
				ui_inst_delete_conf(prof->cs);
			list_delete(&prof->link);
			free(prof);
		}
	}
}

static void br_bridge_free(bridge_t *bridge)
{
	if (bridge) {
		/* ports should be delete before profile. */
		if (br_port_exist(bridge))
			br_ports_delete(bridge);
		if (bridge->profile)
			br_profile_free(bridge->profile);
		if (bridge->dev)
			net_device_put(bridge->dev);
		if (bridge->brno >= 0)
			br_no_free(bridge->brno);

		list_delete(&bridge->link);
		free(bridge);
	}
}

static void br_gc_timeout(void *eloop, void *data)
{
	bridge_t *bridge, *n;

	for_each_bridge_gc_safe(bridge, n) {
		if (atomic_read(&bridge->refcnt) == 0) {
			br_bridge_free(bridge);
		}
	}
	if (!list_empty(&br_bridges_gc))
		eloop_register_timeout(NULL, BRIDGE_GC_TIMEOUT, 0,
				       br_gc_timeout, NULL, NULL);
}

static void br_prof_set_stp(bridge_t *br)
{
	if (br->profile->stp == 1) {
		int ret = br_enable_bridge_stp(br->brno);
		if (ret >= 0) {
			br_device_notify(BR_BRIDGE_ENABLE_STP, br);
		}
	}
}

static bridge_port_t *__br_port_new(const char *ifname)
{
	bridge_port_t *port = malloc(sizeof (bridge_port_t));

	if (!port) {
		br_log(BR_LOG_ERR, "PORT: Out of memory.");
		return NULL;
	}
	memset(port, 0, sizeof (bridge_port_t));
	port->ifname = ifname;
	/* every new port must wait dev. */
	port->wait_dev = 1;
	list_init(&port->link);
	return port;
}

static void __br_port_free(bridge_port_t *port)
{
	if (port) {
		list_delete(&port->link);
		free(port);
	}
}

static void br_port_delete(bridge_t *br, bridge_port_t *port, int fr)
{
	if (!br)
		return;
	if (port->dev) {
		br_del_interface(br->brno, port);
		/* FIXME: which notify */
		net_device_put(port->dev);
		port->dev = NULL;
		/* wait dev again */
		port->wait_dev = 1;
	}
	/* true delete */
	if (fr)
		__br_port_free(port);
}

/* every new port belongs to a bridge */
static bridge_port_t *br_port_new(bridge_t *br, const char *port_ifname)
{
	bridge_port_t *port = __br_port_new(port_ifname);
	if (!port)
		return NULL;

	port->br = br;
	list_insert_before(&port->link, &br->port_list);

	return port;
}

#if 0
static void br_prof_get_info(bridge_t *br)
{
	const char *brname = br_no2name(br->brno);
	if (!brname)
		return;

	__br_get_bridge_info(brname, &br->br_info);
}
#endif

/* setup ports in profile */
static void br_prof_set_ports(bridge_t *br)
{
	ui_entry_t *cp = NULL;
	bridge_port_t *port;
	net_device_t *dev;

	while ((cp = ui_value_iterate_conf(br->profile->cs,
			"port_ifname", cp)) != NULL) {
		port = br_port_new(br, ui_get_conf_value(cp));
		if (!port)
			continue;
		br_log(BR_LOG_INFO, "PORT: create port=%s", port->ifname);
		dev = net_device_by_name(ui_get_conf_value(cp));
		if (dev) {
			int ret;
			port->dev = net_device_get(dev);
			port->wait_dev = 0;
			ret = br_add_interface(br->brno, port);
		}
	}
}

/* ports / stp / ... */
static int br_prof_param_set(bridge_t *br)
{
	br_prof_set_stp(br);
	br_prof_set_ports(br);

	/* TODO: get */
	/* br_prof_get_info(br); */
	
	return 0;
}

static void br_ports_delete(bridge_t *br)
{
	bridge_port_t *port, *node;

	for_each_port_on_bridge_safe(br, port, node) {
		br_port_delete(br, port, 1);	/* free */
	}
}

static int br_port_exist(bridge_t *br)
{
	if (!list_empty(&br->port_list))
		return 1;
	return 0;
}

static bridge_t *br_get_bridge_by_port(bridge_port_t *port)
{
	bridge_t *br;
	bridge_port_t *pp;
	
	for_each_bridge(br) {
		for_each_port_on_bridge(br, pp) {
			if (pp == port)
				return br;
		}
	}
	return NULL;
}

static int br_get_brno_by_port(bridge_port_t *port)
{
	bridge_t *br;
	bridge_port_t *pp;
	
	for_each_bridge(br) {
		for_each_port_on_bridge(br, pp) {
			if (pp == port)
				return br->brno;
		}
	}
	return -1;
}

/* open bridge and its port if exist */
static bridge_t *br_device_open(net_device_t *dev)
{
	bridge_t *bridge = NULL;
	br_profile_t *prof = NULL;
	int ret, brno = -1;
	
	prof = br_profile_get_by_dev(dev->cs);
	if (!prof) {
		br_log(BR_LOG_ERR, "DEVICE: missing profile, dev=%s",
			 dev->ifname);
		goto fail;
	}

	brno = br_no_alloc();
	if (brno == BRIDGE_DEVICE) {
		br_log(BR_LOG_ERR, "DEVICE: too many device allocated");
		goto fail;
	}

	bridge = malloc(sizeof (bridge_t));
	if (!bridge) {
		br_log(BR_LOG_ERR, "DEVICE: out of memory");
		goto fail;
	}

	memset(bridge, 0, sizeof (bridge_t));
	list_init(&bridge->link);
	list_init(&bridge->port_list);
	atomic_set(&bridge->refcnt, 1);

	bridge->profile = prof;
	bridge->dev = dev;
	/* Management number */
	bridge->brno = brno;
	
	/* XXX: add to list before bridge operations */
	list_insert_before(&bridge->link, &br_bridges);
	
	if ((ret = br_add_bridge(bridge->brno)) < 0)
		goto fail;
	br_device_notify(BR_BRIDGE_ADD, bridge);

	/* bridge is prepare. Set its param in profile */
	br_prof_param_set(bridge);

	return bridge;
fail:
	if (brno != -1)
		br_no_free(brno);
	if (prof)
		br_profile_free(prof);
	if (bridge)
		br_bridge_free(bridge);
	return NULL;
}

static void br_device_remove(bridge_t *bridge)
{
	if (bridge && !bridge->closing) {
		bridge->closing = 1;

		if (bridge->dev) {
			br_del_bridge(bridge->brno);
			net_device_put(bridge->dev);
			bridge->dev = NULL;
			//br_device_notify(BR_BRIDGE_DEL, bridge);
		}

		br_bridge_put(bridge);
		list_delete_init(&bridge->link);
		list_insert_before(&bridge->link, &br_bridges_gc);
		eloop_register_timeout(NULL, 0, 0,
				       br_gc_timeout, NULL, NULL);
	}
}

static void br_device_close(bridge_t *bridge)
{
	if (bridge && !bridge->closing) {
		bridge->closing = 1;

		if (bridge->dev) {
			br_del_bridge(bridge->brno);
			net_device_put(bridge->dev);
			bridge->dev = NULL;
			//br_device_notify(BR_BRIDGE_DEL, bridge);
		}

		br_bridge_put(bridge);
		list_delete_init(&bridge->link);
		list_insert_before(&bridge->link, &br_bridges_gc);
		eloop_register_timeout(NULL, BRIDGE_GC_TIMEOUT, 0,
				       br_gc_timeout, NULL, NULL);
	}
}

int br_register_notify(notify_t *nb)
{
	bridge_t *bridge;
	bridge_t *last;
	int err;

	err = register_notify_chain(&br_chain, nb);
	if (err)
		goto unlock;

	for_each_bridge(bridge) {
		err = nb->call(nb, BR_BRIDGE_REGISTER, bridge);
		err = notify_to_errno(err);
		if (err)
			goto rollback;
	}
unlock:
	return err;
rollback:
	last = bridge;
	for_each_bridge(bridge) {
		if (bridge == last)
			break;
		nb->call(nb, BR_BRIDGE_UNREGISTER, bridge);
	}
	goto unlock;
}

void br_unregister_notify(notify_t *nb)
{
	unregister_notify_chain(&br_chain, nb);
}

/* name to bridge_notify? */
int br_device_notify(unsigned long val, void *v)
{
	return call_notify_chain(&br_chain, val, v);
}

static void *br_net_start(net_device_t *dev)
{
	/* the only entrance to open a bridge,
	 * thus no refcnt increment required
	 */
	return br_device_open(dev);
}

static void br_net_stop(net_device_t *dev, void *data)
{
	bridge_t *br = (bridge_t *)data;

	/* the only entrance to close a bridge,
	 * thus no refcnt decrement required
	 */
	br_device_close(br);
}

net_media_t br_net_media = {
	BRIDGE_SERVICE_NAME,
	BRIDGE_SERVICE_DESC,
	"br",
	NET_FORMAT_ONE,
	BRIDGE_DEVICE,

	br_net_start,
	br_net_stop,
};

static int br_conf_start(void)
{
	ui_entry_t *cs;
	const char *oid = "bridge";

	if (br_main_section) return 0;

	cs = ui_inst_lookup_conf(NULL, oid, NULL);
	if (!cs) {
		br_log(BR_LOG_ERR,
			 "CONF: cannot find instance, oid=%s", oid);
		return 0;
	}

	br_main_section = cs;
	return 0;
}

static br_profile_t *br_conf_profile(ui_entry_t *cs)
{
	const char *profnm;
	const char *name;
	br_profile_t *c;
	int rc;

	name = ui_get_conf_value(cs);
	if (!name) {
		br_log(BR_LOG_ERR, "PROF: name missing");
		return NULL;
	}
	/* check the lengths, we don't want any core dumps */
	profnm = name;

	if (br_profile_by_name(name)) {
		br_log(BR_LOG_ERR,
			 "PROF: duplicated profile, prof=%s", profnm);
		return NULL;
	}

	c = br_profile_new(name);
	if (!c) return NULL;

	rc = ui_load_single_values(cs, c, br_profile_parser);
	if (rc) {
		br_log(BR_LOG_ERR,
			 "PROF: cannot load profile, prof=%s", profnm);
		br_profile_free(c);
		return NULL;
	}
	c->cs = ui_inst_get(cs);

	br_log(BR_LOG_DEBUG,
		 "PROF: profile ready, prof=%s", c->name);

	return c;
}

static void br_conf_stop(void)
{
	if (br_main_section) {
		ui_inst_delete_conf(br_main_section);
		br_main_section = NULL;
	}
}

static int br_prof_start(void)
{
	br_profile_t *prof;
	ui_entry_t *cs = NULL;

	if (br_main_section) {
		while ((cs = ui_minst_iterate_conf(br_main_section,
						   "profile", cs)) != NULL) {
			ui_inst_hold(cs);
			prof = br_conf_profile(cs);
			ui_inst_delete_conf(cs);
		}
	}
	return 0;
}

static void br_prof_stop(void)
{
	br_profile_t *c, *n;

	for_each_profile_safe(c, n) {
		list_delete_init(&c->link);
		list_insert_before(&c->link, &br_profiles_gc);
		br_profile_free(c);
	}
}

static void br_device_gc(void *eloop_data, void *data)
{
	bridge_t *bridge, *n;

	for_each_bridge_gc_safe(bridge, n) {
		if (atomic_read(&bridge->refcnt) == 0)
			br_bridge_free(bridge);
	}
	eloop_register_timeout(NULL, 30, 0, br_device_gc, NULL, NULL);
}

static void br_bridge_event(bridge_t *bridge, unsigned long event)
{
	BUG_ON(!bridge->dev);

	switch (event) {
	case NET_DEVICE_UP:
		br_device_notify(BR_BRIDGE_UP, bridge);
		break;
	case NET_DEVICE_REMOVE:
		/* TODO: notify free all ports */
		br_device_remove(bridge);
		break;
	case NET_DEVICE_GOING_DOWN:
		break;
	case NET_DEVICE_DOWN:
		br_device_notify(BR_BRIDGE_DOWN, bridge);
		break;
	}
}

static void br_port_event(bridge_port_t *port, unsigned long event)
{
	BUG_ON(!port->dev);

	switch (event) {
	case NET_DEVICE_REGISTER:
	case NET_DEVICE_UP:
		/* TODO: add interface? */
		if (!port->in_kernel) {
			int brno, ret;
			brno = br_get_brno_by_port(port);
			ret = br_add_interface(brno, port);
		}
		break;
	case NET_DEVICE_GOING_DOWN:
		/* not free, dev may up again */
		br_port_delete(br_get_bridge_by_port(port), port, 0);
		break;
	case NET_DEVICE_DOWN:
		break;
	}
}

static int br_dev_event(notify_t *nb, unsigned long event, void *data)
{
	net_device_t *dev = (net_device_t *)data;
	bridge_t *bridge;
	bridge_port_t *port;

	for_each_bridge(bridge) {
		if (bridge->dev == dev) {
			br_bridge_event(bridge, event);
			break;
		}
		for_each_port_on_bridge(bridge, port) {
			if (port->wait_dev == 1 && 
			    strcasecmp(port->ifname, dev->ifname) == 0) {
				port->dev = net_device_get(dev);
				port->wait_dev = 0;
			}
			if (port->dev == dev) {
				br_port_event(port, event);
				break;
			}
		}
	}

	return 0;
}

static int br_link_start(void)
{
	br_dev_notify.call = br_dev_event;
	br_dev_notify.next = NULL;
	br_dev_notify.priority = 9;
	net_register_notify(&br_dev_notify, NET_NOTIFY_DEVICE);
	eloop_register_timeout(NULL, 0, 0, br_device_gc, NULL, NULL);
	return 0;
}

static void br_link_stop(void)
{
	net_unregister_notify(&br_dev_notify, NET_NOTIFY_DEVICE);
	/* eloop_cancel_timeout(NULL, 0, 0, br_intfc_gc, NULL, NULL); */
	eloop_cancel_timeout(NULL, br_device_gc, NULL, NULL);
}

static int br_start(void)
{
	if (br_conf_start() ||
	    br_prof_start() ||
	    br_link_start())
		return -1;
	return 0;
}

static void br_stop(void)
{
	br_link_stop();
	br_prof_stop();
	br_conf_stop();
}

ui_choice_t bridge_profile_choice = {
	".bridge.profile",
	".bridge.profile",
	ui_inst_choice_foreach,
	ui_inst_choice_name,
	ui_inst_choice_desc,
};

#if 0
ui_choice_t bridge_choice = {
	".bridge.device",
	".bridge.device",
	ui_inst_choice_foreach,
	ui_inst_choice_name,
	ui_inst_choice_desc,
};
#endif

static int br_dump_bridges(ui_session_t *sess, ui_entry_t *inst,
			       void *ctx, int argc, char **argv)
{
	bridge_t *br;
	bridge_port_t *port;
	int i = 0;
	ui_table_t *table = ui_table_by_name(sess, "br_bridges");
	char buf[25] = "";
	uint16_t brid;

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "br_bridges");
	if (!table)
		return -1;

	ui_add_title(table, 0, "name");
	ui_add_title(table, 1, "bridge_id");
	ui_add_title(table, 2, "stp");
	ui_add_title(table, 3, "ports");

	for_each_bridge(br) {
		ui_add_value(table, "name", i, br->profile->name);
#ifdef WIN32
		snprintf(buf, sizeof(buf), "xxxxxxxxx");
		ui_add_value(table, "bridge_id", i, buf);		
		ui_add_value(table, "stp", i, "x");				
#else
		/* id is priority and addr */
		brid = (br->br_info.bridge_id >> 48) & 0xffff;
		snprintf(buf, sizeof(buf), "%04x", brid);
		ui_add_value(table, "bridge_id", i, buf);		
		snprintf(buf, sizeof(buf), "%s", br->br_info.stp_enabled ? "on" : "off");
		ui_add_value(table, "stp", i, buf);				
#endif
		for_each_port_on_bridge(br, port)
			if (port->dev)
				snprintf(buf, sizeof(buf), "%s\n", port->dev->ifname);	
		ui_add_value(table, "ports", i, buf);				
		i++;						
	}
	sess->result_table = table;
	return 0;
}

ui_command_t br_dump_bridges_cmd = {
	"dump",
	"Dump bridges",
	".bridge.device",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(br_dump_bridges_cmd.link),
	br_dump_bridges,
};

service_t br_service = {
	BRIDGE_SERVICE_NAME,
	BRIDGE_SERVICE_DESC,
	SERVICE_UP_DEMAND,
	SERVICE_FLAG_MODULE,
	LIST_HEAD_INIT(br_service.depends),
	br_start,
	br_stop,
};

modlinkage int __init bridge_init(void)
{
	br_logger = log_register_source(&br_log_source);
	if (!br_logger)
		return -1;

	ui_register_schema(bridge_schema);
	ui_register_choice(&bridge_profile_choice);
	ui_register_command(&br_dump_bridges_cmd);

	net_register_media(&br_net_media);
	service_register_depend(NIF_SERVICE_NAME, BRIDGE_SERVICE_NAME);
	br_handle = register_service(&br_service);
	return br_handle ? 0 : 1;
}

modlinkage void __exit bridge_exit(void)
{
	unregister_service(br_handle);
	net_unregister_media(&br_net_media);

	ui_unregister_command(&br_dump_bridges_cmd);

	ui_unregister_choice(&bridge_profile_choice);

	ui_unregister_schema(bridge_schema);

	log_unregister_source(br_logger);
}

subsys_initcall(bridge_init);
subsys_exitcall(bridge_exit);
