static int __br_add_bridge(const char *brname)
{
	int ret = -1, s;

	if ((s = __net_config_open()) < 0)
		goto err;

	ret = ioctl(s, SIOCBRADDBR, (unsigned long)brname);
	if (ret < 0)
	{
		char _br[IFNAMSIZ];
		unsigned long arg[3]
			= { BRCTL_ADD_BRIDGE, (unsigned long) _br };

		strncpy(_br, brname, IFNAMSIZ);
		ret = ioctl(s, SIOCSIFBR, (unsigned long)arg);
	}
err:
	__net_config_close(s);
	return ret;
}

static int __br_del_bridge(const char *brname)
{
	int ret = -1, s;

	if ((s = __net_config_open()) < 0)
		goto err;
	{
		char _br[IFNAMSIZ];
		unsigned long arg[3]
			= { BRCTL_DEL_BRIDGE, (unsigned long) _br };

		strncpy(_br, brname, IFNAMSIZ);
		ret = ioctl(s, SIOCSIFBR, (unsigned long)arg);
	}

err:
	__net_config_close(s);
	return ret;
}
static int __br_add_interface(const char *brname, int ifindex)
{
	struct ifreq ifr;
	int err = -1, s;

	if ((s = __net_config_open()) < 0)
		goto err;
	
	strncpy(ifr.ifr_name, brname, IFNAMSIZ);
	ifr.ifr_ifindex = ifindex;

	err = ioctl(s, SIOCBRADDIF, (unsigned long)&ifr);
	if (err < 0)
	{
		unsigned long args[4] = 
			{ BRCTL_ADD_IF, ifindex, 0, 0 };
					  
		ifr.ifr_data = (char *) args;
		err = ioctl(s, SIOCDEVPRIVATE, (unsigned long)&ifr);
	}
err:
	__net_config_close(s);
	return err;
}

static int __br_del_interface(const char *brname, int ifindex)
{
	struct ifreq ifr;
	int err = -1, s;

	if (ifindex == 0) 
		return ENODEV;
	
	strncpy(ifr.ifr_name, brname, IFNAMSIZ);
	ifr.ifr_ifindex = ifindex;

	if ((s = __net_config_open()) < 0)
		goto err;

	err = ioctl(s, SIOCBRDELIF, (unsigned long)&ifr);
	if (err < 0)
	{
		unsigned long args[4] = { BRCTL_DEL_IF, ifindex, 0, 0 };
					  
		ifr.ifr_data = (char *) args;
		err = ioctl(s, SIOCDEVPRIVATE, (unsigned long)&ifr);
	}
err:
	__net_config_close(s);
	return err;
}
/* TODO: bridge states */
static int __br_set(const char *bridge, const char *name,
		  unsigned long value, unsigned long oldcode)
{
	int ret = -1, s;

	struct ifreq ifr;
	unsigned long args[4] = { oldcode, value, 0, 0 };
	
	if ((s = __net_config_open()) < 0)
		goto err;

	strncpy(ifr.ifr_name, bridge, IFNAMSIZ);
	ifr.ifr_data = (char *) &args;
	ret = ioctl(s, SIOCDEVPRIVATE, (unsigned long)&ifr);
err:
	__net_config_close(s);
	return ret;
}
int br_add_bridge(int brno)
{
	int ret;
	const char *brname = br_no2name(brno);

	if (!brname)
		return -1;

	ret = __br_add_bridge(brname);

	if (ret < 0) {
		br_log(BR_LOG_ERR,  "DEVICE: add bridge <%s> failure", brname);
	} else
		br_log(BR_LOG_INFO, "DEVICE: add bridge <%s> success.", brname);
	return ret;
}




void br_del_bridge(int brno)
{
	int ret;
	const char *brname = br_no2name(brno);

	if (!brname)
		return;

	ret = __br_del_bridge(brname);
	if (ret < 0) {
		br_log(BR_LOG_ERR, "DEVICE: del bridge <%s> failure",
		       brname);
	} else 
		br_log(BR_LOG_INFO, "DEVICE: del bridge <%s> success.",
		       brname);
}

int br_add_interface(int brno, bridge_port_t *port)
{
	int ret;
	const char *brname = br_no2name(brno);

	if (!brname)
		return -1;

	ret = __br_add_interface(brname, port->dev->ifindex);
	if (ret < 0) {
		br_log(BR_LOG_ERR, "DEVICE: bridge <%s> add port <%s> failure",
		       brname, port->dev->ifname);

		port->in_kernel = 0;
	} else {
		br_log(BR_LOG_INFO, "DEVICE: bridge <%s> add port <%s> success.",
		       brname, port->dev->ifname);

		port->in_kernel = 1;
	}
	return ret;
}

void br_del_interface(int brno, bridge_port_t *port)
{
	int ret;
	const char *brname = br_no2name(brno);

	if (!brname)
		return;

	ret = __br_del_interface(brname, port->dev->ifindex);
	if (ret < 0) {
		br_log(BR_LOG_ERR, "DEVICE: <%s> del port=%s failure",
		       brname, port->dev->ifname);
	} else {
		br_log(BR_LOG_INFO, "DEVICE: <%s> del port=%s success.",
		       brname, port->dev->ifname);
		port->in_kernel = 0;
	}
}

int br_enable_bridge_stp(int brno)
{
	const char *brname = br_no2name(brno);
	if (!brname)
		return -1;

	return __br_set(brname, "stp_state", TRUE, 
		        BRCTL_SET_BRIDGE_STP_STATE);
}

int br_disable_bridge_stp(int brno)
{
	const char *brname = br_no2name(brno);
	if (!brname)
		return -1;
	
	return __br_set(brname, "stp_state", FALSE, 
		        BRCTL_SET_BRIDGE_STP_STATE);
}

