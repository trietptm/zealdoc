#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv)
{
    union {
          struct {
              char a : 1;          
              char b : 2;          
              char c : 3;        
          } d;
        char e;
    } f;
    
    f.e = 1;
    printf("%d\n",f.d.c);   
    getchar();
    return 0;
}