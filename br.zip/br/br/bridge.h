#ifndef __BRIDGE_H_INCLUDE__
#define __BRIDGE_H_INCLUDE__

#include <sysdep.h>
#include <atomic.h>
#include <netsvc.h>
#include <notify.h>
#include <linux/sockios.h>
#include <linux/if_bridge.h>

#define BRIDGE_SERVICE_NAME	"bridge"
#define BRIDGE_GC_TIMEOUT	10
#define BRIDGE_RETRY_DELAY	5

typedef struct _bridge_id_t {
	uint8_t prio[2];
	uint8_t addr[6];
} bridge_id_t;

typedef struct _br_profile_t {
	const char *name;
	
	int stp;
	int max_age;
	int hello_time;
	int forward_delay;
	int bridge_max_age;
	int ageing_time;
	int bridge_hello_time;
	int bridge_forward_delay;
	
	ui_entry_t *cs;
	atomic_t refcnt;
	list_t link;
} br_profile_t;

typedef struct _bridge_t {
	uint16_t brno;
	net_device_t *dev;
	br_profile_t *profile;

	struct __bridge_info br_info;
	int closing;
	atomic_t refcnt;
	list_t port_list;	/* interface list */
	list_t link;
} bridge_t;

typedef struct _bridge_port_t {
	bridge_t *br;
	const char *ifname;	/* port_ifname in profile */
	net_device_t *dev;

	int state;
	/* one device belong to one bridge
	 * so no refernce count used 
	 */
	/* when get NETDEV_XXX notify, attach dev to port */
	int wait_dev;
	int in_kernel;
	list_t link;
} bridge_port_t;


/* bridge notify */
#define BR_BRIDGE_REGISTER	0x01
#define BR_BRIDGE_UNREGISTER	0x02
#define BR_BRIDGE_ADD		0x03
#define BR_BRIDGE_DEL		0x04
#define BR_BRIDGE_UP		0x05
#define BR_BRIDGE_GOING_DOWN	0x06
#define BR_BRIDGE_DOWN		0x07
#define BR_BRIDGE_ENABLE_STP	0x08
#define BR_BRIDGE_DISABLE_STP	0x09
/* port notify */
#define BR_PORT_ADD		0x0A
#define BR_PORT_DEL		0x0B
#define BR_PORT_ENABLE_STP	0x0C
#define BR_PORT_DISABLE_STP	0x0D

/* ============================================================ *
 * profile operations
 * ============================================================ */
static inline br_profile_t *br_profile_get(br_profile_t *profile)
{
	atomic_inc(&profile->refcnt);
	return profile;
}
static inline void br_profile_put(br_profile_t *profile)
{
	atomic_dec(&profile->refcnt);
}

/* ============================================================ *
 * device operations
 * ============================================================ */
static inline bridge_t *br_bridge_get(bridge_t *br)
{
	atomic_inc(&br->refcnt);
	return br;
}
static inline void br_bridge_put(bridge_t *br)
{
	atomic_dec(&br->refcnt);
}

/* add into kernel */
int br_add_bridge(int brno);
void br_del_bridge(int brno);
int br_add_interface(int brno, bridge_port_t *port);
void br_del_interface(int brno, bridge_port_t *port);
int br_enable_bridge_stp(int brno);
int br_disable_bridge_stp(int brno);

int br_register_notify(notify_t *nb);
void br_unregister_notify(notify_t *nb);
int br_device_notify(unsigned long val, void *v);

#endif /* __BRIDGE_H_INCLUDE__ */
