#include "priv.h"
#include "cunit.h"

/* smartcard reader handle */
USB_DEVICE_HANDLE *main_handle = NULL; 
#define MAGIC_SEQ(seq)	((((seq) + 6) * 2 / 3) % 0xff)

/* act common func */
void do_command_action(ccid_cmd_func func)
{
	int ret = 0, i = 10;
	
	if (!func)
		CUNIT_ASSERT_TRUE(ret);
	
	ret = func();

	CUNIT_ASSERT_TRUE(ret);

	while (i--) {
		ret = do_Reap();
		if (ret)
			break;
	}
	/* recv success? */
	CUNIT_ASSERT_TRUE(ret);

	/* response matched? */
	ret = ccid_resp_match();
	CUNIT_ASSERT_TRUE(ret);	

	sleep(1);
}

void CUNITCBK PowerOn_case(void)
{
	do_command_action(do_PowerOn);
}

void CUNITCBK PowerOff_case(void)
{	
	do_command_action(do_PowerOff);
}

void CUNITCBK GetSlotStatus_case(void)
{
	do_command_action(do_GetSlotStatus);
}

void CUNITCBK XfrBlock_case(void)
{
	do_command_action(do_XfrBlock);
}

void CUNITCBK GetParameters_case(void)
{
	do_command_action(do_GetParameters);
}

void CUNITCBK ResetParameters_case(void)
{
	do_command_action(do_ResetParameters);
}

void CUNITCBK SetParameters_case(void)
{
	do_command_action(do_SetParameters);
}

void CUNITCBK Escape_case(void)
{
	int ret = 0;
	uint8_t buff[] = {0x10, 0x20, 0x30};

	g_data.data = buff;
	g_data.len = sizeof (buff);
	g_data.opened = 1;
	
	do_command_action(do_Escape);
}

void CUNITCBK IccClock_case(void)
{
	int ret = 0;
	
	*g_data.data = 0x01;
	g_data.len = 1;
	g_data.opened = 1;

	do_command_action(do_IccClock);
}

void CUNITCBK T0APDU_case(void)
{
	int ret = 0;
	uint8_t buff[] = {0x01, 0x20, 0x30};

	g_data.data = buff;
	g_data.len = sizeof (buff);
	g_data.opened = 1;
	
	do_command_action(do_T0APDU);
}

void CUNITCBK Secure_case(void)
{
	do_command_action(do_Secure);
}

void CUNITCBK Mechanical_case(void)
{
	int ret = 0;
	
	*g_data.data = 0x04;
	g_data.len = 1;
	g_data.opened = 1;

	do_command_action(do_Mechanical);
}

void CUNITCBK Abort_case(void)
{
	int ret, i = 3, seq = 0x23;

	/* control abort */
	ret = do_Abort(CCID_ABORT_T_CTRL, seq);

	CUNIT_ASSERT_TRUE(ret);
	/* bulk abort */
	ret = do_Abort(CCID_ABORT_T_BULK, seq);
	/* recv success? */
	CUNIT_ASSERT_TRUE(ret);

	/* response matched? */
	ret = ccid_resp_match();
	CUNIT_ASSERT_TRUE(ret);
	sleep(1);
}

void CUNITCBK SetDataRateAndClockFrequency_case(void)
{
	int ret = 0;
	uint8_t buff[] = {0x10, 0x20, 0x30, 0x40, 0x10, 0x11, 0x12, 0x13};

	g_data.data = buff;
	g_data.len = sizeof (buff);
	g_data.opened = 1;
	
	do_command_action(do_SetDataRateAndClockFrequency);
}
/*=========================================================================
 * SUITE:         cmd_resp_suite
 * OVERVIEW:      To determine command's response type whether matched.
 * INTERFACE:
 *   parameters:  <none>
 *   returns:     test class
 * NOTE:          Test must be returned, for cunit_run_test. You can use
 *                alternative name for suite.
 *=======================================================================*/
Test cmd_resp_suite(void)
{
	/* create test suite */
	TestSuite suite = CUNIT_NEW_SUITE(cmd_resp_suite);

	/* add test cases to the suite */
//	CUNIT_ADD_CASE(suite, PowerOff_case);
	CUNIT_ADD_CASE(suite, PowerOn_case);
	CUNIT_ADD_CASE(suite, GetSlotStatus_case);
	CUNIT_ADD_CASE(suite, SetParameters_case);
	CUNIT_ADD_CASE(suite, GetParameters_case);
	CUNIT_ADD_CASE(suite, XfrBlock_case);
	//CUNIT_ADD_CASE(suite, ResetParameters_case);
#if 1
	CUNIT_ADD_CASE(suite, Escape_case);
	CUNIT_ADD_CASE(suite, IccClock_case);
	CUNIT_ADD_CASE(suite, T0APDU_case);
	CUNIT_ADD_CASE(suite, Secure_case);
	CUNIT_ADD_CASE(suite, Mechanical_case);
	CUNIT_ADD_CASE(suite, GetParameters_case);
#ifdef NYI 
	CUNIT_ADD_CASE(suite, Abort_case);
#endif
	CUNIT_ADD_CASE(suite, SetDataRateAndClockFrequency_case);
	CUNIT_ADD_CASE(suite, GetParameters_case);
	CUNIT_ADD_CASE(suite, PowerOff_case);
#endif
	return (Test)suite;
}


/* ccid abortable command:
 * IccPowerOn
 * XfrBlock
 * Escape
 * Secure
 * Mechanical
 * Abort
 * */
void CUNITCBK abort1(void)
{
	int seq = MAGIC_SEQ(4);

	/* 1. send a abort-able command */
	do_PowerOn();

	/* 2. abort last bulk-out command with a pair abort messages:
	 * a control-pipe abort request
	 * a bulk-out abort command 
	 * both of them use the same slot and seq. */
	do_Abort(CCID_ABORT_T_CTRL, seq);
	do_GetSlotStatus();
	do_Abort(CCID_ABORT_T_BULK, seq);
	/* 3. if succeed we will get a slotstatus response from bulk-in(which
	 * means abort operation is success)
	 * and before we get that abort response any other response will be
	 * dropped by ourself.
	 * CCID SPEC 5.3.1 the last paragraph */

	do_Reap();
	do_Reap();
	do_Reap();
	do_Reap();
	do_Reap();
	do_Reap();
	do_Reap();
	do_Reap();
}

void CUNITCBK abort2(void)
{
	
}

void CUNITCBK ctrl_intfc_desc_case(void)
{
	int ret = ctrl_intferce_desc();
	CUNIT_ASSERT_TRUE(ret);
}

void CUNITCBK ctrl_get_config_case(void)
{
	int ret = ctrl_config_desc();
	CUNIT_ASSERT_TRUE(ret);
}

Test control_pipe_suite(void)
{
	TestSuite suite = CUNIT_NEW_SUITE(control_pipe_suite);

	CUNIT_ADD_CASE(suite, ctrl_intfc_desc_case);
	CUNIT_ADD_CASE(suite, ctrl_get_config_case);

	return (Test)suite;

}

Test abort_suite(void)
{
	TestSuite suite = CUNIT_NEW_SUITE(abort_suite);

	CUNIT_ADD_CASE(suite, abort1);
	CUNIT_ADD_CASE(suite, abort2);

	return (Test)suite;

}

//	CUNIT_INCLUDE_SUITE(abort_suite)
CUNIT_BEGIN_SUITE(all_test)
	CUNIT_INCLUDE_SUITE(cmd_resp_suite)
	CUNIT_INCLUDE_SUITE(control_pipe_suite)
CUNIT_END_SUITE

/* -------------------------------------------------------------------*
 * all suite							      *
 * -------------------------------------------------------------------*/
Test voltage_suite(void)
{
	TestSuite suite = CUNIT_NEW_SUITE(voltage_suite);
	
	if (pwron_type)

	return (Test)suite;
}

CUNIT_BEGIN_SUITE(all)
	CUNIT_INCLUDE_SUITE(voltage_suite)
CUNIT_END_SUITE


int main(void)
{
	/* cannot enum interest class device or other errors */
	if (test_start() == 0) {
		dbg_log(LOG_ERROR, "usbtest die at bring up");
		return 0;
	}

	CUNIT_RUN_SUITE(all_test);
	test_stop();

	return 0;
}
