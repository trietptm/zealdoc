#ifndef __PRIV_H
#define __PRIV_H

#include <libusb-1.0/libusb.h>	/* libusb */

#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#ifndef WIN32
 #include <unistd.h>
 #include <errno.h>
#else
 #define __FUNCTION__	"fun()"
 #define sleep(x)	Sleep(x*1000)
 #define random		rand
 #define srandom		srand

 #define ftruncate(f,s)	chsize(f,s)
 #define msleep(x)	Sleep(x);
 #define sleep(x)	Sleep(x*1000)

#endif

typedef unsigned char 	uint8_t;
typedef unsigned short 	uint16_t;
typedef unsigned int	uint32_t;
#define USB_DEVICE_HANDLE libusb_device_handle

#define MAX_BUFFER_LEN		128
#define DEF_SLOT		0
#define DEF_TO			1000
extern uint8_t DEF_INTFC;

#ifdef ACS_READER
/* for ACS reader */
 #define INTEREST_CLASS		0x00
#else
 #define INTEREST_CLASS		0x0b
#endif


#include "ccid.h"

extern USB_DEVICE_HANDLE *main_handle; 
extern uint8_t DEF_INTFC;

enum usbi_log_level {
	LOG_DEBUG,
	LOG_INFO,
	LOG_WARNING,
	LOG_ERROR,
};

void dbg_log(int level, const char *format, ...);

int test_start(void);
void test_stop(void);
int test_bulk_send(uint8_t *snd, int slen, int print);
int test_bulk_recv(uint8_t *rcv, int rlen, int print);
int test_ctrl_msg(uint8_t reqType, uint8_t req, uint16_t value, 
		  uint16_t index, uint8_t *buff, uint16_t len);
void print_bin2hex(uint8_t *tmp_bin, int len, int t);
void log_close(void);
void log_open(void);

#endif /* __PRIV_H */
