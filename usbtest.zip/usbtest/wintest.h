#ifndef _WINTEST_H_
#define _WINTEST_H_

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <tchar.h>
#include <assert.h>

#include <Winscard.h>
#include <WinSmCrd.h>	/* IOCLT */

#endif /* _WINTEST_H_ */