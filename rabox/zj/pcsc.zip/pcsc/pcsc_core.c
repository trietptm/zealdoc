#include "pcsc_priv.h"
#include <udev.h>

int pcsc_logger = 0;
log_source_t pcsc_log_source = {
	"pcsc"
};

void pcsc_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(pcsc_logger, level, format, ap);
	va_end(ap);
}

static int __init pcsc_log_init(void)
{
	pcsc_logger = log_register_source(&pcsc_log_source);
	return !pcsc_logger;
}

static void __exit pcsc_log_exit(void)
{
	log_unregister_source(pcsc_logger);
}

ui_schema_t pscs_scheme[] = {
	/* .pcsc */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE,
	  UI_TYPE_STRING, NULL, NULL,
	  ".pcsc", "pcsc", PCSC_SERVICE_DESC },

	{ UI_TYPE_NONE },
};


modlinkage int __init pcsc_init(void)
{
	ui_register_schema(pscs_scheme);

	pcsc_log_init();

	pcsc_ifd_init();
	pcsc_icc_init();
	return 0;
}

modlinkage void __exit pcsc_exit(void)
{
	pcsc_icc_exit();
	pcsc_ifd_exit();

	pcsc_log_exit();
	ui_unregister_schema(pscs_scheme);
}

subsys_initcall(pcsc_init);
subsys_exitcall(pcsc_exit);
