#ifndef __PCSC_H__
#define __PCSC_H__
#include <sysdep.h>
#include <pcsc_pinpad.h>

#include <pcsc_defs.h>

#if 0
pcsc_ifd_hd_t *pcsc_connect(int reader_idx, int slot_idx);
int pcsc_disconnect(pcsc_ifd_hd_t *handle);
int pcsc_check_handle_valid(pcsc_ifd_hd_t *handle);

int pcsc_card_status(int reader_idx, int slot_idx, 
		     uint32_t *icc_status);
int pcsc_transmit(pcsc_trans_param_t *param);

int pcsc_ifd_control(pcsc_trans_param_t *param);
#endif


#endif /*__PCSC_H__*/
