#ifndef __PCSC_DEFS_H__
#define __PCSC_DEFS_H__

/* ALL pcsc / ccid / scard define and enum */

/* ifd exchange (ESCAPE command) */
#define IOCTL_SMARTCARD_VENDOR_IFD_EXCHANGE	SCARD_CTL_CODE(1)

#define PCSC_SERVICE_DESC	"Personal computer smart card"

#define PCSC_MAX_READERS	16
#define PCSC_MAX_DEVID_PARTS	5
#define PCSC_MAX_ATR		33

enum pcsc_reader_type {
	PCSC_READER_TYPE_USB = 1,
};

enum pcsc_reader_status {
	PCSC_READER_STATUS_FAILED	= 0x0000,
	PCSC_READER_STATUS_ABSENT	= 0x0001,
	PCSC_READER_STATUS_PRESENT	= 0x0010,
};

enum pcsc_card_status {
	PCSC_CARD_STATUS_UNKNOWN	= 0xFFFF,	/*Unknown state */
	PCSC_CARD_PRESENT_MASK		= 0x00F0,
	PCSC_CARD_POWER_MASK		= 0x000F,

	PCSC_CARD_PRESENT_POWERUP	= 0x0011,
	PCSC_CARD_PRESENT_POWERDOWN	= 0x0010,
	PCSC_CARD_ABSENT		= 0x0000,

	PCSC_CARD_STATUS_NEGOTIABLE	= 0x0200,	/*Ready for PTS*/
	PCSC_CARD_STATUS_SPECIFIC	= 0x0400,	/*PTS has been set*/
};

enum pcsc_protocol {
	PCSC_PROTOCOL_UNKNOWN	= 0x00000000,
	PCSC_PROTOCOL_T0	= 0x00000001,
	PCSC_PROTOCOL_T1	= 0x00000002,
	PCSC_PROTOCOL_T15	= 0x00000008,
};

enum pcsc_error {
	PCSC_S_SUCCESS			= 0,
	PCSC_E_NO_MEMORY		= -1,
	PCSC_E_INVALID_HANDLE		= -2,
	PCSC_E_INVALID_PARAMETER	= -3,
	PCSC_E_INSUFFICIENT_BUFFER	= -4,
	PCSC_E_CANCELLED		= -5,
	PCSC_E_TIMEOUT			= -6, /*  The user-specified timeout value has expired. */
	PCSC_E_SHARING_VIOLATION	= -7,
	PCSC_E_NOT_SUPPORTED		= -8,
	PCSC_E_NOT_READY		= -9,
	PCSC_E_INVALID_SLOT		= -10,
	
	PCSC_E_NO_SMARTCARD		= -20,
	PCSC_E_UNKNOWN_CARD		= -21,
	PCSC_E_PROTO_MISMATCH		= -22,
	PCSC_E_INVALID_ATR		= -23,
	
	PCSC_E_UNRESPONSIVE_CARD	= -30,
	PCSC_E_UNPOWERED_CARD		= -31,
	PCSC_E_RESET_CARD		= -32,
	PCSC_E_REMOVED_CARD		= -33,
	PCSC_E_INSERTED_CARD		= -34,

	PCSC_E_NO_READER		= -40,
	PCSC_E_UNKNOWN_READER		= -41,
	PCSC_E_READER_UNAVAILABLE	= -42, /*  The specified reader is not currently available for use. */
	PCSC_E_READER_BUSY		= -43, 
	
	PCSC_F_INTERNAL_ERROR		= -99,
};

enum atr_info_ts {
	PCSC_ATR_TS_DIRECT	= 0x01,
	PCSC_ATR_TS_INVERSE	= 0x02,
};

#define PCSC_GET_ATTR_SN	0x01	/* slot number */

#endif /* __PCSC_DEFS_H__ */

