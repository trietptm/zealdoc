#ifndef __PCSC_ICC_H__
#define __PCSC_ICC_H__

/* 
 * call-chain: parent create first, two layer
 * child: ICC driver
 * parent: ICC
 */

typedef struct _pcsc_icc_t	pcsc_icc_t;	/* card */

typedef struct __icc_driver_t {
	const char *name;
	int (*match)(pcsc_icc_t *);
	int (*open)(pcsc_icc_t *);


	list_t link;
} icc_driver_t;

/* card */
struct _pcsc_icc_t {
	uint8_t atr[PCSC_MAX_ATR];
	size_t atr_len;
	int proto;
	int proto_supported;
	icc_driver_t *icc_ops;
	
	atomic_t refcnt;

	list_t link;
};



pcsc_icc_t *pcsc_icc_new(void);
void pcsc_icc_free(pcsc_icc_t *icc);

#endif	/* __PCSC_ICC_H__ */