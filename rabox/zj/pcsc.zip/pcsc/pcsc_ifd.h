#ifndef __PCSC_IFD_H__
#define __PCSC_IFD_H__

#include "pcsc_icc.h"

/* 
 * call-chain: child create first, two layer
 * child: IFD driver
 * parent: IFD
 */

typedef struct pcsc_transmit_param pcsc_trans_param_t;
typedef struct _pcsc_ifd_t	pcsc_ifd_t;	/* reader */
typedef struct _pcsc_ifd_hd_t   pcsc_ifd_hd_t;	/* reader handle */
typedef struct _pcsc_slot_t	pcsc_slot_t;	/* slot */

typedef void (*pcsc_ifd_hd_cb)(pcsc_ifd_hd_t *hd);
typedef void (*pcsc_trans_comp)(pcsc_trans_param_t *pcsc_param);

typedef struct __ifd_driver_t {
	const char *name;
	int (*get_desc_attr)(void *lower, int type, void *v);
	int (*get_feature)(pcsc_ifd_hd_t *);
	int (*cancel)(pcsc_ifd_hd_t *);
	int (*icc_status)(pcsc_ifd_hd_t *);
	int (*power_on)(pcsc_ifd_hd_t *);
	int (*power_off)(pcsc_ifd_hd_t *);
	int (*xfr_block)(pcsc_ifd_hd_t *,
			 pcsc_trans_param_t *pcsc_param);
	int (*ifd_ctl)(pcsc_ifd_hd_t *, pcsc_trans_param_t *pcsc_param);
} ifd_driver_t;

/* slot on the reader, sturct icc must not NULL */
/* FIXME: this struct belong to? */
struct _pcsc_slot_t {
	int idx;	
	pcsc_icc_t *icc;
	/* insert times */
	uint32_t icc_seq;
	uint32_t card_status;
};

/* reader, struct slots must not NULL */
struct _pcsc_ifd_t {
	char *name;
	int type;	/* device type */
	uint16_t idx;	/* reader index in system */
	uint32_t reader_status;

	int nslots;
	pcsc_slot_t *slots;
	list_t handles;
	/* FIXME: whats this? */
	struct pcsc_path10_data path10;

	/* below is ext feature of this reader */
	/* When you open the reader, you should determine(FIXME: How to ?) 
	 * wheter the reader support keypad/display. 
	 * SPEC: extend ifd.
	 */
	int keypad;
	int display;
	int row_num;
	int col_num;

	atomic_t refcnt;

	list_t link;
};

/* reader handle */
struct _pcsc_ifd_hd_t {
	pcsc_ifd_t *reader;
	
	/* one slot on the reader which will bind with a ICC */
	pcsc_slot_t *slot;
	uint32_t icc_status;	/* keep old status */
	int slot_idx;	/* from 0 ~ */

	pcsc_ifd_hd_cb cb;
	int ret;

	stm_instance_t *fsmi;
	ifd_driver_t *ifd_ops;	/* driver ops */
	void *lower;		/* ccid_reader_t */

	list_t link;
	atomic_t refcnt;
};

struct pcsc_transmit_param {
	pcsc_ifd_hd_t *handle;

	uint32_t ioctl;

	int ret;
	uint8_t *sbuf;
	size_t sbuf_len;
	uint8_t *rbuf;
	size_t rbuf_len;
	size_t rbuf_actual;
	uint32_t card_status;

	pcsc_trans_comp callback;
	void *user_data;
};

void __exit ifd_ccid_exit(void);
int __init ifd_ccid_init(void);


/* ============================================================ *
 * API for lower
 * ============================================================ */
int pcsc_ifd_up(const char *name, int type, void *lower, ifd_driver_t *ops);
int pcsc_ifd_down(const char *name, int type, void *lower);

#endif	/* __PCSC_IFD_H__ */