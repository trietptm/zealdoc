#ifndef __PCSC_PRIV_H__
#define __PCSC_PRIV_H__

#include <sysdep.h>
#include <logger.h>
#include <panic.h>
#include <module.h>
#include <strutl.h>
#include <dfastm.h>
#include <eloop.h>
#include <service.h>
#include <list.h>
#include <pcsc.h>
#include <bitops.h>

#include "pcsc_ifd.h"
#include "pcsc_icc.h"

/*Logging operations*/
#define PCSC_LOG_CRIT	LOG_EMERG
#define PCSC_LOG_FAIL	LOG_CRIT
#define PCSC_LOG_ERR	LOG_ERR
#define PCSC_LOG_WARN	LOG_WARNING
#define PCSC_LOG_INFO	LOG_INFO
#define PCSC_LOG_DEBUG	LOG_DEBUG

void pcsc_log(int level, const char *format, ...);


struct pcsc_atr_info {
	uint8_t TS;
	uint8_t T0;
	uint8_t history_len;

	int supported_protos;
	int default_proto;
	
};


int pcsc_parse_atr(const char *atr, size_t atr_len, 
		   struct pcsc_atr_info *atr_info);
int pcsc_default_proto(const uint8_t *atr, size_t atr_len, 
			      int *def_pro);
int pcsc_support_proto(const uint8_t *atr, size_t atr_len, 
			int *supp_proto);

int pcsc_reader_down(const char *filename);
int pcsc_icc_poweron(pcsc_ifd_hd_t *);
int pcsc_icc_poweroff(pcsc_ifd_hd_t *);
int pcsc_icc_insert(pcsc_ifd_hd_t *);
int pcsc_icc_remove(pcsc_ifd_hd_t *);


int __init pcsc_ifd_init(void);
void __exit pcsc_ifd_exit(void);

int __init pcsc_icc_init(void);
void __exit pcsc_icc_exit(void);


/* call-chain */
void __icc_create(pcsc_icc_t *icc);
void icc_create(void);
void icc_new(void);
void icc_start(void);
void icc_bind(void);
void icc_up(void);

#endif /*__PCSC_PRIV_H__*/
