#include "pcsc_priv.h"
#include "pcsc_icc.h"

DECLARE_LIST(pcsc_icc_list);

#define for_each_icc(e)	\
	list_for_each_entry(pcsc_icc_t, e, &pcsc_icc_list, link)

pcsc_icc_t *pcsc_icc_new(void)
{
	pcsc_icc_t *icc = malloc(sizeof (pcsc_icc_t));

	if (!icc)
		return NULL;
	memset(icc, 0, sizeof (pcsc_icc_t));

	list_init(&icc->link);
	list_insert_before(&icc->link, &pcsc_icc_list);
	atomic_set(&icc->refcnt, 1);
	pcsc_log(PCSC_LOG_DEBUG, "ICC: create icc");
	return icc;
}

void pcsc_icc_free(pcsc_icc_t *icc)
{
	if (atomic_dec_and_test(&icc->refcnt)) {
		list_delete(&icc->link);
		free(icc);
		pcsc_log(PCSC_LOG_DEBUG, "ICC: delete icc");
	}
}


static int pcsc_icc_cmd_dump(ui_session_t *sess, ui_entry_t *inst,
			     void *ctx, int argc, char **argv)
{
	ui_table_t *table = ui_table_by_name(sess, "pcsc_ifd_list");
#if 0
	char buf[25] = "";
	int i = 0;
#endif
	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "pcsc_ifd_list");
	if (!table)
		return -1;

	sess->result_table = table;
	return 0;
}

ui_schema_t pscs_icc_scheme[] = {

	/* .pcsc.icc */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".pcsc.icc", "icc", "PCSC smart cards" },

	{ UI_TYPE_NONE },
};


ui_command_t pscs_icc_command = {
	"dump",
	"Dump all icc on the system",
	".pcsc.icc",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(pscs_icc_command.link),
	pcsc_icc_cmd_dump,
};


int __init pcsc_icc_init(void)
{
	ui_register_schema(pscs_icc_scheme);
	ui_register_command(&pscs_icc_command);
	/* icc driver init */
	return 0;
}

void __exit pcsc_icc_exit(void)
{
	ui_unregister_command(&pscs_icc_command);
	ui_unregister_schema(pscs_icc_scheme);

}

DECLARE_LIST(icc_drv_list);

#define for_each_driver(e)	\
	list_for_each_entry(icc_driver_t, e, &icc_drv_list, link)

icc_driver_t *icc_driver_by_name(const char *name)
{
	icc_driver_t *drv;

	for_each_driver(drv) {
		if (name && strcmp(name, drv->name) == 0)
			return drv;
	}
	return NULL;
}

int icc_register_driver(icc_driver_t *type)
{
	icc_driver_t *tmp;

	tmp = icc_driver_by_name(type->name);
	if (!tmp) {
		list_init(&type->link);
		list_insert_before(&type->link, &icc_drv_list);
	}
	return 0;
}

void icc_unregister_driver(icc_driver_t *phys)
{
	icc_driver_t *tmp;

	tmp = icc_driver_by_name(phys->name);
	if (tmp) {
		list_delete(&tmp->link);
	}
}

icc_driver_t *icc_match_one_driver(pcsc_icc_t *icc)
{
	icc_driver_t *drv;
	for_each_driver(drv) {
		if (drv->match && drv->match(icc))
			return drv;
	}
	return NULL;
}

/* icc is exist */
void __icc_create(pcsc_icc_t *icc)
{
	icc_driver_t *drv;

	icc_new();
	icc_start();
	/* icc_find_driver then open it */
	drv = icc_match_one_driver(icc);

	if (drv && drv->open)
		;
}

void icc_create(void)
{}

void icc_new(void)
{/* NULL */}

void icc_start(void)
{/* NULL */}

void icc_bind(void)
{}

void icc_up(void)
{}
