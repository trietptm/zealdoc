#include <pcap.h>
#include <spoof.h>
#include <eloop.h>
#include <netsvc.h>
#include <logger.h>
#include <strutl.h>

extern eloop_t *eloop_main;

typedef struct _eloop_pcap_t {
	pcap_t *cap;
	eloop_t *eloop;
	int id;
	const char *ifname;
	const char *filter;
	/* packet proxy port */
	int sock;
	uint32_t addr;
	uint16_t port;
	int stopping;
	eloop_sock_cb handler;
	void *user_data;
	list_t link;
} eloop_pcap_t;

DECLARE_LIST(eloop_captures);

eloop_pcap_t *eloop_find_pcap_handler(eloop_t *eloop,
				      const char *ifname,
				      const char *filter,
				      eloop_sock_cb handler);

eloop_pcap_t *eloop_find_pcap_handler(eloop_t *eloop,
				      const char *ifname,
				      const char *filter,
				      eloop_sock_cb handler)
{
	eloop_pcap_t *pcap;
	list_t *pos, *n;

	if (!eloop)
		eloop = eloop_main;
	list_iterate_forward(pos, n, &eloop_captures) {
		pcap = list_entry(pos, eloop_pcap_t, link);
		if (pcap->eloop == eloop &&
		    strcasecmp(pcap->ifname, ifname) == 0 &&
		    strcasecmp(pcap->filter, filter) == 0 &&
		    pcap->handler == handler)
			return pcap;
	}
	return NULL;
}

static eloop_pcap_t *eloop_pcap_by_id(int id)
{
	eloop_pcap_t *pcap;
	list_t *pos, *n;

	list_iterate_forward(pos, n, &eloop_captures) {
		pcap = list_entry(pos, eloop_pcap_t, link);
		if (pcap->id == id)
			return pcap;
	}
	return NULL;
}

#ifdef WIN32
static int eloop_pcap_last_id = 0;

static int eloop_pcap_alloc_id(void)
{
	uint16_t id;
	int looped_id;

	if (!eloop_pcap_last_id)
		eloop_pcap_last_id++;
	looped_id = eloop_pcap_last_id;
	do {
		eloop_pcap_last_id++;
		if (!eloop_pcap_last_id)
			eloop_pcap_last_id++;
		id = eloop_pcap_last_id;
		if (id == looped_id)
			return 0;
	} while (!id || eloop_pcap_by_id(id));
	return id;
}

static int __eloop_pcap_get_sock(void)
{
	int res;
	int sock;
	int on = 1;
	struct sockaddr_in saddr;

	sock = socket(PF_INET, SOCK_DGRAM, 0);
	if (sock < 0)
		return -1;
 	(void) setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on));

	memset(&saddr, 0, sizeof(saddr));
	saddr.sin_family = AF_INET;
	saddr.sin_port = 0;
	saddr.sin_addr.s_addr = INADDR_ANY;

	res = bind(sock, (struct sockaddr *) &saddr, sizeof(saddr));
	if (res < 0) {
		closesocket(sock);
		return -1;
	}
	return sock;
}

static void eloop_pcap_handler(u_char *args,
			       const struct pcap_pkthdr *header,
			       const u_char *packet)
{
	struct sockaddr_in addr;
	int sock;
	int res;
	int len = sizeof (addr);
	eloop_pcap_t *pcap = (eloop_pcap_t *)args;

	sock = __eloop_pcap_get_sock();
	if (sock >= 0) {
		memset(&addr, 0, sizeof (addr));
		addr.sin_family = AF_INET;
		addr.sin_addr.s_addr = pcap->addr;
		addr.sin_port = pcap->port;
		res = sendto(sock, packet, header->caplen, 0,
			     (struct sockaddr *)&addr, len);

		if (res < 0)
			log_kern(LOG_ERR, "PCAP: cannot sendto pcap.");
		else
			log_kern(LOG_INFO, "PCAP: sendto pcap, addr=%s:%d, bytes=%d",
				 inet_addr_ntoa(pcap->addr),
				 ntohs(pcap->port), res);
		closesocket(sock);
	}
}

static void eloop_pcap_proxy(int sock, void *eloop_data, void *user_data)
{
	eloop_pcap_t *pcap = (eloop_pcap_t *)user_data;
	if (!pcap->stopping)
		pcap->handler(pcap->id, eloop_data, pcap->user_data);
}

static void eloop_pcap_thread(void *param)
{
	eloop_pcap_t *pcap = (eloop_pcap_t *)param;

	while (!pcap->stopping) {
		pcap_dispatch(pcap->cap, 0, eloop_pcap_handler,
			      (unsigned char *)pcap);
	}
	pcap_close(pcap->cap);
	free(pcap);
	_endthread();
}

int eloop_get_output_descriptor(eloop_t *eloop,
				const char *ifname,
				const char *filter,
				eloop_sock_cb handler)
{
	eloop_pcap_t *pcap = eloop_find_pcap_handler(eloop, ifname, filter, handler);
	return pcap ? pcap->id : 0;
}

int eloop_register_pcap_handler(eloop_t *eloop,
				const char *ifname, const char *filter,
				eloop_sock_cb handler,
				void *eloop_data, void *user_data)
{
	int res;
	pcap_t *cap = NULL;
	net_device_t *dev = net_device_by_name(ifname);
	struct bpf_program bpf;
	char error[PCAP_ERRBUF_SIZE];
	eloop_pcap_t *pcap = NULL;
	int sock = -1, id;
	struct sockaddr_in addr;
	int len = sizeof (addr);

	if (!dev)
		return -1;
	if (!eloop)
		eloop = eloop_main;

	cap = pcap_open_live(net_device_name(dev), dev->mtu, 1, 1000, error);
	if (cap) {
		res = pcap_compile(cap, &bpf, filter, 1, -1);
		if (res < 0)
			goto failure;
		if (pcap_setfilter(cap, &bpf) < 0)
			goto failure;
		sock = __eloop_pcap_get_sock();
		if (sock < 0)
			goto failure;
		res = getsockname(sock, (struct sockaddr *)&addr, &len);
		if (res < 0)
			goto failure;
		id = eloop_pcap_alloc_id();
		if (!id)
			goto failure;

		pcap = malloc(sizeof (eloop_pcap_t));
		if (pcap) {
			memset(pcap, 0, sizeof (pcap));
			pcap->cap = cap;
			if (addr.sin_addr.s_addr)
				pcap->addr = addr.sin_addr.s_addr;
			else
				pcap->addr = inet_addr("127.0.0.1");
			pcap->port = addr.sin_port;
			pcap->eloop = eloop;
			pcap->ifname = ifname;
			pcap->filter = filter;
			pcap->handler = handler;
			pcap->user_data = user_data;
			pcap->sock = sock;
			pcap->stopping = 0;
			pcap->id = id;
			eloop_register_read_sock(eloop, pcap->sock,
						 eloop_pcap_proxy,
						 eloop_data, pcap);
			_beginthread(eloop_pcap_thread, 0, pcap);
			list_init(&pcap->link);
			list_insert_before(&pcap->link, &eloop_captures);
			return 0;
		}
	}

failure:
	if (cap) pcap_close(cap);
	if (sock >= 0) closesocket(sock);
	return -1;
}

int eloop_unregister_pcap_handler(eloop_t *eloop,
				  const char *ifname, const char *filter,
				  eloop_sock_cb handler)
{
	eloop_pcap_t *pcap;

	pcap = eloop_find_pcap_handler(eloop, ifname, filter, handler);
	if (pcap) {
		list_delete(&pcap->link);
		eloop_unregister_read_sock(pcap->eloop, pcap->sock);
		closesocket(pcap->sock);
		pcap->stopping = 1;
	}
	return 0;
}
#else
int eloop_register_pcap_handler(eloop_t *eloop,
				const char *ifname, const char *filter,
				eloop_sock_cb handler,
				void *eloop_data, void *user_data)
{
	int res;
	pcap_t *cap = NULL;
	net_device_t *dev = net_device_by_name(ifname);
	struct bpf_program bpf;
	char error[PCAP_ERRBUF_SIZE];
	eloop_pcap_t *pcap = NULL;

	if (!dev)
		return -1;
	if (!eloop)
		eloop = eloop_main;

	cap = pcap_open_live(dev->ifname, dev->mtu, 1, 1000, error);
	if (cap) {
		res = pcap_compile(cap, &bpf, filter, 1, -1);
		if (res < 0)
			goto failure;
		if (pcap_setfilter(cap, &bpf) < 0)
			goto failure;

		pcap = malloc(sizeof (eloop_pcap_t));
		if (pcap) {
			memset(pcap, 0, sizeof (pcap));
			pcap->cap = cap;
			pcap->eloop = eloop;
			pcap->ifname = ifname;
			pcap->filter = filter;
			pcap->handler = handler;
			pcap->user_data = user_data;
			pcap->sock = pcap_get_selectable_fd(cap);
			pcap->id = pcap->sock;
			pcap->stopping = 0;
			eloop_register_read_sock(eloop, pcap->sock,
						 handler,
						 eloop_data, user_data);
			list_init(&pcap->link);
			list_insert_before(&pcap->link, &eloop_captures);
			return 0;
		}
	}

failure:
	if (cap) pcap_close(cap);
	return -1;
}

int eloop_unregister_pcap_handler(eloop_t *eloop,
				  const char *ifname, const char *filter,
				  eloop_sock_cb handler)
{
	eloop_pcap_t *pcap;

	pcap = eloop_find_pcap_handler(eloop, ifname, filter, handler);
	if (pcap) {
		list_delete(&pcap->link);
		eloop_unregister_read_sock(pcap->eloop, pcap->sock);
		pcap->stopping = 1;
		pcap_close(pcap->cap);
		free(pcap);
	}
	return 0;
}

int eloop_get_output_descriptor(eloop_t *eloop,
				const char *ifname,
				const char *filter,
				eloop_sock_cb handler)
{
	eloop_pcap_t *pcap = eloop_find_pcap_handler(eloop, ifname,
						     filter, handler);
	return pcap ? pcap_get_selectable_fd(pcap->cap) : -1;
}
#endif

int eloop_pcap_send_packet(int id, uint8_t *packet, size_t length)
{
	eloop_pcap_t *pcap = eloop_pcap_by_id(id);

	if (pcap)
		return pcap_sendpacket(pcap->cap, packet, length);
	return -1;
}

int eloop_pcap_recv_packet(int id, uint8_t *packet, size_t length)
{
	eloop_pcap_t *pcap = eloop_pcap_by_id(id);

	if (pcap)
		return recv(pcap->sock, packet, length, 0);
	return -1;
}
