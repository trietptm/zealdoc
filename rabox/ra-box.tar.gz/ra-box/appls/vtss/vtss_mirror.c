#include "vtss_priv.h"

int vtss_mirror_start(void)
{
	/* Initialize mirror port */
	vtss_mac_state.mirror_port = 0; /* Mirror port disabled */
	return 0;
}
