/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.

*/

#include "vtss_priv.h"
#include "vtss_grocx.h"

#ifdef CONFIG_VTSS_GROCX

/* - Star switch specific ------------------------------------------ */
/* device name to do ioctl */
static char vtss_ioctl_dev[] = "eth0";

int vtss_grocx_router_mac1_control(vtss_grx_mac1_control_t * mac1_control)
{
	struct ifreq ifr;
	int err;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	if (s < 0) {
		vtss_log(VTSS_LOG_ERR,
			 "GROCX: socket(AF_INET, SOCK_DGRAM) failed");
		return VTSS_FATAL_ERROR;
	}

	memset(&ifr, 0, sizeof(ifr));
	strcpy(ifr.ifr_name, vtss_ioctl_dev);
	
	ifr.ifr_data = (caddr_t)mac1_control;
	
	err = ioctl(s, SIOCDEVPRIVATE, (unsigned long)&ifr);
	closesocket(s);
	if (err < 0) {
		vtss_log(VTSS_LOG_ERR,
			 "GROCX: ioctl(SIOCDEVPRIVATE - mac1) failed");
		return VTSS_FATAL_ERROR;
	}
	return 0;
}

/* - wrapper for vtss_grocx_* ------------------------------------------ */
static int vtss_grocx_router_port_setup(const vtss_grocx_port_conf_t * const setup)
{
	vtss_grx_mac1_control_t ctl;
	
	ctl.an = setup->autoneg;
	switch (setup->speed) {
        case VTSS_SPEED_10M:
		ctl.force_speed = FORCE_10;
		ctl.giga_mode = MODE_10_100;
		break;
	case VTSS_SPEED_100M:
		ctl.force_speed = FORCE_100;
		ctl.giga_mode = MODE_10_100;
		break;
	case VTSS_SPEED_1G:
		ctl.force_speed = FORCE_1000;
		ctl.giga_mode = MODE_10_100_1000;
		break;
	default:
		break;
	}
	
	ctl.force_fc_tx = setup->flow_control;
	ctl.force_fc_rx = setup->flow_control;
	
	ctl.cmd = VTSS_GRX_IOCTL_MAC1_CONTROL;
	
	if (setup->fdx == 1)
		ctl.force_duplex = FULL_DUPLEX;
	else
		ctl.force_duplex = HALF_DUPLEX;
	
	vtss_grocx_router_mac1_control(&ctl);
	return 0;
}

int vtss_grocx_port_setup(const vtss_port_no_t port_no,
			  const vtss_grocx_port_conf_t * const setup)
{
	vtss_port_setup_t port_setup, *ps;
	
	if (port_no == 1)
		return vtss_grocx_router_port_setup(setup);
	ps = &port_setup;
	memset(ps, 0, sizeof(*ps));
	ps->interface_mode.interface_type = VTSS_PORT_INTERFACE_INTERNAL;
	ps->powerdown = (setup->enable ? 0 : 1);
	ps->maxframelength = setup->maxframelength;
	ps->frame_gaps.hdx_gap_1 = VTSS_FRAME_GAP_DEFAULT;
	ps->frame_gaps.hdx_gap_2 = VTSS_FRAME_GAP_DEFAULT;
	ps->frame_gaps.fdx_gap = VTSS_FRAME_GAP_DEFAULT;
	ps->interface_mode.speed = setup->speed;
	ps->fdx = setup->fdx;
	ps->flowcontrol.obey = setup->flow_control;
	ps->flowcontrol.generate = setup->flow_control; 
	
	return vtss_port_setup(port_no, ps);
}
#endif
