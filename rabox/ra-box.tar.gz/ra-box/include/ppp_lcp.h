/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2005
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@hzcnc.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)ppp_lcp.h: link control protocol interface
 * $Id: ppp_lcp.h,v 1.62 2009-02-09 08:15:40 zhenglv Exp $
 */

#ifndef __PPP_LCP_H_INCLUDE__
#define __PPP_LCP_H_INCLUDE__

#include <ppp_nego.h>

/* RFC1771 The PPP Initial Configuration Options */
//#define LCP_CI_VENDOR			0	/* Vendor Specific */
#define LCP_CI_MRU			1	/* Maximum-Receive-Unit */
#define LCP_CI_ACCM			2	/* Async-Control-Character-Map */
#define LCP_CI_MAGIC			5	/* Magic-Number */
#define LCP_CI_PFC			7	/* Protocol-Field-Compression */
#define LCP_CI_ACFC			8	/* Address-and-Control-Field-Compression */

#ifndef PPP_MRU
#define PPP_MRU				1500
#endif
#define PPP_MIN_MRU			128	/* no MRUs below this */
#define PPP_MAX_MRU			16384	/* normally limit MRU to this */

/* LCP-specific packet types (code numbers) */
#define PPP_CODE_CONFREQ		1	/* Configuration Request */
#define PPP_CODE_CONFACK		2	/* Configuration Ack */
#define PPP_CODE_CONFNAK		3	/* Configuration Nak */
#define PPP_CODE_CONFREJ		4	/* Configuration Reject */
#define PPP_CODE_TERMREQ		5	/* Termination Request */
#define PPP_CODE_TERMACK		6	/* Termination Ack */
#define PPP_CODE_CODEREJ		7	/* Code Reject */

#define PPP_CODE_NAME(x)		((x) == PPP_CODE_CONFACK ? "Configure-Ack" : \
					 (x) == PPP_CODE_CONFNAK ? "Configure-Nak" : \
					                           "Configure-Reject")

#define PPP_PROTO_HDRLEN		4

#define PPP_CILEN_VOID			2
#define PPP_CILEN_CHAR			3
#define PPP_CILEN_SHORT			4	/* PPP_CILEN_VOID + 2 */
#define PPP_CILEN_LONG			6	/* PPP_CILEN_VOID + 4 */

/* Packet header = Code, id, length */
#define LCP_HEADER_LEN			PPP_PROTO_HDRLEN

#define LCP_CODE_PROTREJ		8	/* Protocol Reject */
#define LCP_CODE_ECHOREQ		9	/* Echo Request */
#define LCP_CODE_ECHOREP		10	/* Echo Reply */
#define LCP_CODE_DISCREQ		11	/* Discard Request */
#define LCP_CODE_IDENTIF		12	/* Identification */
#define LCP_CODE_TIMEREM		13	/* Time Remaining */

typedef struct _lcp_option_t lcp_option_t;
typedef struct _lcp_extension_t lcp_extension_t;

struct _lcp_extension_t {
	uint8_t type;
	const char *name;

	int  (*init)(ppp_negoinst_t *inst);
	void (*exit)(ppp_negoinst_t *inst, lcp_option_t *opt);

	void (*opt_init)(lcp_option_t *opt);
	void (*opt_reset)(lcp_option_t *opti);
	int  (*opt_bcr)(lcp_option_t *opti, msgbuf_t *msg);
	int  (*opt_pcp)(lcp_option_t *opti, msgbuf_t *msg, uint8_t code);
	int  (*opt_rcr)(lcp_option_t *opti, msgbuf_t *req, msgbuf_t *nak, uint8_t *orc);
	void (*opt_rca)(lcp_option_t *opti, msgbuf_t *msg);
	void (*opt_rcn)(lcp_option_t *opti, msgbuf_t *msg);
	void (*opt_rcj)(lcp_option_t *opti, msgbuf_t *msg);

	bool (*opt_cnq)(lcp_option_t *opti);
	bool (*opt_cnp)(lcp_option_t *opti, msgbuf_t *req);
	bool (*opt_cnj)(lcp_option_t *opti, msgbuf_t *req);
	list_t link;
};

struct _lcp_option_t {
	lcp_extension_t *lcp_extension;
	ppp_negoinst_t *lcp_instance;

	int seen_nak_before;
	list_t link;
};

lcp_extension_t *lcp_find_extension(uint8_t type);
int lcp_register_extension(lcp_extension_t *opt);
void lcp_unregister_extension(lcp_extension_t *opt);

void lcp_option_enable(ppp_negoinst_t *insti, lcp_option_t *opt);
void lcp_option_disable(ppp_negoinst_t *insti, lcp_option_t *opt);

#endif
