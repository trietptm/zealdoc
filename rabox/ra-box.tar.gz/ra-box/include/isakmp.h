#ifndef __ISAKMP_H_INCLUDE__
#define __ISAKMP_H_INCLUDE__

#include <sysdep.h>
#include <list.h>
#include <uiserv.h>
#include <netsvc.h>
#include <dfastm.h>

#define ISAKMP_PORT		500
#define ISAKMP_NATT_PORT	4500

#define ISAKMP_DEF_NONCE_SIZE	16

#define ISAKMP_SERVICE_NAME	"isakmp"

#define ISAKMP_INITIATOR	0	/* synonym sender */
#define ISAKMP_RESPONDER	1	/* synonym receiver */

typedef uint8_t cookie_t[8];
typedef struct _isakmp_profile_t isakmp_profile_t;
typedef struct _isakmp_doi_t isakmp_doi_t;
typedef struct _isakmp_phase_t isakmp_phase_t;
typedef struct _isakmp_xchange_t isakmp_xchange_t;
typedef struct _isakmp_domain_t isakmp_domain_t;

typedef struct _isakmp_index_t {
	/* i_cookie + r_cookie */
	cookie_t i_ck;
	cookie_t r_ck;
} isakmp_index_t;

/* 3.1 ISAKMP Header Format
 *
 *    An ISAKMP message has a fixed header format, shown in Figure 2,
 *    followed by a variable number of payloads.  A fixed header
 *    simplifies parsing, providing the benefit of protocol parsing
 *    software that is less complex and easier to implement.  The fixed
 *    header contains the information required by the protocol to
 *    maintain state, process payloads and possibly prevent denial of
 *    service or replay attacks.
 *
 *                        1                   2                   3
 *    0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *   !                          Initiator                            !
 *   !                            Cookie                             !
 *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *   !                          Responder                            !
 *   !                            Cookie                             !
 *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *   !  Next Payload ! MjVer ! MnVer ! Exchange Type !     Flags     !
 *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *   !                          Message ID                           !
 *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *   !                            Length                             !
 *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 */
typedef struct _isakmp_message_t {
	uint8_t np;		/* Next Payload Type */
	uint8_t etype;		/* Exchange Type */
	uint8_t flags;		/* Flags */
	uint32_t msgid;
	uint32_t length;

	int encrypted;

	int extralen;
	list_t payload_list;
	time_t last_sent;
} isakmp_message_t;

#define ISAKMP_HDRLEN			28

/* Next Payload Type */
#define ISAKMP_NPTYPE_NONE		0	/* NONE*/
#define ISAKMP_NPTYPE_SA		1	/* Security Association */
#define ISAKMP_NPTYPE_P			2	/* Proposal */
#define ISAKMP_NPTYPE_T			3	/* Transform */
#define ISAKMP_NPTYPE_KE		4	/* Key Exchange */
#define ISAKMP_NPTYPE_ID		5	/* Identification */
#define ISAKMP_NPTYPE_CERT		6	/* Certificate */
#define ISAKMP_NPTYPE_CR		7	/* Certificate Request */
#define ISAKMP_NPTYPE_HASH		8	/* Hash */
#define ISAKMP_NPTYPE_SIG		9	/* Signature */
#define ISAKMP_NPTYPE_NONCE		10	/* Nonce */
#define ISAKMP_NPTYPE_N			11	/* Notification */
#define ISAKMP_NPTYPE_D			12	/* Delete */
#define ISAKMP_NPTYPE_VID		13	/* Vendor ID */

/* NAT-T draft-ietf-ipsec-nat-t-ike-05 and later */
/* XXX conflicts with values assigned to RFC 3547 */
#define ISAKMP_NPTYPE_NATD_BADDRAFT	15	/* NAT Discovery */
#define ISAKMP_NPTYPE_NATOA_BADDRAFT	16	/* NAT Original Address */

/* NAT-T RFC */
#define ISAKMP_NPTYPE_NATD_RFC		20	/* NAT Discovery */
#define ISAKMP_NPTYPE_NATOA_RFC		21	/* NAT Original Address */

/*	128 - 255 Private Use */
/* NAT-T up to draft-ietf-ipsec-nat-t-ike-04 */
#define ISAKMP_NPTYPE_NATD_DRAFT	130	/* NAT Discovery */
#define ISAKMP_NPTYPE_NATOA_DRAFT	131	/* NAT Original Address */

/* Frag does not seems to be documented */
#define ISAKMP_NPTYPE_FRAG		132	/* IKE fragmentation payload */

#define ISAKMP_NPTYPE_MAX		17

/* Major/Minor Version */
#define ISAKMP_MAJOR_VERSION		1
#define ISAKMP_MINOR_VERSION		0
#define ISAKMP_VERSION_NUMBER		0x10
#define ISAKMP_GETMAJORV(v)		(((v) & 0xf0) >> 4)
#define ISAKMP_SETMAJORV(v, m)		((v) = ((v) & 0x0f) | (((m) << 4) & 0xf0))
#define ISAKMP_GETMINORV(v)		((v) & 0x0f)
#define ISAKMP_SETMINORV(v, m)		((v) = ((v) & 0xf0) | ((m) & 0x0f))

/* Exchange Type */
#define ISAKMP_XCHG_NONE		0	/* NONE */
#define ISAKMP_XCHG_BASE		1	/* Base */
#define ISAKMP_XCHG_IDENT		2	/* Identity Proteciton */
#define ISAKMP_XCHG_AUTH		3	/* Authentication Only */
#define ISAKMP_XCHG_AGG			4	/* Aggressive */
#define ISAKMP_XCHG_INFO		5	/* Informational */
#define ISAKMP_XCHG_CFG			6	/* Mode config */
/* Additional Exchange Type */
#define ISAKMP_XCHG_QUICK		32	/* Quick Mode */
#define ISAKMP_XCHG_NEWGRP		33	/* New group Mode */
#define ISAKMP_XCHG_ACKINFO		34	/* Acknowledged Informational */

/* Flags */
#define ISAKMP_FLAG_E			0x01	/* Encryption Bit */
#define ISAKMP_FLAG_C			0x02	/* Commit Bit */
#define ISAKMP_FLAG_A			0x04	/* Authentication Only Bit */

/* 3.2 Payload Generic Header
         0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
        +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
        ! Next Payload  !   RESERVED    !         Payload Length        !
        +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
#define ISAKMP_GEN_HDRLEN		4

/* Certificate Type */
#define ISAKMP_CERT_NONE		0
#define ISAKMP_CERT_PKCS7		1
#define ISAKMP_CERT_PGP			2
#define ISAKMP_CERT_DNS			3
#define ISAKMP_CERT_X509SIGN		4
#define ISAKMP_CERT_X509KE		5
#define ISAKMP_CERT_KERBEROS		6
#define ISAKMP_CERT_CRL			7
#define ISAKMP_CERT_ARL			8
#define ISAKMP_CERT_SPKI		9
#define ISAKMP_CERT_X509ATTR		10
#define ISAKMP_CERT_PLAINRSA		11

/* flags */
#define ISAKMP_FRAG_LAST		1

/* 3.14.1 Notify Message Types */
/* NOTIFY MESSAGES - ERROR TYPES */
#define ISAKMP_ERROR_INVALID_PAYLOAD_TYPE	1
#define ISAKMP_ERROR_DOI_NOT_SUPPORTED		2
#define ISAKMP_ERROR_SITUATION_NOT_SUPPORTED	3
#define ISAKMP_ERROR_INVALID_COOKIE		4
#define ISAKMP_ERROR_INVALID_MAJOR_VERSION	5
#define ISAKMP_ERROR_INVALID_MINOR_VERSION	6
#define ISAKMP_ERROR_INVALID_EXCHANGE_TYPE	7
#define ISAKMP_ERROR_INVALID_FLAGS		8
#define ISAKMP_ERROR_INVALID_MESSAGE_ID	9
#define ISAKMP_ERROR_INVALID_PROTOCOL_ID	10
#define ISAKMP_ERROR_INVALID_SPI		11
#define ISAKMP_ERROR_INVALID_TRANSFORM_ID	12
#define ISAKMP_ERROR_ATTRIBUTES_NOT_SUPPORTED	13
#define ISAKMP_ERROR_NO_PROPOSAL_CHOSEN	14
#define ISAKMP_ERROR_BAD_PROPOSAL_SYNTAX	15
#define ISAKMP_ERROR_PAYLOAD_MALFORMED		16
#define ISAKMP_ERROR_INVALID_KEY_INFORMATION	17
#define ISAKMP_ERROR_INVALID_ID_INFORMATION	18
#define ISAKMP_ERROR_INVALID_CERT_ENCODING	19
#define ISAKMP_ERROR_INVALID_CERTIFICATE	20
#define ISAKMP_ERROR_BAD_CERT_REQUEST_SYNTAX	21
#define ISAKMP_ERROR_INVALID_CERT_AUTHORITY	22
#define ISAKMP_ERROR_INVALID_HASH_INFORMATION	23
#define ISAKMP_ERROR_AUTHENTICATION_FAILED	24
#define ISAKMP_ERROR_INVALID_SIGNATURE		25
#define ISAKMP_ERROR_ADDRESS_NOTIFICATION	26
#define ISAKMP_ERROR_NOTIFY_SA_LIFETIME		27
#define ISAKMP_ERROR_CERTIFICATE_UNAVAILABLE	28
#define ISAKMP_ERROR_UNSUPPORTED_EXCHANGE_TYPE	29
#define ISAKMP_ERROR_UNEQUAL_PAYLOAD_LENGTHS	30
#define ISAKMP_ERROR_MINERROR			1
#define ISAKMP_ERROR_MAXERROR			16383
/* NOTIFY MESSAGES - STATUS TYPES */
#define ISAKMP_ERROR_CONNECTED			16384
/* 4.6.3 IPSEC DOI Notify Message Types */
#define ISAKMP_ERROR_RESPONDER_LIFETIME	24576
#define ISAKMP_ERROR_REPLAY_STATUS		24577
#define ISAKMP_ERROR_INITIAL_CONTACT		24578

/* using only to log */
#define ISAKMP_ERROR_MIN			0
#define ISAKMP_ERROR_MAX			32768

#define ISAKMP_IS_EXTERNAL(e)	(e > ISAKMP_ERROR_MIN && e < ISAKMP_ERROR_MAX)
#define ISAKMP_IS_INTERNAL(e)	(e >= ISAKMP_ERROR_MAX)
#define ISAKMP_IS_SUCCESS(e)	(e == ISAKMP_ERROR_MIN)
#define ISAKMP_ERROR_SUCCESS			0
#define ISAKMP_ERROR_INVALID_DOI		65533
#define ISAKMP_ERROR_RETRY_LIMIT_REACHED	65534
#define ISAKMP_ERROR_INTERNAL			65535

#define ISAKMP_PHASE_NONE	0
#define ISAKMP_PHASE_ONE	1
#define ISAKMP_PHASE_TWO	2

#define ISAKMP_EVENT_START_REQ			0
#define ISAKMP_EVENT_STOP_REQ			1
#define ISAKMP_EVENT_TO_REMAIN			2
#define ISAKMP_EVENT_TO_EXPIRE			3
#define ISAKMP_EVENT_SA_EXPIRE			4

#define ISAKMP_STATE_SPAWNED			0
#define ISAKMP_STATE_EXPIRED			1
#define ISAKMP_STATE_STARTED			2
#define ISAKMP_STATE_STOPPED			3
#define ISAKMP_STATE_ESTABLISHED		4

typedef struct _isakmp_xchg_t {
	uint8_t type;
	const char *name;
	int flags;
#define ISAKMP_XCHG_ESTABLISH	0x00000001
#define ISAKMP_XCHG_ONEWAY	0x00000002
	int (*init)(isakmp_phase_t *);
	void (*exit)(isakmp_phase_t *, isakmp_xchange_t *inst);
	int (*input)(isakmp_xchange_t *, msgbuf_t *);
	list_t link;
} isakmp_xchg_t;

struct _isakmp_xchange_t {
	isakmp_xchg_t *type;
	int enabled;
	isakmp_phase_t *phase;

	stm_instance_t *fsmi;
	list_t link;
};

typedef struct _isakmp_payload_t {
	uint8_t type;
	uint16_t length;
	const uint8_t *ptr;
	list_t link;
	int parsed;
} isakmp_payload_t;

struct _isakmp_profile_t {
	const char *name;
	atomic_t refcnt;
	list_t link;

	ui_entry_t *cs;
	nic_t *dev;

	const char *ifname;

	/* used for incoming */
	struct sockaddr remote;
	uint32_t remote_ipv4;
	uint16_t remote_port;

	uint16_t local_port;

	int nat_traversal;		/* NAT-Traversal */
	int ike_frag;			/* IKE fragmentation */
};

#define ISAKMP_DOI_ISAKMP	0
#define ISAKMP_DOI_IPSEC	1

struct _isakmp_doi_t {
	const char *name;
	uint32_t doi;

	isakmp_domain_t *(*init)(isakmp_phase_t *phase);
	void (*exit)(isakmp_domain_t *);
	int (*encode_proposal)(isakmp_domain_t *, msgbuf_t *msg);
	int (*decode_proposal)(isakmp_domain_t *, msgbuf_t *msg);
	int (*delete_spis)(isakmp_domain_t *, uint8_t proto, int num,
			   size_t size, uint8_t *spis);
	list_t link;
};

struct _isakmp_domain_t {
	isakmp_doi_t *doi;
	isakmp_phase_t *phase;
};

/* ============================================================ *
 * domain operations
 * ============================================================ */
int isakmp_register_doi(isakmp_doi_t *doi);
void isakmp_unregister_doi(isakmp_doi_t *doi);
isakmp_doi_t *isakmp_doi_by_type(uint32_t type);
isakmp_doi_t *isakmp_doi_by_name(const char *name);

isakmp_domain_t *isakmp_generic_domain_init(isakmp_phase_t *phase);
void isakmp_generic_domain_exit(isakmp_domain_t *domain);

/* ============================================================ *
 * exchange operations
 * ============================================================ */
isakmp_xchg_t *isakmp_xchg_by_type(uint8_t type);
isakmp_xchg_t *isakmp_xchg_by_name(const char *name);
void isakmp_unregister_xchg(isakmp_xchg_t *type);
int isakmp_register_xchg(isakmp_xchg_t *type);
void isakmp_xchange_enable(isakmp_phase_t *phase, isakmp_xchange_t *inst);
void isakmp_xchange_disable(isakmp_phase_t *phase, isakmp_xchange_t *inst);
void isakmp_event_stm_log(const stm_instance_t *fsmi, int level,
			  const char *fmt, ...);

/* ============================================================ *
 * profile operations
 * ============================================================ */
static inline isakmp_profile_t *isakmp_profile_get(isakmp_profile_t *profile)
{
	atomic_inc(&profile->refcnt);
	return profile;
}
isakmp_profile_t *isakmp_profile_get_by_name(const char *name);
void isakmp_profile_free(isakmp_profile_t *prof);

/* ============================================================ *
 * phase operations
 * ============================================================ */
isakmp_phase_t *isakmp_phase_get(isakmp_phase_t *phase);
void isakmp_phase_raise(isakmp_phase_t *phase, int event);
isakmp_phase_t *isakmp_phase1_get_by_index(isakmp_index_t *idx);
isakmp_phase_t *isakmp_phase2_get_by_index(isakmp_phase_t *ph1,
					   uint32_t msgid);
void isakmp_phase_free(isakmp_phase_t *phase);
void isakmp_phase_expired(isakmp_phase_t *phase);
isakmp_profile_t *isakmp_phase_profile(isakmp_phase_t *phase);
int isakmp_phase_step(isakmp_phase_t *phase);
isakmp_phase_t *isakmp_phase1_initiate(uint32_t doi,
				       struct sockaddr *remote,
				       struct sockaddr *local);
int isakmp_phase_send(isakmp_phase_t *phase, msgbuf_t *msg);

/* ============================================================ *
 * DOI operations
 * ============================================================ */
uint16_t isakmp_doi_encode_proposal(isakmp_phase_t *phase, msgbuf_t *msg);

/* ============================================================ *
 * global operations
 * ============================================================ */
void isakmp_service_raise(int event, void *param);

/* ============================================================ *
 * exchange operations
 * ============================================================ */
int isakmp_xchange_init(isakmp_phase_t *phase, uint8_t type);

/* ============================================================ *
 * payload operations
 * ============================================================ */
isakmp_payload_t *isakmp_append_payload(msgbuf_t *msg, uint8_t type,
					const uint8_t *payload,
					uint16_t length);

#endif /* __ISAKMP_H_INCLUDE__ */
