#ifndef __NET_AVP_H_INCLUDE__
#define __NET_AVP_H_INCLUDE__

#include <uiserv.h>

typedef struct _net_avp_t net_avp_t;


/* AVP definitions, all used AVPs for our application */

/* Types */
#define PW_TYPE_STRING			UI_TYPE_STRING
#define PW_TYPE_INTEGER			UI_TYPE_INT
#define PW_TYPE_IPADDR			UI_TYPE_IPADDR
#define PW_TYPE_DATE			UI_TYPE_DATE
#define PW_TYPE_ABINARY			UI_TYPE_ABINARY
#define PW_TYPE_OCTETS			UI_TYPE_OCTETS
#define PW_TYPE_IFID			UI_TYPE_IFID
#define PW_TYPE_IPV6ADDR		UI_TYPE_IPV6ADDR
#define PW_TYPE_IPV6PREFIX		UI_TYPE_IPV6PREFIX

/* Vendors */
#define PW_VENDOR_MS			311
#define PW_VENDOR_SOLITON		990
#define PW_VENDOR_VPN			3076

/* Attributes */
#define	PW_USER_NAME			1
#define	PW_PASSWORD			2
#define	PW_FRAMED_PROTOCOL		7
#define	PW_FRAMED_IP_ADDRESS		8
#define	PW_FRAMED_IP_NETMASK		9
#define	PW_NAS_IP_ADDRESS		4
#define	PW_NAS_PORT			5
#define	PW_SERVICE_TYPE			6
#define PW_FRAMED_ID			11
#define PW_FRAMED_MTU			12

#define PW_FRAMED_ROUTE			22
#define PW_VENDOR_SPECIFIC		26

#define PW_CALLED_STATION_ID		30
#define PW_CALLING_STATION_ID		31

#define PW_CHAP_CHALLENGE		60
#define PW_NAS_PORT_TYPE		61

#define PW_FALL_THROUGH			500
#define PW_AUTH_TYPE			1000
#define PW_GROUP			1005
#define PW_CRYPT_PASSWORD		1006
#define PW_SESSION_TYPE			1013
#define PW_EAP_TYPE			1018
#define PW_HINT				1040
#define PW_REALM			1045
#define PW_CLIENT_IP_ADDRESS		1052

#define PW_CHAP_CHALLENGE		60
#define PW_CHAP_PASSWORD		3

/* Microsoft */
#define PW_MSCHAP_RESPONSE		((PW_VENDOR_MS << 16) | 1)
#define PW_MSCHAP_ERROR			((PW_VENDOR_MS << 16) | 2)
#define PW_MS_MPPE_ENCRYPTION_POLICY	((PW_VENDOR_MS << 16) | 7)
#define PW_MS_MPPE_ENCRYPTION_TYPES	((PW_VENDOR_MS << 16) | 8)
#define PW_MSCHAP_CHALLENGE		((PW_VENDOR_MS << 16) | 11)
#define PW_MS_CHAP_MPPE_KEYS		((PW_VENDOR_MS << 16) | 12)
#define PW_MS_MPPE_SEND_KEY		((PW_VENDOR_MS << 16) | 16)
#define PW_MS_MPPE_RECV_KEY		((PW_VENDOR_MS << 16) | 17)
#define PW_MSCHAP2_RESPONSE		((PW_VENDOR_MS << 16) | 25)
#define PW_MS_PRIMARY_DNS		((PW_VENDOR_MS << 16) | 28)
#define PW_MS_SECONDARY_DNS		((PW_VENDOR_MS << 16) | 29)
#define PW_MS_PRIMARY_WINS		((PW_VENDOR_MS << 16) | 30)
#define PW_MS_SECONDARY_WINS		((PW_VENDOR_MS << 16) | 31)

/* Soliton */
#define PW_FRAMED_IP_OPTION		((PW_VENDOR_SOLITON << 16) | 1)
#define PW_FRAMED_IP_DSTADDR		((PW_VENDOR_SOLITON << 16) | 2)

#define PW_PPP_CHANNEL_TYPE		((PW_VENDOR_SOLITON << 16) | 11)
#define PW_PPP_SERVER_AUTH		((PW_VENDOR_SOLITON << 16) | 12)
#define PW_PPP_CLIENT_AUTH		((PW_VENDOR_SOLITON << 16) | 13)
#define PW_PPP_NETWORK_TYPE		((PW_VENDOR_SOLITON << 16) | 14)
#define PW_PPP_CLIENT_UNIT		((PW_VENDOR_SOLITON << 16) | 15)
#define PW_PPP_SERVER_UNIT		((PW_VENDOR_SOLITON << 16) | 16)

#define PW_CHAP_SERVER_ALGO		((PW_VENDOR_SOLITON << 16) | 21)
#define PW_CHAP_CLIENT_ALGO		((PW_VENDOR_SOLITON << 16) | 22)
#define PW_CHAP_AUTH_RESULT		((PW_VENDOR_SOLITON << 16) | 23)

/* RTNL link */
#define PW_FRAMED_ID_BCAST		((PW_VENDOR_SOLITON << 16) | 31)
#define PW_FRAMED_TX_QUEUE		((PW_VENDOR_SOLITON << 16) | 32)
#define PW_FRAMED_MCAST			((PW_VENDOR_SOLITON << 16) | 33)
#define PW_FRAMED_MCAST_ALL		((PW_VENDOR_SOLITON << 16) | 34)
#define PW_FRAMED_PROMISC		((PW_VENDOR_SOLITON << 16) | 35)
#define PW_FRAMED_TRAILERS		((PW_VENDOR_SOLITON << 16) | 36)
#define PW_FRAMED_ARP			((PW_VENDOR_SOLITON << 16) | 37)
#define PW_FRAMED_DYNAMIC		((PW_VENDOR_SOLITON << 16) | 38)

/* Values */
/* Service-Type */
#define	PW_LOGIN_USER			1
#define	PW_FRAMED_USER			2

/* Framed-Protocol */
#define	PW_PPP				1

/* PPP-Channel-Type */
#define PW_PPP_TTY			1
#define PW_PPP_L2TP			2
#define PW_PPP_PPPOE			3
#define PW_PPP_PPPOA			4

/* PPP-Auth-Type */
#define PW_PPP_NONE			0
#define PW_PPP_PAP			0xc023
#define PW_PPP_CHAP			0xc223
#define PW_PPP_EAP			0xc227

/* PPP-Network-Type */
#define PW_PPP_IP			0
#define PW_PPP_IPV6			1

/* Chap-Digest-Type */
#define PW_CHAP_NONE			0
#define PW_CHAP_MD5			0x05
#define PW_CHAP_MSCHAP			0x80
#define PW_CHAP_MSCHAP2			0x81

/* Chap-Result */
#define	PW_CHAP_SUCCESS			1
#define	PW_CHAP_FAILURE			2

/* ============================================================ *
 * dictionary operations
 * ============================================================ */
typedef enum _dict_token_t dict_token_t;

#define DICT_PATH	"/etc/dict"
#define DICT_NAME	"dictionary"

#define VENDORPEC_USR		429
#define VENDORPEC_LUCENT	4846
#define VENDORPEC_STARENT	8164
#define VENDOR(x)		((x >> 16) & 0xffff)
#define TAG_VALID(x)	        ((x) > 0 && (x) < 0x20)
#define TAG_VALID_ZERO(x)       ((x) >= 0 && (x) < 0x20)
#define TAG_ANY                 -128   /* minimum signed char */

#define NET_MAX_STRING			254	/* RFC2138: string 0-253 octets */

enum _dict_token_t {
	T_INVALID = 0,                  /* invalid token */
	T_EOL,                          /* end of line */
	T_COMMA,			/* , */
	T_HASH,                         /* # */

	T_OP_ADD,			/* += */
	T_OP_SUB,			/* -= */
	T_OP_SET,			/* := */
	T_OP_EQ,			/* = */
	T_OP_NE,			/* != */
	T_OP_GE,			/* >= */
	T_OP_GT,			/* > */
	T_OP_LE,			/* <= */
	T_OP_LT,			/* < */
	T_OP_REG_EQ,			/* =~ */
	T_OP_REG_NE,			/* !~ */
	T_OP_CMP_TRUE,                  /* =* */
	T_OP_CMP_FALSE,                 /* !* */
	T_OP_CMP_EQ,			/* == */

	T_BARE_WORD,			/* bare word */
	T_DOUBLE_QUOTED_STRING,         /* "foo" */
	T_SINGLE_QUOTED_STRING,         /* 'foo' */
	T_BACK_QUOTED_STRING,		/* `foo` */
	T_TOKEN_LAST
};

#define T_EQSTART	T_OP_ADD
#define	T_EQEND		(T_OP_CMP_EQ + 1)

typedef struct _dict_flags_t {
	char addport;		/* Add port to IP address */
	char has_tag;		/* attribute allows tags */
	signed char len_disp;	/* length displacement */
	char do_xlat;
	signed char tag;
	uint8_t encrypt;	/* encryption method */
} dict_flags_t;

/* values of the encryption flags */
#define FLAG_ENCRYPT_NONE            (0)
#define FLAG_ENCRYPT_USER_PASSWORD   (1)
#define FLAG_ENCRYPT_TUNNEL_PASSWORD (2)
#define FLAG_ENCRYPT_ASCEND_SECRET   (3)

typedef struct _dict_attr_t {
	char			name[40];
	int			attr;
	int			type;
	int			vendor;
        dict_flags_t              flags;
} dict_attr_t;

typedef struct _dict_value_t {
	int			attr;
	int			value;
	char			name[1];
} dict_value_t;

typedef struct _dict_vendor_t {
	int			vendorpec;
	int			type; /* length of type data */
	int			length;	/* length of length data */
	char			name[1];
} dict_vendor_t;

typedef struct _dict_hash_t dict_hash_t;

typedef struct _net_dict_t {
	dict_hash_t *vendors_byname;
	dict_hash_t *vendors_byvalue;

	dict_hash_t *attributes_byname;
	dict_hash_t *attributes_byvalue;

	dict_hash_t *values_byvalue;
	dict_hash_t *values_byname;
} net_dict_t;

typedef void (*dict_free_fn)(void *);
typedef int (*dict_iterate_fn)(void * /* ctx */, void * /* data */);

int dict_add_vendor(const char *name, int value);
int dict_add_attr(const char *name, int vendor, int type,
		  int value, dict_flags_t flags);
int dict_add_value(const char *namestr, const char *attrstr, int value);
dict_attr_t *dict_attr_by_attr(int attr);
dict_attr_t *dict_attr_by_name(const char *attr);
dict_value_t *dict_value_by_attr(int attr, int val);
dict_value_t *dict_value_by_name(int attr, const char *val);
int dict_vendor_by_name(const char *name);
dict_vendor_t *dict_vendor_by_vendor(int vendor);

dict_hash_t *dict_hash_new(dict_free_fn freeNode);
void dict_hash_free(dict_hash_t *ht);
int dict_hash_insert(dict_hash_t *ht, uint32_t key, void *data);
int dict_hash_delete(dict_hash_t *ht, uint32_t key);
int dict_hash_count(dict_hash_t *ht);
int dict_hash_iterate(dict_hash_t *ht, dict_iterate_fn callback, void *ctx);
void *dict_hash_yank(dict_hash_t *ht, uint32_t key);
int dict_hash_replace(dict_hash_t *ht, uint32_t key, void *data);
void *dict_hash_find_data(dict_hash_t *ht, uint32_t key);

/* ============================================================ *
 * avpair operations
 * ============================================================ */
struct _net_avp_t {
	char name[40];
	int attribute;
	int type;
	int length; /* of strvalue */
	uint32_t lvalue;
	dict_token_t operator;
	uint8_t strvalue[NET_MAX_STRING];
        dict_flags_t flags;
	net_avp_t *next;
};

net_avp_t *net_avp_new(int attr);
net_avp_t *net_avp_new_op(const char *attribute,
			  const char *value, int op);
void net_avp_free(net_avp_t *pair);
net_avp_t *net_avp_parse(net_avp_t *vp, const char *value);
net_avp_t *net_avp_read(char **ptr, dict_token_t *eol);
dict_token_t net_avps_parse(char *buffer, net_avp_t **first_pair);

void net_avps_free(net_avp_t **);
net_avp_t *net_avps_dup_attr(net_avp_t *vp, int attr);
net_avp_t *net_avps_dup(net_avp_t *vp);
void net_avps_move(net_avp_t **to, net_avp_t **from);
void net_avps_move_attr(net_avp_t **to, net_avp_t **from, int attr);
net_avp_t *net_avp_by_long(net_avp_t *first, int attr, uint32_t lval);
net_avp_t *net_avp_by_attr(net_avp_t *first, int attr, net_avp_t *last);
void net_avps_unset(net_avp_t **, int);
void net_avps_add(net_avp_t **, net_avp_t *);
void net_avps_set(net_avp_t **first, net_avp_t *add);
net_avp_t *net_avps_load(FILE *fp, int *pfiledone, const char *errprefix);
int net_avp_count(net_avp_t *first);

int net_avp_printable(net_avp_t *vp);
int net_avp_print_value(char * out, int outlen, net_avp_t *vp, int delimitst);
void net_avp_logging(net_avp_t *first, int logger, int level);

#endif /* __NET_AVP_H_INCLUDE__ */
