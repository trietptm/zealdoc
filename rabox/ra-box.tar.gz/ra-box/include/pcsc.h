#ifndef __PCSC_H__
#define __PCSC_H__
#include <sysdep.h>
#include <pcsc_pinpad.h>
#include <pcsc_defs.h>

/* connector: IFD and ICC main handle */
typedef struct _pcsc_icc_t	pcsc_icc_t;
typedef struct _pcsc_slot_t	pcsc_slot_t;
typedef struct _pcsc_transfer_t pcsc_transfer_t;

typedef void (*pcsc_appcmd_complete)(void *user_data, int ret);

struct icc_path {
	int type;

	uint8_t value[ICC_PATH_MAX];
	size_t len;

	/* The next two fileds are used in PKCS15, where 
	 * a path object can reference a portion of a file-count
	 * octets starting at offset index. */
	int idx;
	int count;
};

struct icc_acl_entry {
	unsigned int method;	/* enum scard_access_control_flags */
	unsigned int key_ref;

	struct icc_acl_entry *next;
};

struct icc_file {
	struct icc_path path;
	uint8_t df_name[16];
	size_t df_name_len;

	int type;
	int shareable;
	int ef_structure;
	size_t size;
	int id;
	int status;

	struct icc_acl_entry *acl[ICC_AC_OP_MAX];

	int record_length;
	int record_count;
	
	uint8_t *sec_attr;
	size_t sec_attr_len;
	uint8_t *prop_attr;
	size_t prop_attr_len;
	uint8_t *type_attr;
	size_t type_attr_len;
};

struct icc_app_info {
	uint8_t aid[ICC_AID_MAX];
	size_t aid_len;
	char *label;
	struct icc_path path;
	uint8_t *ddo;
	size_t ddo_len;

	const char *desc;	/* App description, if known */
	int rec_nr;		/* -1, if EF(DIR) is transparent */
};

struct icc_object_id {
	int value[ICC_OBJECT_ID_OCTETS_MAX];
};

struct icc_algorithm_id {
	unsigned int algorithm;
	struct icc_object_id obj_id;
	void *params;
};

struct icc_pbkdf2_params {
	uint8_t salt[16];
	size_t salt_len;
	int iterations;
	size_t key_length;
	struct icc_algorithm_id hash_alg;
};

struct icc_pbes2_params {
	struct icc_algorithm_id derivation_alg;
	struct icc_algorithm_id key_encr_alg;
};

typedef struct _icc_binder_t {
	const char *name;
	int (*bind)(uint16_t index);
	list_t link;
} pcsc_binder_t;

#define PCSC_REGISTER		0x01
#define PCSC_UNREGISTER		0x02
#define PCSC_ICC_INSERT		0x03
#define PCSC_ICC_REMOVE		0x04

int pcsc_register_notify(notify_t *nb);
void pcsc_unregister_notify(notify_t *nb);
int pcsc_notify(unsigned long val, void *v);

int pcsc_register_binder(pcsc_binder_t *);
void pcsc_unregister_binder(pcsc_binder_t *);


/* PKCS15 API */
int pcsc_app_count(pcsc_slot_t *hd);
struct icc_app_info **pcsc_app_place(pcsc_slot_t *hd);
struct icc_file **pcsc_app_ef_dir(pcsc_slot_t *hd);
void pcsc_app_count_inc(pcsc_slot_t *hd);
void pcsc_app_count_dec(pcsc_slot_t *hd);
int pcsc_app_is_exist(pcsc_slot_t *slot, struct icc_app_info *app);

/* PCSC iso7616 cmd API*/
/* FIXME: **p not well */
int pcsc_select_file(pcsc_slot_t *hd, struct icc_path *path,
		     struct icc_file **file_out,
		     pcsc_appcmd_complete cb, void *user_data);
int pcsc_read_binary(pcsc_slot_t *hd, uint16_t offset,
		     uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
		     pcsc_appcmd_complete cb, void *user_data);

int icc_append_path_id(struct icc_path *dest, const uint8_t *id, size_t idlen);
void icc_format_path(const char *str, struct icc_path *path);
struct icc_file *icc_file_new(void);
void icc_file_free(struct icc_file *filp);
int icc_asn1_read_tag(const uint8_t **buf, size_t buflen, 
		      unsigned int *cla_out, unsigned int *tag_out,
		      size_t *taglen);
const uint8_t *icc_asn1_find_tag(const uint8_t *b, size_t bl, 
				 unsigned int tag_in, size_t *taglen_in);
int icc_make_absolute_path(const struct icc_path *parent, 
			     struct icc_path *child);
void icc_file_dup(struct icc_file **dest, const struct icc_file *src);

/* out upper may use this get hd first. only one instance can held hd */
pcsc_slot_t *pcsc_handle_get_by_idx(uint16_t idx);
void pcsc_handle_put(pcsc_slot_t *hd);

#endif /*__PCSC_H__*/
