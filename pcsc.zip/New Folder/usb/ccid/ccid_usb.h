#ifndef __CCID_USB_H__
#define __CCID_USB_H__
#include "ccid_priv.h"

enum ccid_usb_intfc_protocol {
	CCID_USB_INTFC_PROTO_BULK	= 0x00,
	CCID_USB_INTFC_PROTO_CTRL_A	= 0x01,
	CCID_USB_INTFC_PROTO_CTRL_B	= 0x02,
};

struct ccid_usb_control_param {
	uint8_t		bmRequestType;
	uint8_t		bRequest;
	uint16_t	wValue;
	uint16_t	wIndex;
	uint16_t	wLength;
	uint8_t		*data;

	ccid_transfer_complete callback;
	void *user_data;
};

int ccid_usb_cancel(ccid_reader_t *hccid);

int ccid_usb_fill_cmd(struct ccid_transfer *ccid_trans);

int ccid_usb_send_transfer(struct ccid_transfer *ccid_trans);
int ccid_usb_reap_transfer(struct ccid_transfer *ccid_trans);

int ccid_usb_fill_control(uint8_t request_class, uint8_t request, 
			  uint8_t *data, size_t data_len,
			  struct ccid_usb_control_param *control_param);
int ccid_usb_control_transfer(usb_intfc_t *intfc, 
			      struct ccid_usb_control_param *control_param);
/* soliton ccid driver match id table */
#define CCID_MATCH_ID_FLAGS	\
		(USB_DEVICE_ID_MATCH_INT_CLASS | \
		 USB_DEVICE_ID_MATCH_INT_SUBCLASS | \
		 USB_DEVICE_ID_MATCH_INT_PROTOCOL)

static usb_dev_id_t ccid_id_table[] = {
	{
		CCID_MATCH_ID_FLAGS,
		0,	/* idVendor */
		0,	/* idProduct */
		0,	/* bcdDevice_lo */
		0,	/* bcdDevice_hi */
			
		0,	/* bDeviceClass */
		0,	/* bDeviceSubClass */
		0,	/* bDeviceProtocol */
			
		0x0b,	/* bInterfaceClass: Smart Card Device Class */
		0,	/* bInterfaceSubClass */
		0,	/* bInterfaceProtocol: CCID; */
			
		0,	/* driver_info; */
	},

	{0}		/* terminating entry */
};

int ccid_register_usb_driver(void);
void ccid_unregister_usb_driver(void);

int ccid_usb_claim(ccid_reader_t *rdr);
int ccid_usb_release(ccid_reader_t *rdr);

uint16_t ccid_usb_dev_idVendor(ccid_reader_t *rdr);
uint16_t ccid_usb_dev_idProduct(ccid_reader_t *rdr);

#endif /*__CCID_USB_H__*/
