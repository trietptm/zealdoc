#include "usb_priv.h"

static void usbi_transfer_exit_delay(void *eloop, void *user_ctx);

static void usb_stm_log(const stm_instance_t *fsmi,
			int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

#define USB_TRANSFER_STATE_INIT		0
#define USB_TRANSFER_STATE_SENDING	1
#define USB_TRANSFER_STATE_SENT		2
#define USB_TRANSFER_STATE_CANCEL	3
#define USB_TRANSFER_STATE_RCVED	4
#define USB_TRANSFER_STATE_EXIT		5

#define USB_TRANSFER_STATE_COUNT	6

#define USB_TRANSFER_STATE_NAMES {	\
	"INIT",				\
	"SENDING",			\
	"SENT",				\
	"CANCEL",			\
	"RCVED",			\
	"EXIT",				\
}

#define USB_TRANSFER_EVENT_SUBMIT	0
#define USB_TRANSFER_EVENT_STS		1 /* Send Transfer Success */
#define USB_TRANSFER_EVENT_STF		2 /* Send Transfer Fail */
#define USB_TRANSFER_EVENT_RRS		3 /* Response Received Success */
#define USB_TRANSFER_EVENT_RRF		4 /* Response Received Fail */
#define USB_TRANSFER_EVENT_TCP		5 /* Transfer ComPlete */
#define USB_TRANSFER_EVENT_TTO		6 /* Transfer TimeOut */
#define USB_TRANSFER_EVENT_CTS		7 /* Cancel Transfer Success*/
#define USB_TRANSFER_EVENT_CTF		8 /* Cancel Transfer Fail*/

#define USB_TRANSFER_EVENT_COUNT	9


#define USB_TRANSFER_EVENT_NAMES {	\
	"SUBMIT",			\
	"STS",				\
	"STF",				\
	"RRS",				\
	"RRF",				\
	"TCP",				\
	"TTO",				\
	"CTS",				\
	"CTF",				\
}

static void usb_transfer_raise_event(void *data, int event)
{
	struct usb_transfer *transfer = (struct usb_transfer *)data;

	eloop_schedule_event(NULL, transfer->fsmi, event, data);
}

static void usb_transfer_raise_submit(struct usb_transfer *transfer)
{
	usb_transfer_raise_event(transfer, USB_TRANSFER_EVENT_SUBMIT);
}

static void usb_transfer_raise_sts(struct usb_transfer *transfer)
{
	usb_transfer_raise_event(transfer, USB_TRANSFER_EVENT_STS);
}

static void usb_transfer_raise_stf(struct usb_transfer *transfer)
{
	usb_transfer_raise_event(transfer, USB_TRANSFER_EVENT_STF);
}

static void usb_transfer_raise_rrs(struct usb_transfer *transfer)
{
	usb_transfer_raise_event(transfer, USB_TRANSFER_EVENT_RRS);
}

static void usb_transfer_raise_rrf(struct usb_transfer *transfer)
{
	usb_transfer_raise_event(transfer, USB_TRANSFER_EVENT_RRF);
}

static void usb_transfer_raise_tcp(struct usb_transfer *transfer)
{
	usb_transfer_raise_event(transfer, USB_TRANSFER_EVENT_TCP);
}

static void usb_transfer_raise_tto(struct usb_transfer *transfer)
{
	usb_transfer_raise_event(transfer, USB_TRANSFER_EVENT_TTO);
}

static void usb_transfer_raise_cts(struct usb_transfer *transfer)
{
	usb_transfer_raise_event(transfer, USB_TRANSFER_EVENT_CTS);
}

static void usb_transfer_raise_ctf(struct usb_transfer *transfer)
{
	usb_transfer_raise_event(transfer, USB_TRANSFER_EVENT_CTF);
}

/* Submit Transfer */
static int usb_transfer_action_st(stm_instance_t *fsmi, void *data)
{
	struct usb_transfer *transfer = (struct usb_transfer *)data;
	int r;
	
	list_insert_tail(&transfer->link, 
		&transfer->dev_handle->transfer_list);

	r = sys_ops->sys_submit_transfer(transfer);
	if (r < 0) {
		transfer->status = USB_TRANSFER_ERROR;
		usb_transfer_raise_stf(transfer);
	} else {
		usb_transfer_raise_sts(transfer);
	}
	
	return 1;
}

/* Check Response*/
static int usb_transfer_action_cr(stm_instance_t *fsmi, void *data)
{
	struct usb_transfer *transfer = (struct usb_transfer *)data;

	switch (transfer->status) {
	case USB_TRANSFER_TIME_OUT:
	case USB_TRANSFER_NO_DEVICE:
	case USB_TRANSFER_ERROR:
	case USB_TRANSFER_CANCELLED:
	case USB_TRANSFER_STALL:
	case USB_TRANSFER_OVERFLOW:
	case USB_TRANSFER_COMPLETED:
		usb_transfer_raise_tcp(transfer);
		break;
	default:
		usb_log(USB_LOG_ERR, "ACT: unrecognised transfer status %d",
				transfer->status);
		usb_transfer_raise_tcp(transfer);
		break;
	}
	return 1;
}

/* Exit Transfer Context*/
static int usb_transfer_action_etc(stm_instance_t *fsmi, void *data)
{
	struct usb_transfer *transfer = (struct usb_transfer *)data;
	struct usb_trans_params *param = transfer->user_data;

	switch (transfer->status) {
	case USB_TRANSFER_COMPLETED:
		param->ret = USB_SUCCESS;
		break;
	case USB_TRANSFER_TIME_OUT:
		param->ret = USB_ERROR_TIMEOUT;
		break;
	case USB_TRANSFER_CANCELLED:
		param->ret = USB_ERROR_CANCELLED;
		break;
	case USB_TRANSFER_STALL:
		param->ret = USB_ERROR_PIPE;
		break;
	case USB_TRANSFER_NO_DEVICE:
		param->ret = USB_ERROR_NO_DEVICE;
		break;
	case USB_TRANSFER_OVERFLOW:
		param->ret = USB_ERROR_OVERFLOW;
		break;
	case USB_TRANSFER_ERROR:
		param->ret = USB_ERROR_IO;
		break;
	default:
		param->ret = USB_ERROR_OTHER;
		break;
	}
	transfer->callback(transfer->user_data);
	list_delete(&transfer->link);
	
	eloop_register_timeout(NULL, 0, 0, usbi_transfer_exit_delay, NULL, 
			       transfer);
	return 1;
}

static void usb_trans_timeout_cb(void *eloop_data, void *user_ctx)
{
	struct usb_transfer *transfer = (struct usb_transfer *)user_ctx;
	
	transfer->status = USB_TRANSFER_TIME_OUT;
	usb_transfer_raise_tto(transfer);
}

/* Register Time Out*/
static int usb_transfer_action_rto(stm_instance_t *fsmi, void *data)
{
	struct usb_transfer *transfer = (struct usb_transfer *)data;

	eloop_register_timeout(NULL, transfer->timeout.tv_sec, 
			       transfer->timeout.tv_usec,
			       usb_trans_timeout_cb, NULL, transfer);
	return 1;
}

/* Unregister Time Out*/
static int usb_transfer_action_uto(stm_instance_t *fsmi, void *data)
{
	struct usb_transfer *transfer = (struct usb_transfer *)data;

	eloop_cancel_timeout(NULL, usb_trans_timeout_cb, NULL, transfer);

	return 1;
}

/* Cancel Transfer*/
static int usb_transfer_action_ct(stm_instance_t *fsmi, void *data)
{
	struct usb_transfer *transfer = (struct usb_transfer *)data;

	if (usbi_cancel_transfer(transfer) == USB_SUCCESS)
		usb_transfer_raise_cts(transfer);
	else
		usb_transfer_raise_ctf(transfer);

	return 1;
}

/* Response Process*/
static int usb_transfer_action_null(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static const stm_action_fn usb_transfer_act_st [] = {
	usb_transfer_action_st,
};


static const stm_action_fn usb_transfer_act_cr [] = {
	usb_transfer_action_cr,
};

static const stm_action_fn usb_transfer_act_etc [] = {
	usb_transfer_action_etc,
};

static const stm_action_fn usb_transfer_act_rto [] = {
	usb_transfer_action_rto,
};

static const stm_action_fn usb_transfer_act_uto [] = {
	usb_transfer_action_uto,
};

static const stm_action_fn usb_transfer_act_ct [] = {
	usb_transfer_action_ct,
};

static const stm_action_fn usb_transfer_act_uto_cr [] = {
	usb_transfer_action_uto,
	usb_transfer_action_cr,
};

static const stm_action_fn usb_transfer_act_uto_etc [] = {
	usb_transfer_action_uto,
	usb_transfer_action_etc,
};

static const stm_action_fn usb_transfer_act_null [] = {
	usb_transfer_action_null,
};

#define STATE(state)	USB_TRANSFER_STATE_##state
#define EVENT(event)	USB_TRANSFER_EVENT_##event
#define ACTION(stem) usb_transfer_act_##stem, \
		sizeof(usb_transfer_act_##stem) / sizeof(stm_action_fn) 

static const stm_entry_t usb_stm_transfer_entries[] = {
	/* state	event		action		new_state */
	{STATE(INIT),	EVENT(SUBMIT),	ACTION(st),	STATE(SENDING),},

	{STATE(SENDING),EVENT(STF),	ACTION(etc),	STATE(EXIT),},
	{STATE(SENDING),EVENT(STS),	ACTION(rto),	STATE(SENT),},
	
	{STATE(SENT),	EVENT(RRS),	ACTION(uto_cr),	STATE(RCVED),},
	{STATE(SENT),	EVENT(RRF),	ACTION(uto_etc),STATE(EXIT),},
	{STATE(SENT),	EVENT(TTO),	ACTION(ct),	STATE(CANCEL),},
	
	{STATE(CANCEL),	EVENT(CTS),	ACTION(rto),	STATE(SENT),},
	{STATE(CANCEL),	EVENT(CTF),	ACTION(etc),	STATE(EXIT),},
	
	{STATE(RCVED),	EVENT(TCP),	ACTION(etc),	STATE(EXIT),},

	{0,		0,		ACTION(null),	0,},
};

static const char *usb_transfer_state_names[] = USB_TRANSFER_STATE_NAMES;
static const char *usb_transfer_event_names[] = USB_TRANSFER_EVENT_NAMES;

const stm_table_t usb_stm_transfer_table = {
	"USB-TRANS",
	usb_stm_log,
	USB_TRANSFER_STATE_COUNT,
	&usb_transfer_state_names[0],
	USB_TRANSFER_EVENT_COUNT,
	&usb_transfer_event_names[0],
	usb_stm_transfer_entries,	
};

#undef STATE
#undef EVENT
#undef ACTION

int usbi_submit_transfer(struct usb_transfer *transfer)
{
	if (!transfer)
		return USB_ERROR_INVALID_PARAM;
	if (transfer->name == NULL)
		transfer->name = strdup("usb trans");

	transfer->fsmi = stm_table_new(&usb_stm_transfer_table, 
				       transfer->name, 
				       USB_TRANSFER_STATE_INIT);
	if (!transfer->fsmi)
		return USB_ERROR_NO_MEM;		
	
	/* usb_ref_handle(transfer->dev_handle);*/
	usb_transfer_raise_submit(transfer);
	
	return 0;
}

int usbi_cancel_transfer(struct usb_transfer *usb_trans)
{
	return sys_ops->sys_cancel_transfer(usb_trans);
}

static void usbi_transfer_exit(struct usb_transfer *transfer)
{
	BUG_ON(transfer == NULL);
	
	/* usb_unref_handle(transfer->dev_handle);*/
	if (transfer->fsmi) {
		eloop_cleanup_events(NULL, transfer->fsmi);
		stm_table_free(transfer->fsmi);
	}
	usb_free_transfer(transfer);
	
}

static void usbi_transfer_exit_delay(void *eloop, void *user_ctx) 
{
	usbi_transfer_exit((struct usb_transfer *)user_ctx);
}

void usbi_eloop_handle_cb(int fd, void *eloop_data, void *user_ctx)
{
	usb_intfc_t *dev_handle = (usb_intfc_t *)user_ctx;
	struct usb_transfer *usb_trans = NULL;
	int r;
	
	r = sys_ops->sys_asyn_reap(dev_handle, &usb_trans);
	if (r == USB_REAP_AGAIN) {
		/* usb_log(USB_LOG_DEBUG, "USBI: REAP AGAIN"); */
		return;
	} else if (r == USB_SUCCESS) {
		if (usb_trans->status == USB_TRANSFER_REAPING) {
			usb_log(USB_LOG_DEBUG, "USBI: there are some more URBs");
			return;
		} else {
			struct usb_trans_params *param = usb_trans->user_data;
#if 0
			usb_log(USB_LOG_DEBUG, "USBI: reap trans name=%s", 
					usb_trans->name);
			usb_log(USB_LOG_DEBUG, "USBI: reap Success");
#endif
			param->rbuf_actual = usb_trans->actual_length;
			usb_transfer_raise_rrs(usb_trans);
		}
	} else /*if (r < USB_SUCCESS) */{
		usb_log(USB_LOG_ERR, "USBI: reap failed=%d", r);
		if (usb_trans) {
			if (r == USB_ERROR_NO_DEVICE)
				usb_trans->status = USB_TRANSFER_NO_DEVICE;
			else
				usb_trans->status = USB_TRANSFER_REAP_ERROR;
			usb_transfer_raise_rrf(usb_trans);
		} else {
			/* FIXME: all tranfer related to the device should enter
			 * EXIT state.
			 */
			struct usb_transfer *trans_next;

			sys_ops->sys_close(dev_handle);

			list_for_each_entry_safe(usb_transfer_t, usb_trans, 
				trans_next, &dev_handle->transfer_list, link) {
				if (r == USB_ERROR_NO_DEVICE)
					usb_trans->status = USB_TRANSFER_NO_DEVICE;
				else
					usb_trans->status = USB_TRANSFER_REAP_ERROR;
				usb_trans->fsmi->state= USB_TRANSFER_STATE_EXIT;
				usb_transfer_action_etc(usb_trans->fsmi, usb_trans);
			}
		}
	}
}
