#include "pcsc_priv.h"

DECLARE_LIST(pcsc_handle_list);

#define for_each_handle(e)		\
	list_for_each_entry(pcsc_handle_t, e, &pcsc_handle_list, link)

static inline int handle_detect_icc_insert(pcsc_handle_t *hd);
static inline int handle_detect_icc_remove(pcsc_handle_t *hd);
static void __ifd_icc_status_loop_cb(pcsc_handle_t *hd);
static inline uint16_t __build_handle_idx(uint16_t r_idx, int s_idx);
static void __handle_detect_icc_start(pcsc_handle_t *hd);
static void ifd_hd_start(pcsc_handle_t *hd);
static void ifd_hd_stop(pcsc_handle_t *hd);

/* ifd ops */
static int ifd_hd_cancel(pcsc_handle_t *hd);
static int ifd_hd_icc_status(pcsc_handle_t *hd);
static int ifd_hd_power_off(pcsc_handle_t *hd);
static int ifd_hd_power_on(pcsc_handle_t *hd);
static int ifd_hd_xfr_block(pcsc_handle_t *hd, pcsc_transfer_t *t);
static int ifd_hd_ifd_ctl(pcsc_handle_t *hd, pcsc_transfer_t *t);

/* icc ops */
static int icc_hd_read_binary(pcsc_handle_t *, uint16_t offset,
			      uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
			      pcsc_appcmd_complete cb, void *user_data);


static void pcsc_raise_event(pcsc_handle_t *rd_ctx, int event);
static void pcsc_raise_ris(pcsc_handle_t *hd);
static void pcsc_raise_ors(pcsc_handle_t *rd_ctx);
static void pcsc_raise_css(pcsc_handle_t *rd_ctx);
static void pcsc_raise_csf(pcsc_handle_t *rd_ctx);
static void pcsc_raise_to(pcsc_handle_t *rd_ctx);
static void pcsc_raise_iccp(pcsc_handle_t *rd_ctx);
static void pcsc_raise_iccnp(pcsc_handle_t *rd_ctx);
static void pcsc_raise_cas(pcsc_handle_t *rd_ctx);
static void pcsc_raise_caf(pcsc_handle_t *rd_ctx);
static void pcsc_raise_icca(pcsc_handle_t *rd_ctx);
static void pcsc_raise_iccd(pcsc_handle_t *rd_ctx);
static void pcsc_raise_iccr(pcsc_handle_t *rd_ctx);
static void pcsc_raise_cis(pcsc_handle_t *rd_ctx);
static void pcsc_raise_rrm(pcsc_handle_t *rd_ctx);
static void pcsc_raise_cds(pcsc_handle_t *rd_ctx);
static void pcsc_raise_cdf(pcsc_handle_t *rd_ctx);

static void pcsc_stm_exit_delay(void *eloop, void *user_ctx);

static void pcsc_stm_log(const stm_instance_t *fsmi,
			int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

#define PCSC_STATE_INIT		0
#define PCSC_STATE_OPEN		1	/* Reader Opening */
#define PCSC_STATE_CSTATUSING	2	/* ICC statusing */
#define PCSC_STATE_CSTATUSED	3	/* ICC statused */
#define PCSC_STATE_PRESENT	4	/* ICC present */
#define PCSC_STATE_ABSENT	5	/* ICC absent */
#define PCSC_STATE_POWERUP	6	/* ICC powerup(actived) */
#define PCSC_STATE_DEACTIVE	7	/* ICC deactive */
#define PCSC_STATE_POWERDOWN	8	/* ICC powerdown(deactived) */
#define PCSC_STATE_EXIT		9	

#define PCSC_STATE_COUNT	10

#define PCSC_STATE_NAMES {	\
	"INIT",			\
	"OPEN",			\
	"CSTATUSING",		\
	"CSTATUSED",		\
	"PRESENT",		\
	"ABSENT",		\
	"POWERUP",		\
	"DEACTIVE",		\
	"POWERDOWN",		\
	"EXIT",			\
}

#define PCSC_EVENT_RIS		0	/* Reader InSerted*/
#define PCSC_EVENT_ORS		1	/* Open Reader Success */
#define PCSC_EVENT_ORF		2	/* Open Reader Failed */
#define PCSC_EVENT_CSS		3	/* icC Status Success */
#define PCSC_EVENT_CSF		4	/* icC Status Failed */
#define PCSC_EVENT_TO		5	/* Time Out*/
#define PCSC_EVENT_ICCP		6	/* ICC Present */
#define PCSC_EVENT_ICCNP	7	/* ICC Not Present */
#define PCSC_EVENT_CAS		8	/* Card Active Success */
#define PCSC_EVENT_CAF		9	/* Card Active Failed */
#define PCSC_EVENT_ICCA		10	/* ICC active */
#define PCSC_EVENT_ICCD		11	/* Card deactive */
#define PCSC_EVENT_ICCR		12	/* ICC removed */
#define PCSC_EVENT_CIS		13	/* Card InSerted */	
#define PCSC_EVENT_RRM		14	/* Reader ReMoved */
#define PCSC_EVENT_CDS		15	/* Card Deactive Success */
#define PCSC_EVENT_CDF		16	/* Card Deactive Failed */

#define PCSC_EVENT_COUNT	17

#define PCSC_EVENT_NAMES {	\
	"RIS",			\
	"ORS",			\
	"ORF",			\
	"CSS",			\
	"CSF",			\
	"TO",			\
	"ICCP",			\
	"ICCNP",		\
	"CAS",			\
	"CAF",			\
	"ICCA",			\
	"ICCD",			\
	"ICCR",			\
	"CIS",			\
	"RRM",			\
	"CDS",			\
	"CDF",			\
}

static void pcsc_raise_event(pcsc_handle_t *rd_ctx, int event)
{
	eloop_schedule_event(NULL, rd_ctx->fsmi, event, rd_ctx);
}

static void pcsc_raise_ris(pcsc_handle_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_RIS);
}

static void pcsc_raise_ors(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ORS);
}

static void pcsc_raise_css(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CSS);
}

static void pcsc_raise_csf(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CSF);
}

static void pcsc_raise_to(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_TO);
}

static void pcsc_raise_iccp(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCP);
}

static void pcsc_raise_iccnp(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCNP);
}

static void pcsc_raise_cas(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CAS);
}

static void pcsc_raise_caf(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CAF);
}

static void pcsc_raise_icca(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCA);
}

static void pcsc_raise_iccd(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCD);
}

static void pcsc_raise_iccr(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCR);
}

static void pcsc_raise_cis(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CIS);
}

static void pcsc_raise_rrm(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_RRM);
}

static void pcsc_raise_cds(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CDS);
}

static void pcsc_raise_cdf(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CDF);
}

int pcsc_action_open(stm_instance_t *fsmi, void *data)
{
	pcsc_raise_ors(data);
	return 1;
}

static int pcsc_action_close(stm_instance_t *fsmi, void *data)
{
	pcsc_handle_t *hd = (pcsc_handle_t *)data;

	pcsc_icc_down(hd->icc);
	return 1;
}


static int pcsc_action_erc(stm_instance_t *fsmi, void *data)
{
	eloop_register_timeout(NULL, 0, 0, 
		pcsc_stm_exit_delay, NULL, data);
	return 1;
}

/* This "warm up" sequence is sometimes needed when pcscd is
 * restarted with the reader already connected. We get some
 * "usb_bulk_read: Resource temporarily unavailable" on the 
 * first few tries. It is an empirical hack
 */
#define ICC_STATUS_RETRY_MAX	3
static int icc_status_retry = ICC_STATUS_RETRY_MAX;

static void icc_status_complete(pcsc_handle_t *hd)
{
	uint32_t icc_status;

	if (hd->ret != PCSC_S_SUCCESS) {
		if ((--icc_status_retry) > 0) {
			pcsc_raise_to(hd);
		} else {
			pcsc_raise_csf(hd);
			icc_status_retry = ICC_STATUS_RETRY_MAX;
		}
	} else {

#if 0
		if (hd->old_icc_status == hd->icc_status)
			return;
#endif

		icc_status = hd->icc->status;
		if (icc_status & PCSC_ICC_PRESENT_MASK) {
			/* ICC insert */
			pcsc_raise_iccp(hd);
			/* FIXME: need? icc_seq */
			hd->icc_seq++;

		} else {
			pcsc_raise_iccnp(hd);
		}
		icc_status_retry = ICC_STATUS_RETRY_MAX;
		hd->old_icc_status = hd->icc->status;
	}
}

static int pcsc_action_icc_status(stm_instance_t *fsmi, void *data)
{
	pcsc_handle_t *hd = (pcsc_handle_t *)data;
	int r;
	
	hd->cb = icc_status_complete;
	r = ifd_hd_icc_status(hd);

	if (r == PCSC_S_SUCCESS)
		pcsc_raise_css(hd);
	else
		pcsc_raise_csf(hd);
	return 1;
}

static void power_on_complete(pcsc_handle_t *hd)
{
	struct pcsc_atr_info atr_info;
	uint8_t atr[PCSC_MAX_ATR * 3];
	size_t i;

	if (hd->ret < 0) {
		if (hd->ret == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(hd);
		else
			pcsc_raise_caf(hd);
	} else {
		hd->icc->atr_len = hd->ret;
		if (pcsc_parse_atr(hd->icc->atr, hd->icc->atr_len, &atr_info) 
			== PCSC_S_SUCCESS) {
			hd->icc->proto = atr_info.default_proto;
			hd->icc->proto_supported = atr_info.supported_protos;

			for (i = 0; i < hd->icc->atr_len; i++) {
				if (i == hd->icc->atr_len - 1)
					sprintf(atr + i * 3, "%02X", hd->icc->atr[i]);
				else 
					sprintf(atr + i * 3, "%02X:", hd->icc->atr[i]);
			}
			pcsc_log(PCSC_LOG_DEBUG, "ATR: %s", atr);
			if (hd->icc->proto_supported & PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_DEBUG, "Support protocol: T0");
			if (hd->icc->proto_supported & PCSC_PROTOCOL_T1)
				pcsc_log(PCSC_LOG_DEBUG, "Support protocol: T1");

			if (hd->icc->proto == PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_DEBUG, "Default protocol: T0");
		} else {
			hd->icc->proto = PCSC_PROTOCOL_UNKNOWN;
			hd->icc->proto_supported = PCSC_PROTOCOL_UNKNOWN;
		}
		/* FIXME: we need set this value by hand and here?? */
		hd->icc->status = PCSC_ICC_PRESENT_POWERUP;
		pcsc_raise_cas(hd);
		pcsc_icc_up(hd->icc);
	}
}

/* active ICC */
static int pcsc_action_aicc(stm_instance_t *fsmi, void *data)
{
	pcsc_handle_t *rd_ctx = (pcsc_handle_t *)data;
	int r;

	rd_ctx->cb = power_on_complete;

	r = ifd_hd_power_on(rd_ctx);

	if (r != PCSC_S_SUCCESS) {
		if (r == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_caf(rd_ctx);
	}
	return 1;
}

static void power_off_complete(pcsc_handle_t *rd_ctx)
{
	if (rd_ctx->ret != PCSC_S_SUCCESS) {
		if (rd_ctx->ret == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_cdf(rd_ctx);
	} else {
		pcsc_raise_cds(rd_ctx);
	}
}

/* deactive ICC */
static int pcsc_action_dicc(stm_instance_t *fsmi, void *data)
{
	pcsc_handle_t *rd_ctx = (pcsc_handle_t *)data;
	int r;

	rd_ctx->cb = power_off_complete;

	r = ifd_hd_power_off(rd_ctx);

	if (r != PCSC_S_SUCCESS) {
		if (r == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_cdf(rd_ctx);
	}	
	return 1;
}

/* Card Not Present */
static int pcsc_action_cnp(stm_instance_t *fsmi, void *data)
{
	pcsc_handle_t *hd = (pcsc_handle_t *)data;

	hd->icc->status = PCSC_ICC_ABSENT;
	pcsc_icc_down(hd->icc);

	return 1;
}

/* Clear handle */
static int pcsc_action_chd(stm_instance_t *fsmi, void *data)
{
	pcsc_handle_t *ifd = (pcsc_handle_t *)data;
	
	ifd_hd_cancel(ifd);
	return 1;
}

static int pcsc_action_null(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static const stm_action_fn pcsc_act_open [] = {
	pcsc_action_open,
};

static const stm_action_fn pcsc_act_erc [] = {
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_close_erc [] = {
	pcsc_action_close,
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_icc_status [] = {
	pcsc_action_icc_status,
};

static const stm_action_fn pcsc_act_aicc [] = {
	pcsc_action_aicc,
};

static const stm_action_fn pcsc_act_cnp [] = {
	pcsc_action_cnp,
};

static const stm_action_fn pcsc_act_chd_cnp [] = {
	pcsc_action_chd,
	pcsc_action_cnp,
};

static const stm_action_fn pcsc_act_chd_dicc [] = {
	pcsc_action_chd,
	pcsc_action_dicc,
};


static const stm_action_fn pcsc_act_null [] = {
	pcsc_action_null,
};


#define STATE(state)	PCSC_STATE_##state
#define EVENT(event)	PCSC_EVENT_##event
#define ACTION(stem)	pcsc_act_##stem, \
		sizeof(pcsc_act_##stem) / sizeof(stm_action_fn) 

static const stm_entry_t pcsc_stm_entries[] = {
	/* state	event		action			new_state */
	{STATE(INIT),	EVENT(RIS),	ACTION(open),		STATE(OPEN),},

	{STATE(OPEN),	EVENT(ORS),	ACTION(icc_status),	STATE(CSTATUSING),},
#if 0
	{STATE(OPEN),	EVENT(ORF),	ACTION(erc),		STATE(EXIT),},
#endif
	{STATE(CSTATUSING),EVENT(CSS),	ACTION(null),		STATE(CSTATUSED),},
	{STATE(CSTATUSING),EVENT(CSF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(CSTATUSING),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(CSTATUSED),EVENT(CSF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(CSTATUSED),EVENT(TO),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(CSTATUSED),EVENT(ICCP),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(CSTATUSED),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(CSTATUSED),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},
	
	{STATE(PRESENT),EVENT(CAS),	ACTION(null),		STATE(POWERUP),},
	{STATE(PRESENT),EVENT(CAF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(PRESENT),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(PRESENT),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(PRESENT),EVENT(RRM),	ACTION(erc),		STATE(EXIT),},

	{STATE(ABSENT),	EVENT(CIS),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(ABSENT),	EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(POWERUP),EVENT(ICCA),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(POWERUP),EVENT(ICCD),	ACTION(chd_dicc),	STATE(DEACTIVE),},
	{STATE(POWERUP),EVENT(ICCR),	ACTION(chd_cnp),	STATE(ABSENT),},
	{STATE(POWERUP),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(DEACTIVE),EVENT(CDS),	ACTION(null),		STATE(POWERDOWN),},
	{STATE(DEACTIVE),EVENT(CDF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(DEACTIVE),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(DEACTIVE),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(DEACTIVE),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(POWERDOWN),EVENT(ICCA),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(POWERDOWN),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(POWERDOWN),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{0,		0,		ACTION(null),		0,},
};

static const char *pcsc_state_names[] = PCSC_STATE_NAMES;
static const char *pcsc_event_names[] = PCSC_EVENT_NAMES;

const stm_table_t pcsc_stm_table = {
	"PCSC",
	pcsc_stm_log,
	PCSC_STATE_COUNT,
	&pcsc_state_names[0],
	PCSC_EVENT_COUNT,
	&pcsc_event_names[0],
	pcsc_stm_entries,	
};

#undef STATE
#undef EVENT
#undef ACTION

#if 0
int pcsc_icc_poweron(pcsc_handle_t *hd)
{
	pcsc_raise_icca(hd);
	return PCSC_S_SUCCESS;
}
#endif

static void pcsc_stm_exit(pcsc_handle_t *rd_ctx)
{
	if (rd_ctx->fsmi) {
		eloop_cleanup_events(NULL, rd_ctx->fsmi);
		stm_table_free(rd_ctx->fsmi);
		rd_ctx->fsmi = NULL;
	}
}

static void pcsc_stm_exit_delay(void *eloop, void *user_ctx) 
{
	pcsc_stm_exit((pcsc_handle_t *)user_ctx);
}

static inline uint16_t __build_handle_idx(uint16_t rdr_idx, int slot_idx)
{
	return (uint16_t)(rdr_idx << 8 | slot_idx);
}

pcsc_handle_t *pcsc_connect(int reader_idx, int slot_idx)
{

	return NULL;
}

int pcsc_check_handle_valid(pcsc_handle_t *handle)
{
	if (!handle) return 0;
	return 0;
//	return (handle->slot->icc_seq == handle->reader->icc_seq);
}




pcsc_handle_t *pcsc_handle_new(pcsc_ifd_t *rdr, int slot_idx)
{
	pcsc_handle_t *hd;

	hd = malloc(sizeof (pcsc_handle_t));
	if (!hd)
		goto err;

	memset(hd, 0, sizeof (pcsc_handle_t));

	hd->fsmi = stm_table_new(&pcsc_stm_table, rdr->name, 
				 PCSC_STATE_INIT);
	if (!hd->fsmi)
		goto err;

	hd->idx = __build_handle_idx(rdr->idx, slot_idx);
	hd->old_icc_status = PCSC_ICC_STATUS_UNKNOWN;
	list_init(&hd->link);
	/* can?? */
	list_insert_before(&hd->link, &pcsc_handle_list);
	atomic_set(&hd->refcnt, 1);
	/* FIXME: call-chain may not need this? */
	hd->ifd = pcsc_ifd_get(rdr);
	hd->icc = pcsc_icc_new(hd->idx);

	return hd;
err:
	if (hd)
		free(hd);
	return NULL;
}

void pcsc_handle_free(pcsc_ifd_t *ifd)
{
	pcsc_handle_t *hd;
	
	for_each_handle(hd) {
		if (hd->ifd != ifd)
			continue;
		/* who will refernce hd?  a transfer param now */
		if (atomic_dec_and_test(&hd->refcnt)) {
			
			if (hd->fsmi) {
				/* for a BUG */
				eloop_cancel_timeout(NULL, 
					pcsc_stm_exit_delay, NULL, hd);
				pcsc_stm_exit(hd);
			}
			if (hd->icc)
				pcsc_icc_free(hd->icc);
			
			list_delete(&hd->link);
			pcsc_ifd_put(hd->ifd);
			free(hd);
		}
	}
}

void ifd_hd_start_by_ifd(pcsc_ifd_t *ifd)
{
	pcsc_handle_t *hd;
	for_each_handle(hd) {
		if (ifd == hd->ifd)
			ifd_hd_start(hd);
	}
}

void ifd_hd_stop_by_ifd(pcsc_ifd_t *ifd)
{
	pcsc_handle_t *hd;
	for_each_handle(hd) {
		if (ifd == hd->ifd)
			ifd_hd_stop(hd);
	}
}

void ifd_hd_get_feature(pcsc_ifd_t *ifd)
{
	pcsc_handle_t *hd;

	for_each_handle(hd) {
		if (ifd == hd->ifd && ifd->ifd_ops->get_feature) {
			ifd->ifd_ops->get_feature(hd);
			/* only get once? */
			break;
		}
	}
}


static void __ifd_icc_status_loop(void *eloop_data, void *data)
{
	pcsc_handle_t *hd = (pcsc_handle_t *)data;

	__handle_detect_icc_start(hd);

}

/* detect ICC insert/remove event */
void ifd_hd_detect_icc_loop(pcsc_ifd_t *ifd)
{
	pcsc_handle_t *hd;

	for_each_handle(hd) {
		if (hd->ifd == ifd)
			eloop_register_timeout(NULL, 4, 0,
				__ifd_icc_status_loop, NULL, hd);

	}
}

void ifd_hd_detect_icc_loop_stop(pcsc_ifd_t *ifd)
{
	eloop_cancel_timeout(NULL, __ifd_icc_status_loop, NULL, ifd);
}

static void ifd_hd_start(pcsc_handle_t *hd)
{
	/* sm start - reader insert event */
	pcsc_raise_ris(hd);
}

static void ifd_hd_stop(pcsc_handle_t *hd)
{
	/* sm start - reader remove event */
	pcsc_raise_rrm(hd);
}

static int ifd_hd_cancel(pcsc_handle_t *hd)
{
	return hd->ifd->ifd_ops->cancel(hd);
}

static int ifd_hd_icc_status(pcsc_handle_t *hd)
{
	return hd->ifd->ifd_ops->icc_status(hd);	
}

static int ifd_hd_power_off(pcsc_handle_t *hd)
{
	return hd->ifd->ifd_ops->power_off(hd);	
}

static int ifd_hd_power_on(pcsc_handle_t *hd)
{
	return hd->ifd->ifd_ops->power_on(hd);	
}

static int ifd_hd_xfr_block(pcsc_handle_t *hd, pcsc_transfer_t *p)
{
	return hd->ifd->ifd_ops->xfr_block(hd, p);	
}

static int ifd_hd_ifd_ctl(pcsc_handle_t *hd, pcsc_transfer_t *p)
{
	return hd->ifd->ifd_ops->ifd_ctl(hd, p);	
}

static void __ifd_icc_status_loop_cb(pcsc_handle_t *hd)
{
	if (pcsc_icc_status(hd->icc) != hd->old_icc_status) {
		pcsc_log(PCSC_LOG_INFO, "IFD: icc state changed, %s -> %s",
			 pcsc_card_status_str(hd->old_icc_status), 
			 pcsc_card_status_str(hd->icc->status));
		if (hd->icc->status != 0)
			handle_detect_icc_insert(hd);
		else
			handle_detect_icc_remove(hd);
		/* forever check */
		/* record new status */
		hd->old_icc_status = hd->icc->status;
	}
	ifd_hd_detect_icc_loop(hd->ifd);
}

static void __handle_detect_icc_start(pcsc_handle_t *hd)
{
	hd->cb = __ifd_icc_status_loop_cb;
	pcsc_log(PCSC_LOG_DEBUG, "IFD: do icc state detect");
	ifd_hd_icc_status(hd);
}

static inline int handle_detect_icc_insert(pcsc_handle_t *hd)
{
	pcsc_raise_cis(hd);
	return PCSC_S_SUCCESS;
}

static inline int handle_detect_icc_remove(pcsc_handle_t *hd)
{
	pcsc_raise_iccr(hd);
	return PCSC_S_SUCCESS;
}

static int icc_hd_read_binary(pcsc_handle_t *hd, uint16_t offset,
			      uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
			      pcsc_appcmd_complete cb, void *user_data)
{
	return hd->icc->icc_ops->ops->read_binary(hd, offset, rbuf, rbuf_len, flags, cb, user_data);
}
#if 1

/* only one can use? */
pcsc_handle_t *pcsc_handle_get(uint16_t idx)
{
	pcsc_handle_t *hd;
	for_each_handle(hd) {
		if (hd->idx == idx && 
		    hd->locked == 0) {
			hd->locked = 1;
			return hd;
		}
	}
	return NULL;
}

void pcsc_handle_put(pcsc_handle_t *hd)
{
	hd->locked = 0;
}

int pcsc_transmit(pcsc_transfer_t *trans)
{
	return ifd_hd_xfr_block(trans->handle, trans);
}
/* APPLICATION API */
int pcsc_read_binary(uint16_t ifd_icc, uint16_t offset,
		     uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
		     pcsc_appcmd_complete cb, void *user_data)
{
	pcsc_handle_t *hd = pcsc_handle_get(ifd_icc);
	
	if (!hd) {
		pcsc_log(PCSC_LOG_ERR, 
			 "HANDLE: no match handle find, idx=%02x", ifd_icc);
		return -1;
	}

	return icc_hd_read_binary(hd, offset, rbuf, rbuf_len, flags, cb, user_data);
}

uint8_t tb[2];

static void __test_read_binary_complete(void *user_data, int ret)
{
	if (ret >= PCSC_S_SUCCESS)
		pcsc_log(PCSC_LOG_INFO, "HANDLE: test read binary success");
	else
		pcsc_log(PCSC_LOG_INFO, "HANDLE: test read binary failed=%d", ret);
}

static void __test_read_binary(void)
{
	pcsc_read_binary(0x00, 0, tb, 2, 0, __test_read_binary_complete, NULL);
}
#endif 0
