#ifndef __PCSC_PRIV_H__
#define __PCSC_PRIV_H__

#include <sysdep.h>
#include <logger.h>
#include <panic.h>
#include <module.h>
#include <strutl.h>
#include <dfastm.h>
#include <eloop.h>
#include <service.h>
#include <list.h>
#include <pcsc.h>
#include <bitops.h>

/*Logging operations*/
#define PCSC_LOG_CRIT	LOG_EMERG
#define PCSC_LOG_FAIL	LOG_CRIT
#define PCSC_LOG_ERR	LOG_ERR
#define PCSC_LOG_WARN	LOG_WARNING
#define PCSC_LOG_INFO	LOG_INFO
#define PCSC_LOG_DEBUG	LOG_DEBUG

#define LOG_CALL_CHAIN	PCSC_LOG_WARN
//#define LOG_CALL_CHAIN	PCSC_LOG_DEBUG

void pcsc_log(int level, const char *format, ...);

struct pcsc_atr_info {
	uint8_t TS;
	uint8_t T0;
	uint8_t history_len;

	int supported_protos;
	int default_proto;	
};

/* upper */
typedef struct _pcsc_ifd_t pcsc_ifd_t;
typedef struct _pcsc_icc_t pcsc_icc_t;

/* connector: IFD and ICC main handle */
typedef struct _pcsc_handle_t   pcsc_handle_t;
typedef struct _pcsc_transfer_t pcsc_transfer_t;

/* lower */
typedef struct __ifd_driver_t ifd_driver_t;
typedef struct __icc_driver_t icc_driver_t;

typedef void (*pcsc_handle_cb)(pcsc_handle_t *hd);
typedef void (*pcsc_trans_cb)(pcsc_transfer_t *trans);

#include "pcsc_ifd.h"
#include "pcsc_icc.h"


struct _pcsc_handle_t {
	uint16_t idx;	/* XXYY: XX - IFD idx, YY IFD_SLOT idx */
	pcsc_ifd_t *ifd;
	pcsc_icc_t *icc;

	int locked;
	/* FIXME: ICC insert times, need? */
	uint32_t icc_seq;
	uint16_t old_icc_status;	/* for detect ICC state change */

	pcsc_handle_cb cb;
	int ret;
	stm_instance_t *fsmi;

	/* from scard handle */
	uint8_t cla;
	size_t max_send;
	size_t max_recv;
	struct icc_path curr_path;
	struct icc_app_info *app[ICC_APP_MAX];
	int app_count;
	struct icc_file *ef_dir;
	uint32_t active_proto;
	int flags;

	atomic_t refcnt;
	list_t link;
};

typedef struct _pcsc_trans_param {
	uint8_t *sbuf;
	size_t sbuf_len;
	size_t sbuf_transmitted;
	void *priv_param;

	uint8_t *rbuf;
	size_t rbuf_len;
	size_t rbuf_actual;
#if 1
	/* For SELECT FILE command */
	struct icc_path *path;
	struct icc_file **file_out;
#endif
	pcsc_appcmd_complete callback;
	void *user_data;
	int ret;
} pcsc_trans_param;

struct _pcsc_transfer_t {

	pcsc_handle_t *handle;

	uint32_t ioctl;

	int ret;

	uint32_t card_status;

	pcsc_trans_cb callback;
	void *user_data;

	/* from icc_transfer */
	pcsc_trans_param *cmd_param;
	struct icc_apdu *apdu;
#define SCARD_CARD_PARAM_FLAG_NOT_FREE_APDU	0x00000001
	uint32_t flags;
};


int pcsc_parse_atr(const char *atr, size_t atr_len, struct pcsc_atr_info *atr_info);
int pcsc_default_proto(const uint8_t *atr, size_t atr_len, int *def_pro);
int pcsc_support_proto(const uint8_t *atr, size_t atr_len, int *supp_proto);

int __init pcsc_ifd_init(void);
void __exit pcsc_ifd_exit(void);

int __init pcsc_icc_init(void);
void __exit pcsc_icc_exit(void);

/* handle API start*/
pcsc_handle_t *pcsc_handle_new(pcsc_ifd_t *ifd, int idx);
void pcsc_handle_free(pcsc_ifd_t *ifd);
void ifd_hd_stop_by_ifd(pcsc_ifd_t *ifd);
void ifd_hd_start_by_ifd(pcsc_ifd_t *ifd);
void ifd_hd_get_feature(pcsc_ifd_t *ifd);
void ifd_hd_detect_icc_loop_stop(pcsc_ifd_t *ifd);
void ifd_hd_detect_icc_loop(pcsc_ifd_t *ifd);

pcsc_handle_t *pcsc_handle_get(uint16_t idx);
void pcsc_handle_put(pcsc_handle_t *hd);
int pcsc_transmit(pcsc_transfer_t *trans);

/* handle API stop */


#endif /*__PCSC_PRIV_H__*/
