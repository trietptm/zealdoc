#ifndef __PCSC_H__
#define __PCSC_H__
#include <sysdep.h>
#include <pcsc_pinpad.h>
#include <pcsc_defs.h>

/* APPLICATION API */
typedef void (*pcsc_appcmd_complete)(void *user_data, int ret);

int pcsc_read_binary(uint16_t ifd_icc, uint16_t offset,
		     uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
		     pcsc_appcmd_complete cb, void *user_data);

#endif /*__PCSC_H__*/
