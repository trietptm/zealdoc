#include "../pcsc_priv.h"

/* test call-chain arch */

/*Watchdata TimeCOS/PK file types(DF/EF, W/I EF, B/R structure, No.)*/
#define WD_FILE_TYPE_UNKNOWN		0x8000
#define WD_FILE_TYPE_DF			0x1000	/* DF */
#define WD_FILE_TYPE_MF			0x1100
#define WD_FILE_TYPE_DF_DDF		0x1210
#define WD_FILE_TYPE_DF_ADF		0x1220
#define WD_FILE_TYPE_DF_A5		0X1230	/* V3.5: create key file */
#define WD_FILE_TYPE_EF			0x2000	/* EF */
#define WD_FILE_TYPE_EF_W		0x2100	/* Working EF */
#define WD_FILE_TYPE_EF_I		0x2200	/* Internal EF */
/*Working EF*/
#define WD_FILE_TYPE_BINARY		0x2101
#define WD_FILE_TYPE_RECORD_FIX		0x2112
#define WD_FILE_TYPE_RECORD_CYCLIC	0x2113
#define WD_FILE_TYPE_WALLET		0x2114
#define WD_FILE_TYPE_ELEC_PASSBOOK	0x2115
#define WD_FILE_TYPE_ELEC_WALLET	0x2116
#define WD_FILE_TYPE_RECORD_VAR		0x2117
/*Internal EF*/
#define WD_FILE_TYPE_PRIVATE_KEY	0x2201
#define WD_FILE_TYPE_PUBLIC_KEY		0x2202
#define WD_FILE_TYPE_KEYS		0x2213


#define WD_MAX_DF_NAME	16
#define WD_MIN_DF_NAME	5


static icc_atr_table wd_atr_table[] = {
	{"WatchData TimePOS", 
	 "3B:7D:94:00:00:57:44:35:65:F4:86:93:07:17:BD:06:20:1E",
	 NULL,
	},

	{NULL, NULL, NULL,},
};


static void wd_new(void);
static void wd_start(void);
static void wd_free(void);
static void wd_stop(void);
static void wd_bind(pcsc_icc_t *icc);
static void wd_unbind(pcsc_icc_t *icc);
static void wd_up(void *eloop_data, void *data);
static void wd_down(void *eloop_data, void *data);

static void wd_new(void)
{/* NULL since icc_wd exist */
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: new");
}

static void wd_start(void)
{/* NULL since wd has nothing to start (now) */
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: start");
}

static void wd_free(void)
{/* NULL since icc_wd is static exist */
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: free");
}

static void wd_stop(void)
{/* NULL since wd has nothing to stop (now) */
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: stop");
}

static void wd_bind(pcsc_icc_t *icc)
{
	pcsc_icc_get(icc);
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: bind");
	/* not sure whether driver has some private data to bind */
}

static void wd_unbind(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: unbind");
	pcsc_icc_put(icc);
}

static void wd_up(void *eloop_data, void *data)
{
	pcsc_icc_t *icc = (pcsc_icc_t *)data;
	/* FIXME: parent set this value, not child */
	pcsc_log(LOG_CALL_CHAIN, "ICC_C: up");
	icc_up(icc);
}

static void wd_down(void *eloop_data, void *data)
{
	pcsc_icc_t *icc = (pcsc_icc_t *)data;

	pcsc_log(LOG_CALL_CHAIN, "ICC_C: down");
	icc_down(icc);
	wd_unbind(icc);
}

static int wd_drv_match(pcsc_icc_t *icc)
{
	icc_atr_table *atr_table;
	int i = 0;

	pcsc_log(LOG_CALL_CHAIN, "WD: driver match");

	while((atr_table = &wd_atr_table[i++]) && atr_table->name) {
		if (icc_match_atr(atr_table, icc->atr, icc->atr_len))
			return 1;
	}

	return 0;
}

static int wd_drv_open(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "WD: driver open");
	wd_new();
	wd_bind(icc);
	wd_start();

	/* async notify, but not necessary in these two layer. */
	eloop_register_timeout(NULL, 0, 0, 
			       wd_up, NULL, icc);
	return -1;
}

static int wd_drv_close(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "WD: driver close");
	wd_stop();

	/* async notify, but not necessary in these two layer. */
	eloop_register_timeout(NULL, 0, 0, 
			       wd_down, NULL, icc);
	return -1;
}

#define ICC_DRIVER_NAME		"watchdata"

static icc_driver_t icc_wd = {
	ICC_DRIVER_NAME,
	ICC_DRV_SYNC_MATCH,
	wd_drv_match,
	wd_drv_open,
	wd_drv_close,
};

int __init icc_wd_init(void)
{
	icc_register_driver(&icc_wd);
	return 0;
}

void __exit icc_wd_exit(void)
{
	icc_unregister_driver(&icc_wd);
}

/* copy from SCARD wd */

static int wd_init(struct scard_handle *handle)
{
	return 0;
}

static int wd_exit(struct scard_handle *handle)
{
	return 0;
}

#if 0
static int wd_default_file(const struct scard_path *in_path, 
			   struct scard_file *filp)
{
	unsigned int op;

	/* TODO: get file info from config */
	if (in_path->type == SCARD_PATH_TYPE_DF_NAME)
		return SCARD_ERR_INVALID_ARGS;
	filp->type = SCARD_FILE_TYPE_WORKING_EF;
	filp->ef_structure = SCARD_FILE_EF_TRANSPARENT;
	filp->status = SCARD_FILE_STATUS_ACTIVATED;
	filp->id = (in_path->value[in_path->len - 2] << 8)
			| in_path->value[in_path->len - 1];
	filp->path = *in_path;

	switch (filp->id) {
	case 0x2F00:	
		filp->size = 128;
		break;
	case 0x4946:
		filp->size = 128;
		break;
	case 0x5031:
		filp->size = 256;
		break;
	case 0x5032:
		filp->size = 128;
		break;
	case 0x5033:
		filp->size = 128;
		break;
	case 0x4401:
	case 0x4402:
	case 0x4403:
	case 0x4404:
	case 0x4405:
		filp->size = 256;
		for (op = 0; op < SCARD_AC_OP_MAX; op++) {
			scard_file_clear_acl_entries(filp, op);
			scard_file_add_acl_entry(filp, op, SCARD_AC_AUT, 0);
		}
		scard_file_add_acl_entry(filp, SCARD_AC_OP_READ, SCARD_AC_NONE, 0);
		break;
	default:
		if ((filp->id & 0xFF00) == 0x3300) { /* Data object template */
			filp->size = 128;
			scard_file_add_acl_entry(filp, SCARD_AC_OP_UPDATE, SCARD_AC_CHV, 0);
			scard_file_add_acl_entry(filp, SCARD_AC_OP_WRITE, SCARD_AC_CHV, 0);
			scard_file_add_acl_entry(filp, SCARD_AC_OP_ERASE, SCARD_AC_AUT, 0);
		} else if ((filp->id & 0xFF00) == 0x0000) {
			if ((filp->id & 0x00FF) % 3 == 1) { /* Private Key */
				filp->size = 330;					
				scard_file_add_acl_entry(filp, SCARD_AC_OP_UPDATE, SCARD_AC_AUT, 0);
				scard_file_add_acl_entry(filp, SCARD_AC_OP_WRITE, SCARD_AC_AUT, 0);
				scard_file_add_acl_entry(filp, SCARD_AC_OP_READ, SCARD_AC_AUT, 0);
				scard_file_add_acl_entry(filp, SCARD_AC_OP_USE, SCARD_AC_CHV, 0);
				scard_file_add_acl_entry(filp, SCARD_AC_OP_ERASE, SCARD_AC_AUT, 0);
			} else if ((filp->id & 0x00FF) % 3 == 2) { /* Public Key */
				filp->size = 135;					
				scard_file_add_acl_entry(filp, SCARD_AC_OP_UPDATE, SCARD_AC_AUT, 0);
				scard_file_add_acl_entry(filp, SCARD_AC_OP_WRITE, SCARD_AC_AUT, 0);
				scard_file_add_acl_entry(filp, SCARD_AC_OP_ERASE, SCARD_AC_AUT, 0);
			} else { /* Certification */
				filp->size = 2048;					
				scard_file_add_acl_entry(filp, SCARD_AC_OP_UPDATE, SCARD_AC_AUT, 0);
				scard_file_add_acl_entry(filp, SCARD_AC_OP_WRITE, SCARD_AC_AUT, 0);
				scard_file_add_acl_entry(filp, SCARD_AC_OP_ERASE, SCARD_AC_AUT, 0);
			}
		} else {
			return SCARD_ERR_FILE_NOT_FOUND;
		}
		break;
	}

	return SCARD_SUCCESS;
}

static void __wd_select_file_complete(struct scard_card_cmd_param *card_param)
{
	struct scard_cmd_param *cmd_param = card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;
	struct scard_path *in_path = cmd_param->path;
	int r;

	if (card_param->ret != SCARD_SUCCESS) {
		cmd_param->ret = card_param->ret;
	} else {
		cmd_param->ret = scard_check_sw(card_param->handle, 
						apdu->sw1, apdu->sw2);
		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
			switch (in_path->type) {
			case SCARD_PATH_TYPE_FILE_ID:
			case SCARD_PATH_TYPE_FROM_CURRENT:
			case SCARD_PATH_TYPE_PATH:
				if (in_path->type == SCARD_PATH_TYPE_PATH) {
					in_path->type = SCARD_PATH_TYPE_FROM_CURRENT;
					card_param->handle->curr_path.len = 0;
				}
				scard_append_path_id(&card_param->handle->curr_path,
						     cmd_param->sbuf, 2);

				cmd_param->sbuf += 2;
				cmd_param->sbuf_len -= 2;
				if (cmd_param->sbuf_len >= 2) {
					apdu->data = cmd_param->sbuf;
					apdu->datalen = cmd_param->sbuf_len;
					if (cmd_param->file_out && apdu->datalen == 2) {
						apdu->le = cmd_param->rbuf_len -2;
						apdu->resp = cmd_param->rbuf;
						apdu->resplen = cmd_param->rbuf_len;
					}
					r = scard_reader_transmit(card_param);
					if (r == SCARD_SUCCESS)
						return;
					
					cmd_param->ret = r;
				} 
			case SCARD_PATH_TYPE_DF_NAME:
				if (in_path->type == SCARD_PATH_TYPE_DF_NAME)
					card_param->handle->curr_path = *in_path;

				if (cmd_param->file_out) {
					struct scard_file *filp;
					
					cmd_param->rbuf_actual = cmd_param->rbuf_len - apdu->resplen;
					scard_log_xxd(SCARD_LOG_DEBUG, "FCI: ", 
						cmd_param->rbuf, cmd_param->rbuf_actual);

					filp = scard_file_new();
					if (!filp) {
						cmd_param->ret = SCARD_ERR_NO_MEM;
					} else {
						if (cmd_param->rbuf_actual > 0) {
							cmd_param->ret = card_param->handle->card_driver->ops->process_fci(card_param->handle,
										filp, cmd_param->rbuf, cmd_param->rbuf_actual);
						} else {
							cmd_param->ret = wd_default_file(in_path, filp);
						}
							
						if (cmd_param->ret == SCARD_SUCCESS)
							*cmd_param->file_out = filp;
						else
							scard_file_free(filp);
					}
				}
				break;
			}
		}
	}

	cmd_param->callback(cmd_param->user_data, cmd_param->ret);

	free(in_path);
	if (cmd_param->rbuf) free(cmd_param->rbuf);
	free(cmd_param);
	free(apdu);
	free(card_param);
}


static int __wd_select_file(struct scard_handle *card_handle,
			    struct scard_path *in_path,
			    struct scard_file **file_out, 
			    scard_cmd_complete callback, 
			    void *user_data)
{
	struct scard_card_cmd_param *card_param;
	struct scard_cmd_param *cmd_param;
	struct scard_apdu *apdu;
	uint8_t *fci_buf = NULL;
	size_t fcibuf_len = 0;
	int r;

	cmd_param = malloc(sizeof(struct scard_cmd_param));
	if (!cmd_param) {
		free(in_path);
		return SCARD_ERR_NO_MEM;
	}
	memset(cmd_param, 0, sizeof(struct scard_cmd_param));
	cmd_param->path = in_path;
	/* XXX: Because Watch Data Card only support SELECT_BY_FILE_ID
	 * (or DF NAME), we use cmd_param->sbuf to trace the in_path. */
	cmd_param->sbuf = in_path->value;
	cmd_param->sbuf_len = in_path->len;
	cmd_param->file_out = file_out;
	if (file_out != NULL) {
		fcibuf_len = SCARD_APDU_BUFFER_MAX;
		fci_buf = malloc(fcibuf_len);
		if (!fci_buf) {
			free(in_path);
			free(cmd_param);
			return SCARD_ERR_NO_MEM;
		}
	}
	cmd_param->rbuf = fci_buf;
	cmd_param->rbuf_len = fcibuf_len;
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;
	
	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(in_path);
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = SCARD_APDU_CASE_4_SHORT;
	apdu->cla = card_handle->cla;
	apdu->ins = 0xA4;
	
	switch (in_path->type) {
	case SCARD_PATH_TYPE_DF_NAME:
		apdu->p1 = 0x04;
		apdu->p2 = 0x00;
		apdu->lc = cmd_param->sbuf_len;
		apdu->data = cmd_param->sbuf;
		apdu->datalen = cmd_param->sbuf_len;
		if (file_out) {
			apdu->le = cmd_param->rbuf_len -2;
			apdu->resp = cmd_param->rbuf;
			apdu->resplen = cmd_param->rbuf_len;
		}

		break;
	case SCARD_PATH_TYPE_FILE_ID:
	case SCARD_PATH_TYPE_FROM_CURRENT:
	case SCARD_PATH_TYPE_PATH:
		apdu->p1 = 0x00;
		apdu->p2 = 0x00;
		apdu->lc = 2;
		apdu->data = cmd_param->sbuf;
		apdu->datalen = cmd_param->sbuf_len;
		if (file_out && apdu->datalen == 2) {
			apdu->le = cmd_param->rbuf_len -2;
			apdu->resp = cmd_param->rbuf;
			apdu->resplen = cmd_param->rbuf_len;
		}

		break;
	default:
		free(in_path);
		free(cmd_param);
		free(apdu);
		return SCARD_ERR_NOT_SUPPORTED;			
	}
	
	card_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!card_param) {
		free(in_path);
		free(cmd_param);
		free(apdu);
		return SCARD_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct scard_card_cmd_param));
	card_param->handle = card_handle;
	card_param->cmd_param = cmd_param;
	card_param->apdu = apdu;
	card_param->callback = __wd_select_file_complete;

	r = scard_reader_transmit(card_param);
	if (r != SCARD_SUCCESS) {
		free(in_path);
		free(cmd_param);
		free(apdu);
		free(card_param);
	}

	return r;	
}

static int wd_select_file(struct scard_handle *card_handle, 
			  struct scard_path *in_path,
			  struct scard_file **file_out, 
			  scard_cmd_complete callback, void *user_data)
{
	
	struct scard_path *curr_path = &card_handle->curr_path;
	struct scard_path *out_path;
	
	out_path = malloc(sizeof(struct scard_path));
	if (!out_path)
		return SCARD_ERR_NO_MEM;

	switch (in_path->type) {
	case SCARD_PATH_TYPE_FILE_ID:
		if (in_path->len != 2) {
			free(out_path);
			return SCARD_ERR_INVALID_ARGS;
		}
	case SCARD_PATH_TYPE_DF_NAME:
	case SCARD_PATH_TYPE_FROM_CURRENT:
		*out_path = *in_path;
		break;
	case SCARD_PATH_TYPE_PATH:
		/* Your select path is equal to the current path, 
		 * and you want not file_out, return directly. */
		if ((in_path->len == curr_path->len)
			&& (memcmp(curr_path->value, in_path->value,
				   curr_path->len) == 0)
			&& (file_out == 0)) {
			callback(user_data, SCARD_SUCCESS);
			free(out_path);
			return SCARD_SUCCESS;
		}else if ((in_path->len > curr_path->len)
			&& (memcmp(curr_path->value, in_path->value,
				   curr_path->len) == 0)) {
			memcpy(out_path->value, 
				in_path->value + curr_path->len, 
				in_path->len - curr_path->len);
			out_path->len = in_path->len - curr_path->len;
			out_path->type = SCARD_PATH_TYPE_FROM_CURRENT;
		} else {
			*out_path = *in_path;
		}
		break;
	default:
		free(out_path);
		return SCARD_ERR_NOT_SUPPORTED;
	}
	
	return __wd_select_file(card_handle, out_path, file_out,
				callback, user_data);
}

static int file_type_sc_to_wd(const struct scard_file *filp)
{
	int wd_file_type = WD_FILE_TYPE_UNKNOWN;

	switch (filp->type) {
	case SCARD_FILE_TYPE_DF:
		if (filp->id == 0x3F00)
			wd_file_type = WD_FILE_TYPE_MF;
		else
			wd_file_type = WD_FILE_TYPE_DF;
		break;
	case SCARD_FILE_TYPE_WORKING_EF:
		switch (filp->ef_structure) {
		case SCARD_FILE_EF_TRANSPARENT:
			wd_file_type = WD_FILE_TYPE_BINARY;
			break;
		case SCARD_FILE_EF_LINEAR_FIXED:
		case SCARD_FILE_EF_LINEAR_FIXED_TLV:
			wd_file_type = WD_FILE_TYPE_RECORD_FIX;
			break;
		case SCARD_FILE_EF_CYCLIC:
		case SCARD_FILE_EF_CYCLIC_TLV:
			wd_file_type = WD_FILE_TYPE_RECORD_CYCLIC;
			break;
		case SCARD_FILE_EF_LINEAR_VARIABLE:
		case SCARD_FILE_EF_LINEAR_VARIABLE_TLV:
			wd_file_type = WD_FILE_TYPE_RECORD_VAR;
			break;
		}
		break;
	case SCARD_FILE_TYPE_INTERNAL_EF:
		switch (filp->ef_structure){
		case SCARD_FILE_EF_LINEAR_VARIABLE:
		case SCARD_FILE_EF_LINEAR_VARIABLE_TLV:
			if (filp->id == 0x0000)
				wd_file_type = WD_FILE_TYPE_KEYS;
			break;
		case SCARD_FILE_EF_TRANSPARENT:
			/* XXX: For PKI, We assume:
			 *	the file id of private key % 3 == 1
			 *	the file id of public key %3 == 2
			 *	the file id of certificate % 3 == 0
			 */
			if ((filp->id & 0xFF00) == 0x0000) {
				if ((filp->id & 0x00FF) % 3 == 1)
					wd_file_type = WD_FILE_TYPE_PRIVATE_KEY;
				else if ((filp->id & 0x00FF) % 3 == 2)
					wd_file_type = WD_FILE_TYPE_PUBLIC_KEY;
				else /*Cert*/
					wd_file_type = WD_FILE_TYPE_BINARY;
			}
			break;
		}
		break;
	}

	return wd_file_type;
}

static uint8_t acl2permission(const struct scard_file *filp, unsigned int op)
{
	uint8_t perm = WATCHDATA_SEC_STATE_NONE;
	const struct scard_acl_entry *acl;

	acl = scard_file_get_acl_entry(filp, op);

	if (!acl) {
		perm = WATCHDATA_SEC_STATE_NONE;
	} else {
		switch (acl->method) {
		case SCARD_AC_UNKNOWN:
		case SCARD_AC_NONE:
			perm = WATCHDATA_SEC_STATE_NONE;
			break;
		case SCARD_AC_CHV:
		case SCARD_AC_TERM:
		case SCARD_AC_PRO:
			perm = WATCHDATA_SEC_STATE_PIN;
			break;
		case SCARD_AC_AUT:
			perm = WATCHDATA_SEC_STATE_AUTH;
			break;
		case SCARD_AC_NEVER:
			perm = WATCHDATA_SEC_STATE_NEVER;
			break;
		default:
			perm = WATCHDATA_SEC_STATE_NONE;
			break;
		}
	}

	return perm;
}

/* XXX: We do not support CIRCURIT PROTECTED */
static int wd_format_ef_header(int wd_file_type, const struct scard_file *filp,
			       uint8_t *out, size_t *outlen)
{
	uint8_t *p = out;

	switch (wd_file_type) {
	case WD_FILE_TYPE_MF:
		*p++ = 0x38;
		*p++ = 0xFF;	/*File size(2 bytes)*/
		*p++ = 0xFF;
		*p++ = acl2permission(filp, SCARD_AC_OP_CREATE);
		*p++ = acl2permission(filp, SCARD_AC_OP_DELETE);
		*p++ = 0xFF;	/*The next 8 bytes reserved*/
		*p++ = 0xFF;
		*p++ = 0xFF;
		*p++ = 0xFF;
		*p++ = 0xFF;
		*p++ = 0xFF;
		*p++ = 0xFF;
		*p++ = 0xFF;
		break;
	case WD_FILE_TYPE_DF:
		*p++ = 0x38;	/*File Type*/
		*p++ = (filp->size >> 8) & 0xFF;
		*p++ = filp->size  & 0xFF;
		*p++ = acl2permission(filp, SCARD_AC_OP_CREATE);
		*p++ = acl2permission(filp, SCARD_AC_OP_DELETE);
		*p++ = 0xFF;	/*The next 3 bytes reserved*/
		*p++ = 0xFF;
		*p++ = 0xFF;
		if (filp->df_name_len > 0) {
			if (filp->df_name_len >= WD_MIN_DF_NAME 
				&& filp->df_name_len <= WD_MAX_DF_NAME) {
				memcpy(p, filp->df_name, filp->df_name_len);
				p += filp->df_name_len;
			} else {
				return SCARD_ERR_INVALID_ARGS;
			}
		}

		break;
	case WD_FILE_TYPE_BINARY:
		*p++ = 0x28;	/*File Type*/
		*p++ = (filp->size >> 8) & 0xFF;
		*p++ = filp->size  & 0xFF;
		*p++ = acl2permission(filp, SCARD_AC_OP_READ);
		*p++ = acl2permission(filp, SCARD_AC_OP_WRITE);
		*p++ = 0xFF;
		*p++ = 0xFF;

		break;
	case WD_FILE_TYPE_RECORD_FIX:
		if (filp->record_count < 2 || filp->record_count > 254)
			return SCARD_ERR_INVALID_ARGS;
		if (filp->record_length > 178)
			return SCARD_ERR_INVALID_ARGS;
		*p++ = 0x2A;/*File Type*/
		*p++ = filp->record_count;
		*p++ = filp->record_length;
		*p++ = acl2permission(filp, SCARD_AC_OP_READ);
		*p++ = acl2permission(filp, SCARD_AC_OP_WRITE);
		*p++ = 0xFF;
		*p++ = 0xFF;

		break;
	case WD_FILE_TYPE_RECORD_CYCLIC:
		if (filp->record_count < 2 || filp->record_count > 254)
			return SCARD_ERR_INVALID_ARGS;
		if (filp->record_length > 178)
			return SCARD_ERR_INVALID_ARGS;
		*p++ = 0x2E;/*File Type*/
		*p++ = filp->record_count;
		*p++ = filp->record_length;
		*p++ = acl2permission(filp, SCARD_AC_OP_READ);
		*p++ = acl2permission(filp, SCARD_AC_OP_WRITE);
		*p++ = 0xFF;
		*p++ = 0xFF;

		break;
	case WD_FILE_TYPE_RECORD_VAR:
		*p++ =  0x2C;/*File Type*/
		*p++ = (filp->size >> 8) & 0xFF;
		*p++ = filp->size  & 0xFF;
		*p++ = acl2permission(filp, SCARD_AC_OP_READ);
		*p++ = acl2permission(filp, SCARD_AC_OP_WRITE);
		*p++ = 0xFF;
		*p++ = 0xFF;

		break;
	case WD_FILE_TYPE_PRIVATE_KEY:
		if (filp->size < 330)
			return SCARD_ERR_INVALID_ARGS;
		*p++ = 0x3D;/*File Type*/
		*p++ = (filp->size >> 8) & 0xFF;
		*p++ = filp->size  & 0xFF;
		*p++ = acl2permission(filp, SCARD_AC_OP_USE);
		*p++ = acl2permission(filp, SCARD_AC_OP_UPDATE);
		*p++ = acl2permission(filp, SCARD_AC_OP_READ);
		*p++ = 0xFF;

		break;
	case WD_FILE_TYPE_PUBLIC_KEY:
		if (filp->size < 135)
			return SCARD_ERR_INVALID_ARGS;
		*p++ = 0x3E;/*File Type*/
		*p++ = (filp->size >> 8) & 0xFF;
		*p++ = filp->size  & 0xFF;
		*p++ = acl2permission(filp, SCARD_AC_OP_USE);
		*p++ = acl2permission(filp, SCARD_AC_OP_UPDATE);
		*p++ = acl2permission(filp, SCARD_AC_OP_READ);
		*p++ = 0xFF;

		break;
	case WD_FILE_TYPE_KEYS:
		*p++ = 0x3F;
		*p++ = (filp->size >> 8) & 0xFF;
		*p++ = filp->size  & 0xFF;
		*p++ = 0xFF;
		*p++ = acl2permission(filp, SCARD_AC_OP_WRITE);
		*p++ = 0xFF;
		*p++ = 0xFF;
		break;
/*TODO:
 *	WD_FILE_TYPE_WALLET
 *	WD_FILE_TYPE_ELEC_PASSBOOK
 *	WD_FILE_TYPE_ELEC_WALLET
 */
	default:
		return SCARD_ERR_NOT_SUPPORTED;		
	}

	*outlen = p - out;
	return SCARD_SUCCESS;
}

static int wd_construct_fci(struct scard_handle *card_handle, 
			    struct scard_file *filp,
			    uint8_t *fci_buf, size_t *fci_buflen)
{
	/*TODO: Support Security Message*/
	int wd_file_type = file_type_sc_to_wd(filp);
	
	return wd_format_ef_header(wd_file_type, filp, fci_buf, fci_buflen);
}

static void wd_create_file_complete(struct scard_card_cmd_param *card_param)
{
	struct scard_cmd_param *cmd_param = card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;

	if (card_param->ret != SCARD_SUCCESS)
		cmd_param->ret = card_param->ret;
	else {
		cmd_param->ret = scard_check_sw(card_param->handle, 
						apdu->sw1, apdu->sw2);
	}

	cmd_param->callback(cmd_param->user_data, cmd_param->ret);

	free(apdu);
	free(cmd_param);
	free(card_param);
}

static int wd_create_file(struct scard_handle *card_handle, 
			  struct scard_file *filp,
			  scard_cmd_complete callback, void *user_data)
{
	struct scard_card_cmd_param *card_param;
	struct scard_cmd_param *cmd_param;
	struct scard_apdu *apdu;
	uint8_t fci_buf[SCARD_APDU_BUFFER_MAX];
	size_t fci_buflen;
	int r;

	cmd_param = malloc(sizeof(struct scard_cmd_param));
	if (!cmd_param) 
		return SCARD_ERR_NO_MEM;
	memset(cmd_param, 0, sizeof(struct scard_cmd_param));
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;
	
	fci_buflen = sizeof(fci_buf);
	r = card_handle->card_driver->ops->construct_fci(card_handle, filp, 
							 fci_buf, &fci_buflen);
	if (r != SCARD_SUCCESS) {
		free(cmd_param);
		return r;
	}

	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(cmd_param);
		return SCARD_ERR_NO_MEM;	
	}
	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = SCARD_APDU_CASE_3_SHORT;
	apdu->cla = 0x80;
	apdu->ins = 0xE0;
	apdu->p1 = (filp->id >> 8) & 0xFF;
	apdu->p2 = filp->id & 0xFF;
	apdu->lc = fci_buflen;
	apdu->data = fci_buf;
	apdu->datalen = fci_buflen;

	card_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!card_param) {
		free(apdu);
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct scard_card_cmd_param));
	card_param->handle = card_handle;
	card_param->cmd_param = cmd_param;
	card_param->apdu = apdu;
	card_param->callback = wd_create_file_complete;

	r = scard_reader_transmit(card_param);
	if (r != SCARD_SUCCESS) {
		free(cmd_param);
		free(apdu);
		free(card_param);
	}

	return r;	
}

static int wd_construct_key_header(struct scard_cardctl_wd_write_key *keyp,
				   uint8_t *key_data, size_t *key_datalen)
{
	uint8_t *p = key_data;

	if (keyp->len + 5 > *key_datalen)
		return SCARD_ERR_INSUF_BUFFER;

	*p++ = keyp->type;
	switch (keyp->type) {
	case WD_KEY_TYPE_DES_ENCRYPT:
	case WD_KEY_TYPE_DES_DECRYPT:
	case WD_KEY_TYPE_DESMAC:
	case WD_KEY_TYPE_INTERNAL:
	case WD_KEY_TYPE_UPDATE_OVERDRAW:
	case WD_KEY_TYPE_DEBIT:
	case WD_KEY_TYPE_PURCHASE:
	case WD_KEY_TYPE_CREDIT:
		if (keyp->len != 8 && keyp->len != 16)
			return SCARD_ERR_INVALID_ARGS;
		*p++ = keyp->perm_use;
		*p++ = keyp->perm_update;
		*p++ = keyp->b4.ver;
		*p++ = keyp->b5.flag;
		break;
	case WD_KEY_TYPE_MAINTANCE:
	case WD_KEY_TYPE_PIN_UNBLOCK:
	case WD_KEY_TYPE_PIN_RELOAD:
		if (keyp->len != 8 && keyp->len != 16)
			return SCARD_ERR_INVALID_ARGS;
		*p++ = keyp->perm_use;
		*p++ = keyp->perm_update;
		*p++ = 0xFF;
		*p++ = keyp->b5.tries;
		break;
	case WD_KEY_TYPE_EXTERNAL_AUTH:
		if (keyp->len != 8 && keyp->len != 16)
			return SCARD_ERR_INVALID_ARGS;
		*p++ = keyp->perm_use;
		*p++ = keyp->perm_update;
		*p++ = keyp->b4.next_state;
		*p++ = keyp->b5.tries;
		break;
	case WD_KEY_TYPE_PIN:
		if (keyp->len < 2 || keyp->len > 8)
			return SCARD_ERR_INVALID_ARGS;
		*p++ = keyp->perm_use;
		*p++ = 0xEF;
		*p++ = keyp->b4.next_state;
		*p++ = keyp->b5.tries;
		break;
	case WD_KEY_TYPE_UNBLOCK:
		if (keyp->len != 8)
			return SCARD_ERR_INVALID_ARGS;
		*p++ = keyp->perm_use;
		*p++ = keyp->perm_update;
		*p++ = keyp->b4.pinid;
		*p++ = keyp->b5.tries;
		break;
	default:
		return SCARD_ERR_NOT_SUPPORTED;
	}

	memcpy(p, keyp->value, keyp->len);
	p += keyp->len;

	*key_datalen = p - key_data;

	return SCARD_SUCCESS;
}

static void wd_write_key_complete(struct scard_card_cmd_param *card_param)
{
	struct scard_cmd_param *cmd_param = card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;

	if (card_param->ret != SCARD_SUCCESS)
		cmd_param->ret = card_param->ret;
	else {
		cmd_param->ret = scard_check_sw(card_param->handle, 
						apdu->sw1, apdu->sw2);
	}

	cmd_param->callback(cmd_param->user_data, cmd_param->ret);

	free(apdu);
	free(cmd_param);
	free(card_param);
}

static int wd_write_key(struct scard_handle *card_handle, 
			struct scard_cardctl_wd_write_key *keyp,
			scard_cmd_complete callback, void *user_data)
{
	struct scard_card_cmd_param *card_param;
	struct scard_cmd_param *cmd_param;
	struct scard_apdu *apdu;
	uint8_t key_data[SCARD_APDU_BUFFER_MAX];
	size_t key_datalen = sizeof(key_data);
	int r;

	cmd_param = malloc(sizeof(struct scard_cmd_param));
	if (!cmd_param)
		return SCARD_ERR_NO_MEM;
	memset(cmd_param, 0, sizeof(struct scard_cmd_param));
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;

	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = SCARD_APDU_CASE_3_SHORT;
	apdu->cla = 0x80;
	apdu->ins = 0xD4;
	if (keyp->action == WRITE_KEY_ACTION_LOAD) {
		apdu->p1 = 0x01;
		r = wd_construct_key_header(keyp, key_data, &key_datalen);
		if (r != SCARD_SUCCESS) {
			free(cmd_param);
			free(apdu);
			return r;
		}
	} else {
		apdu->p1 = keyp->type;
		if (keyp->len > sizeof(key_data)) {
			free(cmd_param);
			free(apdu);
			return SCARD_ERR_INVALID_ARGS;
		}
		memcpy(key_data, keyp->value, keyp->len);
		key_datalen = keyp->len;
	}
	apdu->p2 = keyp->kid;
	/* TODO: construct key data */
	apdu->lc = key_datalen;
	apdu->data = key_data;
	apdu->datalen = key_datalen;

	card_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!card_param) {
		free(apdu);
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct scard_card_cmd_param));
	card_param->handle = card_handle;
	card_param->apdu = apdu;
	card_param->cmd_param = cmd_param;
	card_param->callback = wd_write_key_complete;

	r = scard_reader_transmit(card_param);
	if (r != SCARD_SUCCESS) {
		free(apdu);
		free(cmd_param);
		free(card_param);
	}

	return r;
}

static int wd_card_ctl(struct scard_handle *card_handle, 
		       unsigned long request, void *data,
		       scard_cmd_complete callback, void *user_data)
{
	struct scard_cardctl_wd_write_key *keyp;

	switch (request) {
	case SCARD_CARDCTL_WRITE_KEY:
		keyp = (struct scard_cardctl_wd_write_key *)data;
		return wd_write_key(card_handle, keyp, callback, user_data);
	default:
		return SCARD_ERR_INVALID_ARGS;
	}
}
#endif