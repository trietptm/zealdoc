#include "pcsc_priv.h"

static void ifd_hd_cancel(pcsc_handle_t *hd);
static int ifd_hd_icc_status(pcsc_handle_t *hd);
static int ifd_hd_power_off(pcsc_handle_t *hd);
static int ifd_hd_power_on(pcsc_handle_t *hd);
static int ifd_hd_xfr_block(pcsc_handle_t *hd, 
			    pcsc_trans_param_t *p);
static void __ifd_icc_status_loop_cb(pcsc_handle_t *hd);
static inline uint16_t __build_handle_idx(uint16_t r_idx, int s_idx);

static void pcsc_raise_event(pcsc_handle_t *rd_ctx, int event);

static void pcsc_stm_exit_delay(void *eloop, void *user_ctx);

static void pcsc_stm_log(const stm_instance_t *fsmi,
			int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

/* NOW ICC and IFD use the same state machine.
 * STM instance is in the ifd_hd_t *hd, its corresping to
 * a single slot(will bind to a ICC).
 * Its all right that all hd(s) shard the same reader state(I thought)
 * since reader is only related to RIS/RRM(insert/remove) event.
 */
#define PCSC_STATE_INIT		0
#define PCSC_STATE_OPEN		1	/* Reader Opening */
#define PCSC_STATE_CSTATUSING	2	/* ICC statusing */
#define PCSC_STATE_CSTATUSED	3	/* ICC statused */
#define PCSC_STATE_PRESENT	4	/* ICC present */
#define PCSC_STATE_ABSENT	5	/* ICC absent */
#define PCSC_STATE_POWERUP	6	/* ICC powerup(actived) */
#define PCSC_STATE_DEACTIVE	7	/* ICC deactive */
#define PCSC_STATE_POWERDOWN	8	/* ICC powerdown(deactived) */
#define PCSC_STATE_EXIT		9	

#define PCSC_STATE_COUNT	10

#define PCSC_STATE_NAMES {	\
	"INIT",			\
	"OPEN",			\
	"CSTATUSING",		\
	"CSTATUSED",		\
	"PRESENT",		\
	"ABSENT",		\
	"POWERUP",		\
	"DEACTIVE",		\
	"POWERDOWN",		\
	"EXIT",			\
}

#define PCSC_EVENT_RIS		0	/* Reader InSerted*/
#define PCSC_EVENT_ORS		1	/* Open Reader Success */
#define PCSC_EVENT_ORF		2	/* Open Reader Failed */
#define PCSC_EVENT_CSS		3	/* icC Status Success */
#define PCSC_EVENT_CSF		4	/* icC Status Failed */
#define PCSC_EVENT_TO		5	/* Time Out*/
#define PCSC_EVENT_ICCP		6	/* ICC Present */
#define PCSC_EVENT_ICCNP	7	/* ICC Not Present */
#define PCSC_EVENT_CAS		8	/* Card Active Success */
#define PCSC_EVENT_CAF		9	/* Card Active Failed */
#define PCSC_EVENT_ICCA		10	/* ICC active */
#define PCSC_EVENT_ICCD		11	/* Card deactive */
#define PCSC_EVENT_ICCR		12	/* ICC removed */
#define PCSC_EVENT_CIS		13	/* Card InSerted */	
#define PCSC_EVENT_RRM		14	/* Reader ReMoved */
#define PCSC_EVENT_CDS		15	/* Card Deactive Success */
#define PCSC_EVENT_CDF		16	/* Card Deactive Failed */

#define PCSC_EVENT_COUNT	17

#define PCSC_EVENT_NAMES {	\
	"RIS",			\
	"ORS",			\
	"ORF",			\
	"CSS",			\
	"CSF",			\
	"TO",			\
	"ICCP",			\
	"ICCNP",		\
	"CAS",			\
	"CAF",			\
	"ICCA",			\
	"ICCD",			\
	"ICCR",			\
	"CIS",			\
	"RRM",			\
	"CDS",			\
	"CDF",			\
}

static void pcsc_raise_event(pcsc_handle_t *rd_ctx, int event)
{
	eloop_schedule_event(NULL, rd_ctx->fsmi, event, rd_ctx);
}

void pcsc_raise_ris(pcsc_handle_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_RIS);
}

void pcsc_raise_ors(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ORS);
}

void pcsc_raise_css(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CSS);
}

void pcsc_raise_csf(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CSF);
}

void pcsc_raise_to(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_TO);
}

void pcsc_raise_iccp(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCP);
}

void pcsc_raise_iccnp(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCNP);
}

void pcsc_raise_cas(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CAS);
}

void pcsc_raise_caf(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CAF);
}

void pcsc_raise_icca(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCA);
}

void pcsc_raise_iccd(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCD);
}

void pcsc_raise_iccr(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCR);
}

void pcsc_raise_cis(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CIS);
}

void pcsc_raise_rrm(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_RRM);
}

void pcsc_raise_cds(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CDS);
}

void pcsc_raise_cdf(pcsc_handle_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CDF);
}

int pcsc_action_open(stm_instance_t *fsmi, void *data)
{
	pcsc_raise_ors(data);
	return 1;
}

static int pcsc_action_close(stm_instance_t *fsmi, void *data)
{
#if 0
	pcsc_handle_t *rd_ctx;
	
	rd_ctx = (pcsc_handle_t *)data;
	rd_ctx->ops->close(-1);
#endif
	return 1;
}


static int pcsc_action_erc(stm_instance_t *fsmi, void *data)
{
	eloop_register_timeout(NULL, 0, 0, 
		pcsc_stm_exit_delay, NULL, data);
	return 1;
}

/* This "warm up" sequence is sometimes needed when pcscd is
 * restarted with the reader already connected. We get some
 * "usb_bulk_read: Resource temporarily unavailable" on the 
 * first few tries. It is an empirical hack
 */
#define ICC_STATUS_RETRY_MAX	3
static int icc_status_retry = ICC_STATUS_RETRY_MAX;

static void icc_status_complete(pcsc_handle_t *hd)
{
	uint32_t icc_status;

	if (hd->ret != PCSC_S_SUCCESS) {
		if ((--icc_status_retry) > 0) {
			pcsc_raise_to(hd);
		} else {
			pcsc_raise_csf(hd);
			icc_status_retry = ICC_STATUS_RETRY_MAX;
		}
	} else {

#if 0
		if (hd->old_icc_status == hd->icc_status)
			return;
#endif

		icc_status = hd->icc_status;
		if (icc_status & PCSC_CARD_PRESENT_MASK) {
			/* ICC insert */
			pcsc_raise_iccp(hd);
			/* FIXME: need? icc_seq */
			hd->icc_seq++;

			pcsc_icc_up(hd->icc);
		} else {
			pcsc_icc_down(hd->icc);
			pcsc_raise_iccnp(hd);
		}
		icc_status_retry = ICC_STATUS_RETRY_MAX;
		hd->old_icc_status = hd->icc_status;
	}
}

static int pcsc_action_icc_status(stm_instance_t *fsmi, void *data)
{
	pcsc_handle_t *hd = (pcsc_handle_t *)data;
	int r;
	
	hd->cb = icc_status_complete;
	r = ifd_hd_icc_status(hd);

	if (r == PCSC_S_SUCCESS)
		pcsc_raise_css(hd);
	else
		pcsc_raise_csf(hd);
	return 1;
}

static void power_on_complete(pcsc_handle_t *hd)
{
	struct pcsc_atr_info atr_info;
	uint8_t atr[PCSC_MAX_ATR * 3];
	size_t i;

	if (hd->ret < 0) {
		if (hd->ret == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(hd);
		else
			pcsc_raise_caf(hd);
	} else {
		hd->icc->atr_len = hd->ret;
		if (pcsc_parse_atr(hd->icc->atr, hd->icc->atr_len, &atr_info) 
			== PCSC_S_SUCCESS) {
			hd->icc->proto = atr_info.default_proto;
			hd->icc->proto_supported = atr_info.supported_protos;

			for (i = 0; i < hd->icc->atr_len; i++) {
				if (i == hd->icc->atr_len - 1)
					sprintf(atr + i * 3, "%02X", hd->icc->atr[i]);
				else 
					sprintf(atr + i * 3, "%02X:", hd->icc->atr[i]);
			}
			pcsc_log(PCSC_LOG_DEBUG, "ATR: %s", atr);
			if (hd->icc->proto_supported & PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_DEBUG, "Support protocol: T0");
			if (hd->icc->proto_supported & PCSC_PROTOCOL_T1)
				pcsc_log(PCSC_LOG_DEBUG, "Support protocol: T1");

			if (hd->icc->proto == PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_DEBUG, "Default protocol: T0");
		} else {
			hd->icc->proto = PCSC_PROTOCOL_UNKNOWN;
			hd->icc->proto_supported = PCSC_PROTOCOL_UNKNOWN;
		}
		/* FIXME: we need set this value by hand? */
		hd->icc_status = PCSC_CARD_PRESENT_POWERUP;
		pcsc_raise_cas(hd);
	}
}

/* active ICC */
static int pcsc_action_aicc(stm_instance_t *fsmi, void *data)
{
	pcsc_handle_t *rd_ctx = (pcsc_handle_t *)data;
	int r;

	rd_ctx->cb = power_on_complete;

	r = ifd_hd_power_on(rd_ctx);

	if (r != PCSC_S_SUCCESS) {
		if (r == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_caf(rd_ctx);
	}
	return 1;
}

static void power_off_complete(pcsc_handle_t *rd_ctx)
{
	if (rd_ctx->ret != PCSC_S_SUCCESS) {
		if (rd_ctx->ret == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_cdf(rd_ctx);
	} else {
		pcsc_raise_cds(rd_ctx);
	}
}

/* deactive ICC */
static int pcsc_action_dicc(stm_instance_t *fsmi, void *data)
{
	pcsc_handle_t *rd_ctx = (pcsc_handle_t *)data;
	int r;

	rd_ctx->cb = power_off_complete;

	r = ifd_hd_power_off(rd_ctx);

	if (r != PCSC_S_SUCCESS) {
		if (r == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_cdf(rd_ctx);
	}	
	return 1;
}

/* Card Not Present */
static int pcsc_action_cnp(stm_instance_t *fsmi, void *data)
{
	pcsc_handle_t *hd = (pcsc_handle_t *)data;

	hd->icc_status = PCSC_CARD_ABSENT;
	pcsc_icc_down(hd->icc);
#if 0
	conn_num = atomic_read(&hd->handle.refcnt);
	while (conn_num--) {
		pcsc_disconnect(&hd->handle);
	}
#endif
	return 1;
}

/* Clear handle */
static int pcsc_action_chd(stm_instance_t *fsmi, void *data)
{
	pcsc_handle_t *ifd = (pcsc_handle_t *)data;
	
	ifd_hd_cancel(ifd);
	return 1;
}

static int pcsc_action_null(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static const stm_action_fn pcsc_act_open [] = {
	pcsc_action_open,
};

static const stm_action_fn pcsc_act_erc [] = {
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_close_erc [] = {
	pcsc_action_close,
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_icc_status [] = {
	pcsc_action_icc_status,
};

static const stm_action_fn pcsc_act_aicc [] = {
	pcsc_action_aicc,
};

static const stm_action_fn pcsc_act_cnp [] = {
	pcsc_action_cnp,
};

static const stm_action_fn pcsc_act_chd_cnp [] = {
	pcsc_action_chd,
	pcsc_action_cnp,
};

static const stm_action_fn pcsc_act_chd_dicc [] = {
	pcsc_action_chd,
	pcsc_action_dicc,
};


static const stm_action_fn pcsc_act_null [] = {
	pcsc_action_null,
};


#define STATE(state)	PCSC_STATE_##state
#define EVENT(event)	PCSC_EVENT_##event
#define ACTION(stem)	pcsc_act_##stem, \
		sizeof(pcsc_act_##stem) / sizeof(stm_action_fn) 

static const stm_entry_t pcsc_stm_entries[] = {
	/* state	event		action			new_state */
	{STATE(INIT),	EVENT(RIS),	ACTION(open),		STATE(OPEN),},

	{STATE(OPEN),	EVENT(ORS),	ACTION(icc_status),	STATE(CSTATUSING),},
#if 0
	{STATE(OPEN),	EVENT(ORF),	ACTION(erc),		STATE(EXIT),},
#endif
	{STATE(CSTATUSING),EVENT(CSS),	ACTION(null),		STATE(CSTATUSED),},
	{STATE(CSTATUSING),EVENT(CSF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(CSTATUSING),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(CSTATUSED),EVENT(CSF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(CSTATUSED),EVENT(TO),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(CSTATUSED),EVENT(ICCP),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(CSTATUSED),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(CSTATUSED),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},
	
	{STATE(PRESENT),EVENT(CAS),	ACTION(null),		STATE(POWERUP),},
	{STATE(PRESENT),EVENT(CAF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(PRESENT),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(PRESENT),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(PRESENT),EVENT(RRM),	ACTION(erc),		STATE(EXIT),},

	{STATE(ABSENT),	EVENT(CIS),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(ABSENT),	EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(POWERUP),EVENT(ICCA),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(POWERUP),EVENT(ICCD),	ACTION(chd_dicc),	STATE(DEACTIVE),},
	{STATE(POWERUP),EVENT(ICCR),	ACTION(chd_cnp),	STATE(ABSENT),},
	{STATE(POWERUP),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(DEACTIVE),EVENT(CDS),	ACTION(null),		STATE(POWERDOWN),},
	{STATE(DEACTIVE),EVENT(CDF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(DEACTIVE),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(DEACTIVE),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(DEACTIVE),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(POWERDOWN),EVENT(ICCA),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(POWERDOWN),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(POWERDOWN),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{0,		0,		ACTION(null),		0,},
};

static const char *pcsc_state_names[] = PCSC_STATE_NAMES;
static const char *pcsc_event_names[] = PCSC_EVENT_NAMES;

const stm_table_t pcsc_stm_table = {
	"PCSC",
	pcsc_stm_log,
	PCSC_STATE_COUNT,
	&pcsc_state_names[0],
	PCSC_EVENT_COUNT,
	&pcsc_event_names[0],
	pcsc_stm_entries,	
};

#undef STATE
#undef EVENT
#undef ACTION

int pcsc_icc_poweron(pcsc_handle_t *hd)
{
	pcsc_raise_icca(hd);
	return PCSC_S_SUCCESS;
}

static void pcsc_stm_exit(pcsc_handle_t *rd_ctx)
{
	if (rd_ctx->fsmi) {
		eloop_cleanup_events(NULL, rd_ctx->fsmi);
		stm_table_free(rd_ctx->fsmi);
		rd_ctx->fsmi = NULL;
	}
#if 0
	pcsc_handle_free(rd_ctx);
#endif
}

static void pcsc_stm_exit_delay(void *eloop, void *user_ctx) 
{
	pcsc_stm_exit((pcsc_handle_t *)user_ctx);
}

static inline uint16_t __build_handle_idx(uint16_t rdr_idx, int slot_idx)
{
	return (uint16_t)(rdr_idx << 8 | slot_idx);
}

pcsc_handle_t *pcsc_connect(int reader_idx, int slot_idx)
{

	return NULL;
}

int pcsc_check_handle_valid(pcsc_handle_t *handle)
{
	if (!handle) return 0;
	return 0;
//	return (handle->slot->icc_seq == handle->reader->icc_seq);
}

int pcsc_disconnect(pcsc_handle_t *handle)
{
#if 0
	int i;

	for (i = 0; i < PCSC_MAX_READERS; i++) {
		if (reader_ctx[i] && &reader_ctx[i]->handle == handle) {
			atomic_dec(&reader_ctx[i]->handle.refcnt);
			return PCSC_S_SUCCESS;
		}
	}
#endif
	return PCSC_E_INVALID_HANDLE;
}

int pcsc_transmit(pcsc_trans_param_t *param)
{
	pcsc_handle_t *rdr = param->handle;

	return rdr->ifd->ifd_ops->xfr_block(rdr, param);
}

int pcsc_ifd_control(pcsc_trans_param_t *param)
{
	ifd_driver_t *ops = param->handle->ifd->ifd_ops;

	return ops->ifd_ctl(param->handle, param);		
}


/*
int pcsc_pin_verify(struct pcsc_transmit_param *param)
{
	const struct pcsc_ifd_driver *driver = param->handle->reader.driver;

	return driver->ops->pin_verify(param->handle->hd, param);
}

int pcsc_pin_modify(struct pcsc_transmit_param *param)
{
	const struct pcsc_ifd_driver *driver = param->handle->reader.driver;

	return driver->ops->pin_modify(param->handle->hd, param);
}
*/


pcsc_handle_t *pcsc_handle_new(pcsc_ifd_t *rdr, int slot_idx)
{
	pcsc_handle_t *hd;

	hd = malloc(sizeof (pcsc_handle_t));
	if (!hd)
		goto err;

	memset(hd, 0, sizeof (pcsc_handle_t));

	hd->fsmi = stm_table_new(&pcsc_stm_table, rdr->name, 
				 PCSC_STATE_INIT);
	if (!hd->fsmi)
		goto err;

	hd->icc_status = hd->old_icc_status = PCSC_CARD_STATUS_UNKNOWN;
	hd->ifd_status = PCSC_READER_STATUS_PRESENT;
	hd->idx = __build_handle_idx(rdr->idx, slot_idx);

	list_init(&hd->link);
	list_insert_before(&hd->link, &rdr->handles);

	atomic_set(&hd->refcnt, 1);
	/* FIXME: call-chain may not need this? */
	hd->ifd = pcsc_ifd_get(rdr);
	hd->icc = pcsc_icc_new();

	return hd;
err:
	if (hd)
		free(hd);
	return NULL;
}

void pcsc_handle_free(pcsc_handle_t *hd)
{
	/* who will refernce hd?  a transfer param now */
	if (atomic_dec_and_test(&hd->refcnt)) {
		
		if (hd->fsmi) {
			/* for a BUG */
			eloop_cancel_timeout(NULL, pcsc_stm_exit_delay, NULL, hd);
			pcsc_stm_exit(hd);
		}
		if (hd->icc)
			pcsc_icc_free(hd->icc);

		list_delete(&hd->link);
		pcsc_ifd_put(hd->ifd);
		free(hd);
	}
}

void ifd_hd_start(pcsc_handle_t *hd)
{
	/* sm start - reader insert event */
	pcsc_raise_ris(hd);
}

void ifd_hd_stop(pcsc_handle_t *hd)
{
	/* sm start - reader remove event */
	pcsc_raise_rrm(hd);
}

static int ifd_hd_ifd_ctl(pcsc_handle_t *hd, 
			  pcsc_trans_param_t *p);

static void ifd_hd_cancel(pcsc_handle_t *hd)
{
	hd->ifd->ifd_ops->cancel(hd);
}

static int ifd_hd_icc_status(pcsc_handle_t *hd)
{
	return hd->ifd->ifd_ops->icc_status(hd);	
}

static int ifd_hd_power_off(pcsc_handle_t *hd)
{
	return hd->ifd->ifd_ops->power_off(hd);	
}

static int ifd_hd_power_on(pcsc_handle_t *hd)
{
	return hd->ifd->ifd_ops->power_on(hd);	
}

static int ifd_hd_xfr_block(pcsc_handle_t *hd, pcsc_trans_param_t *p)
{
	return hd->ifd->ifd_ops->xfr_block(hd, p);	
}

static int ifd_hd_ifd_ctl(pcsc_handle_t *hd, pcsc_trans_param_t *p)
{
	return hd->ifd->ifd_ops->ifd_ctl(hd, p);	
}


static void __ifd_icc_status_loop_cb(pcsc_handle_t *hd)
{
	if (hd->icc_status != hd->old_icc_status) {
		pcsc_log(PCSC_LOG_INFO, "IFD: icc state changed, %s -> %s",
			 pcsc_card_status_str(hd->old_icc_status), 
			 pcsc_card_status_str(hd->icc_status));
		if (hd->icc_status != 0)
			pcsc_icc_insert(hd);
		else
			pcsc_icc_remove(hd);
		/* forever check */
		/* record new status */
		hd->old_icc_status = hd->icc_status;
	}
	pcsc_detect_icc_loop(hd->ifd);
}

void pcsc_handle_detect_icc_start(pcsc_handle_t *hd)
{
	hd->cb = __ifd_icc_status_loop_cb;
	pcsc_log(PCSC_LOG_INFO, "IFD: do icc state detect");
	ifd_hd_icc_status(hd);
}
