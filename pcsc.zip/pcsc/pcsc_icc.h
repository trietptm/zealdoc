#ifndef __PCSC_ICC_H__
#define __PCSC_ICC_H__

struct __icc_driver_t {

	const char *name;
	uint32_t match_flags;
#define ICC_DRV_NO_MATCH	0x00	/* common, can it? */
#define	ICC_DRV_SYNC_MATCH	0x01	/* sync match */
#define ICC_DRV_ASYNC_MATCH	0x02	/* async match */
	/* muscle card will use async mode to match,
	 * watchdata card use sync match mode(just lookup id table)
	 */
	int (*match)(pcsc_icc_t *);
	int (*open)(pcsc_icc_t *);
	int (*close)(pcsc_icc_t *);
	list_t link;
};

struct _pcsc_icc_t {
	uint8_t atr[PCSC_MAX_ATR];
	size_t atr_len;
	int proto;
	int proto_supported;
	icc_driver_t *icc_ops;
	int lowerup;	/* 1 means can use this card's service */

	atomic_t refcnt;
	list_t link;
};

typedef struct _icc_atr_table {
	const char *name;
	const uint8_t *atr;
	const uint8_t *atr_mask;
} icc_atr_table;

const char *pcsc_card_status_str(uint32_t status);
int icc_match_atr(icc_atr_table *atr_table, const uint8_t *atr_bin,
			size_t atr_bin_len);

void pcsc_icc_up(pcsc_icc_t *);
void pcsc_icc_down(pcsc_icc_t *);

pcsc_icc_t *pcsc_icc_get(pcsc_icc_t *icc);
void pcsc_icc_put(pcsc_icc_t *icc);

pcsc_icc_t *pcsc_icc_new(void);
void pcsc_icc_free(pcsc_icc_t *icc);

int icc_register_driver(icc_driver_t *);
void icc_unregister_driver(icc_driver_t *);

/* card driver */
int __init icc_wd_init(void);
void __exit icc_wd_exit(void);

void icc_up(pcsc_icc_t *);
void icc_down(pcsc_icc_t *);

#endif	/* __PCSC_ICC_H__ */

