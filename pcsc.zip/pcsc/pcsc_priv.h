#ifndef __PCSC_PRIV_H__
#define __PCSC_PRIV_H__

#include <sysdep.h>
#include <logger.h>
#include <panic.h>
#include <module.h>
#include <strutl.h>
#include <dfastm.h>
#include <eloop.h>
#include <service.h>
#include <list.h>
#include <pcsc.h>
#include <bitops.h>

/*Logging operations*/
#define PCSC_LOG_CRIT	LOG_EMERG
#define PCSC_LOG_FAIL	LOG_CRIT
#define PCSC_LOG_ERR	LOG_ERR
#define PCSC_LOG_WARN	LOG_WARNING
#define PCSC_LOG_INFO	LOG_INFO
#define PCSC_LOG_DEBUG	LOG_DEBUG

#define LOG_CALL_CHAIN	PCSC_LOG_WARN
//#define LOG_CALL_CHAIN	PCSC_LOG_DEBUG

void pcsc_log(int level, const char *format, ...);

struct pcsc_atr_info {
	uint8_t TS;
	uint8_t T0;
	uint8_t history_len;

	int supported_protos;
	int default_proto;
	
};

/* upper */
typedef struct _pcsc_ifd_t pcsc_ifd_t;
typedef struct _pcsc_icc_t pcsc_icc_t;

/* connector: IFD and ICC main handle */
typedef struct _pcsc_handle_t   pcsc_handle_t;
typedef struct _pcsc_trans_param_t pcsc_trans_param_t;

/* lower */
typedef struct __ifd_driver_t ifd_driver_t;
typedef struct __icc_driver_t icc_driver_t;

typedef void (*pcsc_handle_cb)(pcsc_handle_t *hd);
typedef void (*pcsc_trans_comp)(pcsc_trans_param_t *pcsc_param);

#include "pcsc_ifd.h"
#include "pcsc_icc.h"

struct _pcsc_handle_t {
	uint16_t idx;	/* XXYY: XX - IFD idx, YY IFD_SLOT idx */
	pcsc_ifd_t *ifd;
	pcsc_icc_t *icc;

	/* if handle has this field, 
	 * all handle(s) need sync it. */
	uint16_t ifd_status;
	/* FIXME: ICC insert times, need? */
	uint32_t icc_seq;
	uint16_t icc_status;
	uint16_t old_icc_status;	/* for detect ICC state change */

	pcsc_handle_cb cb;
	int ret;
	stm_instance_t *fsmi;

	atomic_t refcnt;
	list_t link;
};

struct _pcsc_trans_param_t {
	pcsc_handle_t *handle;

	uint32_t ioctl;

	int ret;
	uint8_t *sbuf;
	size_t sbuf_len;
	uint8_t *rbuf;
	size_t rbuf_len;
	size_t rbuf_actual;
	uint32_t card_status;

	pcsc_trans_comp callback;
	void *user_data;
};

int pcsc_parse_atr(const char *atr, size_t atr_len, 
		   struct pcsc_atr_info *atr_info);
int pcsc_default_proto(const uint8_t *atr, size_t atr_len, 
			      int *def_pro);
int pcsc_support_proto(const uint8_t *atr, size_t atr_len, 
			int *supp_proto);

int pcsc_icc_poweron(pcsc_handle_t *);
int pcsc_icc_poweroff(pcsc_handle_t *);
int pcsc_icc_insert(pcsc_handle_t *);
int pcsc_icc_remove(pcsc_handle_t *);

int __init pcsc_ifd_init(void);
void __exit pcsc_ifd_exit(void);

int __init pcsc_icc_init(void);
void __exit pcsc_icc_exit(void);

/* handle API start*/
pcsc_handle_t *pcsc_handle_new(pcsc_ifd_t *rdr, int idx);
void pcsc_handle_free(pcsc_handle_t *hd);

void pcsc_raise_ris(pcsc_handle_t *hd);
void pcsc_raise_ors(pcsc_handle_t *rd_ctx);
void pcsc_raise_css(pcsc_handle_t *rd_ctx);
void pcsc_raise_csf(pcsc_handle_t *rd_ctx);
void pcsc_raise_to(pcsc_handle_t *rd_ctx);
void pcsc_raise_iccp(pcsc_handle_t *rd_ctx);
void pcsc_raise_iccnp(pcsc_handle_t *rd_ctx);
void pcsc_raise_cas(pcsc_handle_t *rd_ctx);
void pcsc_raise_caf(pcsc_handle_t *rd_ctx);
void pcsc_raise_icca(pcsc_handle_t *rd_ctx);
void pcsc_raise_iccd(pcsc_handle_t *rd_ctx);
void pcsc_raise_iccr(pcsc_handle_t *rd_ctx);
void pcsc_raise_cis(pcsc_handle_t *rd_ctx);
void pcsc_raise_rrm(pcsc_handle_t *rd_ctx);
void pcsc_raise_cds(pcsc_handle_t *rd_ctx);
void pcsc_raise_cdf(pcsc_handle_t *rd_ctx);

void ifd_hd_start(pcsc_handle_t *hd);
void ifd_hd_stop(pcsc_handle_t *hd);
void pcsc_handle_detect_icc_start(pcsc_handle_t *hd);

/* handle API stop */


#endif /*__PCSC_PRIV_H__*/
