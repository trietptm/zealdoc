#include "pcsc_priv.h"

int pcsc_parse_atr(const char *atr, size_t atr_len, 
		   struct pcsc_atr_info *atr_info)
{
	uint16_t p;
	uint8_t K, TCK;	/* MSN of T0/Check Sum */
	uint8_t Y1i, T;	/* MSN/LSN of TDi */
	int i = 1;	/* value of the index in TAi, TBi, etc. */

	p = K = TCK = Y1i = T = 0;

	atr_info->default_proto = PCSC_PROTOCOL_UNKNOWN;
	atr_info->supported_protos = PCSC_PROTOCOL_UNKNOWN;

	if (atr_len < 2)
		return PCSC_E_INVALID_ATR;

	BUG_ON(atr[0] != 0x3F &&
	       atr[0] != 0x3B);

	if (atr[0] == 0x3F)
		atr_info->TS = PCSC_ATR_TS_INVERSE;
	else if (atr[0] == 0x3B)
		atr_info->TS = PCSC_ATR_TS_DIRECT;
	else 
		return PCSC_E_INVALID_ATR;

	Y1i = atr[1] >> 4;
	K = atr[1] & 0x0F;

	p = 2;

	do {
		short TAi, TBi, TCi, TDi;

		TAi = (Y1i & 0x01) ? atr[p++] : -1;
		TBi = (Y1i & 0x02) ? atr[p++] : -1;
		TCi = (Y1i & 0x04) ? atr[p++] : -1;
		TDi = (Y1i & 0x08) ? atr[p++] : -1;
		
		if (TDi >= 0) {
			Y1i = TDi >> 4;
			T = TDi & 0x0F;

			if (atr_info->default_proto == PCSC_PROTOCOL_UNKNOWN) {
				switch (T) {
				case 0: 
					atr_info->default_proto = PCSC_PROTOCOL_T0;
					break;
				case 1:
					atr_info->default_proto = PCSC_PROTOCOL_T1;
					break;
				default:
					return PCSC_E_NOT_SUPPORTED;
				}
			}

			if (T == 0) {
				atr_info->supported_protos |= PCSC_PROTOCOL_T0;
			} else if (T == 1) {
				atr_info->supported_protos |= PCSC_PROTOCOL_T1;
			} else if (T == 15) {
				atr_info->supported_protos |= PCSC_PROTOCOL_T15;
			} else {
				/* Do nothing for now since other protocols are not 
				 * supported at this time. */
			}
			
			if ((i == 2) && (TAi >= 0)) {
				T = TAi & 0x0F;
				switch (T) {
				case 0:
					atr_info->default_proto = 
						atr_info->supported_protos = 
						PCSC_PROTOCOL_T0;
					break;
				case 1:
					atr_info->default_proto = 
						atr_info->supported_protos = 
						PCSC_PROTOCOL_T1;
					break;
				default:
					return	PCSC_E_NOT_SUPPORTED;
				}
			}
		} else {
			Y1i = 0;
		}

		if (p > PCSC_MAX_ATR)
			return PCSC_E_INVALID_ATR;
		i++;
	} while (Y1i != 0);
	
	if (atr_info->default_proto == PCSC_PROTOCOL_UNKNOWN) {
		atr_info->default_proto = PCSC_PROTOCOL_T0;
		atr_info->supported_protos |= PCSC_PROTOCOL_T0;
	}

	atr_info->history_len = K;
	p += K;

	if (atr_info->supported_protos & PCSC_PROTOCOL_T1)
		TCK = atr[p++];

	return PCSC_S_SUCCESS;
}

int pcsc_default_proto(const uint8_t *atr, size_t atr_len, 
		       int *default_proto) 
{
	struct pcsc_atr_info atr_info;
	int r;
	
	r = pcsc_parse_atr(atr, atr_len, &atr_info);
	if (r == PCSC_S_SUCCESS) {
		*default_proto = atr_info.default_proto;
		return PCSC_S_SUCCESS;
	} else {
		return r;
	}
}

/* support protocol */
int pcsc_support_proto(const uint8_t *atr, size_t atr_len, 
		       int *supported_proto) 
{
	struct pcsc_atr_info atr_info;
	int r;

	r = pcsc_parse_atr(atr, atr_len, &atr_info);
	if (r == PCSC_S_SUCCESS) {
		*supported_proto = atr_info.supported_protos;
		return PCSC_S_SUCCESS;
	} else {
		return r;
	}
}
