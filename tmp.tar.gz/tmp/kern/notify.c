#include <notify.h>
#include <stdlib.h>
#include <errno.h>

#define assign_pointer(p, v)	((p) = (v))
#define dereference(p)		(p)

/*
 * Notifier chain core routines.  The exported routines below
 * are layered on top of these, with appropriate locking added.
 */
static int notify_chain_register(notify_t **nl, notify_t *n)
{
	while ((*nl) != NULL) {
		if (n->priority > (*nl)->priority)
			break;
		nl = &((*nl)->next);
	}
	n->next = *nl;
	assign_pointer(*nl, n);
	return 0;
}

static int notify_chain_unregister(notify_t **nl, notify_t *n)
{
	while ((*nl) != NULL) {
		if ((*nl) == n) {
			assign_pointer(*nl, n->next);
			return 0;
		}
		nl = &((*nl)->next);
	}
	return -ENOENT;
}

/**
 * notifier_call_chain - Informs the registered notifiers about an event.
 * @nl:		Pointer to head of the blocking notifier chain
 * @val:	Value passed unmodified to notifier function
 * @v:		Pointer passed unmodified to notifier function
 * @nr_to_call:	Number of notifier functions to be called. Don't care
 *	     	value of this parameter is -1.
 * @nr_calls:	Records the number of notifications sent. Don't care
 *	   	value of this field is NULL.
 * @returns:	notifier_call_chain returns the value returned by the
 *		last notifier function called.
 */
static int notify_call_chain(notify_t **nl,
			     unsigned long val, void *v,
			     int nr_to_call, int *nr_calls)
{
	int ret = NOTIFY_DONE;
	notify_t *nb, *next_nb;

	nb = dereference(*nl);

	while (nb && nr_to_call) {
		next_nb = dereference(nb->next);
		ret = nb->call(nb, val, v);

		if (nr_calls)
			(*nr_calls)++;

		if ((ret & NOTIFY_STOP_MASK) == NOTIFY_STOP_MASK)
			break;
		nb = next_nb;
		nr_to_call--;
	}
	return ret;
}

int register_notify_chain(notify_head_t *nh, notify_t *n)
{
	return notify_chain_register(&nh->head, n);
}

int unregister_notify_chain(notify_head_t *nh, notify_t *n)
{
	return notify_chain_unregister(&nh->head, n);
}

static int __call_notify_chain(notify_head_t *nh, unsigned long val,
			       void *v, int nr_to_call, int *nr_calls)
{
	return notify_call_chain(&nh->head, val, v, nr_to_call, nr_calls);
}

int call_notify_chain(notify_head_t *nh, unsigned long val, void *v)
{
	return __call_notify_chain(nh, val, v, -1, NULL);
}
