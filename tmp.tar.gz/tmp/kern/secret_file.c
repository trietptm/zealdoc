#include <secret.h>
#include <strutl.h>
#include <nfastm.h>
#include "secret_priv.h"

#define FILE_TIMEOUT			1000	/* 1 sec */
#define FILE_COMPARE_MATCH		1
#define FILE_COMPARE_NOT_MATCH		0
#define file_restore(fd, off)		lseek(fd, off, SEEK_SET)

typedef struct _file_secret_t file_secret_t;

struct _file_secret_t {
	int lines;	/* which line we've read in fd_base */
	int fd_base;

	int fd_tmp;
	char *tmp_name;
	int del_line;	/* keep which line will be deleted. */

	const char *up_user;
	const char *up_domain;
	const char *up_format;
	char *up_secret;	/* may do strcpy */
	
	complete_cb comp_trans;
	int trans_type;
};

const char *secret_file_path = NULL;

static int file_put_line(int fd, char *buf);
static int file_get_line(int fd, char *buf);
static int file_add_line(file_secret_t *file, int fd);
static int file_skip_lines(int fd, int lineno);
static int file_divide_line(char *line, char words[4][MAX_SECRET_WORD_LEN]);
static void file_update_line(file_secret_t *file, int fd, int line_c);
static void file_delete_line(file_secret_t *file);
static char *file_build_a_line(char *str, const char *lname, const char *rname, 
			       const char *format, const char *pass);

static void file_complete_trans(void *ctx, int match);
static int file_compare_core(char *line, file_secret_t *file);
/* search and delete */
static void file_do_action(file_secret_t *file);
static void file_do_update(file_secret_t *file);

file_secret_t *delete_file = NULL;

#define FILE_READ_STATE_EOF	1
#define FILE_READ_STATE_ERROR	2
#define FILE_READ_STATE_FINISH	3	/* have finish this mission */
#define FILE_READ_STATE_SKIP	4
#define FILE_READ_STATE_NO_DATE		FILE_READ_STATE_ERROR

#define FILE_WRITE_STATE_ERROR	FILE_READ_STATE_ERROR
#define FILE_WRITE_STATE_FINISH	FILE_READ_STATE_FINISH

static int file_put_line(int fd, char *buf)
{
	int res, len = strlen(buf);

	res = write(fd, buf, len);
	if (len != res) {
		log_kern(LOG_ERR, "FILE: put line error.");
		return FILE_WRITE_STATE_ERROR;
	} else
		return FILE_WRITE_STATE_FINISH;
}

static int file_get_line(int fd, char *buf)
{
	int res, i = 0;
	
	do {
		res = read(fd, &buf[i], 1);
		if (buf[i] == '\n') {
			/* tell caller, the whole line read finish. */
			res = FILE_READ_STATE_FINISH;
			break;
		} else if (res == 0) {
			res = FILE_READ_STATE_EOF;
			break;
		}
		/* some thing error, need restore. */
		if (res < 0)
			return FILE_READ_STATE_NO_DATE;
		i++;
	} while (1);
	/* delete '\n' */
	buf[i] = '\0';
	/* Skip thie line if comment */
	if (buf[0] == '#')
		res = FILE_READ_STATE_SKIP;
	return res;
}

static int file_skip_lines(int fd, int lineno)
{
	int res, i = 0;
	char buf[MAX_SECRET_LINE_LEN];
	
	for (i = 0; i < lineno;) {
		res = file_get_line(fd, buf);
		if (buf[0] == '#')
			continue;
		i++;
	}
	return res;
}

static char *file_build_a_line(char *str, const char *lname, const char *rname, 
			       const char *format, const char *pass)
{
	BUG_ON(!format && !pass);

	if (lname)
		str = strdup(lname);
	else
		str = strdup("*");
	str = strredup(str, "\t");
	if (rname)
		str = strredup(str, rname);
	else
		str = strredup(str, "*");
	str = strredup(str, "\t");
	str = strredup(str, format);
	str = strredup(str, "\t");
	str = strredup(str, pass);
	str = strredup(str, "\n");

	return str;
}

/* If the line not contain 4 words? */
static int file_divide_line(char *line, char words[4][MAX_SECRET_WORD_LEN])
{
	char *start = NULL, *end = NULL;
	char *p = line;
	int len, num = 0;

	/* get words in this line. 
 	 * In our file there are four columns in one line.
	 * 
	 * domain \t user \t format \t secret \n
	 */
	while (*p) {
		start = p;
		/* BUG: two \t */
		if (!p)
			break;
		while (*p != '\t' && *p != ' ' && *p != 0)
			p++;
		end = p++;
		len = end - start;
		strncpy(words[num], start, len);
		words[num][len] = '\0';
		num++;
		if (num == 4)
			break;
	}
	if (num != 4)
		return -1;
	return 0;
}

static int file_add_line(file_secret_t *file, int fd)
{
	char *str =NULL;
	int len;
	int res = -1;

	if (lseek(fd, 0, SEEK_END) == -1)
		return res;
	
	str = file_build_a_line(str, file->up_domain, 
			file->up_user, file->up_format, file->up_secret);
	if (!str)
		return res;
	
	len = strlen(str);
	res = write(fd, str, len);
	if (res != len) {
		log_kern(LOG_ERR, "FILE: write error");
		res = -1;
	} else
		res = 0;

	if (str) free(str);
	return res;
}

static void file_update_line(file_secret_t *file, int fd, int line_c)
{
	int res, len;
	char *str =NULL;
	
	if (lseek(fd, 0, SEEK_SET) == -1)
		return;
	
	file_skip_lines(fd, line_c);
	
	str = file_build_a_line(str, file->up_domain, file->up_user, 
			file->up_format, file->up_secret);
	
	if (!str)
		return;
	
	len = strlen(str);
	res = write(fd, str, len);
	if (res != len)
		log_kern(LOG_ERR, "FILE: write error");

	if (str) free(str);
	return;
}

static void file_complete_trans(void *ctx, int match)
{
	file_secret_t *file = (file_secret_t *)ctx;
	char en_secret[MAX_SECRET_WORD_LEN], *tmp;
	secret_format_t *format;

	switch (file->trans_type) {
	case SECRET_TRANS_SEARCH:
		/* For close STM. */
		if (match)
			secret_source_success(file);
		else
			secret_source_failure(file);
		break;
	case SECRET_TRANS_UPDATE:
		format = secret_get_format(file->up_format);
		BUG_ON(!format);

		tmp = file->up_secret;

		if (format->crypt) {
			format->crypt(file->up_secret, en_secret, MAX_SECRET_WORD_LEN);
			file->up_secret = en_secret;
		}
		if (match) {
			log_kern(LOG_INFO, "FILE: exist a entry, updating...");
			file_update_line(file, file->fd_base, file->lines - 1);
		} else {
			log_kern(LOG_INFO, "FILE: Non-exist entry, creating...");
			file_add_line(file, file->fd_base);
		}

		file->up_secret = tmp;
		memset(en_secret, 0, MAX_SECRET_WORD_LEN);
		/* go on do update since may have other format in list. */
		file_do_update(file);
		break;
	case SECRET_TRANS_DELETE:
		if (match) {
			log_kern(LOG_INFO, "FILE: exist a entry, deleting...");
			/* TODO: do delete */
			/* need raise event */
			file_delete_line(file);
		} else {
			log_kern(LOG_INFO, "FILE: Non-exist entry for deleting.");
			secret_source_success(file);
		}
		break;
	default:
		log_kern(LOG_ERR, "FILE: Unknown type.");
		break;
	}
}

static int file_compare_core(char *line, file_secret_t *file)
{
	char words[4][MAX_SECRET_WORD_LEN];

	/* host user format secret */
	file_divide_line(line, words);

	if (strcasecmp(file->up_format, words[2]) == 0 &&
		strcmp(file->up_domain, words[0]) == 0 &&
		strcmp(file->up_user, words[1]) == 0) {
		/* XXX: only search need modify secret. */
		if (file->trans_type == SECRET_TRANS_SEARCH)
			strlcpy(file->up_secret, words[3], MAX_SECRET_LEN);
		return FILE_COMPARE_MATCH;
	}
	return FILE_COMPARE_NOT_MATCH;
}

static void file_search_core(void *eloop_data, void *data)
{
	file_secret_t *file = (file_secret_t *)data;
	int res, start_eloop = 0;
	char buf[MAX_SECRET_LINE_LEN];
	off_t offset;
	time_t start, now;
	int fd, match = FALSE;
	
	fd = file->fd_base;
	
	time(&start);
	while (1) {
		time(&now);
		
		if (now - start > FILE_TIMEOUT) {
			/* register eloop timeout */
			start_eloop = 1;	
			break;
		}
		
		offset = lseek(fd, 0, SEEK_CUR);
		memset(buf, 0, MAX_SECRET_LINE_LEN);
		res = file_get_line(fd, buf);
		
		if (res == FILE_READ_STATE_FINISH) {
			/* eloop cancel timeout */
			start_eloop = 0;
			file->lines++;
			if (FILE_COMPARE_MATCH == file_compare_core(buf, file)) {
				match = TRUE;
				break;			
			}
			/* Go on read if not match this line */
			continue;			
		} else if (res == FILE_READ_STATE_EOF) {
			match = FALSE;
			/* eloop cancel timeout */
			start_eloop = 0;
			break;
		} else if (res == FILE_READ_STATE_NO_DATE) {		
			file_restore(fd, offset);
			continue;
		} else if (res == FILE_READ_STATE_SKIP)
			continue;
	}
	
	if (start_eloop)
		eloop_register_timeout(NULL, 0, 
		FILE_TIMEOUT / 2,  file_search_core, NULL, file);
	else {
		eloop_cancel_timeout(NULL, file_search_core, NULL, file);
		if (file->comp_trans)
			file->comp_trans(file, match);
	}
	return;
}

static char *file_make_new_name(void)
{
	char *new_name;
	new_name = strdup(secret_file_path);
	new_name = strredup(new_name, ".tmp");
	if (!new_name)
		log_kern(LOG_ERR, "FILE: make new name failure.");
	return new_name;
}

static void file_clean_delete(file_secret_t *file)
{
	if (file) {
		close(file->fd_base);
		file->fd_base = 0;
		close(file->fd_tmp);
		file->fd_tmp = 0;
		remove(secret_file_path);
		if (file->tmp_name) {
			rename(file->tmp_name, secret_file_path);
			free(file->tmp_name);
		}
	}
}

static void file_delete_line_timeout(void *eloop, void *data)
{
	file_secret_t *file = (file_secret_t *)data;

	time_t start, now;
	int start_eloop = 0;
	off_t offset;
	char buf[MAX_SECRET_LINE_LEN];
	int res, len;

	time(&start);
	while (1) {
		time(&now);
		if (now - start > FILE_TIMEOUT) {
			/* register eloop timeout */
			start_eloop = 1;	
			break;
		}
		
		offset = lseek(file->fd_base, 0, SEEK_CUR);
		memset(buf, 0, MAX_SECRET_LINE_LEN);
		res = file_get_line(file->fd_base, buf);
		
		if (res == FILE_READ_STATE_FINISH) {
			/* eloop cancel timeout */ 
			file->lines++;
	
			len = strlen(buf);
			BUG_ON(len > MAX_SECRET_LINE_LEN);
			buf[len] = '\n';
			buf[len + 1] = 0;

			if (file->lines != file->del_line)
				res = file_put_line(file->fd_tmp, buf);
			if (FILE_WRITE_STATE_FINISH == res)
				continue;
			else {
				/* TODO: handle error */
				BUG();	
			}
		} else if (res == FILE_READ_STATE_EOF) {
			break;
		}
	}
	
	if (start_eloop) {
		eloop_register_timeout(NULL, 0, FILE_TIMEOUT, file_delete_line_timeout, NULL, file);
	}
	else {
		eloop_cancel_timeout(NULL, file_delete_line_timeout, NULL, file);
		/* remove and rename file */
		file_clean_delete(file);
		secret_source_success(file);
	}
	return;
}

static void file_delete_line(file_secret_t *file)
{
	char *name;
	name = file_make_new_name();

	if (!name)
		return;
	file->fd_tmp = open(name, O_CREAT);
	close(file->fd_tmp);
	file->fd_tmp = open(name, O_RDWR);
	if (file->fd_tmp < 0)
		goto err;

	lseek(file->fd_base, 0, SEEK_SET);
	lseek(file->fd_tmp, 0, SEEK_SET);
	
	/* Note: sequence. */
	file->del_line = file->lines;
	file->lines = 0;
	file->tmp_name = name;
	eloop_register_timeout(NULL, 0, 0, file_delete_line_timeout, NULL, file);

	return;
err:
	if (name)
		free(name);
	return;
}

/************************************************************************/
/*       source inst callback                                           */
/************************************************************************/

static void file_do_update(file_secret_t *file)
{
	secret_format_t *format = NULL;

	/* First time arrive here. */
	if (!file->up_format)
		format = secret_get_next_format(NULL);
	else 
		format = secret_get_next_format_by_name(file->up_format);

	if (format) {
		file->up_format = format->name;
		file_search_core(NULL, file);
		return;
	}
	/* We have walked all format and now raise close STM. */
	log_kern(LOG_INFO, "FILE: update operation(s) finished.");
	secret_source_success(file);	
}

static void file_do_action(file_secret_t *file)
{
	/* complete cb will raise event. */
	file_search_core(NULL, file);	
	return;
}

static file_secret_t *file_new(void)
{
	file_secret_t *file;
	
	/* XXX: every new file, we should reset path */
	secret_file_path = (const char *)
			secret_read_profile(SECRET_SOURCE_FILE,
					    SECRET_PROF_PATH);

	if (!secret_file_path)
		return NULL;
	
	file = malloc(sizeof (file_secret_t));
	if (!file)
		return NULL;
	
	memset(file, 0, sizeof (file_secret_t));
	file->fd_base = open(secret_file_path, O_RDWR);
	if (file->fd_base < 0) {
		log_kern(LOG_ERR, "FILE: cannot open file=%s", secret_file_path);
		free(file);
		return NULL;
	}

	file->comp_trans = file_complete_trans;

	return file;
}

static void file_free(file_secret_t *file)
{
	if (file) {
		file->comp_trans = NULL;
		if (file->fd_base > 0)
			close(file->fd_base);
		if (file->fd_tmp > 0)
			close(file->fd_tmp);
		free(file);
	}	
}

static void *file_init(void)
{
	return file_new();
}

static void file_exit(void *data)
{
	file_secret_t *file = (file_secret_t *)data;
	if (file)
		file_free(file);
}

static int file_start_search(void *data, const char *domain, const char *user,
			     const char *format, char *secret)
{
	file_secret_t *file = (file_secret_t *)data;

	file->up_domain = domain;
	file->up_user = user;
	file->up_format = format;
	/* May modify secret if match. */
	file->up_secret = secret;

	file->trans_type = SECRET_TRANS_SEARCH;

	/* Ensure from head. */
	if (lseek(file->fd_base, 0, SEEK_SET) == -1)
		BUG();
	file_do_action(file);
	return 0;
}

static int file_start_update(void *data, const char *domain, const char *user,
			      const char *format, const char *secret)
{
	file_secret_t *file = (file_secret_t *)data;
	file->up_domain = domain;
	file->up_user = user;
	file->up_format = NULL;
	/* Do not modify secret. */
	file->up_secret = (char *)secret;

	file->trans_type = SECRET_TRANS_UPDATE;

	/* walk all format */
	file_do_update(file);
	return 0;
}

static int file_start_delete(void *data, const char *domain, const char *user,
			     const char *format)
{
	file_secret_t *file = (file_secret_t *)data;
	file->up_domain = domain;
	file->up_user = user;
	file->up_format = format;
	file->up_secret = NULL;
	
	file->trans_type = SECRET_TRANS_DELETE;
	file_do_action(file);

	return 0;
}

secret_source_t secret_file = {
	SECRET_SOURCE_FILE,
	file_init,
	file_exit,
	file_start_search,
	file_start_delete,
	file_start_update,
};

modlinkage int __init secret_file_init(void)
{
	return secret_register_source(&secret_file);
}

modlinkage void __exit secret_file_exit(void)
{
	secret_unregister_source(&secret_file);
}

module_init(secret_file_init);
module_exit(secret_file_exit);
