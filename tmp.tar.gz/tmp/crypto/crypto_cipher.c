#include "crypto_priv.h"

static int crypto_setkey(crypto_tfm_t *tfm, const uint8_t *key, unsigned int keylen)
{
	struct cipher_alg *cia = &tfm->__crt_alg->cra_cipher;

	tfm->crt_flags &= ~CRYPTO_TFM_RES_MASK;
	if (keylen < cia->cia_min_keysize || keylen > cia->cia_max_keysize) {
		tfm->crt_flags |= CRYPTO_TFM_RES_BAD_KEY_LEN;
		return -EINVAL;
	}

	return cia->cia_setkey(tfm, key, keylen);
}

int crypto_init_cipher_ops(crypto_tfm_t *tfm)
{
	struct cipher_tfm *ops = &tfm->crt_cipher;
	struct cipher_alg *cipher = &tfm->__crt_alg->cra_cipher;

	ops->cit_setkey = crypto_setkey;
	ops->cit_encrypt_one = cipher->cia_encrypt;
	ops->cit_decrypt_one = cipher->cia_decrypt;

	return 0;
}

void crypto_exit_cipher_ops(crypto_tfm_t *tfm)
{
}
