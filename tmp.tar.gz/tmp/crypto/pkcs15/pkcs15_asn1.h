#ifndef __PKCS15_ASN1_H__
#define __PKCS15_ASN1_H__
#include <pkcs15.h>

#define PKCS15_ASN1_CLASS_MASK		0x30000000
#define PKCS15_ASN1_UNI			0x00000000 /* Universal */
#define PKCS15_ASN1_APP			0x10000000 /* Application */
#define PKCS15_ASN1_CTX			0x20000000 /* Context */
#define PKCS15_ASN1_PRV			0x30000000 /* Private */
#define PKCS15_ASN1_CONS		0x01000000

#define PKCS15_ASN1_TAG_MASK		0x00FFFFFF

/* asn1 entry type */
#define PKCS15_ASN1_BOOLEAN                 1
#define PKCS15_ASN1_INTEGER                 2
#define PKCS15_ASN1_BIT_STRING              3
#define PKCS15_ASN1_BIT_STRING_NI           128
#define PKCS15_ASN1_OCTET_STRING            4
#define PKCS15_ASN1_NULL                    5
#define PKCS15_ASN1_OBJECT                  6
#define PKCS15_ASN1_ENUMERATED              10
#define PKCS15_ASN1_UTF8STRING              12
#define PKCS15_ASN1_SEQUENCE                16
#define PKCS15_ASN1_SET                     17
#define PKCS15_ASN1_PRINTABLESTRING         19
#define PKCS15_ASN1_UTCTIME                 23
#define PKCS15_ASN1_GENERALIZEDTIME         24
/* internal structures */
#define PKCS15_ASN1_STRUCT		129
#define PKCS15_ASN1_CHOICE		130
#define PKCS15_ASN1_BIT_FIELD		131	/* bit string as integer */
/* 'complex' structures */
#define PKCS15_ASN1_PATH		256
#define PKCS15_ASN1_PKCS15_ID		257
#define PKCS15_ASN1_PKCS15_OBJECT	258
#define PKCS15_ASN1_ALGORITHM_ID	259
#define PKCS15_ASN1_SE_INFO		260
/* use callback function */
#define PKCS15_ASN1_CALLBACK		384

/* asn1 entry flags */
#define PKCS15_ASN1_PRESENT		0x00000001
#define PKCS15_ASN1_OPTIONAL		0x00000002
#define PKCS15_ASN1_ALLOC		0x00000004
#define PKCS15_ASN1_UNSIGNED		0x00000008

/* asn1 entry tag */
#define PKCS15_ASN1_TAG_EOC			0
#define PKCS15_ASN1_TAG_BOOLEAN			1
#define PKCS15_ASN1_TAG_INTEGER			2
#define PKCS15_ASN1_TAG_BIT_STRING		3
#define PKCS15_ASN1_TAG_OCTET_STRING		4
#define PKCS15_ASN1_TAG_NULL			5
#define PKCS15_ASN1_TAG_OBJECT			6
#define PKCS15_ASN1_TAG_OBJECT_DESCRIPTOR	7
#define PKCS15_ASN1_TAG_EXTERNAL		8
#define PKCS15_ASN1_TAG_REAL			9
#define PKCS15_ASN1_TAG_ENUMERATED		10
#define PKCS15_ASN1_TAG_UTF8STRING		12
#define PKCS15_ASN1_TAG_SEQUENCE		16
#define PKCS15_ASN1_TAG_SET			17
#define PKCS15_ASN1_TAG_NUMERICSTRING		18
#define PKCS15_ASN1_TAG_PRINTABLESTRING		19
#define PKCS15_ASN1_TAG_T61STRING		20
#define PKCS15_ASN1_TAG_TELETEXSTRING		20
#define PKCS15_ASN1_TAG_VIDEOTEXSTRING		21
#define PKCS15_ASN1_TAG_IA5STRING		22
#define PKCS15_ASN1_TAG_UTCTIME			23
#define PKCS15_ASN1_TAG_GENERALIZEDTIME		24
#define PKCS15_ASN1_TAG_GRAPHICSTRING		25
#define PKCS15_ASN1_TAG_ISO64STRING		26
#define PKCS15_ASN1_TAG_VISIBLESTRING		26
#define PKCS15_ASN1_TAG_GENERALSTRING		27
#define PKCS15_ASN1_TAG_UNIVERSALSTRING		28
#define PKCS15_ASN1_TAG_BMPSTRING		30

struct pkcs15_asn1_entry {
	const char *name;
	unsigned int type;
	unsigned int tag;
	unsigned int flags;
	void *param;
	void *arg;
};

struct asn1_pkcs15_object {
	struct pkcs15_object *p15_obj;
	struct pkcs15_asn1_entry *asn1_class_attr;
	struct pkcs15_asn1_entry *asn1_subclass_attr;
	struct pkcs15_asn1_entry *asn1_type_attr;
};

struct asn1_pkcs15_algorithm_info {
	int id;
	struct icc_object_id oid;
	int (*decode)(void **, const uint8_t *, size_t, int);
	int (*encode)(void *, uint8_t **, size_t *, int);
	void (*free)(void *);
};

void pkcs15_format_asn1_entry(struct pkcs15_asn1_entry *entry, void *param, 
			     void *arg, int set_present);
void pkcs15_copy_asn1_entry (const struct pkcs15_asn1_entry *src,
			    struct pkcs15_asn1_entry *dest);
int pkcs15_asn1_encode_algorithm_id(uint8_t **buf, size_t *len,
				   const struct icc_algorithm_id *id,
				   int depth);

int pkcs15_asn1_decode_integer(const uint8_t * inbuf, size_t inlen, int *out);
int pkcs15_asn1_decode_object_id(const uint8_t * inbuf, size_t inlen,
				 struct icc_object_id *id);
int asn1_encode(const struct pkcs15_asn1_entry *asn1, uint8_t **ptr, 
		      size_t *size, int depth);
int pkcs15_asn1_decode_algorithm_id(const uint8_t *in, size_t len, 
				    struct icc_algorithm_id *id, int depth);
int asn1_decode(struct pkcs15_asn1_entry *asn1, const uint8_t *in, size_t len,
		const uint8_t **newp, size_t *len_left, int choice, int depth);
int pkcs15_asn1_encode(const struct pkcs15_asn1_entry *asn1, uint8_t **ptr, 
		      size_t *size);
int pkcs15_asn1_decode(struct pkcs15_asn1_entry *asn1, const uint8_t *in, 
		       size_t len, const uint8_t **newp, size_t *len_left);
int pkcs15_asn1_decode_choice(struct pkcs15_asn1_entry *asn1, const uint8_t *in, 
			  size_t len, const uint8_t **newp, size_t *len_left);

struct asn1_pkcs15_algorithm_info *
	pkcs15_asn1_get_algorithm_info(const struct icc_algorithm_id *id);

/* DER encoding */
#endif  /* __PKCS15_ASN1_H__ */

