#include <sys/socket.h>
#include <sys/types.h>
#include <linux/in.h>

int sock = -1;

/* create socket */
int sock_open(char *ip)
{
	struct sockaddr_in srv_addr;
	int ret;

	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0) {
		printf("socket err\n");
		return -1;
	}

	memset(&srv_addr, 0, sizeof (srv_addr));
	srv_addr.sin_family = AF_INET;
	srv_addr.sin_port = htons(1234);
	srv_addr.sin_addr.s_addr = inet_addr(ip);

	ret = connect(sock, (struct sockaddr *)&srv_addr, sizeof (srv_addr));
	if (ret != 0) {
		printf("conn fail, server ip=%s\n", ip);
		close(sock);
		return -1;
	} else
		printf("conn succ\n");

	ret = send(sock, "client", strlen("client"), 0);
	if (ret > 0) {
		printf("send succ\n");
	} else
		printf("send %d\n", ret);
	return sock;
}

void sock_close(void)
{
	if (sock > 0)
		close(sock);
	sock = -1;
}

int main(int argc, char *argv[])
{
	if (argc < 2) {
		printf("usage: cli [IP]\n");
		return 0;
	}
	sock_open(argv[1]);
	sock_close();
	return 0;
}
