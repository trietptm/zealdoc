#include "wintest.h"

/* http://msdn.microsoft.com/en-us/library/aa379790(VS.85).aspx */
/* http://www.diybl.com/course/3_program/c++/cppsl/200866/122899.html */

SCARDCONTEXT *g_hSC = NULL;

void win_exit(void);
int win_init(void);
static t_list_rdrs(void);
static void win_err_dump(void);

int main(void)
{
	if (win_init())
		return 1;

	t_list_rdrs();
//	test_list_intfc();
	win_exit();
	return 0;
}

int win_init(void)
{
	SCARDCONTEXT    hSC;
	LONG            lReturn;
	// Establish the context.
	lReturn = SCardEstablishContext(SCARD_SCOPE_USER,
		NULL,
		NULL,
		&hSC);

	if ( SCARD_S_SUCCESS != lReturn ) {
		printf("Failed SCardEstablishContext\n");
		return -1;
	} else {
		g_hSC = &hSC;
		return 0;
	}	
}

void win_exit(void)
{
	if (g_hSC)
		SCardReleaseContext(*g_hSC);
}

static int t_list_rdrs(void)
{
	LPTSTR          pmszReaders = NULL;
	LPTSTR          pReader;
	LONG            lReturn, lReturn2;
	DWORD           cch = SCARD_AUTOALLOCATE;
	SCARDCONTEXT	hSC = *g_hSC;
	int num = 0;

	// Retrieve the list the readers.
	// hSC was set by a previous call to SCardEstablishContext.
	lReturn = SCardListReaders(hSC, NULL, (LPTSTR)&pmszReaders, &cch);

	switch( lReturn )
	{
	case SCARD_E_NO_READERS_AVAILABLE:
		printf("Reader is not in groups.\n");
		// Take appropriate action.
		// ...
		break;
		
	case SCARD_S_SUCCESS:
		// Do something with the multi string of readers.
		// Output the values.
		// A double-null terminates the list of values.

		pReader = pmszReaders;
		while ( '\0' != *pReader )
		{
			// Display the value.
			printf("Reader: %s\n", pReader );

			// Advance to the next value.
			pReader = pReader + wcslen((wchar_t *)pReader) + 1;
		}


		// Free the memory.
		lReturn2 = SCardFreeMemory(hSC, pmszReaders);
		if (SCARD_S_SUCCESS != lReturn2)
			printf("Failed SCardFreeMemory\n");
		break;
		
	default:
		printf("Failed SCardListReaders\n");
		break;
	}
}

static void win_err_dump(void)
{
	char szError[256];
	DWORD dwError = GetLastError();
	
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM,
		      NULL,                        
		      0,
		      0,
		      szError,
		      sizeof(szError),
		      NULL);

	printf("<err>=%s, <line>=%d\r\n", szError, __LINE__);
}