// SCardConnectTest.cpp : �R���\�[�� �A�v���P�[�V�����p�̃G���g�� �|�C���g�̒�`
//

#include "stdafx.h"
#include <winscard.h>
#include <stdio.h>

#define ACR122_READER_NAME1		"ACS ACR122U for NFC  0"
#define ACR122_READER_NAME2		"    CCID USB Reader 0"
#define ACR122_READER_NAME3		"ACS ACR122 0"

SYSTEMTIME Clock[5] = {0};
char ReaderName[256] = "";

BOOL acrTest();
BOOL cardmanTest();
void showUsage();
void showReport();
DWORD getReaderName();
void compareAcr( const char* SourceReader );

static void win_err_dump(void)
{
	char szError[256];
	DWORD dwError = GetLastError();
	
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM,
		      NULL,                        
		      0,
		      0,
		      szError,
		      sizeof(szError),
		      NULL);

	printf("<err>=%s\r\n", szError);
}
int main(int argc, char* argv[])
{
	if ( argc == 2 ) {
		if ( !strcmp( argv[1], "-a" ) ){
			getReaderName();
			if ( !acrTest() )
				return 1;
		}
		else if ( !strcmp( argv[1], "-c" ) ){
			if ( !cardmanTest() )
				return 1;
		}
		else {
			showUsage();
			return 1;
		}
	}
	else {
		showUsage();
		return 1;
	}

	showReport();

	return 0;
}

void showUsage()
{
	printf( "Usage: SCardConnectTest.exe -a | -c \n" );
	printf( "Options:\n" );
	printf( "       -a  Use for ACR122 \n" );
	printf( "       -c  Use for CardMan5321 \n" );
}

BOOL acrTest()
{
	SCARDCONTEXT Context;
	DWORD ActiveProtocol;
	SCARDHANDLE CardHandle;
	DWORD Result;

	SCardEstablishContext( SCARD_SCOPE_USER, NULL, NULL, &Context );

	GetSystemTime( &Clock[0] );

	Result = 
		SCardConnect( Context, ReaderName, SCARD_SHARE_SHARED,
					SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1,  
					&CardHandle, &ActiveProtocol );

	if( Result != SCARD_S_SUCCESS )
		return FALSE;


	GetSystemTime( &Clock[1] );

	BYTE SendBuffer[] = { 0xff, 0x00, 0x00, 0x00, 0x05, 0xD4, 0x60, 0x01, 0x01, 0x10 };
	BYTE ReceiveBuffer[256] = { 0x00 };
	DWORD ReceiveLength = sizeof(ReceiveBuffer);

	Result = SCardTransmit( CardHandle, SCARD_PCI_T0, 
					SendBuffer, sizeof(SendBuffer), NULL, ReceiveBuffer, &ReceiveLength );

	GetSystemTime( &Clock[2] );

	SendBuffer[1] = 0xC0;
	SendBuffer[4] = ReceiveBuffer[1];
	ZeroMemory( SendBuffer+5, sizeof(SendBuffer)-5 );
	ReceiveLength = sizeof(ReceiveBuffer);
	ZeroMemory( ReceiveBuffer, ReceiveLength );
	
	SCardTransmit( CardHandle, SCARD_PCI_T0, SendBuffer, 5, NULL, ReceiveBuffer, &ReceiveLength );

	GetSystemTime( &Clock[3] );

	SCardDisconnect( CardHandle, SCARD_LEAVE_CARD );

	GetSystemTime( &Clock[4] );

	char szOutput[200] = {0};
	char szTemp[5] = {0};
	for (DWORD i = 0; i < ReceiveLength; i++){
		wsprintf(szTemp, "%02x ", ReceiveBuffer[i]);
		lstrcat(szOutput, szTemp);
	}
	szOutput[lstrlen(szOutput)-1] = '\0';

	printf( "%s\n", szOutput );

	return TRUE;
}

BOOL cardmanTest()
{
	SCARDCONTEXT Context;
	char ReaderName[MAX_PATH] = "";
	DWORD ActiveProtocol;
	SCARDHANDLE CardHandle;
	DWORD Result;


	SCardEstablishContext( SCARD_SCOPE_USER, NULL, NULL, &Context );

	GetSystemTime( &Clock[0] );

	Result = 
		SCardConnect( Context, "OMNIKEY CardMan 5x21-CL 0", SCARD_SHARE_SHARED,
					SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1,  
					&CardHandle, &ActiveProtocol );

	GetSystemTime( &Clock[1] );

	if( Result != SCARD_S_SUCCESS )
		return FALSE;

	BYTE SendBuffer[] = { 0xFF, 0xCA, 0x00, 0x00, 0x00 };
	BYTE ReceiveBuffer[256] = { 0x00 };
	DWORD ReceiveLength = sizeof(ReceiveBuffer);

	Result = SCardTransmit( CardHandle, SCARD_PCI_T1, 
			   SendBuffer, sizeof(SendBuffer), NULL, ReceiveBuffer, &ReceiveLength );

	GetSystemTime( &Clock[2] );

	Clock[3].wSecond = 90;

	SCardDisconnect( CardHandle, SCARD_LEAVE_CARD );

	GetSystemTime( &Clock[4] );

	return TRUE;
}

void calc( float* time, int sec, int mil )
{
	if ( ( sec == 0 ) && ( mil == 0 ) )
		*time = 0.0;
	else {
		if ( sec < 0 )
			sec += 60;
		if ( mil < 0 ){
			mil += 1000;
			--sec;
		}
	}
		*time = float ( ( sec * 1000 + mil ) / 1000.0 );
}
void showReport()
{

	float time = 0.0;
	int sec, mil;

	for ( int i = 0; i < 5; ++i ) {
		if ( Clock[i].wSecond != 90 ){
			printf("%d: %d:%d\"%d.%d\n", 
				i, Clock[i].wHour, Clock[i].wMinute, Clock[i].wSecond, Clock[i].wMilliseconds );
		}
	}
	sec = Clock[1].wSecond - Clock[0].wSecond;
	mil = Clock[1].wMilliseconds - Clock[0].wMilliseconds;
	calc( &time, sec, mil );
	printf( "SCardConnect: %3.2f sec.\n", time );

	
	sec = Clock[2].wSecond - Clock[1].wSecond;
	mil = Clock[2].wMilliseconds - Clock[1].wMilliseconds;
	calc( &time, sec, mil );
	printf( "SCardTransmit: %3.2f sec.\n", time );
	
	if ( Clock[3].wSecond == 90 ){
		sec = Clock[4].wSecond - Clock[2].wSecond;
		mil = Clock[4].wMilliseconds - Clock[2].wMilliseconds;
		calc( &time, sec, mil );
		printf( "SCardDissconnect: %3.2f sec.\n", time );
	}
	else {
		sec = Clock[3].wSecond - Clock[2].wSecond;
		mil = Clock[3].wMilliseconds - Clock[2].wMilliseconds;
		calc( &time, sec, mil );
		printf( "SCardTransmit(Receive): %3.2f sec.\n", time );

		sec = Clock[4].wSecond - Clock[3].wSecond;
		mil = Clock[4].wMilliseconds - Clock[3].wMilliseconds;
		calc( &time, sec, mil );
		printf( "SCardDissconnect: %3.2f sec.\n", time );
	}
}

DWORD getReaderName()
{
	DWORD  dwReturn;
	LPTSTR pmszReaders = NULL;
	LPTSTR pReader;
	DWORD  cch = SCARD_AUTOALLOCATE;
	SCARDCONTEXT Context;

	SCardEstablishContext( SCARD_SCOPE_USER, NULL, NULL, &Context );
	dwReturn = SCardListReaders(Context, NULL, (LPTSTR)&pmszReaders, &cch );

	switch( dwReturn ) {
	
//	case SCARD_E_NO_READERS_AVAILABLE:
//		dwReturn = SCARD_E_NO_READERS_AVAILABLE;
//		break;

	case SCARD_S_SUCCESS:
		pReader = pmszReaders;

		if ( (lstrlen(pReader) != 0) && (lstrlen(pReader) <= MAX_PATH) ) {
			compareAcr( pReader );
		}
		
		while ( '\0' != *pReader ) {
			pReader = pReader + strlen(pReader) + 1;
			
			if ( (lstrlen(pReader) != 0) && (lstrlen(pReader) <= MAX_PATH) ) {
				compareAcr( pReader );
			}
		}

		dwReturn = SCardFreeMemory( Context, pmszReaders );
		break;
		
	default:
		dwReturn = 0; //SCARD_E_NO_READERS_AVAILABLE;
		break;
	}

	return dwReturn;
}

void compareAcr( const char* SourceReader )
{
	if ( lstrcmp( SourceReader, ACR122_READER_NAME1 ) == 0 ){
		lstrcpy( ReaderName, ACR122_READER_NAME1 );
	}
	if ( lstrcmp( SourceReader, ACR122_READER_NAME2 ) == 0 ){
		lstrcpy( ReaderName, ACR122_READER_NAME2 );
	}
	if ( lstrcmp( SourceReader, ACR122_READER_NAME3 ) == 0 ){
		lstrcpy( ReaderName, ACR122_READER_NAME3 );
	}
}
