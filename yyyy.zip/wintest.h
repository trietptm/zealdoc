#ifndef _WINTEST_H_
#define _WINTEST_H_

#include <windows.h>
#include <stdio.h>

#include <Winscard.h>

#endif /* _WINTEST_H_ */