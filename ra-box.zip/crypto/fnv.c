#include <fnv.h>

#define FNV_MAGIC_INIT (0x811c9dc5)
#define FNV_MAGIC_PRIME (0x01000193)

uint32_t fnv_32_init(const void *data, size_t size)
{
	const uint8_t *p = data;
	const uint8_t *q = p + size;
	uint32_t hash = FNV_MAGIC_INIT;

	/* FNV-1 hash each octet in the buffer
	 */
	while (p != q) {
		/* multiple by 32-bit magic FNV prime, mod 2^32 */
		hash *= FNV_MAGIC_PRIME;
#if 0
		/* potential optimization */
		hash += (hash<<1) + (hash<<4) + (hash<<7) + (hash<<8) + (hash<<24);
#endif
		/* XOR the 8-bit quantity into the bottom of
		 * the hash.
		 */
		hash ^= (uint32_t) (*p++);
    }

    return hash;
}

uint32_t fnv_32_buf(const void *data, size_t size, uint32_t hash)
{
	const uint8_t *p = data;
	const uint8_t *q = p + size;

	while (p != q) {
		hash *= FNV_MAGIC_PRIME;
		hash ^= (uint32_t) (*p++);
	}
	return hash;
}

/* Return a "folded" hash, where the lower "bits" are the
 * hash, and the upper bits are zero.
 *
 * If you need a non-power-of-two hash, cope.
 */
uint32_t fnv_32_fold(uint32_t hash, int bits)
{
	int count;
	uint32_t result;

	if ((bits <= 0) || (bits >= 32)) return hash;

	result = hash;

	/* never use the same bits twice in an xor */
	for (count = 0; count < 32; count += bits) {
		hash >>= bits;
		result ^= hash;
	}
	return result & (((uint32_t) (1 << bits)) - 1);
}

/* hash a C string, so we loop over it once */
uint32_t fnv_32_str(const char *p)
{
	uint32_t hash = FNV_MAGIC_INIT;
	while (*p) {
		hash *= FNV_MAGIC_PRIME;
		hash ^= (uint32_t) (*p++);
	}
	return hash;
}
