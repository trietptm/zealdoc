#include "scard_priv.h"

void ulong2bebytes(uint8_t *buf, uint32_t x)
{
    buf[3] = (uint8_t) (x & 0xff);
    buf[2] = (uint8_t) ((x >> 8) & 0xff);
    buf[1] = (uint8_t) ((x >> 16) & 0xff);
    buf[0] = (uint8_t) ((x >> 24) & 0xff);
}

void ushort2bebytes(uint8_t *buf, uint16_t x)
{
    buf[1] = (uint8_t) (x & 0xff);
    buf[0] = (uint8_t) ((x >> 8) & 0xff);
}

uint32_t bebytes2ulong(const uint8_t *buf)
{
	return (uint32_t)(buf[0] << 24 | buf[1] << 16
		| buf[2] << 8 | buf[3]);
}

/* FIXME: different from opensc */
uint16_t bebytes2ushort(const uint8_t *buf)
{
	return (uint16_t)(buf[0] << 16 | buf[1]);
}

/* If there is not sep, set in_sep = 0 */
int scard_bin_to_hex(const uint8_t *in, size_t in_len,
		     char *out, size_t out_len, uint8_t in_sep)
{
	size_t n, sep_len;
	uint8_t *pos, *end, sep;

	sep = in_sep;
	sep_len = sep > 0 ? 1 : 0;
	pos = out;
	end = out + out_len;

	for (n = 0; n < in_len; n++) {
		if (pos + 3 + sep_len >= end)
			return SCARD_ERR_INSUF_BUFFER;
		if (n && sep_len)
			*pos++ = sep;
		sprintf(pos, "%02x", in[n]);
		pos += 2;
	}
	*pos = '\0';

	return 0;
}

int scard_hex_to_bin(const char *in, uint8_t *out, size_t *outlen)
{
	int err = SCARD_SUCCESS;
	size_t left, count = 0;

	BUG_ON(!in || !out || !outlen);

	left = *outlen;

	while (*in != '\0') {
		uint8_t byte = 0, nybbles = 2;

		while (nybbles-- && *in && *in != ':') {
			char c;

			byte <<= 4;
			c = *in++;
			if ('0' <= c && c <= '9')
				c -= '0';
			else if ('a' <= c && c <= 'f')
				c = c - 'a' + 10;
			else if ('A' <= c && c <= 'F')
				c = c- 'A' + 10;
			else {
				err = SCARD_ERR_INVALID_ARGS;
				goto out;
			}
			byte |= c;
		}
		if (*in == ':')
			in++;
		if (left <= 0) {
			err = SCARD_ERR_INSUF_BUFFER;
			break;
		}
		out[count++] = byte;
		left--;
	}
out:
	*outlen = count;
	return err;
}

void scard_format_path(const char *str, struct scard_path *path)
{
	int type = SCARD_PATH_TYPE_PATH;

	memset(path, 0, sizeof(*path));
	path->len = sizeof(path->value);
	if (scard_hex_to_bin(str, path->value, &path->len) >= 0)
		path->type = type;
}

static int scard_concatenate_path(struct scard_path *d, 
				  const struct scard_path *p1, 
				  const struct scard_path *p2)
{
	struct scard_path tpath;

	if (!d || !p1 || !p2)
		return SCARD_ERR_INVALID_ARGS;
	if (p1->type == SCARD_PATH_TYPE_DF_NAME
		|| p2->type == SCARD_PATH_TYPE_DF_NAME)
		return SCARD_ERR_INVALID_ARGS;
	if (p1->len + p2->len > SCARD_PATH_MAX)
		return SCARD_ERR_INVALID_ARGS;
	
	memset(&tpath, 0, sizeof(struct scard_path));
	memcpy(tpath.value, p1->value, p1->len);
	memcpy(tpath.value + p1->len, p2->value, p2->len);
	tpath.len = p1->len + p2->len;
	tpath.type = SCARD_PATH_TYPE_PATH;

	*d = tpath;

	return SCARD_SUCCESS;
}

int scard_append_path(struct scard_path *dest, const struct scard_path *src)
{
	return scard_concatenate_path(dest, dest, src);
}

int scard_append_path_id(struct scard_path *dest, const uint8_t *id, size_t idlen)
{
	if (dest->len + idlen > SCARD_PATH_MAX)
		return SCARD_ERR_INVALID_ARGS;
	memcpy(dest->value + dest->len, id, idlen);
	dest->len += idlen;

	return SCARD_SUCCESS;
}

int scard_compare_path(const struct scard_path *path1, 
		       const struct scard_path *path2)
{
	return path1->len == path2->len
		&& !memcmp(path1->value, path2->value, path1->len);
}

int scard_compare_path_prefix(const struct scard_path *prefix, 
			      const struct scard_path *path)
{
	struct scard_path tpath;

	if (prefix->len > path->len)
		return 0;

	tpath     = *path;
	tpath.len = prefix->len;

	return scard_compare_path(&tpath, prefix);
}

const struct scard_path *scard_get_mf_path(void)
{
	static const struct scard_path mf_path = 
		{SCARD_PATH_TYPE_PATH, {0x3f, 0x00,}, 2, 0, 0, };
	return &mf_path;
}

int scard_make_absolute_path(const struct scard_path *parent, 
			     struct scard_path *child)
{
	/* a 0 length path stays a 0 length path */
	if (child->len == 0)
		return SCARD_SUCCESS;

	if (scard_compare_path_prefix(scard_get_mf_path(), child))
		return SCARD_SUCCESS;
	return scard_concatenate_path(child, parent, child);
}

int scard_append_file_id(struct scard_path *dest, uint16_t fid)
{
	uint8_t id[2] = {fid >> 8, fid & 0xff};

	return scard_append_path_id(dest, id, 2);
}

struct scard_file *scard_file_new(void)
{
	struct scard_file *filp;

	filp = calloc(1, sizeof(struct scard_file));
	if (!filp)
		return NULL;

	return filp;
}

void scard_file_free(struct scard_file *filp)
{
	int i;

	for (i = 0; i < SCARD_AC_OP_MAX; i++)
		scard_file_clear_acl_entries(filp, i);

	if (filp->sec_attr) free(filp->sec_attr);
	if (filp->prop_attr) free(filp->prop_attr);
	if (filp->type_attr) free(filp->type_attr);
	free(filp);
}

void scard_file_dup(struct scard_file **dest, 
		    const struct scard_file *src)
{
	struct scard_file *newf;
	const struct scard_acl_entry *e;
	unsigned int op;

	*dest = NULL;
	newf = scard_file_new();
	if (newf == NULL)
		return;
	*dest = newf;

	memcpy(&newf->path, &src->path, sizeof(struct scard_path));
	memcpy(&newf->df_name, &src->df_name, sizeof(src->df_name));
	newf->df_name_len = src->df_name_len;
	newf->type    = src->type;
	newf->shareable    = src->shareable;
	newf->ef_structure = src->ef_structure;
	newf->size    = src->size;
	newf->id      = src->id;
	newf->status  = src->status;
	for (op = 0; op < SCARD_AC_OP_MAX; op++) {
		newf->acl[op] = NULL;
		e = scard_file_get_acl_entry(src, op);
		if (e != NULL) {
			if (scard_file_add_acl_entry(newf, op, e->method, e->key_ref) < 0)
				goto err;
		}
	}
	newf->record_length = src->record_length;
	newf->record_count  = src->record_count;

	if (scard_file_set_sec_attr(newf, src->sec_attr, src->sec_attr_len) < 0)
		goto err;
	if (scard_file_set_sec_attr(newf, src->prop_attr, src->prop_attr_len) < 0)
		goto err;
	if (scard_file_set_sec_attr(newf, src->type_attr, src->type_attr_len) < 0)
		goto err;
	return;
err:
	if (newf != NULL)
		scard_file_free(newf);
	*dest = NULL;
}

int scard_file_set_prop_attr(struct scard_file *file, const uint8_t *prop_attr,
			     size_t prop_attr_len)
{
	uint8_t *tmp;

	if (prop_attr == NULL) {
		if (file->prop_attr != NULL)
			free(file->prop_attr);
		file->prop_attr = NULL;
		file->prop_attr_len = 0;

		return SCARD_SUCCESS;
	}
	tmp = (uint8_t *)realloc(file->prop_attr, prop_attr_len);
	if (!tmp) {
		if (file->prop_attr)
			free(file->prop_attr);
		file->prop_attr = NULL;
		file->prop_attr_len = 0;

		return SCARD_ERR_NO_MEM;
	}
	file->prop_attr = tmp;
	memcpy(file->prop_attr, prop_attr, prop_attr_len);
	file->prop_attr_len = prop_attr_len;

	return SCARD_SUCCESS;
}

int scard_file_set_sec_attr(struct scard_file *file, const uint8_t *sec_attr,
			    size_t sec_attr_len)
{
	uint8_t *tmp;

	if (sec_attr == NULL) {
		if (file->sec_attr != NULL)
			free(file->sec_attr);
		file->sec_attr = NULL;
		file->sec_attr_len = 0;

		return SCARD_SUCCESS;
	}
	tmp = (uint8_t *)realloc(file->sec_attr, sec_attr_len);
	if (!tmp) {
		if (file->sec_attr)
			free(file->sec_attr);
		file->sec_attr = NULL;
		file->sec_attr_len = 0;

		return SCARD_ERR_NO_MEM;
	}
	file->sec_attr = tmp;
	memcpy(file->sec_attr, sec_attr, sec_attr_len);
	file->sec_attr_len = sec_attr_len;

	return SCARD_SUCCESS;	
}

int scard_match_atr_table(const struct scard_atr_table *atr_table, 
			  const uint8_t *atr_bin,
			  size_t atr_bin_len)
{
	const uint8_t *tatr, *matr;
	size_t tatr_len;
	const uint8_t *card_atr_bin = atr_bin;
	size_t card_atr_bin_len = atr_bin_len;
	char card_atr_hex[3 * SCARD_ATR_MAX];
	size_t card_atr_hex_len;

	scard_bin_to_hex(card_atr_bin, card_atr_bin_len, card_atr_hex,
		sizeof(card_atr_hex), ':');
	card_atr_hex_len = strlen(card_atr_hex);

	tatr = atr_table->atr;
	matr = atr_table->atr_mask;
	tatr_len = strlen(tatr);
				
	if (tatr_len != card_atr_hex_len)
		return 0;
	if (matr == NULL) {
		if (strncasecmp(tatr, card_atr_hex, tatr_len) != 0)
			return 0;
	} else {
		uint8_t mbin[SCARD_ATR_MAX], tbin[SCARD_ATR_MAX];
		size_t mbin_len, tbin_len, s, matr_len;

		matr_len = strlen(matr);
		if (tatr_len != matr_len)
			return 0;
		tbin_len = sizeof(tbin);
		scard_hex_to_bin(tatr, tbin, &tbin_len);
		mbin_len = sizeof(mbin);
		scard_hex_to_bin(matr, mbin, &mbin_len);
		if (mbin_len != card_atr_bin_len)
			return 0;
		for (s = 0; s < tbin_len; s++) {
			tbin[s] = tbin[s] & mbin[s];
			mbin[s] = card_atr_bin[s] & mbin[s];
		}
		if (memcmp(tbin, mbin, tbin_len) != 0)
			return 0;
	}

	return 1;
}

int scard_file_clear_acl_entries(struct scard_file *filp, unsigned int op)
{
	struct scard_acl_entry *p1, *p2;

	BUG_ON(op >= SCARD_AC_OP_MAX);

	p1 = filp->acl[op];

	while (p1) {
		p2 = p1->next;
		free(p1);
		p1 = p2;
	}
	filp->acl[op] = NULL;

	return SCARD_SUCCESS;
}

int scard_file_add_acl_entry(struct scard_file *filp, unsigned int op, 
			     unsigned int method, unsigned int key_ref)
{
	struct scard_acl_entry *p, *new_acl;

	BUG_ON(op >= SCARD_AC_OP_MAX);

	switch (method) {
	case SCARD_AC_NONE:
	case SCARD_AC_NEVER:
	case SCARD_AC_UNKNOWN:
		scard_file_clear_acl_entries(filp, op);
		key_ref = SCARD_AC_KEY_REF_NONE;
		break;
	}

	for (p = filp->acl[op]; p != NULL; p = p->next) {
		if ((p->method == method) && (p->key_ref == key_ref))
			return 0;
	}
	
	new_acl = malloc(sizeof(struct scard_acl_entry));
	if (!new_acl)
		return SCARD_ERR_NO_MEM;
	new_acl->method = method;
	new_acl->key_ref = key_ref;
	new_acl->next = NULL;

	p = filp->acl[op];
	if (!p) {
		filp->acl[op] = new_acl;
	} else {
		while (p->next != NULL)
			p = p->next;
		p->next = new_acl;
	}

	return SCARD_SUCCESS;
}

const struct scard_acl_entry *scard_file_get_acl_entry(const struct scard_file *filp,
						  unsigned int op)
{
	BUG_ON(op >= SCARD_AC_OP_MAX);

	return filp->acl[op];
}
