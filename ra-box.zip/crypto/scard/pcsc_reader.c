#include "scard_priv.h"

static uint32_t scard2pcsc_protocol(uint32_t scard_proto)
{
	switch (scard_proto) {
	case SCARD_PROTOCOL_T0:
		return PCSC_PROTOCOL_T0;
	case SCARD_PROTOCOL_T1:
		return PCSC_PROTOCOL_T1;
	default:
		return PCSC_PROTOCOL_UNKNOWN;
	}
}

static uint32_t pcsc2scard_protocol(uint32_t pcsc_proto)
{
	switch (pcsc_proto) {
	case PCSC_PROTOCOL_T0:
		return SCARD_PROTOCOL_T0;
	case PCSC_PROTOCOL_T1:
		return SCARD_PROTOCOL_T1;
	default:
		return SCARD_PROTOCOL_RAW;
	}
}

int scard_reader_connect(int reader_idx, int slot_idx, 
			 struct scard_handle *card_handle)
{
#if 0	
	pcsc_ifd_hd_t *slot_handle;
	struct pcsc_slot *slot;
	slot_handle = pcsc_connect(reader_idx, slot_idx);
	if (!slot_handle)
		return SCARD_ERR_NO_READER;
	slot = &slot_handle->reader->slot[slot_handle->slot_idx];
	
	card_handle->reader_idx = reader_idx;
	card_handle->slot_idx = slot_idx;
	card_handle->slot_handle = slot_handle;
	
	memcpy(card_handle->atr, slot->atr, slot->atr_len);
	card_handle->atr_len = slot->atr_len;
	card_handle->max_send = SCARD_DEFAULT_SEND_MAX;
	card_handle->max_recv = SCARD_DEFAULT_RECV_MAX;
	card_handle->active_proto = pcsc2scard_protocol(slot->proto);
#endif
	return SCARD_SUCCESS;
}

int scard_reader_disconnect(struct scard_handle *card_handle)
{
	pcsc_disconnect(card_handle->slot_handle);

	return SCARD_SUCCESS;
}

int scard_reader_icc_status(int reader_idx, int slot_idx, int *icc_status)
{
	int pcsc_icc_status;
	int r;

	r = pcsc_card_status(reader_idx, slot_idx, &pcsc_icc_status);
	if (r != PCSC_S_SUCCESS) {
		return SCARD_ERR_NO_READER;
	}
	switch (pcsc_icc_status) {
	case PCSC_CARD_PRESENT_POWERUP:
		*icc_status = SCARD_ICC_PRESENT_POWERUP;
		break;
	case PCSC_CARD_PRESENT_POWERDOWN:
		*icc_status = SCARD_ICC_PRESENT_POWERDOWN;
		break;
	default:
		*icc_status = SCARD_ICC_ABSENT;
		break;
	}

	return SCARD_SUCCESS;
}

int scard_handle_check_valid(struct scard_handle *card_handle)
{
	if (!card_handle) return 0;

	return pcsc_check_handle_valid(card_handle->slot_handle);
}

static void scard_reader_trans_complete(struct pcsc_transmit_param *pcsc_param)
{
	struct scard_card_cmd_param *card_param = pcsc_param->user_data;
	uint8_t *rbuf;
	size_t rbuf_actual;
	int r;
	
	if (pcsc_param->ret != PCSC_S_SUCCESS) {
		card_param->ret = SCARD_ERR_COMMUNICATION;
	} else {
		card_param->ret = SCARD_SUCCESS;
		rbuf = pcsc_param->rbuf;
		rbuf_actual = pcsc_param->rbuf_actual;
		
		if (rbuf_actual < 2) {
			card_param->ret = SCARD_ERR_COMMUNICATION;
			goto ret;
		}

		card_param->apdu->sw1 = rbuf[rbuf_actual - 2];
		card_param->apdu->sw2 = rbuf[rbuf_actual - 1];
		rbuf_actual -= 2;
		if (card_param->apdu->sw1 == 0x90 
				&& card_param->apdu->sw2 == 0x00) {
			if (rbuf_actual > card_param->apdu->resplen)
				rbuf_actual = card_param->apdu->resplen;
			
			if (rbuf_actual != 0) {
				memcpy(card_param->apdu->resp, rbuf, 
					rbuf_actual);
				card_param->apdu->resp += rbuf_actual;
				card_param->apdu->resplen -= rbuf_actual;
			}
		} else if (card_param->apdu->sw1 == 0x6C 
				&& (card_param->apdu->flags & 
					SCARD_APDU_FLAG_NO_RETRY_WL) == 0) {
			uint8_t nlen = card_param->apdu->sw2 != 0 ? 
					card_param->apdu->sw2 : 256;
			
			if (nlen > card_param->apdu->resplen){
				card_param->ret = SCARD_ERR_INSUF_BUFFER;
				goto ret;
			}
			card_param->apdu->le = nlen;
			card_param->apdu->flags |= SCARD_APDU_FLAG_NO_GET_RESP;
			
			scard_reader_transmit(card_param);
			goto out;
		} else if (card_param->apdu->sw1 == 0x61) {
			uint8_t le = card_param->apdu->sw2 != 0 ? 
					card_param->apdu->sw2 : 256;

			if (card_param->apdu->resplen == 0) {
				card_param->apdu->sw1 = 0x90;
				card_param->apdu->sw2 = 0x00;
				goto ret;
			}

			if (rbuf_actual > card_param->apdu->resplen)
				rbuf_actual = card_param->apdu->resplen;
			
			if (rbuf_actual != 0) {
				memcpy(card_param->apdu->resp, rbuf, 
					rbuf_actual);
				card_param->apdu->resp += rbuf_actual;
				card_param->apdu->resplen -= rbuf_actual;
			}

			r = card_param->handle->card_driver->ops->get_response(
				card_param, card_param->apdu->resp,
				card_param->apdu->resplen, le);
			if (r != SCARD_SUCCESS) {
				card_param->ret = r;
				goto ret;
			}
			goto out;
		}
	}

ret:
	card_param->callback(card_param);
out:
	free(pcsc_param->rbuf);
	free(pcsc_param->sbuf);
	free(pcsc_param);
}

int scard_reader_transmit(struct scard_card_cmd_param *card_param)
{
	struct pcsc_transmit_param *pcsc_param;
	uint8_t *tpdu = NULL, *rbuf = NULL;
	size_t tpdu_len, rbuf_len;
	int r;

	if (!scard_handle_check_valid(card_param->handle))
		return SCARD_ERR_INVALID_HANDLE;

	scard_detect_apdu_cse(card_param->handle, card_param->apdu);
	r = scard_check_apdu(card_param->handle, card_param->apdu);
	if (r != SCARD_SUCCESS)
		return r;
	r = scard_apdu_get_octets(card_param->apdu, 
				  &tpdu, &tpdu_len, 
				  card_param->handle->active_proto);
	if (r != SCARD_SUCCESS)
		return r;
		
	pcsc_param = malloc(sizeof(struct pcsc_transmit_param));
	if (!pcsc_param) {
		free(tpdu);
		return SCARD_ERR_NO_MEM;
	}
	memset(pcsc_param, 0, sizeof(struct pcsc_transmit_param));

	/* we always use a at least 258 byte size big return buffer
	 * to mimic the behaviour of the old implementation (some readers
	 * seems to require a larger than necessary return buffer).
	 * The buffer for the returned data needs to be at least 2 bytes
	 * larger than the expected data length to store SW1 and SW2. */
	rbuf_len = card_param->apdu->resplen < 256 ? 258 : card_param->apdu->resplen + 2;
	
	rbuf = malloc(rbuf_len);
	if (!rbuf) {
		free(pcsc_param);
		free(tpdu);
		return SCARD_ERR_NO_MEM;
	}
	
	pcsc_param->handle = card_param->handle->slot_handle;
	pcsc_param->sbuf = tpdu;
	pcsc_param->sbuf_len = tpdu_len;
	pcsc_param->rbuf = rbuf;
	pcsc_param->rbuf_len = rbuf_len;
	pcsc_param->callback = scard_reader_trans_complete;
	pcsc_param->user_data = card_param;
	
	r = pcsc_transmit(pcsc_param);
	if (r != PCSC_S_SUCCESS) {
		free(rbuf);
		free(pcsc_param);
		free(tpdu);
		return SCARD_ERR_COMMUNICATION;
	}

	return SCARD_SUCCESS;
}

#define SCARD_CCID_PIN_TIME_OUT		30

#define SCARD_CCID_PIN_ENCODING_BIN	0x00
#define SCARD_CCID_PIN_ENCODING_BCD	0x01
#define SCARD_CCID_PIN_ENCODING_ASCII	0x10

#define SCARD_CCID_PIN_UNITS_BYTES	0x80

#define HOST_TO_CCID_16(x) (x)
#define HOST_TO_CCID_32(x) (x)

static int part10_build_verify_pin_block(uint8_t *rbuf, size_t *rbuf_len,
					 struct scard_pin_cmd_data *pin_cmd,
					 struct scard_apdu *apdu)
{
	struct pcsc_pin_verify *pin_verify = (struct pcsc_pin_verify *)rbuf;
	uint8_t tmp;
	uint16_t tmp16;
	int offset = 0;

	pin_verify->bTimerOut = SCARD_CCID_PIN_TIME_OUT;
	pin_verify->bTimerOut2 = SCARD_CCID_PIN_TIME_OUT;
	
	/* bmFormatString */
	tmp = 0x00;
	if (pin_cmd->pin1.encode_type == SCARD_PIN_ENCODING_ASCII) {
		tmp |= SCARD_CCID_PIN_ENCODING_ASCII;
		
		if (pin_cmd->pin1.len_offset > 4) {
			tmp |= SCARD_CCID_PIN_UNITS_BYTES;
			tmp |= (pin_cmd->pin1.len_offset - 5) << 3;
		}
	} else if (pin_cmd->pin1.encode_type == SCARD_PIN_ENCODING_BCD) {
		tmp |= SCARD_CCID_PIN_ENCODING_BCD;
		tmp |= SCARD_CCID_PIN_UNITS_BYTES;
	} else if (pin_cmd->pin1.encode_type == SCARD_PIN_ENCODING_GLP) {
		tmp |= SCARD_CCID_PIN_ENCODING_BCD;
		tmp |= 0x04 << 3;
	} else 
		return SCARD_ERR_NOT_SUPPORTED;
	pin_verify->bmFormatString = tmp;

	/* bmPinBlockString */
	tmp = 0x00;
	if (pin_cmd->pin1.encode_type == SCARD_PIN_ENCODING_GLP)
		tmp |= 0x04 | 0x08;
	else if (pin_cmd->pin1.encode_type == SCARD_PIN_ENCODING_ASCII && pin_cmd->pin1.pad_len)
		tmp |= pin_cmd->pin1.pad_len;
	pin_verify->bmPINBlockString = tmp;

	/* bmPinLengthFormat */
	tmp = 0x00;
	if (pin_cmd->pin1.encode_type == SCARD_PIN_ENCODING_GLP)
		tmp |= 0x04;
	pin_verify->bmPINLengthFormat = tmp;

	if (!pin_cmd->pin1.min_len || !pin_cmd->pin1.max_len)
		return SCARD_ERR_INVALID_ARGS;

	tmp16 = (pin_cmd->pin1.min_len << 8) + pin_cmd->pin1.max_len;
	pin_verify->wPINMaxExtraDigit = HOST_TO_CCID_16(tmp16);

	pin_verify->bEntryValidationCondition = 0x02; /* Keypress only */

	/* Ignore language and T = 1 parameters */
	pin_verify->bNumberMessage = 0x00;
	pin_verify->wLangId = HOST_TO_CCID_16(0x0000);
	pin_verify->bMsgIndex = 0x00;
	pin_verify->bTeoPrologue[0] = 0x00;
	pin_verify->bTeoPrologue[1] = 0x00;
	pin_verify->bTeoPrologue[2] = 0x00;

	/* APDU itself */
	offset = 0;
	pin_verify->abData[offset++] = apdu->cla;
	pin_verify->abData[offset++] = apdu->ins;
	pin_verify->abData[offset++] = apdu->p1;
	pin_verify->abData[offset++] = apdu->p2;
	if (pin_cmd->pin1.len_offset != 4) {
		pin_verify->abData[offset++] = (uint8_t)apdu->lc;
		memcpy(&pin_verify->abData[offset], apdu->data, apdu->datalen);
		offset += apdu->datalen;		
	}
	pin_verify->ulDataLength = HOST_TO_CCID_32(offset);

	*rbuf_len = sizeof(struct pcsc_pin_verify) + offset - 1;
	
	return SCARD_SUCCESS;
}

static int part10_build_modify_pin_block(uint8_t *rbuf, size_t *rbuf_len,
					 struct scard_pin_cmd_data *pin_cmd,
					 struct scard_apdu *apdu)
{
	struct pcsc_pin_modify *pin_modify = (struct pcsc_pin_modify *)rbuf;
	uint8_t tmp;
	uint16_t tmp16;
	int offset = 0;

	pin_modify->bTimerOut = SCARD_CCID_PIN_TIME_OUT;
	pin_modify->bTimerOut2 = SCARD_CCID_PIN_TIME_OUT;

	/* bmFormatString */
	tmp = 0x00;
	if (pin_cmd->pin1.encode_type == SCARD_PIN_ENCODING_ASCII) {
		tmp |= SCARD_CCID_PIN_ENCODING_ASCII;

		if (pin_cmd->pin1.len_offset > 4) {
			tmp |= SCARD_CCID_PIN_UNITS_BYTES;
			tmp |= (pin_cmd->pin1.len_offset - 5) << 3;
		}
	} else if (pin_cmd->pin1.encode_type == SCARD_PIN_ENCODING_BCD) {
		tmp |= SCARD_CCID_PIN_ENCODING_BCD;
		tmp |= SCARD_CCID_PIN_UNITS_BYTES;
	} else if (pin_cmd->pin1.encode_type == SCARD_PIN_ENCODING_GLP) {
		tmp |= SCARD_CCID_PIN_ENCODING_BCD;
		tmp |= 0x04 << 3;
	} else
		return SCARD_ERR_NOT_SUPPORTED;
	pin_modify->bmFormatString = tmp;

	/* bmPINBlockString */
	tmp = 0x00;
	if (pin_cmd->pin1.encode_type == SCARD_PIN_ENCODING_GLP) {
		tmp |= 0x40 | 0x08;
	} else if (pin_cmd->pin1.encode_type == SCARD_PIN_ENCODING_ASCII 
		&& pin_cmd->pin1.pad_len) {
		tmp |= pin_cmd->pin1.pad_len;
	}
	pin_modify->bmPINBlockString = tmp;

	tmp = 0x00;
	if (pin_cmd->pin1.encode_type == SCARD_PIN_ENCODING_GLP)
		tmp |= 0x04;
	pin_modify->bmPINLengthFormat = tmp;

	pin_modify->bInsertionOffsetOld = 0x00;
	pin_modify->bInsertionOffsetNew = 0x00;

	if (!pin_cmd->pin1.min_len || !pin_cmd->pin1.max_len)
		return SCARD_ERR_INVALID_ARGS;
	tmp16 = (pin_cmd->pin1.min_len << 8) + pin_cmd->pin1.max_len;
	pin_modify->wPINMaxExtraDigit = tmp16;

	pin_modify->bConfirmPIN = 0x03;
	pin_modify->bEntryValidationCondition = 0x02;

	/* Ignore languare and T= 1 parameters */
	pin_modify->bNumberMessage = 0x00;
	pin_modify->wLangId = HOST_TO_CCID_16(0x0000);
	pin_modify->bMsgIndex1 = 0x00;
	pin_modify->bMsgIndex2 = 0x00;
	pin_modify->bMsgIndex3 = 0x00;
	pin_modify->bTeoPrologue[0] = 0x00;
	pin_modify->bTeoPrologue[1] = 0x00;
	pin_modify->bTeoPrologue[2] = 0x00;

	/* APDU itself */
	pin_modify->abData[offset++] = apdu->cla;
	pin_modify->abData[offset++] = apdu->ins;
	pin_modify->abData[offset++] = apdu->p1;
	pin_modify->abData[offset++] = apdu->p2;

	if (pin_cmd->pin1.len_offset != 4) {
		pin_modify->abData[offset++] = (uint8_t)apdu->lc;
		memcpy(&pin_modify->abData[offset], apdu->data, apdu->datalen);
		offset += apdu->datalen;
	}
	pin_modify->ulDataLength = HOST_TO_CCID_32(offset);

	*rbuf_len = sizeof(struct pcsc_pin_modify) + offset - 1;

	return SCARD_SUCCESS;
}

static void scard_reader_pin_cmd_complete(struct pcsc_transmit_param *pcsc_param)
{
	struct scard_card_cmd_param *card_param = pcsc_param->user_data;
	uint8_t *rbuf;
	size_t rbuf_actual;

	if (pcsc_param->ret != PCSC_S_SUCCESS) {
		card_param->ret = SCARD_ERR_COMMUNICATION;
	} else {
		card_param->ret = SCARD_SUCCESS;
		rbuf = pcsc_param->rbuf;
		rbuf_actual = pcsc_param->rbuf_actual;
		
		if (rbuf_actual < 2) {
			card_param->ret = SCARD_ERR_COMMUNICATION;
			goto ret;
		}

		card_param->apdu->sw1 = rbuf[rbuf_actual - 2];
		card_param->apdu->sw2 = rbuf[rbuf_actual - 1];
		rbuf_actual -= 2;
		if (card_param->apdu->sw1 == 0x90 
				&& card_param->apdu->sw2 == 0x00) {
			if (rbuf_actual > card_param->apdu->resplen)
				rbuf_actual = card_param->apdu->resplen;
			
			if (rbuf_actual != 0) {
				memcpy(card_param->apdu->resp, rbuf, 
					rbuf_actual);
				card_param->apdu->resp += rbuf_actual;
				card_param->apdu->resplen -= rbuf_actual;
			}
		}
	}

ret:
	card_param->callback(card_param);
	free(pcsc_param->rbuf);
	free(pcsc_param);
}

static scard_reader_ccid_pin_cmd(struct scard_card_cmd_param *card_param, 
				 struct scard_pin_cmd_data *pin_cmd)
{
	struct scard_handle *card_handle = card_param->handle;
	struct scard_apdu *apdu = card_param->apdu;
	struct pcsc_reader *reader;
	struct pcsc_transmit_param *pcsc_param;
	uint8_t *rbuf = NULL, sbuf[SCARD_APDU_BUFFER_MAX];
	size_t rbuf_len, sbuf_len;
	uint32_t pin_ioctl;
	int r;
#if 0
	reader = &card_handle->slot_handle[card_handle->slot_idx].reader;
	switch(pin_cmd->cmd) {
	case SCARD_PIN_CMD_VERIFY:
		if (!(reader->path10.verify_ioctl ||
			(reader->path10.verify_ioctl_start 
			 && reader->path10.verify_ioctl_finish)))
			return SCARD_ERR_NOT_SUPPORTED;
		r = part10_build_verify_pin_block(sbuf, &sbuf_len, pin_cmd, apdu);
		if (r != SCARD_SUCCESS) return r;	

		break;
	case SCARD_PIN_CMD_CHANGE:
	case SCARD_PIN_CMD_UNBLOCK:
		if (!(reader->path10.modify_ioctl ||
			(reader->path10.modify_ioctl_start
			 && reader->path10.modify_ioctl_finish)))
			return SCARD_ERR_NOT_SUPPORTED;
		r = part10_build_modify_pin_block(sbuf, &sbuf_len, pin_cmd, apdu);
		if (r != SCARD_SUCCESS) return r;

		break;
	default:
		return SCARD_ERR_NOT_SUPPORTED;
	}
	
	pcsc_param = malloc(sizeof(struct pcsc_transmit_param));
	if (!pcsc_param) {
		return SCARD_ERR_NO_MEM;
	}
	memset(pcsc_param, 0, sizeof(struct pcsc_transmit_param));

	/* we always use a at least 258 byte size big return buffer
	 * to mimic the behaviour of the old implementation (some readers
	 * seems to require a larger than necessary return buffer).
	 * The buffer for the returned data needs to be at least 2 bytes
	 * larger than the expected data length to store SW1 and SW2. */
	rbuf_len = card_param->apdu->resplen < 256 ? 258 : card_param->apdu->resplen + 2;
	rbuf = malloc(rbuf_len);
	if (!rbuf) {
		free(pcsc_param);
		return SCARD_ERR_NO_MEM;
	}
	
	pcsc_param->handle = card_param->handle->slot_handle;
	pcsc_param->sbuf = sbuf;
	pcsc_param->sbuf_len = sbuf_len;
	pcsc_param->rbuf = rbuf;
	pcsc_param->rbuf_len = rbuf_len;
	pcsc_param->callback = scard_reader_pin_cmd_complete;
	pcsc_param->user_data = card_param;
	
	switch (pin_cmd->cmd) {
	case SCARD_PIN_CMD_VERIFY:
		if (reader->path10.verify_ioctl) 
			pin_ioctl = reader->path10.verify_ioctl;
		else if (reader->path10.verify_ioctl_start &&
				reader->path10.verify_ioctl_finish) {
			/* TODO: support verify_ioctl_start and verify_ioctl_finish*/
			free(rbuf);
			free(pcsc_param);
			return SCARD_ERR_NOT_SUPPORTED;
		}
		break;
	case SCARD_PIN_CMD_CHANGE:
	case SCARD_PIN_CMD_UNBLOCK:
		if (reader->path10.modify_ioctl) 
			pin_ioctl = reader->path10.verify_ioctl;
		else if (reader->path10.modify_ioctl_start &&
				reader->path10.modify_ioctl_finish) {
			/* TODO: support modify_ioctl_start and modify_ioctl_finish */
			free(rbuf);
			free(pcsc_param);
			return SCARD_ERR_NOT_SUPPORTED;
		}
		break;
	}
	pcsc_param->ioctl = pin_ioctl;
	r = pcsc_ifd_control(pcsc_param);
	if (r != PCSC_S_SUCCESS) {
		free(rbuf);
		free(pcsc_param);
		return SCARD_ERR_COMMUNICATION;
	}
#endif
	return SCARD_SUCCESS;		
}

static scard_reader_acr83_pin_cmd(struct scard_card_cmd_param *card_param, 
				  struct scard_pin_cmd_data *pin_cmd)
{
	
}

int scard_reader_pin_cmd(struct scard_card_cmd_param *card_param, 
			 struct scard_pin_cmd_data *pin_cmd)
{
	if (!scard_handle_check_valid(card_param->handle))
		return SCARD_ERR_INVALID_HANDLE;
	
	return scard_reader_ccid_pin_cmd(card_param, pin_cmd);
}