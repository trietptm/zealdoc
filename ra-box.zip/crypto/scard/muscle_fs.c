#include "scard_priv.h"
#include "muscle_fs.h"

#define MSCFS_CACHE_INCREMENT	128

static struct msc_id root_id = {{0x3F, 0x00, 0x3F, 0x00}};

struct mscfs *mscfs_new(void)
{
	struct mscfs *fs;

	fs = malloc(sizeof(struct mscfs));
	if (!fs) return NULL;
	memset(fs, 0, sizeof(struct mscfs));
	memcpy(fs->curr_path, "\x3F\x00", 2);

	list_init(&fs->file_cache_list);

	return fs;
}

void mscfs_free(struct mscfs *fs)
{
	mscfs_clear_cache(fs);
	free(fs);
}

void mscfs_clear_cache(struct mscfs *fs)
{
	struct mscfs_file *pos, *n;

	list_for_each_entry_safe(struct mscfs_file, pos, n,
		&fs->file_cache_list, link) {
		list_delete(&pos->link);
		free(pos);
	}
}

int mscfs_cache_push (struct mscfs *fs, const struct mscfs_file *filp)
{
	struct mscfs_file *new_entry;

	BUG_ON(!fs);

	new_entry = malloc(sizeof(struct mscfs_file));
	if (!new_entry)
		return SCARD_ERR_NO_MEM;
	*new_entry = *filp;
	
	list_insert_before(&new_entry->link, &fs->file_cache_list);

	return SCARD_SUCCESS;
}

void mscfs_cache_pop(struct mscfs_file *filp)
{
	if (!filp)
		return;
	list_delete(&filp->link);
	free(filp);
}

static const uint8_t *ignored_files[] = {
	(const uint8_t *) "l0\0\0",
	(const uint8_t *) "L0\0\0",
	NULL,
};

static int mscfs_is_ignored(struct mscfs *fs, struct msc_id obj_id)
{
	int ignored = 0;
	const uint8_t **ptr = ignored_files;

	while (ptr && *ptr && !ignored) {
		if (0 == memcmp(obj_id.id, *ptr, 4))
			ignored = 1;
		ptr++;
	}
	return ignored;
}

static void mscfs_select_app_complete(struct scard_card_cmd_param *card_param)
{
	struct scard_cmd_param *cmd_param = card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;

	if (card_param->ret != SCARD_SUCCESS) {
		cmd_param->ret = card_param->ret;
	} else {
		cmd_param->ret = scard_check_sw(card_param->handle,
						apdu->sw1, apdu->sw2);	
	}

	cmd_param->callback(cmd_param->user_data, cmd_param->ret);

	free(cmd_param);
	free(apdu);
	free(card_param);
}

int mscfs_select_applet(struct scard_handle *card_handle, 
		      uint8_t *applet_id, size_t applet_id_len,
		      scard_cmd_complete callback, void *user_data)
{
	struct scard_card_cmd_param *card_param;
	struct scard_cmd_param *cmd_param;
	struct scard_apdu *apdu;
	int r;

	cmd_param = malloc(sizeof(struct scard_cmd_param));
	if (!cmd_param)
		return SCARD_ERR_NO_MEM;
	memset(cmd_param, 0, sizeof(struct scard_cmd_param));
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;

	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = SCARD_APDU_CASE_3_SHORT;
	apdu->cla = 0x00;
	apdu->ins = 0xA4;
	apdu->p1 = 0x04;
	apdu->p2 = 0x00;
	apdu->lc = applet_id_len;
	apdu->data = applet_id;
	apdu->datalen = applet_id_len;

	card_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!card_param) {
		free(cmd_param);
		free(apdu);
		return SCARD_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct scard_card_cmd_param));
	card_param->handle = card_handle;
	card_param->apdu = apdu;
	card_param->cmd_param = cmd_param;
	card_param->callback = mscfs_select_app_complete;

	r = scard_reader_transmit(card_param);
	if (r != SCARD_SUCCESS) {
		free(cmd_param);
		free(apdu);
		free(card_param);
	}

	return r;
}

static void mscfs_list_objects_complete(struct scard_card_cmd_param *card_param)
{
	struct scard_cmd_param *cmd_param = 
			(struct scard_cmd_param *)card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;
	struct mscfs_file *filp = (struct mscfs_file *)cmd_param->priv_param;
	uint8_t *file_data = cmd_param->rbuf;
	size_t data_len;

	if (card_param->ret != SCARD_SUCCESS) {
		cmd_param->ret = card_param->ret;
	} else {
		/* No more data available */
		if (apdu->sw1 == 0x9C && apdu->sw2 == 0x12) {
			cmd_param->ret = SCARD_ERR_SEQUENCE_END;
			goto ret;
		}
		cmd_param->ret = scard_check_sw(card_param->handle, 
						apdu->sw1, apdu->sw2);
		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
			cmd_param->rbuf_actual = cmd_param->rbuf_len 
						- apdu->resplen;
			data_len = cmd_param->rbuf_actual;	
			if (data_len == 0) {
				cmd_param->ret = SCARD_ERR_SEQUENCE_END;
				goto ret;
			}

			if (data_len != 14) {
				cmd_param->ret = SCARD_ERR_UNKNOWN_RECEIVED;
				goto ret;
			}
			memcpy(filp->object_id.id, file_data, 4);
			filp->size = bebytes2ulong(file_data + 4);
			filp->read = bebytes2ushort(file_data + 8);
			filp->write = bebytes2ushort(file_data + 10);
			filp->del = bebytes2ushort(file_data + 12);
		}
	}

ret:
	cmd_param->callback(cmd_param->user_data, cmd_param->ret);

	free(file_data);
	free(cmd_param);
	free(apdu);
	free(card_param);
}

int mscfs_list_objects(struct scard_handle *card_handle,
		     uint8_t next, struct mscfs_file *filp,
		     scard_cmd_complete callback, void *user_data)
{
	struct scard_card_cmd_param *card_param;
	struct scard_cmd_param *cmd_param;
	struct scard_apdu *apdu;
	uint8_t *file_data;
	int r;
	
	file_data = malloc(14);
	if (!file_data)
		return SCARD_ERR_NO_MEM;

	cmd_param = malloc(sizeof(struct scard_cmd_param));
	if (!cmd_param) {
		free(file_data);
		return SCARD_ERR_NO_MEM;
	}
	memset(cmd_param, 0, sizeof(struct scard_cmd_param));
	cmd_param->priv_param = filp;
	cmd_param->rbuf = file_data;
	cmd_param->rbuf_len = 14;
	cmd_param->rbuf_actual = 0;
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;
	
	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(file_data);
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = SCARD_APDU_CASE_2;
	apdu->cla = card_handle->cla;
	apdu->ins = MSC_INS_LIST_OBJECTS;
	apdu->p1 = next;
	apdu->p2 = 0x00;
	apdu->le = 14;
	apdu->resp = cmd_param->rbuf;
	apdu->resplen = cmd_param->rbuf_len;

	card_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!card_param) {
		free(file_data);
		free(cmd_param);
		free(apdu);
		return SCARD_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct scard_card_cmd_param));
	card_param->handle = card_handle;
	card_param->cmd_param = cmd_param;
	card_param->apdu = apdu;
	card_param->callback = mscfs_list_objects_complete;

	r = scard_reader_transmit(card_param);
	if (r != SCARD_SUCCESS) {
		free(file_data);
		free(cmd_param);
		free(apdu);
		free(card_param);		
	}

	return r;
}

int mscfs_list_file(struct scard_handle *card_handle,
		    struct mscfs_file *filp, int reset,
		    scard_cmd_complete callback, void *user_data)
{
	uint8_t next = reset ? 0x00 : 0x01;

	return mscfs_list_objects(card_handle, next, filp, callback, user_data);
}

struct mscfs_update_param {
	struct mscfs *fs;
	struct mscfs_file *filp;
	scard_cmd_complete callback;
	void *user_data;
};

static void mscfs_update_cache_complete(void *user_data, int ret)
{
	struct mscfs_update_param *update_cache_param = 
				(struct mscfs_update_param *)user_data;
	struct mscfs *fs = update_cache_param->fs;
	struct mscfs_file *filp = update_cache_param->filp;
	struct scard_handle *card_handle = 
				(struct scard_handle *)fs->udata;
	int r;
	
	if (ret == SCARD_ERR_SEQUENCE_END) {/* No more data avaliable */
		r = SCARD_SUCCESS;
		goto out;
	} else if (ret < 0) {
		r = ret;
	} else {
		if (!mscfs_is_ignored(fs, filp->object_id)) {
			uint8_t *oid = filp->object_id.id;
			if (oid[2] == 0 && oid[3] == 0) {
				oid[2] = oid[0];
				oid[3] = oid[1];
				oid[0] = 0x3F;
				oid[1] = 0x00;
				filp->ef = 0;
			} else {
				filp->ef = 1;
			}
			mscfs_cache_push(fs, filp);
		}
		memset(filp, 0, sizeof(struct mscfs_file));
		r = mscfs_list_file(card_handle, filp, 0, 
			  mscfs_update_cache_complete, update_cache_param);
		if (r == SCARD_SUCCESS) return;
	}

out:
	update_cache_param->callback(update_cache_param->user_data, r);
	free(filp);
	free(update_cache_param);
}

int mscfs_update_cache(struct mscfs *fs, 
		       scard_cmd_complete callback, void *user_data)
{
	int r;
	struct mscfs_update_param *update_cache_param;
	struct mscfs_file *filp;
	struct scard_handle *card_handle = 
				(struct scard_handle *)fs->udata;

	filp = malloc(sizeof(struct mscfs_file));
	if (!filp)
		return SCARD_ERR_NO_MEM;
	memset(filp, 0, sizeof(struct mscfs_file));

	update_cache_param = malloc(sizeof(struct mscfs_update_param));
	if (!update_cache_param) {
		free(filp);
		return SCARD_ERR_NO_MEM;
	}
	memset(update_cache_param, 0, sizeof(struct mscfs_update_param));
	update_cache_param->fs = fs;
	update_cache_param->filp = filp;
	update_cache_param->callback = callback;
	update_cache_param->user_data = user_data;
	
	mscfs_clear_cache(fs);
	r = mscfs_list_file(card_handle, filp, 1, 
			    mscfs_update_cache_complete, update_cache_param);
	if (r != SCARD_SUCCESS) {
		free(filp);
		free(update_cache_param);
	}
	
	return r;
}

static int mscfs_lookup_path (struct mscfs *fs, const uint8_t *path, int pathlen,
		       struct msc_id *obj_id, int is_dir)
{
	uint8_t *oid = obj_id->id;

	if ((pathlen & 1) != 0)
		return SCARD_ERR_INVALID_ARGS;
	if (is_dir) {
		/* Directory must be right next to root */
		if ((0 == memcmp(path, "\x3F\x00", 2) && pathlen == 4)
			|| (0 == memcmp(fs->curr_path, "\x3F\x00", 2) && pathlen == 2)) {
			oid[0] = path[pathlen - 2];
			oid[1] = path[pathlen - 1];
			oid[2] = oid[3] = 0;
		} else {
			return SCARD_ERR_INVALID_ARGS;
		}
	}

	oid[0] = fs->curr_path[0];
	oid[1] = fs->curr_path[1];
	if (pathlen > 2 && memcmp(path, "\x3F\x00", 2) == 0) {
		path += 2;
		pathlen -= 2;
		oid[0] = 0x3F;
		oid[1] = 0x00;
	}
	/* Limit to a signal directory */
	if (pathlen > 4)
		return SCARD_ERR_INVALID_ARGS;

	/* Reset to root */
	if (0 == memcmp(path, "\x3F\x00", 2) && pathlen == 2) {
		oid[0] = oid[2] = path[0];
		oid[1] = oid[3] = path[1];
	} else if (pathlen == 2) { /* Path preserved for current-path */
		oid[2] = path[0];
		oid[3] = path[1];
	} else if (pathlen == 4) {
		oid[0] = path[0];
		oid[1] = path[1];
		oid[2] = path[2];
		oid[3] = path[3];
	}

	return SCARD_SUCCESS;
}

int mscfs_load_fileinfo(struct mscfs *fs, const uint8_t *path, int pathlen,
			struct mscfs_file **file_data)
{
	struct mscfs_file *pos;
	struct msc_id fullpath;

	BUG_ON(!fs || !path || !file_data);

	mscfs_lookup_path(fs, path, pathlen, &fullpath, 0);

	if (list_empty(&fs->file_cache_list))
		return SCARD_ERR_CACHE_EMPTY;

	*file_data = NULL;
	list_for_each_entry(struct mscfs_file, pos, 
		&fs->file_cache_list, link) {
		struct msc_id obj_id;

		obj_id = pos->object_id;
		if (0 == memcmp(obj_id.id, fullpath.id, 4)) {
			*file_data = pos;
			break;
		}
	}

	if (*file_data == NULL && 
		((0 == memcmp("\x3F\x00\x00\x00", fullpath.id, 4)) 
		|| (0 == memcmp("\x3F\x00\x3F\x00", fullpath.id, 4)))) {
		static struct mscfs_file ROOT_FILE;

		ROOT_FILE.ef = 0;
		ROOT_FILE.size = 0;
		/* Faked Root ID */
		ROOT_FILE.object_id = root_id;

		ROOT_FILE.read = 0;
		ROOT_FILE.write = 0x02; /* User pin access */
		ROOT_FILE.del = 0x02;

		*file_data = &ROOT_FILE;
	} else if (*file_data == NULL) {
		return SCARD_ERR_FILE_NOT_FOUND;
	}

	return SCARD_SUCCESS;
}

/* -1 any, 0 DF, 1 EF */
int mscfs_check_selection(struct mscfs *fs, int required_item)
{
	if (fs->curr_path[0] == 0 && fs->curr_path[1] == 0)
		return SCARD_ERR_INVALID_ARGS;
	if (required_item == 1 &&
		fs->curr_file[0] == 0 && fs->curr_file[1] == 0)
		return SCARD_ERR_INVALID_ARGS;
	return 0;
}

/* Construct object id */
int mscfs_lookup_local(struct mscfs *fs, const int id, struct msc_id *obj_id)
{
	uint8_t *oid = obj_id->id;

	oid[0] = fs->curr_path[0];
	oid[1] = fs->curr_path[1];
	oid[2] = (id >> 8) & 0xFF;
	oid[3] = (id & 0xFF);

	return 0;
}

uint16_t muscle_parse_single_acl(const struct scard_acl_entry *acl)
{
	uint16_t acl_entry = 0;

	while (acl) {
		int key = acl->key_ref;
		int method = acl->method;

		switch(method) {
		case SCARD_AC_NEVER:
			/* Ignore... other items overwrite these */
			return MSC_ACL_NEVER;
		case SCARD_AC_NONE:
		case SCARD_AC_UNKNOWN:
			break;
		case SCARD_AC_CHV:
			acl_entry |= (1 << key); /* assuming key 0 == SO */
			break;
		case SCARD_AC_AUT:
		case SCARD_AC_TERM:
		case SCARD_AC_PRO:
		default:
			/* Ignored. */
			break;
		}
		acl = acl->next;
	}

	return acl_entry;
}

void muscle_parse_acls(const struct scard_file *filp, 
			      uint16_t *read_perm, uint16_t *write_perm, 
			      uint16_t *delete_perm)
{
	*read_perm = muscle_parse_single_acl(scard_file_get_acl_entry(filp, SCARD_AC_OP_READ));
	*write_perm = muscle_parse_single_acl(scard_file_get_acl_entry(filp, SCARD_AC_OP_UPDATE));
	*delete_perm = muscle_parse_single_acl(scard_file_get_acl_entry(filp, SCARD_AC_OP_DELETE));
}
