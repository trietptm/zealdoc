#include "scard_priv.h"
#include "muscle_fs.h"

#define SCARD_MUSCLE_DRIVER_NAME	"MUSCLE"
static uint8_t applet_id[] = { 0xA0, 0x00,0x00,0x00, 0x01, 0x01 };

#if 0
static struct msc_id output_id = {{0xFF, 0xFF, 0xFF, 0xFE}};	/*Import large data to card */
#endif
static struct msc_id input_id = {{0xFF, 0xFF, 0xFF, 0xFF}};	/* Export large data from card */

struct muscle_private {
	unsigned short verifiedpins;
	struct mscfs *fs;
	int rsa_key_ref;
};

#define MSC_PRIV(card_handle)	\
	(struct muscle_private *)card_handle->card_driver->priv_data
#define MSC_RECV_MAX(card_handle) \
	(card_handle->max_recv > 255) ? 255 : card_handle->max_recv
#define MSC_SEND_MAX(card_handle) \
	(card_handle->max_send > 255) ? 255 : card_handle->max_send

static struct scard_card_operations msc_ops;

static int msc_init(struct scard_handle *card_handle)
{
	struct muscle_private *priv;

	priv = malloc(sizeof(struct muscle_private));
	if (!priv)
		return SCARD_ERR_NO_MEM;
	memset(priv, 0, sizeof(struct muscle_private));
	priv->verifiedpins = 0;
	priv->fs = mscfs_new();
	if (!priv->fs) {
		free(priv);
		return SCARD_ERR_NO_MEM;
	}
	priv->fs->udata = card_handle;
	
	card_handle->cla = 0xB0;

	card_handle->card_driver->priv_data = priv;

	return SCARD_SUCCESS;
}

static int msc_exit(struct scard_handle *card_handle)
{
	struct muscle_private *priv = MSC_PRIV(card_handle);

	mscfs_free(priv->fs);
	return 0;
}

static int msc_match(struct scard_handle *card_handle,
			scard_cmd_complete callback, void *user_data)
{
	return mscfs_select_applet(card_handle, applet_id, sizeof(applet_id),
				    callback, user_data);
}

static const struct scard_card_error msc_errors[] = {
	{ 0x9000, SCARD_SUCCESS,		"Success"},
	{ 0x9C01, SCARD_ERR_MEMORY_FAILURE,	"Insufficient memory" },
	{ 0x9C02, SCARD_ERR_AUTH_FAILED,	"Unsuccessful authentication"},
	{ 0x9C03, SCARD_ERR_NOT_ALLOWED,	"Operation not allowed"},
	{ 0x9C05, SCARD_ERR_NO_CARD_SUPPORT,	"Not supported"},
	{ 0x9C06, SCARD_ERR_UNAUTHORIZED,	"Security status not satisfied"},
	{ 0x9C07, SCARD_ERR_FILE_NOT_FOUND,	"Object not found"},
	{ 0x9C08, SCARD_ERR_FILE_EXISTS,	"Object already exists"},
	{ 0x9C09, SCARD_ERR_INVALID_ALG,	"Invalid algorithm"},
	{ 0x9C0B, SCARD_ERR_INVALID_SIG,	"Invalid signature"},
	{ 0x9C0C, SCARD_ERR_AUTH_BLOCKED,	"Specified identity blocked"},
	{ 0x9C0D, SCARD_ERR_UNSPECIFIED,	"no futher error info"},
	{ 0x9C0E, SCARD_ERR_INCORRECT_PARAM,	"Invalid Parameters"},
	{ 0x9C10, SCARD_ERR_INCORRECT_PARAM,	"Incorrect P1"},
	{ 0x9C11, SCARD_ERR_INCORRECT_PARAM,	"Incorrect P2"},
	{ 0x9C12, SCARD_ERR_INCORRECT_PARAM,	"Incorrect Le"},
	{ 0x6300, SCARD_ERR_AUTH_FAILED,	"Unsuccessful auth(for ISO PIN Verify)"},
	{ 0x6983, SCARD_ERR_AUTH_BLOCKED,	"PIN verify blocked"},
	{ 0x6A83, SCARD_ERR_INCORRECT_PARAM,	"Incorrect P1P2"},
	{ 0x6D00, SCARD_ERR_INS_NOT_SUPPORTED,	"Incorrect INS"},
};

static int msc_check_sw(struct scard_handle *handle, uint8_t sw1, uint8_t sw2)
{
	const int err_count = sizeof(msc_errors)/sizeof(msc_errors[0]);
	int i;

	for (i = 0; i < err_count; i++) {
		if (msc_errors[i].SWs == ((sw1 << 8) | sw2))
			return msc_errors[i].errorno;
	}
	return SCARD_ERR_UNSPECIFIED;
}

static void muscle_load_signal_acl(struct scard_file *filp, int op, uint16_t acl)
{
	int key_ref;

	if (acl == MSC_ACL_NEVER) {
		scard_file_add_acl_entry(filp, op, SCARD_AC_NEVER, 
					 SCARD_AC_KEY_REF_NONE);
		return;
	}

	for (key_ref = 0; key_ref < 16; key_ref++) {
		if (acl >> key_ref & 1) {
			scard_file_add_acl_entry(filp, op, SCARD_AC_CHV, key_ref);
		}
	}
}

static void muscle_load_file_acls(struct scard_file *filp,
				  struct mscfs_file *file_data)
{
	muscle_load_signal_acl(filp, SCARD_AC_OP_READ, file_data->read);
	muscle_load_signal_acl(filp, SCARD_AC_OP_WRITE, file_data->write);
	muscle_load_signal_acl(filp, SCARD_AC_OP_UPDATE, file_data->write);
	muscle_load_signal_acl(filp, SCARD_AC_OP_DELETE, file_data->del);
}

static void muscle_load_dir_acls(struct scard_file *filp,
				 struct mscfs_file *file_data)
{
	muscle_load_signal_acl(filp, SCARD_AC_OP_SELECT, MSC_ACL_NONE);
	muscle_load_signal_acl(filp, SCARD_AC_OP_LIST_FILES, MSC_ACL_NONE);
	muscle_load_signal_acl(filp, SCARD_AC_OP_LOCK, MSC_ACL_NEVER);
	muscle_load_signal_acl(filp, SCARD_AC_OP_DELETE, file_data->del);
	muscle_load_signal_acl(filp, SCARD_AC_OP_CREATE, file_data->write);
}

static void select_item_complete(void *user_data, int ret)
{
	struct scard_card_cmd_param *card_param = 
			(struct scard_card_cmd_param *)user_data;
	struct scard_cmd_param *cmd_param = card_param->cmd_param;
	struct scard_path *in_path = cmd_param->path;
	struct muscle_private *priv = MSC_PRIV(card_param->handle);
	struct mscfs *fs = priv->fs;
	int r = ret;
	
	if (ret == SCARD_SUCCESS) {
		struct mscfs_file *file_data = NULL;
		uint8_t *oid;

		r = mscfs_load_fileinfo(fs, in_path->value,
				in_path->len, &file_data);
		if (r < 0) goto out;

		oid = file_data->object_id.id;

		if (file_data->ef) {
			fs->curr_path[0] = oid[0];
			fs->curr_path[1] = oid[1];
			fs->curr_file[0] = oid[2];
			fs->curr_file[1] = oid[3];
		} else {
			fs->curr_path[0] = oid[in_path->len - 2];
			fs->curr_path[1] = oid[in_path->len - 1];
			fs->curr_file[0] = 0;
			fs->curr_file[1] = 0;
		}
		
		fs->curr_filp = file_data;
		if (cmd_param->file_out) {
			struct scard_file *filp;
			filp = scard_file_new();
			if (!filp) {
				r = SCARD_ERR_NO_MEM;
				goto out;
			}
			memset(filp, 0, sizeof(struct scard_file));
			filp->path = *in_path;
			filp->size = file_data->size;
			filp->id = (oid[2] << 8) | oid[3];
			memcpy(filp->df_name, in_path->value, in_path->len);
			filp->df_name_len = in_path->len;
			if (!file_data->ef) {
				filp->type = SCARD_FILE_TYPE_DF;
			} else {
				filp->type = SCARD_FILE_TYPE_WORKING_EF;
				filp->ef_structure = SCARD_FILE_EF_TRANSPARENT;
			}
			/* Setup ACLs */
			if (file_data->ef) {
				muscle_load_file_acls(filp, file_data);
			} else {
				muscle_load_dir_acls(filp, file_data);
			}
			*cmd_param->file_out = filp;
		}
	} else {
		r = ret;
	}
out:
	cmd_param->callback(cmd_param->user_data, r);
	free(in_path);
	free(cmd_param);
}

/* Before select_item you should check cache. If the cache is null, you should
 * first update the cache. */
static int select_item(struct scard_handle *card_handle, 
		       int req_type,
		       struct scard_path *in_path,
		       struct scard_file **file_out, 
		       scard_cmd_complete callback, void *user_data)
{
	struct muscle_private *priv = MSC_PRIV(card_handle);
	struct mscfs *fs = priv->fs;
	struct scard_cmd_param *select_param;
	struct scard_card_cmd_param *card_param;
	int r;

	select_param = malloc(sizeof(struct scard_cmd_param));
	if (!select_param)
		return SCARD_ERR_NO_MEM;
	memset(select_param, 0, sizeof(struct scard_cmd_param));
	select_param->path = malloc(sizeof(struct scard_path));
	if (!select_param->path) {
		free(select_param);
		return SCARD_ERR_NO_MEM;
	}
	*select_param->path = *in_path;
	select_param->file_out = file_out;
	select_param->callback = callback;
	select_param->user_data = user_data;

	card_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!card_param) {
		free(select_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct scard_card_cmd_param));
	card_param->handle = card_handle;
	card_param->cmd_param = select_param;

	if (list_empty(&fs->file_cache_list)) {
		r = mscfs_update_cache(fs, select_item_complete, card_param);
		if (r != SCARD_SUCCESS)
			free(select_param);
		return r;
	} else {
		select_item_complete(card_param, SCARD_SUCCESS);
		return SCARD_SUCCESS;
	}
}

static int msc_select_file(struct scard_handle *card_handle, 
			      struct scard_path *in_path,
			      struct scard_file **file_out, 
			      scard_cmd_complete callback, void *user_data)
{
	int req_type;

	switch (in_path->type) {
	case SCARD_PATH_TYPE_FILE_ID:
		req_type = 1;
		break;
	case SCARD_PATH_TYPE_DF_NAME:
		req_type = 0;
		break;
	case SCARD_PATH_TYPE_PATH:
		req_type = -1;
		break;
	default:
		return SCARD_ERR_INVALID_ARGS;
	}

	return select_item(card_handle, req_type, in_path, file_out, 
			   callback, user_data);	
}

struct msc_object_priv {
	struct msc_id obj_id;
	uint32_t offset;
	size_t obj_size;
};

static void msc_read_object_complete(struct scard_card_cmd_param *card_param)
{
	struct scard_handle *card_handle = card_param->handle;
	struct scard_cmd_param *cmd_param = card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;
	struct msc_object_priv *read_priv = 
			(struct msc_object_priv *)cmd_param->priv_param;
	uint32_t transmitted;
	uint8_t buffer[9];
	uint8_t le;
	int r;

	if (card_param->ret != SCARD_SUCCESS) {
		cmd_param->ret = card_param->ret;
	} else {
		cmd_param->ret = scard_check_sw(card_handle, 
					apdu->sw1, apdu->sw2);
		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
			transmitted = cmd_param->rbuf_len - cmd_param->rbuf_actual - 
					apdu->resplen;
			cmd_param->rbuf_actual += transmitted;
			
			if (cmd_param->rbuf_actual == cmd_param->rbuf_len) {
				cmd_param->ret = cmd_param->rbuf_actual;
				goto ret;
			} else {
				memset(apdu, 0, sizeof(struct scard_apdu));
				apdu->cse = SCARD_APDU_CASE_4_SHORT;
				apdu->cla = card_handle->cla;
				apdu->ins = 0x56;
				apdu->p1 = 0x00;
				apdu->p2 = 0x00;
				apdu->lc = 9;

				memcpy(buffer, read_priv->obj_id.id, 4);

				read_priv->offset += transmitted;
				ulong2bebytes(buffer + 4, read_priv->offset);

				le = (uint8_t) MIN(MSC_RECV_MAX(card_handle), 
						cmd_param->rbuf_len - cmd_param->rbuf_actual);
				buffer[8] = le;
				
				apdu->data = buffer;
				apdu->datalen = 9;
				apdu->le = le;
				apdu->resp = cmd_param->rbuf + cmd_param->rbuf_actual;
				apdu->resplen = cmd_param->rbuf_len - cmd_param->rbuf_actual;

				r = scard_reader_transmit(card_param);
				if (r == SCARD_SUCCESS) 
					return;
				else 
					cmd_param->ret = r;
			}
		} else if (apdu->sw1 == 0x9C) {
			if (apdu->sw2 == 0x07)
				cmd_param->ret = SCARD_ERR_FILE_NOT_FOUND;
			else if (apdu->sw2 == 0x06) 
				cmd_param->ret = SCARD_ERR_NOT_ALLOWED;
			else if (apdu->sw2 == 0x0F)
				cmd_param->ret = SCARD_ERR_INVALID_ARGS;
		}
	}

ret:
	cmd_param->callback(cmd_param->user_data, cmd_param->ret);

	free(apdu);
	free(read_priv);
	free(cmd_param);
	free(card_param);	
}

static int msc_read_object(struct scard_handle *card_handle, 
			   struct msc_id obj_id, uint32_t offset, 
			   uint8_t *rbuf, size_t rbuf_len, 
			   scard_cmd_complete callback, void *user_data)
{
	struct scard_card_cmd_param *card_param;
	struct scard_cmd_param *cmd_param;
	struct scard_apdu *apdu;
	struct msc_object_priv *read_priv;
	uint8_t buffer[9];
	uint8_t le;
	int r;

	cmd_param = malloc(sizeof(struct scard_cmd_param));
	if (!cmd_param) 
		return SCARD_ERR_NO_MEM;
	memset(cmd_param, 0, sizeof(struct scard_cmd_param));
	
	read_priv = malloc(sizeof(struct msc_object_priv));
	if (!read_priv) {
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(read_priv, 0, sizeof(struct msc_object_priv));
	read_priv->obj_id = obj_id;
	read_priv->offset = offset;

	cmd_param->priv_param = read_priv;
	cmd_param->rbuf = rbuf;
	cmd_param->rbuf_len = rbuf_len;
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;
	
	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(read_priv);
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = SCARD_APDU_CASE_4_SHORT;
	apdu->cla = card_handle->cla;
	apdu->ins = 0x56;
	apdu->p1 = 0x00;
	apdu->p2 = 0x00;
	apdu->lc = 9;

	memcpy(buffer, obj_id.id, 4);
	ulong2bebytes(buffer + 4, offset);

	le = (uint8_t) MIN(MSC_RECV_MAX(card_handle),  rbuf_len);
	buffer[8] = le;
	
	apdu->data = buffer;
	apdu->datalen = 9;
	apdu->le = le;
	apdu->resp = cmd_param->rbuf;
	apdu->resplen = cmd_param->rbuf_len;

	card_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!card_param) {
		free(apdu);
		free(read_priv);
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct scard_card_cmd_param));
	card_param->handle = card_handle;
	card_param->cmd_param = cmd_param;
	card_param->apdu = apdu;
	card_param->callback = msc_read_object_complete;
	
	r = scard_reader_transmit(card_param);
	if (r != SCARD_SUCCESS) {
		free(apdu);
		free(read_priv);
		free(cmd_param);
		free(card_param);	
	}

	return r;
}

static int msc_read_binary(struct scard_handle *card_handle, uint32_t offset,
			   uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
			   scard_cmd_complete callback, void *user_data)
{
	struct muscle_private *priv = MSC_PRIV(card_handle);
	struct mscfs *fs = priv->fs;
	struct msc_id obj_id;
	uint8_t *oid = obj_id.id;
	struct mscfs_file *filp;
	int r;

	r = mscfs_check_selection(fs, -1);
	if (r < 0) return r;
	filp = fs->curr_filp;
	obj_id = filp->object_id;
	if (!filp->ef) {
		oid[0] = oid[2];
		oid[1] = oid[3];
		oid[2] = oid[3] = 0;
	}

	return msc_read_object(card_handle, obj_id, offset, rbuf, rbuf_len,
			       callback, user_data);	
}

static void msc_update_object_complete(struct scard_card_cmd_param *card_param)
{
	struct scard_handle *card_handle = card_param->handle;
	struct scard_cmd_param *cmd_param = card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;
	struct msc_object_priv *update_priv = 
			(struct msc_object_priv *)cmd_param->priv_param;
	uint8_t buffer[SCARD_APDU_BUFFER_MAX];
	uint8_t data_max = (uint8_t)MSC_SEND_MAX(card_handle) - 9;
	size_t data_transmitted, data_left;
	
	int r;

	if (card_param->ret != SCARD_SUCCESS) {
		cmd_param->ret = card_param->ret;
	} else {
		cmd_param->ret = scard_check_sw(card_handle, apdu->sw1,
						apdu->sw2);
		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
			data_transmitted = apdu->lc - 9;
			cmd_param->sbuf_transmitted += data_transmitted;

			if (cmd_param->sbuf_transmitted == cmd_param->sbuf_len) {
				cmd_param->ret = cmd_param->sbuf_len;
				goto ret;
			}
			data_left = cmd_param->sbuf_len - cmd_param->sbuf_transmitted;
			data_max = MIN(data_max, data_left);
			update_priv->offset += data_transmitted;

			memset(apdu, 0, sizeof(struct scard_apdu));
			apdu->cse = SCARD_APDU_CASE_3_SHORT;
			apdu->cla = card_handle->cla;
			apdu->ins = 0x54;
			apdu->p1 = 0x00;
			apdu->p2 = 0x00;

			apdu->lc = data_max + 9;
			
			memcpy(buffer, update_priv->obj_id.id, 4);
			ulong2bebytes(buffer + 4, update_priv->offset);
			buffer[8] = data_max;
			memcpy(buffer + 9, 
				cmd_param->sbuf + cmd_param->sbuf_transmitted,
				data_max);
			
			apdu->data = buffer;
			apdu->datalen = data_left;

			r = scard_reader_transmit(card_param);
			if (r == SCARD_SUCCESS)
				return;
			else 
				cmd_param->ret = r;
		} else if (apdu->sw1 == 0x9C) {
			if (apdu->sw2 == 0x07)
				cmd_param->ret = SCARD_ERR_FILE_NOT_FOUND;
			else if (apdu->sw2 == 0x06)
				cmd_param->ret = SCARD_ERR_NOT_ALLOWED;
			else if (apdu->sw2 == 0x0F) 
				cmd_param->ret = SCARD_ERR_INVALID_ARGS;
		}
	}

ret:
	cmd_param->callback(cmd_param->user_data, cmd_param->ret);
	free(apdu);
	free(update_priv);
	free(cmd_param);
	free(card_param);
}

static int msc_update_object(struct scard_handle *card_handle, 
			 struct msc_id obj_id, uint32_t offset,
			 const uint8_t *sbuf, size_t sbuf_len,
			 scard_cmd_complete callback, void *user_data)
{
	struct scard_card_cmd_param *card_param;
	struct scard_cmd_param *cmd_param;
	struct scard_apdu *apdu;
	struct msc_object_priv *update_priv;
	uint8_t buffer[SCARD_APDU_BUFFER_MAX];
	uint8_t data_max = (uint8_t)MSC_SEND_MAX(card_handle) - 9;
	int r;

	cmd_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!cmd_param) 
		return SCARD_ERR_NO_MEM;
	memset(cmd_param, 0, sizeof(struct scard_card_cmd_param));

	update_priv = malloc(sizeof(struct msc_object_priv));
	if (!update_priv) {
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	update_priv->obj_id = obj_id;
	update_priv->offset = offset;

	cmd_param->priv_param = update_priv;
	cmd_param->sbuf = sbuf;
	cmd_param->sbuf_len = sbuf_len;
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;

	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(update_priv);
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = SCARD_APDU_CASE_3_SHORT;
	apdu->cla = card_handle->cla;
	apdu->ins = 0x54;
	apdu->p1 = 0x00;
	apdu->p2 = 0x00;

	data_max = (uint8_t)MIN(data_max, sbuf_len);

	apdu->lc = data_max + 9;

	
	memcpy(buffer, obj_id.id, 4);
	ulong2bebytes(buffer + 4, offset);
	buffer[8] = data_max;
	memcpy(buffer + 9, sbuf, data_max);

	apdu->data = buffer;
	apdu->datalen = sbuf_len; /* Data left*/

	card_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!card_param) {
		free(apdu);
		free(update_priv);
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct scard_card_cmd_param));
	card_param->handle = card_handle;
	card_param->cmd_param = cmd_param;
	card_param->apdu = apdu;
	card_param->callback = msc_update_object_complete;

	r = scard_reader_transmit(card_param);
	if (r != SCARD_SUCCESS) {
		free(apdu);
		free(update_priv);
		free(cmd_param);
		free(card_param);
	}

	return r;
}

static int msc_update_binary(struct scard_handle *card_handle, uint32_t offset,
			     const uint8_t *sbuf, size_t sbuf_len,
			     uint32_t flags, scard_cmd_complete callback, 
			     void *user_data)
{
	struct muscle_private *msc_priv = MSC_PRIV(card_handle);
	struct mscfs *fs = msc_priv->fs;
	struct msc_id obj_id;
	uint8_t *oid = obj_id.id;
	struct mscfs_file *filp;
	int r;

	r = mscfs_check_selection(fs, -1);
	if (r < 0) return r;

	filp = fs->curr_filp;
	obj_id = filp->object_id;

	if (!filp->ef) {
		oid[0] = oid[2];
		oid[1] = oid[3];
		oid[2] = oid[3] = 0;
	}
	/* XXX: We not support the size is more than file size,
	 *	while OpenSC supported.(first delte and create, write) */
	if (filp->size < offset + sbuf_len)
		return SCARD_ERR_INVALID_ARGS;
	return msc_update_object(card_handle, obj_id, offset, sbuf, sbuf_len,
				 callback, user_data);
}

static void msc_zero_object_complete(void *user_data, int ret)
{
	struct scard_cmd_param *cmd_param = 
			(struct scard_cmd_param *)user_data;
	
	cmd_param->callback(cmd_param->user_data, ret);

	free((uint8_t *)cmd_param->sbuf);
	free(cmd_param);
}

static int msc_zero_object(struct scard_handle *card_handle, 
			   struct msc_id obj_id, size_t obj_size,
			   scard_cmd_complete callback, void *user_data)
{
	struct scard_cmd_param *cmd_param;
	uint8_t *zero_buf;
	
	cmd_param = malloc(sizeof(struct scard_cmd_param));
	if (!cmd_param) 
		return SCARD_ERR_NO_MEM;
	memset(cmd_param, 0, sizeof(struct scard_cmd_param));

	zero_buf = malloc(obj_size);
	if (!zero_buf) {
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(zero_buf, 0, obj_size);

	cmd_param->sbuf = zero_buf;
	cmd_param->sbuf_len = obj_size;
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;

	return msc_update_object(card_handle, obj_id, 0, 
				 cmd_param->sbuf, cmd_param->sbuf_len, 
				 msc_zero_object_complete, cmd_param);
}

static void msc_create_object_complete(struct scard_card_cmd_param *card_param)
{
	struct scard_handle *card_handle = card_param->handle;
	struct scard_cmd_param *cmd_param = card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;
	struct msc_object_priv *create_priv = 
			(struct msc_object_priv *)cmd_param->priv_param;
	int r;

	if (card_param->ret != SCARD_SUCCESS) {
		cmd_param->ret = card_param->ret;
	} else {
		cmd_param->ret = scard_check_sw(card_handle, apdu->sw1,
						apdu->sw2);
		
		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
			r = msc_zero_object(card_handle, 
					       create_priv->obj_id, 
					       create_priv->obj_size, 
					       cmd_param->callback, 
					       cmd_param->user_data);
			if (r == SCARD_SUCCESS)
				return;
			else 
				cmd_param->ret = r;
		} else if (apdu->sw1 == 0x9C) {
			if (apdu->sw2 == 0x01)
				cmd_param->ret = SCARD_ERR_NO_MEM;
			else if (apdu->sw2 == 0x08)
				cmd_param->ret = SCARD_ERR_FILE_EXISTS;
			else if (apdu->sw2 == 0x06) 
				cmd_param->ret = SCARD_ERR_NOT_ALLOWED;			
		}
	}

	cmd_param->callback(cmd_param->user_data, cmd_param->ret);

	free(apdu);
	free(cmd_param);
	free(card_param);
}

static int msc_create_object(struct scard_handle *card_handle, 
			     struct msc_id obj_id, size_t obj_size, 
			     uint16_t read_perm, uint16_t write_perm,
			     uint16_t delete_perm,
			     scard_cmd_complete callback, void *user_data)
{
	struct scard_card_cmd_param *card_param;
	struct scard_cmd_param *cmd_param;
	struct scard_apdu *apdu;
	struct msc_object_priv *create_priv;
	uint8_t buffer[14];
	int r;

	cmd_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!cmd_param)
		return SCARD_ERR_NO_MEM;
	memset(cmd_param, 0, sizeof(struct scard_card_cmd_param));

	create_priv = malloc(sizeof(struct msc_object_priv));
	if (!create_priv) {
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	create_priv->obj_id = obj_id;
	create_priv->obj_size = obj_size;

	cmd_param->priv_param = create_priv;
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;

	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = SCARD_APDU_CASE_3_SHORT;
	apdu->cla = card_handle->cla;
	apdu->ins = 0x5A;
	apdu->p1 = 0x00;
	apdu->p2 = 0x00;
	apdu->lc = 14;

	memcpy(buffer, obj_id.id, 4);
	ulong2bebytes(buffer + 4, obj_size);
	ushort2bebytes(buffer + 8, read_perm);
	ushort2bebytes(buffer + 10, write_perm);
	ushort2bebytes(buffer + 12, delete_perm);

	apdu->data = buffer;
	apdu->datalen = 14;

	card_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!card_param) {
		free(apdu);
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct scard_card_cmd_param));
	card_param->handle = card_handle;
	card_param->cmd_param = cmd_param;
	card_param->apdu = apdu;
	card_param->callback = msc_create_object_complete;
		
	r = scard_reader_transmit(card_param);
	if (r != SCARD_SUCCESS) {
		free(apdu);
		free(cmd_param);
		free(card_param);
	}
	
	return r;
}

struct msc_create_file_priv {
	struct scard_handle *card_handle;
	struct mscfs_file msc_file;

	scard_cmd_complete callback;
	void *user_data;
};

static void msc_create_file_complete(void *user_data, int ret)
{
	struct msc_create_file_priv *create_priv = 
		(struct msc_create_file_priv *) user_data;
	struct scard_handle *card_handle = create_priv->card_handle;
	struct muscle_private *msc_priv = MSC_PRIV(card_handle);
	struct mscfs_file *filp = &create_priv->msc_file;

	if (ret == SCARD_SUCCESS) {
		mscfs_cache_push(msc_priv->fs, filp);
	}

	create_priv->callback(create_priv->user_data, ret);
	free(create_priv);
}

static int msc_create_directory(struct scard_handle *card_handle, 
				struct scard_file *filp,
				scard_cmd_complete callback, void *user_data)
{
	struct muscle_private *msc_priv = MSC_PRIV(card_handle);
	struct mscfs *fs = msc_priv->fs;
	struct msc_id obj_id;
	uint8_t *oid = obj_id.id;
	int fid =filp->id;
	uint16_t read_perm = 0, write_perm = 0, delete_perm = 0;
	size_t obj_size = filp->size;
	struct msc_create_file_priv *create_priv;

	if (fid == 0) /* No null name files */
		return SCARD_ERR_INVALID_ARGS;
	/* No nesting directories */
	if (fs->curr_path[0] != 0x3F || fs->curr_path[1] != 0x00)
		return SCARD_ERR_NOT_SUPPORTED;
	oid[0] = ((fid & 0xFF00) >> 8) & 0xFF;
	oid[1] = fid & 0xFF;
	oid[2] = oid[3] = 0;

	muscle_parse_acls(filp, &read_perm, &write_perm, &delete_perm);

	create_priv = malloc(sizeof(struct msc_create_file_priv));
	if (!create_priv)
		return SCARD_ERR_NO_MEM;
	memset(create_priv, 0, sizeof(struct msc_create_file_priv));
	create_priv->card_handle = card_handle;
	create_priv->callback = callback;
	create_priv->user_data = user_data;

	create_priv->msc_file.object_id = obj_id;
	create_priv->msc_file.size = filp->size;
	create_priv->msc_file.ef = 0;
	create_priv->msc_file.read = read_perm;
	create_priv->msc_file.write = write_perm;
	create_priv->msc_file.del = delete_perm;

	return msc_create_object(card_handle, obj_id, obj_size, 
			      read_perm, write_perm, delete_perm, 
			      msc_create_file_complete, create_priv);
}

static int msc_create_file(struct scard_handle *card_handle, 
			   struct scard_file *filp,
			   scard_cmd_complete callback, void *user_data)
{
	struct muscle_private *msc_priv = MSC_PRIV(card_handle);
	struct mscfs *fs = msc_priv->fs;
	size_t obj_size = filp->size;
	uint16_t read_perm = 0, write_perm = 0, delete_perm = 0;
	struct msc_id obj_id;
	struct msc_create_file_priv *create_priv;

	if (filp->type == SCARD_FILE_TYPE_DF)
		return msc_create_directory (card_handle, filp, 
					     callback, user_data);
	if (filp->type != SCARD_FILE_TYPE_WORKING_EF) 
		return SCARD_ERR_NOT_SUPPORTED;
	if (filp->id == 0) /* No null name files */
		return SCARD_ERR_INVALID_ARGS;

	muscle_parse_acls(filp, &read_perm, &write_perm, &delete_perm);
	mscfs_lookup_local(fs, filp->id, &obj_id);

	create_priv = malloc(sizeof(struct msc_create_file_priv));
	if (!create_priv)
		return SCARD_ERR_NO_MEM;
	memset(create_priv, 0, sizeof(struct msc_create_file_priv));
	create_priv->card_handle = card_handle;
	create_priv->callback = callback;
	create_priv->user_data = user_data;

	create_priv->msc_file.object_id = obj_id;
	create_priv->msc_file.size = filp->size;
	create_priv->msc_file.ef = 1;
	create_priv->msc_file.read = read_perm;
	create_priv->msc_file.write = write_perm;
	create_priv->msc_file.del = delete_perm;

	return msc_create_object(card_handle, obj_id, obj_size, read_perm,
			      write_perm, delete_perm, 
			      msc_create_file_complete, create_priv);
}

static void msc_delete_object_complete(struct scard_card_cmd_param *card_param)
{
	struct scard_handle *card_handle = card_param->handle;
	struct scard_cmd_param *cmd_param = card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;

	if (card_param->ret != SCARD_SUCCESS)
		cmd_param->ret = card_param->ret;
	else {
		cmd_param->ret = scard_check_sw(card_handle, 
						apdu->sw1, apdu->sw2);
		if (apdu->sw1 == 0x9c) {
			if (apdu->sw2 == 0x07)
				cmd_param->ret = SCARD_ERR_FILE_NOT_FOUND;
			else if (apdu->sw2 == 0x06)
				cmd_param->ret = SCARD_ERR_NOT_ALLOWED;			
		}
	}

	cmd_param->callback(cmd_param->user_data, cmd_param->ret);
	free(cmd_param);
	free(apdu);
	free(card_param);	
}

static int msc_delete_object(struct scard_handle *card_handle, 
			     struct msc_id obj_id, int zero,
			     scard_cmd_complete callback, void *user_data)
{
	struct scard_card_cmd_param *card_param;
	struct scard_cmd_param *cmd_param;
	struct scard_apdu *apdu;
	int r;

	cmd_param = malloc(sizeof(struct scard_cmd_param));
	if (!cmd_param)
		return SCARD_ERR_NO_MEM;
	memset(cmd_param, 0, sizeof(struct scard_cmd_param));
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;
	
	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = SCARD_APDU_CASE_3_SHORT;
	apdu->cla = card_handle->cla;
	apdu->ins = 0x52;
	apdu->p1 = 0x00;
	apdu->p2 = zero ? 0x01 : 0x00;
	apdu->lc = 4;
	apdu->data = obj_id.id;
	apdu->datalen = 4;

	card_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!card_param) {
		free(apdu);
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct scard_card_cmd_param));
	card_param->handle = card_handle;
	card_param->cmd_param = cmd_param;
	card_param->apdu = apdu;
	card_param->callback = msc_delete_object_complete;

	r = scard_reader_transmit(card_param);
	if (r != SCARD_SUCCESS) {
		free(cmd_param);
		free(apdu);
		free(card_param);
	}

	return r;
}

struct msc_delete_priv {
	struct scard_handle *card_handle;
	struct scard_path root_path;
	struct mscfs_file *leaf;
	scard_cmd_complete callback;
	void *user_data;
};

static int msc_get_a_leaf(struct scard_handle *card_handle, 
			  struct mscfs_file *parent_filp,
			  struct mscfs_file **leaf)
{
	struct muscle_private *msc_priv = MSC_PRIV(card_handle);
	struct mscfs *fs = msc_priv->fs;
	struct mscfs_file *child_filp;
	const struct msc_id *parent_id, *child_id;
	int r;

	if (parent_filp->ef) {
		*leaf = parent_filp;
		return SCARD_SUCCESS;
	}
	
	parent_id = &parent_filp->object_id;
	list_for_each_entry(struct mscfs_file, child_filp, 
			    &fs->file_cache_list, link) {
		child_id = &child_filp->object_id;

		if (0 == memcmp(parent_id->id + 2, child_id->id, 2)) {
			if (child_filp->ef) {
				*leaf = child_filp;
				return SCARD_SUCCESS;
			} else {
				r = msc_get_a_leaf(card_handle, child_filp, leaf);
				 /* Directory 'child_filp' there are no children */
				if (r == SCARD_SUCCESS && *leaf == NULL)
					*leaf = child_filp;
				return r;
			}
		}
	}
	
	*leaf = parent_filp;
	return SCARD_SUCCESS;
}

static void msc_delete_file_complete(void *user_data, int ret)
{
	struct msc_delete_priv *delete_priv = 
			(struct msc_delete_priv *)user_data;
	struct scard_handle *card_handle = delete_priv->card_handle;
	struct muscle_private *msc_priv = MSC_PRIV(card_handle);
	
	struct msc_id obj_id;
	uint8_t *oid = obj_id.id;
	struct mscfs_file *tree_root, *deleted_leaf, *leaf;
	const struct scard_path *root_path = &delete_priv->root_path;
	int r;
	

	deleted_leaf = delete_priv->leaf;
	obj_id = deleted_leaf->object_id;

	/* Check if its the root... this file generally is virtual
	 * So don't return an error if it fails */
	if ((0 == memcpy(oid, "\x3F\x00\x00\x00", 4))
		|| (0 == memcpy(oid, "\x3F\x00\x3F\x00", 4))) {
		r = SCARD_SUCCESS;
		goto ret;
	} else if (ret != SCARD_SUCCESS) {
		r = ret;
		goto ret;
	}

	mscfs_cache_pop(deleted_leaf);
	
	r = mscfs_load_fileinfo(msc_priv->fs, root_path->value, root_path->len,
				&tree_root);
	if (r != SCARD_SUCCESS)
		goto ret;

	r = msc_get_a_leaf(card_handle, tree_root, &leaf);
	if (r != SCARD_SUCCESS)
		goto ret;

	obj_id = leaf->object_id;
	if (!leaf->ef) {
		oid[0] = oid[2];
		oid[1] = oid[3];
		oid[2] = oid[3] = 0;
	}

	delete_priv->leaf = leaf;
	r = msc_delete_object(card_handle, obj_id, 1, 
			      msc_delete_file_complete, delete_priv);
	if (r == SCARD_SUCCESS) 
		return;

ret: 
	delete_priv->callback(delete_priv->user_data, r);
	free(delete_priv);
}

static int msc_delete_file (struct scard_handle *card_handle, 
			    const struct scard_path *in_path,
			    scard_cmd_complete callback, void *user_data)
{
	struct muscle_private *msc_priv = MSC_PRIV(card_handle);
	struct mscfs_file *tree_root, *leaf;
	struct msc_id obj_id;
	uint8_t *oid;
	struct msc_delete_priv *delete_priv;
	int r;

	r = mscfs_load_fileinfo(msc_priv->fs, in_path->value, in_path->len,
				&tree_root);
	if (r != SCARD_SUCCESS)
		return r;

	r = msc_get_a_leaf(card_handle, tree_root, &leaf);
	if (r != SCARD_SUCCESS)
		return r;
	if (!leaf)
		leaf = tree_root;
	obj_id = leaf->object_id;
	oid = obj_id.id;
	if (!leaf->ef) {
		oid[0] = oid[2];
		oid[1] = oid[3];
		oid[2] = oid[3] = 0;
	}

	delete_priv = malloc(sizeof(struct msc_delete_priv));
	if (!delete_priv) 
		return SCARD_ERR_NO_MEM;
	delete_priv->root_path = *in_path;
	delete_priv->leaf = leaf;
	delete_priv->callback = callback;
	delete_priv->user_data = user_data;

	r = msc_delete_object(card_handle, obj_id, 1, 
			      msc_delete_file_complete, delete_priv);
	if (r != SCARD_SUCCESS) {
		free(delete_priv);
	}

	return 0;
}

struct msc_list_priv {
	struct scard_handle *card_handle;
	uint8_t *buf;
	size_t buflen;

	scard_cmd_complete callback;
	void *user_data;
};

static int msc_get_linea_childs_id(struct mscfs *fs, uint8_t *buf, size_t buflen)
{
	struct mscfs_file *pos;
	uint8_t *oid;
	uint8_t *p = buf;
	int count = 0;

	list_for_each_entry(struct mscfs_file, pos, 
			    &fs->file_cache_list, link) {
		oid = pos->object_id.id;
		if (0 == memcmp(fs->curr_path, oid, 2)) {
			if (count == (int)buflen)
				break;

			p[0] = oid[2];
			p[1] = oid[3];
			/* No direcotries/null names outside of root */
			if (p[0] == 0x00 && p[1] == 0x00)
				continue;
			p += 2;
			count += 2;
		}
	}
	return count;
}

static void msc_list_file_complete(void *user_data, int ret)
{
	struct msc_list_priv *list_priv = 
			(struct msc_list_priv *)user_data;
	struct scard_handle *card_handle = list_priv->card_handle;
	struct muscle_private *msc_priv = MSC_PRIV(card_handle);
	struct mscfs *fs = msc_priv->fs;
	int r = ret;
	
	if (ret == SCARD_SUCCESS) {
		r = msc_get_linea_childs_id(fs, list_priv->buf, 
					    list_priv->buflen);
	}

	list_priv->callback(list_priv->user_data, r);
	free(list_priv);
}

static int msc_list_file(struct scard_handle *card_handle, 
			 uint8_t *buf, size_t buflen,
			 scard_cmd_complete callback, void *user_data)
{
	struct muscle_private *msc_priv = MSC_PRIV(card_handle);
	struct mscfs *fs = msc_priv->fs;
	struct msc_list_priv *list_priv;
	int r;
	
	if (list_empty(&fs->file_cache_list)) {
		list_priv = malloc(sizeof(struct msc_list_priv));
		if (!list_priv)
			return SCARD_ERR_NO_MEM;
		list_priv->card_handle = card_handle;
		list_priv->buf = buf;
		list_priv->buflen = buflen;
		list_priv->callback = callback;
		list_priv->user_data = user_data;

		r = mscfs_update_cache(fs, msc_list_file_complete, list_priv);
		if (r != SCARD_SUCCESS) {
			free(list_priv);
			return r;
		}
	} else {
		r = msc_get_linea_childs_id(fs, buf, buflen);
		callback(user_data, r);
	}

	return 0;
}

static void truncate_pin_nulls(const uint8_t *pin_val, int *pin_len)
{
	for (; *pin_len > 0; (*pin_len)--)
		if (pin_val[*pin_len - 1])
			break;
}

static int (*iso_pin_cmd)(struct scard_handle *card_handle,
		       struct scard_pin_cmd_data *pin_cmd, int tries_left, 
		       scard_cmd_complete callback, void *user_data);

static int msc_build_pin_cmd(struct scard_handle *card_handle, 
			     struct scard_apdu *apdu, 
			     struct scard_pin_cmd_data *pin_cmd,
			     uint8_t *sbuf, size_t sbuf_len)
{
	uint8_t *p = sbuf;

	switch (pin_cmd->pin_type) {
	case SCARD_AC_CHV:
		break;
	default:
		return SCARD_ERR_INVALID_ARGS;
	}
	
	switch (pin_cmd->cmd) {
	case SCARD_PIN_CMD_VERIFY:
		truncate_pin_nulls(pin_cmd->pin1.data, &pin_cmd->pin1.len);
		memcpy(sbuf, pin_cmd->pin1.data, pin_cmd->pin1.len);

		apdu->cse = SCARD_APDU_CASE_3_SHORT;
		apdu->cla = card_handle->cla;
		apdu->ins = MSC_INS_VERIFY_PIN;
		apdu->p1 = pin_cmd->pin_ref;
		apdu->p2 = 0x00;
		apdu->lc = pin_cmd->pin1.len;
		apdu->data = sbuf;
		apdu->datalen = apdu->lc;

		pin_cmd->pin1.offset = 5;		
		break;
	case SCARD_PIN_CMD_CHANGE:
		truncate_pin_nulls(pin_cmd->pin1.data, &pin_cmd->pin1.len);
		truncate_pin_nulls(pin_cmd->pin2.data, &pin_cmd->pin2.len);
		
		apdu->cse = SCARD_APDU_CASE_3_SHORT;
		apdu->cla = card_handle->cla;
		apdu->ins = MSC_INS_CHANGE_PIN;
		apdu->p1 = pin_cmd->pin_ref;
		apdu->p2 = 0x00;
		/* Old PIN */
		*p++ = (uint8_t)pin_cmd->pin1.len;
		memcpy(p, pin_cmd->pin1.data, pin_cmd->pin1.len);
		p += pin_cmd->pin1.len;
		/* New PIN */
		*p++ = (uint8_t)pin_cmd->pin2.len;
		memcpy(p, pin_cmd->pin2.data, pin_cmd->pin2.len);
		p += pin_cmd->pin2.len;

		apdu->lc = p - sbuf;
		apdu->data = sbuf;
		apdu->datalen = apdu->lc;
		break;
	case SCARD_PIN_CMD_UNBLOCK:
		truncate_pin_nulls(pin_cmd->pin1.data, &pin_cmd->pin1.len);
		memcpy(sbuf, pin_cmd->pin1.data, pin_cmd->pin1.len);

		apdu->cse = SCARD_APDU_CASE_3_SHORT;
		apdu->cla = card_handle->cla;
		apdu->ins = MSC_INS_UNBLOCK_PIN;
		apdu->p1 = pin_cmd->pin_ref;
		apdu->p2 = 0x00;
		apdu->lc = pin_cmd->pin1.len;
		apdu->data = sbuf;
		apdu->datalen = apdu->lc;
		break;
	default:
		return SCARD_ERR_NOT_SUPPORTED;
	}

	return SCARD_SUCCESS;
}

static int msc_pin_cmd(struct scard_handle *card_handle,
		       struct scard_pin_cmd_data *pin_cmd, int tries_left, 
		       scard_cmd_complete callback, void *user_data)
{
	struct scard_apdu *apdu;
	uint8_t pin_buf[SCARD_APDU_BUFFER_MAX];
	int r;

	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu)
		return SCARD_ERR_NO_MEM;
	memset(apdu, 0, sizeof(struct scard_apdu));

	r = msc_build_pin_cmd(card_handle, apdu, 
			      pin_cmd, pin_buf, sizeof(pin_buf));
	if (r != SCARD_SUCCESS) {
		free(apdu);
		return r;
	}
	pin_cmd->apdu = apdu;
	r = iso_pin_cmd(card_handle, pin_cmd, tries_left, callback, user_data);
	if (r == SCARD_SUCCESS)
		return SCARD_SUCCESS;

	return r;
}

#define MSC_DL_APDU	0x01
#define MSC_DL_OBJECT	0x02

struct msc_get_challenge_priv {
	uint8_t location;
};

static void msc_get_challenge_complete(struct scard_card_cmd_param *card_param)
{
	struct scard_handle *card_handle = card_param->handle;
	struct scard_cmd_param *cmd_param = card_param->cmd_param;
	struct scard_apdu *apdu = card_param->apdu;
	struct msc_get_challenge_priv *get_rnd_priv = 
			(struct msc_get_challenge_priv *)cmd_param->priv_param;
	uint8_t location = get_rnd_priv->location;
	int r;

	if (card_param->ret != SCARD_SUCCESS) {
		cmd_param->ret = card_param->ret;
		goto ret;
	} else {
		cmd_param->ret = scard_check_sw(card_handle, apdu->sw1, apdu->sw2);
		if (apdu->sw1 != 0x90 || apdu->sw2 == 0x00)
			goto ret;

		if (location == MSC_DL_APDU) {
			cmd_param->rbuf_actual = cmd_param->rbuf_len - apdu->resplen;
			cmd_param->ret = cmd_param->rbuf_actual;
			goto ret;			
		} else {
			r = msc_read_object(card_handle, input_id, 2, 
					    cmd_param->rbuf, 
					    cmd_param->rbuf_len,
					    cmd_param->callback, 
					    cmd_param->user_data);
			if (r != SCARD_SUCCESS) {
				cmd_param->ret = r;
				goto ret;
			} else
				goto read_rnd;
		}
	}

ret:
	cmd_param->callback(cmd_param->user_data, cmd_param->ret);
read_rnd:
	free(get_rnd_priv);
	free((uint8_t *)cmd_param->sbuf);
	free(cmd_param);
	free(apdu);
	free(card_param);
}

static int _msc_get_challenge(struct scard_handle *card_handle,
			      uint8_t *seed, uint16_t seed_len,
			      uint8_t *rnd, uint16_t rnd_len,
			      scard_cmd_complete callback, void *user_data)
{
	struct scard_card_cmd_param *card_param;
	struct scard_cmd_param *cmd_param;
	struct scard_apdu *apdu;
	uint8_t location = (rnd_len < MSC_RECV_MAX(card_handle)) ? MSC_DL_APDU : MSC_DL_OBJECT;
	uint8_t cse = (location == MSC_DL_APDU) ? SCARD_APDU_CASE_4_SHORT : SCARD_APDU_CASE_3_SHORT;
	uint8_t *buffer, *p;
	struct msc_get_challenge_priv *get_rnd_priv;
	int r;

	buffer = malloc(4 + seed_len);
	if (!buffer) {
		return SCARD_ERR_NO_MEM;
	}
	p = buffer;
	ushort2bebytes(p, rnd_len);
	p += 2;
	ushort2bebytes(p, seed_len);
	p += 2;
	if (seed_len > 0)
		memcpy(p, seed, seed_len);

	cmd_param = malloc(sizeof(struct scard_cmd_param));
	if (!cmd_param) {
		free(buffer);
		return SCARD_ERR_NO_MEM;
	}
	memset(cmd_param, 0, sizeof(struct scard_cmd_param));
	get_rnd_priv = malloc(sizeof(struct msc_get_challenge_priv));
	if (!get_rnd_priv) {
		free(buffer);
		free(cmd_param);
		return SCARD_ERR_NO_MEM;
	}
	get_rnd_priv->location = location;
	cmd_param->priv_param = get_rnd_priv;
	cmd_param->sbuf = buffer;
	cmd_param->sbuf_len = 4 + seed_len;
	cmd_param->rbuf = rnd;
	cmd_param->rbuf_len = rnd_len;
	cmd_param->callback = callback;
	cmd_param->user_data = user_data;

	apdu = malloc(sizeof(struct scard_apdu));
	if (!apdu) {
		free(cmd_param);
		free(buffer);
		free(get_rnd_priv);
		return SCARD_ERR_NO_MEM;
	}

	memset(apdu, 0, sizeof(struct scard_apdu));
	apdu->cse = cse;
	apdu->cla = card_handle->cla;
	apdu->ins = MSC_INS_GET_CHALLENGE;
	apdu->p1 = 0x00;
	apdu->p2 = location;
	apdu->lc = 4 + seed_len;
	apdu->data = buffer;
	apdu->datalen = apdu->lc;

	/* FIXME: differenct from OpenSC */
	if (location == 1) {
		apdu->le = rnd_len;
		apdu->resp = rnd;
		apdu->resplen = rnd_len;
	}

	card_param = malloc(sizeof(struct scard_card_cmd_param));
	if (!card_param) {
		free(cmd_param);
		free(buffer);
		free(get_rnd_priv);
		free(apdu);
		return SCARD_ERR_NO_MEM;
	}
	memset(card_param, 0, sizeof(struct scard_card_cmd_param));
	card_param->handle = card_handle;
	card_param->cmd_param = cmd_param;
	card_param->apdu = apdu;
	card_param->callback = msc_get_challenge_complete;
	
	r = scard_reader_transmit(card_param);
	if (r != SCARD_SUCCESS) {
		free(cmd_param);
		free(buffer);
		free(get_rnd_priv);
		free(apdu);
		free(card_param);	
	}

	return r;
}

static int msc_get_challenge(struct scard_handle *card_handle, 
			     uint8_t *rnd, size_t rnd_len,
			     scard_cmd_complete callback, void *user_data)
{
	return _msc_get_challenge(card_handle, NULL, 0, rnd, (uint16_t)rnd_len, 
				  callback, user_data);
}

static struct scard_card_operations *scard_get_msc_ops (void)
{
	struct scard_card_operations *iso_ops;
	
	iso_ops = scard_get_iso7816_ops();
	iso_pin_cmd = iso_ops->pin_cmd;

	msc_ops = *iso_ops;
	msc_ops.match = msc_match;
	msc_ops.init = msc_init;
	msc_ops.exit = msc_exit;
	msc_ops.check_sw = msc_check_sw;
	msc_ops.select_file = msc_select_file;
	msc_ops.read_binary = msc_read_binary;
	msc_ops.update_binary = msc_update_binary;
	msc_ops.create_file = msc_create_file;
	msc_ops.delete_file = msc_delete_file;
	msc_ops.list_file = msc_list_file;
	msc_ops.pin_cmd = msc_pin_cmd;
	msc_ops.get_challenge = msc_get_challenge;
	
	return &msc_ops;
}

int scard_register_card_muscle (void)
{
	return scard_card_driver_register(SCARD_MUSCLE_DRIVER_NAME, 
		scard_get_msc_ops());
}

void scard_unregister_card_muscle(void)
{
	scard_card_driver_unregister(SCARD_MUSCLE_DRIVER_NAME);
}
