#include "scard_priv.h"

DECLARE_LIST(scard_driver_list);

struct scard_card_driver *scard_card_driver_by_name(const char *name)
{
	struct scard_card_driver *pos;
	
	list_for_each_entry(struct scard_card_driver, pos,
		&scard_driver_list, link) {
		if (strcmp(pos->name, name) == 0)
			return pos;
	}

	return NULL;
}

int scard_card_driver_register(const char *name, struct scard_card_operations *ops)
{
	struct scard_card_driver *driver;

	driver = scard_card_driver_by_name(name);
	if (driver) {
		scard_log(SCARD_LOG_WARN, "Driver '%s' has been registerred",
			  name);
		return SCARD_ERR_UNSPECIFIED;
	}

	driver = malloc(sizeof(struct scard_card_driver));
	if (!driver)
		return SCARD_ERR_NO_MEM;
	memset(driver, 0, sizeof(struct scard_card_driver));
	driver->name = strdup(name);
	driver->ops = ops;

	list_init(&driver->link);

	list_insert_tail(&driver->link, &scard_driver_list);

	return SCARD_SUCCESS;
}

void scard_card_driver_unregister(const char *name)
{
	struct scard_card_driver *driver;

	driver = scard_card_driver_by_name(name);
	if (!driver) return ;

	list_delete(&driver->link);

	free(driver->name);
	free(driver);
}

struct scard_match_param {
	struct scard_card_driver *card_driver_pos;
	struct scard_handle **out_handle;
	scard_cmd_complete callback;
	void *user_data;
};

static void scard_match_driver_complete(void *user_data, int ret)
{
	struct scard_match_param *match_param = 
			(struct scard_match_param *)user_data;
	struct scard_handle *card_handle = *(match_param->out_handle);
	struct scard_card_driver *pos, *n = NULL;
	int r = SCARD_SUCCESS;

	if (ret != SCARD_SUCCESS) {
		pos = match_param->card_driver_pos;
		for (n = list_entry(pos->link.next, 
				    struct scard_card_driver, link);
		     &n->link != &scard_driver_list;
		     n = list_entry(pos->link.next, 
				    struct scard_card_driver, link)) {
			if (n->ops->match == NULL)
				continue;
			scard_log(SCARD_LOG_DEBUG, 
				  "Trying card driver: %s", n->name);
			card_handle->card_driver = n;
			r = n->ops->match(card_handle, 
					  scard_match_driver_complete, 
					  match_param);
			if (r != SCARD_SUCCESS)
				goto out;
			else 
				return;
		}
		r = SCARD_ERR_NO_DRIVER;
	}
out:
	if (r != SCARD_SUCCESS) {
		scard_reader_disconnect(card_handle);
		free(card_handle);
		*(match_param->out_handle) = NULL;
	} else {
		if (card_handle->card_driver->ops->init)
			card_handle->card_driver->ops->init(card_handle);
		card_handle->flags = 0;
		scard_format_path("3F00", &card_handle->curr_path);
		card_handle->curr_path.type = SCARD_PATH_TYPE_PATH;
	}
	match_param->callback(match_param->user_data, r);
	free(match_param);	
}

int scard_match_driver(struct scard_handle *card_handle,
		       struct scard_handle **out_handle,
		       scard_cmd_complete callback, void *user_data)
{
	struct scard_match_param *match_param;
	struct scard_card_driver *pos = NULL;

	list_for_each_entry(struct scard_card_driver, pos,
		&scard_driver_list, link) {
		if (pos->ops->match)
			break;
	}
	if (!pos)
		return SCARD_ERR_NO_DRIVER;
	card_handle->card_driver = pos;

	match_param = malloc(sizeof(struct scard_match_param));
	if (!match_param) 
		return SCARD_ERR_NO_MEM;
	*out_handle = card_handle;
	match_param->card_driver_pos = pos;
	match_param->out_handle = out_handle;
	match_param->callback = callback;
	match_param->user_data = user_data;
	
	if (pos->ops->match) {
		scard_log(SCARD_LOG_DEBUG, 
			  "Trying card driver: %s", pos->name);
		return pos->ops->match(card_handle, 
				       scard_match_driver_complete,
				       match_param);
	} else {
		free(match_param);
		return SCARD_ERR_NO_DRIVER;
	}
}
