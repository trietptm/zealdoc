#include "scard_priv.h"

static int scard_pin_cmd(struct scard_handle *card_handle, 
		  struct scard_pin_cmd_data *pin_cmd,
		  int tries_left, 
		  scard_cmd_complete callback, void *user_data)
{
	if (card_handle->card_driver->ops->pin_cmd == NULL)
		return SCARD_ERR_NOT_SUPPORTED;
	return card_handle->card_driver->ops->pin_cmd(card_handle, pin_cmd,
					tries_left, callback, user_data);
}

int scard_verify(struct scard_handle *card_handle, unsigned int type, int ref,
		 const uint8_t *pin, size_t pin_len, int tries_left,
		 scard_cmd_complete callback, void *user_data)
{
	struct scard_pin_cmd_data pin_cmd;

	memset(&pin_cmd, 0, sizeof(pin_cmd));
	pin_cmd.cmd = SCARD_PIN_CMD_VERIFY;
	pin_cmd.pin_type = type;
	pin_cmd.pin_ref = ref;
	pin_cmd.pin1.data = pin;
	pin_cmd.pin1.len = pin_len;

	return scard_pin_cmd(card_handle, &pin_cmd, tries_left, 
			     callback, user_data);
}

int scard_change(struct scard_handle *card_handle, unsigned int type, int ref,
		 const uint8_t *pin1, size_t pin1_len, 
		 uint8_t *pin2, size_t pin2_len,
		 int tries_left, scard_cmd_complete callback, void *user_data)
{
	struct scard_pin_cmd_data pin_cmd;

	memset(&pin_cmd, 0, sizeof(pin_cmd));
	pin_cmd.cmd = SCARD_PIN_CMD_CHANGE;
	pin_cmd.pin_type = type;
	pin_cmd.pin_ref = ref;
	pin_cmd.pin1.data = pin1;
	pin_cmd.pin1.len = pin1_len;
	pin_cmd.pin2.data = pin2;
	pin_cmd.pin2.len = pin2_len;

	return scard_pin_cmd(card_handle, &pin_cmd, tries_left, 
			     callback, user_data);
}

int scard_unblock(struct scard_handle *card_handle, unsigned int type, int ref,
		 const uint8_t *pin1, size_t pin1_len, 
		 uint8_t *pin2, size_t pin2_len,
		 int tries_left, scard_cmd_complete callback, void *user_data)
{
	struct scard_pin_cmd_data pin_cmd;

	memset(&pin_cmd, 0, sizeof(pin_cmd));
	pin_cmd.cmd = SCARD_PIN_CMD_UNBLOCK;
	pin_cmd.pin_type = type;
	pin_cmd.pin_ref = ref;
	pin_cmd.pin1.data = pin1;
	pin_cmd.pin1.len = pin1_len;
	pin_cmd.pin2.data = pin2;
	pin_cmd.pin2.len = pin2_len;

	return scard_pin_cmd(card_handle, &pin_cmd, tries_left, 
			     callback, user_data);
}

/*
 * This function will copy a PIN, convert and pad it as required
 *
 * Note about the SC_PIN_ENCODING_GLP encoding:
 * PIN buffers are allways 16 nibbles (8 bytes) and look like this:
 *   0x2 + len + pin_in_BCD + paddingnibbles
 * in which the paddingnibble = 0xF
 * E.g. if PIN = 12345, then sbuf = {0x24, 0x12, 0x34, 0x5F, 0xFF, 0xFF, 0xFF, 0xFF}
 * E.g. if PIN = 123456789012, then sbuf = {0x2C, 0x12, 0x34, 0x56, 0x78, 0x90, 0x12, 0xFF}
 * Reference: Global Platform - Card Specification - version 2.0.1' - April 7, 2000
 */
int scard_build_pin(uint8_t *rbuf, size_t rbuf_len, 
		    struct scard_pin_cmd_pin *pin, int pad)
{
	size_t i = 0, j, pin_len = pin->len;

	if (pin->max_len && pin_len > pin->max_len)
		return SCARD_ERR_INVALID_ARGS;
	if (pin->encode_type == SCARD_PIN_ENCODING_GLP) {
		while (pin_len > 0 && pin->data[pin_len - 1] == 0xFF)
			pin_len--;
		if (pin_len > 12)
			return SCARD_ERR_INVALID_ARGS;
		for (i = 0; i < pin_len; i++) {
			if (pin->data[i] < '0' || pin->data[i] > '9')
				return SCARD_ERR_INVALID_ARGS;
		}
		rbuf[0] = 0x20 | pin_len;
		rbuf++;
		rbuf_len--;
	}

	if (pin->encode_type == SCARD_PIN_ENCODING_ASCII) {
		if (pin_len > rbuf_len)
			return SCARD_ERR_INSUF_BUFFER;
		memcpy(rbuf, pin->data, pin_len);
		i = pin_len;
	} else if (pin->encode_type == SCARD_PIN_ENCODING_BCD ||
		pin->encode_type == SCARD_PIN_ENCODING_GLP) {
		if (pin_len > 2 *rbuf_len)
			return SCARD_ERR_INSUF_BUFFER;
		for (i = j = 0; j < pin_len; j++) {
			rbuf[i] <<= 4;
			rbuf[i] |= pin->data[j] & 0x0F;
			if (j & 1) i++;
		}
		if (j & 1) {
			rbuf[i] <<= 4;
			rbuf[i] |= pin->pad_char & 0x0F;
			i++;
		}
	}
	if (pad || pin->encode_type == SCARD_PIN_ENCODING_GLP) {
		size_t pad_len = pin->pad_len;
		uint8_t pad_char = pin->encode_type == SCARD_PIN_ENCODING_GLP ? 0xFF: pin->pad_char;

		if (pin->encode_type == SCARD_PIN_ENCODING_BCD)
			pad_len >>= 1;
		if (pin->encode_type == SCARD_PIN_ENCODING_GLP)
			pad_len = 8;

		if (pad_len > rbuf_len)
			return SCARD_ERR_INSUF_BUFFER;
		if (pad_len && i < pad_len) {
			memset(rbuf + i, pad_char, pad_len - i);
			i = pad_len;
		}
	}

	return i;
}