#include "pcsc_priv.h"
#ifdef CONFIG_USB
#include <usb.h>
#endif

/* TODO: assume all reader only have one slot */

static void pcsc_raise_ris(pcsc_ifd_hd_t *hd);
static void pcsc_raise_ors(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_css(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_csf(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_to(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_iccp(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_iccnp(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_cas(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_caf(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_icca(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_iccd(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_iccr(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_cis(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_rrm(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_cds(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_cdf(pcsc_ifd_hd_t *rd_ctx);
static void pcsc_raise_event(pcsc_ifd_hd_t *rd_ctx, int event);

static void ifd_hd_start(pcsc_ifd_hd_t *hd)
{
	/* sm start - reader insert event */
	pcsc_raise_ris(hd);
}

static void ifd_hd_stop(pcsc_ifd_hd_t *hd)
{
	/* sm start - reader remove event */
	pcsc_raise_rrm(hd);
}
static void ifd_hd_get_feature(pcsc_ifd_hd_t *hd)
{
	hd->ops->get_feature(hd);
}

static void ifd_hd_cancel(pcsc_ifd_hd_t *hd)
{
	hd->ops->cancel(hd);
}

static int ifd_hd_icc_status(pcsc_ifd_hd_t *hd)
{
	return hd->ops->icc_status(hd);	
}

static int ifd_hd_power_off(pcsc_ifd_hd_t *hd)
{
	return hd->ops->power_off(hd);	
}

static int ifd_hd_power_on(pcsc_ifd_hd_t *hd)
{
	return hd->ops->power_on(hd);	
}

static int ifd_hd_xfr_block(pcsc_ifd_hd_t *hd, pcsc_trans_param_t *p)
{
	return hd->ops->xfr_block(hd, p);	
}

static int ifd_hd_ifd_ctl(pcsc_ifd_hd_t *hd, pcsc_trans_param_t *p)
{
	return hd->ops->ifd_ctl(hd, p);	
}

#define PCSC_ERR_PRINT(ret)	\
		pcsc_log(PCSC_LOG_ERR, "PCSC_IFD: return err=%d at line=%d", ret, __LINE__)


static void pcsc_stm_exit_delay(void *eloop, void *user_ctx);

static void pcsc_stm_log(const stm_instance_t *fsmi,
			int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

#define PCSC_STATE_INIT		0
#define PCSC_STATE_OPEN		1	/* Reader Opening */
#define PCSC_STATE_CSTATUSING	2	/* ICC statusing */
#define PCSC_STATE_CSTATUSED	3	/* ICC statused */
#define PCSC_STATE_PRESENT	4	/* ICC present */
#define PCSC_STATE_ABSENT	5	/* ICC absent */
#define PCSC_STATE_POWERUP	6	/* ICC powerup(actived) */
#define PCSC_STATE_DEACTIVE	7	/* ICC deactive */
#define PCSC_STATE_POWERDOWN	8	/* ICC powerdown(deactived) */
#define PCSC_STATE_EXIT		9	

#define PCSC_STATE_COUNT	10

#define PCSC_STATE_NAMES {	\
	"INIT",			\
	"OPEN",			\
	"CSTATUSING",		\
	"CSTATUSED",		\
	"PRESENT",		\
	"ABSENT",		\
	"POWERUP",		\
	"DEACTIVE",		\
	"POWERDOWN",		\
	"EXIT",			\
}

#define PCSC_EVENT_RIS		0	/* Reader InSerted*/
#define PCSC_EVENT_ORS		1	/* Open Reader Success */
#define PCSC_EVENT_ORF		2	/* Open Reader Failed */
#define PCSC_EVENT_CSS		3	/* icC Status Success */
#define PCSC_EVENT_CSF		4	/* icC Status Failed */
#define PCSC_EVENT_TO		5	/* Time Out*/
#define PCSC_EVENT_ICCP		6	/* ICC Present */
#define PCSC_EVENT_ICCNP	7	/* ICC Not Present */
#define PCSC_EVENT_CAS		8	/* Card Active Success */
#define PCSC_EVENT_CAF		9	/* Card Active Failed */
#define PCSC_EVENT_ICCA		10	/* ICC active */
#define PCSC_EVENT_ICCD		11	/* Card deactive */
#define PCSC_EVENT_ICCR		12	/* ICC removed */
#define PCSC_EVENT_CIS		13	/* Card InSerted */	
#define PCSC_EVENT_RRM		14	/* Reader ReMoved */
#define PCSC_EVENT_CDS		15	/* Card Deactive Success */
#define PCSC_EVENT_CDF		16	/* Card Deactive Failed */

#define PCSC_EVENT_COUNT	17

#define PCSC_EVENT_NAMES {	\
	"RIS",			\
	"ORS",			\
	"ORF",			\
	"CSS",			\
	"CSF",			\
	"TO",			\
	"ICCP",			\
	"ICCNP",		\
	"CAS",			\
	"CAF",			\
	"ICCA",			\
	"ICCD",			\
	"ICCR",			\
	"CIS",			\
	"RRM",			\
	"CDS",			\
	"CDF",			\
}

static void pcsc_raise_event(pcsc_ifd_hd_t *rd_ctx, int event)
{
	eloop_schedule_event(NULL, rd_ctx->fsmi, event, rd_ctx);
}


static void pcsc_raise_ris(pcsc_ifd_hd_t *hd)
{
	pcsc_raise_event(hd, PCSC_EVENT_RIS);
}

static void pcsc_raise_ors(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ORS);
}

static void pcsc_raise_css(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CSS);
}

static void pcsc_raise_csf(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CSF);
}

static void pcsc_raise_to(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_TO);
}

static void pcsc_raise_iccp(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCP);
}

static void pcsc_raise_iccnp(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCNP);
}

static void pcsc_raise_cas(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CAS);
}

static void pcsc_raise_caf(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CAF);
}

static void pcsc_raise_icca(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCA);
}

static void pcsc_raise_iccd(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCD);
}

static void pcsc_raise_iccr(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCR);
}

static void pcsc_raise_cis(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CIS);
}

static void pcsc_raise_rrm(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_RRM);
}

static void pcsc_raise_cds(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CDS);
}

static void pcsc_raise_cdf(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CDF);
}

static int pcsc_action_open(stm_instance_t *fsmi, void *data)
{
	pcsc_raise_ors(data);

	return 1;
}

static int pcsc_action_close(stm_instance_t *fsmi, void *data)
{
#if 0
	pcsc_ifd_hd_t *rd_ctx;
	
	rd_ctx = (pcsc_ifd_hd_t *)data;
	rd_ctx->ops->close(-1);
#endif	
	return 1;
}


static int pcsc_action_erc(stm_instance_t *fsmi, void *data)
{	
	eloop_register_timeout(NULL, 0, 0, pcsc_stm_exit_delay, NULL, data);

	return 1;
}

/* This "warm up" sequence is sometimes needed when pcscd is
 * restarted with the reader already connected. We get some
 * "usb_bulk_read: Resource temporarily unavailable" on the 
 * first few tries. It is an empirical hack*/
#define ICC_STATUS_RETRY_MAX	3
static int icc_status_retry = ICC_STATUS_RETRY_MAX;

static void icc_status_complete(pcsc_ifd_hd_t *rd_ctx)
{
	uint32_t icc_status;

	if (rd_ctx->ret != PCSC_S_SUCCESS) {
		if ((--icc_status_retry) > 0) {
			pcsc_raise_to(rd_ctx);
		} else {
			pcsc_raise_csf(rd_ctx);
			icc_status_retry = ICC_STATUS_RETRY_MAX;
		}
	} else {
		icc_status = rd_ctx->slot->card_status;
		if (icc_status & PCSC_CARD_PRESENT_MASK) {
			pcsc_raise_iccp(rd_ctx);
			/* FIXME: which icc_seq */
			rd_ctx->slot->icc_seq++;
			/*
				rd_ctx->handle.reader.icc_seq++;
			*/
		} else {
			pcsc_raise_iccnp(rd_ctx);
		}
		icc_status_retry = ICC_STATUS_RETRY_MAX;
	}
}

static int pcsc_action_icc_status(stm_instance_t *fsmi, void *data)
{
	pcsc_ifd_hd_t *rdr = (pcsc_ifd_hd_t *)data;
	int r;
	
	rdr->cb = icc_status_complete;
	r = ifd_hd_icc_status(rdr);

	if (r == PCSC_S_SUCCESS)
		pcsc_raise_css(rdr);
	else
		pcsc_raise_csf(rdr);
	return 1;
}

static void power_on_complete(pcsc_ifd_hd_t *rd_ctx)
{
	pcsc_icc_t *slot;
	struct pcsc_atr_info atr_info;
	uint8_t atr[PCSC_MAX_ATR * 3];
	size_t i;

	if (rd_ctx->ret < 0) {
		if (rd_ctx->ret == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_caf(rd_ctx);
	} else {
		slot = rd_ctx->slot;
		slot->atr_len = rd_ctx->ret;
		if (pcsc_parse_atr(slot->atr, slot->atr_len, &atr_info) 
			== PCSC_S_SUCCESS) {
			slot->proto = atr_info.default_proto;
			slot->proto_supported = atr_info.supported_protos;

			for (i = 0; i < slot->atr_len; i++) {
				if (i == slot->atr_len - 1)
					sprintf(atr + i * 3, "%02X", slot->atr[i]);
				else 
					sprintf(atr + i * 3, "%02X:", slot->atr[i]);
			}
			pcsc_log(PCSC_LOG_DEBUG, "ATR: %s", atr);
			if (slot->proto_supported & PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_DEBUG, "Support protocol: T0");
			if (slot->proto_supported & PCSC_PROTOCOL_T1)
				pcsc_log(PCSC_LOG_DEBUG, "Support protocol: T1");

			if (slot->proto == PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_DEBUG, "Default protocol: T0");
		} else {
			slot->proto = PCSC_PROTOCOL_UNKNOWN;
			slot->proto_supported = PCSC_PROTOCOL_UNKNOWN;
		}	
		slot->card_status = PCSC_CARD_PRESENT_POWERUP;
		pcsc_raise_cas(rd_ctx);
	}
}

/* Active ICC*/
static int pcsc_action_aicc(stm_instance_t *fsmi, void *data)
{
	pcsc_ifd_hd_t *rd_ctx = (pcsc_ifd_hd_t *)data;
	int r;

	rd_ctx->cb = power_on_complete;
	r = ifd_hd_power_on(rd_ctx);
	if (r == PCSC_S_SUCCESS)
		pcsc_raise_cas(rd_ctx);
	else {
		if (r == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_caf(rd_ctx);
	}	
	return 1;
}

static void power_off_complete(pcsc_ifd_hd_t *rd_ctx)
{
	if (rd_ctx->ret != PCSC_S_SUCCESS) {
		if (rd_ctx->ret == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_cdf(rd_ctx);
	} else {
		pcsc_raise_cds(rd_ctx);
	}
}

/* Deactive ICC*/
static int pcsc_action_dicc(stm_instance_t *fsmi, void *data)
{
	pcsc_ifd_hd_t *rd_ctx = (pcsc_ifd_hd_t *)data;
	int r;

	rd_ctx->cb = power_off_complete;
	r = ifd_hd_power_off(rd_ctx);
	if (r != PCSC_S_SUCCESS) {
		if (r == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_cdf(rd_ctx);
	}	
	return 1;
}

/* Card Not Present*/
static int pcsc_action_cnp(stm_instance_t *fsmi, void *data)
{
	pcsc_ifd_hd_t *rd_ctx = (pcsc_ifd_hd_t *)data;

	rd_ctx->slot->card_status = PCSC_CARD_ABSENT;
#if 0
	conn_num = atomic_read(&rd_ctx->handle.refcnt);
	while (conn_num--) {
		pcsc_disconnect(&rd_ctx->handle);
	}
#endif
	return 1;
}

/* Clear handle*/
static int pcsc_action_chd(stm_instance_t *fsmi, void *data)
{
	pcsc_ifd_hd_t *ifd = (pcsc_ifd_hd_t *)data;
	
	ifd_hd_cancel(ifd);
	return 1;
}

static int pcsc_action_null(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static const stm_action_fn pcsc_act_open [] = {
	pcsc_action_open,
};

static const stm_action_fn pcsc_act_erc [] = {
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_close_erc [] = {
	pcsc_action_close,
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_icc_status [] = {
	pcsc_action_icc_status,
};

static const stm_action_fn pcsc_act_aicc [] = {
	pcsc_action_aicc,
};

static const stm_action_fn pcsc_act_cnp [] = {
	pcsc_action_cnp,
};

static const stm_action_fn pcsc_act_chd_cnp [] = {
	pcsc_action_chd,
	pcsc_action_cnp,
};

static const stm_action_fn pcsc_act_chd_dicc [] = {
	pcsc_action_chd,
	pcsc_action_dicc,
};


static const stm_action_fn pcsc_act_null [] = {
	pcsc_action_null,
};


#define STATE(state)	PCSC_STATE_##state
#define EVENT(event)	PCSC_EVENT_##event
#define ACTION(stem)	pcsc_act_##stem, \
		sizeof(pcsc_act_##stem) / sizeof(stm_action_fn) 

static const stm_entry_t pcsc_stm_entries[] = {
	/* state	event		action			new_state */
	{STATE(INIT),	EVENT(RIS),	ACTION(open),		STATE(OPEN),},

	{STATE(OPEN),	EVENT(ORS),	ACTION(icc_status),	STATE(CSTATUSING),},
#if 0
	{STATE(OPEN),	EVENT(ORF),	ACTION(erc),		STATE(EXIT),},
#endif
	{STATE(CSTATUSING),EVENT(CSS),	ACTION(null),		STATE(CSTATUSED),},
	{STATE(CSTATUSING),EVENT(CSF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(CSTATUSING),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(CSTATUSED),EVENT(CSF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(CSTATUSED),EVENT(TO),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(CSTATUSED),EVENT(ICCP),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(CSTATUSED),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(CSTATUSED),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},
	
	{STATE(PRESENT),EVENT(CAS),	ACTION(null),		STATE(POWERUP),},
	{STATE(PRESENT),EVENT(CAF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(PRESENT),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(PRESENT),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(PRESENT),EVENT(RRM),	ACTION(erc),		STATE(EXIT),},

	{STATE(ABSENT),	EVENT(CIS),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(ABSENT),	EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(POWERUP),EVENT(ICCA),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(POWERUP),EVENT(ICCD),	ACTION(chd_dicc),	STATE(DEACTIVE),},
	{STATE(POWERUP),EVENT(ICCR),	ACTION(chd_cnp),	STATE(ABSENT),},
	{STATE(POWERUP),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(DEACTIVE),EVENT(CDS),	ACTION(null),		STATE(POWERDOWN),},
	{STATE(DEACTIVE),EVENT(CDF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(DEACTIVE),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(DEACTIVE),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(DEACTIVE),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(POWERDOWN),EVENT(ICCA),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(POWERDOWN),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(POWERDOWN),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{0,		0,		ACTION(null),		0,},
};

static const char *pcsc_state_names[] = PCSC_STATE_NAMES;
static const char *pcsc_event_names[] = PCSC_EVENT_NAMES;

const stm_table_t pcsc_stm_table = {
	"pcsc",
	pcsc_stm_log,
	PCSC_STATE_COUNT,
	&pcsc_state_names[0],
	PCSC_EVENT_COUNT,
	&pcsc_event_names[0],
	pcsc_stm_entries,	
};

#undef STATE
#undef EVENT
#undef ACTION

int pcsc_icc_poweron(pcsc_ifd_hd_t *hd)
{
	pcsc_raise_icca(hd);
	return PCSC_S_SUCCESS;
}

static void pcsc_stm_exit(pcsc_ifd_hd_t *rd_ctx)
{
	if (rd_ctx->fsmi) {
		eloop_cleanup_events(NULL, rd_ctx->fsmi);
		stm_table_free(rd_ctx->fsmi);
		rd_ctx->fsmi = NULL;
	}
#if 0
	ifd_hd_free(rd_ctx);
#endif
}

static void pcsc_stm_exit_delay(void *eloop, void *user_ctx) 
{
	pcsc_stm_exit((pcsc_ifd_hd_t *)user_ctx);
}

int pcsc_card_status(int reader_idx, int slot_idx, 
		     uint32_t *icc_status)
{
#if 0
	struct pcsc_reader *reader;

	if (reader_idx >= PCSC_MAX_READERS) {
		pcsc_log(PCSC_LOG_WARN, "There is not reader %d", reader_idx);
		return PCSC_E_INVALID_PARAMETER;
	}
	if (!reader_ctx[reader_idx])
		return PCSC_E_INVALID_HANDLE;
	reader = &reader_ctx[reader_idx]->handle.reader;

	if (slot_idx >= reader->nslots)
		return PCSC_E_INVALID_PARAMETER;
	*icc_status = reader->slot[slot_idx].card_status;
#endif
	return PCSC_S_SUCCESS;
}

pcsc_ifd_hd_t *pcsc_connect(int reader_idx, int slot_idx)
{
#if 0
	uint32_t icc_status;

	if (reader_idx >= PCSC_MAX_READERS)
		return NULL;
	if ( reader_ctx[reader_idx] == NULL)
		return NULL;
	if (atomic_read(&reader_ctx[reader_idx]->handle.refcnt) > 0)
		return NULL;
	if (slot_idx >= reader_ctx[reader_idx]->handle.reader.nslots)
		return NULL;
	icc_status = reader_ctx[reader_idx]->handle.reader.slot[slot_idx].card_status;
	if (!(icc_status & PCSC_CARD_PRESENT_MASK))
		return NULL;

	atomic_inc(&reader_ctx[reader_idx]->handle.refcnt);
	reader_ctx[reader_idx]->handle.icc_seq = 
			reader_ctx[reader_idx]->handle.reader.icc_seq;

	return &reader_ctx[reader_idx]->handle;
#endif
	return NULL;
}

int pcsc_check_handle_valid(pcsc_ifd_hd_t *handle)
{
	if (!handle) return 0;
	return 0;
//	return (handle->slot->icc_seq == handle->reader->icc_seq);
}

int pcsc_disconnect(pcsc_ifd_hd_t *handle)
{
#if 0
	int i;

	for (i = 0; i < PCSC_MAX_READERS; i++) {
		if (reader_ctx[i] && &reader_ctx[i]->handle == handle) {
			atomic_dec(&reader_ctx[i]->handle.refcnt);
			return PCSC_S_SUCCESS;
		}
	}
#endif
	return PCSC_E_INVALID_HANDLE;
}

int pcsc_transmit(struct pcsc_transmit_param *param)
{
	pcsc_ifd_hd_t *rdr = param->handle;

	return rdr->ops->xfr_block(rdr, param);
}

int pcsc_ifd_control(struct pcsc_transmit_param *param)
{
	pcsc_ifd_hd_ops *ops = param->handle->ops;

	return ops->ifd_ctl(param->handle, param);		
}


/*
int pcsc_pin_verify(struct pcsc_transmit_param *param)
{
	const struct pcsc_ifd_driver *driver = param->handle->reader.driver;

	return driver->ops->pin_verify(param->handle->hd, param);
}

int pcsc_pin_modify(struct pcsc_transmit_param *param)
{
	const struct pcsc_ifd_driver *driver = param->handle->reader.driver;

	return driver->ops->pin_modify(param->handle->hd, param);
}
*/

DECLARE_LIST(pcsc_ifd_list);
DECLARE_LIST(pcsc_ifd_hd_list);

#define for_each_ifd(e)	\
	list_for_each_entry(pcsc_ifd_t, e, &pcsc_ifd_list, link)

#define for_each_ifd_hd(e)	\
	list_for_each_entry(pcsc_ifd_hd_t, e, &pcsc_ifd_hd_list, link)

pcsc_ifd_t *ifd_get(pcsc_ifd_t *rdr)
{
	atomic_inc(&rdr->refcnt);
	return rdr;
}

void ifd_put(pcsc_ifd_t *rdr)
{
	atomic_dec(&rdr->refcnt);
}

pcsc_ifd_t *ifd_find(const char *name, int type)
{
	pcsc_ifd_t *rdr;

	for_each_ifd(rdr) {
		if (strcasecmp(rdr->name, name) == 0 &&
		    rdr->type == type)
		    return rdr;
	}
	return NULL;
}


static int ifd_start(pcsc_ifd_t *rdr)
{
	pcsc_ifd_hd_t *hd;
	for_each_ifd_hd(hd) {
		if (hd->reader == rdr) {
			ifd_hd_start(hd);
		}
	}
	return -1;
}

static int ifd_stop(pcsc_ifd_t *rdr)
{
	pcsc_ifd_hd_t *hd;
	for_each_ifd_hd(hd) {
		if (hd->reader == rdr) {
			ifd_hd_stop(hd);
		}
	}
	return -1;
}


/* check whether support PinPad/Display */
static void ifd_get_feature(pcsc_ifd_t *ifd)
{
	pcsc_ifd_hd_t *hd;
	for_each_ifd_hd(hd) {
		if (hd->reader == ifd && hd->ops->get_feature) {
			ifd_hd_get_feature(hd);
			/* if reader has more than one hd, only get 
			 * feature once or?
			 */
			break;
		}
	}
}

static void ifd_icc_status(pcsc_ifd_t *ifd)
{

}

static pcsc_ifd_hd_t *ifd_hd_new(pcsc_ifd_t *rdr, void *lower, pcsc_ifd_hd_ops *ops)
{
	pcsc_ifd_hd_t *hd;

	hd = malloc(sizeof (pcsc_ifd_hd_t));
	if (!hd)
		goto err;

	memset(hd, 0, sizeof (pcsc_ifd_hd_t));
	
	hd->slot = rdr->slots;
	hd->slot_idx = 0;	/* only has 1 slot now */
	hd->icc_present = hd->slot->card_status;
	hd->ops = ops;
	hd->lower = lower;
	/* use rdr name now */
	hd->fsmi = stm_table_new(&pcsc_stm_table, rdr->name, PCSC_STATE_INIT);
	if (!hd->fsmi)
		goto err;
	list_init(&hd->link);
	list_insert_before(&hd->link, &pcsc_ifd_hd_list);

	atomic_set(&hd->refcnt, 1);
	hd->reader = ifd_get(rdr);

	return hd;
err:
	if (hd)
		free(hd);
	return NULL;
}

static void ifd_hd_free(pcsc_ifd_hd_t *hd)
{
	if (hd->fsmi) {
		stm_table_free(hd->fsmi);
	}
	list_delete(&hd->link);
	ifd_put(hd->reader);
	free(hd);
}

static pcsc_ifd_t *ifd_new(const char *name, int type)
{
	pcsc_ifd_t *rdr;

	rdr = malloc(sizeof (pcsc_ifd_t));
	if (!rdr)
		goto err;

	memset(rdr, 0, sizeof (pcsc_ifd_t));

	/* Here we only support one slot. 
	 * TODO: support multi-slots reader */
	rdr->slots = malloc(sizeof (pcsc_icc_t));
	if (!rdr->slots)
		goto err;
	memset(rdr->slots, 0, sizeof (pcsc_icc_t));
	rdr->slots[0].card_status = PCSC_CARD_STATUS_UNKNOWN;
	rdr->nslots = 1;

	rdr->type = type;
	rdr->name = strdup(name);
	rdr->reader_status = PCSC_READER_STATUS_PRESENT;
	list_init(&rdr->link);
	list_insert_before(&rdr->link, &pcsc_ifd_list);

	atomic_set(&rdr->refcnt, 1);

	return rdr;
err:
	/* NOTE slot number */
	if (rdr->slots)
		free(rdr->slots);
	if (rdr->name) 
		free(rdr->name);
	free(rdr);
	return NULL;
}

static void ifd_free(pcsc_ifd_t *rdr)
{
	if (atomic_dec_and_test(&rdr->refcnt)) {
		if (rdr->name) free(rdr->name);
		list_delete(&rdr->link);
		free(rdr);
	}
}

/* lower reader up
 * create new ifd_t and ifd_hd_t
 *
 * reader		- ifd_t
 * reader handle	- ifd_hd_t
 * handle use the default slot(first one) on reader.
 * TODO: if there are more than 1 slot on this reader
 */
int pcsc_ifd_handle_up(const char *name, int type, void *lower, pcsc_ifd_hd_ops *ops)
{
	pcsc_ifd_t *rdr = ifd_find(name, type);
	pcsc_ifd_hd_t *hd;

	if (rdr) {
		pcsc_log(PCSC_LOG_INFO, "IFD: handle=%s/%d has up before",
			name, type);
		BUG();
	}
	
	rdr = ifd_new(name, type);
	
	if (rdr) {
		/* new ifd need attach to a handle. */
		hd = ifd_hd_new(rdr, lower, ops);
		if (!hd) {
			ifd_free(rdr);
			return -1;
		}
		ifd_get_feature(rdr);
		ifd_start(rdr);
	}

	return -1;
}

int pcsc_ifd_handle_down(const char *name, int type, void *lower)
{
	pcsc_ifd_t *rdr = ifd_find(name, type);
	
	if (rdr) {
		ifd_stop(rdr);
		ifd_free(rdr);
	}
	return -1;
}

int pcsc_icc_poweroff(pcsc_ifd_hd_t *hd)
{
	pcsc_raise_iccd(hd);
	return PCSC_S_SUCCESS;
}

int pcsc_icc_insert(pcsc_ifd_hd_t *hd)
{
	pcsc_raise_cis(hd);
	return PCSC_S_SUCCESS;
}

int pcsc_icc_remove(pcsc_ifd_hd_t *hd)
{
	pcsc_raise_iccr(hd);
	return PCSC_S_SUCCESS;
}
