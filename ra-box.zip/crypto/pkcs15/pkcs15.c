#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

static void pkcs15_bind_stm_exit_delay(void *eloop, void *user_ctx);

struct pkcs15_handle *pkcs15_handle_new(void)
{
	struct pkcs15_handle *p15_handle;

	p15_handle = malloc(sizeof(struct pkcs15_handle));
	if (!p15_handle)
		return NULL;
	memset(p15_handle, 0, sizeof(struct pkcs15_handle));

	list_init(&p15_handle->df_list);
	list_init(&p15_handle->obj_list);

	return p15_handle;
}

void pkcs15_handle_free(struct pkcs15_handle *p15_handle)
{
	struct pkcs15_df *pos_df, *n_df;
	struct pkcs15_object *pos_obj, *n_obj;

	if (!p15_handle) return;
	/* TODO: free members */

	list_for_each_entry_safe(struct pkcs15_df, pos_df, n_df,
				 &p15_handle->df_list, link) {
		list_delete(&pos_df->link);
		if (pos_df->filp)
			scard_file_free(pos_df->filp);
		free(pos_df);
	}
	list_for_each_entry_safe(struct pkcs15_object, pos_obj, n_obj,
				 &p15_handle->obj_list, link) {
		list_delete(&pos_obj->link);
		pkcs15_free_object(pos_obj);
	}
	
	if (p15_handle->app_root)
		scard_file_free(p15_handle->app_root);
	if (p15_handle->odf)
		scard_file_free(p15_handle->odf);
	if (p15_handle->tif)
		scard_file_free(p15_handle->tif);
	if (p15_handle->unused)
		scard_file_free(p15_handle->unused);
	if (p15_handle->tokeninfo.serial_num)
		free(p15_handle->tokeninfo.serial_num);
	if (p15_handle->tokeninfo.manufacturer_id)
		free(p15_handle->tokeninfo.manufacturer_id);
	if (p15_handle->tokeninfo.label)
		free(p15_handle->tokeninfo.label);
	if (p15_handle->tokeninfo.last_update)
		free(p15_handle->tokeninfo.last_update);
	if (p15_handle->tokeninfo.prefered_lang)
		free(p15_handle->tokeninfo.prefered_lang);
	if (p15_handle->tokeninfo.sec_info) {
		size_t i;

		for (i = 0; i < p15_handle->tokeninfo.sec_info_num; i++) {
			free(p15_handle->tokeninfo.sec_info[i]);
		}
		free(p15_handle->tokeninfo.sec_info);
	}
	
	free(p15_handle);
}

int pkcs15_free_object(struct pkcs15_object *obj)
{
	return PKCS15_SUCCESS;
}

struct pkcs15_bind_trans {
	const char	*name;
	stm_instance_t *fsmi;
	
	uint8_t rec_nr;
	size_t	rec_size;

	uint8_t *sbuf;
	size_t	sbuf_len;
	uint8_t *rbuf;
	size_t	rbuf_len;
	size_t	rbuf_actual;

	struct pkcs15_handle **handle_out, *p15_handle;
	scard_cmd_complete callback;
	void *user_data;

	int ret;
};

static void pkcs15_bind_stm_log(const stm_instance_t *fsmi,
				int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

#define PKCS15_BIND_STATE_INIT		0
#define PKCS15_BIND_STATE_SELECT_DIR	1
#define PKCS15_BIND_STATE_READ_DIR	2
#define PKCS15_BIND_STATE_PARSE_DIR	3
#define PKCS15_BIND_STATE_SELECT_ROOT	4
#define PKCS15_BIND_STATE_SELECT_ODF	5
#define PKCS15_BIND_STATE_READ_ODF	6
#define PKCS15_BIND_STATE_PARSE_ODF	7
#define PKCS15_BIND_STATE_SELECT_INFO	8
#define PKCS15_BIND_STATE_READ_INFO	9
#define PKCS15_BIND_STATE_PARSE_INFO	10
#define PKCS15_BIND_STATE_EXIT		11

#define PKCS15_BIND_STATE_COUNT		12

#define PKCS15_BIND_STATE_NAMES {	\
	"INIT",				\
	"SELECT_DIR",			\
	"READ_DIR",			\
	"PARSE_DIR",			\
	"SELECT_ROOT",			\
	"SELECT_ODF",			\
	"READ_ODF",			\
	"PARSE_ODF",			\
	"SELECT_INFO",			\
	"READ_INFO",			\
	"PARSE_INFO",			\
	"EXIT",				\
}
#define PKCS15_BIND_EVENT_BIND		0
#define PKCS15_BIND_EVENT_SSDS		1
#define PKCS15_BIND_EVENT_SSDF		2
#define PKCS15_BIND_EVENT_RSDS		3
#define PKCS15_BIND_EVENT_RSDF		4
#define PKCS15_BIND_EVENT_SRDS		5
#define PKCS15_BIND_EVENT_SRDF		6
#define PKCS15_BIND_EVENT_RRDS		7
#define PKCS15_BIND_EVENT_DNF		8
#define PKCS15_BIND_EVENT_RRDF		9
#define PKCS15_BIND_EVENT_RNR		9
#define PKCS15_BIND_EVENT_PDS		10
#define PKCS15_BIND_EVENT_PDF		11
#define PKCS15_BIND_EVENT_SSRS		12
#define PKCS15_BIND_EVENT_SSRF		13
#define PKCS15_BIND_EVENT_RSRS		14
#define PKCS15_BIND_EVENT_SSRA		15
#define PKCS15_BIND_EVENT_RSRF		16
#define PKCS15_BIND_EVENT_SSOS		17
#define PKCS15_BIND_EVENT_SSOF		18
#define PKCS15_BIND_EVENT_RSOS		19
#define PKCS15_BIND_EVENT_RSOF		20
#define PKCS15_BIND_EVENT_SROS		21
#define PKCS15_BIND_EVENT_SROF		22
#define PKCS15_BIND_EVENT_RROS		23
#define PKCS15_BIND_EVENT_RROF		24
#define PKCS15_BIND_EVENT_POS		25
#define PKCS15_BIND_EVENT_POF		26
#define PKCS15_BIND_EVENT_SSIS		27
#define PKCS15_BIND_EVENT_SSIF		28
#define PKCS15_BIND_EVENT_RSIS		29
#define PKCS15_BIND_EVENT_RSIF		30
#define PKCS15_BIND_EVENT_SRIS		31
#define PKCS15_BIND_EVENT_SRIF		32
#define PKCS15_BIND_EVENT_RRIS		33
#define PKCS15_BIND_EVENT_RRIF		34
#define PKCS15_BIND_EVENT_PIS		35
#define PKCS15_BIND_EVENT_PIF		36

#define PKCS15_BIND_EVENT_COUNT		37

#define PKCS15_BIND_EVENT_NAMES {	\
	"BIND"				\
	"SSDS",				\
	"SSDF",				\
	"RSDS",				\
	"DNF",				\
	"RSDF",				\
	"SRDS",				\
	"SRDF",				\
	"RRDS",				\
	"RRDF",				\
	"RNR",				\
	"PDS",				\
	"PDF",				\
	"SSRS",				\
	"SSRF",				\
	"RSRS",				\
	"SSRA",				\
	"RSRF",				\
	"SSOS",				\
	"SSOF",				\
	"RSOS",				\
	"RSOF",				\
	"SROS",				\
	"SROF",				\
	"RROS",				\
	"RROF",				\
	"POS",				\
	"POF",				\
	"SSIS",				\
	"SSIF",				\
	"RSIS",				\
	"RSIF",				\
	"SRIS",				\
	"SRIF",				\
	"RRIS",				\
	"RRIF",				\
	"PIS",				\
	"PIF",				\
}

static void pkcs15_bind_raise_event(struct pkcs15_bind_trans *p15_bind_trans,
				    int event)
{
	eloop_schedule_event(NULL, p15_bind_trans->fsmi, event, p15_bind_trans);
}

static void pkcs15_bind_raise_bind(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_BIND);
}

static void pkcs15_bind_raise_ssds(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SSDS);
}

static void pkcs15_bind_raise_ssdf(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SSDF);
}

static void pkcs15_bind_raise_rsds(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RSDS);
}

static void pkcs15_bind_raise_dnf(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_DNF);
}

static void pkcs15_bind_raise_rsdf(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RSDF);
}

static void pkcs15_bind_raise_srds(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SRDS);
}

static void pkcs15_bind_raise_srdf(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SRDF);
}

static void pkcs15_bind_raise_rrds(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RRDS);
}

static void pkcs15_bind_raise_rrdf(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RRDF);
}

/* Read Next Record */
static void pkcs15_bind_raise_rnr(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RNR);
}

static void pkcs15_bind_raise_pds(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_PDS);
}

static void pkcs15_bind_raise_pdf(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_PDF);
}

static void pkcs15_bind_raise_ssrs(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SSRS);
}

static void pkcs15_bind_raise_ssrf(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SSRF);
}

static void pkcs15_bind_raise_rsrs(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RSRS);
}

static void pkcs15_bind_raise_ssra(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SSRA);
}

static void pkcs15_bind_raise_rsrf(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RSRF);
}

static void pkcs15_bind_raise_ssos(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SSOS);
}

static void pkcs15_bind_raise_ssof(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SSOF);
}

static void pkcs15_bind_raise_rsos(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RSOS);
}

static void pkcs15_bind_raise_rsof(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RSOF);
}

static void pkcs15_bind_raise_sros(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SROS);
}

static void pkcs15_bind_raise_srof(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SROF);
}

static void pkcs15_bind_raise_rros(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RROS);
}

static void pkcs15_bind_raise_rrof(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RROF);
}

static void pkcs15_bind_raise_pos(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_POS);
}

static void pkcs15_bind_raise_pof(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_POF);
}

static void pkcs15_bind_raise_ssis(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SSIS);
}

static void pkcs15_bind_raise_ssif(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SSIF);
}

static void pkcs15_bind_raise_rsis(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RSIS);
}

static void pkcs15_bind_raise_rsif(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RSIF);
}

static void pkcs15_bind_raise_sris(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SRIS);
}

static void pkcs15_bind_raise_srif(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_SRIF);
}

static void pkcs15_bind_raise_rris(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RRIS);
}

static void pkcs15_bind_raise_rrif(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_RRIF);
}

static void pkcs15_bind_raise_pis(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_PIS);
}

static void pkcs15_bind_raise_pif(struct pkcs15_bind_trans *p15_bind_trans)
{
	pkcs15_bind_raise_event(p15_bind_trans, PKCS15_BIND_EVENT_PIF);
}

static int pkcs15_bind_action_null(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static int pkcs15_bind_action_itc(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;

	p15_handle->app_root = scard_file_new();
	if (p15_handle->app_root == NULL) {
		p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
		pkcs15_bind_raise_ssdf(p15_bind_trans);
		return 1;
	}

	return 1;
}

static int pkcs15_bind_action_etc(stm_instance_t *fsmi, void *data)
{
	eloop_register_timeout(NULL, 0, 0, pkcs15_bind_stm_exit_delay, NULL, data);

	return 1;
}

static void select_dir_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;

	if (ret == SCARD_SUCCESS) {
		pkcs15_bind_raise_rsds(p15_bind_trans);
		p15_bind_trans->rec_nr = 1;
	} else if (ret ==  SCARD_ERR_FILE_NOT_FOUND){
		scard_format_path("3F005015", 
			&p15_bind_trans->p15_handle->app_root->path);
		pkcs15_bind_raise_dnf(p15_bind_trans);
	} else {
		pkcs15_bind_raise_rsdf(p15_bind_trans);
	}
}

static int pkcs15_bind_action_select_dir(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct scard_handle *card_handle = p15_bind_trans->p15_handle->card_handle;
	struct scard_path dir_path;
	int r;

	if (!scard_handle_check_valid(card_handle)) {
		p15_bind_trans->ret = PKCS15_ERR_INVALID_HANDLE;
		pkcs15_bind_raise_ssrf(p15_bind_trans);
		return 1;
	}
	if (scard_check_icc_present_pwd(card_handle) <= 0) {
		p15_bind_trans->ret = PKCS15_ERR_CARD_INACTIVE;
		pkcs15_bind_raise_ssrf(p15_bind_trans);
		return 1;
	}
	
	scard_format_path("3F002F00", &dir_path);
	dir_path.type = SCARD_PATH_TYPE_PATH;

	r = scard_select_file(card_handle, &dir_path, &card_handle->ef_dir, 
				select_dir_complete, p15_bind_trans);
	if (r != SCARD_SUCCESS) {
		p15_bind_trans->ret = r;
		pkcs15_bind_raise_ssdf(p15_bind_trans);
	}
	pkcs15_bind_raise_ssds(p15_bind_trans);
		
	return 1;
}

static void read_dir_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;
	
	if (ret == SCARD_ERR_RECORD_NOT_FOUND) {
		pkcs15_bind_raise_rrds(p15_bind_trans);
	} else if (ret >= 0) {
		p15_bind_trans->rbuf_actual = ret;
		pkcs15_bind_raise_rrds(p15_bind_trans);
	} else {
		p15_bind_trans->ret = ret;
		pkcs15_bind_raise_rrdf(p15_bind_trans);
	}
}

static int pkcs15_bind_action_read_dir(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct scard_handle *card_handle = 
			p15_bind_trans->p15_handle->card_handle;
	struct scard_file *ef_dir = card_handle->ef_dir;
	uint8_t *rbuf;
	size_t rbuf_len;
	int r;
	
	if (!scard_handle_check_valid(card_handle)) {
		p15_bind_trans->ret = PKCS15_ERR_INVALID_HANDLE;
		goto srdf;
	}
	if (scard_check_icc_present_pwd(card_handle) <= 0) {
		p15_bind_trans->ret = PKCS15_ERR_CARD_INACTIVE;
		goto srdf;
	}

	if (ef_dir->ef_structure == SCARD_FILE_EF_TRANSPARENT) {
		rbuf_len = ef_dir->size;
		rbuf = malloc(rbuf_len);
		if (rbuf == NULL) {
			p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
			goto srdf;
		}
		memset(rbuf, 0, rbuf_len);
		p15_bind_trans->rbuf = rbuf;
		p15_bind_trans->rbuf_len = rbuf_len;
		r = scard_read_binary(card_handle, 0, rbuf, rbuf_len, 0,
			read_dir_complete, p15_bind_trans);
		if (r != SCARD_SUCCESS) {
			p15_bind_trans->ret = r;
			free(rbuf);
			goto srdf;
		}
	} else {
		rbuf_len = ef_dir->record_length;
		rbuf = malloc(rbuf_len);
		if (rbuf == NULL) {
			p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
			goto srdf;
		}
		memset(rbuf, 0, rbuf_len);
		p15_bind_trans->rbuf = rbuf;
		p15_bind_trans->rbuf_len = rbuf_len;
		r = scard_read_record(card_handle, p15_bind_trans->rec_nr++,
				      rbuf, rbuf_len, SCARD_RECORD_BY_REC_NR, 
				      read_dir_complete, p15_bind_trans);
		if (r != SCARD_SUCCESS) {
			p15_bind_trans->ret = r;
			free(rbuf);
			goto srdf;
		}
	}

	pkcs15_bind_raise_srds(p15_bind_trans);
	return 1;
srdf:
	pkcs15_bind_raise_srdf(p15_bind_trans);

	return 1;
}

static int pkcs15_bind_action_parse_dir(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct scard_handle *card_handle = p15_bind_trans->p15_handle->card_handle;
	struct scard_file *ef_dir = card_handle->ef_dir;
	uint8_t *p, *rbuf = p15_bind_trans->rbuf;
	size_t rbuf_actual = p15_bind_trans->rbuf_actual;
	int r;

	p = rbuf;
	if (ef_dir->ef_structure == SCARD_FILE_EF_TRANSPARENT) {
		while (rbuf_actual > 0) {
			if (card_handle->app_count == SCARD_APP_MAX) 
				goto pds;
			r = parse_dir_record(card_handle, &p, &rbuf_actual, -1);
			if (r != SCARD_SUCCESS)
				break;
		}
		goto pds;
	} else {
		if (p15_bind_trans->ret == SCARD_ERR_RECORD_NOT_FOUND) {
			p15_bind_trans->ret = SCARD_SUCCESS;
			goto pds;
		}
		if (card_handle->app_count == SCARD_APP_MAX)
			goto pds;
		parse_dir_record(card_handle, &p, &rbuf_actual, 
				(int)rbuf_actual);
		goto rnr;/* read next app record */
	}

rnr:
	free(rbuf);
	pkcs15_bind_raise_rnr(p15_bind_trans);
	return 1;
pds:
	if (rbuf) free(rbuf);
	pkcs15_bind_raise_pds(p15_bind_trans);

	return 1;
}

static int pkcs15_bind_action_find_app(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;

	scard_format_path("3F005015", &p15_handle->app_root->path);
	if (p15_handle->card_handle->app_count > 0) {
		const struct scard_app_info *info;

		info = pkcs15_find_app(p15_handle->card_handle);
		if (info) {
			if (info->path.len)
				p15_handle->app_root->path = info->path;
			if (info->ddo)
				parse_ddo(p15_handle, info->ddo, info->ddo_len);
		}
	}
	
	return 1;
}

/* Set App Root path*/
static int pkcs15_bind_action_sar(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static void select_root_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;

	if (ret == SCARD_SUCCESS) {
		pkcs15_bind_raise_rsrs(p15_bind_trans);
	} else if (ret == SCARD_ERR_FILE_NOT_FOUND) {
		scard_format_path("3F00", 
			&p15_bind_trans->p15_handle->app_root->path);
		pkcs15_bind_raise_ssra(p15_bind_trans);
	} else {
		pkcs15_bind_raise_rsrf(p15_bind_trans);
	}
}

static int pkcs15_bind_action_select_root(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct scard_file *app_root = p15_bind_trans->p15_handle->app_root;
	struct scard_handle *card_handle = p15_bind_trans->p15_handle->card_handle;
	int r;

	if (!scard_handle_check_valid(card_handle)) {
		p15_bind_trans->ret = PKCS15_ERR_INVALID_HANDLE;
		pkcs15_bind_raise_ssrf(p15_bind_trans);
		return 1;
	}
	if (scard_check_icc_present_pwd(card_handle) <= 0) {
		p15_bind_trans->ret = PKCS15_ERR_CARD_INACTIVE;
		pkcs15_bind_raise_ssrf(p15_bind_trans);
		return 1;
	}
	
	r = scard_select_file(card_handle, &app_root->path, NULL, 
				select_root_complete, p15_bind_trans);
	if (r != SCARD_SUCCESS) {
		p15_bind_trans->ret = r;
		pkcs15_bind_raise_ssrf(p15_bind_trans);
	}

	pkcs15_bind_raise_ssrs(p15_bind_trans);
	
	return 1;
}

static void select_odf_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;

	if (ret == SCARD_SUCCESS) {
		pkcs15_bind_raise_rsos(p15_bind_trans);
	} else {
		pkcs15_bind_raise_rsof(p15_bind_trans);
	}
}

static int pkcs15_bind_action_select_odf(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;
	struct scard_handle *card_handle = p15_handle->card_handle;
	struct scard_path tmppath;
	int r;

	if (!scard_handle_check_valid(card_handle)) {
		p15_bind_trans->ret = PKCS15_ERR_INVALID_HANDLE;
		pkcs15_bind_raise_ssrf(p15_bind_trans);
		return 1;
	}

	if (scard_check_icc_present_pwd(card_handle) <= 0) {
		p15_bind_trans->ret = PKCS15_ERR_CARD_INACTIVE;
		pkcs15_bind_raise_ssrf(p15_bind_trans);
		return 1;
	}

	if (p15_handle->odf) {
		tmppath = p15_handle->odf->path;
		scard_file_free(p15_handle->odf);
		p15_handle->odf = NULL;
	} else {
		tmppath = p15_handle->app_root->path;
		scard_append_path_id(&tmppath, (const uint8_t *) "\x50\x31", 2);
	}
	
	r = scard_select_file(card_handle, &tmppath, &p15_handle->odf, 
				select_odf_complete, p15_bind_trans);
	if (r != SCARD_SUCCESS) {
		p15_bind_trans->ret = r;
		pkcs15_bind_raise_ssof(p15_bind_trans);
	}

	pkcs15_bind_raise_ssos(p15_bind_trans);
	
	return 1;
}

static void read_odf_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;
	
	if (ret >= 0) {
		p15_bind_trans->rbuf_actual = ret;
		pkcs15_bind_raise_rros(p15_bind_trans);
	} else {
		p15_bind_trans->ret = PKCS15_ERR_OTHER;
		pkcs15_bind_raise_rrof(p15_bind_trans);
	}
}

static int pkcs15_bind_action_read_odf(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;
	struct scard_handle *card_handle = p15_handle->card_handle;
	struct scard_file *app_odf = p15_handle->odf;
	uint8_t *rbuf;
	size_t rbuf_len;
	int r;
	
	if (!scard_handle_check_valid(card_handle)) {
		p15_bind_trans->ret = PKCS15_ERR_INVALID_HANDLE;
		goto srof;
	}
	if (scard_check_icc_present_pwd(card_handle) <= 0) {
		p15_bind_trans->ret = PKCS15_ERR_CARD_INACTIVE;
		goto srof;
	}

	rbuf_len = app_odf->size;
	rbuf = malloc(rbuf_len);
	if (rbuf == NULL) {
		p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
		goto srof;
	}
	memset(rbuf, 0, rbuf_len);
	p15_bind_trans->rbuf = rbuf;
	p15_bind_trans->rbuf_len = rbuf_len;
	r = scard_read_binary(card_handle, 0, rbuf, rbuf_len, 0,
		read_odf_complete, p15_bind_trans);
	if (r != SCARD_SUCCESS) {
		p15_bind_trans->ret = r;
		free(rbuf);
		goto srof;
	}

	pkcs15_bind_raise_sros(p15_bind_trans);
	return 1;
srof:
	pkcs15_bind_raise_srof(p15_bind_trans);

	return 1;
}

static int pkcs15_bind_action_parse_odf(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;
	int r;

	r = parse_odf(p15_bind_trans->rbuf, p15_bind_trans->rbuf_actual, p15_handle);
	if (r == PKCS15_SUCCESS)
		pkcs15_bind_raise_pos(p15_bind_trans);
	else 
		pkcs15_bind_raise_pof(p15_bind_trans);

	return 1;
}

static void select_tokeninfo_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;

	if (ret == SCARD_SUCCESS) {
		pkcs15_bind_raise_rsis(p15_bind_trans);
	} else {
		pkcs15_bind_raise_rsif(p15_bind_trans);	
	}
}

static int pkcs15_bind_action_select_info(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;
	struct scard_handle *card_handle = p15_handle->card_handle;
	struct scard_path tmppath;
	int r;

	if (!scard_handle_check_valid(card_handle)) {
		p15_bind_trans->ret = PKCS15_ERR_INVALID_HANDLE;
		pkcs15_bind_raise_ssrf(p15_bind_trans);
		return 1;
	}

	if (scard_check_icc_present_pwd(card_handle) <= 0) {
		p15_bind_trans->ret = PKCS15_ERR_CARD_INACTIVE;
		pkcs15_bind_raise_ssrf(p15_bind_trans);
		return 1;
	}

	if (p15_handle->tif) {
		tmppath = p15_handle->tif->path;
		scard_file_free(p15_handle->tif);
		p15_handle->odf = NULL;
	} else {
		tmppath = p15_handle->app_root->path;
		scard_append_path_id(&tmppath, (const uint8_t *) "\x50\x32", 2);
	}
		
	r = scard_select_file(card_handle, &tmppath, &p15_handle->tif, 
				select_tokeninfo_complete, p15_bind_trans);
	if (r != SCARD_SUCCESS) {
		p15_bind_trans->ret = r;
		pkcs15_bind_raise_ssif(p15_bind_trans);
	}

	pkcs15_bind_raise_ssis(p15_bind_trans);
	
	return 1;
}

static void read_tokeninfo_complete(void *user_data, int ret)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)user_data;
	if (ret >= 0) {
		p15_bind_trans->rbuf_actual = ret;
		pkcs15_bind_raise_rris(p15_bind_trans);
	} else {
		free(p15_bind_trans->rbuf);
		p15_bind_trans->ret = PKCS15_ERR_OTHER;
		pkcs15_bind_raise_rrif(p15_bind_trans);
	}
}

static int pkcs15_bind_action_read_info(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_handle *p15_handle = p15_bind_trans->p15_handle;
	struct scard_handle *card_handle = p15_handle->card_handle;
	struct scard_file *app_tokeninfo = p15_handle->tif;
	uint8_t *rbuf;
	size_t rbuf_len;
	int r;
	
	if (!scard_handle_check_valid(card_handle)) {
		p15_bind_trans->ret = PKCS15_ERR_INVALID_HANDLE;
		goto srif;
	}
	if (scard_check_icc_present_pwd(card_handle) <= 0) {
		p15_bind_trans->ret = PKCS15_ERR_CARD_INACTIVE;
		goto srif;
	}

	rbuf_len = app_tokeninfo->size;
	rbuf = malloc(rbuf_len);
	if (rbuf == NULL) {
		p15_bind_trans->ret = PKCS15_ERR_NO_MEM;
		goto srif;
	}
	memset(rbuf, 0, rbuf_len);
	p15_bind_trans->rbuf = rbuf;
	p15_bind_trans->rbuf_len = rbuf_len;
	r = scard_read_binary(card_handle, 0, rbuf, rbuf_len, 0,
		read_tokeninfo_complete, p15_bind_trans);
	if (r != SCARD_SUCCESS) {
		p15_bind_trans->ret = r;
		free(rbuf);
		goto srif;
	}

	pkcs15_bind_raise_sris(p15_bind_trans);
	return 1;
srif:
	pkcs15_bind_raise_srif(p15_bind_trans);

	return 1;
}

static int pkcs15_bind_action_parse_info(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	struct pkcs15_tokeninfo *tokeninfo = 
			&p15_bind_trans->p15_handle->tokeninfo;
	int r;
	
	memset(tokeninfo, 0, sizeof(struct pkcs15_tokeninfo));
	r = pkcs15_parse_tokeninfo(tokeninfo, p15_bind_trans->rbuf,
				   p15_bind_trans->rbuf_actual);
	if (r != PKCS15_SUCCESS)
		pkcs15_bind_raise_pif(p15_bind_trans);
	else 
		pkcs15_bind_raise_pis(p15_bind_trans);		

	free(p15_bind_trans->rbuf);
	return 1;
}

static int pkcs15_bind_action_init_handle(stm_instance_t *fsmi, void *data)
{
	struct pkcs15_bind_trans *p15_bind_trans = 
			(struct pkcs15_bind_trans *)data;
	
	*p15_bind_trans->handle_out = p15_bind_trans->p15_handle;

	return 1;
}

static const stm_action_fn pkcs15_bind_act_null [] = {
	pkcs15_bind_action_null,
};

static const stm_action_fn pkcs15_bind_act_itc_select_dir[] = {
	pkcs15_bind_action_itc,
	pkcs15_bind_action_select_dir,
};

static const stm_action_fn pkcs15_bind_act_etc[] = {
	pkcs15_bind_action_etc,
};

static const stm_action_fn pkcs15_bind_act_read_dir[] = {
	pkcs15_bind_action_read_dir,
};

static const stm_action_fn pkcs15_bind_act_parse_dir[] = {
	pkcs15_bind_action_parse_dir,
};

static const stm_action_fn pkcs15_bind_act_sar_select_root[] = {
	pkcs15_bind_action_sar,
	pkcs15_bind_action_select_root,
};

static const stm_action_fn pkcs15_bind_act_find_app_sar_select_root[] = {
	pkcs15_bind_action_find_app,
	pkcs15_bind_action_sar,
	pkcs15_bind_action_select_root,
};

static const stm_action_fn pkcs15_bind_act_select_odf[] = {
	pkcs15_bind_action_select_odf,
};

static const stm_action_fn pkcs15_bind_act_read_odf[] = {
	pkcs15_bind_action_read_odf,
};

static const stm_action_fn pkcs15_bind_act_parse_odf[] = {
	pkcs15_bind_action_parse_odf,
};

static const stm_action_fn pkcs15_bind_act_select_info[] = {
	pkcs15_bind_action_select_info,
};

static const stm_action_fn pkcs15_bind_act_read_info[] = {
	pkcs15_bind_action_read_info,
};

static const stm_action_fn pkcs15_bind_act_parse_info[] = {
	pkcs15_bind_action_parse_info,
};

static const stm_action_fn pkcs15_bind_act_init_handle_etc[] = {
	pkcs15_bind_action_init_handle,
	pkcs15_bind_action_etc,
};

#define STATE(state)	PKCS15_BIND_STATE_##state
#define EVENT(event)	PKCS15_BIND_EVENT_##event
#define ACTION(stem)	pkcs15_bind_act_##stem, \
		sizeof(pkcs15_bind_act_##stem) / sizeof(stm_action_fn) 
static const stm_entry_t pkcs15_bind_stm_entries[] = {
	/* state	event		action					new_state */
	{STATE(INIT),		EVENT(BIND),	ACTION(itc_select_dir),			STATE(SELECT_DIR),},

	{STATE(SELECT_DIR),	EVENT(SSDS),	ACTION(null),				STATE(SELECT_DIR),},
	{STATE(SELECT_DIR),	EVENT(SSDF),	ACTION(etc),				STATE(EXIT),},
	{STATE(SELECT_DIR),	EVENT(RSDS),	ACTION(read_dir),			STATE(READ_DIR),},
	{STATE(SELECT_DIR),	EVENT(DNF),	ACTION(sar_select_root),		STATE(SELECT_ROOT),},
	{STATE(SELECT_DIR),	EVENT(RRDF),	ACTION(etc),				STATE(EXIT),},

	{STATE(READ_DIR),	EVENT(SRDS),	ACTION(null),				STATE(READ_DIR),},
	{STATE(READ_DIR),	EVENT(SRDF),	ACTION(etc),				STATE(EXIT),},
	{STATE(READ_DIR),	EVENT(RRDS),	ACTION(parse_dir),			STATE(PARSE_DIR),},
	{STATE(READ_DIR),	EVENT(RRDF),	ACTION(etc),				STATE(EXIT),},

	{STATE(PARSE_DIR),	EVENT(RNR),	ACTION(read_dir),			STATE(READ_DIR),},
	{STATE(PARSE_DIR),	EVENT(PDS),	ACTION(find_app_sar_select_root),	STATE(SELECT_ROOT),},
	{STATE(PARSE_DIR),	EVENT(PDF),	ACTION(etc),				STATE(EXIT),},
	
	{STATE(SELECT_ROOT),	EVENT(SSRS),	ACTION(null),				STATE(SELECT_ROOT),},
	{STATE(SELECT_ROOT),	EVENT(SSRF),	ACTION(etc),				STATE(EXIT),},
	{STATE(SELECT_ROOT),	EVENT(RSRS),	ACTION(select_odf),			STATE(SELECT_ODF),},
	{STATE(SELECT_ROOT),	EVENT(SSRA),	ACTION(sar_select_root),		STATE(SELECT_ROOT),},
	{STATE(SELECT_ROOT),	EVENT(RSRF),	ACTION(etc),				STATE(EXIT),},

	{STATE(SELECT_ODF),	EVENT(SSOS),	ACTION(null),				STATE(SELECT_ODF),},
	{STATE(SELECT_ODF),	EVENT(SSOF),	ACTION(etc),				STATE(EXIT),},
	{STATE(SELECT_ODF),	EVENT(RSOS),	ACTION(read_odf),			STATE(READ_ODF),},
	{STATE(SELECT_ODF),	EVENT(RSOF),	ACTION(etc),				STATE(EXIT),},

	{STATE(READ_ODF),	EVENT(SROS),	ACTION(null),				STATE(READ_ODF),},
	{STATE(READ_ODF),	EVENT(SROF),	ACTION(etc),				STATE(EXIT),},
	{STATE(READ_ODF),	EVENT(RROS),	ACTION(parse_odf),			STATE(PARSE_ODF),},
	{STATE(READ_ODF),	EVENT(RROF),	ACTION(etc),				STATE(EXIT),},

	{STATE(PARSE_ODF),	EVENT(POS),	ACTION(select_info),			STATE(SELECT_INFO),},
	{STATE(PARSE_ODF),	EVENT(POF),	ACTION(etc),				STATE(EXIT),},

	{STATE(SELECT_INFO),	EVENT(SSIS),	ACTION(null),				STATE(SELECT_INFO),},
	{STATE(SELECT_INFO),	EVENT(SSIF),	ACTION(etc),				STATE(EXIT),},
	{STATE(SELECT_INFO),	EVENT(RSIS),	ACTION(read_info),			STATE(READ_INFO),},
	{STATE(SELECT_INFO),	EVENT(RSIF),	ACTION(etc),				STATE(EXIT),},

	{STATE(READ_INFO),	EVENT(SRIS),	ACTION(null),				STATE(READ_INFO),},
	{STATE(READ_INFO),	EVENT(SRIF),	ACTION(etc),				STATE(EXIT),},
	{STATE(READ_INFO),	EVENT(RRIS),	ACTION(parse_info),			STATE(PARSE_INFO),},
	{STATE(READ_INFO),	EVENT(RRIF),	ACTION(etc),				STATE(EXIT),},

	{STATE(PARSE_INFO),	EVENT(PIS),	ACTION(init_handle_etc),			STATE(EXIT),},
	{STATE(PARSE_INFO),	EVENT(PIF),	ACTION(etc),				STATE(EXIT),},

	{0,			0,		ACTION(null),				0,},
};

static const char *pkcs15_bind_state_names[] = PKCS15_BIND_STATE_NAMES;
static const char *pkcs15_bind_event_names[] = PKCS15_BIND_EVENT_NAMES;

const stm_table_t pkcs15_bind_stm_table = {
	"pkcs15",
	pkcs15_bind_stm_log,
	PKCS15_BIND_STATE_COUNT,
	&pkcs15_bind_state_names[0],
	PKCS15_BIND_EVENT_COUNT,
	&pkcs15_bind_event_names[0],
	pkcs15_bind_stm_entries,	
};

#undef STATE
#undef EVENT
#undef ACTION

int pkcs15_bind(struct scard_handle *card_handle, 
		struct pkcs15_handle **p15_handle_out,
		scard_cmd_complete callback, void *user_data)
{
	struct pkcs15_handle *p15_handle;
	struct pkcs15_bind_trans *p15_bind_trans;

	p15_handle = pkcs15_handle_new();
	if (!p15_handle)
		return PKCS15_ERR_NO_MEM;
	p15_handle->card_handle = card_handle;

	p15_bind_trans = malloc(sizeof(struct pkcs15_bind_trans));
	if (!p15_bind_trans) {
		free(p15_handle);
		return PKCS15_ERR_NO_MEM;
	}
	memset(p15_bind_trans, 0, sizeof(struct pkcs15_bind_trans));
	p15_bind_trans->name = "PKCS15-BIND";
	p15_bind_trans->handle_out = p15_handle_out;
	p15_bind_trans->callback = callback;
	p15_bind_trans->user_data = user_data;
	p15_bind_trans->p15_handle = p15_handle;

	p15_bind_trans->fsmi = stm_table_new(&pkcs15_bind_stm_table,
					     p15_bind_trans->name, 
					     PKCS15_BIND_STATE_INIT);
	if (!p15_bind_trans->fsmi) {
		free(p15_bind_trans);
		return PKCS15_ERR_NO_MEM;
	}

	pkcs15_bind_raise_bind(p15_bind_trans);

	return PKCS15_SUCCESS;
}

static void pkcs15_bind_stm_exit(struct pkcs15_bind_trans *p15_bind_trans)
{
	p15_bind_trans->callback(p15_bind_trans->user_data, 
				p15_bind_trans->ret);

	if (p15_bind_trans->fsmi) {
		eloop_cleanup_events(NULL, p15_bind_trans->fsmi);
		stm_table_free(p15_bind_trans->fsmi);
	}
	free(p15_bind_trans);
}

static void pkcs15_bind_stm_exit_delay(void *eloop, void *user_ctx) 
{
	pkcs15_bind_stm_exit((struct pkcs15_bind_trans *)user_ctx);
}

int pkcs15_unbind(struct pkcs15_handle *p15_handle)
{
	pkcs15_handle_free(p15_handle);

	return SCARD_SUCCESS;
}

static const unsigned int odf_indexes[] = {
	PKCS15_PRKDF,
	PKCS15_PUKDF,
	PKCS15_PUKDF_TRUSTED,
	PKCS15_SKDF,
	PKCS15_CDF,
	PKCS15_CDF_TRUSTED,
	PKCS15_CDF_USEFUL,
	PKCS15_DODF,
	PKCS15_AODF,
};

/*
static const struct sc_asn1_entry c_asn1_odf[] = {
	{ "privateKeys",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 0 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "publicKeys",		 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 1 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "trustedPublicKeys",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 2 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "secretKeys",	 	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 3 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "certificates",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 4 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "trustedCertificates", PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 5 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "usefulCertificates",  PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 6 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "dataObjects",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 7 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "authObjects",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 8 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

int pkcs15_encode_odf (struct pkcs15_handle *p15_handle,
		       uint8_t **out, size_t *out_len)
{
	struct scard_path path;
	struct pkcs15_asn1_entry asn1_obj_or_path[] = {
		{ "path", PKCS15_ASN1_PATH, PKCS15_ASN1_CONS | PKCS15_ASN1_SEQUENCE, 0, &path, NULL },
		{ NULL, 0, 0, 0, NULL, NULL },
	};
	struct pkcs15_asn1_entry *asn1_paths = NULL;
	struct pkcs15_asn1_entry *asn1_odf = NULL;
	int df_count = 0, r, c = 0;
	const int nr_indexs = sizeof(odf_indexes)/sizeof(odf_indexes[0]);
	struct pkcs15_df *df, *pos_df;

	list_for_each_entry(struct pkcs15_df, pos_df, 
		&p15_handle->df_list, link) {
		df_count++;
	}
	if (df_count == 0) 
		return PKCS15_ERR_OBJECT_NOT_FOUND;
	asn1_odf = (struct pkcs15_asn1_entry *) malloc(sizeof(struct pkcs15_asn1_entry) * (df_count + 1));
	if (!asn1_odf) {
		r = PKCS15_ERR_NO_MEM;
		goto err;
	}

	asn1_paths = (struct pkcs15_asn1_entry *) malloc(sizeof(struct pkcs15_asn1_entry) * (df_count * 2));
	if (asn1_paths) {
		r = PKCS15_ERR_NO_MEM;
		goto err;
	}

	list_for_each_entry(struct pkcs15_df, pos_df, 
		&p15_handle->df_list, link) {
		int j, type = -1;

		for (j = 0; j < nr_indexes; j++) {
			if (odf_indexes[j] == df->type) {
				type = j;
				break;
			}
		}
		if (type == -1)
			continue;
		asn1_odf[c] = c_asn1_odf[type];
		pkcs15_format_asn1_entry(asn1_odf + c, asn1_paths + 2 * c, NULL, 1);
		pkcs15_copy_asn1_entry(asn1_obj_or_path, asn1_paths + 2 * c);
		pkcs15_format_asn1_entry(asn1_paths + 2 * c, &df->path, NULL, 1);
		c++;			
	}
	asn1_odf[c].name = NULL;
	r = pkcs15_asn1_encode(asn1_odf, out, out_len);

err:
	if (asn1_paths)
		free(asn1_paths);
	if (asn1_odf)
		free(asn1_odf);
	return r;
}

int pkcs15_encode_tokeninfo(struct pkcs15_handle *p15_handle,
			    struct pkcs15_tokeninfo *ti,
			    uint8_t **out, size_t *out_len)
{
	int r;
	int ver = ti->version;
	size_t 
}

  */