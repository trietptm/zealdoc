#include "crypto_priv.h"

DECLARE_LIST(crypto_alg_list);
DECLARE_LIST(crypto_template_list);


static inline int crypto_set_driver_name(crypto_alg_t *alg)
{
	static const char suffix[] = "-generic";
	char *driver_name = alg->cra_driver_name;
	int len;

	if (*driver_name)
		return 0;

	len = strlcpy(driver_name, alg->cra_name, CRYPTO_MAX_ALG_NAME);
	if (len + sizeof(suffix) > CRYPTO_MAX_ALG_NAME)
		return -ENAMETOOLONG;

	memcpy(driver_name + len, suffix, sizeof(suffix));
	return 0;
}

static int crypto_check_alg(crypto_alg_t *alg)
{
	if (alg->cra_blocksize > 512)
		return -EINVAL;

	if (alg->cra_priority < 0)
		return -EINVAL;

	return crypto_set_driver_name(alg);
}

static inline int crypto_is_dead(crypto_alg_t *alg)
{
	return alg->cra_flags & CRYPTO_ALG_DEAD;
}

static inline int crypto_is_moribund(crypto_alg_t *alg)
{
	return alg->cra_flags & (CRYPTO_ALG_DEAD | CRYPTO_ALG_DYING);
}

static void crypto_destroy_instance(crypto_alg_t *alg)
{
	struct crypto_instance *inst = (void *)alg;
	struct crypto_template *tmpl = inst->tmpl;

	tmpl->free(inst);
	crypto_tmpl_put(tmpl);
}

static void crypto_remove_spawn(crypto_spawn_t *spawn,
				list_t *list,
				list_t *secondary_spawns)
{
	struct crypto_instance *inst = spawn->inst;
	struct crypto_template *tmpl = inst->tmpl;

	list_delete_init(&spawn->list);
	spawn->alg = NULL;

	if (crypto_is_dead(&inst->alg))
		return;

	inst->alg.cra_flags |= CRYPTO_ALG_DEAD;
	if (!tmpl || !crypto_tmpl_get(tmpl))
		return;

	//crypto_notify(CRYPTO_MSG_ALG_UNREGISTER, &inst->alg);
	list_move_head(&inst->alg.cra_list, list);
	hlist_del(&inst->list);
	inst->alg.cra_destroy = crypto_destroy_instance;

	list_splice(&inst->alg.cra_users, secondary_spawns);
}

static void crypto_remove_spawns(list_t *spawns,
				 list_t *list, uint32_t new_type)
{
	crypto_spawn_t *spawn, *n;
	DECLARE_LIST(secondary_spawns);

	list_for_each_entry_safe(crypto_spawn_t, spawn, n, spawns, list) {
		if ((spawn->alg->cra_flags ^ new_type) & spawn->mask)
			continue;

		crypto_remove_spawn(spawn, list, &secondary_spawns);
	}

	while (!list_empty(&secondary_spawns)) {
		list_for_each_entry_safe(crypto_spawn_t, spawn, n, &secondary_spawns, list)
			crypto_remove_spawn(spawn, list, &secondary_spawns);
	}
}

static int __crypto_register_alg(crypto_alg_t *alg,
				 list_t *list)
{
	crypto_alg_t *q;
	int ret = -EAGAIN;

	if (crypto_is_dead(alg))
		goto out;

	list_init(&alg->cra_users);

	ret = -EEXIST;

	atomic_set(&alg->cra_refcnt, 1);
	list_for_each_entry(crypto_alg_t, q, &crypto_alg_list, cra_list) {
		if (q == alg)
			goto out;

		if (crypto_is_moribund(q))
			continue;

		if (strcmp(alg->cra_name, q->cra_name))
			continue;

		if (strcmp(alg->cra_driver_name, q->cra_driver_name) &&
		    q->cra_priority > alg->cra_priority)
			continue;

		crypto_remove_spawns(&q->cra_users, list, alg->cra_flags);
	}
	
	list_insert_before(&alg->cra_list, &crypto_alg_list);

	//crypto_notify(CRYPTO_MSG_ALG_REGISTER, alg);
	ret = 0;

out:	
	return ret;
}

static void crypto_remove_final(list_t *list)
{
	crypto_alg_t *alg;
	crypto_alg_t *n;

	list_for_each_entry_safe(crypto_alg_t, alg, n, list, cra_list) {
		list_delete_init(&alg->cra_list);
		crypto_alg_put(alg);
	}
}

int crypto_register_alg(crypto_alg_t *alg)
{
	DECLARE_LIST(list);
	int err;

	err = crypto_check_alg(alg);
	if (err)
		return err;

	err = __crypto_register_alg(alg, &list);

	crypto_remove_final(&list);
	return err;
}

static int crypto_remove_alg(crypto_alg_t *alg, list_t *list)
{
	if (list_empty(&alg->cra_list))
		return -ENOENT;

	alg->cra_flags |= CRYPTO_ALG_DEAD;

	//crypto_notify(CRYPTO_MSG_ALG_UNREGISTER, alg);
	list_delete_init(&alg->cra_list);
	crypto_remove_spawns(&alg->cra_users, list, alg->cra_flags);

	return 0;
}

int crypto_unregister_alg(crypto_alg_t *alg)
{
	int ret;
	DECLARE_LIST(list);
	
	ret = crypto_remove_alg(alg, &list);

	if (ret)
		return ret;

	BUG_ON(atomic_read(&alg->cra_refcnt) != 1);
	if (alg->cra_destroy)
		alg->cra_destroy(alg);

	crypto_remove_final(&list);
	return 0;
}


int crypto_register_template(struct crypto_template *tmpl)
{
	struct crypto_template *q;
	int err = -EEXIST;

	list_for_each_entry(struct crypto_template, q, &crypto_template_list, list) {
		if (q == tmpl)
			goto out;
	}

	list_insert_before(&tmpl->list, &crypto_template_list);
	//crypto_notify(CRYPTO_MSG_TMPL_REGISTER, tmpl);
	err = 0;
out:
	return err;
}

void crypto_unregister_template(struct crypto_template *tmpl)
{
	struct crypto_instance *inst;
	struct hlist_node *p, *n;
	struct hlist_head *list;
	DECLARE_LIST(users);

	BUG_ON(list_empty(&tmpl->list));
	list_delete_init(&tmpl->list);

	list = &tmpl->instances;
	hlist_for_each_entry(struct crypto_instance, inst, p, list, list) {
		int err = crypto_remove_alg(&inst->alg, &users);
		BUG_ON(err);
	}

	//crypto_notify(CRYPTO_MSG_TMPL_UNREGISTER, tmpl);

	hlist_for_each_entry_safe(struct crypto_instance, inst, p, n, list, list) {
		BUG_ON(atomic_read(&inst->alg.cra_refcnt) != 1);
		tmpl->free(inst);
	}
	crypto_remove_final(&users);
}

static struct crypto_template *__crypto_lookup_template(const char *name)
{
	struct crypto_template *q, *tmpl = NULL;

	list_for_each_entry(struct crypto_template, q, &crypto_template_list, list) {
		if (strcmp(q->name, name))
			continue;
		if (!crypto_tmpl_get(q))
			continue;

		tmpl = q;
		break;
	}

	return tmpl;
}

struct crypto_template *crypto_lookup_template(const char *name)
{
	return __crypto_lookup_template(name);
}

int crypto_register_instance(struct crypto_template *tmpl,
			     struct crypto_instance *inst)
{
	DECLARE_LIST(list);
	int err = -EINVAL;

	if (inst->alg.cra_destroy)
		goto err;

	err = crypto_check_alg(&inst->alg);
	if (err)
		goto err;

	err = __crypto_register_alg(&inst->alg, &list);
	if (err)
		goto unlock;

	hlist_add_head(&inst->list, &tmpl->instances);
	inst->tmpl = tmpl;

unlock:
	crypto_remove_final(&list);

err:
	return err;
}

int crypto_init_spawn(crypto_spawn_t *spawn, crypto_alg_t *alg,
		      struct crypto_instance *inst, uint32_t mask)
{
	int err = -EAGAIN;

	spawn->inst = inst;
	spawn->mask = mask;

	if (!crypto_is_moribund(alg)) {
		list_insert_before(&spawn->list, &alg->cra_users);
		spawn->alg = alg;
		err = 0;
	}

	return err;
}

void crypto_drop_spawn(crypto_spawn_t *spawn)
{
	list_delete(&spawn->list);
}

crypto_tfm_t *crypto_spawn_tfm(crypto_spawn_t *spawn, uint32_t type,
			       uint32_t mask)
{
	crypto_alg_t *alg;
	crypto_alg_t *alg2;
	crypto_tfm_t *tfm;

	alg = spawn->alg;
	alg2 = alg;
	if (alg2)
		alg2 = crypto_alg_get(alg2);

	if (!alg2) {
		if (alg)
			crypto_shoot_alg(alg);
		return NULL;
	}

	tfm = NULL;
	if ((alg->cra_flags ^ type) & mask)
		goto out_put_alg;

	tfm = __crypto_alloc_tfm(alg, type, mask);
	if (!tfm)
		goto out_put_alg;

	return tfm;

out_put_alg:
	crypto_alg_put(alg);
	return tfm;
}

crypto_alg_t *__crypto_alg_lookup(const char *name,
				  uint32_t type, uint32_t mask)
{
	crypto_alg_t *q, *alg = NULL;
	int best = -2;

	list_for_each_entry(crypto_alg_t, q, &crypto_alg_list, cra_list) {
		int exact, fuzzy;

		if (crypto_is_moribund(q))
			continue;

		if ((q->cra_flags ^ type) & mask)
			continue;

		exact = !strcmp(q->cra_driver_name, name);
		fuzzy = !strcmp(q->cra_name, name);
		if (!exact && !(fuzzy && q->cra_priority > best))
			continue;

		if (!crypto_alg_get(q))
			continue;

		best = q->cra_priority;
		if (alg)
			crypto_alg_put(alg);
		alg = q;

		if (exact)
			break;
	}

	return alg;
}

static crypto_alg_t *crypto_alg_lookup(const char *name, uint32_t type,
					    uint32_t mask)
{
	crypto_alg_t *alg;

	alg = __crypto_alg_lookup(name, type, mask);
	return alg;
}

crypto_alg_t *crypto_alg_mod_lookup(const char *name,
				    uint32_t type, uint32_t mask)
{
	crypto_alg_t *alg;

	if (!name)
		return NULL;

	mask &= ~(CRYPTO_ALG_LARVAL | CRYPTO_ALG_DEAD);
	type &= mask;

	alg = crypto_alg_lookup(name, type, mask);
	if (alg)
		return alg;
	return alg;
}

static int crypto_init_ops(crypto_tfm_t *tfm, uint32_t type, uint32_t mask)
{
	switch (crypto_tfm_alg_type(tfm)) {
	case CRYPTO_ALG_TYPE_CIPHER:
		return crypto_init_cipher_ops(tfm);
		
	case CRYPTO_ALG_TYPE_DIGEST:
		return crypto_init_digest_ops(tfm);
		
	case CRYPTO_ALG_TYPE_COMPRESS:
		return crypto_init_compress_ops(tfm);
	
	default:
		break;
	}
	
	BUG();
	return -EINVAL;
}

static void crypto_exit_ops(crypto_tfm_t *tfm)
{
	switch (crypto_tfm_alg_type(tfm)) {
	case CRYPTO_ALG_TYPE_CIPHER:
		crypto_exit_cipher_ops(tfm);
		break;
		
	case CRYPTO_ALG_TYPE_DIGEST:
		crypto_exit_digest_ops(tfm);
		break;
		
	case CRYPTO_ALG_TYPE_COMPRESS:
		crypto_exit_compress_ops(tfm);
		break;
	
	default:
		BUG();
	}
}

static unsigned int crypto_ctxsize(crypto_alg_t *alg, uint32_t type,
				   uint32_t mask)
{
	unsigned int len = 0;

	switch (alg->cra_flags & CRYPTO_ALG_TYPE_MASK) {
	default:
		BUG();

	case CRYPTO_ALG_TYPE_CIPHER:
		len += crypto_cipher_ctxsize(alg);
		break;
		
	case CRYPTO_ALG_TYPE_DIGEST:
		len += crypto_digest_ctxsize(alg);
		break;
		
	case CRYPTO_ALG_TYPE_COMPRESS:
		len += crypto_compress_ctxsize(alg);
		break;
	}

	return len;
}

void crypto_shoot_alg(crypto_alg_t *alg)
{
	alg->cra_flags |= CRYPTO_ALG_DYING;
}

crypto_tfm_t *__crypto_alloc_tfm(crypto_alg_t *alg, uint32_t type,
				 uint32_t mask)
{
	crypto_tfm_t *tfm = NULL;
	unsigned int tfm_size;
	int err = -ENOMEM;

	tfm_size = sizeof(*tfm) + crypto_ctxsize(alg, type, mask);
	tfm = calloc(tfm_size, 1);
	if (tfm == NULL)
		goto out_err;

	tfm->__crt_alg = alg;

	err = crypto_init_ops(tfm, type, mask);
	if (err)
		goto out_free_tfm;

	if (alg->cra_init && (err = alg->cra_init(tfm))) {
		if (err == -EAGAIN)
			crypto_shoot_alg(alg);
		goto cra_init_failed;
	}

	goto out;

cra_init_failed:
	crypto_exit_ops(tfm);
out_free_tfm:
	free(tfm);
out_err:
	tfm = NULL;
out:
	return tfm;
}

/*
 *	crypto_alloc_base - Locate algorithm and allocate transform
 *	@alg_name: Name of algorithm
 *	@type: Type of algorithm
 *	@mask: Mask for type comparison
 *
 *	crypto_alloc_base() will first attempt to locate an already loaded
 *	algorithm.  If that fails and the kernel supports dynamically loadable
 *	modules, it will then attempt to load a module of the same name or
 *	alias.  If that fails it will send a query to any loaded crypto manager
 *	to construct an algorithm on the fly.  A refcount is grabbed on the
 *	algorithm which is then associated with the new transform.
 *
 *	The returned transform is of a non-determinate type.  Most people
 *	should use one of the more specific allocation functions such as
 *	crypto_alloc_blkcipher.
 *
 *	In case of error the return value is an error pointer.
 */
crypto_tfm_t *crypto_alloc_base(const char *alg_name, uint32_t type,
				uint32_t mask)
{
	crypto_tfm_t *tfm = NULL;

	for (;;) {
		crypto_alg_t *alg;

		alg = crypto_alg_mod_lookup(alg_name, type, mask);
		if (!alg) {
			goto err;
		}

		tfm = __crypto_alloc_tfm(alg, type, mask);
		if (tfm)
			return tfm;

		crypto_alg_put(alg);
err:
		;
	}

	return NULL;
}
 
/*
 *	crypto_free_tfm - Free crypto transform
 *	@tfm: Transform to free
 *
 *	crypto_free_tfm() frees up the transform and any associated resources,
 *	then drops the refcount on the associated algorithm.
 */
void crypto_free_tfm(crypto_tfm_t *tfm)
{
	crypto_alg_t *alg;
	int size;

	if (!tfm)
		return;

	alg = tfm->__crt_alg;
	size = sizeof(*tfm) + alg->cra_ctxsize;

	if (alg->cra_exit)
		alg->cra_exit(tfm);
	crypto_exit_ops(tfm);
	crypto_alg_put(alg);
	memset(tfm, 0, size);
	free(tfm);
}
#if 0
int crypto_has_alg(const char *name, uint32_t type, uint32_t mask)
{
	int ret = 0;
	crypto_alg_t *alg = crypto_alg_mod_lookup(name, type, mask);
	
	if (alg) {
		crypto_alg_put(alg);
		ret = 1;
	}
	
	return ret;
}
#endif
