#ifndef __FNV_H_INCLUDE__
#define __FNV_H_INCLUDE__

#include <sysdep.h>

/* Fowler / Noll / Vo (FNV) Hash
 * For details, see:
 * http://www.isthe.com/chongo/tech/comp/fnv/
 */
uint32_t fnv_32_init(const void *, size_t);
uint32_t fnv_32_buf(const void *data, size_t size, uint32_t hash);
uint32_t fnv_32_str(const char *p);
uint32_t fnv_32_fold(uint32_t hash, int bits);

#endif /* __FNV_H_INCLUDE__ */
