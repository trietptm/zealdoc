#ifndef __CRYPTO_H_INCLUDE__
#define __CRYPTO_H_INCLUDE__

#include <sysdep.h>
#include <list.h>
#include <panic.h>
#include <linux/rtnetlink.h>

#define CRYPTO_SERVICE_NAME		"crypto"

#define CRYPTO_ALG_TYPE_MASK		0x0000000f
#define CRYPTO_ALG_TYPE_CIPHER		0x00000001
#define CRYPTO_ALG_TYPE_DIGEST		0x00000002
#define CRYPTO_ALG_TYPE_HASH		0x00000003
#define CRYPTO_ALG_TYPE_BLKCIPHER	0x00000004
#define CRYPTO_ALG_TYPE_COMPRESS	0x00000005

#define CRYPTO_ALG_TYPE_HASH_MASK	0x0000000e

#define CRYPTO_ALG_LARVAL		0x00000010
#define CRYPTO_ALG_DEAD			0x00000020
#define CRYPTO_ALG_DYING		0x00000040
#define CRYPTO_ALG_ASYNC		0x00000080

/*
 * Miscellaneous stuff.
 */
#define CRYPTO_MAX_ALG_NAME		64

/*
 * Transform masks and values (for crt_flags).
 */
#define CRYPTO_TFM_REQ_MASK		0x000fff00
#define CRYPTO_TFM_RES_MASK		0xfff00000

#define CRYPTO_TFM_REQ_WEAK_KEY		0x00000100
#define CRYPTO_TFM_REQ_MAY_SLEEP	0x00000200
#define CRYPTO_TFM_REQ_MAY_BACKLOG	0x00000400
#define CRYPTO_TFM_RES_WEAK_KEY		0x00100000
#define CRYPTO_TFM_RES_BAD_KEY_LEN   	0x00200000
#define CRYPTO_TFM_RES_BAD_KEY_SCHED 	0x00400000
#define CRYPTO_TFM_RES_BAD_BLOCK_LEN 	0x00800000
#define CRYPTO_TFM_RES_BAD_FLAGS 	0x01000000

struct crypto_ablkcipher;
struct crypto_blkcipher;
struct crypto_hash;
struct crypto_queue;
typedef struct _crypto_tfm_t crypto_tfm_t;
typedef struct _crypto_alg_t crypto_alg_t;
struct crypto_async_request;

typedef void (*crypto_completion_t)(struct crypto_async_request *req, int err);

struct crypto_async_request {
	list_t list;
	crypto_completion_t complete;
	void *data;
	crypto_tfm_t *tfm;

	uint32_t flags;
};

struct ablkcipher_request {
	struct crypto_async_request base;

	unsigned int nbytes;

	void *info;

	struct iovec *src;
	struct iovec *dst;

	void *__ctx[];
};

struct blkcipher_desc {
	struct crypto_blkcipher *tfm;
	void *info;
	uint32_t flags;
};

struct cipher_desc {
	crypto_tfm_t *tfm;
	void (*crfn)(crypto_tfm_t *tfm, uint8_t *dst, const uint8_t *src);
	unsigned int (*prfn)(const struct cipher_desc *desc, uint8_t *dst,
			     const uint8_t *src, unsigned int nbytes);
	void *info;
};

struct hash_desc {
	struct crypto_hash *tfm;
	uint32_t flags;
};

/*
 * Algorithms: modular crypto algorithm implementations, managed
 * via crypto_register_alg() and crypto_unregister_alg().
 */
struct ablkcipher_alg {
	int (*setkey)(struct crypto_ablkcipher *tfm, const uint8_t *key,
	              unsigned int keylen);
	int (*encrypt)(struct ablkcipher_request *req);
	int (*decrypt)(struct ablkcipher_request *req);

	struct crypto_queue *queue;

	unsigned int min_keysize;
	unsigned int max_keysize;
	unsigned int ivsize;
};

struct blkcipher_alg {
	int (*setkey)(crypto_tfm_t *tfm, const uint8_t *key,
	              unsigned int keylen);
	int (*encrypt)(struct blkcipher_desc *desc,
		       struct iovec *dst, struct iovec *src,
		       unsigned int nbytes);
	int (*decrypt)(struct blkcipher_desc *desc,
		       struct iovec *dst, struct iovec *src,
		       unsigned int nbytes);

	unsigned int min_keysize;
	unsigned int max_keysize;
	unsigned int ivsize;
};

struct cipher_alg {
	unsigned int cia_min_keysize;
	unsigned int cia_max_keysize;
	int (*cia_setkey)(crypto_tfm_t *tfm, const uint8_t *key,
	                  unsigned int keylen);
	void (*cia_encrypt)(crypto_tfm_t *tfm, uint8_t *dst, const uint8_t *src);
	void (*cia_decrypt)(crypto_tfm_t *tfm, uint8_t *dst, const uint8_t *src);
};

struct digest_alg {
	unsigned int dia_digestsize;
	void (*dia_init)(crypto_tfm_t *tfm);
	void (*dia_update)(crypto_tfm_t *tfm, const uint8_t *data,
			   unsigned int len);
	void (*dia_final)(crypto_tfm_t *tfm, uint8_t *out);
	int (*dia_setkey)(crypto_tfm_t *tfm, const uint8_t *key,
	                  unsigned int keylen);
};

struct hash_alg {
	int (*init)(struct hash_desc *desc);
	int (*update)(struct hash_desc *desc, struct iovec *sg,
		      unsigned int nbytes);
	int (*final)(struct hash_desc *desc, uint8_t *out);
	int (*digest)(struct hash_desc *desc, struct iovec *sg,
		      unsigned int nbytes, uint8_t *out);
	int (*setkey)(struct crypto_hash *tfm, const uint8_t *key,
		      unsigned int keylen);

	unsigned int digestsize;
};

struct compress_alg {
	int (*coa_compress)(crypto_tfm_t *tfm, const uint8_t *src,
			    unsigned int slen, uint8_t *dst, unsigned int *dlen);
	int (*coa_decompress)(crypto_tfm_t *tfm, const uint8_t *src,
			      unsigned int slen, uint8_t *dst, unsigned int *dlen);
};

#define cra_ablkcipher	cra_u.ablkcipher
#define cra_blkcipher	cra_u.blkcipher
#define cra_cipher	cra_u.cipher
#define cra_digest	cra_u.digest
#define cra_hash	cra_u.hash
#define cra_compress	cra_u.compress

struct _crypto_alg_t {
	list_t cra_list;
	list_t cra_users;

	int cra_flags;
	unsigned int cra_blocksize;
	unsigned int cra_ctxsize;

	int cra_priority;
	atomic_t cra_refcnt;
	char cra_name[CRYPTO_MAX_ALG_NAME];
	char cra_driver_name[CRYPTO_MAX_ALG_NAME];

	union {
		struct ablkcipher_alg ablkcipher;
		struct blkcipher_alg blkcipher;
		struct cipher_alg cipher;
		struct digest_alg digest;
		struct hash_alg hash;
		struct compress_alg compress;
	} cra_u;

	int (*cra_init)(crypto_tfm_t *tfm);
	void (*cra_exit)(crypto_tfm_t *tfm);
	void (*cra_destroy)(crypto_alg_t *alg);
};

/*
 * Algorithm registration interface.
 */
int crypto_register_alg(crypto_alg_t *alg);
int crypto_unregister_alg(crypto_alg_t *alg);

/*
 * Algorithm query interface.
 */
#ifdef CONFIG_CRYPTO
int crypto_has_alg(const char *name, uint32_t type, uint32_t mask);
#else
static inline int crypto_has_alg(const char *name, uint32_t type, uint32_t mask)
{
	return 0;
}
#endif

/*
 * Transforms: user-instantiated objects which encapsulate algorithms
 * and core processing logic.  Managed via crypto_alloc_*() and
 * crypto_free_*(), as well as the various helpers below.
 */

struct ablkcipher_tfm {
	int (*setkey)(struct crypto_ablkcipher *tfm, const uint8_t *key,
	              unsigned int keylen);
	int (*encrypt)(struct ablkcipher_request *req);
	int (*decrypt)(struct ablkcipher_request *req);
	unsigned int ivsize;
	unsigned int reqsize;
};

struct blkcipher_tfm {
	void *iv;
	int (*setkey)(crypto_tfm_t *tfm, const uint8_t *key,
		      unsigned int keylen);
	int (*encrypt)(struct blkcipher_desc *desc, struct iovec *dst,
		       struct iovec *src, unsigned int nbytes);
	int (*decrypt)(struct blkcipher_desc *desc, struct iovec *dst,
		       struct iovec *src, unsigned int nbytes);
};

struct cipher_tfm {
	int (*cit_setkey)(crypto_tfm_t *tfm,
	                  const uint8_t *key, unsigned int keylen);
	void (*cit_encrypt_one)(crypto_tfm_t *tfm, uint8_t *dst, const uint8_t *src);
	void (*cit_decrypt_one)(crypto_tfm_t *tfm, uint8_t *dst, const uint8_t *src);
};

struct hash_tfm {
	int (*init)(struct hash_desc *desc);
	int (*update)(struct hash_desc *desc,
		      struct iovec *sg, unsigned int nsg);
	int (*final)(struct hash_desc *desc, uint8_t *out);
	int (*digest)(struct hash_desc *desc, struct iovec *sg,
		      unsigned int nsg, uint8_t *out);
	int (*setkey)(struct crypto_hash *tfm, const uint8_t *key,
		      unsigned int keylen);
	unsigned int digestsize;
};

struct compress_tfm {
	int (*cot_compress)(crypto_tfm_t *tfm,
	                    const uint8_t *src, unsigned int slen,
	                    uint8_t *dst, unsigned int *dlen);
	int (*cot_decompress)(crypto_tfm_t *tfm,
	                      const uint8_t *src, unsigned int slen,
	                      uint8_t *dst, unsigned int *dlen);
};

#define crt_ablkcipher	crt_u.ablkcipher
#define crt_blkcipher	crt_u.blkcipher
#define crt_cipher	crt_u.cipher
#define crt_hash	crt_u.hash
#define crt_compress	crt_u.compress

struct _crypto_tfm_t {

	uint32_t crt_flags;
	
	union {
		struct ablkcipher_tfm ablkcipher;
		struct blkcipher_tfm blkcipher;
		struct cipher_tfm cipher;
		struct hash_tfm hash;
		struct compress_tfm compress;
	} crt_u;
	
	crypto_alg_t *__crt_alg;

	void *__crt_ctx[];
};

struct crypto_ablkcipher {
	crypto_tfm_t base;
};

struct crypto_blkcipher {
	crypto_tfm_t base;
};

struct crypto_cipher {
	crypto_tfm_t base;
};

struct crypto_comp {
	crypto_tfm_t base;
};

struct crypto_hash {
	crypto_tfm_t base;
};

struct crypto_instance {
	crypto_alg_t alg;

	struct crypto_template *tmpl;
	struct hlist_node list;

	void *__ctx[];
};

struct crypto_template {
	list_t list;
	struct hlist_head instances;
	
	atomic_t refcnt;
	struct crypto_instance *(*alloc)(struct rtattr **tb);
	void (*free)(struct crypto_instance *inst);

	char name[CRYPTO_MAX_ALG_NAME];
};

typedef struct _crypto_spawn_t {
	list_t list;
	crypto_alg_t *alg;
	struct crypto_instance *inst;
	uint32_t mask;
} crypto_spawn_t;

struct crypto_queue {
	list_t list;
	list_t *backlog;

	unsigned int qlen;
	unsigned int max_qlen;
};

static inline crypto_alg_t *crypto_alg_get(crypto_alg_t *alg)
{
	atomic_inc(&alg->cra_refcnt);
	return alg;
}
static inline void crypto_alg_put(crypto_alg_t *alg)
{
	if (atomic_dec_and_test(&alg->cra_refcnt) && alg->cra_destroy)
		alg->cra_destroy(alg);
}

static inline int crypto_tmpl_get(struct crypto_template *tmpl)
{
	atomic_inc(&tmpl->refcnt);
	return 1;
}
static inline void crypto_tmpl_put(struct crypto_template *tmpl)
{
	if (atomic_dec_and_test(&tmpl->refcnt))
		;
}

int crypto_register_template(struct crypto_template *tmpl);
void crypto_unregister_template(struct crypto_template *tmpl);
struct crypto_template *crypto_lookup_template(const char *name);

int crypto_init_spawn(crypto_spawn_t *spawn, crypto_alg_t *alg,
		      struct crypto_instance *inst, uint32_t mask);
void crypto_drop_spawn(crypto_spawn_t *spawn);
crypto_tfm_t *crypto_spawn_tfm(crypto_spawn_t *spawn, uint32_t type,
			       uint32_t mask);

/* 
 * Transform user interface.
 */
 
crypto_tfm_t *crypto_alloc_tfm(const char *alg_name, uint32_t tfm_flags);
crypto_tfm_t *crypto_alloc_base(const char *alg_name, uint32_t type, uint32_t mask);
void crypto_free_tfm(crypto_tfm_t *tfm);

/*
 * Transform helpers which query the underlying algorithm.
 */
static inline const char *crypto_tfm_alg_name(crypto_tfm_t *tfm)
{
	return tfm->__crt_alg->cra_name;
}

static inline const char *crypto_tfm_alg_driver_name(crypto_tfm_t *tfm)
{
	return tfm->__crt_alg->cra_driver_name;
}

static inline int crypto_tfm_alg_priority(crypto_tfm_t *tfm)
{
	return tfm->__crt_alg->cra_priority;
}

static inline uint32_t crypto_tfm_alg_type(crypto_tfm_t *tfm)
{
	return tfm->__crt_alg->cra_flags & CRYPTO_ALG_TYPE_MASK;
}

static inline unsigned int crypto_tfm_alg_blocksize(crypto_tfm_t *tfm)
{
	return tfm->__crt_alg->cra_blocksize;
}

static inline uint32_t crypto_tfm_get_flags(crypto_tfm_t *tfm)
{
	return tfm->crt_flags;
}

static inline void crypto_tfm_set_flags(crypto_tfm_t *tfm, uint32_t flags)
{
	tfm->crt_flags |= flags;
}

static inline void crypto_tfm_clear_flags(crypto_tfm_t *tfm, uint32_t flags)
{
	tfm->crt_flags &= ~flags;
}

static inline void *crypto_tfm_ctx(crypto_tfm_t *tfm)
{
	return tfm->__crt_ctx;
}

static inline unsigned int crypto_tfm_ctx_alignment(void)
{
#ifndef WIN32
	crypto_tfm_t *tfm;
	return __alignof__(tfm->__crt_ctx);
#else
	return sizeof (unsigned int);
#endif
}

static inline struct crypto_hash *__crypto_hash_cast(crypto_tfm_t *tfm)
{
	return (struct crypto_hash *)tfm;
}

static inline struct crypto_hash *crypto_hash_cast(crypto_tfm_t *tfm)
{
	BUG_ON((crypto_tfm_alg_type(tfm) ^ CRYPTO_ALG_TYPE_HASH) &
	       CRYPTO_ALG_TYPE_HASH_MASK);
	return __crypto_hash_cast(tfm);
}

static inline struct crypto_hash *crypto_alloc_hash(const char *alg_name,
						    uint32_t type, uint32_t mask)
{
	type &= ~CRYPTO_ALG_TYPE_MASK;
	type |= CRYPTO_ALG_TYPE_HASH;
	mask |= CRYPTO_ALG_TYPE_HASH_MASK;

	return __crypto_hash_cast(crypto_alloc_base(alg_name, type, mask));
}

static inline crypto_tfm_t *crypto_hash_tfm(struct crypto_hash *tfm)
{
	return &tfm->base;
}

static inline void crypto_free_hash(struct crypto_hash *tfm)
{
	crypto_free_tfm(crypto_hash_tfm(tfm));
}

static inline int crypto_has_hash(const char *alg_name, uint32_t type, uint32_t mask)
{
	type &= ~CRYPTO_ALG_TYPE_MASK;
	type |= CRYPTO_ALG_TYPE_HASH;
	mask |= CRYPTO_ALG_TYPE_HASH_MASK;

	return crypto_has_alg(alg_name, type, mask);
}

static inline struct hash_tfm *crypto_hash_crt(struct crypto_hash *tfm)
{
	return &crypto_hash_tfm(tfm)->crt_hash;
}

static inline unsigned int crypto_hash_blocksize(struct crypto_hash *tfm)
{
	return crypto_tfm_alg_blocksize(crypto_hash_tfm(tfm));
}

static inline unsigned int crypto_hash_digestsize(struct crypto_hash *tfm)
{
	return crypto_hash_crt(tfm)->digestsize;
}

static inline uint32_t crypto_hash_get_flags(struct crypto_hash *tfm)
{
	return crypto_tfm_get_flags(crypto_hash_tfm(tfm));
}

static inline void crypto_hash_set_flags(struct crypto_hash *tfm, uint32_t flags)
{
	crypto_tfm_set_flags(crypto_hash_tfm(tfm), flags);
}

static inline void crypto_hash_clear_flags(struct crypto_hash *tfm, uint32_t flags)
{
	crypto_tfm_clear_flags(crypto_hash_tfm(tfm), flags);
}

static inline int crypto_hash_init(struct hash_desc *desc)
{
	return crypto_hash_crt(desc->tfm)->init(desc);
}

static inline int crypto_hash_update(struct hash_desc *desc,
				     struct iovec *sg,
				     unsigned int nbytes)
{
	return crypto_hash_crt(desc->tfm)->update(desc, sg, nbytes);
}

static inline int crypto_hash_final(struct hash_desc *desc, uint8_t *out)
{
	return crypto_hash_crt(desc->tfm)->final(desc, out);
}

static inline int crypto_hash_digest(struct hash_desc *desc,
				     struct iovec *sg,
				     unsigned int nbytes, uint8_t *out)
{
	return crypto_hash_crt(desc->tfm)->digest(desc, sg, nbytes, out);
}

static inline int crypto_hash_setkey(struct crypto_hash *hash,
				     const uint8_t *key, unsigned int keylen)
{
	return crypto_hash_crt(hash)->setkey(hash, key, keylen);
}

#include <crypto_eay.h>

#endif /* __CRYPTO_H_INCLUDE__ */
