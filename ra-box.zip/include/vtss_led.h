#ifndef __VTSS_LED_H_INCLUDE__
#define __VTSS_LED_H_INCLUDE__

/* - Serial LED ---------------------------------------------------- */
#ifdef VTSS_FEATURE_SERIAL_LED
/* LED mode */
#define VTSS_LED_MODE_DISABLED	0 /* Disabled */
#define VTSS_LED_MODE_OFF	1 /* Off */
#define VTSS_LED_MODE_ON	2 /* On */
#define VTSS_LED_MODE_2_5	3 /* 2.5 Hz */
#define VTSS_LED_MODE_5		4 /* 5 Hz */
#define VTSS_LED_MODE_10	5 /* 10 Hz */
#define VTSS_LED_MODE_20        6 /* 20 Hz */

/******************************************************************************
 * Description: Setup serial LED mode.
 *
 * \param port (input): Serial LED port, 0-29 or 0-15 (G_ROCX).
 * \param mode (input): Serial LED mode for three LEDs.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_led_set(const uint port, const ulong mode[3]);

int vtss_led_start(void);
void vtss_led_update_port(vtss_port_no_t port_no,
			  vtss_port_status_t *port_status,
			  BOOL act_update);
#else
static inline int vtss_led_start(void) { return 0; }
static inline void vtss_led_update_port(vtss_port_no_t port_no,
					vtss_port_status_t *port_status,
					BOOL act_update)
{
}
#endif

#endif /* __VTSS_LED_H_INCLUDE__ */
