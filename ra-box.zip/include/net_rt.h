#ifndef __NET_RT_H_INCLUDE__
#define __NET_RT_H_INCLUDE__

#include <net_if.h>

/* ============================================================ *
 * other operations (may be deprecated)
 * ============================================================ */
#define rt_table_t FILE
rt_table_t *route_open_table(void);
int route_read_table(rt_table_t *route_fd, struct rtentry *rt);
#define route_close_table(fd)	fclose(fd)
int have_route_to(net_device_t *dev, uint32_t addr);
int route_set_default(net_device_t *dev, uint32_t gateway, short metric);
int route_default_exist(net_device_t *dev, struct rtentry *rt);
int route_unset_default(void);

int arp_proxy_addr(u_int32_t ipaddr, struct sockaddr *hwaddr,
		   char *name, int namelen);
int arp_add_proxy(net_device_t *dev, uint32_t his_adr, int ip_forward);
int arp_delete_proxy(net_device_t *dev, uint32_t his_adr);

#endif /* __NET_RT_H_INCLUDE__ */
