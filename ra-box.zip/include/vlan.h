#ifndef __VLAN_H_INCLUDE__
#define __VLAN_H_INCLUDE__

#include <netsvc.h>
#include <uiserv.h>

#define VLAN_SERVICE_NAME	"vlan"
#define _PATH_VLAN_CONFIG	"/proc/net/vlan/config"

/* ============================================================ *
 * V-LAN definitions
 * ============================================================ */
typedef struct _vlan_profile_t {
	const char *name;
	const char *ifname;
	uint16_t vid;

	ui_entry_t *cs;

	atomic_t refcnt;
	list_t link;
} vlan_profile_t;

typedef struct _vlan_group_t {
	net_device_t *dev;
	uint16_t gid;
	vlan_profile_t *profile;

	time_t last_create;
	atomic_t refcnt;
	int wait_lower : 1;
	int closing : 1;
	list_t link;
} vlan_group_t;

#define VLAN_MAX_VID		4096
#ifdef CONFIG_VLAN_GROUP
#define VLAN_MAX_GROUPS		CONFIG_VLAN_GROUP
#else
#define VLAN_MAX_GROUPS		8
#endif
#define VLAN_MAX_GID		VLAN_MAX_GROUP - 1

#define VLAN_GROUP_REGISTER	0x01
#define VLAN_GROUP_UNREGISTER	0x02
#define VLAN_GROUP_ADD		0x03
#define VLAN_GROUP_REMOVE	0x04
#define VLAN_GROUP_UP		0x05
#define VLAN_GROUP_GOING_DOWN	0x06
#define VLAN_GROUP_DOWN		0x07

/* ============================================================ *
 * profile operations
 * ============================================================ */
static inline vlan_profile_t *vlan_profile_get(vlan_profile_t *profile)
{
	atomic_inc(&profile->refcnt);
	return profile;
}
static inline void vlan_profile_put(vlan_profile_t *profile)
{
	atomic_dec(&profile->refcnt);
}
void vlan_profile_free(vlan_profile_t *prof);
vlan_group_t *vlan_group_open(net_device_t *dev);
void vlan_group_close(vlan_group_t *group);

/* ============================================================ *
 * group operations
 * ============================================================ */
static inline vlan_group_t *vlan_group_get(vlan_group_t *group)
{
	atomic_inc(&group->refcnt);
	return group;
}
static inline void vlan_group_put(vlan_group_t *group)
{
	atomic_dec(&group->refcnt);
}

int vlan_register_notify(notify_t *nb);
void vlan_unregister_notify(notify_t *nb);
int vlan_group_notify(unsigned long val, void *v);

#endif /* __VLAN_H_INCLUDE__ */
