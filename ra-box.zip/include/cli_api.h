/*****************************************************************************
 * Copyright (C) 2004,2005,2006,2007 Katalix Systems Ltd
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 *
 *****************************************************************************/

#ifndef __CLI_API_H_INCLUDE__
#define __CLI_API_H_INCLUDE__

#include <stdlib.h>
#include <errno.h>
#include <eloop.h>
#include <sysdep.h>
#include <service.h>
#include <setjmp.h>
#include <panic.h>
#include <uiserv.h>
#include <logger.h>

typedef struct _cli_session_t cli_session_t;

#include <cli_readline.h>
#include <cli_history.h>

int cli_execute(int argc, char *argv[]);
int cli_set_prompt(cli_session_t *sess, const char *prompt);
void cli_clear_history(void);

typedef struct _cli_session_ops {
	int (*init_terminal)(cli_session_t *);
	void (*exit_terminal)(cli_session_t *);
	void (*default_bindings)(cli_session_t *);
	int (*prepare_input)(cli_session_t *);
} cli_session_ops;

typedef struct _cli_params_t {
	int instream;
	int outstream;

	cli_session_ops *ops;
} cli_params_t;

typedef struct _cli_terminal_t {
	const char *clreol;
	const char *clrpag;
	const char *im;
	const char *ic;
	const char *ei;
	const char *up;
	const char *cr;
	const char *IC;
	const char *DC;
	const char *dc;

	const char *backspace;
	const char *gotopos;
	const char *pc;

	/* private */
	/* A visible bell; char if the terminal can be made to flash the screen. */
	const char *visible_bell;

	/* The key sequences output by the arrow keys, if this terminal has any. */
	const char *ku;
	const char *kd;
	const char *kr;
	const char *kl;
	
	/* How to initialize and reset the arrow keys, if this terminal has any. */
	const char *ks;
	const char *ke;
	
	/* The key sequences sent by the Home and End keys, if any. */
	const char *kh;
	const char *kH;
	const char *at7;	/* @7 */
	
	/* Delete key */
	const char *kD;
	
	/* Insert key */
	const char *kI;

	const char *forward_char;
	int autowrap;
	int can_insert;
	int screenheight;
	int screenwidth;
	int screenchars;

	char *buffer;
	char *string_buffer;
} cli_terminal_t;

/* The actions that undo knows how to undo.  Notice that UNDO_DELETE means
   to insert some text, and UNDO_INSERT means to delete some text.   I.e.,
   the code tells undo what to undo, not how to undo it. */
#define CLI_UNDO_DELETE		1
#define CLI_UNDO_INSERT		2
#define CLI_UNDO_BEGIN		3
#define CLI_UNDO_END		4

/* What an element of THE_UNDO_LIST looks like. */
typedef struct _cli_undo_t {
	struct _cli_undo_t *next;
	int start, end;		/* Where the change took place. */
	char *text;		/* The text to insert, if undoing a delete. */
	int what;		/* Delete, Insert, Begin, End. */
} cli_undo_t;

#ifndef __internal_var__
#define __internal_var__
#endif

struct _cli_session_t {
	ui_session_t ui;

	log_output_t *logger;
	int debugging;

	__internal_var__ int rl_instream;
	__internal_var__ int rl_outstream;

	__internal_var__ int point;
	__internal_var__ int end;
	__internal_var__ int mark;
	__internal_var__ int done;

	__internal_var__ int banner_done;

	__internal_var__ jmp_buf top_context;
	__internal_var__ int readline_state;
/* Possible state values for rl_readline_state */
#define RL_STATE_NONE		0x000000		/* no state; before first call */

#define RL_STATE_INITIALIZING	0x000001	/* initializing */
#define RL_STATE_INITIALIZED	0x000002	/* initialization done */
#define RL_STATE_TERMPREPPED	0x000004	/* terminal is prepped */
#define RL_STATE_READCMD	0x000008	/* reading a command key */
#define RL_STATE_METANEXT	0x000010	/* reading input after ESC */
#define RL_STATE_DISPATCHING	0x000020	/* dispatching to a command */
#define RL_STATE_MOREINPUT	0x000040	/* reading more input in a command function */
#define RL_STATE_ISEARCH	0x000080	/* doing incremental search */
#define RL_STATE_COMPLETING	0x004000	/* doing completion */
#define RL_STATE_SIGHANDLER	0x008000	/* in readline sighandler */
#define RL_STATE_UNDOING	0x010000	/* doing an undo */
#define RL_STATE_INPUTPENDING	0x020000	/* rl_execute_next called */
#define RL_STATE_TTYCSAVED	0x040000	/* tty special chars saved */
#define RL_STATE_CALLBACK	0x080000	/* using the callback interface */

#define RL_STATE_DONE		0x800000	/* done; accepted line */

#define RL_SETSTATE(s, x)	(s->readline_state |= (x))
#define RL_UNSETSTATE(s, x)	(s->readline_state &= ~(x))
#define RL_ISSTATE(s, x)	(s->readline_state & (x))

	__internal_var__ cli_keymap_t keymap;
	__internal_var__ cli_keymap_t dispatching_keymap;
	__internal_var__ cli_terminal_t term;

	cli_session_ops ops;

	/* Pointer to alternative function to create matches.
	 * Function is called with TEXT, START, and END.
	 * START and END are indices in RL_LINE_BUFFER saying what the
	 * boundaries of TEXT are.
	 * If this function exists and returns NULL then call the value of
	 * rl_completion_entry_function to try to match, otherwise use the
	 * array of strings returned.
	 */
	char **(*attempted_completion)(cli_session_t *sess,
				       const char *, int, int);
	void (*input_hook)(cli_session_t *sess);
	void *input_contex;

#define CLI_INPUT_WAIT_TABLE	0x01
#define CLI_INPUT_WAIT_SEARCH	0x02

	/* If non-zero, completions are printed horizontally in
	 * alphabetical order, like `ls -x'.
	 */
	int print_completions_horizontally;
	int complete_show_all;
	int complete_show_unmodified;
	/* Non-zero means to output characters with the meta bit set
	 * directly rather than as a meta-prefixed escape sequence.
	 */
	int output_meta_chars;

	/* If this is non-zero, completion is (temporarily) inhibited, and
	 * the completion character will be inserted as any other.
	 */
	int inhibit_completion;

	/* Function to call to decide whether or not a word break character is
	   quoted.  If a character is quoted, it does not break words for the
	   completer. */
	cli_linebuf_fn *char_is_quoted_p;

	int echoing_p;
	int insert_mode;
	int dispatching;
	__internal_var__ int last_command_was_kill;
	__internal_var__ int initialized;

	/* The current undo list for RL_LINE_BUFFER. */
	__internal_var__ cli_undo_t *undo_list;
	__internal_var__ int doing_an_undo;
	__internal_var__ int undo_group_level;

	__internal_var__ char **kill_ring;
	__internal_var__ int kill_ring_length;
	__internal_var__ int kill_index;

	__internal_var__ char *the_prompt;

	__internal_var__ char *the_line;
	__internal_var__ int visible_prompt_length;

	int eof_char;

	__internal_var__ char *line_buffer;
	__internal_var__ int line_buffer_len;

	int erase_empty_line;

	cli_command_fn *last_func;

	/* when ? pressed, displaying help is required */
	__internal_var__ int display_help;

	/* Character appended to completed words when at the end of the
	 * line.  The default is a space. */
	int completion_append_character;

	/* The number of characters read in order to type this complete
	 * command.
	 */
	int key_sequence_length;
	/* Non-zero makes this the next keystroke to read. */
	int pending_input;
	/* Pointer to a useful terminal name. */
	const char *terminal_name;

	int do_isearch;

	/* local varible */
	__internal_var__ int completion_changed_buffer;
	__internal_var__ int *inv_lbreaks;
	__internal_var__ int *vis_lbreaks;
	__internal_var__ int inv_lbsize;
	__internal_var__ int vis_lbsize;
};

typedef struct _cli_stream_t {
	const char *name;
	int (*start)(void);
	void (*stop)(void);

	list_t link;
} cli_stream_t;

int cli_bind_key(cli_session_t *, int, cli_command_fn *);
int cli_bind_key_map(cli_keymap_t, int, cli_command_fn *);
int cli_unbind_key(cli_session_t *, int);
int cli_unbind_key_map(cli_keymap_t, int);
int cli_bind_keyseq(cli_session_t *, const char *, cli_command_fn *);
int cli_bind_keyseq_map(cli_keymap_t, const char *, cli_command_fn *);

/* ============================================================ *
 * bindable operations
 * ============================================================ */
int cli_insert(cli_session_t *, int, int);
int cli_tab_insert(cli_session_t *, int, int);
int cli_newline(cli_session_t *, int, int);
int cli_rubout(cli_session_t *, int, int);
int cli_delete(cli_session_t *, int, int);

int cli_forward_byte(cli_session_t *, int, int);
int cli_forward_char(cli_session_t *, int, int);
int cli_forward(cli_session_t *, int, int);
int cli_backward_byte(cli_session_t *, int, int);
int cli_backward_char(cli_session_t *, int, int);
int cli_backward(cli_session_t *, int, int);
int cli_beg_of_line(cli_session_t *, int, int);
int cli_end_of_line(cli_session_t *, int, int);
int cli_forward_word(cli_session_t *, int, int);
int cli_backward_word(cli_session_t *, int, int);
int cli_clear_screen(cli_session_t *, int, int);

int cli_beginning_of_history(cli_session_t *, int, int);
int cli_end_of_history(cli_session_t *, int, int);
int cli_get_next_history(cli_session_t *, int, int);
int cli_get_previous_history(cli_session_t *, int, int);
int cli_complete(cli_session_t *, int, int);
int cli_kill_word(cli_session_t *, int, int);
int cli_backward_kill_word(cli_session_t *, int, int);
int cli_kill_line(cli_session_t *, int, int);
int cli_backward_kill_line(cli_session_t *, int, int);
int cli_kill_full_line(cli_session_t *, int, int);
int cli_unix_word_rubout(cli_session_t *, int, int);
int cli_unix_line_discard(cli_session_t *, int, int);
int cli_reverse_search_history(cli_session_t *, int, int);
int cli_forward_search_history(cli_session_t *, int, int);
int cli_revert_line(cli_session_t *, int, int);
int cli_undo_command(cli_session_t *, int, int);
int cli_abort(cli_session_t *, int, int);

void cli_session_input(cli_session_t *sess);
cli_session_t *cli_session_start(cli_params_t *param);
void cli_session_stop(cli_session_t *sess);

/* ============================================================ *
 * buffer operations
 * ============================================================ */
int cli_stuff_char(cli_session_t *, int);

int cli_ding(cli_session_t *);
int cli_crlf(cli_session_t *);
int cli_backspace(cli_session_t *, int);
void cli_write(cli_session_t *, const char *, int);
void cli_vprintf(cli_session_t *sess, const char *fmt, va_list args);
void cli_flush(cli_session_t *sess);

void cli_printf_eol(ui_session_t *sess, const char *fmt, ...);
void cli_printf(ui_session_t *, const char *fmt, ...);
void cli_print_table(ui_session_t *, ui_table_t *);

int cli_register_stream(cli_stream_t *stream);
void cli_unregister_stream(cli_stream_t *stream);

#endif /* __CLI_API_H_INCLUDE__ */
