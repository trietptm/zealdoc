#ifndef __SYSFS_H_INCLUDE__
#define __SYSFS_H_INCLUDE__

#include <sysdep.h>
#include <list.h>

#define PATH_SIZE			512
#define NAME_SIZE			256

typedef struct _sysfs_device_t sysfs_device_t;

struct _sysfs_device_t {
	list_t node;			/* for device cache */
	sysfs_device_t *parent;		/* already cached parent */
	char devpath[PATH_SIZE];	/**/
	char subsystem[NAME_SIZE];	/* $class, $bus, driver, module */
	char kernel[NAME_SIZE];		/* device instance name */
	char kernel_number[NAME_SIZE];
	char driver[NAME_SIZE];		/* device driver name */
};

void sysfs_device_set_values(sysfs_device_t *dev, const char *devpath,
			     const char *subsystem, const char *driver);
char *sysfs_attr_get_value(const char *devpath, const char *attr_name);
sysfs_device_t *sysfs_device_get_parent(sysfs_device_t *dev);
sysfs_device_t *sysfs_device_get_parent_with_subsystem(sysfs_device_t *dev,
						       const char *subsystem);
sysfs_device_t *sysfs_device_get(const char *devpath);
int sysfs_resolve_link(char *devpath, size_t size);
int sysfs_lookup_devpath_by_subsys_id(char *devpath_full, size_t len,
				      const char *subsystem, const char *id);
const char *sysfs_resolve_path(const char *relative_path);

#endif /* __SYSFS_H_INCLUDE__ */
