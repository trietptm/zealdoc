#ifndef __SCARD_H__
#define __SCARD_H__

#include <sysdep.h>
#include <list.h>

struct scard_handle;
struct scard_card_cmd_param;
struct scard_pin_cmd_data;
typedef void (*scard_cmd_complete)(void *user_data, int ret);

#define SCARD_AID_MAX	16
#define SCARD_APP_MAX	8
#define SCARD_OBJECT_ID_OCTETS_MAX	16

#define SCARD_ATR_MAX	33
#define SCARD_PATH_MAX	16

#define SCARD_SHORT_LC_MAX	255
#define SCARD_SHORT_LE_MAX	256
#define SCARD_EXT_LC_MAX	65535
#define SCARD_EXT_LE_MAX	65536

enum scard_protocol {
	SCARD_PROTOCOL_T0  = 0x00000001,
	SCARD_PROTOCOL_T1  = 0x00000002,
	SCARD_PROTOCOL_RAW = 0x00001000,
	SCARD_PROTOCOL_ANY = 0xFFFFFFFF,
};


enum scard_apdu_case {
	SCARD_APDU_CASE_NONE	= 0x00,
	
	SCARD_APDU_CASE_1	= 0x01,/* CLA INS P1 P2 */
	SCARD_APDU_CASE_2_SHORT	= 0x02,/* CLA INS P1 P2 Le */
	SCARD_APDU_CASE_3_SHORT	= 0x03,/* CLA INS P1 P2 Lc Data */
	SCARD_APDU_CASE_4_SHORT	= 0x04,/* CLA INS P1 P2 Lc Data Le */
	SCARD_APDU_SHORT_MASK	= 0x0f,

	SCARD_APDU_EXT		= 0x10,
	SCARD_APDU_CASE_2_EXT	= SCARD_APDU_CASE_2_SHORT | SCARD_APDU_EXT,
	SCARD_APDU_CASE_3_EXT	= SCARD_APDU_CASE_3_SHORT | SCARD_APDU_EXT,
	SCARD_APDU_CASE_4_EXT	= SCARD_APDU_CASE_4_SHORT | SCARD_APDU_EXT,

	/* The following types let scard determinates whether to use
	 * short or extended APDUs*/
	SCARD_APDU_CASE_2	= 0x22,
	SCARD_APDU_CASE_3	= 0x23,
	SCARD_APDU_CASE_4	= 0x24,
};

/* use command chaining if the Lc value is greater than normally allowed. */
#define SCARD_APDU_FLAG_CHAINING	0x00000001UL
/* do not automatically call GET RESPONSE command to read all available data.*/
#define SCARD_APDU_FLAG_NO_GET_RESP	0x00000002UL
/* do not automatically try a re-transmit with a new  length if the card 
 * return 0x6Cxx(wrong length) */
#define SCARD_APDU_FLAG_NO_RETRY_WL	0x00000004UL

struct scard_apdu {
	int cse; /*apdu case*/
	uint8_t cla, ins, p1, p2;
	uint32_t lc, le;/*1 or 3 bytes*/
	const uint8_t *data;
	size_t datalen;
	uint8_t *resp;
	size_t resplen;
	/*size_t resp_actual;*/

	uint8_t sw1, sw2;
	unsigned long flags;
};


enum scard_path_type {
	SCARD_PATH_TYPE_FILE_ID		= 0,
	SCARD_PATH_TYPE_DF_NAME		= 1,
	SCARD_PATH_TYPE_PATH		= 2,
	SCARD_PATH_TYPE_FROM_CURRENT	= 3,
	SCARD_PATH_TYPE_PARENT		= 4,
};


struct scard_path {
	int type;

	uint8_t value[SCARD_PATH_MAX];
	size_t len;

	/* The next two fileds are used in PKCS15, where 
	 * a path object can reference a portion of a file-count
	 * octets starting at offset index. */
	int idx;
	int count;
};

enum scard_file_type {
	SCARD_FILE_TYPE_DF		= 0x04,
	SCARD_FILE_TYPE_INTERNAL_EF	= 0x03,
	SCARD_FILE_TYPE_WORKING_EF	= 0x01,
};

enum scard_ef_structure {
	SCARD_FILE_EF_UNKNOWN			= 0x00,
	SCARD_FILE_EF_TRANSPARENT		= 0x01,
	SCARD_FILE_EF_LINEAR_FIXED		= 0x02,
	SCARD_FILE_EF_LINEAR_FIXED_TLV		= 0x03,
	SCARD_FILE_EF_LINEAR_VARIABLE		= 0x04,
	SCARD_FILE_EF_LINEAR_VARIABLE_TLV	= 0x05,
	SCARD_FILE_EF_CYCLIC			= 0x06,
	SCARD_FILE_EF_CYCLIC_TLV		= 0x07,
};

enum scard_access_control_method {
	SCARD_AC_NONE		= 0x00000000,
	SCARD_AC_CHV		= 0x00000001,	/* Card Holder Verif. */
	SCARD_AC_TERM		= 0x00000002,	/* Terminal Auth. */
	SCARD_AC_PRO		= 0x00000004,	/* Secure Messaging. */
	SCARD_AC_AUT		= 0x00000008,	/* Key Auth. */

	SCARD_AC_NEVER		= 0xFFFFFFFE,
	SCARD_AC_UNKNOWN	= 0xFFFFFFFF,
};


/* Operations relating to access control (in case of DF) */
#define	SCARD_AC_OP_SELECT		0x00
#define	SCARD_AC_OP_LOCK		0x01
#define	SCARD_AC_OP_DELETE		0x02
#define	SCARD_AC_OP_CREATE		0x03
#define	SCARD_AC_OP_REHABILITATE	0x04
#define	SCARD_AC_OP_INVALIDATE		0x05
#define	SCARD_AC_OP_LIST_FILES		0x06
#define	SCARD_AC_OP_CRYPTO		0x07
#define	SCARD_AC_OP_DELETE_SELF		0x08

/* Operations relating to access control (in case of EF) */
#define	SCARD_AC_OP_READ		0x00
#define	SCARD_AC_OP_UPDATE		0x01
#define SCARD_AC_OP_ERASE		0x02
#define	SCARD_AC_OP_WRITE		0x03
#define	SCARD_AC_OP_USE			0x04 /* (in case of KEY(eg.WATCHDATA card)) */

#define SCARD_AC_OP_MAX			0x09

#define SCARD_AC_KEY_REF_NONE		0xFFFFFFFF

struct scard_acl_entry {
	unsigned int method;	/* enum scard_access_control_flags */
	unsigned int key_ref;

	struct scard_acl_entry *next;
};

/* File status flags */
#define SCARD_FILE_STATUS_ACTIVATED	0x00
#define SCARD_FILE_STATUS_INVALIDATED	0x01
#define SCARD_FILE_STATUS_CREATION	0x02 /* Full access in this state,
					      * (at least for SetCOS 4.4 */

struct scard_file {
	struct scard_path path;
	uint8_t df_name[16];
	size_t df_name_len;

	int type;
	int shareable;
	int ef_structure;
	size_t size;
	int id;
	int status;

	struct scard_acl_entry *acl[SCARD_AC_OP_MAX];

	int record_length;
	int record_count;
	
	uint8_t *sec_attr;
	size_t sec_attr_len;
	uint8_t *prop_attr;
	size_t prop_attr_len;
	uint8_t *type_attr;
	size_t type_attr_len;
};

struct scard_card_operations {
	/* Called when a card match the driver. usually after scard_connect. */
	int (*init)(struct scard_handle *handle);
	int (*exit)(struct scard_handle *handle);

	int (*match)(struct scard_handle *handle, 
		     scard_cmd_complete callback, void *user_data);
	/* ISO 7816 - 4 */
	int (*read_binary)(struct scard_handle *handle, uint32_t offset,
			   uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
			   scard_cmd_complete callback, void *user_data);
	int (*write_binary)(struct scard_handle *handle, uint32_t offset,
			   const uint8_t *sbuf, size_t sbuf_len, uint32_t flags,
			   scard_cmd_complete callback, void *user_data);
	int (*update_binary)(struct scard_handle *handle, uint32_t offset,
			     const uint8_t *sbuf, size_t sbuf_len,
			     uint32_t flags, scard_cmd_complete callback, 
			     void *user_data);
	int (*erase_binary)(struct scard_handle *handle);
	int (*read_record)(struct scard_handle *card_handle, uint8_t rec_nr, 
		      uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		      scard_cmd_complete callback, void *user_data);
	int (*write_record)(struct scard_handle *card_handle, uint8_t rec_nr, 
		      uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		      scard_cmd_complete callback, void *user_data);
	int (*append_record)(struct scard_handle *card_handle,
		      uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		      scard_cmd_complete callback, void *user_data);
	int (*update_record)(struct scard_handle *handle, uint8_t rec_nr,
		       uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		       scard_cmd_complete callback, void *user_data);
	int (*get_data)(struct scard_handle *handle);
	int (*put_data)(struct scard_handle *handle);
	
	int (*select_file)(struct scard_handle *card_handle, 
			   struct scard_path *in_path,
			   struct scard_file **file_out, 
			   scard_cmd_complete callback, void *user_data);

	/* Protocol-T0 oriented */
	int (*get_response)(struct scard_card_cmd_param *card_param, 
			    uint8_t *resp, size_t resp_len, uint32_t le);
	int (*envelope)(struct scard_handle *handle);

	/* ISO 7816 - 8 */
	int (*pin_cmd)(struct scard_handle *handle,
			struct scard_pin_cmd_data *pin_cmd, int tries_left, 
			scard_cmd_complete callback, void *user_data);
	int (*inter_auth)(struct scard_handle *handle);
	int (*exter_auth)(struct scard_handle *handle);
	int (*get_challenge)(struct scard_handle *handle, 
			     uint8_t *rnd, size_t rnd_len,
			     scard_cmd_complete callback, void *user_data);
	int (*manage_channel)(struct scard_handle *handle);
	
	int (*computer_signature)(struct scard_handle *handle);

	/* ISO 7816 - 9 */
	int (*create_file)(struct scard_handle *handle, struct scard_file *filp,
			   scard_cmd_complete callback, void *user_data);
	int (*delete_file)(struct scard_handle *handle, 
			   const struct scard_path *path,
			   scard_cmd_complete callback, void *user_data);
	int (*list_file)(struct scard_handle *handle, uint8_t *buf, size_t buflen,
			 scard_cmd_complete callback, void *user_data);

	int (*check_sw)(struct scard_handle *handle, uint8_t sw1, uint8_t sw2);
	int (*card_ctl)(struct scard_handle *card_handle, 
			unsigned long request, void *data,
			scard_cmd_complete callback, void *user_data);
	int (*process_fci)(struct scard_handle *handle, 
			   struct scard_file *file_out,
			   const uint8_t *buf, size_t buf_len);
	int (*construct_fci)(struct scard_handle *handle, 
			     struct scard_file *filp,
			     uint8_t *fci_buf, size_t *fci_buflen);
};

struct scard_atr_table {
	const char *name;

	const uint8_t *atr;
	const uint8_t *atr_mask;
	
	list_t link;
};

struct scard_card_driver {
	char *name;
	struct scard_card_operations *ops;
	void *priv_data;
	list_t link;
};

struct scard_object_id {
	int value[SCARD_OBJECT_ID_OCTETS_MAX];
};

enum algorithm_id {
	/* PK algorithms */
	SCARD_ALGORITHM_RSA		= 0,
	SCARD_ALGORITHM_DSA		= 1,
	SCARD_ALGORITHM_EC		= 2,

	/* Symmetric algorithms */
	SCARD_ALGORITHM_DES		= 64,
	SCARD_ALGORITHM_3DES		= 65,

	/* Hash algorithms */
	SCARD_ALGORITHM_MD5		= 128,
	SCARD_ALGORITHM_SHA1		= 129,

	/* Key derivation algorithms */
	SCARD_ALGORITHM_PBKDF2		= 192,

	/* Key encryption algoprithms */
	SCARD_ALGORITHM_PBES2		= 256,
};

enum algorithm_flags {
	SCARD_ALGORITHM_ONBOARD_KEY_GEN		= 0x80000000,
	SCARD_ALGORITHM_NEED_USAGE		= 0x40000000,
	SCARD_ALGORITHM_SPECIFIC_FLAGS		= 0x0000FFFF,

	SCARD_ALGORITHM_RSA_RAW			= 0x00000001,

	/* If the card is willing to produce a cryptogram padded with
	 * the following methods, se these flags accordingly. */
	SCARD_ALGORITHM_RSA_PAD_NONE		= 0x00000000,
	SCARD_ALGORITHM_RSA_PAD_PKCS1		= 0x00000002,
	SCARD_ALGORITHM_RSA_PAD_ANSI		= 0x00000004,
	SCARD_ALGORITHM_RSA_PAD_ISO9796		= 0x00000008,
	SCARD_ALGORITHM_RSA_PADS		= 0x0000000E,

	/* If the card is willing to produce a cryptogram with the following 
	 * hash values, set these flags accordingly. */
	SCARD_ALGORITHM_RSA_HASH_NONE		= 0x00000010,
	SCARD_ALGORITHM_RSA_HASH_SHA1		= 0x00000020,
	SCARD_ALGORITHM_RSA_HASH_MD5		= 0x00000040,
	SCARD_ALGORITHM_RSA_HASH_MD5_SHA1	= 0x00000080,
	SCARD_ALGORITHM_RSA_HASH_RIPEMD160	= 0x00000100,
	SCARD_ALGORITHM_RSA_HASH_SHA256		= 0x00000200,
	SCARD_ALGORITHM_RSA_HASH_SHA384		= 0x00000400,
	SCARD_ALGORITHM_RSA_HASH_SHA512		= 0x00000800,
	SCARD_ALGORITHM_RSA_HASH_SHA224		= 0x00001000,
	SCARD_ALGORITHM_RSA_HASHS		= 0x00001FE0,
};

struct scard_algorithm_id {
	unsigned int algorithm;
	struct scard_object_id obj_id;
	void *params;
};

struct scard_pbkdf2_params {
	uint8_t salt[16];
	size_t salt_len;
	int iterations;
	size_t key_length;
	struct scard_algorithm_id hash_alg;
};

struct scard_pbes2_params {
	struct scard_algorithm_id derivation_alg;
	struct scard_algorithm_id key_encr_alg;
};

struct scard_algorithm_info {
	unsigned int algorithm;
	unsigned int key_length;
	unsigned int flags;

	union {
		struct scard_rsa_info {
			unsigned long exponent;
		} _rsa;
	} u;
};

struct scard_app_info {
	uint8_t aid[SCARD_AID_MAX];
	size_t aid_len;
	char *label;
	struct scard_path path;
	uint8_t *ddo;
	size_t ddo_len;

	const char *desc;	/* App description, if known */
	int rec_nr;		/* -1, if EF(DIR) is transparent */
};

#define SCARD_DEFAULT_SEND_MAX	255
#define SCARD_DEFAULT_RECV_MAX	256

/* Card can handle large(> 256 bytes) buffers in calls to read binary,
 * write binary and update binary; if not, several successive calls to
 * the corresponding function is made. */
#define SCARD_CAPS_APDU_EXT		0x00000001
/* Card has on-board random number source. */
#define SCARD_CAPS_RNG			0x00000002
/* Card doesn't return any File control Info. */
#define SCARD_CAPS_NO_FCI		0x00000004
/* Use the card's ACs in scard_pkcs15init_auth(), 
 * instead of relying on the ACL info in the profile files. */
#define SCARD_CAP_USE_FCI_AC		0x00000008
#define SCARD_CAP_RSA_2048		0x00000010

struct scard_handle {
	int reader_idx;
	int slot_idx;
	struct pcsc_ifd_handle *slot_handle;
	
	uint8_t cla;
	uint8_t atr[SCARD_ATR_MAX];
	size_t atr_len;
	size_t max_send;
	size_t max_recv;
	struct scard_path curr_path;

	struct scard_app_info *app[SCARD_APP_MAX];
	int app_count;
	struct scard_file *ef_dir;

	struct scard_card_driver *card_driver;

	uint32_t active_proto;

	unsigned long caps;

#define SCARD_FLAGS_PIN_PAD	0x00000001
#define SCARD_FLAGS_DISPLAY	0x00000002
	int flags;
};

/* SCARD ASN.1 */
#define SCARD_ASN1_TAG_CLASS_MASK		0xC0
#define SCARD_ASN1_TAG_UNIVERSAL		0x00
#define SCARD_ASN1_TAG_APPLICATION		0x40
#define SCARD_ASN1_TAG_CONTEXT			0x80
#define SCARD_ASN1_TAG_PRIVATE			0xC0

#define SCARD_ASN1_TAG_CONSTRUCTED		0x20
#define SCARD_ASN1_TAG_PRIMITIVE		0x1F

enum fci_tag {
	SCARD_FCI_TAG_FCI	= 0x6F,
	SCARD_FCI_TAG_SPEC	= 0xA5,

	SCARD_FCI_TAG_SIZE	= 0x80,/* For transparent EF */
	SCARD_FCI_TAG_ANY	= 0x81,/* For any EF */
	SCARD_FCI_TAG_FD	= 0x82,/* File Descriptor */
	SCARD_FCI_TAG_FID	= 0x83,
	SCARD_FCI_TAG_DF_NAME	= 0x84,
	SCARD_FCI_TAG_PROPRIETARY = 0x85,
	SCARD_FCI_TAG_SECURITY	= 0x86,
	SCARD_FCI_TAG_EF_ID	= 0x87,	/* Ideftifier of and EF containing
					 * an extension of the FCI*/
	SCARD_FCI_TAG_SFI	= 0x88,
	SCARD_FCI_TAG_PRIV	= 0x9F0C,
};

int scard_asn1_read_tag(const uint8_t **buf, size_t buflen, 
			unsigned int *cla_out, unsigned int *tag_out,
			size_t *taglen);
const uint8_t *scard_asn1_find_tag(const uint8_t *buf, size_t buflen,
				   unsigned int tag_in, size_t *taglen_in);
int scard_asn1_put_tag(int tag, const uint8_t *data, size_t datalen,
		       uint8_t *out, size_t out_len, uint8_t **ptr);

struct scard_card_error {
	uint16_t SWs;
	int errorno;
	const char *errorstr;
};

enum {
	SCARD_SUCCESS				= 0,
	SCARD_ERR_INVALID_ARGS			= -1,
	SCARD_ERR_NO_MEM			= -2,
	SCARD_ERR_INSUF_BUFFER			= -3,
	SCARD_ERR_NOT_SUPPORTED			= -4,
	SCARD_ERR_NOT_MATCH			= -5,

	SCARD_ERR_INVALID_ASN1_OBJ		= -6,

	SCARD_ERR_NO_READER			= -10,
	SCARD_ERR_NO_CARD			= -11,
	SCARD_ERR_NO_DRIVER			= -12,
	SCARD_ERR_INVALID_HANDLE		= -13,

	SCARD_ERR_COMMUNICATION			= - 20,


	SCARD_ERR_INVALID_ASN1_OBJECT		= -50,

	/* Resulting from a card command or related to the card*/
	SCARD_ERR_CARD_CMD_FAILED		= -1200,
	SCARD_ERR_FILE_NOT_FOUND		= -1201,
	SCARD_ERR_RECORD_NOT_FOUND		= -1202,
	SCARD_ERR_CLASS_NOT_SUPPORTED		= -1203,
	SCARD_ERR_INS_NOT_SUPPORTED		= -1204,
	SCARD_ERR_INCORRECT_PARAM		= -1205,
	SCARD_ERR_WRONG_LENGTH			= -1206,
	SCARD_ERR_MEMORY_FAILURE		= -1207,
	SCARD_ERR_NO_CARD_SUPPORT		= -1208,
	SCARD_ERR_NOT_ALLOWED			= -1209,
	SCARD_ERR_INVALID_CARD			= -1210,
	SCARD_ERR_UNAUTHORIZED			= -1211,
	SCARD_ERR_AUTH_BLOCKED			= -1212,
	SCARD_ERR_UNKNOWN_RECEIVED		= -1213,
	SCARD_ERR_PIN_CODE_INCORRECT		= -1214,
	SCARD_ERR_FILE_EXISTS			= -1215,
	SCARD_ERR_DATA_OBJ_NOT_FOUND		= -1216,

	/* Muscle */
	SCARD_ERR_SEQUENCE_END			= -1217, /* 9C12*/
	SCARD_ERR_CACHE_EMPTY			= -1218,
	SCARD_ERR_AUTH_FAILED			= -1220,
	SCARD_ERR_INVALID_ALG			= -1222,
	SCARD_ERR_INVALID_SIG			= -1223,

	
	SCARD_ERR_UNSPECIFIED			= -99,
};

void scard_format_path(const char *str, struct scard_path *path);
int scard_append_path(struct scard_path *dest, const struct scard_path *src);
int scard_append_path_id(struct scard_path *dest, const uint8_t *id, 
			 size_t idlen);
int scard_append_file_id(struct scard_path *dest, uint16_t fid);
int scard_compare_path(const struct scard_path *path1, 
		       const struct scard_path *path2);
int scard_compare_path_prefix(const struct scard_path *prefix, 
			      const struct scard_path *path);
const struct scard_path *scard_get_mf_path(void);
int scard_make_absolute_path(const struct scard_path *parent, 
			     struct scard_path *child);

struct scard_file *scard_file_new(void);
void scard_file_free(struct scard_file *file);
void scard_file_dup(struct scard_file **dest, 
		    const struct scard_file *src);


size_t scard_apdu_get_length(const struct scard_apdu *apdu, 
			     unsigned int proto);
int scard_apdu2tpdu(const struct scard_apdu *apdu, uint32_t proto, 
		    uint8_t *out, size_t outlen);

int scard_connect(int reader_idx, int slot_idx, 
		  struct scard_handle **card_handle,
		  scard_cmd_complete callback, void *user_data);
int scard_disconnect(struct scard_handle *card_handle);

#define	SCARD_ICC_PRESENT_POWERUP	0x00
#define	SCARD_ICC_PRESENT_POWERDOWN	0x01
#define SCARD_ICC_ABSENT		0x02

int scard_icc_status(int reader_idx, int slot_idx, int *icc_status);
int scard_check_icc_present_pwd(struct scard_handle *card_handle);
int scard_handle_check_valid(struct scard_handle *card_handle);

/*===========================================================================*/
/*		ISO 7816-4 related functions				     */
/*===========================================================================*/
int scard_select_file(struct scard_handle *handle, struct scard_path *path,
		      struct scard_file **file_out, 
		      scard_cmd_complete callback, void *user_data);

/* XXX: When READ/WRITE/UPDATE data(binary or record) , 
 * the file MUST BE the cuurent selected file */
int scard_read_binary(struct scard_handle *handle, uint16_t offset,
		      uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
		      scard_cmd_complete callback, void *user_data);
int scard_write_binary(struct scard_handle *handle, uint16_t offset,
		       const uint8_t *sbuf, size_t sbuf_len, uint32_t flags,
		       scard_cmd_complete callback, void *user_data);
int scard_update_binary(struct scard_handle *handle, uint16_t offset,
			const uint8_t *sbuf, size_t sbuf_len, uint32_t flags,
			scard_cmd_complete callback, void *user_data);

/* flags for record operations */
#define SCARD_RECORD_EF_ID_MASK	0x0001FUL
/* use first record */
#define SCARD_RECORD_BY_REC_ID	0x00000UL
/* use the specified record number */
#define SCARD_RECORD_BY_REC_NR	0x00100UL
/* use currently selected record */
#define SCARD_RECORD_CURRENT	0x00000UL

/* Read a record from current file.
 * The record number is rec_nr (rec_nr >= 1). */
int scard_read_record(struct scard_handle *card_handle, uint8_t rec_nr, 
		      uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		      scard_cmd_complete callback, void *user_data);
int scard_write_record(struct scard_handle *card_handle, uint8_t rec_nr, 
		      uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		      scard_cmd_complete callback, void *user_data);
int scard_append_record(struct scard_handle *handle,
		       uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		       scard_cmd_complete callback, void *user_data);
int scard_update_record(struct scard_handle *handle, uint8_t rec_nr,
		       uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		       scard_cmd_complete callback, void *user_data);
int scard_delete_record(struct scard_handle *handle, uint8_t rec_nr,
			scard_cmd_complete callback, void *user_data);

int scard_get_response(struct scard_handle *handle, void *resp, 
		       size_t *resp_len, scard_cmd_complete callback, 
		       void *user_data);
int scard_get_challenge(struct scard_handle *handle, void *rnd, 
		       size_t rnd_len, scard_cmd_complete callback, 
		       void *user_data);

/*===========================================================================*/
/*			ISO 7816-8 related functions			     */
/*===========================================================================*/

#define SCARD_PIN_CMD_VERIFY	0
#define SCARD_PIN_CMD_CHANGE	1
#define SCARD_PIN_CMD_UNBLOCK	2

#define SCARD_PIN_CMD_USE_PINPAD	0x0001
#define SCARD_PIN_CMD_NEED_PADDING	0x0002
/* Pin encode type */
#define SCARD_PIN_ENCODING_ASCII	0
#define SCARD_PIN_ENCODING_BCD		1
#define SCARD_PIN_ENCODING_GLP		2 /* Global Platform - Card Spec V2.0.1*/

struct scard_pin_cmd_pin {
	const char *prompt;	/* Prompt to display */

	const uint8_t *data;
	int len;

	size_t min_len;
	size_t max_len;
	unsigned int encode_type;
	size_t pad_len;
	uint8_t pad_char;
	size_t offset;
	size_t len_offset;
};

struct scard_pin_cmd_data {
	unsigned int cmd;
	unsigned int flags;

	unsigned int pin_type;
	int pin_ref;

	struct scard_pin_cmd_pin pin1, pin2;

	struct scard_apdu *apdu;
};

int scard_verify(struct scard_handle *handle, unsigned int type, int ref,
		 const uint8_t *pin, size_t pin_len, int tries_left,
		 scard_cmd_complete callback, void *user_data);
int scard_change(struct scard_handle *card_handle, unsigned int type, int ref,
		 const uint8_t *pin1, size_t pin1_len, 
		 uint8_t *pin2, size_t pin2_len,
		 int tries_left, scard_cmd_complete callback, void *user_data);
int scard_unblock(struct scard_handle *card_handle, unsigned int type, int ref,
		 const uint8_t *pin1, size_t pin1_len, 
		 uint8_t *pin2, size_t pin2_len,
		 int tries_left, scard_cmd_complete callback, void *user_data);

/*===========================================================================*/
/*			ISO7816-9 related functions			     */
/*===========================================================================*/
int scard_create_file(struct scard_handle *card_handle, struct scard_file *filp,
		      scard_cmd_complete callback, void *user_data);
int scard_delete_file(struct scard_handle *card_handle, 
		      const struct scard_path *path,
		      scard_cmd_complete callback, void *user_data);

/*===========================================================================*/
/*			Card Control CMDs				     */
/*===========================================================================*/
#define _CTL_PREFIX(a, b, c) (((a) << 24) | ((b) << 16) | ((c) << 8))

enum scard_ctl_request {
	/*
	 * Generic card_ctl calls
	 */
	SCARD_CARDCTL_GENERIC_BASE = 0x00000000,
	SCARD_CARDCTL_ERASE_CARD,
	SCARD_CARDCTL_GET_DEFAULT_KEY,
	SCARD_CARDCTL_LIFECYCLE_GET,
	SCARD_CARDCTL_LIFECYCLE_SET,
	SCARD_CARDCTL_GET_SERIALNR,

	/*
	 * Watch Data TimeCOS/PK specific calls
	 */
	 SCARD_CARDCTL_WD_BASE = _CTL_PREFIX('W', 'D', 'P'),
	 SCARD_CARDCTL_WD_GENERATE_KEY,
	 SCARD_CARDCTL_WD_DATA_COMPRESS,
	 SCARD_CARDCTL_WD_ENCRYPT,
	 SCARD_CARDCTL_WD_DECRYPT,
	 SCARD_CARDCTL_WD_VERIFY_SIGN,
	 SCARD_CARDCTL_WRITE_KEY,
	 SCARD_CARDCTL_WD_IMPORT_KEY,
};

/* Watch Data Card Control */
#define WD_MAX_KEY_SIZE		16


enum wd_key_type {
	WD_KEY_TYPE_DES_ENCRYPT		= 0x30,
	WD_KEY_TYPE_DES_DECRYPT		= 0x31,
	WD_KEY_TYPE_DESMAC		= 0x32,
	WD_KEY_TYPE_INTERNAL		= 0x34,
	WD_KEY_TYPE_MAINTANCE		= 0x36,
	WD_KEY_TYPE_PIN_UNBLOCK		= 0x37,
	WD_KEY_TYPE_PIN_RELOAD		= 0x38,
	WD_KEY_TYPE_EXTERNAL_AUTH	= 0x39,
	WD_KEY_TYPE_MAIN		= WD_KEY_TYPE_EXTERNAL_AUTH,
	WD_KEY_TYPE_PIN			= 0x3A,
	WD_KEY_TYPE_UNBLOCK		= 0x3B,
	WD_KEY_TYPE_UPDATE_OVERDRAW	= 0x3C,
	WD_KEY_TYPE_DEBIT		= 0x3D,
	WD_KEY_TYPE_PURCHASE		= 0x3E,
	WD_KEY_TYPE_CREDIT		= 0x3F,
};

/*Default Card and DF 's Regsiter state*/
#define WATCHDATA_SEC_STATE_NONE	0xF0
#define WATCHDATA_SEC_STATE_PIN		0x11
#define WATCHDATA_SEC_STATE_AUTH	0xAA
#define WATCHDATA_SEC_STATE_NEVER	0xEF

struct scard_cardctl_wd_write_key {
#define WRITE_KEY_ACTION_LOAD	0x00
#define WRITE_KEY_ACTION_UPDATE	0x01
	uint8_t action;
	uint8_t kid;	/*reference */
	uint8_t pid;	/*parent DF FID */
	/* Key header */
	uint8_t type;
	uint8_t perm_use;
	uint8_t perm_update;
	union {
		uint8_t ver;
		uint8_t next_state;	/* for EXTERNAL AUTH and PIN */
		uint8_t pinid;		/* for WD_KEY_TYPE_PIN_UNBLOCK */
	}b4;
	union {
		uint8_t flag;
		uint8_t tries;
	}b5;
	/* Key value */
	uint8_t value[WD_MAX_KEY_SIZE];
	size_t len;
};

int scard_card_ctl(struct scard_handle *card_handle, 
		   unsigned long request, void *data,
		   scard_cmd_complete callback, void *user_data);


#endif /*__SCARD_H__*/
