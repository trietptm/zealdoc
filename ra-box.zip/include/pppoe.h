#ifndef __PPPOE_H_INCLUDE__
#define __PPPOE_H_INCLUDE__

#include <sysdep.h>
#include <ppp.h>

#define PPPOE_SERVICE_DESC	"PPP over ethernet protocol"
#define PPPOE_SERVICE_NAME	"pppoe"
	
/* ETH_HLEN + type and ver + code + sess_id(2) + len(2) = 20 */
#define PPPOE_HDRLEN		(ETH_HLEN + 6)		

#define MAX_HOST_NAME_LEN	32

#define PPPOE_MODE_CLIENT	0
#define PPPOE_MODE_SERVER	1

#ifdef CONFIG_PPPOE_SESSIONS
#define PPPOE_MAX_SESSIONS	CONFIG_PPPOE_SESSIONS
#else
#define PPPOE_MAX_SESSIONS	8
#endif

typedef struct _pppoe_path_t pppoe_path_t;
typedef struct _pppoe_front_t pppoe_front_t;
typedef struct _pppoe_config_t pppoe_config_t;
typedef struct _pppoe_session_t pppoe_session_t;
typedef struct _pppoe_message_t pppoe_message_t;
typedef struct _pppoe_profile_t pppoe_profile_t;
typedef struct _pppoe_sniffer_t pppoe_sniffer_t;

struct _pppoe_path_t {
	const char *name;
	void *(*data_open)(pppoe_session_t *);
	void (*data_close)(pppoe_session_t *, void *data);
	int (*data_send)(pppoe_session_t *, msgbuf_t *);
	int (*set_recv_option)(pppoe_session_t *, uint16_t protocol,
			       uint8_t option_type, void *arg);
	int (*get_recv_option)(pppoe_session_t *, uint16_t protocol,
			       uint8_t option_type, void *arg);
	int (*set_send_option)(pppoe_session_t *, uint16_t protocol,
			       uint8_t option_type, void *arg);
	int (*get_send_option)(pppoe_session_t *, uint16_t protocol,
			       uint8_t option_type, void *arg);
	list_t link;
};

struct _pppoe_profile_t {
	const char *name;
	int mode;
	const char *ifname;
	ui_entry_t *cs;
	atomic_t refcnt;
	list_t link;
};

struct _pppoe_config_t {
	uint16_t 	max_retrans;
	uint16_t 	retrans_interval;
};

struct _pppoe_message_t {
	uint8_t		*local;
	uint8_t		*peer;
	uint16_t	eth_type;
	uint16_t	sid;
	int		data;		/* put what in here? */
};

struct _pppoe_session_t {
	uint16_t	sid;
	int		mode;
	uint8_t		state;
	
	char ifname[IFNAMSIZ];
	int wait_dev;	/* wait dev flag */
	/* ethernet address */
	uint8_t		local_eth[ETH_ALEN];
	uint8_t		peer_eth[ETH_ALEN];

	uint8_t		*ac_cook;
	int		ac_cook_len;
	
	uint8_t		acname[MAX_HOST_NAME_LEN];
	int 		acname_len;

	uint8_t		*uniq;
	int		uniq_len;

	uint16_t	st_flag;	/* send tag flag */
	uint16_t	rt_flag;	/* recv tag flag */

	ppp_phase_t     *ctx;		/* ppp_phase_t */
	nac_client_t	*nac_client;
	void		*path;		/* data path */
	pppoe_sniffer_t *sniff;	
	
	int		retrans_count;
	list_t		link;
};

typedef struct _pppoe_mode_t {
	int mode;
	const char *name;
	const char *desc;
	int (*process_packet)(pppoe_session_t *s, uint8_t *peer, uint16_t sid, uint8_t code);
	list_t link;
} pppoe_mode_t;

struct _pppoe_sniffer_t {
	int		disc_id;	/* pcap id for discovery stage */
	int		sess_id;	/* pcap id for session stage */

	int		mode;
	pppoe_profile_t *prof;

	int wait_dev;

	/* store filter */
#define MAX_FILTER_LEN	100
	/* e.g. ether dst host or broadcast and pppoed */
	char		host_filter[MAX_FILTER_LEN];
	/* Do not need refcnt. 
	 * Every session who refer this sniff will be inserted to list */
	list_t		sessions;  /* link all sessions that reference this sniff. */
	list_t		link;
};

struct _pppoe_front_t {
	nac_t *nac;
	list_t link;
};

static inline pppoe_profile_t *pppoe_prof_get(pppoe_profile_t *prof)
{
	atomic_inc(&prof->refcnt);
	return prof;
}

static inline void pppoe_prof_put(pppoe_profile_t *prof)
{
	atomic_dec(&prof->refcnt);
}


int pppoe_register_data_path(pppoe_path_t *xprt);
void pppoe_unregister_data_path(pppoe_path_t *xprt);
int  pppoe_message_add_info(msgbuf_t *msg, int i);
pppoe_path_t *pppoe_get_data_path(void);
pppoe_profile_t *pppoe_get_profile_by_name(const char *name);

/* called by channel */
int pppoe_nac_start(pppoe_profile_t *prof, ppp_profile_t *pprof, nac_t *nac);
void pppoe_nac_stop(pppoe_profile_t *prof, nac_t *nac);
void pppoe_nic_stop(pppoe_session_t *s);
pppoe_session_t *pppoe_nic_start(pppoe_profile_t *prof, 
				 ppp_phase_t *phase, nac_param_t param);

#endif	/* __PPPOE_H_INCLUDE__ */

