/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2008
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@hzcnc.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)spoof.h: helper routines for ARP/IP/TCP/DHCP spoofing
 * $Id: spoof.h,v 1.12 2009-02-12 03:36:05 zhenglv Exp $
 */

#ifndef __SPOOF_H_INCLUDE__
#define __SPOOF_H_INCLUDE__

#include <sysdep.h>
#include <net_skb.h>
#include <linux/if_ether.h>

/* interfaces for spoofing a raw Ethernet-II packet
 * this module is required by DHCP client / EAPoL
 * PPPoE implementations
 */
#define IP_HLEN_MIN	20
#define UDP_HLEN	8
#define UDPIP_HLEN		(IP_HLEN_MIN + UDP_HLEN)

uint16_t in_checksum(uint16_t *addr, size_t len);

void eth_build_header(msgbuf_t *msg,
		      uint8_t *from, uint8_t *to,
		      uint16_t protocol);
void udp_build_header(msgbuf_t *msg,
		      uint32_t saddr, uint32_t daddr,
		      uint16_t sport, uint16_t dport);
int eth_parse_header(msgbuf_t *msg,
		     uint8_t **src, uint8_t **dst,
		     uint16_t *protocol);
int udp_parse_header(msgbuf_t *msg,
		     uint32_t *saddr, uint32_t *daddr,
		     uint16_t *sport, uint16_t *dport);

extern uint8_t eth_unknown_addr[ETH_ALEN];
extern uint8_t eth_bcast_addr[ETH_ALEN];

#endif /* __SPOOF_H_INCLUDE__ */
