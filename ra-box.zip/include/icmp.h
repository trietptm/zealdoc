#ifndef __ICMP_H_INCLUDE__
#define __ICMP_H_INCLUDE__

#include <sysdep.h>
#include <notify.h>
#include <service.h>
#include <linux/icmp.h>

extern service_depend_t icmp_depend;

const char *icmp_type_name(int id);

int __init icmp_init(void);
void __exit icmp_exit(void);

#endif /* __ICMP_H_INCLUDE__ */
