#ifndef __FSSERV_H_INCLUDE__
#define __FSSERV_H_INCLUDE__

#ifdef __cplusplus
extern "C" {
#endif

#include <sysdep.h>
#include <module.h>
#include <strutl.h>
#include <sysfs.h>

#define _PATH_SYS			"/sys"
#define _PATH_PROC			"/proc"
#define _PATH_DEVPTS			"/dev/pts"
#define _PATH_DEVSHM			"/dev/shm"

#define ROOTFS_SERVICE_NAME		"rootfs"

typedef struct _fs_type_t {
	char *type;
	int nodev;
	list_t link;
} fs_type_t;

int fs_mount_single(const char *dev, const char *dir,
		    const char *fstype, const char *cmdopts);

int fs_create_path(const char *path);
int fs_delete_path(const char *path);
int fs_unlink_secure(const char *filename);
int fs_copy_file(const char *from, const char *to);
int fs_path_isdir(const char *file);
int fs_path_islink(const char *file);
int fs_create_dir(const char *dir);
int fs_remove_dir(const char *path);
int fs_copy_dir(const char *oldpath, const char *newpath);
int fs_make_dir(const char *dir);

int file_map(const char *filename, char **buf, size_t *bufsize);
void file_unmap(void *buf, size_t bufsize);
size_t buf_get_line(const char *buf, size_t buflen, size_t cur);
char *path_to_procfs(const char *tail);

int lock_file(const char *file, FILE **pfp);
void unlock_file(FILE *fp);
int fs_touch_file(const char *file);

int fs_loop_set(char **device, const char *file, uint64_t offset);
int fs_loop_unset(const char *device);

/* File listing canonical interesting mount points.  */
#define	MNTTAB		"/dev/mtab"	/* Deprecated alias.  */

/* File listing currently active mount points.  */
#define	MOUNTED		"/etc/mtab"	/* Deprecated alias.  */

/* General filesystem types.  */
#define MNTTYPE_IGNORE	"ignore"	/* Ignore this entry.  */
#define MNTTYPE_NFS	"nfs"		/* Network file system.  */
#define MNTTYPE_SWAP	"swap"		/* Swap device.  */


/* Generic mount options.  */
#define MNTOPT_DEFAULTS	"defaults"	/* Use all default options.  */
#define MNTOPT_RO	"ro"		/* Read only.  */
#define MNTOPT_RW	"rw"		/* Read/write.  */
#define MNTOPT_SUID	"suid"		/* Set uid allowed.  */
#define MNTOPT_NOSUID	"nosuid"	/* No set uid allowed.  */
#define MNTOPT_NOAUTO	"noauto"	/* Do not auto mount.  */

/* Structure describing a mount table entry.  */
typedef struct _fs_mntent_t {
	char *mnt_fsname;	/* Device or server for filesystem.  */
	char *mnt_dir;		/* Directory mounted on.  */
	char *mnt_type;		/* Type of filesystem: ufs, nfs, etc.  */
	char *mnt_opts;		/* Comma-separated options for fs.  */
	int mnt_freq;		/* Dump frequency (in days).  */
	int mnt_passno;		/* Pass number for `fsck'.  */
} fs_mntent_t;

extern fs_mntent_t *fs_mntent_get(FILE *stream);
extern int fs_mntent_add(FILE *stream,
			 const fs_mntent_t *mnt);
extern int fs_mntent_end(FILE *stream);
extern char *fs_has_mntopt(const fs_mntent_t *mnt,
			   const char *opt);
extern FILE *fs_mntent_begin(const char *__file, const char *__mode);

#ifdef __cplusplus
}
#endif

#endif /* __FSSERV_H_INCLUDE__ */
