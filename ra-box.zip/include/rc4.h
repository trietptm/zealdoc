#ifndef __RC4_H_INCLUDE__
#define __RC4_H_INCLUDE__

#include <sysdep.h>

typedef struct _rc4_t {      
	uint8_t state[256];       
	uint8_t x;        
	uint8_t y;
} rc4_t;

void rc4_key(rc4_t *ctx, uint8_t *key, size_t length);
void rc4(rc4_t *key, uint8_t *buffer, size_t length);

#endif /* __RC4_H_INCLUDE__ */
