#ifndef __NETPHY_H_INCLUDE__
#define __NETPHY_H_INCLUDE__

#include <net_if.h>

/* PHY type */
typedef struct _net_physic_t net_physic_t;
/* L1-port */
typedef struct _net_port_t net_port_t;

/* add to net_ports */
#define NET_PORT_REGISTER	0x0a
/* remove from net_ports */
#define NET_PORT_UNREGISTER	0x0b
/* port link up */
#define NET_PORT_UP		0x0c
/* port link down */
#define NET_PORT_DOWN		0x0d

#define NET_MIB_UNDEF		0x00
#define NET_MIB_RMON		0x01
#define NET_MIB_IFGRP		0x02
#define NET_MIB_BRIDGE		0x03

/* RMON counters (RFC 2819) */
typedef struct _net_mib_rmon_t {
	/* Rx counters */
	uint64_t rx_etherStatsDropEvents;
	uint64_t rx_etherStatsOctets;
	uint64_t rx_etherStatsPkts;
	uint64_t rx_etherStatsBroadcastPkts;
	uint64_t rx_etherStatsMulticastPkts;
	uint64_t rx_etherStatsCRCAlignErrors;
	uint64_t rx_etherStatsUndersizePkts;
	uint64_t rx_etherStatsOversizePkts;
	uint64_t rx_etherStatsFragments;
	uint64_t rx_etherStatsJabbers;
	uint64_t rx_etherStatsPkts64Octets;
	uint64_t rx_etherStatsPkts65to127Octets;
	uint64_t rx_etherStatsPkts128to255Octets;
	uint64_t rx_etherStatsPkts256to511Octets;
	uint64_t rx_etherStatsPkts512to1023Octets;
	uint64_t rx_etherStatsPkts1024to1518Octets;
	uint64_t rx_etherStatsPkts1519toMaxOctets;  /* Proprietary */
	/* Tx counters */
	uint64_t tx_etherStatsDropEvents;
	uint64_t tx_etherStatsOctets;
	uint64_t tx_etherStatsPkts;
	uint64_t tx_etherStatsBroadcastPkts;
	uint64_t tx_etherStatsMulticastPkts;
	uint64_t tx_etherStatsCollisions;
	uint64_t tx_etherStatsPkts64Octets;
	uint64_t tx_etherStatsPkts65to127Octets;
	uint64_t tx_etherStatsPkts128to255Octets;
	uint64_t tx_etherStatsPkts256to511Octets;
	uint64_t tx_etherStatsPkts512to1023Octets;
	uint64_t tx_etherStatsPkts1024to1518Octets;
	uint64_t tx_etherStatsPkts1519toMaxOctets;  /* Proprietary */
} net_mib_rmon_t;

/* Interfaces Group counters (RFC 2863) */ 
typedef struct _net_mib_ifgrp_t {
	/* Rx counters */
	uint64_t ifInOctets;
	uint64_t ifInUcastPkts;
	uint64_t ifInMulticastPkts;
	uint64_t ifInBroadcastPkts;
	uint64_t ifInNUcastPkts;
	uint64_t ifInDiscards;
	uint64_t ifInErrors;
	
	/* Tx counters */
	uint64_t ifOutOctets;
	uint64_t ifOutUcastPkts;
	uint64_t ifOutMulticastPkts;
	uint64_t ifOutBroadcastPkts;
	uint64_t ifOutNUcastPkts;
	uint64_t ifOutDiscards;
	uint64_t ifOutErrors;
} net_mib_ifgrp_t;

/* Bridge counters (RFC 4188) */
typedef struct _net_mib_bridge_t {
	uint64_t dot1dTpPortInDiscards;
} net_mib_bridge_t;

/* ============================================================ *
 * L2-PHY definitions
 * ============================================================ */
struct _net_port_t {
	list_t link;
	list_t link_dev;

	/* logical port no */
	int port_no;
	int phys_port_no;
	net_physic_t *phys;

	/* config */
	int enabled;

	/* status */
	int port_speed;
#define NET_SPEED_UNDEF	0
#define NET_SPEED_10M	1
#define NET_SPEED_100M	2
#define NET_SPEED_1G	3
#define NET_SPEED_2500M	4 /* 2.5G */
#define NET_SPEED_5G	5 /* 5G or 2x2.5G */
#define NET_SPEED_10G	6

	int link_state;
#define NET_LINK_DOWN	0x00
#define NET_LINK_UP		0x01
	bool full_duplex;
};

struct _net_physic_t {
	const char *name;
	const char *desc;

	int (*get_mib)(net_port_t *port, int mib, void *counters);
	int (*get_status)(net_port_t *port);
	int (*get_config)(net_port_t *port);
	int (*set_config)(net_port_t *port);

	list_t link;
};

#define ETH_ADDR_LEN	6

/* MAC table entry */
typedef struct _mac_entry_t {
	uint8_t mac[MAX_ADDR_LEN];
	uint16_t vid;
	int state;
#define SWITCH_MAC_UNDEF	0
#define SWITCH_MAC_LEARNED	1
#define SWITCH_MAC_AGED		2
} mac_entry_t;

typedef struct _bridge_id_t {
	unsigned char	prio[2];
	unsigned char	addr[6];
} bridge_id_t;

typedef struct _net_bridge_t {
	list_t port_list;

	net_device_t *dev;

	/* STP */
	bridge_id_t designated_root;
	bridge_id_t bridge_id;

	uint32_t root_path_cost;

	uint8_t group_addr[ETH_ADDR_LEN];
	uint16_t root_port;

	int topology_change;
	int topology_change_detected;
} net_bridge_t;

const char *mac_entry_state2name(int state);

/* ============================================================ *
 * MIB operations
 * ============================================================ */
const char *net_mib2name(int type);

/* ============================================================ *
 * phys operations
 * ============================================================ */
net_physic_t *net_physic_by_name(const char *name);
int net_register_physic(net_physic_t *phys);
void net_unregister_physic(net_physic_t *phys);
net_physic_t *net_iterate_physic(net_physic_t *phys);

/* ============================================================ *
 * port operations
 * ============================================================ */
net_port_t *net_port_by_logical(int port_no);
int net_register_port(int log, int phy, const char *type);
void net_unregister_port(int port_no);
const char *net_port_link2name(int state);
const char *net_port_speed2name(int speed);
void net_port_link(int port_no, int link_state);
int net_port_notify(unsigned long val, void *v);
int net_port_get_counter(net_port_t *port, int mib, void *cnts);
int net_port_get_status(net_port_t *port);

#endif /* __NETPHY_H_INCLUDE__ */
