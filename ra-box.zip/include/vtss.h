#ifndef __VTSS_H_INCLUDE__
#define __VTSS_H_INCLUDE__

/* Vitesse G'RocX support */
#include <sysdep.h>

#include <vtss_board.h>
#include <vtss_conf.h>

#define _PATH_VITGENIO		"/dev/vitgenio"

#define VTSS_SERVICE_NAME	"vtss"

/* ================================================================= *
 * return codes
 * ================================================================= */
#define VTSS_RC(expr) { int rc = (expr); if (rc != 0) return rc; }

/* General warnings */
#define VTSS_WARNING            -0x01  /* Error, but fixed by API. */
#define VTSS_INCOMPLETE         -0x02  /* Operation incomplete */

/* General errors */
#define VTSS_UNSPECIFIED_ERROR  -0x03
#define VTSS_NOT_IMPLEMENTED    -0x04
#define VTSS_INVALID_PARAMETER  -0x05
#define VTSS_DATA_NOT_READY     -0x06
#define VTSS_ENTRY_NOT_FOUND    -0x07
#define VTSS_TIMEOUT_RETRYLATER -0x08  /* Timeout, retry later. */
#define VTSS_FATAL_ERROR        -0x09  /* Fatal error. Chip reset required. */

/* PHY errors */
#define VTSS_PHY_NOT_MAPPED     -0x10
#define VTSS_PHY_READ_ERROR     -0x11  /* No PHY read reply. */
#define VTSS_PHY_TIMEOUT        -0x12  /* The PHY did not react within spec'ed time */

/* Packet errors */
#define VTSS_PACKET_BUF_SMALL    -0x30 
#define VTSS_PACKET_PROTOCOL_ERROR -0x31
 
/* Layer 2 errors */
#define VTSS_AGGR_INVALID       -0x40

/* I/O errors for Vitesse implementation */
#define VTSS_IO_READ_ERROR      -0x60  /* I/O Layer read error */
#define VTSS_IO_WRITE_ERROR     -0x61  /* I/O Layer write error */
#define VTSS_IO_DMA             -0x62  /* I/O Layer DMA error */

#define VTSS_IO_NIC_READ_ERROR  -0x63  /* I/O NIC Layer read error */
#define VTSS_IO_NIC_WRITE_ERROR -0x64  /* I/O NIC Layer write error */
#define VTSS_IO_NIC_ERROR       -0x65  /* I/O NIC Layer error */

#ifdef WIN32
#define VTSS_NSLEEP(nsec) { Sleep((nsec+999999)/1000000); }
#define VTSS_MSLEEP(msec) { Sleep(msec); }
#else
#define VTSS_NSLEEP(nsec) { \
	struct timespec ts = { 0, nsec }; \
	while (nanosleep(&ts,&ts) == -1 && errno == EINTR); \
}
#define VTSS_MSLEEP(msec) { \
	struct timespec ts; \
	ts.tv_sec = msec/1000; \
	ts.tv_nsec = (msec%1000)*1000000; \
	while (nanosleep(&ts,&ts) == -1 && errno == EINTR); \
}
#endif

/* The function "gettimeofday" is available, so use it. */
typedef struct _vtss_mtimer_t {
	struct timeval  timeout;
	struct timeval  now;
} vtss_mtimer_t;

#define VTSS_MTIMER_START(timer,msec) { \
	gettimeofday(&((timer)->timeout), NULL); \
	(timer)->timeout.tv_usec += msec*1000; \
	if ((timer)->timeout.tv_usec >= 1000000) { \
		(timer)->timeout.tv_sec += (timer)->timeout.tv_usec/1000000; \
		(timer)->timeout.tv_usec%=1000000; \
	} \
}
#define VTSS_MTIMER_TIMEOUT(timer) (gettimeofday(&((timer)->now),NULL)==0 && timercmp(&((timer)->now),&((timer)->timeout),>))
#define VTSS_MTIMER_CANCEL(timer) /* No action in this implementation. */

/* ================================================================= *
 *  Various definitions and macros
 * ================================================================= */
/* MAKEBOOL01(value): Convert BOOL value to 0 (false) or 1 (true). */
/* Use this to ensure BOOL values returned are always 1 or 0. */
#ifndef MAKEBOOL01
#define MAKEBOOL01(value) ((value)?1:0)
#endif

/* Event type. When a variable of this type is used as an input parameter,
   the API will set the variable if the event has occured. The API will 
   never clear the variable. If is up to the application to clear the
   variable, when the event has been handled. */
typedef BOOL vtss_event_t;

#ifndef NULL
#define NULL ((void *)0)
#endif

typedef struct _vtss_config_t {
	int mac_aging;
#define VTSS_MAC_AGE_DEFAULT	300 /* 300 seconds MAC age timer by default */
} vtss_config_t;

const char *vtss_error_string(int rc);
const char *vtss_iftype2name(int mac_if);

#endif /* __VTSS_H_INCLUDE__ */
