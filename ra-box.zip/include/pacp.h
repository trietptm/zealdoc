#ifndef __PACP_H_INCLUDE__
#define __PACP_H_INCLUDE__

#include <sysdep.h>
#include <nfastm.h>
#include <eap.h>

typedef struct _pae_t pae_t;
typedef struct _pae_link_t pae_link_t;

typedef struct _pae_supp_t pae_supp_t;
typedef struct _pae_supp_fe_t pae_supp_fe_t;
typedef struct _pae_supp_be_t pae_supp_be_t;

/* abstract of lower link layer for EAP */
struct _pae_link_t {
	const char *name;
	void (*txSuppRsp)(pae_supp_t *supp, void *eapLowerData);
	void (*txLogoff)(pae_supp_t *supp, void *eapLowerData);
	void (*txStart)(pae_supp_t *supp, void *eapLowerData);
	void (*getSuppRsp)(pae_supp_t *supp, void *eapLowerData);
	msgbuf_t *(*getSuppMsg)(pae_supp_t *supp, void *eapLowerData);
	void (*eapSuccess)(pae_supp_t *supp, void *eapLowerData);
	void (*eapFailure)(pae_supp_t *supp, void *eapLowerData);
	list_t link;
};

/* The controlled port is required to be held in the Unauthorized state */
#define PAE_PORT_FORCE_UNAUTHORIZED	1
/* The controlled port is required to be held in the Authorized state */
#define PAE_PORT_FORCE_AUTHORIZED	2
/* The controlled port is set to the Authorized or Unauthorized state
 * in accordance with the outcome of an authentication exchange between
 * the Supplicant and the Authentication Server
 */
#define PAE_PORT_AUTO			0

struct _pae_t {
	bool authAbort;
	bool authFail;
	int authPortState;
#define PAE_PORT_UNAUTHORIZED	0
#define PAE_PORT_AUTHORIZED	1
	bool authStart;
	bool authTimeout;
	bool authSuccess;
	/* eapolEap */
	bool paeEap;
	bool initialize;
	bool keyAvailable;
	bool keyDone;
	bool keyRun;
	bool keyTxEnabled;
	int portControl;
	int portStatus;
	bool portValid;
	bool reAuthenticate;
	bool suppAbort;
	bool suppFail;
	int suppPortStatus;
	bool suppStart;
	bool suppSuccess;
	bool suppTimeout;
};

struct _pae_supp_be_t {
	pae_supp_t *supp;
	eap_peer_t *peer;

	/* Constants */
	int authPeriod;
#define PAE_SUPP_AUTH_PERIOD	30

	int stm_changed;
	int stm_state;
#define PAE_SUPP_BE_INITIALIZE	1
#define PAE_SUPP_BE_IDLE	2
#define PAE_SUPP_BE_REQUEST	3
#define PAE_SUPP_BE_RESPONSE	4
#define PAE_SUPP_BE_RECEIVE	5
#define PAE_SUPP_BE_FAIL	6
#define PAE_SUPP_BE_TIMEOUT	7
#define PAE_SUPP_BE_SUCCESS	8
};

struct _pae_supp_fe_t {
	pae_supp_t *supp;
	eap_peer_t *peer;

	/* Variables */
	bool logoffSent;
	int sPortMode;

	int startCount;
	bool userLogoff;

	/* Constants */
	int heldPeriod;
#define PAE_HELD_PERIOD			60
	int startPeriod;
#define PAE_START_PERIOD		60
	int maxStart;
#define PAE_MAX_START			3

	int stm_changed;
	int stm_state;
#define PAE_SUPP_FE_LOGOFF		1
#define PAE_SUPP_FE_DISCONNECTED	2
#define PAE_SUPP_FE_CONNECTING		3
#define PAE_SUPP_FE_AUTHENTICATING	4
#define PAE_SUPP_FE_HELD		5
#define PAE_SUPP_FE_AUTHENTICATED	6
#define PAE_SUPP_FE_RESTART		7
#define PAE_SUPP_FE_S_FORCE_AUTH	8
#define PAE_SUPP_FE_S_FORCE_UNAUTH	9
};

struct _pae_supp_t {
	int authWhile;
	int heldWhile;
	int startWhen;

	/* EAP-Identity */
	const char *username;
	const char *password;

	pae_t pae;
	pae_supp_fe_t suppFe;
	pae_supp_be_t suppBe;
	eap_peer_t eapPeer;
	eap_profile_t *eapProf;

	pae_link_t *eapLower;
	void *eapLowerData;
};

void pae_abortSupp(pae_supp_be_t *sm);
void pae_getSuppRsp(pae_supp_be_t *sm);
void pae_txSuppRsp(pae_supp_be_t *sm);
void pae_txLogoff(pae_supp_fe_t *sm);
void pae_txStart(pae_supp_fe_t *sm);

pae_supp_t *pae_supp_new(const char *name, const char *prof,
			 bool tunneling, void *priv);
void pae_supp_free(pae_supp_t *sm);
void pae_supp_input(pae_supp_t *sm, msgbuf_t *msg);
void pae_supp_run(pae_supp_t *sm);
msgbuf_t *pae_supp_message(void *sm);
void pae_supp_abort(pae_supp_t *sm);

void pae_setUsername(pae_supp_t *sm, const char *username);
const char *pae_getUsername(pae_supp_t *sm);
void pae_setPassword(pae_supp_t *sm, const char *password);
const char *pae_getPassword(pae_supp_t *sm);

int pae_register_link(pae_link_t *lnk);
void pae_unregister_link(pae_link_t *lnk);
pae_link_t *pae_find_link(const char *name);

#endif /* __PACP_H_INCLUDE__ */
