#ifndef __OAKLEY_H_INCLUDE__
#define __OAKLEY_H_INCLUDE__

#include <sysdep.h>
#include <vchar.h>
#include <module.h>

/* refer to RFC 2409 */

/* Attribute Classes */
#define OAKLEY_ATTR_ENC_ALG		1 /* B */
#define   OAKLEY_ATTR_ENC_ALG_DES		1
#define   OAKLEY_ATTR_ENC_ALG_IDEA		2
#define   OAKLEY_ATTR_ENC_ALG_BLOWFISH		3
#define   OAKLEY_ATTR_ENC_ALG_RC5		4
#define   OAKLEY_ATTR_ENC_ALG_3DES		5
#define   OAKLEY_ATTR_ENC_ALG_CAST		6
#define   OAKLEY_ATTR_ENC_ALG_AES		7
#define   OAKLEY_ATTR_ENC_ALG_CAMELLIA		8	
					/*	65001 - 65535 Private Use */
#define OAKLEY_ATTR_HASH_ALG		2 /* B */
#define   OAKLEY_ATTR_HASH_ALG_MD5		1
#define   OAKLEY_ATTR_HASH_ALG_SHA		2
#define   OAKLEY_ATTR_HASH_ALG_TIGER		3
#define   OAKLEY_ATTR_HASH_ALG_SHA2_256		4
#if defined(WITH_SHA2)
#define   OAKLEY_ATTR_HASH_ALG_SHA2_384		5
#endif
#define   OAKLEY_ATTR_HASH_ALG_SHA2_512		6
					/*	65001 - 65535 Private Use */
#define OAKLEY_ATTR_AUTH_METHOD		3 /* B */
#define   OAKLEY_ATTR_AUTH_METHOD_PSKEY		1
#define   OAKLEY_ATTR_AUTH_METHOD_DSSSIG	2
#define   OAKLEY_ATTR_AUTH_METHOD_RSASIG	3
#define   OAKLEY_ATTR_AUTH_METHOD_RSAENC	4
#define   OAKLEY_ATTR_AUTH_METHOD_RSAREV	5
#define   OAKLEY_ATTR_AUTH_METHOD_EGENC		6
#define   OAKLEY_ATTR_AUTH_METHOD_EGREV		7

					/*	65500 -> still private
					 * to avoid clash with GSSAPI_KRB below 
					 */
#define FICTIVE_AUTH_METHOD_XAUTH_PSKEY_I	65500


	/*
	 * The following are valid when the Vendor ID is one of
	 * the following:
	 *
	 *	MD5("A GSS-API Authentication Method for IKE")
	 *	MD5("GSSAPI") (recognized by Windows 2000)
	 *	MD5("MS NT5 ISAKMPOAKLEY") (sent by Windows 2000)
	 */
#define   OAKLEY_ATTR_AUTH_METHOD_GSSAPI_KRB	65001
#define OAKLEY_ATTR_GRP_DESC		4 /* B */
#define   OAKLEY_ATTR_GRP_DESC_MODP768		1
#define   OAKLEY_ATTR_GRP_DESC_MODP1024		2
#define   OAKLEY_ATTR_GRP_DESC_EC2N155		3
#define   OAKLEY_ATTR_GRP_DESC_EC2N185		4
#define   OAKLEY_ATTR_GRP_DESC_MODP1536		5
#define   OAKLEY_ATTR_GRP_DESC_MODP2048		14
#define   OAKLEY_ATTR_GRP_DESC_MODP3072		15
#define   OAKLEY_ATTR_GRP_DESC_MODP4096		16
#define   OAKLEY_ATTR_GRP_DESC_MODP6144		17
#define   OAKLEY_ATTR_GRP_DESC_MODP8192		18
					/*	32768 - 65535 Private Use */
#define OAKLEY_ATTR_GRP_TYPE		5 /* B */
#define   OAKLEY_ATTR_GRP_TYPE_MODP		1
#define   OAKLEY_ATTR_GRP_TYPE_ECP		2
#define   OAKLEY_ATTR_GRP_TYPE_EC2N		3
					/*	65001 - 65535 Private Use */
#define OAKLEY_ATTR_GRP_PI		6 /* V */
#define OAKLEY_ATTR_GRP_GEN_ONE		7 /* V */
#define OAKLEY_ATTR_GRP_GEN_TWO		8 /* V */
#define OAKLEY_ATTR_GRP_CURVE_A		9 /* V */
#define OAKLEY_ATTR_GRP_CURVE_B		10 /* V */
#define OAKLEY_ATTR_SA_LD_TYPE		11 /* B */
#define   OAKLEY_ATTR_SA_LD_TYPE_DEFAULT	1
#define   OAKLEY_ATTR_SA_LD_TYPE_SEC		1
#define   OAKLEY_ATTR_SA_LD_TYPE_KB		2
#define   OAKLEY_ATTR_SA_LD_TYPE_MAX		3
					/*	65001 - 65535 Private Use */
#define OAKLEY_ATTR_SA_LD		12 /* V */
#define   OAKLEY_ATTR_SA_LD_SEC_DEFAULT		28800 /* 8 hours */
#define OAKLEY_ATTR_PRF			13 /* B */
#define OAKLEY_ATTR_KEY_LEN		14 /* B */
#define OAKLEY_ATTR_FIELD_SIZE		15 /* B */
#define OAKLEY_ATTR_GRP_ORDER		16 /* V */
#define OAKLEY_ATTR_BLOCK_SIZE		17 /* B */
				/*	16384 - 32767 Private Use */

#define MAXPADLWORD	20

typedef struct _oakley_group_t {
	int type;
	vchar_t *prime;
	int gen1;
	int gen2;
	vchar_t *curve_a;
	vchar_t *curve_b;
	vchar_t *order;
} oakley_group_t;

/* certificate holder */
typedef struct _oakley_cert_t {
	uint8_t type;		/* type of CERT, must be same to pl->v[0]*/
	vchar_t cert;		/* pointer to the CERT */
	vchar_t *pl;		/* CERT payload minus isakmp general header */
} oakley_cert_t;

extern oakley_group_t dh_modp768;
extern oakley_group_t dh_modp1024;
extern oakley_group_t dh_modp1536;
extern oakley_group_t dh_modp2048;
extern oakley_group_t dh_modp3072;
extern oakley_group_t dh_modp4096;
extern oakley_group_t dh_modp6144;
extern oakley_group_t dh_modp8192;

const char *oakley_groupdesc2name(uint8_t type);
uint8_t oakley_name2groupdesc(const char *str);

void oakley_group_free(oakley_group_t *dhgrp);
int oakley_default_lifetime(void);
int oakley_dh_compute(const oakley_group_t *dh,
		      vchar_t *pub, vchar_t *priv,
		      vchar_t *pub_p, vchar_t **gxy);
int oakley_dh_generate(const oakley_group_t *dh,
		       vchar_t **pub, vchar_t **priv);
int oakley_set_group(int group, oakley_group_t **dhgrp);

int __init oakley_init(void);

#endif /* __OAKLEY_H_INCLUDE__ */
