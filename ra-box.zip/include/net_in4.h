#ifndef __NET_IN4_H_INCLUDE__
#define __NET_IN4_H_INCLUDE__

#include <sysdep.h>
#include <net_if.h>
#include <net_nic.h>
#include <uiserv.h>
#include <atomic.h>
#include <list.h>

typedef struct _in4_ifaddr_t in4_ifaddr_t;
typedef struct _in4_method_t in4_method_t;

#define INET_SERVICE_NAME	"inet"

typedef struct _inet_config_t {
	int dummy;
} inet_config_t;

/* ifupdown like interface bring ups */
struct _in4_method_t {
	const char *name;
	const char *desc;

	int (*renew)(in4_ifaddr_t *ifa);
	int (*release)(in4_ifaddr_t *ifa);
	list_t link;
};

typedef struct _in4_ifconf_t {
	void (*set_addr)(in4_ifaddr_t *, uint32_t addr, uint32_t mask);
	void (*set_daddr)(in4_ifaddr_t *, uint32_t);
} in4_ifconf_t;

struct _in4_ifaddr_t {
	nic_t nic;
	char ifname[IFNAMSIZ];

	uint32_t local;
	uint32_t address;
	uint32_t mask;
	uint32_t broadcast;
	uint32_t anycast;
	unsigned char scope;
	unsigned char flags;
	unsigned char prefixlen;
	char label[IFNAMSIZ];

	uint32_t primary_dns;
	uint32_t secondary_dns;

	int up_timing;
	in4_method_t *method;
	void *method_data;

	/* UI object */
	ui_entry_t *cs;

	int ext_exist : 1;
	int renewing : 1;
	int releasing : 1;

	/* common object */
	atomic_t refcnt;	/* refcnt */
	list_t link;		/* link to management list */
	int closing : 1;	/* zombie flag */
};

static inline uint32_t inet_log2mask(int logmask)
{
	if (logmask)
		return htonl(~((1<<(32-logmask))-1));
	return 0;
}

void inet_ifaddr_close(in4_ifaddr_t *ifa);
in4_ifaddr_t *inet_ifaddr_open(const char *label, int type);
void inet_ifaddr_put(in4_ifaddr_t *ifa);
in4_ifaddr_t *inet_ifaddr_get(in4_ifaddr_t *ifa);
int inet_ifaddr_release(in4_ifaddr_t *ifa);
int inet_ifaddr_renew(in4_ifaddr_t *ifa);

void ui_parse_inet_method(const char *str, void *data);

in4_ifaddr_t *inet_ifaddr_open_link(net_device_t *dev,
				    const char *label);
void inet_ifaddr_close_link(in4_ifaddr_t *ifa);

struct sockaddr *inet_ifaddr2inaddr(in4_ifaddr_t *ifa);

int inet_ifaddr_match(uint32_t addr, in4_ifaddr_t *ifa);
int inet_addr_onlink(net_device_t *dev, uint32_t a, uint32_t b);

in4_ifaddr_t *inet_ifaddr_by_label(const char *label);
in4_ifaddr_t *inet_ifaddr_by_local(uint32_t addr);
in4_ifaddr_t *inet_ifaddr_by_address(uint32_t addr);
in4_ifaddr_t *inet_ifaddr_by_inaddr(struct sockaddr *addr);

uint32_t inet_natural_mask(uint32_t inaddr);
uint32_t inet_natural_bcast(uint32_t inaddr);

char *inet_addr_ntoa_r(char *buffer, uint32_t ipaddr);
const char *inet_addr_ntoa(uint32_t ipaddr);

int inet_set_dns(in4_ifaddr_t *ifa, uint32_t dns, int secondary);
int inet_unset_dns(in4_ifaddr_t *ifa, int secondary);

/* ============================================================ *
 * address methods
 * ============================================================ */
in4_method_t *inet_method_by_name(const char *name);
int inet_register_method(in4_method_t *conf);
void inet_unregister_method(in4_method_t *conf);
in4_method_t *inet_iterate_method(in4_method_t *m);

/* usage: method functions
 * 1. when up is called, inet_enable_method might be used by method
 *    handler to set method specific data
 * 2. when down method is called, inet_disable_method might be used
 *    by method handler to release the relationship between nic and
 *    it's method specific data
 * 3. nic_method_data can be used to return enabled method specific
 *    data
 */
void inet_enable_method(in4_ifaddr_t *ifa, void *data);
void inet_disable_method(in4_ifaddr_t *ifa);
void *inet_method_data(in4_ifaddr_t *ifa);

/* ============================================================ *
 * ioctl wrappers
 * ============================================================ */
int __inet_ifaddr_set_addr(int s, in4_ifaddr_t *ifa,
			   uint32_t addr, uint32_t mask);
int __inet_ifaddr_set_daddr(int s, in4_ifaddr_t *ifa,
			    uint32_t addr);

/* ============================================================ *
 * address operations
 * ============================================================ */
void inet_ifaddr_set_addr(in4_ifaddr_t *ifa,
			  uint32_t addr, uint32_t mask);
void inet_ifaddr_set_daddr(in4_ifaddr_t *ifa,
			   uint32_t addr);
void inet_ifaddr_update(in4_ifaddr_t *dev);

#endif /* __NET_IN4_H_INCLUDE__ */
