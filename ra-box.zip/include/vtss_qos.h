#ifndef __VTSS_QOS_H_INCLUDE__
#define __VTSS_QOS_H_INCLUDE__

/* ================================================================= *
 *  Quality of Service                                                   
 * ================================================================= */

/* Priority number: 1..VTSS_PRIOS */
typedef uint vtss_prio_t; /* VTSS_PRIO_START..(VTSS_PRIO_END-1) */

/* Ethernet Type */
typedef ushort vtss_etype_t; 

/* DSCP */
typedef uchar vtss_dscp_t;

/* UDP/TCP port number */
typedef ushort vtss_udp_tcp_t;

/* Queue number: 1..VTSS_QUEUES */
typedef uint vtss_queue_t; /* VTSS_QUEUE_START..(VTSS_QUEUE_END-1) */

#define VTSS_PRIO_START ((vtss_prio_t)1)             /* Lowest priority */
#define VTSS_PRIO_END   (VTSS_PRIO_START+VTSS_PRIOS) 
#define VTSS_PRIO_ARRAY_SIZE VTSS_PRIO_END

#define VTSS_QUEUE_START ((vtss_queue_t)1)
#define VTSS_QUEUE_END   (VTSS_QUEUE_START+VTSS_QUEUES)
#define VTSS_QUEUE_ARRAY_SIZE VTSS_QUEUE_END

/* Policer/Shaper bit rate. 
   Multiply vtss_bitrate_t value by 1000 to get the rate in BPS. */
typedef ulong vtss_bitrate_t; 

/* Special value that disables policer/shaper feature */
#define VTSS_BITRATE_FEATURE_DISABLED   ((ulong)-1)

/* Policer packet rate in PPS */
typedef ulong vtss_packet_rate_t;

/* Special value for disabling packet policer */
#define VTSS_PACKET_RATE_DISABLED ((ulong)-1)

/* Weight for port WFQ: 1, 2, 4 or 8 */
typedef enum {
	VTSS_WEIGHT_1,
	VTSS_WEIGHT_2,
	VTSS_WEIGHT_4,
	VTSS_WEIGHT_8
} vtss_weight_t;

/* - Per Chip ------------------------------------------------------ */

/******************************************************************************
 * Description: Set the number of active priority queues/traffic classes.
 *
 * \param prios (input): Number of priorities.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_qos_prios_set(const vtss_prio_t prios);

/* All parameters below are defined per chip */
typedef struct _vtss_qos_setup_t {
#ifdef VTSS_FEATURE_QOS_DSCP_REMARK
	BOOL           dscp_remark[64];   /* DSCP remarking */
#endif
#ifdef VTSS_FEATURE_QOS_POLICER_CPU_SWITCH
	vtss_packet_rate_t policer_mac;   /* MAC table CPU policer */
	vtss_packet_rate_t policer_cat;   /* BPDU, GARP, IGMP, IP MC Control and MLD CPU policer */
	vtss_packet_rate_t policer_learn; /* Learn frame policer */
#endif
#ifdef VTSS_FEATURE_QOS_POLICER_UC_SWITCH
	vtss_packet_rate_t policer_uc;    /* Unicast packet policer */
#endif
#ifdef VTSS_FEATURE_QOS_POLICER_MC_SWITCH
	vtss_packet_rate_t policer_mc;    /* Multicast packet policer */
#endif
#ifdef VTSS_FEATURE_QOS_POLICER_BC_SWITCH
	vtss_packet_rate_t policer_bc;    /* Broadcast packet policer */
#endif
	ulong       dummy;              /* Unused. Ensures that struct is not empty */
} vtss_qos_setup_t;


/******************************************************************************
 * Description: Get QoS setup for switch.
 *
 * \param qos (output): QoS setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_qos_setup_get(vtss_qos_setup_t * const qos);


/******************************************************************************
 * Description: Set QoS setup for switch.
 *
 * \param qos (input): QoS setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_qos_setup_set(const vtss_qos_setup_t * const qos);


/* - Per Port ------------------------------------------------------ */

#ifdef VTSS_FEATURE_QCL_PORT
/* QCL ID type */
typedef uint vtss_qcl_id_t; 
#define VTSS_QCL_ID_NONE  0 /* Means QCLs disabled for port */
#define VTSS_QCL_ID_START 1
#define VTSS_QCL_ID_END   (VTSS_QCL_ID_START+VTSS_QCL_IDS)
#define VTSS_QCL_ARRAY_SIZE VTSS_QCL_ID_END
#endif

#ifdef VTSS_FEATURE_QOS_DSCP_REMARK
/* DSCP mode for ingress port */
typedef enum {
	VTSS_DSCP_MODE_NONE, /* DSCP not remarked */
	VTSS_DSCP_MODE_ZERO, /* DSCP value zero remarked */
	VTSS_DSCP_MODE_SEL,  /* DSCP values selected above (dscp_remark) are remarked */
	VTSS_DSCP_MODE_ALL   /* DSCP remarked for all values */
} vtss_dscp_mode_t;
#endif

/* All parameters below are defined per port */
typedef struct _vtss_port_qos_setup_t {
	/* Basic classification mode */
#ifdef VTSS_FEATURE_QCL_PORT
	vtss_qcl_id_t  qcl_id;               /* QCL ID or VTSS_QCL_ID_NONE */
#endif
#if defined(VTSS_FEATURE_QOS_L4_PORT)
	BOOL           udp_tcp_enable;       /* Classification on UDP/TCP ports */
#endif
	BOOL           dscp_enable;          /* Classification on DSCP */
#ifdef VTSS_FEATURE_QOS_IP_TOS_PORT
	BOOL           tos_enable;           /* Classification on DSCP 3 MSBit - overrules dscp_enable */
#endif
	BOOL           tag_enable;           /* Classification on VLAN tag prio */
#ifdef VTSS_FEATURE_QOS_ETYPE_PORT
	BOOL           etype_enable;         /* Classification on Ethernet type */
#endif
#ifdef VTSS_FEATURE_QOS_L4_PORT
	vtss_udp_tcp_t udp_tcp_val[10];      /* UDP/TCP port numbers */
	vtss_prio_t    udp_tcp_prio[10];     /* Priority for UDP/TCP port numbers */
#endif
	vtss_prio_t    dscp_prio[64];        /* Map from DSCP to priority */
	vtss_prio_t    tag_prio[8];          /* Map from VLAN tag prio. to prio. */
#ifdef VTSS_FEATURE_QOS_ETYPE_PORT
	ushort         etype_val;            /* Ethernet type value */
	vtss_prio_t    etype_prio;           /* Priority for Ethernet type value */
#endif
	vtss_prio_t    default_prio;         /* Default port priority */
	vtss_tagprio_t usr_prio;             /* Default ingress VLAN tag priority */
#ifdef VTSS_FEATURE_QOS_DSCP_REMARK
	vtss_dscp_mode_t dscp_mode;          /* Ingress DSCP mode */
	BOOL             dscp_remark;        /* Egress DSCP mode */
	vtss_dscp_t      dscp_map[VTSS_PRIO_ARRAY_SIZE]; /* Egress mapping from priority to DSCP */
#endif
#ifdef VTSS_FEATURE_QOS_TAG_REMARK
	BOOL             tag_remark;         /* Egress tag priority mode */
	vtss_tagprio_t   tag_map[VTSS_PRIO_ARRAY_SIZE]; /* Egress mapping from priority to tag priority */
#endif
#ifdef VTSS_FEATURE_QOS_POLICER_PORT
	vtss_bitrate_t policer_port;          /* Ingress port policer, all frames */
#endif
#ifdef VTSS_FEATURE_QOS_POLICER_CIR_PIR_QUEUE
	vtss_bitrate_t policer_cir_queue[VTSS_QUEUE_ARRAY_SIZE];/* Ingress policer, CIR */
	vtss_bitrate_t policer_pir_queue[VTSS_QUEUE_ARRAY_SIZE];/* Ingress policer, PIR */
#endif
#ifdef VTSS_FEATURE_QOS_SHAPER_PORT
	vtss_bitrate_t shaper_port;           /* Egress shaping */
#endif
#ifdef VTSS_FEATURE_QOS_WFQ_PORT
	/* Weighted fairness queueing */
	BOOL           wfq_enable; 
	vtss_weight_t  weight[VTSS_QUEUE_ARRAY_SIZE];
#endif
} vtss_port_qos_setup_t;

#ifdef VTSS_FEATURE_QCL_PORT
#define VTSS_QCL_LIST_SIZE 24

/* QCE ID */
typedef ulong vtss_qce_id_t;
#define VTSS_QCE_ID_LAST 0 /* Special value used to add last in list */

/* QCE type */
typedef enum _vtss_qce_type_t {
	VTSS_QCE_TYPE_ETYPE,   /* Ethernet Type */
	VTSS_QCE_TYPE_VLAN,    /* VLAN ID */
	VTSS_QCE_TYPE_UDP_TCP, /* UDP/TCP port */
	VTSS_QCE_TYPE_DSCP,    /* IP DSCP */
	VTSS_QCE_TYPE_TOS,     /* IP ToS */
	VTSS_QCE_TYPE_TAG      /* VLAN Tag */
} vtss_qce_type_t;

/* QoS Control Entry */
typedef struct _vtss_qce_t {
	vtss_qce_id_t   id;
	vtss_qce_type_t type;
	
	union {
		/* Type VTSS_QCE_TYPE_ETYPE */
		struct {
			vtss_etype_t val;  /* Ethernet Type */ 
			vtss_prio_t  prio; /* Priority mapping */
		} etype;
		
		/* Type VTSS_QCE_TYPE_VLAN_ID */
		struct {
			vtss_vid_t  vid;  /* VLAN ID value */
			vtss_prio_t prio; /* Priority mapping */
		} vlan;
		
		/* Type VTSS_QCE_TYPE_UDP_TCP */
		struct {
			vtss_udp_tcp_t low;  /* UDP/TCP port range low value */
			vtss_udp_tcp_t high; /* UDP/TCP port range high value */
			vtss_prio_t prio;    /* Priority mapping */
		} udp_tcp;
		
		/* Type VTSS_QCE_TYPE_DSCP */
		struct {
			vtss_dscp_t dscp_val; /* DSCP value */
			vtss_prio_t prio; /* Priority mapping */
		} dscp;
		
		/* Type VTSS_QCE_TYPE_TOS */
		vtss_prio_t tos_prio[8]; /* ToS priority mapping */
		
		/* Type VTSS_QCE_TYPE_TAG */
		vtss_prio_t tag_prio[8]; /* Tag priority mapping */
	} frame;
} vtss_qce_t;

typedef struct vtss_qcl_entry_t {
    struct vtss_qcl_entry_t *next;  /* Next in list */
    vtss_qce_t               qce;   /* This entry */
} vtss_qcl_entry_t;

typedef struct {
    vtss_qcl_entry_t         *qcl_list_used;               /* Free entries for QCL usage */
    vtss_qcl_entry_t         *qcl_list_free;               /* Entries in QCL List */
    vtss_qcl_entry_t         qcl_list[VTSS_QCL_LIST_SIZE]; /* Actual storage for list members */
} vtss_qcl_t;
#endif

typedef struct {
	vtss_prio_t              prios;                            /* Number of priorities used */
	vtss_port_qos_setup_t    qos[VTSS_PORT_EXT_ARRAY_SIZE];
	vtss_qos_setup_t         qos_setup;
#ifdef VTSS_FEATURE_QOS_WFQ_PORT
	BOOL                     wfq;
#endif
#ifdef VTSS_FEATURE_QCL_PORT
	vtss_qcl_t               qcl[VTSS_QCL_ARRAY_SIZE];     /* QCL setup */
#endif
} vtss_qos_state_t;

/******************************************************************************
 * Description: Get QoS setup for port.
 *
 * \param port_no (input): Port number.
 * \param qos (output)   : QoS setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_port_qos_get(const vtss_port_no_t port_no,
                          vtss_port_qos_setup_t * const qos);


/******************************************************************************
 * Description: Set QoS setup for port.
 *
 * \param port_no (input): Port number.
 * \param qos (input)    : QoS setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_port_qos_set(const vtss_port_no_t port_no,
                          const vtss_port_qos_setup_t * const qos);

/* - QoS Control Lists --------------------------------------------- */

#ifdef VTSS_FEATURE_QCL_PORT

/******************************************************************************
 * Description: Add QCE to QCL.
 *
 * \param qcl_id (input): QCL ID. 
 * \param qce_id (input): QCE ID. The QCE will be added before the entry with 
 *                        this ID. VTSS_QCE_ID_LAST is reserved for inserting
 *                        last.
 * \param qce (input)   : QCE setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_qce_add(const vtss_qcl_id_t qcl_id,
                     const vtss_qce_id_t qce_id,
                     const vtss_qce_t * const qce);

/******************************************************************************
 * Description: Delete QCE from QCL.
 *
 * \param qcl_id (input): QCL ID.
 * \param qce_id (input): QCE ID.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_qce_del(const vtss_qcl_id_t qcl_id,
                     const vtss_qce_id_t qce_id);

#endif /* VTSS_FEATURE_QCL_PORT */

/* Set port QoS setup */
int vtss_ll_port_qos_setup_set(vtss_port_no_t port_no, const vtss_port_qos_setup_t *qos);

/* Set switch QoS setup */
int vtss_ll_qos_setup_set(const vtss_qos_setup_t *qos);

#ifdef VTSS_FEATURE_QCL_PORT
/* Add QCE */
int vtss_ll_qce_add(vtss_qcl_id_t    qcl_id,
                        vtss_qce_id_t    qce_id,
                        const vtss_qce_t *qce);

/* Delete QCE */
int vtss_ll_qce_del(vtss_qcl_id_t  qcl_id,
                        vtss_qce_id_t  qce_id);
#endif

#ifdef CONFIG_VTSS_QOS
BOOL vtss_qos_get_wfq(void);
vtss_bitrate_t vtss_qos_policer_port(vtss_port_no_t port_no);
int vtss_qos_start(void);
int vtss_qos_reset(void);
#else
static inline BOOL vtss_qos_get_wfq(void) { return 0; }
static inline vtss_bitrate_t vtss_qos_policer_port(vtss_port_no_t port_no)
{
	return VTSS_BITRATE_FEATURE_DISABLED;
}
static inline int vtss_qos_start(void) { return 0; }
static inline int vtss_qos_reset(void) { return 0; }
#endif

#endif
