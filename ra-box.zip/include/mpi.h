/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2003
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@hzcnc.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)mpi.h: multi-precision integer interfaces
 * $Id: mpi.h,v 1.9 2008-05-16 07:07:04 zhenglv Exp $
 */

#ifndef __MPI_H_INCLUDE__
#define __MPI_H_INCLUDE__

#ifdef __cplusplus
extern "C" {
#endif  /* __cpluscplus */

#include <sysdep.h>

typedef unsigned long mpi_t;
typedef unsigned short hmpi_t;    /* half digit */

/* RSA key lengths. */
#define MIN_MODULUS_BITS    512
#define MAX_MODULUS_BITS    1024
#define MAX_MODULUS_BYTES   ((MAX_MODULUS_BITS + 7) / 8)
#define MAX_PRIME_BITS      ((MAX_MODULUS_BITS + 1) / 2)
#define MAX_PRIME_LEN       ((MAX_PRIME_BITS + 7) / 8)

/*
 * Constants.
 *
 * Note: MAX_MPI_DIGITS is long enough to hold any RSA modulus, plus
 * one more digit as required by R_GeneratePEMKeys (for n and phiN,
 * whose lengths must be even). All natural numbers have at most
 * MAX_MPI_DIGITS digits, except for double-length intermediate values
 * in mpi_mult(t), mpi_mod_mult(t), mpi_mod_inv(w), and mpi_div(c).
 */
/* Length of digit in bits */
#define MPI_DIGIT_BITS 32
#define MPI_HALF_DIGIT_BITS 16
/* Length of digit in bytes */
#define MPI_DIGIT_BYTES (MPI_DIGIT_BITS / 8)
/* Maximum length in digits */
#define MAX_MPI_DIGITS \
  ((MAX_MODULUS_BYTES + MPI_DIGIT_BYTES - 1) / MPI_DIGIT_BYTES + 1)
/* Maximum digits */
#define MAX_MPI_DIGIT 0xffffffff
#define MAX_MPI_HALF_DIGIT 0xffff

/* Macros */
#define LOW_HALF(x) ((x) & MAX_MPI_HALF_DIGIT)
#define HIGH_HALF(x) (((x) >> MPI_HALF_DIGIT_BITS) & MAX_MPI_HALF_DIGIT)
#define TO_HIGH_HALF(x) (((mpi_t)(x)) << MPI_HALF_DIGIT_BITS)
#define DIGIT_MSB(x) (unsigned int)(((x) >> (MPI_DIGIT_BITS - 1)) & 1)
#define DIGIT_2MSB(x) (unsigned int)(((x) >> (MPI_DIGIT_BITS - 2)) & 3)

/*
 * Conversions
 * mpi_decode(a, digits, b, len)                Decodes character string b into a.
 * mpi_encode(a, len, b, digits)                Encodes a into character string b.
 *
 * Assignments
 * mpi_assign(a, b, digits)                     Assigns a = b.
 * mpi_assign_digit(a, b, digits)               Assigns a = b, where b is a digit.
 * mpi_assign_zero(a, b, digits)                Assigns a = 0.
 * mpi_assign_2exp(a, b, digits)                Assigns a = 2^b.
 *   
 * Arithmetic operations
 * mpi_add(a, b, c, digits)                     Computes a = b + c.
 * mpi_sub(a, b, c, digits)                     Computes a = b - c.
 * mpi_mult(a, b, c, digits)                    Computes a = b * c.
 * mpi_left_shift(a, b, c, digits)              Computes a = b * 2^c.
 * mpi_right_shift(a, b, c, digits)             Computes a = b / 2^c.
 * mpi_div(a, b, c, cDigits, d, dDigits)        Computes a = c div d and b = c mod d.
 *
 * Number theory
 * mpi_mod(a, b, bDigits, c, cDigits)           Computes a = b mod c.
 * mpi_mod_mult(a, b, c, d, digits)             Computes a = b * c mod d.
 * mpi_mod_exp(a, b, c, cDigits, d, dDigits)    Computes a = b^c mod d.
 * mpi_mod_inv(a, b, c, digits)                 Computes a = 1/b mod c.
 * mpi_gcd(a, b, c, digits)                     Computes a = gcd(b, c).
 *
 * Other operations
 * mpi_even(a, digits)                          Returns 1 iff a is even.
 * mpi_cmp(a, b, digits)                        Returns sign of a - b.
 * mpi_equal(a, digits)                         Returns 1 iff a = b.
 * mpi_zero(a, digits)                          Returns 1 iff a = 0.
 * mpi_digits(a, digits)                        Returns significant length of a in digits.
 * mpi_bits(a, digits)                          Returns significant length of a in bits.
 */
void mpi_decode(mpi_t *, unsigned int, uint8_t *, size_t);
void mpi_encode(uint8_t *, size_t, mpi_t *, unsigned int);

void mpi_assign(mpi_t *, mpi_t *, unsigned int);
void mpi_assign_zero(mpi_t *, unsigned int);
void mpi_assign_2exp(mpi_t *, unsigned int, unsigned int);

mpi_t mpi_add(mpi_t *, mpi_t *, mpi_t *, unsigned int);
mpi_t mpi_sub(mpi_t *, mpi_t *, mpi_t *, unsigned int);
void mpi_mult(mpi_t *, mpi_t *, mpi_t *, unsigned int);
void mpi_div(mpi_t *, mpi_t *, mpi_t *, unsigned int, mpi_t *, unsigned int);
mpi_t mpi_left_shift(mpi_t *, mpi_t *, unsigned int, unsigned int);
mpi_t mpi_right_shift(mpi_t *, mpi_t *, unsigned int, unsigned int);

void mpi_mod(mpi_t *, mpi_t *, unsigned int, mpi_t *, unsigned int);
void mpi_mod_mult(mpi_t *, mpi_t *, mpi_t *, mpi_t *, unsigned int);
void mpi_mod_exp(mpi_t *, mpi_t *, mpi_t *, unsigned int, mpi_t *, unsigned int);
void mpi_mod_inv(mpi_t *, mpi_t *, mpi_t *, unsigned int);
void mpi_gcd(mpi_t *, mpi_t *, mpi_t *, unsigned int);

int mpi_cmp(mpi_t *, mpi_t *, unsigned int);
int mpi_zero(mpi_t *, unsigned int);
unsigned int mpi_bits(mpi_t *, unsigned int);
unsigned int mpi_digits(mpi_t *, unsigned int);

#define mpi_assign_digit(a, b, digits) {mpi_assign_zero(a, digits); a[0] = b;}
#define mpi_equal(a, b, digits) (!mpi_cmp(a, b, digits))
#define mpi_even(a, digits) (((digits) == 0) || !(a[0] & 1))

// digit operations
void mpi_digit_mult(mpi_t[2], mpi_t, mpi_t);
void mpi_digit_div(mpi_t *, mpi_t[2], mpi_t);

#ifdef __cplusplus
}
#endif  /* __cpluscplus */

#endif
