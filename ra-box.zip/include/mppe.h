#ifndef __MPPE_H_INCLUDE__
#define __MPPE_H_INCLUDE__

#include <sysdep.h>

#define MPPE_KEY_BIT_40		1
#define MPPE_KEY_BIT_56		2
#define MPPE_KEY_BIT_128	3

/* MPPE_MAX_KEY_LEN in ppp-comp.h */
#define MPPE_MAX_KEY_LEN	16

/* These values are the RADIUS attribute values--see RFC 2548. */
#define MPPE_ENC_POL_ENC_ALLOWED	1
#define MPPE_ENC_POL_ENC_REQUIRED	2
#define MPPE_ENC_TYPES_RC4_40		2
#define MPPE_ENC_TYPES_RC4_128		4

void GetKey(IN uint8_t *InitialSessionKey,
	    IN OUT uint8_t *CurrentSessionKey,
	    IN int LengthOfDesiredKey);
void GetStartKey(IN const uint8_t *Challenge,
		 IN const uint8_t *NtPasswordHashHash,
		 OUT uint8_t InitialSessionKey[16]);
void GetNewKeyFromSHA(IN uint8_t *StartKey,
		      IN uint8_t *SessionKey,
		      IN size_t SessionKeyLength,
		      OUT uint8_t *InterimKey);
void GetAsymmetricStartKey(IN uint8_t MasterKey[16],
			   OUT uint8_t *SessionKey,
			   IN size_t SessionKeyLength,
			   IN bool IsSend, IN bool IsServer);
void GetMasterKey(IN const uint8_t PasswordHashHash[16],
		  IN const uint8_t NTResponse[24],
		  OUT uint8_t MasterKey[16]);

void mppe_mschap_init_key(int bits, const uint8_t challenge[8],
			  const char *password, uint8_t *key);
void mppe_mschap_curr_key(int bits, uint8_t *init_key, uint8_t *curr_key);

#endif
