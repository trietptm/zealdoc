#ifndef __CCID_H__
#define __CCID_H__

typedef struct ccid_transfer ccid_transfer_t;
typedef struct ccid_descriptor ccid_desc_t;

struct ccid_descriptor {
	uint8_t bLength;
	uint8_t bDescriptorType;
	uint16_t bcdCCID;
	uint8_t bMaxSlotIndex;
	uint8_t bVoltageSupport;
	uint32_t dwProtocols;	/*cardprotocol: t0: 0000 0001 ,t1: 0000 0002*/
	uint32_t dwDefaultClock;
	uint32_t dwMaximumClock;
	uint8_t bNumClockSupported;
	uint32_t dwDataRate;
	uint32_t dwMaxDataRate;
	uint8_t bNumDataRatesSupported;
	uint32_t dwMaxIFSD;
	uint32_t dwSynchProtocols;
	uint32_t dwMechanical;
	uint32_t dwFeatures;
	uint32_t dwMaxCCIDMessageLength;
	uint8_t bClassGetResponse;
	uint8_t bClassEnvelope;
	uint16_t wLcdLayout;
	uint8_t bPINSupport;
	uint8_t bMaxCCIDBusySlots;
};

typedef struct _ccid_reader_t {
	char *name;
	int dev_type;	/* support CCID_DEVICE_TYPE_USB now */
	void *handle;	/* interface data, may usb_intfc_t */

	ccid_desc_t ccid_desc;
	/* BUG, assume rdr only has one slot here */
	uint8_t bseq;
	uint8_t bslot;
	uint8_t intfc_proto;
	uint8_t card_status;
	
	atomic_t refcnt;

	list_t link;
} ccid_reader_t;

#define CCID_NAME(rdr)	(((ccid_reader_t *)rdr)->name)
#define CCID_TYPE(rdr)  (((ccid_reader_t *)rdr)->dev_type)

#define CCID_MAX_READERS	16
#define dw2i(a, x) ((((((a[x+3] << 8) + a[x+2]) << 8) + a[x+1]) << 8) + a[x])
/* Communication buffer size (max = apdu + Lc + Data + Le*/
#define CMD_BUF_SIZE	(4 + 1 + 256 + 1)
/* Larger communication buffer size (max = reader status + data + SW1SW2*/
#define RESP_BUF_SIZE	(1 + 256 + 2)

enum ccid_voltage {
	CCID_VOLTAGE_AUTO	= 0x00,
	CCID_VOLTAGE_5V		= 0x01,
	CCID_VOLTAGE_3V		= 0x02,
	CCID_VOLTAGE_1_8V	= 0x04,
};

enum card_protocol {
	CCID_PROTOCOL_T0	= 0x0001,
	CCID_PROTOCOL_T1	= 0x0002,
	CCID_PROTOCOL_BOTH	= 0x0003,
};

enum ccid_feature {
	CCID_CLASS_AUTO_CONF_ATR	= 0x00000002,
	CCID_CLASS_AUTO_VOLTAGE		= 0x00000008,
	CCID_CLASS_AUTO_BAUD		= 0x00000020,
	CCID_CLASS_AUTO_PPS_PROP	= 0x00000040,
	CCID_CLASS_AUTO_PPS_CUR		= 0x00000080,
	CCID_CLASS_AUTO_IFSD		= 0x00000400,

	CCID_CLASS_CHARACTER		= 0x00000000,
	CCID_CLASS_TPDU			= 0x00010000,
	CCID_CLASS_SHORT_APDU		= 0x00020000,
	CCID_CLASS_EXTENDED_APDU	= 0x00040000,
	CCID_CLASS_EXCHANGE_MASK	= 0x00070000,
};

enum ccid_pin_support {
	CCID_CLASS_PIN_VERIFY		= 0x01,
	CCID_CLASS_PIN_MODIFY		= 0x02,
};

#define USB_CCID_DESCRIPTOR_LENGTH 54

/*
struct ccid_protocol_ops {
	int (*init)(ccid_protocol_t *proto);
	void (*release)(ccid_protocol_t *proto);
	int (*prepare_pc_to_rdr_xfrblock)(struct ccid_transfer *ccid_trans,
					struct usb_transfer **usb_trans);
	int (*prepare_rdr_to_pc_datablock)(struct ccid_transfer *ccid_trans,
					struct usb_transfer **usb_trans);
	
};

struct ccid_protocol {
	uint32_t protocol;
	struct ccid_protocol_ops *ops;
};
*/
enum ccid_intfc_protocol {
	CCID_INTFC_PROTO_BULK	= 0x00,
	CCID_INTFC_PROTO_CTRL_A	= 0x01,
	CCID_INTFC_PROTO_CTRL_B	= 0x02,
};

enum ccid_card_status {
	CCID_CARD_PRESENT_ACTIVE	= 0x01,
	CCID_CARD_PRESENT_DEACTIVE	= 0x02,
	CCID_CARD_ABSENT		= 0x03,
};

struct ccid_handle {
	struct ccid_descriptor ccid_desc;
	uint8_t bslot;
	uint8_t bseq;
	uint8_t intfc_proto;
	uint8_t card_status;
	
	atomic_t refcnt;

	int dev_type;
	union {
		struct usb_interface *usb_handle;
	} handle;
};

enum ccid_device_type {
	CCID_DEVICE_TYPE_USB	= 1,
};

enum ccid_error {
	CCID_SUCCESS			= 0,
	CCID_TIME_EXTENSION		= 1,
	CCID_ERROR_NO_MEM		= -1,
	CCID_ERROR_INSUFFICIENT_BUFFER	= -2,
	CCID_ERROR_CANCELLED		= -4,
	CCID_ERROR_STALL		= -5,
	CCID_ERROR_NO_DEVICE		= -6,
	CCID_ERROR_OVERFLOW		= -7,
	CCID_ERROR_COMMUNICATION	= -8,
	CCID_ERROR_BUSY			= -9,
	
	CCID_ERROR_NO_CARD		= -10,
	CCID_ERROR_COMM_ERR		= -11,
	CCID_ERROR_NO_ATR		= -12,
	CCID_ERROR_INCOMPATIBLE_DEV	= -13,
	CCID_ERROR_INVALID_ARG		= -14,
	CCID_ERROR_TIMEOUT		= -15,
	CCID_ERROR_USER_TIMEOUT		= -16,
	CCID_ERROR_USER_ABORT		= -17,
	CCID_ERROR_NOT_SUPPORTED	= -18,
	CCID_ERROR_INVALID_SLOT		= -19,
	
	CCID_ERROR_GENERIC		= -99,
};

typedef void (*ccid_transfer_cb)(void *user_data, int ret);

/* CCID ops */
#if 0
int ccid_open(int dev_type, const char *file_name, int *reader_idx);
void ccid_close(int reader_idx);
#endif
int ccid_get_slot_status(ccid_reader_t *, uint8_t *card_status, ccid_transfer_cb cb, void *user_data);
int ccid_power_on(ccid_reader_t *handle, uint8_t *atr_ret, size_t atr_len, 
		  ccid_transfer_cb callback, void *user_data);
int ccid_power_off(ccid_reader_t *handle, uint8_t *card_status,  
		   ccid_transfer_cb callback, void *user_data);
int ccid_xfrblock(ccid_reader_t *handle, int32_t protocol,
		  const uint8_t *sbuf, size_t sbuf_len, 
		  uint8_t *rbuf, size_t rbuf_len, 
		  ccid_transfer_cb callback, void *user_data);
/* control transfer */
int ccid_control(ccid_reader_t *, uint8_t request_class, uint8_t request, 
		 uint8_t *data, size_t data_len,
		 ccid_transfer_cb callback, void *user_data);

int ccid_cancel(ccid_reader_t *hanle);

/* Pin pad support */
#define CLASS2_IOCTL_MAGIC 0x330000

#define IOCTL_FEATURE_VERIFY_PIN_DIRECT \
		SCARD_CTL_CODE(FEATURE_VERIFY_PIN_DIRECT + CLASS2_IOCTL_MAGIC)
#define IOCTL_FEATURE_MODIFY_PIN_DIRECT \
		SCARD_CTL_CODE(FEATURE_MODIFY_PIN_DIRECT + CLASS2_IOCTL_MAGIC)

enum ccid_pin_operation {
	CCID_PIN_VERIFY		= 0x00,
	CCID_PIN_MODIFY		= 0x01,
	CCID_PIN_TRANS		= 0x02,
	CCID_PIN_WAIT		= 0x03,
	CCID_PIN_CANCEL		= 0x04,
	CCID_PIN_T1_RESENT	= 0x05,
	CCID_PIN_T1_SENT_NEX	= 0x06,
};

struct ccid_pin_verify {
	uint8_t bTimeOut;
	uint8_t bmFormatString;
	uint8_t bmPinBlockString;
	uint8_t bmPinLengthFormat;
	uint16_t wPinMaxExtraDigit;
	uint8_t bEntryValidationCondition;
	uint8_t bNumberMessage;
	uint16_t wLangId;
	uint8_t bMsgIndex;
	uint8_t bTeoPrologue[3];
	uint8_t abPinAPDU[0];
};

struct ccid_pin_modify {
	uint8_t bTimeOut;
	uint8_t bmFormatString;
	uint8_t bmPinBlockString;
	uint8_t bmPinLengthFormat;
	uint8_t bInsertionOffsetOld;
	uint8_t bInsertionOffsetNew;
	uint16_t wPinMaxExtraDigit;
	uint8_t bConfirmPin;
	uint8_t bEntryValidationCondition;
	uint8_t bNumberMessage;
	uint16_t wLangId;
	uint8_t bMsgIndex1;
	uint8_t bMsgIndex2;
	uint8_t bMsgIndex3;
	uint8_t bTeoPrologue[3];
	uint8_t abPinApdu[0];
};

int ccid_ifd_control(ccid_reader_t *, uint32_t ioctl, 
		     uint8_t *sbuf, size_t sbuf_len,
		     uint8_t *rbuf, size_t rbuf_len,
		     ccid_transfer_cb callback, void *user_data);

/* ccid notify */
#define CCID_RDR_REGISTER	0x01
#define CCID_RDR_UNREGISTER	0x02
#define CCID_RDR_INSERT		0x03
#define CCID_RDR_REMOVE		0x04
#define CCID_SLOT_INSERT	0x05
#define CCID_SLOT_REMOVE	0x06

int ccid_register_notify(notify_t *nb);
void ccid_unregister_notify(notify_t *nb);

uint16_t ccid_dev_idVendor(void *data, int dev_type);
uint16_t ccid_dev_idProduct(void *rdr, int dev_type);

#endif /*__CCID_H__*/
