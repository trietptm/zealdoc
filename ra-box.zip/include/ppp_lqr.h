#ifndef __PPP_LQR_H_INCLUDE__
#define __PPP_LQR_H_INCLUDE__

#include <ppp.h>

#define LCP_CI_LQR			4	/* Link-Quality-Monitoring */

#endif /* __PPP_LQR_H_INCLUDE__ */
