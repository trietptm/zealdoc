#ifndef __PCSC_H__
#define __PCSC_H__
#include <sysdep.h>
#include <pcsc_pinpad.h>

#include <pcsc_defs.h>

typedef struct _pcsc_ifd_t	pcsc_ifd_t;	/* reader */
typedef struct _pcsc_ifd_hd_t   pcsc_ifd_hd_t;	/* reader handle */
typedef struct _pcsc_icc_t	pcsc_icc_t;	/* card */
typedef struct pcsc_transmit_param pcsc_trans_param_t;

typedef void (*pcsc_ifd_hd_cb)(pcsc_ifd_hd_t *hd);
typedef void (*pcsc_trans_comp)(pcsc_trans_param_t *pcsc_param);

typedef struct __ifd_driver_ops {
	int (*get_feature)(pcsc_ifd_hd_t *);
	int (*cancel)(pcsc_ifd_hd_t *);
	int (*icc_status)(pcsc_ifd_hd_t *);
	int (*power_on)(pcsc_ifd_hd_t *);
	int (*power_off)(pcsc_ifd_hd_t *);
	int (*xfr_block)(pcsc_ifd_hd_t *,
			 pcsc_trans_param_t *pcsc_param);
	int (*ifd_ctl)(pcsc_ifd_hd_t *, pcsc_trans_param_t *pcsc_param);
} pcsc_ifd_hd_ops;

/* card */
struct _pcsc_icc_t {
	uint8_t atr[PCSC_MAX_ATR];
	size_t atr_len;
	int proto;
	int proto_supported;
	/* insert times */
	uint32_t icc_seq;
	uint32_t card_status;
};
/* reader */
struct _pcsc_ifd_t {
	char *name;
	int type;	/* device type */
	uint32_t reader_status;

	/* below is feature of this reader */
	/* When you open the reader, you should determine(FIXME: How to ?) 
	 * wheter the reader support keypad/display. */
	int nslots;
	int keypad;
	int display;
	int row_num;
	int col_num;
	/* there may have several slots,
	 * one slot can correspond with one card(icc). */
	pcsc_icc_t *slots;
	/* FIXME: whats this? */
	struct pcsc_path10_data path10;

	atomic_t refcnt;

	list_t link;
};

/* reader handle */
struct _pcsc_ifd_hd_t {
	pcsc_ifd_t *reader;
	
	/* one slot on the reader */
	pcsc_icc_t *slot;
	int slot_idx;	/* from 0 ~ */
	int icc_present;

	pcsc_ifd_hd_cb cb;
	int ret;

	pcsc_ifd_hd_ops *ops;	/* driver ops */
	void *lower;		/* ccid_reader_t */

	stm_instance_t *fsmi;

	list_t link;
	atomic_t refcnt;
};

struct pcsc_transmit_param {
	pcsc_ifd_hd_t *handle;

	uint32_t ioctl;

	int ret;
	uint8_t *sbuf;
	size_t sbuf_len;
	uint8_t *rbuf;
	size_t rbuf_len;
	size_t rbuf_actual;
	uint32_t card_status;

	pcsc_trans_comp callback;
	void *user_data;
};

pcsc_ifd_hd_t *pcsc_connect(int reader_idx, int slot_idx);
int pcsc_disconnect(pcsc_ifd_hd_t *handle);
int pcsc_check_handle_valid(pcsc_ifd_hd_t *handle);

int pcsc_card_status(int reader_idx, int slot_idx, 
		     uint32_t *icc_status);
int pcsc_transmit(pcsc_trans_param_t *param);

int pcsc_ifd_control(pcsc_trans_param_t *param);

/* ============================================================ *
 * API for lower
 * ============================================================ */
int pcsc_ifd_handle_up(const char *name, int type, void *lower, pcsc_ifd_hd_ops *ops);
int pcsc_ifd_handle_down(const char *name, int type, void *lower);

#endif /*__PCSC_H__*/
