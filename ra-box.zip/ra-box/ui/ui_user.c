#include "ui_priv.h"

/* apply to all nodes */
DECLARE_LIST(ui_commands);

static int ui_order_name2int(const char *str);

static ui_command_t *__ui_command_by_name(const char *oid, const char *name)
{
	ui_command_t *pos;

	list_for_each_entry(ui_command_t, pos, &ui_commands, link) {
		if (strcmp(name, pos->name)) continue;
		if (pos->oid && oid && !strcmp(oid, pos->oid))
			return pos;
	}
	if (!oid || !oid[0]) {
		list_for_each_entry(ui_command_t, pos, &ui_commands, link) {
			if (strcmp(name, pos->name)) continue;
			if (!pos->oid)
				return pos;
		}
	}
	return NULL;
}

ui_command_t *ui_command_by_name(const char *oid, const char *name)
{
	ui_command_t *pos;

	list_for_each_entry(ui_command_t, pos, &ui_commands, link) {
		if (strcmp(name, pos->name)) continue;
		if (pos->oid && oid && !strcmp(oid, pos->oid))
			return pos;
	}
	list_for_each_entry(ui_command_t, pos, &ui_commands, link) {
		if (strcmp(name, pos->name)) continue;
		if (!pos->oid)
			return pos;
	}
	return NULL;
}

ui_command_t *ui_command_by_flag(const char *oid, const char *name, int type)
{
	ui_command_t *pos = ui_command_by_name(oid, name);
	if (pos && (pos->type & type))
		return pos;
	return NULL;
}

int ui_register_command(ui_command_t *command)
{
	if (__ui_command_by_name(command->oid, command->name)) {
		log_kern(LOG_ERR, "UI: duplicated command, oid=%s, cmd=%s",
			 command->oid ? command->oid : "global", command->name);
		return -1;
	}
	list_init(&command->link);
	list_insert_before(&command->link, &ui_commands);
	return 0;
}

void ui_unregister_command(ui_command_t *command)
{
	if (command)
		list_delete_init(&command->link);
}

ui_command_t *ui_command_iterate_object(ui_node_t *node,
					ui_command_t *iter)
{
	list_t *t, *pos;
	ui_command_t *c;
	int type = 0;

	if (!iter) t = &ui_commands;
	else t = &iter->link;

	if (node->schema->type == UI_TYPE_CLASS) {
		if (!ui_is_multiple_node(node))
			type = UI_CMD_SINGLE_INST;
		else
			type = UI_CMD_MULTI_INST;
	} else {
		if (!ui_is_multiple_node(node))
			type = UI_CMD_SINGLE_VALUE;
		else
			type = UI_CMD_MULTI_VALUE;
	}
	pos = t->next;
	while (pos != &ui_commands) {
		c = list_entry(pos, ui_command_t, link);
		if (c->type & type &&
		    ((c->oid && !strcmp(node->oid, c->oid)) ||
		     (!c->oid && !(node->schema->flags & UI_FLAG_EXTERNAL))))
			return c;
		pos = pos->next;
	}
	return NULL;
}

ui_command_t *ui_command_iterate_schema(ui_node_t *node,
					ui_command_t *iter)
{
	list_t *t, *pos;
	ui_command_t *c;
	int type = 0;

	if (!iter) t = &ui_commands;
	else t = &iter->link;

	if (node->schema->type == UI_TYPE_CLASS) {
		if (!ui_is_multiple_node(node))
			type = UI_CMD_SINGLE_CLASS;
		else
			type = UI_CMD_MULTI_CLASS;
	} else {
		if (!ui_is_multiple_node(node))
			type = UI_CMD_SINGLE_ATTR;
		else
			type = UI_CMD_MULTI_ATTR;
	}
	pos = t->next;
	while (pos != &ui_commands) {
		c = list_entry(pos, ui_command_t, link);
		if (c->type & type &&
		    ((c->oid && !strcmp(node->oid, c->oid)) ||
		     (!c->oid && !(node->schema->flags & UI_FLAG_EXTERNAL))))
			return c;
		pos = pos->next;
	}
	return NULL;
}

static int ui_cmd_set_value(ui_session_t *sess, ui_entry_t *inst,
			    void *ctx, int argc, char **argv)
{
	ui_node_t *node = (ui_node_t *)ctx;
	ui_entry_t *val = NULL;

	val = ui_value_by_user(inst, node->schema->name, NULL);
	if (val == NULL) {
		val = ui_value_create_user(inst, node->schema->name, argv[0]);
		return val ? 0 : -1;
	}
	if (atomic_read(&val->refcnt) == 0) {
		if (val->conf_value) {
			free(val->conf_value);
			val->conf_value = strdup(argv[0]);
		}
		ui_set_user_value(val, argv[0]);
	} else {
		UI_ENTRY_UNSET_VALID(val, UI_VALID_ALL);
		/* TODO: put val to gc list */
		val = ui_value_create_user(inst, node->schema->name, argv[0]);
		return val ? 0 : -1;
	}
	return 0;
}

static int ui_cmd_add_value(ui_session_t *sess, ui_entry_t *inst,
			    void *ctx, int argc, char **argv)
{
	ui_node_t *node = (ui_node_t *)ctx;
	ui_entry_t *val;
	val = ui_value_create_user(inst, node->schema->name, argv[0]);
	return val ? 0 : -1;
}

static int ui_cmd_unset_value(ui_session_t *sess, ui_entry_t *inst,
			      void *ctx, int argc, char **argv)
{
	ui_entry_t *val = (ui_entry_t *)ctx;
	ui_value_delete_user(val);
	return 0;
}

static int ui_cmd_order_value(ui_session_t *sess, ui_entry_t *inst,
			      void *ctx, int argc, char **argv)
{
	ui_entry_t *val = (ui_entry_t *)ctx;
	int ret = -1;

	switch (ui_order_name2int(argv[0])) {
	case UI_ORDER_HIGHEST:
		ret = ui_set_entry_highest(val);
		break;
	case UI_ORDER_HIGHER:
		ret = ui_set_entry_higher(val);
		break;
	case UI_ORDER_LOWER:
		ret = ui_set_entry_lower(val);
		break;
	case UI_ORDER_LOWEST:
		ret = ui_set_entry_lowest(val);
		break;
	default:
		break;
	}
	if (ret != -1) return 0;
	return ret;
}

static int ui_cmd_create_instance(ui_session_t *sess, ui_entry_t *inst,
				  void *ctx, int argc, char **argv)
{
	ui_node_t *node = (ui_node_t *)ctx;
	
	ui_inst_create_user(inst, node->schema->name, argv[0]);
	return 0;
}

static int ui_cmd_rename_instance(ui_session_t *sess, ui_entry_t *inst,
				  void *ctx, int argc, char **argv)
{
	ui_entry_t *ninst = (ui_entry_t *)ctx;
	
	if (atomic_read(&ninst->refcnt) == 0) {
		if (ninst->user_value) {
			free(ninst->user_value);
			ninst->user_value = strdup(argv[0]);
		}
		if (ninst->conf_value) {
			free(ninst->conf_value);
			ninst->conf_value = strdup(argv[0]);
		}
	} else {
		ui_entry_t *new_en = ui_inst_create_user(ninst->parent, 
							 ninst->node->schema->name, 
							 argv[0]);
		if (!new_en) return -1;
		/* TODO: put ninst to gc list */
		UI_ENTRY_UNSET_VALID(ninst, UI_VALID_ALL);
		new_en->children = ninst->children;
	}

	return 0;
}

static int ui_cmd_delete_instance(ui_session_t *sess, ui_entry_t *inst,
				  void *ctx, int argc, char **argv)
{
	ui_entry_t *ninst = (ui_entry_t *)ctx;
	ui_inst_delete_user(ninst);
	return 0;
}

static int ui_cmd_review_instance(ui_session_t *sess, ui_entry_t *inst,
				  void *ctx, int argc, char **argv)
{
	ui_entry_t *p = (ui_entry_t *)ctx;
	ui_entry_t *cp = NULL;
	int i = 0;
	ui_table_t *table = ui_table_by_name(sess, p->node->oid);

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, p->node->oid);
	if (!table)
		return -1;

	ui_add_title(table, 0, "name");
	ui_add_title(table, 1, "value");

	while ((cp = ui_value_iterate_user(p, NULL, cp)) != NULL) {
		ui_add_value(table, "name", i, cp->node->schema->name);
		ui_add_value(table, "value", i, ui_get_user_value(cp));
		i++;
	}
	while ((cp = ui_inst_iterate_user(p, NULL, cp)) != NULL) {
		ui_add_value(table, "name", i, cp->node->schema->name);
		ui_add_value(table, "value", i, ui_get_user_value(cp));
		i++;
	}
	sess->result_table = table;
	return 0;
}

ui_argument_t ui_set_args[] = {
	{ "value",
	  "Attribute value",
	  NULL,
	  UI_TYPE_VALUE, },
};

ui_command_t ui_set_command = {
	"set",
	"Set attribute value",
	NULL,
	UI_CMD_SINGLE_ATTR,
	ui_set_args,
	1,
	LIST_HEAD_INIT(ui_set_command.link),
	ui_cmd_set_value,
};

ui_command_t ui_unset_command = {
	"unset",
	"Unset attribute value",
	NULL,
	UI_CMD_VALUE,
	NULL,
	0,
	LIST_HEAD_INIT(ui_unset_command.link),
	ui_cmd_unset_value,
};

ui_argument_t ui_order_args[] = {
	{ "order",
	  "Value order",
	  "entry_orders",
	  UI_TYPE_CHOICE, },
};

ui_command_t ui_order_command = {
	"order",
	"Change value order",
	NULL,
	UI_CMD_MULTI_VALUE,
	ui_order_args,
	1,
	LIST_HEAD_INIT(ui_order_command.link),
	ui_cmd_order_value,
};

ui_argument_t ui_add_args[] = {
	{ "value",
	  "Attribute value",
	  NULL,
	  UI_TYPE_VALUE, },
};

ui_command_t ui_add_command = {
	"add",
	"Add attribute value",
	NULL,
	UI_CMD_MULTI_ATTR,
	ui_add_args,
	1,
	LIST_HEAD_INIT(ui_add_command.link),
	ui_cmd_add_value,
};

ui_argument_t ui_create_args[] = {
	{ "instance",
	  "Class instance",
	  NULL,
	  UI_TYPE_INSTANCE, },
};

ui_command_t ui_create_command = {
	"create",
	"Create class instance",
	NULL,
	UI_CMD_MULTI_CLASS,
	ui_create_args,
	1,
	LIST_HEAD_INIT(ui_create_command.link),
	ui_cmd_create_instance,
};

ui_argument_t ui_rename_args[] = {
	{ "instance",
	  "Class instance",
	  NULL,
	  UI_TYPE_INSTANCE, },
};

ui_command_t ui_rename_command = {
	"rename",
	"Rename class instance",
	NULL,
	UI_CMD_MULTI_INST,
	ui_rename_args,
	1,
	LIST_HEAD_INIT(ui_rename_command.link),
	ui_cmd_rename_instance,
};

ui_command_t ui_delete_command = {
	"delete",
	"Delete class instance",
	NULL,
	UI_CMD_MULTI_INST,
	NULL,
	0,
	LIST_HEAD_INIT(ui_delete_command.link),
	ui_cmd_delete_instance,
};

ui_command_t ui_review_command = {
	"review",
	"View instance details",
	NULL,
	UI_CMD_INST,
	NULL,
	0,
	LIST_HEAD_INIT(ui_review_command.link),
	ui_cmd_review_instance,
};

string_map_t ui_multiple_orders[] = {
	{ "highest", UI_ORDER_HIGHEST, "The highest order" },
	{ "higher",  UI_ORDER_HIGHER, "A bit higher order" },
	{ "lower",   UI_ORDER_LOWER, "A bit lower order" },
	{ "lowest",  UI_ORDER_LOWEST, "The lowest order" },
	{ NULL,      0, NULL },
};

static int ui_order_name2int(const char *str)
{
	return name2int(ui_multiple_orders, str, 0);
}

ui_choice_t ui_order_choice = {
	"entry_orders",
	ui_multiple_orders,
	string_map_foreach,
	string_map_name,
	string_map_desc,
};

void ui_inst_choice_foreach(ui_choice_t *choice,
			    ui_iterate_fn func, void *data)
{
	ui_entry_t *iter = NULL;
	ui_entry_t *inst = NULL;
	char *oid = strdup(choice->priv);
	char *name, *next;

	if (!oid) return;

	name = oid[0] == '.' ? &oid[1] : &oid[0];
	next = strchr(name, '.');
	if (next) {
		*next = 0, next++;
	}

	while (next && (*next)) {
		inst = ui_inst_by_user(inst, name, NULL);
		if (!inst) goto end;
		name = next;
		next = strchr(name, '.');
		if (next) {
			*next = 0, next++;
		}
	}

	while ((iter = ui_minst_iterate_user(inst, name, iter)) != NULL) {
		func(choice, iter, data);
	}

end:
	free(oid);
}

const char *ui_inst_choice_name(const void *iter)
{
	ui_entry_t *entry = (ui_entry_t *)iter;
	return ui_get_user_value(entry);
}

const char *ui_inst_choice_desc(const void *iter)
{
	ui_entry_t *entry = (ui_entry_t *)iter;
	return entry->node->schema->desc;
}

int __init ui_user_init(void)
{
	ui_register_choice(&ui_order_choice);
	ui_register_command(&ui_create_command);
	ui_register_command(&ui_rename_command);
	ui_register_command(&ui_delete_command);
	ui_register_command(&ui_set_command);
	ui_register_command(&ui_unset_command);
	ui_register_command(&ui_add_command);
	ui_register_command(&ui_order_command);
	ui_register_command(&ui_review_command);
	return 0;
}

void __exit ui_user_exit(void)
{
	ui_unregister_command(&ui_review_command);
	ui_unregister_command(&ui_create_command);
	ui_unregister_command(&ui_rename_command);
	ui_unregister_command(&ui_delete_command);
	ui_unregister_command(&ui_set_command);
	ui_unregister_command(&ui_unset_command);
	ui_unregister_command(&ui_add_command);
	ui_unregister_command(&ui_order_command);
	ui_unregister_choice(&ui_order_choice);
}
