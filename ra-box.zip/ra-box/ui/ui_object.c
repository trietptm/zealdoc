#include "ui_priv.h"

string_map_t ui_types[] = {
	{ "none", UI_TYPE_NONE },
	{ "string", UI_TYPE_STRING },
	{ "int", UI_TYPE_INT },
	{ "uint", UI_TYPE_UINT },
	{ "boolean", UI_TYPE_BOOLEAN },
	{ "octets", UI_TYPE_OCTETS },
	{ "uint8", UI_TYPE_UINT8 },
	{ "uint16", UI_TYPE_UINT16 },
	{ "uint32", UI_TYPE_UINT32 },
	{ "int8", UI_TYPE_INT8 },
	{ "int16", UI_TYPE_INT16 },
	{ "int32", UI_TYPE_INT32 },

	{ "choice", UI_TYPE_CHOICE },
	{ "range", UI_TYPE_RANGE },

	{ "date", UI_TYPE_DATE },
	{ "ifid", UI_TYPE_IFID },
	{ "ifname", UI_TYPE_IFNAME },
	{ "iplabel", UI_TYPE_IPLABEL },
	{ "ipv4addr", UI_TYPE_IPADDR },
	{ "ipv6addr", UI_TYPE_IPV6ADDR },
	{ "ipv6prefix", UI_TYPE_IPV6PREFIX },

	/* UI internal objects */
	{ "attribute", UI_TYPE_ATTRIBUTE },
	{ "class", UI_TYPE_CLASS },
	{ "value", UI_TYPE_VALUE },
	{ "instance", UI_TYPE_INSTANCE },
	{ NULL, UI_TYPE_NONE },
};

static char *ui_oid_cat(const char *oid, const char *name);
static void ui_oid_free(char *oid);

const char *ui_node_type_name(int type)
{
	return int2name(ui_types, type, "none");
}

int ui_node_entry_type(ui_node_t *node)
{
	if (node) {
		switch (node->schema->type) {
		case UI_TYPE_CLASS:
			return UI_TYPE_INSTANCE;
		case UI_TYPE_ATTRIBUTE:
			return UI_TYPE_VALUE;
		}
	}
	return UI_TYPE_NONE;
}

static char *ui_oid_cat(const char *oid, const char *name)
{
	unsigned int len = strlen(oid)+strlen(name)+2;
	char *res = (char *)malloc(len);

	if (!res) return NULL;

	memset(res, 0x00, len);
	if (strcmp(name, ".") == 0) {
		return strdup(oid);
	}
	if (strcmp(oid, ".") == 0) {
		sprintf(res, "%s%s", oid, name);
	} else {
		sprintf(res, "%s.%s", oid, name);
	}
	return res;
}

static void ui_oid_free(char *oid)
{
	if (oid) free(oid);
}

int ui_is_multiple_entry(ui_entry_t *value)
{
	return !(value->node->schema->flags & UI_FLAG_SINGLE);
}

int ui_is_multiple_node(ui_node_t *node)
{
	return !(node->schema->flags & UI_FLAG_SINGLE);
}

const char *ui_get_entry_name(ui_entry_t *inst)
{
	if (inst && inst->node)
		return inst->node->schema->name;
	return NULL;
}

int ui_set_user_value(ui_entry_t *val, const char *value)
{
	if (value && val->node) {
		if (val->user_value) free(val->user_value);
		val->user_value = strdup(value);
		return 0;
	}
	return 1;
}

int ui_set_conf_value(ui_entry_t *val, const char *value)
{
	if (value && val->node) {
		if (val->conf_value) free(val->conf_value);
		val->conf_value = strdup(value);
		return 0;
	}
	return 1;
}

const char *ui_get_schema_value(ui_node_t *node)
{
	if (node && node->schema->type == UI_TYPE_ATTRIBUTE)
		return node->schema->def_value;
	return NULL;
}

const char *ui_get_conf_value(ui_entry_t *val)
{
	if (val)
		return val->conf_value ? val->conf_value : ui_get_schema_value(val->node);
	return NULL;
}

const char *ui_get_user_value(ui_entry_t *val)
{
	if (val) {
		if (val->user_value)
			return val->user_value;
	}
	return NULL;
}

ui_entry_t *ui_entry_by_conf(ui_entry_t *inst, int type,
			     const char *name, const char *value)
{
	ui_entry_t *iter = NULL;

	assert(name);

	if (!inst) inst = &ui_object_tree;
	for_each_ui_entry(inst, type, iter) {
		if (!(iter->valid & UI_VALID_CONF))
			continue;
		if (strcmp(name, iter->node->schema->name) == 0) {
			if (!ui_is_multiple_entry(iter)) {
				return iter;
			} else {
				if (value && iter->conf_value &&
				    strcmp(value, iter->conf_value) == 0)
					return iter;
			}
		}
	}
	return NULL;
}

ui_entry_t *ui_entry_get_by_conf(ui_entry_t *inst, int type,
				 const char *name, const char *value)
{
	ui_entry_t *ret = ui_entry_by_conf(inst, type, name, value);
	if (ret && ret->type == UI_TYPE_INSTANCE)
		return ui_inst_get(ret);
	return ret;
}

ui_entry_t *ui_entry_by_user(ui_entry_t *inst, int type,
			     const char *name, const char *value)
{
	ui_entry_t *iter = NULL;

	assert(name);

	if (!inst) inst = &ui_object_tree;
	for_each_ui_entry(inst, type, iter) {
		if (!(iter->valid & UI_VALID_USER))
			continue;
		if (strcmp(name, iter->node->schema->name) == 0) {
			if (!ui_is_multiple_entry(iter)) {
				return iter;
			} else {
				if (value && ui_get_user_value(iter) &&
				    strcmp(value, ui_get_user_value(iter)) == 0)
					return iter;
			}
		}
	}
	return NULL;
}

static ui_entry_t *__ui_entry_iterate(ui_entry_t *ins, int valid, ui_entry_t *iter)
{
	list_t *t;

	if (!ins) return NULL;
	if (!iter) t = ins->children.next;
	else t = iter->sibling.next;

	while (t != &ins->children) {
		ui_entry_t *en = list_entry(t, ui_entry_t, sibling);
		if (valid & en->valid) return en;
		t = t->next;
	}
	return NULL;
}

ui_entry_t *ui_entry_iterate(ui_entry_t *parent, int type, int valid,
			     const char *name, ui_entry_t *iter)
{
	if (!parent || !(valid & parent->valid)) return NULL;
	while ((iter = __ui_entry_iterate(parent, valid, iter)) != NULL) {
		if (type == iter->type &&
		    (!name || strcmp(iter->node->schema->name, name) == 0))
			return iter;
	}
	return NULL;
}

ui_entry_t *ui_multiple_entry_iterate(ui_entry_t *parent, int type, int valid,
				      const char *name, ui_entry_t *iter)
{
	while ((iter = __ui_entry_iterate(parent, valid, iter)) != NULL) {
		if (type == iter->type && ui_is_multiple_entry(iter) &&
		    (!name || strcmp(iter->node->schema->name, name) == 0))
			return iter;
	}
	return NULL;
}

int ui_load_single_values(ui_entry_t *inst, void *base, ui_parser_t *parser)
{
	ui_entry_t *val;
	ui_node_t *node;
	uint32_t ipaddr;
	const char *value;
	void *data;
	ui_parser_t *iter;
	int type, offset;
	ui_range_t *range;

	assert(inst && base);

	iter = parser;
	while (iter->oid != NULL) {
		offset = iter->offset;
		if (iter->offset < 0) goto next;
		node = ui_node_by_oid(iter->oid);
		if (!node) {
			log_kern(LOG_ERR, 
				 "UI: unknown oid, oid=%s", iter->oid);
			goto next;
		}

		type = node->schema->type;

		if (type != UI_TYPE_ATTRIBUTE ||
		    !(node->schema->flags & UI_FLAG_SINGLE)) {
			log_kern(LOG_ERR, 
				 "UI: oid is not single attribute, oid=%s",
				 iter->oid);
			goto next;
		}

		type = node->schema->val_type;
		val = ui_value_by_conf(inst, node->schema->name, NULL);
		if (!val) {
			value = ui_get_schema_value(node);
		} else {
			value = ui_get_conf_value(val);
		}

		data = ((char *)base) + offset;

redo_type:
		switch (type) {
		case UI_TYPE_BOOLEAN:
			if ((strcasecmp(value, "yes") == 0) ||
			    (strcasecmp(value, "on") == 0)) {
				*(int *)data = 1;
			} else if ((strcasecmp(value, "no") == 0) ||
				   (strcasecmp(value, "off") == 0)) {
				*(int *)data = 0;
			} else {
				*(int *)data = 0;
				log_kern(LOG_ERR, 
				         "UI: bad value for boolean, oid=%s, val=%s",
					 node->oid, value);
				return -1;
			}
			break;

		case UI_TYPE_INT:
			*(int *)data = strtol(value, 0, 0);
			break;

		case UI_TYPE_UINT:
			*(unsigned int *)data = strtol(value, 0, 0);
			break;

		case UI_TYPE_UINT8:
			*(uint8_t *)data = (uint8_t)strtol(value, 0, 0);
			break;

		case UI_TYPE_UINT16:
			*(uint16_t *)data = (uint16_t)strtol(value, 0, 0);
			if (node->schema->flags & UI_FLAG_NETORDER)
				*(uint16_t *)data = htons(*(uint16_t *)data);
			break;

		case UI_TYPE_UINT32:
			*(uint32_t *)data = (uint32_t)strtol(value, 0, 0);
			if (node->schema->flags & UI_FLAG_NETORDER)
				*(uint32_t *)data = htonl(*(uint32_t *)data);
			break;

		case UI_TYPE_INT8:
			*(int8_t *)data = (int8_t)strtol(value, 0, 0);
			break;

		case UI_TYPE_INT16:
			*(int16_t *)data = (int16_t)strtol(value, 0, 0);
			break;

		case UI_TYPE_INT32:
			*(int32_t *)data = (int32_t)strtol(value, 0, 0);
			break;

		case UI_TYPE_STRING:
		case UI_TYPE_CHOICE:
			if (iter->strconv)
				iter->strconv(value, data);
			else
				*(const char **)data = (const char *)value;
			break;

		case UI_TYPE_IPADDR:
			/* allow '*' as any address */
			if (!value || strcmp(value, "*") == 0) {
				*(uint32_t *) data = 0;
				break;
			}
			ipaddr = ip_addr(value);
			*(uint32_t *) data = ipaddr;
			break;

		case UI_TYPE_RANGE:
			range = ui_range_by_name(node->schema->type_name);
			if (!range) {
				log_kern(LOG_ERR,
					 "UI: undefined range, oid=%s, range=%s",
					 iter->oid, node->schema->type_name);
				return -1;
			}
			type = range->type;
			goto redo_type;
			break;

		default:
			log_kern(LOG_ERR, "UI: unsupported type, type=%d", type);
			return -1;
			break;
		}
		log_kern(LOG_DEBUG, "UI: %s[%s] = %s",
			 node->oid, ui_node_type_name(type), value);
next:
		iter++;
	}
	return 0;
}

int ui_get_entry_order_user(ui_entry_t *entry)
{
	int ret = -1;

	if (!ui_is_multiple_entry(entry)) {
		return ret;
	} else {
		ui_entry_t *iter = NULL;
		while ((iter = ui_mvalue_iterate_user(entry->parent,
						      entry->node->schema->name,
						      iter)) != NULL) { 
			ret++;
			if (iter == entry) break;
		}
	}
	return ret;
}

int ui_get_entry_order_conf(ui_entry_t *val)
{
	int ret = -1;

	if (!ui_is_multiple_entry(val)) {
		return ret;
	} else {
		ui_entry_t *iter = NULL;
		while ((iter = ui_mvalue_iterate_conf(val->parent,
						      val->node->schema->name,
						      iter)) != NULL) { 
			ret++;
			if (iter == val) break;
		}
	}
	return ret;
}

/* return value: the new val (lowest) order */
int ui_set_entry_lowest(ui_entry_t *val)
{
	int ret = -1;

	if (!ui_is_multiple_entry(val)) {
		return ret;
	} else {
		ui_entry_t *iter = NULL, *prev = val;
		char *set = val->user_value;
		int flag = 0;
		while ((iter = ui_mvalue_iterate_user(val->parent,
						      val->node->schema->name,
						      iter)) != NULL) {
			ret++;
			if (iter == val) flag = 1;
			if (flag) {
				prev->user_value = iter->user_value;
				prev = iter;
			}
		}
		prev->user_value = set;
	}
	return ret;
}

/* return value: the new value (highest) order, always be zero */
int ui_set_entry_highest(ui_entry_t *val)
{
	int ret = -1;

	if (!ui_is_multiple_entry(val)) {
		return ret;
	} else {
		ui_entry_t *iter = NULL;
		char *prev = val->user_value;
		while ((iter = ui_mvalue_iterate_user(val->parent,
						      val->node->schema->name,
						      iter)) != NULL) {
			char *temp = iter->user_value;
			iter->user_value = prev;
			prev = temp;
			if (iter == val) break;
		}
		ret = 0;
	}
	return ret;
}

int ui_set_entry_lower(ui_entry_t *val)
{
	int ret = -1;

	if (!ui_is_multiple_entry(val)) {
		return ret;
	} else {
		ui_entry_t *iter = NULL, *prev = NULL;
		while ((iter = ui_mvalue_iterate_user(val->parent,
						      val->node->schema->name,
						      iter)) != NULL) {
			ret++;
			if (iter == val) {
				prev = iter;
				continue;
			}
			if (prev) break;
		}
		if (iter) {
			char *temp = iter->user_value;
			iter->user_value = prev->user_value;
			prev->user_value = temp;
		}
	}
	return ret;
}

int ui_set_entry_higher(ui_entry_t *val)
{
	int ret = -1;

	if (!ui_is_multiple_entry(val)) {
		return ret;
	} else {
		ui_entry_t *iter = NULL, *prev = NULL;
		while ((iter = ui_mvalue_iterate_user(val->parent,
						      val->node->schema->name,
						      iter)) != NULL) {
			ret++;
			if (iter == val) break;
			prev = iter;
		}
		if (prev && prev != val) {
			char *temp = prev->user_value;
			prev->user_value = iter->user_value;
			iter->user_value = temp;
			ret--;
		}
	}
	return ret;
}

ui_entry_t *ui_entry_alloc(ui_entry_t *parent, int type,
			   const char *name, const char *value)
{
	ui_entry_t *entry = NULL;
	ui_node_t *node;
	char *oid = NULL;
	
	assert(parent);

	if (!name || !*name) return NULL;
	oid = ui_oid_cat(parent ? parent->node->oid : ".", name);
	if (!oid) return NULL;
	node = ui_node_by_oid(oid);
	ui_oid_free(oid);
	if (!node) {
		log_kern(LOG_ERR,
			 "UI: invalid entry, oid=%s, name=%s",
			 parent ? parent->node->oid : "-", name);
		return NULL;
	}

	if (node == &ui_schema_tree)
		return ui_inst_get(&ui_object_tree);

	if (!value && ui_is_multiple_node(node)) {
		log_kern(LOG_ERR,
			 "UI: missing entry name, inst=%s", name);
		return NULL;
	}

	if (value && ui_is_multiple_node(node)) {
		int res = 0;
		if (node->schema->type == UI_TYPE_CLASS) {
			res = ui_validate_syntax(parent, UI_TYPE_INSTANCE, value, node);
		} else {
			res = ui_validate_syntax(parent, UI_TYPE_VALUE, value, node);
		}
		if (res) {
			log_kern(LOG_ERR,
				 "UI: invalid entry name, inst=%s", name);
			return NULL;
		}
	}
	entry = (ui_entry_t *)malloc(sizeof(ui_entry_t));

	if (entry) {
		memset(entry, 0, sizeof(ui_entry_t));

		/* no conf_value user's */
		atomic_set(&entry->refcnt, 0);
		list_init(&entry->children);
		list_init(&entry->sibling);
		entry->parent = parent;
		entry->type = type;
		entry->valid = UI_VALID_ALL;
		entry->node = node;
		if (value && *value) {
			entry->conf_value = strdup(value);
			entry->user_value = strdup(value);
		}
		list_insert_before(&entry->sibling, &parent->children);
	}
	return entry;
}

void ui_entry_free(ui_entry_t *entry)
{
	if (entry) {
		ui_entry_t *n, *pos;

		if (atomic_read(&entry->refcnt) != 0 ||
		    (entry->valid & UI_VALID_USER)) {
			/* TODO: put entry to gc list */
			return;
		}
		log_kern(LOG_INFO, "UI: burning entry, oid=%s, inst=%s, val=%s",
			 entry->node->oid,
			 ui_get_conf_value(entry->parent),
			 ui_get_conf_value(entry));
		for_each_ui_inst_safe(entry, pos, n) {
			ui_entry_free(pos);
		}
		for_each_ui_value_safe(entry, pos, n) {
			ui_entry_free(pos);
		}
		if (entry->user_value) 
			free((char *)entry->user_value);
		if (entry->conf_value) 
			free((char *)entry->conf_value);
		list_delete_init(&entry->sibling);
		free(entry);
	}
}

void ui_value_delete_user(ui_entry_t *val)
{
	if (val) {
		UI_ENTRY_UNSET_VALID(val, UI_VALID_ALL);
		if (val->user_value) {
			free(val->user_value);
			val->user_value = NULL;
		}
	}
}

void ui_inst_delete_conf(ui_entry_t *inst)
{
	if (inst && atomic_dec_and_test(&inst->refcnt)) {
		ui_entry_free(inst);
	}
}

void ui_inst_delete_user(ui_entry_t *inst)
{
	if (inst) {
		ui_entry_t *n, *pos;
		UI_ENTRY_UNSET_VALID(inst, UI_VALID_ALL);
		if (inst->user_value) {
			free(inst->user_value);
			inst->user_value = NULL;
		}
		for_each_ui_value_safe(inst, pos, n)
			ui_inst_delete_user(pos);
		for_each_ui_inst_safe(inst, pos, n)
			ui_inst_delete_user(pos);
		if (inst->type == UI_TYPE_INSTANCE) {
			ui_entry_free(inst);
		}
	}
}

ui_entry_t *ui_entry_lookup_conf(ui_entry_t *inst, int type,
				 const char *name, const char *value)
{
	ui_entry_t *ret = NULL;
	ui_node_t *node = NULL;

	if (!inst) inst = &ui_object_tree;
	node = ui_node_by_name(inst->node, name);
	if (!node) return NULL;
	
	ret = ui_entry_get_by_conf(inst, type, name, value);
	if (ret) {
		return ret;
	} else {
		if (type == UI_TYPE_VALUE || ui_is_multiple_node(node))
			return NULL;
		if (!inst)
			inst = &ui_object_tree;
		ret = ui_entry_alloc(inst, type, name, NULL);
		if (ret && ret->type == UI_TYPE_INSTANCE) {
			/* always UI_TYPE_INSTANCE */
			return ui_inst_get(ret);
		}
		return ret;
	}
}

ui_entry_t *ui_entry_create_user(ui_entry_t *inst, int type,
				 const char *name, const char *value)
{
	ui_entry_t *ret = ui_entry_by_user(inst, type, name, value);
	if (ret) {
		return ret;
	} else {
		if (!inst)
			inst = &ui_object_tree;
		ret = ui_entry_alloc(inst, type, name, value);
		return ret;
	}
}
