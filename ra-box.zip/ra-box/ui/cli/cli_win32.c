#include "cli_stdio.h"

#define CONSOLE_MODE	ENABLE_PROCESSED_INPUT | ENABLE_MOUSE_INPUT
/* milliseconds to suspend maximally when waiting for input */
#define WAIT_FOR_INPUT	200
/* flags for open state of the console  */
#define FOR_INPUT	1
#define FOR_OUTPUT	2
#define INITIALIZED	4

static uint16_t tty_port = 0;
static int tty_running = 0;
static int tty_stopped = 0;

#define EXT_PREFIX 0x1f8

#define KEV	   irec.Event.KeyEvent			/* to make life easier  */
#define KST	   irec.Event.KeyEvent.dwControlKeyState

static int pending_key = 0;
static int pending_count = 0;
static int pending_prefix = 0;

extern int haveConsole;		/* imported from rltty.c  */
extern HANDLE hStdout, hStdin;
extern COORD rlScreenOrigin, rlScreenEnd;
extern int rlScreenStart, rlScreenMax;

/* global vars used by other modules */

int	haveConsole	= 0;	/* remember init result of the console  */
HANDLE	hStdout, hStdin;	/* these are different from stdin, stdout  */

COORD	rlScreenOrigin;		/* readline origin in frame buffer coordinates */
int	rlScreenStart = 0;	/* readline origin as frame screen buffer offset */
COORD	rlScreenEnd;		/* end of line in frame buffer coordinates */
int	rlScreenMax = 0;	/* end of line as linear frame buffer offset */

static DWORD savedConsoleMode = 0;	/* to restore console on exit */

void cli_stdio_default_bindings(cli_session_t *sess)
{
#ifdef CONFIG_CLI_HISTORY
	cli_bind_keyseq(sess, "\\M-\\�&", cli_get_previous_history);
	cli_bind_keyseq(sess, "\\M-\\�(", cli_get_next_history);
#endif
	cli_bind_keyseq(sess, "\\M-\\�'", cli_forward_char);
	cli_bind_keyseq(sess, "\\M-\\�%", cli_backward_char);
	
	cli_bind_keyseq(sess, "\\M-\\�$", cli_beg_of_line);
	cli_bind_keyseq(sess, "\\M-\\�#", cli_end_of_line);
	cli_bind_keyseq(sess, "\\M-\\�%", cli_backward_word);
	cli_bind_keyseq(sess, "\\M-\\�'", cli_forward_word);
	
	cli_bind_keyseq(sess, "\\M-\\�.", cli_delete);
	cli_bind_keyseq(sess, ".", cli_unix_word_rubout);
}

/* Query and set up a Window Console */

int cli_stdio_init_terminal(cli_session_t *sess)
{
	sess->echoing_p = 1;
	
	if (!(haveConsole & INITIALIZED)) {
		if (!(haveConsole & FOR_INPUT) &&
		    ((hStdin = GetStdHandle(STD_INPUT_HANDLE)) != INVALID_HANDLE_VALUE) ) {
			DWORD dummy;
			INPUT_RECORD irec;
			if (PeekConsoleInput(hStdin, &irec, 1, &dummy)) {
				haveConsole |= FOR_INPUT;
				if (GetConsoleMode(hStdin, &savedConsoleMode))
					SetConsoleMode(hStdin, CONSOLE_MODE);
			}
		}
		if ((hStdout = GetStdHandle(STD_OUTPUT_HANDLE)) != INVALID_HANDLE_VALUE) {
			CONSOLE_SCREEN_BUFFER_INFO csbi;
			if (GetConsoleScreenBufferInfo(hStdout, &csbi) 
				&& (csbi.dwSize.X > 0) && (csbi.dwSize.Y > 0)) {
				haveConsole |= FOR_OUTPUT;
				rlScreenOrigin = csbi.dwCursorPosition;
				rlScreenStart = (int)csbi.dwCursorPosition.Y * (int)csbi.dwSize.X
					+ (int)csbi.dwCursorPosition.X;
			}
		}
		haveConsole |= INITIALIZED;
	}
	return 0;
}

/* Restore the consoles's normal settings and modes. */
void cli_stdio_exit_terminal(cli_session_t *sess)
{
	SetConsoleMode(hStdin, savedConsoleMode);
	haveConsole = 0;
}

static int cli_stdio_getc(void)
{
	if (pending_count) {
		--pending_count;
		if (pending_prefix && (pending_count & 1))
			return pending_prefix;
		else
			return pending_key;
	}

	while (1) {
		DWORD dummy;
		
		if (WaitForSingleObject(hStdin, WAIT_FOR_INPUT) != WAIT_OBJECT_0) {
			Sleep(100);
			continue;
		}
		if (haveConsole & FOR_INPUT) {
			INPUT_RECORD irec;
			ReadConsoleInput(hStdin, &irec, 1, &dummy);
			switch (irec.EventType) {
			case KEY_EVENT:
				if (KEV.bKeyDown &&
				    ((KEV.wVirtualKeyCode < VK_SHIFT) ||
				     (KEV.wVirtualKeyCode > VK_MENU))) {
					pending_count = KEV.wRepeatCount;
					pending_prefix = 0;
					pending_key = KEV.uChar.AsciiChar & 0xff;
					
					if (KST & ENHANCED_KEY) {
#define CTRL_TO_ASCII(c) ((c) - 'a' + 1)
						switch (KEV.wVirtualKeyCode) {
						case VK_HOME:
							pending_key = CTRL_TO_ASCII('a');
							break;
						case VK_END:
							pending_key = CTRL_TO_ASCII('e');
							break;
						case VK_LEFT:
							pending_key = CTRL_TO_ASCII('b');
							break;
						case VK_RIGHT:
							pending_key = CTRL_TO_ASCII('f');
							break;
						case VK_UP:
							pending_key = CTRL_TO_ASCII('p');
							break;
						case VK_DOWN:
							pending_key = CTRL_TO_ASCII('n');
							break;
						case VK_DELETE:
							pending_key = CTRL_TO_ASCII('d');
							break;
						}
					}
					
					if (KST & (LEFT_ALT_PRESSED | RIGHT_ALT_PRESSED))
						pending_prefix = VK_ESCAPE;
					
					if (pending_prefix)
						pending_count = (pending_count << 1) - 1;
					
					/* Ascii direct */
					if (pending_key)
						pending_count--;
					
					if (pending_prefix)
						return pending_prefix;
					return pending_key;
				}
				break;
			case MOUSE_EVENT:
			default:
				break;
			}
		} else {
			int key;
			ReadFile(hStdin, &key, 1, &dummy, NULL);
			return key;
		}
	}
}

static int __cli_stdio_get_sock(void)
{
	int res;
	int sock;
	int on = 1;
	struct sockaddr_in saddr;

	sock = socket(PF_INET, SOCK_DGRAM, 0);
	if (sock < 0)
		return -1;
 	(void) setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on));

	memset(&saddr, 0, sizeof(saddr));
	saddr.sin_family = AF_INET;
	saddr.sin_port = 0;
	saddr.sin_addr.s_addr = INADDR_ANY;

	res = bind(sock, (struct sockaddr *) &saddr, sizeof(saddr));
	if (res < 0) {
		closesocket(sock);
		return -1;
	}
	return sock;
}

static void cli_stdio_terminal_thread(void *args)
{
	struct sockaddr_in addr;
	int res;
	int len = sizeof (addr);
	unsigned char c;

	/* TODO: use semaphore */
	tty_running = 1;

	while (!tty_stopped) {
		c = cli_stdio_getc();
		memset(&addr, 0, sizeof (addr));
		addr.sin_family = AF_INET;
		addr.sin_addr.s_addr = inet_addr("127.0.0.1");
		addr.sin_port = tty_port;
		if (c != '\n') {
			/* work around \r\n for win32 */
			res = sendto(cli_stdio_instream, &c, sizeof (c), 0,
				     (struct sockaddr *)&addr, len);
			if (res < 0)
				panic();
		}
	}
	tty_running = 0;
}

void cli_stdio_stop_terminal(void)
{
	tty_stopped = 1;
	if (cli_stdio_instream >= 0)
		closesocket(cli_stdio_instream);
	cli_stdio_instream = cli_stdio_outstream = INVALID_SOCKET;
}

int cli_stdio_start_terminal(void)
{
	static int sock = -1;
	struct sockaddr_in addr;
	int len = sizeof (addr);
	int res;

	sock = __cli_stdio_get_sock();
	if (sock < 0)
		goto failure;
	res = getsockname(sock, (struct sockaddr *)&addr, &len);
	if (res < 0)
		goto failure;

	tty_port = addr.sin_port;
	cli_stdio_instream = sock;
	cli_stdio_outstream = STDOUT_FILENO;

	if (!tty_running) {
		_beginthread(cli_stdio_terminal_thread, 0, NULL);
	}
	return 0;
failure:
	if (sock != -1) closesocket(sock);
	return -1;
}
