#include "cli_priv.h"

/* used only in this file */
static char **cli_invoking_keyseqs_map(cli_keymap_t map,
				       cli_command_fn *function);
static int cli_generic_bind(cli_keymap_t, int, const char *, char *);
static cli_command_fn *cli_keyseq_function(cli_keymap_t,
					   const char *, int *);

/* Bind KEY to FUNCTION.  Returns non-zero if KEY is out of range. */
int cli_bind_key_map(cli_keymap_t map, int key, cli_command_fn *function)
{
	if (key < 0)
		return (key);
	
	if (META_CHAR(key) && cli_main_config.convert_meta_chars) {
		if (map[ESC].type == ISKMAP) {
			cli_keymap_t escmap;
			
			escmap = FUNCTION_TO_KEYMAP(map, ESC);
			key = UNMETA(key);
			escmap[key].type = ISFUNC;
			escmap[key].function = function;
			return (0);
		}
		return (key);
	}
	
	map[key].type = ISFUNC;
	map[key].function = function;
	return (0);
}

int cli_bind_key(cli_session_t *sess, int key, cli_command_fn *function)
{
	return cli_bind_key_map(sess->keymap, key, function);
}

int cli_unbind_key(cli_session_t *sess, int key)
{
	return (cli_bind_key(sess, key, (cli_command_fn *)NULL));
}

int cli_bind_keyseq_map(cli_keymap_t map,
		       const char *keyseq, cli_command_fn *function)
{
	return (cli_generic_bind(map, ISFUNC, keyseq, (char *)function));
}

int cli_bind_keyseq(cli_session_t *sess, const char *keyseq,
		    cli_command_fn *default_func)
{
	cli_command_fn *func;
	
	if (keyseq) {
		func = cli_keyseq_function(sess->keymap, keyseq, (int *)NULL);
		if (!func) {
			return (cli_bind_keyseq_map(sess->keymap, keyseq,
						    default_func));
		} else {
			return 1;
		}
	}
	return 0;
}

/* Bind the key sequence represented by the string KEYSEQ to
 * the arbitrary pointer DATA.  TYPE says what kind of data is
 * pointed to by DATA, right now this can be a function (ISFUNC),
 * or a keymap (ISKMAP).  This makes new keymaps as necessary.
 * The initial place to do bindings is in MAP.
 */
int cli_generic_bind(cli_keymap_t map, int type,
		     const char *keyseq, char *data)
{
	char *keys;
	int keys_len;
	register int i;
	cli_kmentry_t k;
	
	k.function = 0;
	k.type = 0;
	
	/* If no keys to bind to, exit right away. */
	if (keyseq == 0 || *keyseq == 0) {
		return -1;
	}
	
	keys = (char *)xmalloc(1 + (2 * strlen(keyseq)));
	
	/* Translate the ASCII representation of KEYSEQ into an array of
	 * characters.  Stuff the characters into KEYS, and the length of
	 * KEYS into KEYS_LEN.
	 */
	if (cli_translate_keyseq(map, keyseq, keys, &keys_len)) {
		free(keys);
		return -1;
	}
	
	/* Bind keys, making new keymaps as necessary. */
	for (i = 0; i < keys_len; i++) {
		unsigned char uc = keys[i];
		int ic;
		
		ic = uc;
		if (ic < 0 || ic >= KEYMAP_SIZE) {
			free(keys);
			return -1;
		}
		
		if (META_CHAR(ic) && cli_main_config.convert_meta_chars) {
			if (map[ESC].type == ISKMAP) {
				map = FUNCTION_TO_KEYMAP(map, ESC);
				ic = UNMETA(ic);
			}
		}
		
		if ((i + 1) < keys_len) {
			if (map[ic].type != ISKMAP) {
				/* We allow subsequences of keys.  If a
				 * keymap is being created that will
				 * `shadow' an existing function or macro
				 * key binding, we save that keybinding
				 * into the ANYOTHERKEY index in the new
				 * map.  The dispatch code will look there
				 * to find the function to execute if the
				 * subsequence is not matched.
				 * ANYOTHERKEY was chosen to be greater
				 * than UCHAR_MAX.
				 */
				k = map[ic];
				
				map[ic].type = ISKMAP;
				map[ic].function = KEYMAP_TO_FUNCTION(cli_keymap_new());
			}
			map = FUNCTION_TO_KEYMAP(map, ic);
			/* The dispatch code will return this function if
			 * no matching key sequence is found in the
			 * keymap.  This (with a little help from the
			 * dispatch code in readline.c) allows `a' to be
			 * mapped to something, `abc' to be mapped to
			 * something else, and the function bound  to `a'
			 * to be executed when the user types `abx',
			 * leaving `bx' in the input queue.
			 */
			if (k.function && k.type == ISFUNC) {
				map[ANYOTHERKEY] = k;
				k.function = 0;
			}
		} else {
			if (map[ic].type == ISKMAP) {
				map = FUNCTION_TO_KEYMAP(map, ic);
				ic = ANYOTHERKEY;
			}
			
			map[ic].function = KEYMAP_TO_FUNCTION(data);
			map[ic].type = type;
		}
	}
	free(keys);
	return 0;
}

/* Translate the ASCII representation of SEQ, stuffing the values into
 * ARRAY, an array of characters.  LEN gets the final length of ARRAY.
 * Return non-zero if there was an error parsing SEQ.
 */
int cli_translate_keyseq(cli_keymap_t map, const char *seq,
			 char *array, int *len)
{
	register int i, c, l, temp;
	
	for (i = 0, l = 0; (c = seq[i]) > 0; i++) {
		if (c == '\\') {
			c = seq[++i];
			
			if (c == 0)
				break;
			
			/* Handle \C- and \M- prefixes. */
			if ((c == 'C' || c == 'M') && seq[i + 1] == '-') {
				/* Handle special case of backwards define. */
				if (strncmp (&seq[i], "C-\\M-", 5) == 0) {
					/* ESC is meta-prefix */
					array[l++] = ESC;
					i += 5;
					array[l++] = CTRL(_rl_to_upper(seq[i]));
					if (seq[i] == '\0')
						i--;
				} else if (c == 'M') {
					/* seq[i] == '-' */
					i++;
					/* XXX - obey convert-meta setting */
					if (cli_main_config.convert_meta_chars &&
					    map[ESC].type == ISKMAP) {
						/* ESC is meta-prefix */
						array[l++] = ESC;
					} else if (seq[i+1] == '\\' &&
						   seq[i+2] == 'C' &&
						   seq[i+3] == '-') {
						i += 4;
						temp = (seq[i] == '?') ? RUBOUT : CTRL(_rl_to_upper(seq[i]));
						array[l++] = META(temp);
					} else {
						/* This doesn't yet handle
						 * things like \M-\a, which
						 * may or may not have any
						 * reasonable meaning.  
						 * You're probably better
						 * off using straight octal
						 * or hex.
						 */
						i++;
						array[l++] = META (seq[i]);
					}
				} else if (c == 'C') {
					i += 2;
					/* Special hack for C-?... */
					array[l++] = (seq[i] == '?') ? RUBOUT : CTRL (_rl_to_upper (seq[i]));
				}
				continue;
			}	      
			
			/* Translate other backslash-escaped characters.
			 * These are the same escape sequences that
			 * bash's `echo' and `printf' builtins handle,
			 * with the addition of \d -> RUBOUT.  A backslash
			 * preceding a character that is not special is
			 * stripped.
			 */
			switch (c) {
			case 'a':
				array[l++] = '\007';
				break;
			case 'b':
				array[l++] = '\b';
				break;
			case 'd':
				array[l++] = RUBOUT;	/* readline-specific */
				break;
			case 'e':
				array[l++] = ESC;
				break;
			case 'f':
				array[l++] = '\f';
				break;
			case 'n':
				array[l++] = NEWLINE;
				break;
			case 'r':
				array[l++] = RETURN;
				break;
			case 't':
				array[l++] = TAB;
				break;
			case 'v':
				array[l++] = 0x0B;
				break;
			case '\\':
				array[l++] = '\\';
				break;
			case '0': case '1': case '2': case '3':
			case '4': case '5': case '6': case '7':
				i++;
				for (temp = 2, c -= '0';
				     ISOCTAL(seq[i]) && temp--; i++)
					c = (c * 8) + OCTVALUE(seq[i]);
				/* auto-increment in for loop */
				i--;
				array[l++] = c & largest_char;
				break;
			case 'x':
				i++;
				for (temp = 2, c = 0;
				     ISXDIGIT((unsigned char)seq[i]) && temp--;
				     i++) {
					c = (c * 16) + HEXVALUE(seq[i]);
				}
				if (temp == 2)
					c = 'x';
				/* auto-increment in for loop */
				i--;
				array[l++] = c & largest_char;
				break;
			default:
				/* backslashes before non-special chars
				 * just add the char
				 */
				array[l++] = c;
				/* the backslash is stripped */
				break;
			}
			continue;
		}
	
		array[l++] = c;
	}
	
	*len = l;
	array[l] = '\0';
	return (0);
}

char *cli_untranslate_keyseq(int seq)
{
	static char kseq[16];
	int i, c;
	
	i = 0;
	c = seq;
	if (META_CHAR(c)) {
		kseq[i++] = '\\';
		kseq[i++] = 'M';
		kseq[i++] = '-';
		c = UNMETA(c);
	} else if (c == ESC) {
		kseq[i++] = '\\';
		c = 'e';
	} else if (CTRL_CHAR(c)) {
		kseq[i++] = '\\';
		kseq[i++] = 'C';
		kseq[i++] = '-';
		c = UNCTRL(c);
		c = _rl_to_lower(c);
	} else if (c == RUBOUT) {
		kseq[i++] = '\\';
		kseq[i++] = 'C';
		kseq[i++] = '-';
		c = '?';
	}
	
	if (c == ESC) {
		kseq[i++] = '\\';
		c = 'e';
	}
	else if (c == '\\' || c == '"') {
		kseq[i++] = '\\';
	}
	
	kseq[i++] = (unsigned char)c;
	kseq[i] = '\0';
	return kseq;
}

/* Return the function (or macro) definition which would be invoked via
 * KEYSEQ if executed in MAP.  If MAP is NULL, then the current keymap is
 * used.  TYPE, if non-NULL, is a pointer to an int which will receive
 * the type of the object pointed to.  One of ISFUNC (function), ISKMAP
 * (keymap).
 */
cli_command_fn *cli_keyseq_function(cli_keymap_t map,
				    const char *keyseq, int *type)
{
	register int i;
	
	if (map == 0)
		map = cli_standard_keymap;
	
	for (i = 0; keyseq && keyseq[i]; i++) {
		unsigned int ic = keyseq[i];
		
		if (META_CHAR(ic) && cli_main_config.convert_meta_chars) {
			if (map[ESC].type == ISKMAP) {
				map = FUNCTION_TO_KEYMAP(map, ESC);
				ic = UNMETA(ic);
			} else {
				if (type)
					*type = map[ESC].type;
				return (map[ESC].function);
			}
		}
		
		if (map[ic].type == ISKMAP) {
			/* If this is the last key in the key sequence,
			 * return the map.
			 */
			if (keyseq[i + 1] == '\0') {
				if (type)
					*type = ISKMAP;
				return (map[ic].function);
			} else
				map = FUNCTION_TO_KEYMAP(map, ic);
		} else if (map[ic].type != ISKMAP && keyseq[i+1]) {
			/* If we're not at the end of the key sequence,
			 * and the current key is bound to something other
			 * than a keymap, then the entire key sequence is
			 * not bound.
			 */
			return ((cli_command_fn *)NULL);
		} else {
			if (type)
				*type = map[ic].type;
			return (map[ic].function);
		}
	}
	return ((cli_command_fn *)NULL);
}

static char *_cli_get_keyname(int key)
{
	char *keyname;
	int i, c;
	
	keyname = (char *)xmalloc(8);
	
	c = key;
	/* Since this is going to be used to write out
	 * keysequence-function pairs for possible inclusion in an
	 * inputrc file, we don't want to do any special meta processing
	 * on KEY.
	 */
#if 1
	/* XXX - Experimental */
	/* We might want to do this, but the old version of the code
	 * did not.
	 */
	
	/* If this is an escape character, we don't want to do any more
	 * processing. Just add the special ESC key sequence and return.
	 */
	if (c == ESC) {
		keyname[0] = '\\';
		keyname[1] = 'e';
		keyname[2] = '\0';
		return keyname;
	}
#endif
	
	/* RUBOUT is translated directly into \C-? */
	if (key == RUBOUT) {
		keyname[0] = '\\';
		keyname[1] = 'C';
		keyname[2] = '-';
		keyname[3] = '?';
		keyname[4] = '\0';
		return keyname;
	}
	
	i = 0;
	/* Now add special prefixes needed for control characters.
	 * This can potentially change C.
	 */
	if (CTRL_CHAR(c)) {
		keyname[i++] = '\\';
		keyname[i++] = 'C';
		keyname[i++] = '-';
		c = UNCTRL(c);
		c = _rl_to_lower(c);
	}
	
	/* XXX experimental code.  Turn the characters that are not ASCII
	 * or ISO Latin 1 (128 - 159) into octal escape sequences
	 * (\200 - \237). This changes C.
	 */
	if (c >= 128 && c <= 159) {
		keyname[i++] = '\\';
		keyname[i++] = '2';
		c -= 128;
		keyname[i++] = (c / 8) + '0';
		c = (c % 8) + '0';
	}
	
	/* Now, if the character needs to be quoted with a backslash,
	 * do that.
	 */
	if (c == '\\' || c == '"')
		keyname[i++] = '\\';
	
	/* Now add the key, terminate the string, and return it. */
	keyname[i++] = (char)c;
	keyname[i] = '\0';
	
	return keyname;
}

/* Return a NULL terminated array of strings which represent the key
 * sequences that are used to invoke FUNCTION in MAP.
 */
char **cli_invoking_keyseqs_map(cli_keymap_t map, cli_command_fn *function)
{
	register int key;
	char **result;
	int result_index, result_size;
	
	result = (char **)NULL;
	result_index = result_size = 0;
	
	for (key = 0; key < KEYMAP_SIZE; key++)	{
		switch (map[key].type) {
		case ISFUNC:
			/* If the function in the keymap is the one we are looking for,
			   then add the current KEY to the list of invoking keys. */
			if (map[key].function == function) {
				char *keyname;
				keyname = _cli_get_keyname(key);
				if (result_index + 2 > result_size) {
					result_size += 10;
					result = (char **)xrealloc(result, result_size * sizeof(char *));
				}
				
				result[result_index++] = keyname;
				result[result_index] = (char *)NULL;
			}
			break;
			
		case ISKMAP:
			{
				char **seqs;
				register int i;
				
				/* Find the list of keyseqs in this map which have FUNCTION as
				   their target.  Add the key sequences found to RESULT. */
				if (map[key].function)
					seqs =
					cli_invoking_keyseqs_map(FUNCTION_TO_KEYMAP(map, key), function);
				else
					break;
				
				if (seqs == 0)
					break;
				
				for (i = 0; seqs[i]; i++) {
					char *keyname = (char *)xmalloc(6 + strlen(seqs[i]));
					
					if (key == ESC) {
						/* If ESC is the meta prefix and we're converting chars
						   with the eighth bit set to ESC-prefixed sequences, then
						   we can use \M-.  Otherwise we need to use the sequence
						   for ESC. */
						if (cli_main_config.convert_meta_chars && map[ESC].type == ISKMAP)
							sprintf(keyname, "\\M-");
						else
							sprintf(keyname, "\\e");
					} 
					else if (CTRL_CHAR(key)) {
						int kt = UNCTRL(key);
						sprintf(keyname, "\\C-%c", _rl_to_lower(kt));
					}
					else if (key == RUBOUT)
						sprintf(keyname, "\\C-?");
					else if (key == '\\' || key == '"') {
						keyname[0] = '\\';
						keyname[1] = (char) key;
						keyname[2] = '\0';
					}
					else {
						keyname[0] = (char) key;
						keyname[1] = '\0';
					}
					
					strcat(keyname, seqs[i]);
					free(seqs[i]);
					
					if (result_index + 2 > result_size) {
						result_size += 10;
						result = (char **)xrealloc(result, result_size * sizeof(char *));
					}
					
					result[result_index++] = keyname;
					result[result_index] = (char *)NULL;
				}
				
				free(seqs);
			}
			break;
		}
	}
	return (result);
}

/* Return a new, empty keymap.
   Free it with free() when you are done. */
cli_keymap_t cli_keymap_new(void)
{
	register int i;
	cli_keymap_t keymap = (cli_keymap_t)xmalloc(KEYMAP_SIZE * sizeof (cli_kmentry_t));
	
	for (i = 0; i < KEYMAP_SIZE; i++) {
		keymap[i].type = ISFUNC;
		keymap[i].function = (cli_command_fn *)NULL;
	}
	
	return (keymap);
}

cli_keymap_t cli_keymap_copy(cli_keymap_t map)
{
	int i;
	cli_keymap_t temp;
	
	temp = cli_keymap_new();
	for (i = 0; i < KEYMAP_SIZE; i++) {
		temp[i].type = map[i].type;
		temp[i].function = map[i].function;
	}
	return (temp);
}

/* Free the storage associated with MAP. */
void cli_keymap_free(cli_keymap_t map)
{
	int i;
	
	if (!map)
		return;
	
	for (i = 0; i < KEYMAP_SIZE; i++) {
		switch (map[i].type) {
		case ISFUNC:
			break;
		case ISKMAP:
			cli_keymap_free((cli_keymap_t)map[i].function);
			break;
		}
	}
}

cli_kmarray_t cli_standard_keymap = {
	/* Control keys. */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-@ */
	{ ISFUNC, cli_beg_of_line },			/* Control-a */
	{ ISFUNC, cli_backward_char },			/* Control-b */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-c */
	{ ISFUNC, cli_delete },				/* Control-d */
	{ ISFUNC, cli_end_of_line },			/* Control-e */
	{ ISFUNC, cli_forward_char },			/* Control-f */
	{ ISFUNC, cli_abort },				/* Control-g */
	{ ISFUNC, cli_rubout },				/* Control-h */
	{ ISFUNC, cli_complete },			/* Control-i */
	{ ISFUNC, cli_newline },			/* Control-j */
	{ ISFUNC, cli_kill_line },			/* Control-k */
	{ ISFUNC, cli_clear_screen },			/* Control-l */
	{ ISFUNC, cli_newline },			/* Control-m */
	{ ISFUNC, cli_get_next_history },		/* Control-n */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-o */
	{ ISFUNC, cli_get_previous_history },		/* Control-p */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-q */
	{ ISFUNC, cli_reverse_search_history },		/* Control-r */
	{ ISFUNC, cli_forward_search_history },		/* Control-s */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-t */
	{ ISFUNC, cli_unix_line_discard },		/* Control-u */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-v */
	{ ISFUNC, cli_unix_word_rubout },		/* Control-w */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-x */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-y */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-z */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-[ */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-\ */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-] */
	{ ISFUNC, (cli_command_fn *)0x0 },		/* Control-^ */
	{ ISFUNC, cli_undo_command },			/* Control-_ */
	
	/* The start of printing characters. */
	{ ISFUNC, cli_insert },		/* SPACE */
	{ ISFUNC, cli_insert },		/* ! */
	{ ISFUNC, cli_insert },		/* " */
	{ ISFUNC, cli_insert },		/* # */
	{ ISFUNC, cli_insert },		/* $ */
	{ ISFUNC, cli_insert },		/* % */
	{ ISFUNC, cli_insert },		/* & */
	{ ISFUNC, cli_insert },		/* ' */
	{ ISFUNC, cli_insert },		/* ( */
	{ ISFUNC, cli_insert },		/* ) */
	{ ISFUNC, cli_insert },		/* * */
	{ ISFUNC, cli_insert },		/* + */
	{ ISFUNC, cli_insert },		/* , */
	{ ISFUNC, cli_insert },		/* - */
	{ ISFUNC, cli_insert },		/* . */
	{ ISFUNC, cli_insert },		/* / */
	
	/* Regular digits. */
	{ ISFUNC, cli_insert },		/* 0 */
	{ ISFUNC, cli_insert },		/* 1 */
	{ ISFUNC, cli_insert },		/* 2 */
	{ ISFUNC, cli_insert },		/* 3 */
	{ ISFUNC, cli_insert },		/* 4 */
	{ ISFUNC, cli_insert },		/* 5 */
	{ ISFUNC, cli_insert },		/* 6 */
	{ ISFUNC, cli_insert },		/* 7 */
	{ ISFUNC, cli_insert },		/* 8 */
	{ ISFUNC, cli_insert },		/* 9 */
	
	/* A little more punctuation. */
	{ ISFUNC, cli_insert },		/* : */
	{ ISFUNC, cli_insert },		/* ; */
	{ ISFUNC, cli_insert },		/* < */
	{ ISFUNC, cli_insert },		/* = */
	{ ISFUNC, cli_insert },		/* > */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* @ */
	
	/* Uppercase alphabet. */
	{ ISFUNC, cli_insert },		/* A */
	{ ISFUNC, cli_insert },		/* B */
	{ ISFUNC, cli_insert },		/* C */
	{ ISFUNC, cli_insert },		/* D */
	{ ISFUNC, cli_insert },		/* E */
	{ ISFUNC, cli_insert },		/* F */
	{ ISFUNC, cli_insert },		/* G */
	{ ISFUNC, cli_insert },		/* H */
	{ ISFUNC, cli_insert },		/* I */
	{ ISFUNC, cli_insert },		/* J */
	{ ISFUNC, cli_insert },		/* K */
	{ ISFUNC, cli_insert },		/* L */
	{ ISFUNC, cli_insert },		/* M */
	{ ISFUNC, cli_insert },		/* N */
	{ ISFUNC, cli_insert },		/* O */
	{ ISFUNC, cli_insert },		/* P */
	{ ISFUNC, cli_insert },		/* Q */
	{ ISFUNC, cli_insert },		/* R */
	{ ISFUNC, cli_insert },		/* S */
	{ ISFUNC, cli_insert },		/* T */
	{ ISFUNC, cli_insert },		/* U */
	{ ISFUNC, cli_insert },		/* V */
	{ ISFUNC, cli_insert },		/* W */
	{ ISFUNC, cli_insert },		/* X */
	{ ISFUNC, cli_insert },		/* Y */
	{ ISFUNC, cli_insert },		/* Z */
	
	/* Some more punctuation. */
	{ ISFUNC, cli_insert },		/* [ */
	{ ISFUNC, cli_insert },		/* \ */
	{ ISFUNC, cli_insert },		/* ] */
	{ ISFUNC, cli_insert },		/* ^ */
	{ ISFUNC, cli_insert },		/* _ */
	{ ISFUNC, cli_insert },		/* ` */
	
	/* Lowercase alphabet. */
	{ ISFUNC, cli_insert },		/* a */
	{ ISFUNC, cli_insert },		/* b */
	{ ISFUNC, cli_insert },		/* c */
	{ ISFUNC, cli_insert },		/* d */
	{ ISFUNC, cli_insert },		/* e */
	{ ISFUNC, cli_insert },		/* f */
	{ ISFUNC, cli_insert },		/* g */
	{ ISFUNC, cli_insert },		/* h */
	{ ISFUNC, cli_insert },		/* i */
	{ ISFUNC, cli_insert },		/* j */
	{ ISFUNC, cli_insert },		/* k */
	{ ISFUNC, cli_insert },		/* l */
	{ ISFUNC, cli_insert },		/* m */
	{ ISFUNC, cli_insert },		/* n */
	{ ISFUNC, cli_insert },		/* o */
	{ ISFUNC, cli_insert },		/* p */
	{ ISFUNC, cli_insert },		/* q */
	{ ISFUNC, cli_insert },		/* r */
	{ ISFUNC, cli_insert },		/* s */
	{ ISFUNC, cli_insert },		/* t */
	{ ISFUNC, cli_insert },		/* u */
	{ ISFUNC, cli_insert },		/* v */
	{ ISFUNC, cli_insert },		/* w */
	{ ISFUNC, cli_insert },		/* x */
	{ ISFUNC, cli_insert },		/* y */
	{ ISFUNC, cli_insert },		/* z */
	
	/* Final punctuation. */
	{ ISFUNC, cli_insert },		/* { */
	{ ISFUNC, cli_insert },		/* | */
	{ ISFUNC, cli_insert },		/* } */
	{ ISFUNC, cli_insert },		/* ~ */
	{ ISFUNC, cli_rubout },		/* RUBOUT */
	
#if KEYMAP_SIZE > 128
	/* Pure 8-bit characters (128 - 159).
	 * These might be used in some
	 * character sets.
	 */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	{ ISFUNC, cli_insert },		/* ? */
	
	/* ISO Latin-1 characters (160 - 255) */
	{ ISFUNC, cli_insert },	/* No-break space */
	{ ISFUNC, cli_insert },	/* Inverted exclamation mark */
	{ ISFUNC, cli_insert },	/* Cent sign */
	{ ISFUNC, cli_insert },	/* Pound sign */
	{ ISFUNC, cli_insert },	/* Currency sign */
	{ ISFUNC, cli_insert },	/* Yen sign */
	{ ISFUNC, cli_insert },	/* Broken bar */
	{ ISFUNC, cli_insert },	/* Section sign */
	{ ISFUNC, cli_insert },	/* Diaeresis */
	{ ISFUNC, cli_insert },	/* Copyright sign */
	{ ISFUNC, cli_insert },	/* Feminine ordinal indicator */
	{ ISFUNC, cli_insert },	/* Left pointing double angle quotation mark */
	{ ISFUNC, cli_insert },	/* Not sign */
	{ ISFUNC, cli_insert },	/* Soft hyphen */
	{ ISFUNC, cli_insert },	/* Registered sign */
	{ ISFUNC, cli_insert },	/* Macron */
	{ ISFUNC, cli_insert },	/* Degree sign */
	{ ISFUNC, cli_insert },	/* Plus-minus sign */
	{ ISFUNC, cli_insert },	/* Superscript two */
	{ ISFUNC, cli_insert },	/* Superscript three */
	{ ISFUNC, cli_insert },	/* Acute accent */
	{ ISFUNC, cli_insert },	/* Micro sign */
	{ ISFUNC, cli_insert },	/* Pilcrow sign */
	{ ISFUNC, cli_insert },	/* Middle dot */
	{ ISFUNC, cli_insert },	/* Cedilla */
	{ ISFUNC, cli_insert },	/* Superscript one */
	{ ISFUNC, cli_insert },	/* Masculine ordinal indicator */
	{ ISFUNC, cli_insert },	/* Right pointing double angle quotation mark */
	{ ISFUNC, cli_insert },	/* Vulgar fraction one quarter */
	{ ISFUNC, cli_insert },	/* Vulgar fraction one half */
	{ ISFUNC, cli_insert },	/* Vulgar fraction three quarters */
	{ ISFUNC, cli_insert },	/* Inverted questionk mark */
	{ ISFUNC, cli_insert },	/* Latin capital letter a with grave */
	{ ISFUNC, cli_insert },	/* Latin capital letter a with acute */
	{ ISFUNC, cli_insert },	/* Latin capital letter a with circumflex */
	{ ISFUNC, cli_insert },	/* Latin capital letter a with tilde */
	{ ISFUNC, cli_insert },	/* Latin capital letter a with diaeresis */
	{ ISFUNC, cli_insert },	/* Latin capital letter a with ring above */
	{ ISFUNC, cli_insert },	/* Latin capital letter ae */
	{ ISFUNC, cli_insert },	/* Latin capital letter c with cedilla */
	{ ISFUNC, cli_insert },	/* Latin capital letter e with grave */
	{ ISFUNC, cli_insert },	/* Latin capital letter e with acute */
	{ ISFUNC, cli_insert },	/* Latin capital letter e with circumflex */
	{ ISFUNC, cli_insert },	/* Latin capital letter e with diaeresis */
	{ ISFUNC, cli_insert },	/* Latin capital letter i with grave */
	{ ISFUNC, cli_insert },	/* Latin capital letter i with acute */
	{ ISFUNC, cli_insert },	/* Latin capital letter i with circumflex */
	{ ISFUNC, cli_insert },	/* Latin capital letter i with diaeresis */
	{ ISFUNC, cli_insert },	/* Latin capital letter eth (Icelandic) */
	{ ISFUNC, cli_insert },	/* Latin capital letter n with tilde */
	{ ISFUNC, cli_insert },	/* Latin capital letter o with grave */
	{ ISFUNC, cli_insert },	/* Latin capital letter o with acute */
	{ ISFUNC, cli_insert },	/* Latin capital letter o with circumflex */
	{ ISFUNC, cli_insert },	/* Latin capital letter o with tilde */
	{ ISFUNC, cli_insert },	/* Latin capital letter o with diaeresis */
	{ ISFUNC, cli_insert },	/* Multiplication sign */
	{ ISFUNC, cli_insert },	/* Latin capital letter o with stroke */
	{ ISFUNC, cli_insert },	/* Latin capital letter u with grave */
	{ ISFUNC, cli_insert },	/* Latin capital letter u with acute */
	{ ISFUNC, cli_insert },	/* Latin capital letter u with circumflex */
	{ ISFUNC, cli_insert },	/* Latin capital letter u with diaeresis */
	{ ISFUNC, cli_insert },	/* Latin capital letter Y with acute */
	{ ISFUNC, cli_insert },	/* Latin capital letter thorn (Icelandic) */
	{ ISFUNC, cli_insert },	/* Latin small letter sharp s (German) */
	{ ISFUNC, cli_insert },	/* Latin small letter a with grave */
	{ ISFUNC, cli_insert },	/* Latin small letter a with acute */
	{ ISFUNC, cli_insert },	/* Latin small letter a with circumflex */
	{ ISFUNC, cli_insert },	/* Latin small letter a with tilde */
	{ ISFUNC, cli_insert },	/* Latin small letter a with diaeresis */
	{ ISFUNC, cli_insert },	/* Latin small letter a with ring above */
	{ ISFUNC, cli_insert },	/* Latin small letter ae */
	{ ISFUNC, cli_insert },	/* Latin small letter c with cedilla */
	{ ISFUNC, cli_insert },	/* Latin small letter e with grave */
	{ ISFUNC, cli_insert },	/* Latin small letter e with acute */
	{ ISFUNC, cli_insert },	/* Latin small letter e with circumflex */
	{ ISFUNC, cli_insert },	/* Latin small letter e with diaeresis */
	{ ISFUNC, cli_insert },	/* Latin small letter i with grave */
	{ ISFUNC, cli_insert },	/* Latin small letter i with acute */
	{ ISFUNC, cli_insert },	/* Latin small letter i with circumflex */
	{ ISFUNC, cli_insert },	/* Latin small letter i with diaeresis */
	{ ISFUNC, cli_insert },	/* Latin small letter eth (Icelandic) */
	{ ISFUNC, cli_insert },	/* Latin small letter n with tilde */
	{ ISFUNC, cli_insert },	/* Latin small letter o with grave */
	{ ISFUNC, cli_insert },	/* Latin small letter o with acute */
	{ ISFUNC, cli_insert },	/* Latin small letter o with circumflex */
	{ ISFUNC, cli_insert },	/* Latin small letter o with tilde */
	{ ISFUNC, cli_insert },	/* Latin small letter o with diaeresis */
	{ ISFUNC, cli_insert },	/* Division sign */
	{ ISFUNC, cli_insert },	/* Latin small letter o with stroke */
	{ ISFUNC, cli_insert },	/* Latin small letter u with grave */
	{ ISFUNC, cli_insert },	/* Latin small letter u with acute */
	{ ISFUNC, cli_insert },	/* Latin small letter u with circumflex */
	{ ISFUNC, cli_insert },	/* Latin small letter u with diaeresis */
	{ ISFUNC, cli_insert },	/* Latin small letter y with acute */
	{ ISFUNC, cli_insert },	/* Latin small letter thorn (Icelandic) */
	{ ISFUNC, cli_insert }		/* Latin small letter y with diaeresis */
#endif /* KEYMAP_SIZE > 128 */
};
