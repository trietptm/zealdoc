#include "cli_priv.h"

static void update_line(cli_session_t *, char *, char *, int, int, int, int);
static void space_to_eol(cli_session_t *, int);
static void delete_chars(cli_session_t *, int);
static void insert_some_chars(cli_session_t *, char *, int, int);
static void cr(cli_session_t *);

#define _rl_col_width(l, s, e)	(((e) <= (s)) ? 0 : (e) - (s))

/* Heuristic used to decide whether it is faster to move from CUR to NEW
   by backing up or outputting a carriage return and moving forward.  CUR
   and NEW are either both buffer positions or absolute screen positions. */
#define CR_FASTER(new, cur) (((new) + 1) < ((cur) - (new)))

/* _rl_last_c_pos is an absolute cursor position in multibyte locales and a
   buffer index in others.  This macro is used when deciding whether the
   current cursor position is in the middle of a prompt string containing
   invisible characters. */
#define PROMPT_ENDING_INDEX	prompt_last_invisible+1
  

/* (PWP) Well... Good for a simple line updater, but totally ignores
   the problems of input lines longer than the screen width.

   update_line and the code that calls it makes a multiple line,
   automatically wrapping line update.  Careful attention needs
   to be paid to the vertical position variables. */

/* Keep two buffers; one which reflects the current contents of the
   screen, and the other to draw what we think the new contents should
   be.  Then compare the buffers, and make whatever changes to the
   screen itself that we should.  Finally, make the buffer that we
   just drew into be the one which reflects the current contents of the
   screen, and place the cursor where it belongs.

   Commands that want to can fix the display themselves, and then let
   this function know that the display has been fixed by setting the
   RL_DISPLAY_FIXED variable.  This is good for efficiency. */

/* Global variables declared here. */
/* What YOU turn on when you have handled all redisplay yourself. */
int rl_display_fixed = 0;

/* The stuff that gets printed out before the actual text of the line.
   This is usually pointing to sess->prompt. */
const char *rl_display_prompt = (char *)NULL;

/* Pseudo-global variables declared here. */

/* The visible cursor position.  If you print some text, adjust this. */
/* NOTE: _rl_last_c_pos is used as a buffer index when not in a locale
   supporting multibyte characters, and an absolute cursor position when
   in such a locale.  This is an artifact of the donated multibyte support.
   Care must be taken when modifying its value. */
int _rl_last_c_pos = 0;
int _rl_last_v_pos = 0;

static int cpos_buffer_position;

/* Number of lines currently on screen minus 1. */
int _rl_vis_botlin = 0;

/* Variables used only in this file. */
/* The last left edge of text that was displayed.  This is used when
   doing horizontal scrolling.  It shifts in thirds of a screenwidth. */
static int last_lmargin;

/* The line display buffers.  One is the line currently displayed on
   the screen.  The other is the line about to be displayed. */
static char *visible_line = (char *)NULL;
static char *invisible_line = (char *)NULL;

/* A buffer for `modeline' messages. */
static char msg_buf[128];

/* Non-zero forces the redisplay even if we thought it was unnecessary. */
static int forced_display;

/* Default and initial buffer size.  Can grow. */
static int line_size = 1024;

/* Variables to keep track of the expanded prompt string, which may
   include invisible characters. */

static char *local_prompt, *local_prompt_prefix;
static int local_prompt_len;
static int prompt_visible_length, prompt_prefix_length;

/* The number of invisible characters in the line currently being
   displayed on the screen. */
static int visible_wrap_offset;

/* The number of invisible characters in the prompt string.  Static so it
   can be shared between rl_redisplay and update_line */
static int wrap_offset;

/* The index of the last invisible character in the prompt string. */
static int prompt_last_invisible;

/* The length (buffer offset) of the first line of the last (possibly
   multi-line) buffer displayed on the screen. */
static int visible_first_line_len;

/* Number of invisible characters on the first physical line of the prompt.
   Only valid when the number of physical characters in the prompt exceeds
   (or is equal to) sess->term.screenwidth. */
static int prompt_invis_chars_first_line;

static int prompt_last_screen_line;

static int prompt_physical_chars;

/* Variables to save and restore prompt and display information. */

/* These are getting numerous enough that it's time to create a struct. */

static char *saved_local_prompt;
static char *saved_local_prefix;
static int saved_last_invisible;
static int saved_visible_length;
static int saved_prefix_length;
static int saved_local_length;
static int saved_invis_chars_first_line;
static int saved_physical_chars;

/* Expand the prompt string S and return the number of visible
   characters in *LP, if LP is not null.  This is currently more-or-less
   a placeholder for expansion.  LIP, if non-null is a place to store the
   index of the last invisible character in the returned string. NIFLP,
   if non-zero, is a place to store the number of invisible characters in
   the first prompt line.  The previous are used as byte counts -- indexes
   into a character buffer. */

/* Current implementation:
	\001 (^A) start non-visible characters
	\002 (^B) end non-visible characters
   all characters except \001 and \002 (following a \001) are copied to
   the returned string; all characters except those between \001 and
   \002 are assumed to be `visible'. */	

static char *expand_prompt(cli_session_t *sess, char *pmt, int *lp,
			   int *lip, int *niflp, int *vlp)
{
	char *r, *ret, *p, *igstart;
	int l, rl, last, ignoring, ninvis, invfl, invflset, physchars;
	
	/* Short-circuit if we can. */
	if (strchr(pmt, RL_PROMPT_START_IGNORE) == 0) {
		r = savestring(pmt);
		if (lp)
			*lp = strlen(r);
		if (lip)
			*lip = 0;
		if (niflp)
			*niflp = 0;
		if (vlp)
			*vlp = lp ? *lp : strlen(r);
		return r;
	}
	
	l = strlen(pmt);
	r = ret = (char *)xmalloc(l + 1);
	
	invfl = 0;	/* invisible chars in first line of prompt */
	invflset = 0;	/* we only want to set invfl once */
	
	igstart = 0;
	for (rl = ignoring = last = ninvis = physchars = 0, p = pmt; p && *p; p++) {
		/* This code strips the invisible character string markers
		   RL_PROMPT_START_IGNORE and RL_PROMPT_END_IGNORE */
		if (ignoring == 0 && *p == RL_PROMPT_START_IGNORE) {		/* XXX - check ignoring? */
			ignoring = 1;
			igstart = p;
			continue;
		} else if (ignoring && *p == RL_PROMPT_END_IGNORE) {
			ignoring = 0;
			if (p != (igstart + 1))
				last = r - ret - 1;
			continue;
		} else {
			*r++ = *p;
			if (!ignoring) {
				rl++;			/* visible length byte counter */
				physchars++;
			} else
				ninvis++;		/* invisible chars byte counter */
			
			if (invflset == 0 && rl >= sess->term.screenwidth) {
				invfl = ninvis;
				invflset = 1;
			}
		}
	}
	
	if (rl < sess->term.screenwidth)
		invfl = ninvis;
	
	*r = '\0';
	if (lp)
		*lp = rl;
	if (lip)
		*lip = last;
	if (niflp)
		*niflp = invfl;
	if  (vlp)
		*vlp = physchars;
	return ret;
}

/* Just strip out RL_PROMPT_START_IGNORE and RL_PROMPT_END_IGNORE from
   PMT and return the rest of PMT. */
char *_rl_strip_prompt(cli_session_t *sess, char *pmt)
{
	char *ret;
	
	ret = expand_prompt(sess, pmt, (int *)NULL, (int *)NULL,
			    (int *)NULL, (int *)NULL);
	return ret;
}

/*
 * Expand the prompt string into the various display components, if
 * necessary.
 *
 * local_prompt = expanded last line of string in rl_display_prompt
 *		  (portion after the final newline)
 * local_prompt_prefix = portion before last newline of rl_display_prompt,
 *			 expanded via expand_prompt
 * prompt_visible_length = number of visible characters in local_prompt
 * prompt_prefix_length = number of visible characters in local_prompt_prefix
 *
 * This function is called once per call to readline().  It may also be
 * called arbitrarily to expand the primary prompt.
 *
 * The return value is the number of visible characters on the last line
 * of the (possibly multi-line) prompt.
 */
int rl_expand_prompt(cli_session_t *sess, char *prompt)
{
	char *p, *t;
	int c;
	
	/* Clear out any saved values. */
	xfree(local_prompt);
	xfree(local_prompt_prefix);
	
	local_prompt = local_prompt_prefix = (char *)0;
	local_prompt_len = 0;
	prompt_last_invisible = prompt_invis_chars_first_line = 0;
	prompt_visible_length = prompt_physical_chars = 0;
	
	if (prompt == 0 || *prompt == 0)
		return (0);
	
	p = strrchr(prompt, '\n');
	if (!p) {
		/* The prompt is only one logical line, though it might wrap. */
		local_prompt = expand_prompt(sess,
					     prompt,
					     &prompt_visible_length,
					     &prompt_last_invisible,
					     &prompt_invis_chars_first_line,
					     &prompt_physical_chars);
		local_prompt_prefix = (char *)0;
		local_prompt_len = local_prompt ? strlen (local_prompt) : 0;
		return (prompt_visible_length);
	} else {
		/* The prompt spans multiple lines. */
		t = ++p;
		local_prompt = expand_prompt(sess, p,
					     &prompt_visible_length,
					     &prompt_last_invisible,
					     (int *)NULL,
					     &prompt_physical_chars);
		c = *t; *t = '\0';
		/* The portion of the prompt string up to and including the
		final newline is now null-terminated. */
		local_prompt_prefix = expand_prompt(sess, prompt,
						    &prompt_prefix_length,
						    (int *)NULL,
						    &prompt_invis_chars_first_line,
						    (int *)NULL);
		*t = c;
		local_prompt_len = local_prompt ? strlen(local_prompt) : 0;
		return (prompt_prefix_length);
	}
}

/* Initialize the VISIBLE_LINE and INVISIBLE_LINE arrays, and their associated
   arrays of line break markers.  MINSIZE is the minimum size of VISIBLE_LINE
   and INVISIBLE_LINE; if it is greater than LINE_SIZE, LINE_SIZE is
   increased.  If the lines have already been allocated, this ensures that
   they can hold at least MINSIZE characters. */
static void init_line_structures(cli_session_t *sess, int minsize)
{
	register int n;
	
	if (invisible_line == 0) {	/* initialize it */
		if (line_size < minsize)
			line_size = minsize;
		visible_line = (char *)xmalloc(line_size);
		invisible_line = (char *)xmalloc(line_size);
	} else if (line_size < minsize) {	/* ensure it can hold MINSIZE chars */
		line_size *= 2;
		if (line_size < minsize)
			line_size = minsize;
		visible_line = (char *)xrealloc(visible_line, line_size);
		invisible_line = (char *)xrealloc(invisible_line, line_size);
	}
	
	for (n = minsize; n < line_size; n++) {
		visible_line[n] = 0;
		invisible_line[n] = 1;
	}
	
	if (sess->vis_lbreaks == 0) {
		/* should be enough. */
		sess->inv_lbsize = sess->vis_lbsize = 256;
		sess->inv_lbreaks = (int *)xmalloc(sess->inv_lbsize * sizeof (int));
		sess->vis_lbreaks = (int *)xmalloc(sess->vis_lbsize * sizeof (int));
		sess->inv_lbreaks[0] = sess->vis_lbreaks[0] = 0;
	}
}
  
/* Basic redisplay algorithm. */
void rl_redisplay(cli_session_t *sess)
{
	register int in, out, c, linenum, cursor_linenum;
	register char *line;
	int inv_botlin, lb_botlin, lb_linenum, o_cpos;
	int newlines, lpos, temp, modmark;
	const char *prompt_this_line;
	
	if (!sess->echoing_p)
		return;
	
	if (!rl_display_prompt)
		rl_display_prompt = "";
	
	if (invisible_line == 0 || sess->vis_lbreaks == 0) {
		init_line_structures(sess, 0);
		rl_on_new_line(sess);
	}

	/* Draw the line into the buffer. */
	cpos_buffer_position = -1;
	
	line = invisible_line;
	out = inv_botlin = 0;
	
	/* Mark the line as modified or not.  We only do this for history
	   lines. */
	modmark = 0;
#ifdef CONFIG_CLI_HISTORY
	if (cli_main_config.mark_modified_lines &&
	    current_history() && sess->undo_list) {
		line[out++] = '*';
		line[out] = '\0';
		modmark = 1;
	}
#endif

	/* If someone thought that the redisplay was handled, but the currently
	   visible line has a different modification state than the one about
	   to become visible, then correct the caller's misconception. */
	if (visible_line[0] != invisible_line[0])
		rl_display_fixed = 0;
	
	/* If the prompt to be displayed is the `primary' readline prompt (the
	   one passed to readline()), use the values we have already expanded.
	   If not, use what's already in rl_display_prompt.  WRAP_OFFSET is the
	   number of non-visible characters in the prompt string. */
	if (rl_display_prompt == sess->the_prompt || local_prompt) {
		if (local_prompt_prefix && forced_display)
			cli_write(sess, local_prompt_prefix,
				  strlen(local_prompt_prefix));
		
		if (local_prompt_len > 0) {
			temp = local_prompt_len + out + 2;
			if (temp >= line_size) {
				line_size = (temp + 1024) - (temp % 1024);
				visible_line = (char *)xrealloc(visible_line, line_size);
				line = invisible_line = (char *)xrealloc(invisible_line, line_size);
			}
			strncpy(line + out, local_prompt, local_prompt_len);
			out += local_prompt_len;
		}
		line[out] = '\0';
		wrap_offset = local_prompt_len - prompt_visible_length;
	} else {
		int pmtlen;
		prompt_this_line = strrchr(rl_display_prompt, '\n');
		if (!prompt_this_line)
			prompt_this_line = rl_display_prompt;
		else {
			prompt_this_line++;
			pmtlen = prompt_this_line - rl_display_prompt;	/* temp var */
			if (forced_display) {
				cli_write(sess, rl_display_prompt, pmtlen);
				/* Make sure we are at column zero even after a newline,
				   regardless of the state of terminal output processing. */
				if (pmtlen < 2 || prompt_this_line[-2] != '\r')
					cr(sess);
			}
		}

		prompt_physical_chars = pmtlen = strlen(prompt_this_line);
		temp = pmtlen + out + 2;
		if (temp >= line_size) {
			line_size = (temp + 1024) - (temp % 1024);
			visible_line = (char *)xrealloc(visible_line, line_size);
			line = invisible_line = (char *)xrealloc(invisible_line, line_size);
		}
		strncpy(line + out,  prompt_this_line, pmtlen);
		out += pmtlen;
		line[out] = '\0';
		wrap_offset = prompt_invis_chars_first_line = 0;
	}

#define CHECK_INV_LBREAKS()								\
	do {										\
		if (newlines >= (sess->inv_lbsize - 2)) {					\
			sess->inv_lbsize *= 2;						\
			sess->inv_lbreaks = (int *)xrealloc(sess->inv_lbreaks,			\
					sess->inv_lbsize * sizeof(int));			\
		}									\
	} while (0)

#define CHECK_LPOS(sess)									\
	do {										\
		lpos++;									\
		if (lpos >= sess->term.screenwidth) {						\
			if (newlines >= (sess->inv_lbsize - 2)) {				\
				sess->inv_lbsize *= 2;					\
				sess->inv_lbreaks = (int *)xrealloc(				\
					sess->inv_lbreaks, sess->inv_lbsize * sizeof(int));		\
			}								\
			sess->inv_lbreaks[++newlines] = out;					\
			lpos = 0;							\
		}									\
	} while (0)

	/* sess->inv_lbreaks[i] is where line i starts in the buffer. */
	sess->inv_lbreaks[newlines = 0] = 0;
	lpos = prompt_physical_chars + modmark;
	
	
	/* prompt_invis_chars_first_line is the number of invisible characters in
	   the first physical line of the prompt.
	   wrap_offset - prompt_invis_chars_first_line is the number of invis
	   chars on the second line. */
	
	/* what if lpos is already >= sess->term.screenwidth before we start drawing the
	   contents of the command line? */
	while (lpos >= sess->term.screenwidth) {
		temp = ((newlines + 1) * sess->term.screenwidth);
		
		/* Now account for invisible characters in the current line. */
		temp += ((local_prompt_prefix == 0) ? ((newlines == 0) ? prompt_invis_chars_first_line
			: ((newlines == 1) ? wrap_offset : 0))
			: ((newlines == 0) ? wrap_offset :0));
		
		sess->inv_lbreaks[++newlines] = temp;
		lpos -= sess->term.screenwidth;
	}

	prompt_last_screen_line = newlines;
	
	/* Draw the rest of the line (after the prompt) into invisible_line, keeping
	   track of where the cursor is (cpos_buffer_position), the number of the line containing
	   the cursor (lb_linenum), the last line number (lb_botlin and inv_botlin).
	   It maintains an array of line breaks for display (sess->inv_lbreaks).
	   This handles expanding tabs for display and displaying meta characters. */
	lb_linenum = 0;
	for (in = 0; in < sess->end; in++) {
		c = (unsigned char)sess->line_buffer[in];

		if (out + 8 >= line_size) {		/* XXX - 8 for \t */
			line_size *= 2;
			visible_line = (char *)xrealloc(visible_line, line_size);
			invisible_line = (char *)xrealloc(invisible_line, line_size);
			line = invisible_line;
		}
		
		if (in == sess->point) {
			cpos_buffer_position = out;
			lb_linenum = newlines;
		}

		if (META_CHAR(c)) {
			if (sess->output_meta_chars == 0) {
				sprintf(line + out, "\\%o", c);
				
				if (lpos + 4 >= sess->term.screenwidth) {
					temp = sess->term.screenwidth - lpos;
					CHECK_INV_LBREAKS();
					sess->inv_lbreaks[++newlines] = out + temp;
					lpos = 4 - temp;
				} else {
					lpos += 4;
				}
				out += 4;
			} else {
				line[out++] = c;
				CHECK_LPOS(sess);
			}
		}
#ifdef CONFIG_CLI_DISPLAY_TABS
		else if (c == '\t') {
			register int newout;

			newout = out + 8 - lpos % 8;
			temp = newout - out;
			if (lpos + temp >= sess->term.screenwidth) {
				register int temp2;
				temp2 = sess->term.screenwidth - lpos;
				CHECK_INV_LBREAKS();
				sess->inv_lbreaks[++newlines] = out + temp2;
				lpos = temp - temp2;
				while (out < newout)
					line[out++] = ' ';
			} else {
				while(out < newout)
					line[out++] = ' ';
				lpos += temp;
			}
		}
#endif
		else if (CTRL_CHAR(c) || c == RUBOUT) {
			line[out++] = '^';
			CHECK_LPOS(sess);
			line[out++] = CTRL_CHAR(c) ? UNCTRL(c) : '?';
			CHECK_LPOS(sess);
		} else {
			line[out++] = c;
			CHECK_LPOS(sess);
		}
	}
	line[out] = '\0';
	if (cpos_buffer_position < 0) {
		cpos_buffer_position = out;
		lb_linenum = newlines;
	}
	
	inv_botlin = lb_botlin = newlines;
	CHECK_INV_LBREAKS();
	sess->inv_lbreaks[newlines+1] = out;
	cursor_linenum = lb_linenum;

	if (sess->term.up && *sess->term.up) {
		int nleft, pos, changed_screen_line, tx;
		
		if (!rl_display_fixed || forced_display) {
			forced_display = 0;
			
			/* If we have more than a screenful of material to
			 * display, then only display a screenful.  We
			 * should display the last screen, not the first.
			 */
			if (out >= sess->term.screenchars) {
				out = sess->term.screenchars - 1;
			}
			
			/* The first line is at character position 0 in
			 * the buffer.  The second and subsequent lines
			 * start at sess->inv_lbreaks[N], offset by OFFSET
			 * (which has already been calculated above).
			 */
#define W_OFFSET(line, offset) ((line) == 0 ? offset : 0)
#define VIS_LLEN(l)	((l) > _rl_vis_botlin ? 0 : (sess->vis_lbreaks[l+1] - sess->vis_lbreaks[l]))
#define INV_LLEN(l)	(sess->inv_lbreaks[l+1] - sess->inv_lbreaks[l])
#define VIS_CHARS(line) (visible_line + sess->vis_lbreaks[line])
#define VIS_LINE(line) ((line) > _rl_vis_botlin) ? "" : VIS_CHARS(line)
#define INV_LINE(line) (invisible_line + sess->inv_lbreaks[line])

			/* For each line in the buffer, do the updating
			 * display.
			 */
			for (linenum = 0; linenum <= inv_botlin; linenum++) {
				/* This can lead us astray if we execute a
				 * program that changes the locale from a
				 * non-multibyte to a multibyte one.
				 */
				o_cpos = _rl_last_c_pos;
				update_line(sess, (char *)(VIS_LINE(linenum)),
					    INV_LINE(linenum), linenum,
					    VIS_LLEN(linenum), INV_LLEN(linenum),
					    inv_botlin);
				
				if (linenum == 0 &&
					inv_botlin == 0 && _rl_last_c_pos == out &&
					(wrap_offset > visible_wrap_offset) &&
					(_rl_last_c_pos < visible_first_line_len)) {
					nleft = sess->term.screenwidth + wrap_offset - _rl_last_c_pos;
					if (nleft)
						_rl_clear_to_eol(sess, nleft);
				}
				
				/* Since the new first line is now
				 * visible, save its length.
				 */
				if (linenum == 0)
					visible_first_line_len = (inv_botlin > 0) ? sess->inv_lbreaks[1] : out - wrap_offset;
			}

			/* We may have deleted some lines.  If so, clear
			 * the left over blank ones at the bottom out.
			 */
			if (_rl_vis_botlin > inv_botlin) {
				char *tt;
				for (; linenum <= _rl_vis_botlin; linenum++) {
					tt = VIS_CHARS(linenum);
					_rl_move_vert(sess, linenum);
					_rl_move_cursor_relative(sess, 0, tt);
					_rl_clear_to_eol(sess,
							 (linenum == _rl_vis_botlin) ? \
							 strlen(tt) : \
							 sess->term.screenwidth);
				}
			}
			_rl_vis_botlin = inv_botlin;
			
			/* CHANGED_SCREEN_LINE is set to 1 if we have
			 * moved to a different screen line during this
			 * redisplay.
			 */
			changed_screen_line = _rl_last_v_pos != cursor_linenum;
			if (changed_screen_line) {
				_rl_move_vert(sess, cursor_linenum);
				if (cursor_linenum == 0 && wrap_offset)
					_rl_last_c_pos += wrap_offset;
			}

			nleft = prompt_visible_length + wrap_offset;
			if (cursor_linenum == 0 && wrap_offset > 0 && _rl_last_c_pos > 0 &&
				_rl_last_c_pos < PROMPT_ENDING_INDEX && local_prompt) {
				if (sess->term.cr)
					cli_write(sess, sess->term.cr, 1);
				cli_write(sess, local_prompt, nleft);
				_rl_last_c_pos = nleft;
			}

			/* Where on that line?  And where does that line start
			in the buffer? */
			pos = sess->inv_lbreaks[cursor_linenum];
			/* nleft == number of characters in the line buffer between the
			   start of the line and the desired cursor position. */
			nleft = cpos_buffer_position - pos;
			
			if (wrap_offset && cursor_linenum == 0 && nleft < _rl_last_c_pos) {
				/* TX == new physical cursor position in multibyte locale. */
				tx = nleft;
				if (_rl_last_c_pos > tx) {
					cli_backspace(sess, _rl_last_c_pos - tx);	/* XXX */
					_rl_last_c_pos = tx;
				}
			}

			_rl_move_cursor_relative(sess, nleft, &invisible_line[pos]);
		}
	} else {
		/* Do horizontal scrolling. */
#define M_OFFSET(margin, offset) ((margin) == 0 ? offset : 0)
		int lmargin, ndisp, nleft, phys_c_pos, t;
		
		/* Always at top line. */
		_rl_last_v_pos = 0;
		
		ndisp = cpos_buffer_position - wrap_offset;
		nleft  = prompt_visible_length + wrap_offset;
		/* Where the new cursor position will be on the screen.  This can be
		   longer than SCREENWIDTH; if it is, lmargin will be adjusted. */
		phys_c_pos = cpos_buffer_position - (last_lmargin ? last_lmargin : wrap_offset);
		t = sess->term.screenwidth / 3;
		
		if (phys_c_pos > sess->term.screenwidth - 2) {
			lmargin = cpos_buffer_position - (2 * t);
			if (lmargin < 0)
				lmargin = 0;
			if (wrap_offset && lmargin > 0 && lmargin < nleft)
				lmargin = nleft;
		} else if (ndisp < sess->term.screenwidth - 2){
			/* XXX - was -1 */
			lmargin = 0;
		} else if (phys_c_pos < 1) {
			lmargin = ((cpos_buffer_position - 1) / t) * t;	/* XXX */
			if (wrap_offset && lmargin > 0 && lmargin < nleft)
				lmargin = nleft;
		} else
			lmargin = last_lmargin;

		/* If the first character on the screen isn't the first character
		   in the display line, indicate this with a special character. */
		if (lmargin > 0)
			line[lmargin] = '<';

		t = lmargin + M_OFFSET(lmargin, wrap_offset) + sess->term.screenwidth;
		if (t < out)
			line[t - 1] = '>';

		if (!rl_display_fixed || forced_display || lmargin != last_lmargin) {
			forced_display = 0;
			update_line(sess, &visible_line[last_lmargin],
				    &invisible_line[lmargin],
				    0, sess->term.screenwidth + visible_wrap_offset,
				    sess->term.screenwidth + (lmargin ? 0 : wrap_offset),
				    0);
			
			t = _rl_last_c_pos - M_OFFSET(lmargin, wrap_offset);
			if ((M_OFFSET (lmargin, wrap_offset) > visible_wrap_offset) &&
				(_rl_last_c_pos == out) &&
				t < visible_first_line_len) {
				nleft = sess->term.screenwidth - t;
				_rl_clear_to_eol(sess, nleft);
			}
			visible_first_line_len = out - lmargin - M_OFFSET(lmargin, wrap_offset);
			if (visible_first_line_len > sess->term.screenwidth)
				visible_first_line_len = sess->term.screenwidth;
			
			_rl_move_cursor_relative(sess, cpos_buffer_position - lmargin,
						 &invisible_line[lmargin]);
			last_lmargin = lmargin;
		}
	}
	cli_flush(sess);

	/* Swap visible and non-visible lines. */
	{
		char *vtemp = visible_line;
		int *itemp = sess->vis_lbreaks, ntemp = sess->vis_lbsize;
		
		visible_line = invisible_line;
		invisible_line = vtemp;
		
		sess->vis_lbreaks = sess->inv_lbreaks;
		sess->inv_lbreaks = itemp;
		
		sess->vis_lbsize = sess->inv_lbsize;
		sess->inv_lbsize = ntemp;
		
		rl_display_fixed = 0;
		/* If we are displaying on a single line, and last_lmargin
		 * is > 0, we are not displaying any invisible characters,
		 * so set visible_wrap_offset to 0.
		 */
		visible_wrap_offset = wrap_offset;
	}
}

/* PWP: update_line() is based on finding the middle difference of each
   line on the screen; vis:

			     /old first difference
	/beginning of line   |	      /old last same       /old EOL
	v		     v	      v		    v
old:	eddie> Oh, my little gruntle-buggy is to me, as lurgid as
new:	eddie> Oh, my little buggy says to me, as lurgid as
	^		     ^	^			   ^
	\beginning of line   |	\new last same	   \new end of line
			     \new first difference

   All are character pointers for the sake of speed.  Special cases for
   no differences, as well as for end of line additions must be handled.

   Could be made even smarter, but this works well enough */
static void update_line(cli_session_t *sess, register char *old,
			register char *new, int current_line, int omax,
			int nmax, int inv_botlin)
{
	register char *ofd, *ols, *oe, *nfd, *nls, *ne;
	int temp, lendiff, wsatend, od, nd;
	int current_invis_chars;
	int col_lendiff, col_temp;

	temp = _rl_last_c_pos - W_OFFSET(_rl_last_v_pos, visible_wrap_offset);
	if (temp == sess->term.screenwidth && sess->term.autowrap &&
	    _rl_last_v_pos == current_line - 1) {
		if (new[0])
			cli_write(sess, new, 1);
		else
			cli_write(sess, " ", 1);
		_rl_last_c_pos = 1;
		_rl_last_v_pos++;
		if (old[0] && new[0])
			old[0] = new[0];
	}
	
      
	/* Find first difference. */
	for (ofd = old, nfd = new; (ofd - old < omax) && *ofd && (*ofd == *nfd);
		ofd++, nfd++);

	for (od = ofd - old, oe = ofd; od < omax && *oe; oe++, od++);
	for (nd = nfd - new, ne = nfd; nd < nmax && *ne; ne++, nd++);
	
	/* If no difference, continue to next line. */
	if (ofd == oe && nfd == ne)
		return;

	wsatend = 1;			/* flag for trailing whitespace */
	
	ols = oe - 1;			/* find last same */
	nls = ne - 1;
	while ((ols > ofd) && (nls > nfd) && (*ols == *nls)) {
		if (*ols != ' ')
			wsatend = 0;
		ols--;
		nls--;
	}

	if (wsatend) {
		ols = oe;
		nls = ne;
	} else if (*ols != *nls) {
		if (*ols) ols++;
		if (*nls) nls++;
	}

	/* count of invisible characters in the current invisible line. */
	current_invis_chars = W_OFFSET(current_line, wrap_offset);
	if (_rl_last_v_pos != current_line) {
		_rl_move_vert(sess, current_line);
		if (current_line == 0 && visible_wrap_offset)
			_rl_last_c_pos += visible_wrap_offset;
	}


	lendiff = local_prompt_len;
	od = ofd - old;	/* index of first difference in visible line */
	if (current_line == 0 && sess->term.cr &&
	    lendiff > prompt_visible_length && _rl_last_c_pos > 0 &&
	    od >= lendiff && _rl_last_c_pos < PROMPT_ENDING_INDEX) {
		if (sess->term.cr)
			cli_write(sess, sess->term.cr, 1);
		cli_write(sess, local_prompt, lendiff);
		_rl_last_c_pos = lendiff;
	}

	/* When this function returns, _rl_last_c_pos is correct, and an absolute
	   cursor postion in multibyte mode, but a buffer index when not in a
	   multibyte locale. */
	_rl_move_cursor_relative(sess, od, old);
	
	lendiff = (nls - nfd) - (ols - ofd);
	col_lendiff = lendiff;
	
	if (current_line == 0 && current_invis_chars != visible_wrap_offset) {
		lendiff += visible_wrap_offset - current_invis_chars;
		col_lendiff = lendiff;
	}

	/* Insert (diff (len (old), len (new)) ch. */
	temp = ne - nfd;
	col_temp = temp;

	if (col_lendiff > 0) {	/* XXX - was lendiff */
		/* Non-zero if we're increasing the number of lines. */
		int gl = current_line >= _rl_vis_botlin && inv_botlin > _rl_vis_botlin;
		if (sess->term.can_insert &&
		    ((2 * col_temp) >= col_lendiff || sess->term.IC) 
			&& (!sess->term.autowrap || !gl)) {
			if (*ols &&
			    (_rl_last_c_pos > 0 ||
			     lendiff <= prompt_visible_length ||
			     !current_invis_chars)) {
				insert_some_chars(sess, nfd, lendiff, col_lendiff);
				_rl_last_c_pos += col_lendiff;
			} else if (*ols == 0 && lendiff > 0) {
				cli_write(sess, nfd, lendiff);
				_rl_last_c_pos += col_lendiff;
			} else {
				cli_write(sess, nfd, temp);
				_rl_last_c_pos += col_temp;
				return;
			}
			/* Copy (new) chars to screen from first diff to last match. */
			temp = nls - nfd;
			if ((temp - lendiff) > 0) {
				cli_write(sess, nfd + lendiff, temp - lendiff);
				_rl_last_c_pos += _rl_col_width (nfd+lendiff, 0, temp-col_lendiff);
			}
		} else {
			/* cannot insert chars, write to EOL */
			cli_write(sess, nfd, temp);
			_rl_last_c_pos += col_temp;
		}
	} else {				/* Delete characters from line. */
		/* If possible and inexpensive to use terminal deletion, then do so. */
		if (sess->term.dc && (2 * col_temp) >= -col_lendiff) {
			if (col_lendiff)
				delete_chars(sess, -col_lendiff); /* delete (diff) characters */
			
			/* Copy (new) chars to screen from first diff to last match */
			temp = nls - nfd;
			if (temp > 0) {
				cli_write(sess, nfd, temp);
				_rl_last_c_pos += _rl_col_width(nfd, 0, temp);;
			}
		} else {
			if (temp > 0) {
				cli_write(sess, nfd, temp);
				_rl_last_c_pos += col_temp;		/* XXX */
			}
			lendiff = (oe - old) - (ne - new);
			col_lendiff = lendiff;
			
			if (col_lendiff) {	  
				if (sess->term.autowrap && current_line < inv_botlin)
					space_to_eol(sess, col_lendiff);
				else
					_rl_clear_to_eol(sess, col_lendiff);
			}
		}
	}
}

/* Tell the update routines that we have moved onto a new (empty) line. */
int rl_on_new_line(cli_session_t *sess)
{
	if (visible_line)
		visible_line[0] = '\0';
	
	_rl_last_c_pos = _rl_last_v_pos = 0;
	_rl_vis_botlin = last_lmargin = 0;
	if (sess->vis_lbreaks)
		sess->vis_lbreaks[0] = sess->vis_lbreaks[1] = 0;
	visible_wrap_offset = 0;
	return 0;
}

/* Actually update the display, period. */
int rl_forced_update_display(cli_session_t *sess)
{
	register char *temp;
	
	if (visible_line) {
		temp = visible_line;
		while (*temp)
			*temp++ = '\0';
	}
	rl_on_new_line(sess);
	forced_display++;
	rl_redisplay(sess);
	return 0;
}

/* Move the cursor from _rl_last_c_pos to NEW, which are buffer indices.
   (Well, when we don't have multibyte characters, _rl_last_c_pos is a
   buffer index.)
   DATA is the contents of the screen line of interest; i.e., where
   the movement is being done. */
void _rl_move_cursor_relative(cli_session_t *sess, int new, const char *data)
{
	register int i;
	int woff;		/* number of invisible chars on current line */
	int cpos, dpos;		/* current and desired cursor positions */
	
	woff = W_OFFSET(_rl_last_v_pos, wrap_offset);
	cpos = _rl_last_c_pos;
	
	dpos = new;
	
	/* If we don't have to do anything, then return. */
	if (cpos == dpos)
		return;
	
	i = _rl_last_c_pos - woff;
	if (dpos == 0 || CR_FASTER(dpos, _rl_last_c_pos) ||
		(sess->term.autowrap && i == sess->term.screenwidth)) {
		if (sess->term.cr)
			cli_write(sess, sess->term.cr, 1);
		cpos = _rl_last_c_pos = 0;
	}
	
	if (cpos < dpos) 
		for (i = cpos; i < new; i++)
			cli_write(sess, data+i, 1);
	else if (cpos > dpos)
		cli_backspace(sess, cpos - dpos);
	
	_rl_last_c_pos = dpos;
}

/* PWP: move the cursor up or down. */
void _rl_move_vert(cli_session_t *sess, int to)
{
	register int delta, i;
	
	if (_rl_last_v_pos == to || to > sess->term.screenheight)
		return;
	
	if ((delta = to - _rl_last_v_pos) > 0) {
		for (i = 0; i < delta; i++)
			cli_write(sess, "\n", 1);
		if (sess->term.cr)
			cli_write(sess, sess->term.cr, 1);
		_rl_last_c_pos = 0;
	} else {			/* delta < 0 */
		if (sess->term.up && *sess->term.up)
			for (i = 0; i < -delta; i++)
				cli_write(sess, sess->term.up, 1);
	}
	
	_rl_last_v_pos = to;		/* Now TO is here */
}

int rl_character_len(cli_session_t *sess, register int c, register int pos)
{
	unsigned int uc;
	
	uc = (unsigned int)c;
	
	if (META_CHAR(uc))
		return ((sess->output_meta_chars == 0) ? 4 : 1);
	
	if (uc == '\t') {
#ifdef CONFIG_CLI_DISPLAY_TABS
		return (((pos | 7) + 1) - pos);
#else
		return (2);
#endif
	}
	
	if (CTRL_CHAR(c) || c == RUBOUT)
		return (2);
	
	return ((ISPRINT(uc)) ? 1 : 2);
}
/* How to print things in the "echo-area".  The prompt is treated as a
   mini-modeline. */
static int msg_saved_prompt = 0;

int rl_message(cli_session_t *sess, const char *format, ...)
{
	va_list args;
	
	va_start(args, format);
	vsprintf(msg_buf, format, args);
	msg_buf[sizeof(msg_buf) - 1] = '\0';	/* overflow? */
	va_end(args);
	
	if (saved_local_prompt == 0) {
		rl_save_prompt(sess);
		msg_saved_prompt = 1;
	}
	rl_display_prompt = msg_buf;
	local_prompt = expand_prompt(sess, msg_buf,
				     &prompt_visible_length,
				     &prompt_last_invisible,
				     &prompt_invis_chars_first_line,
				     &prompt_physical_chars);
	local_prompt_prefix = (char *)NULL;
	local_prompt_len = local_prompt ? strlen(local_prompt) : 0;
	rl_redisplay(sess);
	
	return 0;
}

/* How to clear things from the "echo-area". */
int rl_clear_message(cli_session_t *sess)
{
	rl_display_prompt = sess->the_prompt;
	if (msg_saved_prompt) {
		rl_restore_prompt(sess);
		msg_saved_prompt = 0;
	}
	rl_redisplay(sess);
	return 0;
}

int rl_reset_line_state(cli_session_t *sess)
{
	rl_on_new_line(sess);
	
	rl_display_prompt = sess->the_prompt ? sess->the_prompt : "";
	forced_display = 1;
	return 0;
}

void rl_save_prompt(cli_session_t *sess)
{
	saved_local_prompt = local_prompt;
	saved_local_prefix = local_prompt_prefix;
	saved_prefix_length = prompt_prefix_length;
	saved_local_length = local_prompt_len;
	saved_last_invisible = prompt_last_invisible;
	saved_visible_length = prompt_visible_length;
	saved_invis_chars_first_line = prompt_invis_chars_first_line;
	saved_physical_chars = prompt_physical_chars;
	
	local_prompt = local_prompt_prefix = (char *)0;
	local_prompt_len = 0;
	prompt_last_invisible = prompt_visible_length = prompt_prefix_length = 0;
	prompt_invis_chars_first_line = prompt_physical_chars = 0;
}

void rl_restore_prompt(cli_session_t *sess)
{
	xfree(local_prompt);
	xfree(local_prompt_prefix);
	
	local_prompt = saved_local_prompt;
	local_prompt_prefix = saved_local_prefix;
	local_prompt_len = saved_local_length;
	prompt_prefix_length = saved_prefix_length;
	prompt_last_invisible = saved_last_invisible;
	prompt_visible_length = saved_visible_length;
	prompt_invis_chars_first_line = saved_invis_chars_first_line;
	prompt_physical_chars = saved_physical_chars;
	
	/* can test saved_local_prompt to see if prompt info has been saved. */
	saved_local_prompt = saved_local_prefix = (char *)0;
	saved_local_length = 0;
	saved_last_invisible = saved_visible_length = saved_prefix_length = 0;
	saved_invis_chars_first_line = saved_physical_chars = 0;
}

/* Quick redisplay hack when erasing characters at the end of the line. */
void _rl_erase_at_end_of_line(cli_session_t *sess, int l)
{
	register int i;
	
	cli_backspace(sess, l);
	for (i = 0; i < l; i++)
		cli_write(sess, " ", 1);
	cli_backspace(sess, l);
	for (i = 0; i < l; i++)
		visible_line[--_rl_last_c_pos] = '\0';
	rl_display_fixed++;
}

/* Clear to the end of the line.  COUNT is the minimum
   number of character spaces to clear, */
void _rl_clear_to_eol(cli_session_t *sess, int count)
{
	if (sess->term.clreol)
		cli_write(sess, sess->term.clreol, 1);
	else if (count)
		space_to_eol(sess, count);
}

/* Clear to the end of the line using spaces.  COUNT is the minimum
   number of character spaces to clear, */
static void space_to_eol(cli_session_t *sess, int count)
{
	register int i;
	
	for (i = 0; i < count; i++)
		cli_write(sess, " ", 1);
	
	_rl_last_c_pos += count;
}

void _rl_clear_screen(cli_session_t *sess)
{
	if (sess->term.clrpag)
		cli_write(sess, sess->term.clrpag, 1);
	else
		cli_crlf(sess);
}

/* Insert COUNT characters from STRING to the output stream at column COL. */
static void insert_some_chars(cli_session_t *sess, char *string, int count, int col)
{
#ifdef WIN32
	cli_write(sess, string, count);
#else
	/* DEBUGGING */
	if (count != col)
		fprintf(stderr, "readline: debug: insert_some_chars: count (%d) != col (%d)\n", count, col);
	
	/* If IC is defined, then we do not have to "enter" insert mode. */
	if (sess->term.IC) {
		char *buffer;
		
		buffer = tgoto(sess->term.IC, 0, col);
		cli_write(sess, buffer, 1);
		cli_write(sess, string, count);
	} else {
		register int i;
		
		/* If we have to turn on insert-mode, then do so. */
		if (sess->term.im)
			cli_write(sess, sess->term.im, 1);
		
		/* If there is a special command for inserting characters, then
		   use that first to open up the space. */
		if (sess->term.ic && *sess->term.ic) {
			for (i = col; i--; )
				cli_write(sess, sess->term.ic, 1);
		}
		
		/* Print the text. */
		cli_write(sess, string, count);
		
		/* If there is a string to turn off insert mode, we had best use
		   it now. */
		if (sess->term.ei && *sess->term.ei)
			cli_write(sess, sess->term.ei, 1);
	}
#endif
}

/* Delete COUNT characters from the display line. */
static void delete_chars(cli_session_t *sess, int count)
{
	if (count > sess->term.screenwidth)	/* XXX */
		return;
	
#ifndef WIN32
	if (sess->term.DC && *sess->term.DC) {
		char *buffer;
		buffer = tgoto(sess->term.DC, count, count);
		cli_write(sess, buffer, count);
	} else {
		if (sess->term.dc && *sess->term.dc) {
			while (count--)
				cli_write(sess, sess->term.dc, 1);
		}
	}
#endif
}

void _rl_update_final(cli_session_t *sess)
{
	int full_lines;
	
	full_lines = 0;
	/* If the cursor is the only thing on an otherwise-blank last line,
	   compensate so we don't print an extra CRLF. */
	if (_rl_vis_botlin && _rl_last_c_pos == 0 &&
		visible_line[sess->vis_lbreaks[_rl_vis_botlin]] == 0) {
		_rl_vis_botlin--;
		full_lines = 1;
	}
	_rl_move_vert(sess, _rl_vis_botlin);
	/* If we've wrapped lines, remove the final xterm line-wrap flag. */
	if (full_lines && sess->term.autowrap && (VIS_LLEN(_rl_vis_botlin) == sess->term.screenwidth)) {
		char *last_line;
		char buf[2];
		last_line = &visible_line[sess->vis_lbreaks[_rl_vis_botlin]];
		cpos_buffer_position = -1;	/* don't know where we are in buffer */
		_rl_move_cursor_relative(sess, sess->term.screenwidth - 1, last_line);	/* XXX */
		_rl_clear_to_eol(sess, 0);
		sprintf(buf, "%c", last_line[sess->term.screenwidth - 1]);
		cli_write(sess, buf, 1);
	}
	_rl_vis_botlin = 0;
	cli_crlf(sess);
	cli_flush(sess);
	rl_display_fixed++;
}

/* Move to the start of the current line. */
static void cr(cli_session_t *sess)
{
	if (sess->term.cr) {
		cli_write(sess, sess->term.cr, 1);
		_rl_last_c_pos = 0;
	}
}

/* Redraw the last line of a multi-line prompt that may possibly contain
 * terminal escape sequences.  Called with the cursor at column 0 of the
 * line to draw the prompt on.
 */
static void redraw_prompt(cli_session_t *sess, char *t)
{
	const char *oldp;
	
	oldp = rl_display_prompt;
	rl_save_prompt(sess);
	
	rl_display_prompt = t;
	local_prompt = expand_prompt(sess, t,
				     &prompt_visible_length,
				     &prompt_last_invisible,
				     &prompt_invis_chars_first_line,
				     &prompt_physical_chars);
	local_prompt_prefix = (char *)NULL;
	local_prompt_len = local_prompt ? strlen(local_prompt) : 0;
	
	rl_forced_update_display(sess);
	
	rl_display_prompt = oldp;
	rl_restore_prompt(sess);
}
      
/* Redisplay the current line after a SIGWINCH is received. */
void _rl_redisplay_after_sigwinch(cli_session_t *sess)
{
	char *t;
	
	/* Clear the current line and put the cursor at column 0.  Make
	 * sure the right thing happens if we have wrapped to a new screen
	 * line.
	 */
	if (sess->term.cr) {
		cli_write(sess, sess->term.cr, 1);
		_rl_last_c_pos = 0;
		if (sess->term.clreol) {
			cli_write(sess, sess->term.clreol, 1);
		} else {
			space_to_eol(sess, sess->term.screenwidth);
			cli_write(sess, sess->term.cr, 1);
		}
		if (_rl_last_v_pos > 0)
			_rl_move_vert(sess, 0);
	} else {
		cli_crlf(sess);
	}
	/* Redraw only the last line of a multi-line prompt. */
	t = strrchr(rl_display_prompt, '\n');
	if (t)
		redraw_prompt(sess, ++t);
	else
		rl_forced_update_display(sess);
}

void _rl_clean_up_for_exit(cli_session_t *sess)
{
	if (sess->echoing_p) {
		_rl_move_vert(sess, _rl_vis_botlin);
		_rl_vis_botlin = 0;
		cli_flush(sess);
		//      rl_restart_output (1, 0);
	}
}

void _rl_erase_entire_line(cli_session_t *sess)
{
	cr(sess);
	_rl_clear_to_eol(sess, 0);
	cr(sess);
	cli_flush(sess);
}
