#include "cli_stdio.h"

#ifndef WIN32
/* to find struct winsize */
#include <sys/ioctl.h>
#include <termios.h>

/* Define _POSIX_VDISABLE if we are not using the `new' tty driver and
   it is not already defined.  It is used both to determine if a
   special character is disabled and to disable certain special
   characters.  Posix systems should set to 0, USG systems to -1. */
#if !defined (_POSIX_VDISABLE)
#    if defined (_POSIX_VERSION)
#      define _POSIX_VDISABLE 0
#    else /* !_POSIX_VERSION */
#      define _POSIX_VDISABLE -1
#    endif /* !_POSIX_VERSION */
#endif /* !_POSIX_VDISABLE */

typedef struct _tty_chars_t {
	unsigned char t_eof;
	unsigned char t_eol;
	unsigned char t_eol2;
	unsigned char t_erase;
	unsigned char t_werase;
	unsigned char t_kill;
	unsigned char t_reprint;
	unsigned char t_intr;
	unsigned char t_quit;
	unsigned char t_susp;
	unsigned char t_dsusp;
	unsigned char t_start;
	unsigned char t_stop;
	unsigned char t_lnext;
	unsigned char t_flush;
	unsigned char t_status;
} tty_chars_t;

struct termios otio;
#if defined (FLUSHO)
#  define OUTPUT_BEING_FLUSHED(tp)  (tp->c_lflag & FLUSHO)
#else
#  define OUTPUT_BEING_FLUSHED(tp)  0
#endif

static tty_chars_t cli_stdio_chars, cli_stdio_last_chars;
static int cli_stdio_prepped;

static void cli_stdio_set_winsize(int tty)
{
#if defined (TIOCGWINSZ)
	struct winsize w;
	
	if (ioctl(tty, TIOCGWINSZ, &w) == 0)
		(void)ioctl(tty, TIOCSWINSZ, &w);
#endif /* TIOCGWINSZ */
}

static int __cli_stdio_get_termio(int tty, struct termios *tiop)
{
	int ioctl_ret;
	
	while (1) {
		ioctl_ret = tcgetattr(tty, tiop);
		if (ioctl_ret < 0) {
			if (errno != EINTR)
				return -1;
			else
				continue;
		}
		if (OUTPUT_BEING_FLUSHED(tiop))
			continue;
		break;
	}
	
	return 0;
}

static int cli_stdio_get_termio(int tty, struct termios *tiop)
{
	cli_stdio_set_winsize(tty);
	
	errno = 0;
	if (__cli_stdio_get_termio(tty, tiop) < 0)
		return -1;
	return 0;
}

static int __cli_stdio_set_termio(int tty, struct termios *tiop)
{
	while (tcsetattr(tty, TCSADRAIN, tiop) < 0) {
		if (errno != EINTR)
			return -1;
		errno = 0;
	}
	return 0;
}

static int cli_stdio_set_termio(int tty, struct termios *tiop)
{
	if (__cli_stdio_set_termio(tty, tiop) < 0)
		return -1;
	return 0;
}

static void cli_stdio_save_chars(struct termios *tiop)
{
	cli_stdio_last_chars = cli_stdio_chars;
	
	cli_stdio_chars.t_eof = tiop->c_cc[VEOF];
	cli_stdio_chars.t_eol = tiop->c_cc[VEOL];
#ifdef VEOL2
	cli_stdio_chars.t_eol2 = tiop->c_cc[VEOL2];
#endif
	cli_stdio_chars.t_erase = tiop->c_cc[VERASE];
#ifdef VWERASE
	cli_stdio_chars.t_werase = tiop->c_cc[VWERASE];
#endif
	cli_stdio_chars.t_kill = tiop->c_cc[VKILL];
#ifdef VREPRINT
	cli_stdio_chars.t_reprint = tiop->c_cc[VREPRINT];
#endif
	cli_stdio_chars.t_intr = tiop->c_cc[VINTR];
	cli_stdio_chars.t_quit = tiop->c_cc[VQUIT];
#ifdef VSUSP
	cli_stdio_chars.t_susp = tiop->c_cc[VSUSP];
#endif
#ifdef VDSUSP
	cli_stdio_chars.t_dsusp = tiop->c_cc[VDSUSP];
#endif
#ifdef VSTART
	cli_stdio_chars.t_start = tiop->c_cc[VSTART];
#endif
#ifdef VSTOP
	cli_stdio_chars.t_stop = tiop->c_cc[VSTOP];
#endif
#ifdef VLNEXT
	cli_stdio_chars.t_lnext = tiop->c_cc[VLNEXT];
#endif
#ifdef VDISCARD
	cli_stdio_chars.t_flush = tiop->c_cc[VDISCARD];
#endif
#ifdef VSTATUS
	cli_stdio_chars.t_status = tiop->c_cc[VSTATUS];
#endif
}

void cli_stdio_default_bindings(cli_session_t *sess)
{
}

static void __cli_stdio_prep_terminal(cli_session_t *sess,
				   struct termios oldtio,
				   struct termios *tiop)
{
	sess->echoing_p = (oldtio.c_lflag & ECHO);
	
	tiop->c_lflag &= ~(ICANON | ECHO);
	
	if ((unsigned char)oldtio.c_cc[VEOF] != (unsigned char)_POSIX_VDISABLE)
		sess->eof_char = oldtio.c_cc[VEOF];
	
#if defined (USE_XON_XOFF)
#if defined (IXANY)
	tiop->c_iflag &= ~(IXON | IXOFF | IXANY);
#else
	/* `strict' Posix systems do not define IXANY. */
	tiop->c_iflag &= ~(IXON | IXOFF);
#endif /* IXANY */
#endif /* USE_XON_XOFF */

	/* Only turn this off if we are using all 8 bits. */
	if ((tiop->c_cflag & CSIZE) == CS8)
		tiop->c_iflag &= ~(ISTRIP | INPCK);
	
	/* Make sure we differentiate between CR and NL on input. */
	tiop->c_iflag &= ~(ICRNL | INLCR);
	
	tiop->c_lflag |= ISIG;

	tiop->c_cc[VMIN] = 1;
	tiop->c_cc[VTIME] = 0;
	
#if defined (FLUSHO)
	if (OUTPUT_BEING_FLUSHED(tiop)) {
		tiop->c_lflag &= ~FLUSHO;
		oldtio.c_lflag &= ~FLUSHO;
	}
#endif

	/* Turn off characters that we need on Posix systems with job control,
	   just to be sure.  This includes ^Y and ^V.  This should not really
	   be necessary.  */
#if defined (_POSIX_VDISABLE)
	
#if defined (VLNEXT)
	tiop->c_cc[VLNEXT] = _POSIX_VDISABLE;
#endif
	
#if defined (VDSUSP)
	tiop->c_cc[VDSUSP] = _POSIX_VDISABLE;
#endif
#endif
}

int cli_stdio_init_terminal(cli_session_t *sess)
{
	int tty;
	struct termios tio;
	
	if (cli_stdio_prepped) return -1;
	
	tty = cli_stdio_instream;
	
	if (cli_stdio_get_termio(tty, &tio) < 0) {
		return -1;
	}
	
	otio = tio;

	cli_stdio_save_chars(&otio);
	RL_SETSTATE(sess, RL_STATE_TTYCSAVED);
	
	__cli_stdio_prep_terminal(sess, otio, &tio);
	
	if (cli_stdio_set_termio(tty, &tio) < 0) {
		return -1;
	}
	
	cli_flush(sess);
	cli_stdio_prepped = 1;
	RL_SETSTATE(sess, RL_STATE_TERMPREPPED);
	return 0;
}

void cli_stdio_exit_terminal(cli_session_t *sess)
{
	int tty;
	
	if (!cli_stdio_prepped) return;
	
	tty = cli_stdio_instream;
	
	cli_flush(sess);
	
	if (cli_stdio_set_termio(tty, &otio) < 0) {
		return;
	}
	
	cli_stdio_prepped = 0;
	RL_UNSETSTATE(sess, RL_STATE_TERMPREPPED);
}

int cli_stdio_start_terminal(void)
{
	cli_stdio_instream = STDIN_FILENO;
	cli_stdio_outstream = STDOUT_FILENO;
	return 0;
}

void cli_stdio_stop_terminal(void)
{
}
#endif
