#include "cli_priv.h"

static void cli_bind_termcap_arrow_keys(cli_keymap_t map,
					cli_terminal_t *term);
/* maybe as session's member. */
static int more_line_count = 0;

static void cli_more_start(void)
{
	more_line_count = 0;
}

static void cli_more_stop(void)
{
	more_line_count = 0;
}

static int cli_ask_more(cli_session_t *s)
{
	int scr_height, scr_width;
	rl_get_screen_size(s, &scr_height, &scr_width);
	
	more_line_count++;
	/* FIXME: which height? */
	if (more_line_count >= scr_height - 1) {
		more_line_count = _rl_internal_pager(s, more_line_count);
		if (more_line_count < 0)
			return 0;
	}
	return 0;
}

/* Get readline's idea of the screen size.  TTY is a file descriptor open
   to the terminal.  If IGNORE_ENV is true, we do not pay attention to the
   values of $LINES and $COLUMNS.  The tests for TERM_STRING_BUFFER being
   non-null serve to check whether or not we have initialized termcap. */
void cli_screen_size(cli_session_t *sess, int tty, int ignore_env)
{
	char *ss;
	int wr, wc;
	
	wr = wc = -1;
	
	if (ignore_env) {
		sess->term.screenwidth = wc;
		sess->term.screenheight = wr;
	} else {
		sess->term.screenwidth = sess->term.screenheight = -1;
	}
	/* Environment variable COLUMNS overrides setting of "co" if IGNORE_ENV
	   is unset.  If we prefer the environment, check it first before
	   assigning the value returned by the kernel. */
	if (sess->term.screenwidth <= 0) {
		if (ignore_env == 0 && (ss = getenv("COLUMNS")))
			sess->term.screenwidth = atoi(ss);
		
		if (sess->term.screenwidth <= 0)
			sess->term.screenwidth = wc;
		
		if (sess->term.screenwidth <= 0 && sess->term.string_buffer)
			sess->term.screenwidth = tgetnum("co");
	}
	
	/* Environment variable LINES overrides setting of "li" if IGNORE_ENV
	is unset. */
	if (sess->term.screenheight <= 0) {
		if (ignore_env == 0 && (ss = getenv("LINES")))
			sess->term.screenheight = atoi(ss);
		
		if (sess->term.screenheight <= 0)
			sess->term.screenheight = wr;
		
		if (sess->term.screenheight <= 0 && sess->term.string_buffer)
			sess->term.screenheight = tgetnum("li");
	}
	
	/* If all else fails, default to 80x24 terminal. */
	if (sess->term.screenwidth <= 1)
		sess->term.screenwidth = 80;
	
	if (sess->term.screenheight <= 0)
		sess->term.screenheight = 24;
	
	/* If we're being compiled as part of bash, set the environment
	   variables $LINES and $COLUMNS to new values.  Otherwise, just
	   do a pair of putenv () or setenv () calls. */
	sh_set_lines_and_columns(sess->term.screenheight, sess->term.screenwidth);
	
	if (sess->term.autowrap == 0)
		sess->term.screenwidth--;
	
	sess->term.screenchars = sess->term.screenwidth * sess->term.screenheight;
}

void _rl_set_screen_size(cli_session_t *sess, int rows, int cols)
{
	if (sess->term.autowrap == -1)
		cli_init_termio(sess, sess->terminal_name);
	
	if (rows > 0)
		sess->term.screenheight = rows;
	if (cols > 0) {
		sess->term.screenwidth = cols;
		if (sess->term.autowrap == 0)
			sess->term.screenwidth--;
	}
	
	if (rows > 0 || cols > 0)
		sess->term.screenchars = sess->term.screenwidth * sess->term.screenheight;
}

void rl_set_screen_size(cli_session_t *sess, int rows, int cols)
{
	_rl_set_screen_size(sess, rows, cols);
}

void rl_get_screen_size(cli_session_t *sess, int *rows, int *cols)
{
	if (rows)
		*rows = sess->term.screenheight;
	if (cols)
		*cols = sess->term.screenwidth;
}
     
void rl_resize_terminal(cli_session_t *sess)
{
	if (sess->echoing_p) {
		cli_screen_size(sess, sess->rl_instream, 1);
		if (0)
			rl_forced_update_display(sess);
		else
			_rl_redisplay_after_sigwinch(sess);
	}
}

typedef struct _cli_termcap_t {
	const char *tc_var;
	unsigned long tc_offset;
} cli_termcap_t;

/* This should be kept sorted, just in case we decide to change the
   search algorithm to something smarter. */
static cli_termcap_t tc_strings[] = {
	{ "@7", offsetof(cli_terminal_t, at7) },
	{ "DC", offsetof(cli_terminal_t, DC) },
	{ "IC", offsetof(cli_terminal_t, IC) },
	{ "ce", offsetof(cli_terminal_t, clreol) },
	{ "cl", offsetof(cli_terminal_t, clrpag) },
	{ "cr", offsetof(cli_terminal_t, cr) },
	{ "dc", offsetof(cli_terminal_t, dc) },
	{ "ei", offsetof(cli_terminal_t, ei) },
	{ "ic", offsetof(cli_terminal_t, ic) },
	{ "im", offsetof(cli_terminal_t, im) },
	{ "kD", offsetof(cli_terminal_t, kD) },	/* delete */
	{ "kH", offsetof(cli_terminal_t, kH) },	/* home down ?? */
	{ "kI", offsetof(cli_terminal_t, kI) },	/* insert */
	{ "kd", offsetof(cli_terminal_t, kd) },
	{ "ke", offsetof(cli_terminal_t, ke) },	/* end keypad mode */
	{ "kh", offsetof(cli_terminal_t, kh) },	/* home */
	{ "kl", offsetof(cli_terminal_t, kl) },
	{ "kr", offsetof(cli_terminal_t, kr) },
	{ "ks", offsetof(cli_terminal_t, ks) },	/* start keypad mode */
	{ "ku", offsetof(cli_terminal_t, ku) },
	{ "le", offsetof(cli_terminal_t, backspace) },
	{ "nd", offsetof(cli_terminal_t, forward_char) },
	{ "pc", offsetof(cli_terminal_t, pc) },
	{ "up", offsetof(cli_terminal_t, up) },
	{ "vb", offsetof(cli_terminal_t, visible_bell) },
};

#define NUM_TC_STRINGS (sizeof(tc_strings) / sizeof(cli_termcap_t))

/* Read the desired terminal capability strings into BP.  The capabilities
   are described in the TC_STRINGS table. */
static void cli_init_termcap(cli_terminal_t *term, char **bp)
{
	int i;
	char **ptr;
	
	for (i = 0; i < NUM_TC_STRINGS; i++) {
		ptr = (char **)(term + tc_strings[i].tc_offset);
		*ptr = tgetstr((char *)tc_strings[i].tc_var, bp);
	}
}

int cli_init_termio(cli_session_t *sess, const char *terminal_name)
{
	const char *term;
	char *buffer;
	int tty, tgetent_ret;
	
	term = terminal_name ? terminal_name : getenv("TERM");
	sess->term.clrpag = sess->term.cr = sess->term.clreol = (char *)NULL;
	tty = sess->rl_instream != -1 ? sess->rl_instream : 0;
	
	if (term == 0)
		term = "dumb";
	
	/* I've separated this out for later work on not calling tgetent at all
	   if the calling application has supplied a custom redisplay function,
	   (and possibly if the application has supplied a custom input function). */
	if (sess->term.string_buffer == 0)
		sess->term.string_buffer = (char *)xmalloc(2032);
	
	if (sess->term.buffer == 0)
		sess->term.buffer = (char *)xmalloc(4080);
	
	buffer = sess->term.string_buffer;
	
	tgetent_ret = tgetent(sess->term.buffer, term);

	if (tgetent_ret <= 0) {
		xfree(sess->term.string_buffer);
		xfree(sess->term.buffer);
		buffer = sess->term.buffer = sess->term.string_buffer = (char *)NULL;
		
		sess->term.autowrap = 0;	/* used by _rl_get_screen_size */
		
		/* Allow calling application to set default height and width, using
		   rl_set_screen_size */
		if (sess->term.screenwidth <= 0 || sess->term.screenheight <= 0) {
			cli_screen_size(sess, tty, 0);
		}
		
		/* Defaults. */
		if (sess->term.screenwidth <= 0 || sess->term.screenheight <= 0) {
			sess->term.screenwidth = 79;
			sess->term.screenheight = 24;
		}
		
		/* Everything below here is used by the redisplay code. */
		sess->term.screenchars = sess->term.screenwidth * sess->term.screenheight;
		sess->term.cr = "\r";
		sess->term.im = sess->term.ei = sess->term.ic = (char *)NULL;
		sess->term.IC =  sess->term.up = sess->term.dc = (char *)NULL;
		sess->term.DC = sess->term.visible_bell = (char *)NULL;
		sess->term.ku = sess->term.kd = sess->term.kl = (char *)NULL;
		sess->term.kr = sess->term.kh = sess->term.kH = (char *)NULL;
		sess->term.kI = sess->term.kD = sess->term.ks = (char *)NULL;
		sess->term.ke = sess->term.at7 = (char *)NULL;
		sess->term.can_insert = 0;
		
		/* Reasonable defaults for tgoto().  Readline currently only uses
		   tgoto if sess->term.IC or sess->term.DC is defined, but just in case we
		   change that later... */
		PC = '\0';
		BC = sess->term.backspace = "\b";
		UP = sess->term.up;
		
		return 0;
	}
	
	cli_init_termcap(&sess->term, &buffer);
	
	/* Set up the variables that the termcap library expects the application
	   to provide. */
	PC = sess->term.pc ? *sess->term.pc : 0;
	BC = sess->term.backspace;
	UP = sess->term.up;
	
	if (!sess->term.cr)
		sess->term.cr = "\r";
	
	sess->term.autowrap = tgetflag("am") && tgetflag("xn");
	
	/* Allow calling application to set default height and width,
	 * using rl_set_screen_size
	 */
	if (sess->term.screenwidth <= 0 || sess->term.screenheight <= 0)
		cli_screen_size(sess, tty, 0);
	
	/* "An application program can assume that the terminal can do
	 * character insertion if *any one of* the capabilities `IC',
	 * `im', `ic' or `ip' is provided."  But we can't do anything if
	 * only `ip' is provided, so...
	 */
	sess->term.can_insert = (sess->term.IC || sess->term.im || sess->term.ic);
	
	/* Attempt to find and bind the arrow keys.  Do not override
	 * already bound keys in an overzealous attempt, however.
	 */
	cli_bind_termcap_arrow_keys(sess->keymap, &sess->term);
	return 0;
}

/* Bind the arrow key sequences from the termcap description in MAP. */
static void cli_bind_termcap_arrow_keys(cli_keymap_t map,
					cli_terminal_t *term)
{
	cli_bind_keyseq_map(map, term->ku,  cli_get_previous_history);
	cli_bind_keyseq_map(map, term->kd,  cli_get_next_history);
	cli_bind_keyseq_map(map, term->kr,  cli_forward_char);
	cli_bind_keyseq_map(map, term->kl,  cli_backward_char);
	cli_bind_keyseq_map(map, term->kh,  cli_beg_of_line);	/* Home */
	cli_bind_keyseq_map(map, term->at7, cli_end_of_line);	/* End */
	cli_bind_keyseq_map(map, term->kD,  cli_delete);
}

/* Write COUNT characters from STRING to the output stream. */
void cli_write(cli_session_t *sess, const char *string, int count)
{
	write(sess->rl_outstream, string, count);
}

void cli_flush(cli_session_t *sess)
{
	/* need not do flush since rl_outstream may not be an iobuf */
	//fflush(sess->rl_outstream);
}

/* Move the cursor back. */
int cli_backspace(cli_session_t *sess, int count)
{
	register int i;
	
	if (sess->term.backspace) {
		for (i = 0; i < count; i++)
			cli_write(sess, sess->term.backspace, 1);
	} else {
		for (i = 0; i < count; i++)
			cli_write(sess, "\b", 1);
	}
	return 0;
}

/* Move to the start of the next line. */
int cli_crlf(cli_session_t *sess)
{
	if (sess->term.cr)
		cli_write(sess, sess->term.cr, 1);
	cli_write(sess, "\n", 1);
	return 0;
}

/* Ring the terminal bell. */
int cli_ding(cli_session_t *sess)
{
	if (sess->echoing_p) {
		switch (cli_main_config.bell_type) {
		case NO_BELL:
		default:
			break;
		case VISIBLE_BELL:
			if (sess->term.visible_bell) {
				cli_write(sess, sess->term.visible_bell, 1);
				break;
			}
			/* FALLTHROUGH */
		case AUDIBLE_BELL:
			fprintf(stderr, "\007");
			fflush(stderr);
			break;
		}
		return (0);
	}
	return (-1);
}

void cli_vprintf(cli_session_t *sess, const char *fmt, va_list args)
{
	char buf[120];
	int len = 120;

	vsnprintf(buf, len, fmt, args);
	cli_write(sess, buf, strlen(buf));
}

void cli_printf(ui_session_t *sess, const char *fmt, ...)
{
	va_list ap;
	
	va_start(ap, fmt);
	cli_vprintf((cli_session_t *)sess, fmt, ap);
	cli_flush((cli_session_t *)sess);
	va_end(ap);
}

void cli_printf_eol(ui_session_t *sess, const char *fmt, ...)
{
	va_list ap;
	
	va_start(ap, fmt);
	cli_vprintf((cli_session_t *)sess, fmt, ap);
	cli_crlf((cli_session_t *)sess);
	cli_flush((cli_session_t *)sess);
	va_end(ap);
}

static void print_several_chars(ui_session_t *s, int count, char ch)
{
	int i;
	if (count <= 0)
		return;
	for (i = 0; i < count; i++)
		cli_printf(s, "%c", ch);
}

/* print string at left side and fill up the sub_len with ' '. */
static void print_left_chars(ui_session_t *sess, const char *str, int sub_len)
{					
	cli_printf(sess, "%s", str);
	print_several_chars(sess, sub_len, ' ');
}

/* fill up the sub_len with ' ' and print string at right side. */
static void print_right_chars(ui_session_t *sess, const char *str, int sub_len)
{
	print_several_chars(sess, sub_len, ' ');
	cli_printf(sess, "%s", str);
}

#define OUTPUT_MAX_LINE_ONE_TIME	2

static void cli_print_table_col1(ui_session_t *sess, ui_table_t *table)
{
	cli_session_t *s = (cli_session_t *)sess;
	int table_rows, table_cols, scr_height, scr_width;
	int r_idx, c_idx, sub_len;
	char *e;
	vector_t *line = NULL;

	rl_get_screen_size(s, &scr_height, &scr_width);
	table_rows = ui_table_rows(table);
	table_cols = 1;

	for (r_idx = 0; r_idx < table_rows; r_idx++) {
		line = get_element(table->table, r_idx);
		if (!line) 
			break;
		for (c_idx = 0; c_idx < table_cols; c_idx++) {
			e = get_element(line, c_idx);
			/* One column, its ok print one char */
			if (!e) {
				print_several_chars(sess, 1, ' ');
				continue;
			}
			sub_len = 0;
			print_left_chars(sess, e, sub_len);
		}
		cli_crlf(s);
		cli_flush(s);
	}
}

static void cli_print_table_col2(ui_session_t *sess, ui_table_t *table)
{
	cli_session_t *s = (cli_session_t *)sess;
	vector_t *line = NULL;
	const char *e;
	int c_idx, r_idx, len;
	int sub_len; 
	int table_rows, table_cols, scr_height, scr_width;
	int count, this_col_width[2] = {0};

	table_rows = ui_table_rows(table);
	table_cols = 2;

	rl_get_screen_size(s, &scr_height, &scr_width);
	
	if (scr_width < table_cols) {
		/* Not a error but it's not supported. */
		cli_log(CLI_LOG_ERR, "CLI: Error screenwidth.");
		return;
	}

	/* Get max width of each column */
	for (c_idx = 0; c_idx < table_cols; c_idx++) {
		for (r_idx = 0, len = 0; r_idx < table_rows; r_idx++) {
			e = ui_value_by_index(table, c_idx, r_idx);
			if (e && len < (int)strlen(e))
				len = strlen(e);
		}
		if (this_col_width[c_idx] < len)
			this_col_width[c_idx] = len;
	}

	count = 0;
	for (r_idx = 0; r_idx < table_rows; r_idx++) {
		line = get_element(table->table, r_idx);
		if (!line) 
			break;
		for (c_idx = 0; c_idx < table_cols; c_idx++) {
			e = get_element(line, c_idx);
			if (!e) {
				print_several_chars(sess, 
					this_col_width[c_idx], ' ');
				continue;
			}

			sub_len = this_col_width[c_idx] - strlen(e);
			print_left_chars(sess, e, sub_len);
			/* First column */
			if (c_idx == 0)
				cli_printf(sess, " - ");
		}
		cli_crlf(s);
		cli_flush(s);

		/* For OUTPUT_MAX_LINE_ONE_TIME output more */
		count++;
	}
}

static void cli_print_table_cols(ui_session_t *sess, ui_table_t *table)
{
	cli_session_t *s = (cli_session_t *)sess;
	vector_t *line = NULL;
	const char *e = NULL, *title = NULL;
	const char *empty_title = "nonamed";
	int c_idx, r_idx;
	int sub_len;
	int table_rows, table_cols, scr_height, scr_width;
	int single_col_width;
	int count;
	int non_space, spaces, word_len, col_width[20] = {0};
	int space_bt_col, more_print;

	table_rows = ui_table_rows(table);
	table_cols = ui_table_columns(table);

	rl_get_screen_size(s, &scr_height, &scr_width);

	if (scr_width < table_cols) {
		cli_log(CLI_LOG_ERR, "Error screenwidth.");
		return;
	}
	single_col_width = scr_width / table_cols;

	non_space = 0;
	for (c_idx = 0; c_idx < table_cols; c_idx++) {
		col_width[c_idx] = 0;
		title = get_element(table->title, c_idx);
		word_len = title ? strlen(title) : 0;
		if (col_width[c_idx] < word_len)
			col_width[c_idx] = word_len;

		for (r_idx = 0; r_idx < table_rows; r_idx++) {
			line = get_element(table->table, r_idx);
			if (line)
				e = get_element(line, c_idx);
			word_len = e ? strlen(e) : 0;
			if (col_width[c_idx] < word_len)
				col_width[c_idx] = word_len;
		}
		non_space += col_width[c_idx];
	}
	spaces = scr_width - non_space;
	space_bt_col = spaces / (table_cols - 1);
	if (space_bt_col * (table_cols - 1) != spaces)
		more_print = spaces - (space_bt_col * (table_cols - 1));
	else
		more_print = 0;

	/* Print title first */
	cli_ask_more(s);
	for (c_idx = 0; c_idx < table_cols; c_idx++) {
		title = get_element(table->title, c_idx);
		if (!title)
			title = empty_title;

		if (c_idx == table_cols - 1) {
			single_col_width = col_width[c_idx] + more_print;
			sub_len = single_col_width - strlen(title);
			print_right_chars(sess, title, sub_len);
		} else {
			single_col_width = space_bt_col + col_width[c_idx];
			sub_len = single_col_width - strlen(title);
			print_left_chars(sess, title, sub_len);
		}
	}

	cli_crlf(s);
	cli_flush(s);
	print_several_chars(sess, scr_width, '=');
	cli_crlf(s);
	cli_flush(s);

	count = 0;
	for (r_idx = 0; r_idx < table_rows; r_idx++) {
		line = get_element(table->table, r_idx);
		if (!line) 
			break;

		cli_ask_more(s);

		for (c_idx = 0; c_idx < table_cols; c_idx++) {
			e = get_element(line, c_idx);

			if (c_idx == table_cols - 1)
				single_col_width = col_width[c_idx] + more_print;
			else 
				single_col_width = space_bt_col + col_width[c_idx];

			if (!e) {
				print_several_chars(sess, 
					single_col_width, ' ');
				continue;
			}
			sub_len = single_col_width - strlen(e);
			if (c_idx == table_cols - 1)
				print_right_chars(sess, e, sub_len);
			else 
				print_left_chars(sess, e, sub_len);
		}
		cli_crlf(s);
		cli_flush(s);

		count++;
	}
	return;
}

void cli_print_table(ui_session_t *sess, ui_table_t *table)
{
	int table_rows, table_cols;

	if (!sess || !table)
		return;
	
	table_rows = ui_table_rows(table);
	table_cols = ui_table_columns(table);
	
	if (table_rows <= 0 || table_cols <= 0)
		return;
	/* TODO: ratio by screen size. 
	 *	 more function.
	 *	 matches - col1.
	 */
	cli_more_start();
	if (table_cols == 1)
		cli_print_table_col1(sess, table);
	else if (table_cols == 2)
		cli_print_table_col2(sess, table);
	else
		cli_print_table_cols(sess, table);

	cli_more_stop();
	return;
}
