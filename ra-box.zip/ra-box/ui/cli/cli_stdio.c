#include "cli_stdio.h"

static cli_session_t *cli_stdio_session = NULL;

int cli_stdio_instream = INVALID_SOCKET;
int cli_stdio_outstream = INVALID_SOCKET;

static void cli_stdio_event(int sock, void *eloop_ctx, void *sock_ctx)
{
	cli_session_input(sock_ctx);
}

cli_session_ops cli_stdio_operation = {
	cli_stdio_init_terminal,
	cli_stdio_exit_terminal,
	cli_stdio_default_bindings,
	NULL,
};

static int cli_stdio_start(void)
{
	cli_params_t param;

	if (cli_stdio_start_terminal())
		return -1;

	param.instream = cli_stdio_instream;
	param.outstream = cli_stdio_outstream;
	param.ops = &cli_stdio_operation;
	cli_stdio_session = cli_session_start(&param);

	if (!cli_stdio_session) {
		return -1;
	}

	eloop_register_read_sock(NULL, cli_stdio_instream, cli_stdio_event,
				 NULL, cli_stdio_session);
	return 0;
}

static void cli_stdio_stop(void)
{
	cli_session_stop(cli_stdio_session);
	eloop_unregister_read_sock(NULL, cli_stdio_instream);
	cli_stdio_stop_terminal();
}

cli_stream_t cli_stdio_stream = {
	"stdio",
	cli_stdio_start,
	cli_stdio_stop,
};

modlinkage int __init cli_stdio_init(void)
{
	cli_register_stream(&cli_stdio_stream);
	return 0;
}

modlinkage void __exit cli_stdio_exit(void)
{
	cli_unregister_stream(&cli_stdio_stream);
}

module_init(cli_stdio_init);
module_exit(cli_stdio_exit);
