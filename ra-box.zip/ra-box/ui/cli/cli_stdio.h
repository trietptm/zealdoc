#ifndef __CLI_STDIO_H_INCLUDE__
#define __CLI_STDIO_H_INCLUDE__

#include <sysdep.h>
#include <service.h>
#include <cli_api.h>

extern int cli_stdio_instream;
extern int cli_stdio_outstream;

int cli_stdio_init_terminal(cli_session_t *sess);
void cli_stdio_exit_terminal(cli_session_t *sess);
void cli_stdio_default_bindings(cli_session_t *sess);
int cli_stdio_start_terminal(void);
void cli_stdio_stop_terminal(void);

#endif /* __CLI_STDIO_H_INCLUDE__ */
