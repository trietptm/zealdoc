#include "cli_priv.h"

static void cli_char_cleanup(cli_session_t *);
static int cli_read_char(cli_session_t *);
static void cli_init_line(cli_session_t *sess);
static void bind_arrow_keys(cli_keymap_t map);

void cli_line_init_state(cli_session_t *sess)
{
	sess->point = sess->end = sess->mark = 0;
	sess->the_line = sess->line_buffer;
	sess->the_line[0] = 0;
}

void cli_char_cleanup(cli_session_t *sess)
{
	if (sess->done == 0) {
		rl_redisplay(sess);
	}
	
	/* If the application writer has told us to erase the entire line
	 * if the only character typed was something bound to cli_newline,
	 * do so.
	 */
	if (sess->erase_empty_line && sess->done &&
	    sess->last_func == cli_newline &&
	    sess->point == 0 && sess->end == 0)
		_rl_erase_entire_line(sess);
}

static void cli_line_setup(cli_session_t *sess)
{
	char *nprompt;
	
	cli_banner_start(sess);

	/* If we're not echoing, we still want to at least print a prompt,
	 * because rl_redisplay will not do it for us.  If the calling
	 * application has a custom redisplay function, though, let that
	 * function handle it.
	 */
	if (sess->echoing_p == 0) {
		if (sess->the_prompt) {
			nprompt = _rl_strip_prompt(sess, sess->the_prompt);
			cli_write(sess, (const char *)nprompt, strlen(nprompt));
			free(nprompt);
		}
	} else {
		rl_on_new_line(sess);
		rl_redisplay(sess);
	}
	
	if (sess->ops.prepare_input)
		sess->ops.prepare_input(sess);
}

/* Prompt with PROMPT.  An empty PROMPT means none.  
   A return value of NULL means that EOF was encountered. */
void cli_line_start(cli_session_t *sess)
{
	/* If we are at EOF return a NULL string. */
	if (sess->pending_input == EOF) {
		rl_clear_pending_input(sess);
		return;
	}

	rl_set_prompt(sess, sess->the_prompt);
	
	rl_initialize(sess);
	if (sess->ops.init_terminal)
		sess->ops.init_terminal(sess);
	
	rl_extend_line_buffer(sess, 4000);
	cli_line_setup(sess);
}

static char *cli_line_teardown(cli_session_t *sess, int eof)
{
	char *temp;
	HIST_ENTRY *entry;
	
	/* Restore the original of this history line, iff the line that we
	   are editing was originally in the history, AND the line has changed. */
	entry = current_history();
	
	if (entry && sess->undo_list) {
		temp = savestring(sess->the_line);
		cli_revert_line(sess, 1, 0);
		entry = replace_history_entry(where_history(), sess->the_line, (histdata_t)NULL);
		_rl_free_history_entry(entry);
		
		strcpy(sess->the_line, temp);
		free(temp);
	}

	/* At any rate, it is highly likely that this line has an undo list.  Get
	rid of it now. */
	if (sess->undo_list)
		rl_free_undo_list(sess);
	
	/* Restore normal cursor, if available. */
	_rl_set_insert_mode(sess, RL_IM_INSERT, 0);

	return (eof ? (char *)NULL : savestring(sess->the_line));
}

char *cli_line_stop(cli_session_t *sess, int eof)
{
	char *value = NULL;
	
	value = cli_line_teardown(sess, eof);
	if (sess->ops.exit_terminal)
		sess->ops.exit_terminal(sess);
	return value;
}

char *cli_read_line(cli_session_t *sess)
{
	int eof = 0;
	char *value = NULL;

#ifdef CONFIG_CLI_HISTORY
	if (sess->do_isearch) {
		cli_isearch_internal(sess);
		return value;
	}
#endif
	if (sess->input_hook) {
		sess->input_hook(sess);
	} else {
		eof = cli_read_char(sess);
		if (sess->done)
			value = cli_line_stop(sess, eof);
	}
	return value;
}

int cli_read_char(cli_session_t *sess)
{
	static int lastc;
	int c, lk, code;
	
	lastc = -1;
	lk = sess->last_command_was_kill;
	
	code = setjmp(sess->top_context);
	
	if (code) {
		sess = (cli_session_t *)code;
		rl_redisplay(sess);
		/* If we get here, we're not being called from something dispatched
		   from _rl_callback_read_char(), which sets up its own value of
		   readline_top_level (saving and restoring the old, of course), so
		   we can just return here. */
		if (RL_ISSTATE(sess, RL_STATE_CALLBACK))
			return (0);
	}
	
	if (sess->pending_input == 0) {
		/* Then initialize the argument and number of keys read. */
		sess->key_sequence_length = 0;
	}
	
	RL_SETSTATE(sess, RL_STATE_READCMD);
	c = rl_read_key(sess);
	RL_UNSETSTATE(sess, RL_STATE_READCMD);
	
	/* EOF typed to a non-blank line is a <NL>. */
	if (c == EOF && sess->end)
		c = NEWLINE;
	
	/* The character _rl_eof_char typed to blank line, and not as the
	   previous character is interpreted as EOF. */
	if (((c == sess->eof_char && lastc != c) || c == EOF) && !sess->end) {
		RL_SETSTATE(sess, RL_STATE_DONE);
		return (sess->done = 1);
	}
	
	lastc = c;
	_rl_dispatch(sess, (unsigned char)c, sess->keymap);
	
	/* If there was no change in sess->last_command_was_kill, then no kill
	   has taken place.  Note that if input is pending we are reading
	   a prefix command, so nothing has changed yet. */
	if (sess->pending_input == 0 && lk == sess->last_command_was_kill)
		sess->last_command_was_kill = 0;
	
	cli_char_cleanup(sess);
	
	return 0;
}

/* Set up the prompt and expand it.  Called from readline() and
   rl_callback_handler_install (). */
int rl_set_prompt(cli_session_t *sess, const char *prompt)
{
	if (prompt != sess->the_prompt) {
		xfree(sess->the_prompt);
		sess->the_prompt = prompt ? savestring(prompt) : (char *)NULL;
	}
	sess->visible_prompt_length = rl_expand_prompt(sess, sess->the_prompt);
	return 0;
}

void _rl_set_the_line(cli_session_t *sess)
{
	sess->the_line = sess->line_buffer;
}

/* Do the command associated with KEY in MAP.
   If the associated command is really a keymap, then read
   another key, and dispatch into that map. */
int _rl_dispatch(cli_session_t *sess, register int key, cli_keymap_t map)
{
	sess->dispatching_keymap = map;
	return _rl_dispatch_subseq(sess, key, map, 0);
}

static int _rl_subseq_getchar(cli_session_t *sess, int key)
{
	int k;
	
	if (key == ESC)
		RL_SETSTATE(sess, RL_STATE_METANEXT);
	RL_SETSTATE(sess, RL_STATE_MOREINPUT);
	k = rl_read_key(sess);
	RL_UNSETSTATE(sess, RL_STATE_MOREINPUT);
	if (key == ESC)
		RL_UNSETSTATE(sess, RL_STATE_METANEXT);
	return k;
}

static int _rl_subseq_result(cli_session_t *sess, int r,
			     cli_keymap_t map, int key, int got_subseq)
{
	cli_keymap_t m;
	int type, nt;
	cli_command_fn *func, *nf;
	
	if (r == -2) {
		/* We didn't match anything, and the keymap we're indexed into
		   shadowed a function previously bound to that prefix.  Call
		   the function.  The recursive call to _rl_dispatch_subseq has
		   already taken care of pushing any necessary input back onto
		   the input queue with _rl_unget_char. */
		m = sess->dispatching_keymap;
		type = m[ANYOTHERKEY].type;
		func = m[ANYOTHERKEY].function;
		if (type == ISFUNC && func == cli_insert) {
			/* If the function that was shadowed was self-insert, we
			   somehow need a keymap with map[key].func == self-insert.
			   Let's use this one. */
			nt = m[key].type;
			nf = m[key].function;
			
			m[key].type = type;
			m[key].function = func;
			r = _rl_dispatch(sess, key, m);
			m[key].type = nt;
			m[key].function = nf;
		} else
			r = _rl_dispatch(sess, ANYOTHERKEY, m);
	} else if (r && map[ANYOTHERKEY].function) {
		/* We didn't match (r is probably -1), so return something to
		   tell the caller that it should try ANYOTHERKEY for an
		   overridden function. */
		_rl_unget_char(key);
		sess->dispatching_keymap = map;
		return -2;
	} else if (r && got_subseq) {
		/* OK, back up the chain. */
		_rl_unget_char(key);
		sess->dispatching_keymap = map;
		return -1;
	}
	
	return r;
}

int _rl_dispatch_subseq(cli_session_t *sess, register int key, cli_keymap_t map, int got_subseq)
{
	int r, newkey;
	cli_command_fn *func;
	
	if (META_CHAR(key) && cli_main_config.convert_meta_chars) {
		if (map[ESC].type == ISKMAP) {
			map = FUNCTION_TO_KEYMAP(map, ESC);
			key = UNMETA(key);
			sess->key_sequence_length += 2;
			return (_rl_dispatch(sess, key, map));
		} else {
			cli_ding(sess);
		}
		return 0;
	}
	
	r = 0;
	switch (map[key].type) {
	case ISFUNC:
		func = map[key].function;
		if (func) {
			sess->dispatching = 1;
			RL_SETSTATE(sess, RL_STATE_DISPATCHING);
			(*map[key].function)(sess, 1, key);
			RL_UNSETSTATE(sess, RL_STATE_DISPATCHING);
			sess->dispatching = 0;
			
			/* If we have input pending, then the last command was a prefix
			   command.  Don't change the state of rl_last_func.  Otherwise,
			   remember the last command executed in this variable. */
			if (sess->pending_input == 0)
				sess->last_func = map[key].function;
		} else if (map[ANYOTHERKEY].function) {
			/* OK, there's no function bound in this map, but there is a
			   shadow function that was overridden when the current keymap
			   was created.  Return -2 to note  that. */
			_rl_unget_char(key);
			return -2;
		} else if (got_subseq) {
			/* Return -1 to note that we're in a subsequence, but  we don't
			   have a matching key, nor was one overridden.  This means
			   we need to back up the recursion chain and find the last
			   subsequence that is bound to a function. */
			_rl_unget_char(key);
			return -1;
		} else {
			__cli_abort(sess);
			return -1;
		}
		break;
		
	case ISKMAP:
		if (map[key].function != 0) {
			sess->key_sequence_length++;
			sess->dispatching_keymap = FUNCTION_TO_KEYMAP(map, key);
		
			newkey = _rl_subseq_getchar(sess, key);
			if (newkey < 0) {
				__cli_abort(sess);
				return -1;
			}
			
			r = _rl_dispatch_subseq(sess, newkey,
						sess->dispatching_keymap,
						got_subseq || map[ANYOTHERKEY].function);
			return _rl_subseq_result(sess, r, map, key, got_subseq);
		} else {
			__cli_abort(sess);
			return -1;
		}
		break;
    }
    
    return (r);
}

/* Initialize readline (and terminal if not already). */
int rl_initialize(cli_session_t *sess)
{
	/* If we have never been called before, initialize the
	   terminal and data structures. */
	if (!sess->initialized) {
		RL_SETSTATE(sess, RL_STATE_INITIALIZING);
		cli_init_line(sess);
		RL_UNSETSTATE(sess, RL_STATE_INITIALIZING);
		sess->initialized++;
		RL_SETSTATE(sess, RL_STATE_INITIALIZED);
	}
	
	/* Initalize the current line information. */
	cli_line_init_state(sess);
	
	/* We aren't done yet.  We haven't even gotten started yet! */
	sess->done = 0;
	RL_UNSETSTATE(sess, RL_STATE_DONE);

#ifdef CONFIG_CLI_HISTORY
	/* Tell the history routines what is going on. */
	_rl_start_using_history();
#endif
	
	/* Make the display buffer match the state of the line. */
	rl_reset_line_state(sess);
	
	/* No such function typed yet. */
	sess->last_func = (cli_command_fn *)NULL;
	
	/* Each line starts in insert mode (the default). */
	_rl_set_insert_mode(sess, RL_IM_DEFAULT, 1);
	return 0;
}

/* Initialize the entire state of the world. */
static void cli_init_line(cli_session_t *sess)
{
	/* Allocate data structures. */
	if (sess->line_buffer == 0)
		sess->line_buffer = (char *)xmalloc(sess->line_buffer_len = DEFAULT_BUFFER_SIZE);
	
	/* Initialize the terminal interface. */
	if (sess->terminal_name == 0)
		sess->terminal_name = getenv("TERM");
	cli_init_termio(sess, sess->terminal_name);

	if (sess->ops.default_bindings)
		sess->ops.default_bindings(sess);
	
	/* Try to bind a common arrow key prefix, if not already bound. */
	bind_arrow_keys(sess->keymap);

	/* If the completion parser's default word break characters haven't
	   been set yet, then do so now. */
	if (rl_completer_word_break_characters == (char *)NULL)
		rl_completer_word_break_characters = (char *)rl_basic_word_break_characters;
}

/* Try and bind the common arrow key prefixes after giving termcap and
   the inputrc file a chance to bind them and create `real' keymaps
   for the arrow key prefix. */
static void bind_arrow_keys(cli_keymap_t map)
{
#ifdef WIN32
	cli_bind_keyseq_map(map, "\033[0A", cli_get_previous_history);
	cli_bind_keyseq_map(map, "\033[0B", cli_backward_char);
	cli_bind_keyseq_map(map, "\033[0C", cli_forward_char);
	cli_bind_keyseq_map(map, "\033[0D", cli_get_next_history);
#endif
	
	cli_bind_keyseq_map(map, "\033[A", cli_get_previous_history);
	cli_bind_keyseq_map(map, "\033[B", cli_get_next_history);
	cli_bind_keyseq_map(map, "\033[C", cli_forward_char);
	cli_bind_keyseq_map(map, "\033[D", cli_backward_char);
	cli_bind_keyseq_map(map, "\033[H", cli_beg_of_line);
	cli_bind_keyseq_map(map, "\033[F", cli_end_of_line);
	
	cli_bind_keyseq_map(map, "\033OA", cli_get_previous_history);
	cli_bind_keyseq_map(map, "\033OB", cli_get_next_history);
	cli_bind_keyseq_map(map, "\033OC", cli_forward_char);
	cli_bind_keyseq_map(map, "\033OD", cli_backward_char);
	cli_bind_keyseq_map(map, "\033OH", cli_beg_of_line);
	cli_bind_keyseq_map(map, "\033OF", cli_end_of_line);
	
#ifdef WIN32
	cli_bind_keyseq_map(map, "\340H", cli_get_previous_history);
	cli_bind_keyseq_map(map, "\340P", cli_get_next_history);
	cli_bind_keyseq_map(map, "\340M", cli_forward_char);
	cli_bind_keyseq_map(map, "\340K", cli_backward_char);
#endif
}
