/*****************************************************************************
 * Copyright (C) 2004,2005,2006,2007 Katalix Systems Ltd
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 *
 *****************************************************************************/

#ifndef __CLI_PRIVATE_H_INCLUDE__
#define __CLI_PRIVATE_H_INCLUDE__

#include <sysdep.h>
#include <module.h>
#include <service.h>
#include <panic.h>
#include <strutl.h>
#include <uiserv.h>
#include <logger.h>

#ifdef WIN32
#include <conio.h>
#endif
#include <signal.h>
#include <locale.h>
#include <termcap.h>

#define READLINE_LIBRARY

#define _rl_stricmp strcasecmp
#define _rl_strnicmp strncasecmp
#define _rl_strpbrk strpbrk

#include <cli_api.h>

#define RL_IM_INSERT		1
#define RL_IM_OVERWRITE		0
#define RL_IM_DEFAULT		RL_IM_INSERT

/* Possible values for the found_quote flags word used by the completion
   functions.  It says what kind of (shell-like) quoting we found anywhere
   in the line. */
#define RL_QF_SINGLE_QUOTE	0x01
#define RL_QF_DOUBLE_QUOTE	0x02
#define RL_QF_BACKSLASH		0x04
#define RL_QF_OTHER_QUOTE	0x08

/* Possible values for _rl_bell_preference. */
#define NO_BELL 0
#define AUDIBLE_BELL 1
#define VISIBLE_BELL 2

/* Default readline line buffer length. */
#define DEFAULT_BUFFER_SIZE 256

#define SWAP(s, e)  do { int t; t = s; s = e; e = t; } while (0)

/* ============================================================ *
 * text operations
 * ============================================================ */
#ifdef CTRL
#  undef CTRL
#endif
#ifdef UNCTRL
#  undef UNCTRL
#endif

/* Some character stuff. */
#define control_character_threshold 0x020   /* Smaller than this is control. */
#define control_character_mask 0x1f	    /* 0x20 - 1 */
#define meta_character_threshold 0x07f	    /* Larger than this is Meta. */
#define control_character_bit 0x40	    /* 0x000000, must be off. */
#define meta_character_bit 0x080	    /* x0000000, must be on. */
#define largest_char 255		    /* Largest character value. */

#define CTRL_CHAR(c) ((c) < control_character_threshold && (((c) & 0x80) == 0))
#define META_CHAR(c) ((c) > meta_character_threshold && (c) <= largest_char)

#define CTRL(c) ((c) & control_character_mask)
#define META(c) ((c) | meta_character_bit)

#define UNMETA(c) ((c) & (~meta_character_bit))
#define UNCTRL(c) _rl_to_upper(((c)|control_character_bit))

#if defined STDC_HEADERS || (!defined (isascii) && !defined (HAVE_ISASCII))
#  define IN_CTYPE_DOMAIN(c) 1
#else
#  define IN_CTYPE_DOMAIN(c) isascii(c)
#endif

#if !defined (isxdigit) && !defined (HAVE_ISXDIGIT)
#  define isxdigit(c)   (isdigit((c)) || ((c) >= 'a' && (c) <= 'f') || ((c) >= 'A' && (c) <= 'F'))
#endif

#if defined (CTYPE_NON_ASCII)
#  define NON_NEGATIVE(c) 1
#else
#  define NON_NEGATIVE(c) ((unsigned char)(c) == (c))
#endif

/* Some systems define these; we want our definitions. */
#undef ISPRINT

/* Beware:  these only work with single-byte ASCII characters. */
#define ISALNUM(c)	(IN_CTYPE_DOMAIN (c) && isalnum (c))
#define ISALPHA(c)	(IN_CTYPE_DOMAIN (c) && isalpha (c))
#define ISDIGIT(c)	(IN_CTYPE_DOMAIN (c) && isdigit (c))
#define ISLOWER(c)	(IN_CTYPE_DOMAIN (c) && islower (c))
#define ISPRINT(c)	(IN_CTYPE_DOMAIN (c) && isprint (c))
#define ISUPPER(c)	(IN_CTYPE_DOMAIN (c) && isupper (c))
#define ISXDIGIT(c)	(IN_CTYPE_DOMAIN (c) && isxdigit (c))

#define _rl_lowercase_p(c)	(NON_NEGATIVE(c) && ISLOWER(c))
#define _rl_uppercase_p(c)	(NON_NEGATIVE(c) && ISUPPER(c))
#define _rl_digit_p(c)		((c) >= '0' && (c) <= '9')

#define _rl_pure_alphabetic(c)	(NON_NEGATIVE(c) && ISALPHA(c))
#define ALPHABETIC(c)		(NON_NEGATIVE(c) && ISALNUM(c))

#ifndef _rl_to_upper
#  define _rl_to_upper(c) (_rl_lowercase_p(c) ? toupper((unsigned char)c) : (c))
#  define _rl_to_lower(c) (_rl_uppercase_p(c) ? tolower((unsigned char)c) : (c))
#endif

#ifndef _rl_digit_value
#  define _rl_digit_value(x) ((x) - '0')
#endif

#ifndef _rl_isident
#  define _rl_isident(c) (ISALNUM(c) || (c) == '_')
#endif

#ifndef ISOCTAL
#  define ISOCTAL(c)	((c) >= '0' && (c) <= '7')
#endif
#define OCTVALUE(c)	((c) - '0')

#define HEXVALUE(c) \
  (((c) >= 'a' && (c) <= 'f') \
  	? (c)-'a'+10 \
  	: (c) >= 'A' && (c) <= 'F' ? (c)-'A'+10 : (c)-'0')

#ifndef NEWLINE
#define NEWLINE '\n'
#endif

#ifndef RETURN
#define RETURN CTRL('M')
#endif

#ifndef RUBOUT
#define RUBOUT 0x7f
#endif

#ifndef TAB
#define TAB '\t'
#endif

#ifdef ABORT_CHAR
#undef ABORT_CHAR
#endif
#define ABORT_CHAR CTRL('G')

#ifdef PAGE
#undef PAGE
#endif
#define PAGE CTRL('L')

#ifdef SPACE
#undef SPACE
#endif
#define SPACE ' '	/* XXX - was 0x20 */

#ifdef ESC
#undef ESC
#endif
#define ESC CTRL('[')

#define _rl_char_value(buf,ind)	((buf)[(ind)])
#define _rl_walphabetic(c)	(rl_alphabetic(c))
#define _rl_to_wupper(c)	(_rl_to_upper(c))
#define _rl_to_wlower(c)	(_rl_to_lower(c))

#define MB_NEXTCHAR(b,s,c,f)	((s) + (c))
#define MB_PREVCHAR(b,s,f)	((s) - 1)
#define MB_INVALIDCH(x)		(0)
#define MB_NULLWCH(x)		(0)

#if !defined(STREQ)
#define STREQ(a, b)	(((a)[0] == (b)[0]) && (strcmp ((a), (b)) == 0))
#define STREQN(a, b, n) (((n) == 0) ? (1) \
				    : ((a)[0] == (b)[0]) && (strncmp((a), (b), (n)) == 0))
#endif

#ifndef savestring
#define savestring(x) strcpy(xmalloc(1 + strlen (x)), (x))
#endif

#ifndef whitespace
#define whitespace(c) (((c) == ' ') || ((c) == '\t'))
#endif

/* Possible definitions for history starting point specification. */
#define ANCHORED_SEARCH 1
#define NON_ANCHORED_SEARCH 0

#define CLI_MAX_ARGC		200
#define CLI_MAX_KEYWORDS	100

/* search types */
#define RL_SEARCH_ISEARCH	0x01		/* incremental search */
#define RL_SEARCH_NSEARCH	0x02		/* non-incremental search */
#define RL_SEARCH_CSEARCH	0x04		/* intra-line char search */

/* search flags */
#define SF_REVERSE		0x01
#define SF_FOUND		0x02
#define SF_FAILED		0x04

/* Callback data for reading numeric arguments */
#define NUM_SAWMINUS	0x01
#define NUM_SAWDIGITS	0x02
#define NUM_READONE	0x04

typedef struct  __rl_search_context {
	int type;
	int sflags;
	
	char *search_string;
	int search_string_index;
	int search_string_size;
	
	char **lines;
	char *allocated_line;    
	int hlen;
	int hindex;
	
	int save_point;
	int save_mark;
	int save_line;
	int last_found_line;
	char *prev_line_found;
	
	cli_undo_t *save_undo_list;
	
	int history_pos;
	int direction;
	
	int lastc;
	
	char *sline;
	int sline_len;
	int sline_index;
	
	const char  *search_terminators;
} _rl_search_cxt;

typedef struct _cli_config_t {
	const char *prompt;
	int max_kills;

	int mark_modified_lines;
	int bell_type;
	/* Non-zero means to convert characters with the meta bit set to
	   escape-prefixed characters so we can indirect through
	   emacs_meta_keymap or vi_escape_keymap. */
	int convert_meta_chars;
} cli_config_t;

typedef struct _cli_matches_t {
	char **name;
	char **desc;
	int *type;
#define CLI_MATCH_NONE		0x00
#define CLI_MATCH_SCHEMA	0x01
#define CLI_MATCH_ENTRY		0x02
#define CLI_MATCH_COMMAND	0x03
	int do_describe;
	int matches;
	int size;
} cli_matches_t;

/* ============================================================ *
 * logging operations
 * ============================================================ */
#define CLI_LOG_CRIT		LOG_EMERG
#define CLI_LOG_FAIL		LOG_CRIT
#define CLI_LOG_ERR		LOG_ERR
#define CLI_LOG_WARN		LOG_WARNING
#define CLI_LOG_INFO		LOG_INFO
#define CLI_LOG_DEBUG		LOG_DEBUG

void cli_log(int level, const char *format, ...);

/* ============================================================ *
 * matches operations
 * ============================================================ */
int cli_matches_compute_lcd(cli_matches_t *list, const char *text);
void cli_matches_free(cli_matches_t *list);
char **cli_matches_done(cli_session_t *sess, cli_matches_t *list,
			const char *text);
cli_matches_t *cli_matches_init(int describe);
void cli_matches_push(cli_matches_t *list, const char *name,
		      int type, const char *desc);

extern cli_config_t cli_main_config;
extern int history_offset;
extern int rl_byte_oriented;
extern int rl_display_fixed;
extern int _rl_page_completions;
extern int _rl_vis_botlin;
extern int _rl_last_c_pos;
extern const char *rl_display_prompt;
extern char *_rl_isearch_terminators;
extern _rl_search_cxt *_rl_iscxt;
extern int _rl_history_preserve_point;
extern int _rl_history_saved_point;
extern _rl_search_cxt *_rl_nscxt;

void *xmalloc(size_t);
void *xrealloc(void *, size_t);
void xfree(void *);

void _rl_free_history_entry(HIST_ENTRY *);
void _rl_set_screen_size(cli_session_t *, int, int);
char _rl_find_completion_word(cli_session_t *, int *, int *);
void _rl_free_match_list(char **);
char *_rl_strip_prompt(cli_session_t *, char *);
void _rl_move_cursor_relative(cli_session_t *, int, const char *);
void _rl_move_vert(cli_session_t *, int);
void _rl_save_prompt(void);
void _rl_restore_prompt(void);
void _rl_erase_at_end_of_line(cli_session_t *, int);
void _rl_clear_to_eol(cli_session_t *sess, int);
void _rl_clear_screen(cli_session_t *sess);
void _rl_update_final(cli_session_t *sess);
void _rl_redisplay_after_sigwinch(cli_session_t *sess);
void _rl_clean_up_for_exit(cli_session_t *sess);
void _rl_erase_entire_line(cli_session_t *sess);
int _rl_any_typein(void);
int _rl_input_available(cli_session_t *sess);
void _rl_insert_typein(cli_session_t *, int);
int _rl_unget_char(int);
_rl_search_cxt *_rl_scxt_alloc(int, int);
void _rl_scxt_dispose(_rl_search_cxt *, int);
int _rl_isearch_dispatch(cli_session_t *, _rl_search_cxt *, int);
int _rl_search_getchar(cli_session_t *, _rl_search_cxt *);
void _rl_start_using_history(void);
void _rl_set_insert_mode(cli_session_t *, int, int);
void _rl_set_the_line(cli_session_t *);
int _rl_dispatch(cli_session_t *, int, cli_keymap_t);
int _rl_dispatch_subseq(cli_session_t *, int, cli_keymap_t, int);
void _rl_fix_point(cli_session_t *, int);
int _rl_replace_text(cli_session_t *, const char *, int, int);
int _rl_insert_char(cli_session_t *, int, int);
int _rl_overwrite_char(cli_session_t *, int, int);
int _rl_overwrite_rubout(cli_session_t *, int, int);
int _rl_rubout_char(cli_session_t *, int, int);
cli_undo_t *_rl_copy_undo_entry(cli_undo_t *);
cli_undo_t *_rl_copy_undo_list(cli_undo_t *);
int __cli_abort(cli_session_t *sess);
char *_rl_strindex(const char *, const char *);
int _rl_qsort_string_compare(char **, char **);
void replace_history_data(int, histdata_t *, histdata_t *);
int _rl_internal_pager(cli_session_t *, int);

void sh_set_lines_and_columns(int lines, int cols);
int sh_unset_nodelay_mode(int fd);

void cli_line_start(cli_session_t *sess);
char *cli_line_stop(cli_session_t *sess, int eof);
char *cli_read_line(cli_session_t *sess);
void cli_banner_start(cli_session_t *sess);
void cli_line_init_state(cli_session_t *);

/* ============================================================ *
 * keymap operations
 * ============================================================ */
#define ISFUNC 0
#define ISKMAP 1

#define FUNCTION_TO_KEYMAP(map, key)	(cli_keymap_t)(map[key].function)
#define KEYMAP_TO_FUNCTION(data)	(cli_command_fn *)(data)

typedef cli_kmentry_t cli_kmarray_t[KEYMAP_SIZE];
extern cli_kmarray_t cli_standard_keymap;

cli_keymap_t cli_keymap_new(void);
cli_keymap_t cli_keymap_copy(cli_keymap_t map);
void cli_keymap_free(cli_keymap_t);
int cli_translate_keyseq(cli_keymap_t map, const char *seq,
			 char *array, int *len);
char *cli_untranslate_keyseq(int);

/* ============================================================ *
 * terminal operations
 * ============================================================ */
void cli_screen_size(cli_session_t *, int, int);
int cli_init_termio(cli_session_t *, const char *);

int cli_buffer_to_argv(char *start, char *end, char *argv[], int argv_len);
void cli_clear_history(void);

int cli_isearch_internal(cli_session_t *sess);

int cli_term_start(void);
void cli_term_stop(void);

#endif /* __CLI_PRIVATE_H_INCLUDE__ */
