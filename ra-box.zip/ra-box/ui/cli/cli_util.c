#include "cli_priv.h"

static void cli_memory_error(const char *fname)
{
	fprintf(stderr, "%s: out of virtual memory\n", fname);
	panic();
}

/* Return a pointer to free()able block of memory large enough
   to hold BYTES number of bytes.  If the memory cannot be allocated,
   print an error message and abort. */
void *xmalloc(size_t bytes)
{
	void *temp;
	
	temp = malloc(bytes);
	if (temp == 0)
		cli_memory_error("xmalloc");
	return (temp);
}

void *xrealloc(void *pointer, size_t bytes)
{
	void *temp;
	
	temp = pointer ? realloc(pointer, bytes) : malloc(bytes);
	
	if (temp == 0)
		cli_memory_error("xrealloc");
	return (temp);
}

/* Use this as the function to call when adding unwind protects so we
   don't need to know what free() returns. */
void xfree(void *string)
{
	if (string) free(string);
}

int rl_alphabetic(int c)
{
	return ALPHABETIC(c);
}

/* How to abort things. */
int __cli_abort(cli_session_t *sess)
{
	cli_ding(sess);
	rl_clear_message(sess);
	rl_clear_pending_input(sess);
	
	sess->last_func = (cli_command_fn *)NULL;
	longjmp(sess->top_context, (int)sess);
	return (0);
}

int cli_abort(cli_session_t *sess, int count, int key)
{
	return (__cli_abort(sess));
}

/* Return a copy of the string between FROM and TO.
   FROM is inclusive, TO is not. */
char *rl_copy_text(cli_session_t *sess, int from, int to)
{
	register int length;
	char *copy;
	
	/* Fix it if the caller is confused. */
	if (from > to)
		SWAP (from, to);
	
	length = to - from;
	copy = (char *)xmalloc (1 + length);
	strncpy(copy, sess->line_buffer + from, length);
	copy[length] = '\0';
	return (copy);
}

/* Increase the size of RL_LINE_BUFFER until it has enough space to hold
   LEN characters. */
void rl_extend_line_buffer(cli_session_t *sess, int len)
{
	while (len >= sess->line_buffer_len) {
		sess->line_buffer_len += DEFAULT_BUFFER_SIZE;
		sess->line_buffer = (char *)xrealloc(sess->line_buffer, sess->line_buffer_len);
	}
	
	_rl_set_the_line(sess);
}

/* Determine if s2 occurs in s1.  If so, return a pointer to the
   match in s1.  The compare is case insensitive. */
char *_rl_strindex(const char *s1, const char *s2)
{
	register int i, l, len;
	
	for (i = 0, l = strlen (s2), len = strlen (s1); (len - i) >= l; i++)
		if (_rl_strnicmp(s1 + i, s2, l) == 0)
			return ((char *) (s1 + i));
	return ((char *)NULL);
}

/* Stupid comparison routine for qsort () ing strings. */
int _rl_qsort_string_compare(char **s1, char **s2)
{
#if defined (HAVE_STRCOLL)
	return (strcoll (*s1, *s2));
#else
	int result;
	
	result = **s1 - **s2;
	if (result == 0)
		result = strcmp (*s1, *s2);
	
	return result;
#endif
}

int sh_unset_nodelay_mode(int fd)
{
#if defined (HAVE_FCNTL)
	int flags, bflags;
	
	if ((flags = fcntl(fd, F_GETFL, 0)) < 0)
		return -1;
	
	bflags = 0;
	
#ifdef O_NONBLOCK
	bflags |= O_NONBLOCK;
#endif
	
#ifdef O_NDELAY
	bflags |= O_NDELAY;
#endif
	
	if (flags & bflags) {
		flags &= ~bflags;
		return (fcntl(fd, F_SETFL, flags));
	}
#endif
	return 0;
}

/* Nonzero if the integer type T is signed.  */
#define TYPE_SIGNED(t) (! ((t) 0 < (t) -1))

/* Bound on length of the string representing an integer value of type T.
   Subtract one for the sign bit if T is signed;
   302 / 1000 is log10 (2) rounded up;
   add one for integer division truncation;
   add one more for a minus sign if t is signed.  */
#define INT_STRLEN_BOUND(t) \
  ((sizeof(t) * CHAR_BIT - TYPE_SIGNED (t)) * 302 / 1000 \
   + 1 + TYPE_SIGNED(t))

/* Set the environment variables LINES and COLUMNS to lines and cols,
   respectively. */
void sh_set_lines_and_columns(int lines, int cols)
{
#if defined(HAVE_SETENV) || defined(HAVE_PUTENV)
	char *b = NULL;
#endif
	
#if defined(HAVE_SETENV)
	b = (char *)xmalloc(INT_STRLEN_BOUND(int) + 1);
	sprintf(b, "%d", lines);
	setenv("LINES", b, 1);
	free(b);
	
	b = (char *)xmalloc(INT_STRLEN_BOUND (int) + 1);
	sprintf(b, "%d", cols);
	setenv("COLUMNS", b, 1);
	free(b);
#else /* !HAVE_SETENV */
#  if defined(HAVE_PUTENV)
	b = (char *)xmalloc(INT_STRLEN_BOUND(int) + sizeof("LINES=") + 1);
	sprintf(b, "LINES=%d", lines);
	putenv(b);
	
	b = (char *)xmalloc(INT_STRLEN_BOUND(int) + sizeof("COLUMNS=") + 1);
	sprintf(b, "COLUMNS=%d", cols);
	putenv(b);
#  endif /* HAVE_PUTENV */
#endif /* !HAVE_SETENV */
}
