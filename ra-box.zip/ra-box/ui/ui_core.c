#include "ui_priv.h"

DECLARE_LIST(ui_services);
DECLARE_LIST(ui_sessions);

#define UI_INPUT_STOPPED	0x00
#define UI_INPUT_STARTED	0x01
#define UI_INPUT_STOPPING	0x02
#define UI_INPUT_STARTING	0x03

typedef struct _ui_control_t {
	list_t link;
	ui_service_t *input;
	int state;
} ui_control_t;

#define for_each_service(d)			\
	list_for_each_entry(ui_control_t, d, &ui_services, link)

int ui_begin_session(ui_session_t *sess)
{
	sess->root_schema = &ui_schema_tree;
	sess->root_object = &ui_object_tree;
	list_init(&sess->tables);
	sess->result_table = NULL;
	list_init(&sess->link);
	list_insert_before(&sess->link, &ui_sessions);
	return 0;
}

void ui_end_session(ui_session_t *sess)
{
	if (sess) {
		list_delete_init(&sess->link);
	}
}

static ui_control_t *ui_input_by_name(const char *name)
{
	ui_control_t *svc;

	for_each_service(svc) {
		if (strcasecmp(svc->input->name, name) == 0)
			return svc;
	}
	return NULL;
}

int ui_register_service(ui_service_t *input)
{
	ui_control_t *svc;

	if (input) {
		if (ui_input_by_name(input->name)) {
			log_kern(LOG_ERR,
				 "UI: already registered input: input=%s",
				 input->name);
			return -1;
		}

		svc = malloc(sizeof (ui_control_t));
		if (svc) {
			memset(svc, 0, sizeof (ui_control_t));
			
			svc->input = input;
			svc->state = UI_INPUT_STOPPED;
			list_init(&svc->link);
			list_insert_before(&svc->link, &ui_services);
		}
	}
	return 0;
}

void ui_unregister_service(ui_service_t *input)
{
	ui_control_t *svc;

	if (input) {
		svc = ui_input_by_name(input->name);
		if (svc) {
			list_delete_init(&svc->link);
			free(svc);
		}
	}
}

int ui_user_start(void)
{
	ui_control_t *svc;

	for_each_service(svc) {
		if (svc->state == UI_INPUT_STOPPED && svc->input->start) {
			svc->state = UI_INPUT_STARTING;
			if (svc->input->start()) {
				log_kern(LOG_ERR,
					 "UI: starting input failure, ui=%s",
					 svc->input->name);
				svc->state = UI_INPUT_STOPPED;
			} else {
				svc->state = UI_INPUT_STARTED;
			}
		}
	}
	return 0;
}

void ui_user_stop(void)
{
	ui_control_t *svc;

	for_each_service(svc) {
		if (svc->state == UI_INPUT_STARTED && svc->input->stop) {
			svc->state = UI_INPUT_STOPPING;
			svc->input->stop();
			log_kern(LOG_INFO,
				 "UI: starting input success, ui=%s",
				 svc->input->name);
			svc->state = UI_INPUT_STOPPED;
		}
	}
}

modlinkage int __init ui_init(void)
{
	ui_schema_init();
	ui_user_init();
	return 0;
}

modlinkage void __exit ui_exit(void)
{
	ui_user_exit();
	ui_schema_exit();
}

core_initcall(ui_init);
core_exitcall(ui_exit);
