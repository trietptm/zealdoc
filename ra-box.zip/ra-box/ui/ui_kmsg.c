#include <sysdep.h>
#include <logger.h>
#include <stdio.h>
#include <stdlib.h>
#include <strutl.h>
#include <module.h>
#include <service.h>
#include <eloop.h>
#include <fsserv.h>
#include <udev.h>

#define _PATH_KMSG		"/dev/kmsg"

#define KMSG_SERVICE_DESC	"Linux kernel messaging"
#define KMSG_BUFFER_SIZE	4096
#define KMSG_LINE_SIZE		1000
#define KMSG_PARSING_TEXT	0
#ifdef CONFIG_KMSG_LOG_LEVEL
#define KMSG_LOG_LEVEL	CONFIG_KMSG_LOG_LEVEL
#else
#define KMSG_LOG_LEVEL		4
#endif
#ifdef WIN32
#define KMSG_PORT		54323
#endif

/*
 * Commands to ksyslog:
 *
 * 	0 -- Close the log.  Currently a NOP.
 * 	1 -- Open the log. Currently a NOP.
 * 	2 -- Read from the log.
 * 	3 -- Read all messages remaining in the ring buffer.
 * 	4 -- Read and clear all messages remaining in the ring buffer
 * 	5 -- Clear ring buffer.
 * 	6 -- Disable printk's to console
 * 	7 -- Enable printk's to console
 *	8 -- Set level of messages printed to console
 *	9 -- Return number of unread characters in the log buffer
 *     10 -- Return size of the log buffer
 */
#ifdef WIN32
int ksyslog(int type, char *buf, int len)
{
	return 0;
}
#else
#if !defined(__GLIBC__)
# define __NR_ksyslog __NR_syslog
_syscall3(int,ksyslog,int, type, char *, buf, int, len);
#else
#include <sys/klog.h>
#define ksyslog klogctl
#endif
#endif

static int kmsg_log_fd = -1;

static void kmsg_fd_close(void);
static int kmsg_fd_open(void);
static void kmsg_close(void);
static int kmsg_open(void);
static void kmsg_line_parse(char *ptr, int len);

static void kmsg_fd_event(int sock, void *eloop, void *user)
{
	int remain = ksyslog(9, 0, 0);

	if (remain <= 0) {
		log_kern(LOG_ERR, "KMSG: no unread characters event");
		goto restart;
	} else {
		int rdcnt, len;
		char log_buffer[KMSG_BUFFER_SIZE];

		/* while (remain > 0) { */
			len = MIN(remain, KMSG_BUFFER_SIZE);

			rdcnt = read(sock, log_buffer, 1);
			if (rdcnt <= 0) {
				log_kern(LOG_ERR, "KMSG: failed to read characters");
				goto restart;
			}

			kmsg_line_parse(log_buffer, rdcnt);
			remain -= rdcnt;
		/* } */
	}

	return;
restart:
	kmsg_close();
	kmsg_open();
}

#ifdef WIN32
static int kmsg_fd_open(void)
{
	struct sockaddr_in saddr;

	kmsg_log_fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (kmsg_log_fd < 0) {
		return -1;
	}

	memset(&saddr, 0, sizeof(saddr));
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(KMSG_PORT);
	saddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	if (bind(kmsg_log_fd, (struct sockaddr *) &saddr, sizeof(saddr)) < 0) {
		closesocket(kmsg_log_fd);
		kmsg_log_fd = -1;
		return -1;
	}

	eloop_register_read_sock(NULL, kmsg_log_fd, kmsg_fd_event, NULL, NULL);
	return 0;
}
#else
static int kmsg_fd_open(void)
{
	if (kmsg_log_fd >= 0) {
		kmsg_fd_close();
	}

	kmsg_log_fd = open(_PATH_KLOG, O_RDONLY);
	if (kmsg_log_fd < 0) {
		return -1;
	}
	eloop_register_read_sock(NULL, kmsg_log_fd, kmsg_fd_event, NULL, NULL);
	return 0;
}
#endif

static void kmsg_fd_close(void)
{
	if (kmsg_log_fd >= 0) {
		eloop_unregister_read_sock(NULL, kmsg_log_fd);
		closesocket(kmsg_log_fd);
		kmsg_log_fd = -1;
	}
}

static void kmsg_close(void)
{
	/* close the log */
	ksyslog(0, 0, 0);

        /* shutdown the log sources */
	kmsg_fd_close();
	log_kern(LOG_INFO, "KMSG: kernel messaging stopped");
}

static int kmsg_open(void)
{
	int res;

	/* set level of messages printed to console */
	if ((ksyslog(8, NULL, KMSG_LOG_LEVEL) < 0) &&
	    (errno == EINVAL)) {
		log_kern(LOG_WARNING,
			 "KMSG: failed to set kernel messaging level");
	}

	/* disable printk's to console */
	ksyslog(6, NULL, 0);
	/* open the log */
	ksyslog(1, NULL, 0);

	res = kmsg_fd_open();
	if (res != 0) {
		log_kern(LOG_ERR, "KMSG: failed to open kmsg file");
		return -1;
	}

	log_kern(LOG_INFO, "KMSG: kernel messaging started");
	return 0;
}

/* Copy characters from ptr to line until a char in the delim
 * string is encountered or until min( space, len ) chars have
 * been copied.
 *
 * Returns the actual number of chars copied.
 */
static int kmsg_buf_copyin(char *line, int space, const char *ptr,
			   int len, const char *delim)
{
	int i;
	int count;
	
	count = len < space ? len : space;
	
	for (i = 0; i < count && !strchr(delim, *ptr); i++) {
		*line++ = *ptr++;
	}
	return i;
}

/* Messages are separated by "\n".  Messages longer than
 * KMSG_LINE_SIZE are broken up.
 *
 * Kernel symbols show up in the input buffer as : "[<aaaaaa>]",
 * where "aaaaaa" is the address.  These are replaced with
 * "[symbolname+offset/size]" in the output line - symbolname,
 * offset, and size come from the kernel symbol table.
 *
 * If a kernel symbol happens to fall at the end of a message close
 * in length to KMSG_LINE_SIZE, the symbol will not be expanded.
 * (This should never happen, since the kernel should never generate
 * messages that long.
 *
 * To preserve the original addresses, lines containing kernel symbols
 * are output twice.  Once with the symbols converted and again with the
 * original text.  Just in case somebody wants to run their own Oops
 * analysis on the syslog, e.g. ksymoops.
 */
static void kmsg_line_parse(char *ptr, int len)
{
	static char line_buff[KMSG_LINE_SIZE];
	
	static char *line =line_buff;
	int parse_state = KMSG_PARSING_TEXT;
	static int space = sizeof(line_buff)-1;
	int delta = 0;              /* number of chars copied        */
	char *save_ptr = ptr;       /* save start of input line */
	int save_len = len;         /* save length at start of input line */
	
	while (len > 0) {
		if (space == 0) {
			/* Line too long.  Start a new line */
			*line = 0;   /* force null terminator */
			
			log_kern(LOG_INFO, "KERN: %s", line_buff);
			line  = line_buff;
			space = sizeof(line_buff)-1;
			parse_state = KMSG_PARSING_TEXT;
			save_ptr = ptr;
			save_len = len;
		}

		switch (parse_state) {
		case KMSG_PARSING_TEXT:
		       delta = kmsg_buf_copyin(line, space, ptr, len, "\n[%");
		       line  += delta;
		       ptr   += delta;
		       space -= delta;
		       len   -= delta;
		       
		       if (space == 0 || len == 0) {
			       break;  /* full line_buff or end of input buffer */
		       }
		       
		       if (*ptr == '\0') {
			       ptr++;	/* skip zero byte */
			       space -= 1;
			       len   -= 1;
			       break;
		       }
		       
		       if (*ptr == '\n') {
			       ptr++;	/* skip newline */
			       space -= 1;
			       len   -= 1;
			       
			       *line = 0;  /* force null terminator */
			       log_kern(LOG_INFO, "KERN: %s", line_buff);
			       line  = line_buff;
			       space = sizeof(line_buff)-1;
			       break;
		       }
		       if (*ptr == '[') {
			       /* possible kernel symbol */
			       *line++ = *ptr++;
			       space -= 1;
			       len   -= 1;
			       break;
		       }
		       if (*ptr == '%') {
			       /* dangerous printf marker */
			       delta = 0;
			       while (len && *ptr == '%') {
				       /* copy it in */
				       *line++ = *ptr++;
				       space -= 1;
				       len   -= 1;
				       delta++;
			       }
			       if (delta % 2) {
				       /* odd amount of %'s */
				       if (space) {
					       /* so simply add one */
					       *line++ = '%';
					       space -= 1;
				       } else {
					       /* remove the last one / terminate the string */
					       *line++ = '\0';
				       }
				       
			       }
		       }
		       break;
		default:
			/* can't get here! */
			parse_state = KMSG_PARSING_TEXT;
			
		}
	}
    
	return;
}

#ifdef CONFIG_LOG_KMSG_DEV
static int kmsg_udev_event(notify_t *nb,
			   unsigned long event, void *data);

static notify_t kmsg_udev_notify = {
	NULL,
	kmsg_udev_event,
	9,
};

static int kmsg_udev_event(notify_t *nb,
			   unsigned long event, void *data)
{
	udev_node_t *node = (udev_node_t *)data;
	if (strcmp(node->filename, _PATH_KMSG) != 0)
		return 0;
	switch (event) {
	case UDEV_CREATE:
		kmsg_open();
		break;
	case UDEV_DELETE:
		kmsg_close();
		break;
	}
	return 0;
}
#endif

static int kmsg_start(void)
{
#ifdef CONFIG_LOG_KMSG_DEV
	return udev_register_notify(&kmsg_udev_notify);
#else
	return kmsg_open();
#endif
}

static void kmsg_stop(void)
{
	kmsg_close();
#ifdef CONFIG_LOG_KMSG_DEV
	udev_unregister_notify(&kmsg_udev_notify);
#endif
}

service_t kmsg_service = {
	KMSG_SERVICE_NAME,
	KMSG_SERVICE_DESC,
	SERVICE_UP_ALWAYS,
	SERVICE_FLAG_SYSTEM,
	LIST_HEAD_INIT(kmsg_service.depends),
	kmsg_start,
	kmsg_stop,
};

handle_t kmsg_handle;

static int __init kmsg_serv_init(void)
{
	kmsg_handle = register_service(&kmsg_service);
#ifdef CONFIG_LOG_KMSG_DEV
	/* require /dev/kmsg mounted */
	service_register_depend(KMSG_SERVICE_NAME, UDEV_SERVICE_NAME);
#else
	/* require /proc mounted */
	service_register_depend(KMSG_SERVICE_NAME, ROOTFS_SERVICE_NAME);
#endif
	return kmsg_handle ? 0 : -1;
}

static void __exit kmsg_serv_exit(void)
{
	unregister_service(kmsg_handle);
}

modlinkage int __init kmsg_init(void)
{
	kmsg_serv_init();
	return 0;
}

modlinkage void __exit kmsg_exit(void)
{
	kmsg_serv_exit();
}

core_initcall(kmsg_init);
core_exitcall(kmsg_exit);
