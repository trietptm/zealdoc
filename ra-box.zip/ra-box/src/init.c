#include "main.h"

#ifndef CONFIG_MODULE
int __init kmsg_init(void);
void __exit kmsg_exit(void);
int __init ui_init(void);
void __exit ui_exit(void);
int __init net_init(void);
void __exit net_exit(void);
int __init fs_init(void);
void __exit fs_exit(void);
int __init udev_init(void);
void __exit udev_exit(void);
int __init rtnl_init(void);
void __exit rtnl_exit(void);
int __init rtc_init(void);
void __exit rtc_exit(void);

/* special modules */
int __init dns_init(void);
void __exit dns_exit(void);
int __init dhcp_init(void);
void __exit dhcp_exit(void);
int __init radius_init(void);
void __exit radius_exit(void);
int __init eap_init(void);
void __exit eap_exit(void);
int __init vlan_init(void);
void __exit vlan_exit(void);
int __init bridge_init(void);
void __exit bridge_exit(void);
int __init ppp_init(void);
void __exit ppp_exit(void);
int __init l2tp_init(void);
void __exit l2tp_exit(void);
int __init pppoe_init(void);
void __exit pppoe_exit(void);
int __init crypto_init(void);
void __exit crypto_exit(void);
int __init syslog_init(void);
void __exit syslog_exit(void);
int __init cli_init(void);
void __exit cli_exit(void);
int __init isakmp_init(void);
void __exit isakmp_exit(void);
int __init ipsec_init(void);
void __exit ipsec_exit(void);
int __init ike_init(void);
void __exit ike_exit(void);

/* network appliances */
int __init appl_vtss_init(void);
void __exit appl_vtss_exit(void);
int __init appl_star_init(void);
void __exit appl_star_exit(void);

int __init eap_md5_init(void);
void __exit eap_md5_exit(void);
int __init eap_mschapv2_init(void);
void __exit eap_mschapv2_exit(void);
int __init eap_peap_init(void);
void __exit eap_peap_exit(void);
int __init eap_tls_init(void);
void __exit eap_tls_exit(void);
int __init dhcp_client_init(void);
void __exit dhcp_client_exit(void);
int __init dhcp_server_init(void);
void __exit dhcp_server_exit(void);
int __init dhcp_pcap_init(void);
void __exit dhcp_pcap_exit(void);
int __init l2tp_pppox_init(void);
void __exit l2tp_pppox_exit(void);
int __init l2tp_dgram_init(void);
void __exit l2tp_dgram_exit(void);
int __init l2tp_lac_init(void);
void __exit l2tp_lac_exit(void);
int __init l2tp_lns_init(void);
void __exit l2tp_lns_exit(void);
int __init l2tp_nic_init(void);
void __exit l2tp_nic_exit(void);
int __init l2tp_nac_init(void);
void __exit l2tp_nac_exit(void);
int __init ppp_ipcp_init(void);
void __exit ppp_ipcp_exit(void);
int __init ppp_bcp_init(void);
void __exit ppp_bcp_exit(void);
int __init ppp_ccp_init(void);
void __exit ppp_ccp_exit(void);
int __init ppp_mppce_init(void);
void __exit ppp_mppce_exit(void);
int __init ppp_lqr_init(void);
void __exit ppp_lqr_exit(void);
int __init ppp_pap_init(void);
void __exit ppp_pap_exit(void);
int __init ppp_chap_init(void);
void __exit ppp_chap_exit(void);
int __init ppp_md5_init(void);
void __exit ppp_md5_exit(void);
int __init ppp_mschap_init(void);
void __exit ppp_mschap_exit(void);
int __init ppp_mschapv2_init(void);
void __exit ppp_mschapv2_exit(void);
int __init ppp_eap_init(void);
void __exit ppp_eap_exit(void);
int __init pppol2tp_init(void);
void __exit pppol2tp_exit(void);
int __init pppoe_ppp_init(void);
void __exit pppoe_ppp_exit(void);
int __init pppoe_cli_init(void);
void __exit pppoe_cli_exit(void);
int __init pppoe_srv_init(void);
void __exit pppoe_srv_exit(void);

int __init pppoe_serv_init(void);
void __exit pppoe_serv_exit(void);
int __init pppoe_pcap_init(void);
void __exit pppoe_pcap_exit(void);
int __init pppoe_pppox_init(void);
void __exit pppoe_pppox_exit(void);
int __init isakmp_ident_init(void);
void __exit isakmp_ident_exit(void);
int __init isakmp_agg_init(void);
void __exit isakmp_agg_exit(void);
int __init isakmp_base_init(void);
void __exit isakmp_base_exit(void);
int __init isakmp_info_init(void);
void __exit isakmp_info_exit(void);
int __init ipsec_doi_init(void);
void __exit ipsec_doi_exit(void);
int __init isakmp_doi_init(void);
void __exit isakmp_doi_exit(void);
int __init net_hbr_init(void);
void __exit net_hbr_exit(void);
int __init net_nat_init(void);
void __exit net_nat_exit(void);
int __init net_inet_init(void);
void __exit net_inet_exit(void);

int __init cli_stdio_init(void);
void __exit cli_stdio_exit(void);

int __init secret_file_init(void);
void __exit secret_file_exit(void);
int __init secret_plain_init(void);
void __exit secret_plain_exit(void);

int __init usb_init(void);
void __exit usb_exit(void);
int __init ccid_init(void);
void __exit ccid_exit(void);
int __init pcsc_init(void);
void __exit pcsc_exit(void);
int __init scard_init(void);
void __exit scard_exit(void);
int __init pkcs15_init(void);
void __exit pkcs15_exit(void);

static int __init modules_start3(void)
{
#ifdef CONFIG_PPP_MD5
	ppp_md5_init();
#endif
#ifdef CONFIG_PPP_MSCHAP
	ppp_mschap_init();
#endif
#ifdef CONFIG_PPP_MSCHAPV2
	ppp_mschapv2_init();
#endif
#ifdef CONFIG_PPP_MPPCE
	ppp_mppce_init();
#endif
	return 0;
}

static void __exit modules_stop3(void)
{
#ifdef CONFIG_PPP_MPPCE
	ppp_mppce_exit();
#endif
#ifdef CONFIG_PPP_MSCHAPV2
	ppp_mschapv2_exit();
#endif
#ifdef CONFIG_PPP_MSCHAP
	ppp_mschap_exit();
#endif
#ifdef CONFIG_PPP_MD5
	ppp_md5_exit();
#endif
}

static int __init modules_start2(void)
{
	net_inet_init();
#ifdef CONFIG_STAR
	appl_star_init();
#endif
#ifdef CONFIG_VTSS
	appl_vtss_init();
#endif
#ifdef CONFIG_IPSEC_DOI
	ipsec_doi_init();
#endif
#ifdef CONFIG_ISAKMP_DOI
	isakmp_doi_init();
#endif
#ifdef CONFIG_ISAKMP_INFO
	isakmp_info_init();
#endif
#ifdef CONFIG_ISAKMP_BASE
	isakmp_base_init();
#endif
#ifdef CONFIG_ISAKMP_AGG
	isakmp_agg_init();
#endif
#ifdef CONFIG_ISAKMP_IDENT
	isakmp_ident_init();
#endif
#ifdef CONFIG_PPPOE_PCAP
	pppoe_pcap_init();
#endif
#ifdef CONFIG_PPPOE_PPPOX
	pppoe_pppox_init();
#endif
#ifdef CONFIG_PPPOE_SERVER
	pppoe_srv_init();
#endif
#ifdef CONFIG_PPPOE_CLIENT
	pppoe_cli_init();
#endif
#ifdef CONFIG_PPP_CCP
	ppp_ccp_init();
#endif
#ifdef CONFIG_PPP_IPCP
	ppp_ipcp_init();
#endif
#ifdef CONFIG_PPP_BCP
	ppp_bcp_init();
#endif
#ifdef CONFIG_PPP_LQR
	ppp_lqr_init();
#endif
#ifdef CONFIG_PPP_L2TP
	pppol2tp_init();
#endif
#ifdef CONFIG_PPP_PPPOE
	pppoe_ppp_init();
#endif
#ifdef CONFIG_PPP_PAP
	ppp_pap_init();
#endif
#ifdef CONFIG_PPP_CHAP
	ppp_chap_init();
#endif
#ifdef CONFIG_PPP_EAP
	ppp_eap_init();
#endif
#ifdef CONFIG_L2TP_LNS
	l2tp_lns_init();
#endif
#ifdef CONFIG_L2TP_LAC
	l2tp_lac_init();
#endif
#ifdef CONFIG_L2TP_PPPOX
	l2tp_pppox_init();
#endif
#ifdef CONFIG_L2TP_DGRAM
	l2tp_dgram_init();
#endif
#ifdef CONFIG_EAP_MD5
	eap_md5_init();
#endif
#ifdef CONFIG_EAP_TLS
	eap_tls_init();
#endif
#ifdef CONFIG_EAP_MSCHAPV2
	eap_mschapv2_init();
#endif
#ifdef CONFIG_EAP_PEAP
	eap_peap_init();
#endif
#ifdef CONFIG_DHCP_CLIENT
	dhcp_client_init();
#endif
#ifdef CONFIG_DHCP_SERVER
	dhcp_server_init();
#endif
#ifdef CONFIG_DHCP_PCAP
	dhcp_pcap_init();
#endif
#ifdef CONFIG_NET_HBR
	net_hbr_init();
#endif
#ifdef CONFIG_NET_NAT
	net_nat_init();
#endif
#ifdef CONFIG_CLI_STDIO
	cli_stdio_init();
#endif
#ifdef CONFIG_SECRET_FILE
	secret_file_init();
#endif
#ifdef CONFIG_SECRET_PLAIN
	secret_plain_init();
#endif
	modules_start3();
	return 0;
}

static void __exit modules_stop2(void)
{
#ifdef CONFIG_SECRET_PLAIN
	secret_plain_exit();
#endif
#ifdef CONFIG_SECRET_FILE
	secret_file_exit();
#endif

#ifdef CONFIG_CLI_STDIO
	cli_stdio_exit();
#endif
#ifdef CONFIG_NET_HBR
	net_hbr_exit();
#endif
#ifdef CONFIG_NET_NAT
	net_nat_exit();
#endif
#ifdef CONFIG_EAP_PEAP
	eap_peap_exit();
#endif
#ifdef CONFIG_EAP_MSCHAPV2
	eap_mschapv2_exit();
#endif
#ifdef CONFIG_EAP_TLS
	eap_tls_exit();
#endif
#ifdef CONFIG_EAP_MD5
	eap_md5_exit();
#endif
#ifdef CONFIG_DHCP_PCAP
	dhcp_pcap_exit();
#endif
#ifdef CONFIG_DHCP_SERVER
	dhcp_server_exit();
#endif
#ifdef CONFIG_DHCP_CLIENT
	dhcp_client_exit();
#endif
#ifdef CONFIG_L2TP_DGRAM
	l2tp_dgram_exit();
#endif
#ifdef CONFIG_L2TP_PPPOX
	l2tp_pppox_exit();
#endif
#ifdef CONFIG_L2TP_LAC
	l2tp_lac_exit();
#endif
#ifdef CONFIG_L2TP_LNS
	l2tp_lns_exit();
#endif
#ifdef CONFIG_PPP_EAP
	ppp_eap_exit();
#endif
#ifdef CONFIG_PPP_CHAP
	ppp_chap_exit();
#endif
#ifdef CONFIG_PPP_PAP
	ppp_pap_exit();
#endif
#ifdef CONFIG_PPPOE
	pppoe_ppp_exit();
#endif
#ifdef CONFIG_PPP_L2TP
	pppol2tp_exit();
#endif
#ifdef CONFIG_PPP_LQR
	ppp_lqr_exit();
#endif
#ifdef CONFIG_PPP_BCP
	ppp_bcp_exit();
#endif
#ifdef CONFIG_PPP_IPCP
	ppp_ipcp_exit();
#endif
#ifdef CONFIG_PPP_CCP
	ppp_ccp_exit();
#endif
#ifdef CONFIG_PPPOE_CLIENT
	pppoe_cli_exit();
#endif
#ifdef CONFIG_PPPOE_SERVER
	pppoe_srv_exit();
#endif
#ifdef CONFIG_PPPOE_PPPOX
	pppoe_pppox_exit();
#endif
#ifdef CONFIG_PPPOE_PCAP
	pppoe_pcap_exit();
#endif
#ifdef CONFIG_ISAKMP_INFO
	isakmp_info_exit();
#endif
#ifdef CONFIG_ISAKMP_BASE
	isakmp_base_exit();
#endif
#ifdef CONFIG_ISAKMP_AGG
	isakmp_agg_exit();
#endif
#ifdef CONFIG_ISAKMP_IDENT
	isakmp_ident_exit();
#endif
#ifdef CONFIG_IPSEC_DOI
	ipsec_doi_exit();
#endif
#ifdef CONFIG_ISAKMP_DOI
	isakmp_doi_exit();
#endif
#ifdef CONFIG_VTSS
	appl_vtss_exit();
#endif
#ifdef CONFIG_STAR
	appl_star_exit();
#endif
	net_inet_exit();
}

int __init modules_start(void)
{
	/* subsystem initialization */
	fs_init();
	kmsg_init();
	rtnl_init();
	udev_init();
	rtc_init();
	net_init();
	ui_init();
#ifdef CONFIG_CLI
	cli_init();
#endif
#ifdef CONFIG_SYSLOG
	syslog_init();
#endif
#ifdef CONFIG_CRYPTO
	crypto_init();
#endif
#ifdef CONFIG_DNS
	dns_init();
#endif
#ifdef CONFIG_DHCP
	dhcp_init();
#endif
#ifdef CONFIG_EAP
	eap_init();
#endif
#ifdef CONFIG_RADIUS
	radius_init();
#endif
#ifdef CONFIG_PPP
	ppp_init();
#endif
#ifdef CONFIG_VLAN
	vlan_init();
#endif
#ifdef CONFIG_BRIDGE
	bridge_init();
#endif

#ifdef CONFIG_L2TP
	l2tp_init();
#endif
#ifdef CONFIG_PPPOE
	pppoe_init();
#endif
#ifdef CONFIG_ISAKMP
	isakmp_init();
#endif
#ifdef CONFIG_IPSEC
	ipsec_init();
#endif
#ifdef CONFIG_IKE
	ike_init();
#endif
#ifdef CONFIG_USB
	usb_init();
#endif
#ifdef CONFIG_CCID
	ccid_init();
#endif
#ifdef CONFIG_PCSC
	pcsc_init();
#endif
#ifdef CONFIG_SCARD
	scard_init();
#endif
#ifdef CONFIG_PKCS15
	pkcs15_init();
#endif
	modules_start2();
	return 0;
}

void __exit modules_stop(void)
{
#ifdef CONFIG_PKCS15
	pkcs15_exit();
#endif
#ifdef CONFIG_SCARD
	scard_exit();
#endif
#ifdef CONFIG_PCSC
	pcsc_exit();
#endif
#ifdef CONFIG_CCID
	ccid_exit();
#endif
#ifdef CONFIG_USB
	usb_exit();
#endif
#ifdef CONFIG_IKE
	ike_exit();
#endif
#ifdef CONFIG_IPSEC
	ipsec_exit();
#endif
#ifdef CONFIG_ISAKMP
	isakmp_exit();
#endif
#ifdef CONFIG_PPPOE
	pppoe_exit();
#endif
#ifdef CONFIG_L2TP
	l2tp_exit();
#endif
#ifdef CONFIG_PPP
	ppp_exit();
#endif
#ifdef CONFIG_BRIDGE
	bridge_exit();
#endif
#ifdef CONFIG_VLAN
	vlan_exit();
#endif
#ifdef CONFIG_EAP
	eap_exit();
#endif
#ifdef CONFIG_RADIUS
	radius_exit();
#endif
#ifdef CONFIG_DHCP
	dhcp_exit();
#endif
#ifdef CONFIG_DNS
	dns_exit();
#endif
#ifdef CONFIG_CRYPTO
	crypto_exit();
#endif
#ifdef CONFIG_SYSLOG
	syslog_exit();
#endif
#ifdef CONFIG_CLI
	cli_exit();
#endif
	net_exit();
	rtc_exit();
	udev_exit();
	rtnl_exit();
	kmsg_exit();
	fs_exit();
	ui_exit();
}
#else
int __init modules_start(void)
{
	return 0;
}

void __exit modules_stop(void)
{
}
#endif
