#ifndef __VPN_H_INCLUDE__
#define __VPN_H_INCLUDE__

#include <sysdep.h>
#include <autoconf.h>

#include <uiserv.h>
#include <logger.h>
#include <fsserv.h>

#include <netsvc.h>
#include <service.h>
#include <module.h>

#include <udev.h>
#include <cli_api.h>
#include <nl_route.h>
#include <crypto.h>

#include <l2tp.h>
#include <ppp.h>
#include <eap.h>
#include <dhcp.h>
#include <dns.h>
#include <pppoe.h>
#include <isakmp.h>
#include <ipsec.h>
#include <ike.h>
#include <secret.h>

#include <usb.h>
#include <ccid.h>
#include <pcsc.h>
#include <scard.h>
#include <pkcs15.h>

#ifdef WIN32
#include <getopt.h>
#include <process.h>
#include <ntserv.h>
#endif /* WIN32 */

#include <vtss.h>

int __init modules_start(void);
void __exit modules_stop(void);

#endif /* __VPN_H_INCLUDE__ */
