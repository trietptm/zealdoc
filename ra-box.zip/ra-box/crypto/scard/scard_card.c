#include "scard_priv.h"

int scard_connect(int reader_idx, int slot_idx, 
		  struct scard_handle **out_handle,
		  scard_cmd_complete callback, void *user_data)
{
	struct scard_handle *card_handle;
	int r;
	
	card_handle = malloc(sizeof(struct scard_handle));
	if (!card_handle) {
		return SCARD_ERR_NO_MEM;
	}
	memset(card_handle, 0, sizeof(struct scard_handle));

	r = scard_reader_connect(reader_idx, slot_idx, card_handle);
	if (r != SCARD_SUCCESS) {
		free(card_handle);
		return r;
	}

	r = scard_match_driver(card_handle, out_handle, callback, user_data);
	if (r !=  SCARD_SUCCESS) {
		scard_reader_disconnect(card_handle);
		free(card_handle);
	}

	return r;
}

int scard_disconnect(struct scard_handle *card_handle)
{
	if (card_handle == NULL) return SCARD_SUCCESS;

	if (card_handle->card_driver->ops->exit)
		card_handle->card_driver->ops->exit(card_handle);
	scard_reader_disconnect(card_handle);
	free(card_handle);

	return SCARD_SUCCESS;
}

int scard_icc_status(int reader_idx, int slot_idx, int *icc_status)
{
	return scard_reader_icc_status(reader_idx, slot_idx, icc_status);
}

int scard_check_icc_present_pwd(struct scard_handle *card_handle)
{
	int icc_status;
	int r;

	BUG_ON(card_handle == NULL);

	r = scard_icc_status(card_handle->reader_idx, card_handle->slot_idx,
			     &icc_status);
	if (r != SCARD_SUCCESS)
		return r;

	if (icc_status != SCARD_ICC_PRESENT_POWERUP)
		return 0;
	else 
		return 1;
}

int scard_check_sw(struct scard_handle *card_handle, uint8_t sw1, uint8_t sw2)
{
	return card_handle->card_driver->ops->check_sw(card_handle, sw1, sw2);
}

int scard_select_file(struct scard_handle *card_handle, struct scard_path *path,
		      struct scard_file **file_out, 
		      scard_cmd_complete callback, void *user_data)
{
	int r;

	if (path->len > SCARD_PATH_MAX)
		return SCARD_ERR_INVALID_ARGS;
	if (path->type == SCARD_PATH_TYPE_PATH) {
		size_t i;

		if ((path->len & 1) != 0)
			return SCARD_ERR_INVALID_ARGS;
		for (i = 0; i < path->len/2; i++) {
			uint8_t p1 = path->value[2 * i];
			uint8_t p2 = path->value[2 * i + 1];
			if (p1 == 0x3F && p2 == 0x00  && i != 0)
				return SCARD_ERR_INVALID_ARGS;
		}
	}
	if (!card_handle->card_driver->ops->select_file)
		return SCARD_ERR_NOT_SUPPORTED;
	r = card_handle->card_driver->ops->select_file(card_handle, path, 
					file_out, callback, user_data);

	return r;
}

int scard_read_binary(struct scard_handle *handle, uint16_t offset,
		      uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
		      scard_cmd_complete callback, void *user_data)
{
	if (rbuf_len == 0)
		return SCARD_SUCCESS;
	if (!handle->card_driver->ops->read_binary)
		return SCARD_ERR_NOT_SUPPORTED;
	return handle->card_driver->ops->read_binary(handle,
			offset, rbuf, rbuf_len, flags,
			callback, user_data);
}

int scard_write_binary(struct scard_handle *card_handle, uint16_t offset,
		       const uint8_t *sbuf, size_t sbuf_len, uint32_t flags,
		       scard_cmd_complete callback, void *user_data)
{
	if (!card_handle->card_driver->ops->write_binary)
		return SCARD_ERR_NOT_SUPPORTED;
	return card_handle->card_driver->ops->write_binary(card_handle,
			offset, sbuf, sbuf_len, flags,
			callback, user_data);	
}

int scard_update_binary(struct scard_handle *card_handle, uint16_t offset,
			const uint8_t *sbuf, size_t sbuf_len, uint32_t flags,
			scard_cmd_complete callback, void *user_data)
{
	if (!card_handle->card_driver->ops->update_binary)
		return SCARD_ERR_NOT_SUPPORTED;
	return card_handle->card_driver->ops->update_binary(card_handle,
			offset, sbuf, sbuf_len, flags,
			callback, user_data);	
}

int scard_read_record(struct scard_handle *card_handle, uint8_t rec_nr, 
		      uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		      scard_cmd_complete callback, void *user_data)
{
	if (!card_handle->card_driver->ops->read_record)
		return SCARD_ERR_NOT_SUPPORTED;
	return card_handle->card_driver->ops->read_record(card_handle,
			rec_nr, rec_buf, rec_len, flags,
			callback, user_data);	
}

int scard_write_record(struct scard_handle *card_handle, uint8_t rec_nr, 
		      uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		      scard_cmd_complete callback, void *user_data)
{
	if (!card_handle->card_driver->ops->write_record)
		return SCARD_ERR_NOT_SUPPORTED;
	return card_handle->card_driver->ops->write_record(card_handle,
			rec_nr, rec_buf, rec_len, flags,
			callback, user_data);	
}

int scard_append_record(struct scard_handle *card_handle,
		       uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		       scard_cmd_complete callback, void *user_data)
{
	if (!card_handle->card_driver->ops->append_record)
		return SCARD_ERR_NOT_SUPPORTED;
	return card_handle->card_driver->ops->append_record(card_handle,
			rec_buf, rec_len, flags, callback, user_data);
}

int scard_update_record(struct scard_handle *card_handle, uint8_t rec_nr,
		       uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		       scard_cmd_complete callback, void *user_data)
{
	if (!card_handle->card_driver->ops->update_record)
		return SCARD_ERR_NOT_SUPPORTED;
	return card_handle->card_driver->ops->update_record(card_handle,
			rec_nr, rec_buf, rec_len, flags, callback, user_data);
}

int scard_delete_record(struct scard_handle *card_handle, uint8_t rec_nr,
			scard_cmd_complete callback, void *user_data)
{
	return SCARD_ERR_NOT_SUPPORTED;
}

int scard_get_challenge(struct scard_handle *card_handle, void *rnd, 
		       size_t rnd_len, scard_cmd_complete callback, 
		       void *user_data)
{
	if (!card_handle->card_driver->ops->get_challenge)
		return SCARD_ERR_NOT_SUPPORTED;
	return card_handle->card_driver->ops->get_challenge(card_handle,
			rnd, rnd_len, callback, user_data);
}

int scard_create_file(struct scard_handle *card_handle, struct scard_file *filp,
		      scard_cmd_complete callback, void *user_data)
{
	if (!card_handle->card_driver->ops->create_file)
		return SCARD_ERR_NOT_SUPPORTED;
	return card_handle->card_driver->ops->create_file(card_handle,
			filp, callback, user_data);	
}

int scard_delete_file(struct scard_handle *card_handle, 
		      const struct scard_path *path,
		      scard_cmd_complete callback, void *user_data)
{
	if (!card_handle->card_driver->ops->delete_file)
		return SCARD_ERR_NOT_SUPPORTED;
	return card_handle->card_driver->ops->delete_file(card_handle,
			path, callback, user_data);		
}
