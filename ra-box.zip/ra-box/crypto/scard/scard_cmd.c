#include "scard_priv.h"

static struct scard_handle *card_handle = NULL;
static struct scard_file *file_out = NULL;
static uint8_t sbuf[1024];
static size_t sbuf_len;
static uint8_t rbuf[1024];
static size_t rbuf_len;

static tool_connect_complete(void *user_data, int ret)
{
	if (ret == SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "tool_connect_complete success");
	} else {
		scard_log(SCARD_LOG_DEBUG, "tool_connect_complete failed: %d", ret);	
	}
}

int scard_tool_connect(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int reader_idx, slot_idx = 0;
	int r;

	reader_idx = atoi(argv[0]);

	r = scard_connect(reader_idx, slot_idx, &card_handle, 
			  tool_connect_complete, NULL);
	if (r != SCARD_SUCCESS) {
		scard_log(SCARD_LOG_ERR, "scard_connect failed: %d", r);
	} else {
		scard_log(SCARD_LOG_ERR, "scard_connect success");
	}
	return r;
}

int scard_tool_disconnect(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int r;

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "There is no card connected.");
		return SCARD_ERR_NO_CARD;
	}

	r = scard_disconnect(card_handle);
	if (r != SCARD_SUCCESS) {
		scard_log(SCARD_LOG_ERR, "scard_disconnect failed: %d", r);
	} else {
		card_handle = NULL;
		scard_log(SCARD_LOG_ERR, "scard_disconnect success");
	}
	return r;
}

void scard_tool_select_complete(void *user_data, int ret)
{
	if (ret == SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "scard_tool_select_complete success");
		if (file_out == NULL)
			scard_log(SCARD_LOG_DEBUG, "There is no FCI");
		else {
			/*TODO: print FCI*/
		}
	} else {
		scard_log(SCARD_LOG_DEBUG, "scard_tool_select_complete failed: %d", ret);	
	}

	if (file_out) free(file_out);
	file_out = NULL;
}

int scard_tool_select(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	struct scard_path path;
	const uint8_t *fileid;
	int r;

	fileid = argv[0];

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}

	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
		
	scard_format_path(fileid, &path);
	path.type = SCARD_PATH_TYPE_PATH;

	r = scard_select_file(card_handle, &path, &file_out, 
				scard_tool_select_complete, card_handle);
	if (r != SCARD_SUCCESS) {
		scard_log(SCARD_LOG_ERR, "scard_select_file failed: %d", r);
	}
	
	return r;
}

static void tool_read_binary_complete(void *user_data, int ret)
{
	if (ret >= SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "tool_read_binary_complete success");
		scard_log_xxd(SCARD_LOG_DEBUG, "Read Binary: ", rbuf, ret);
	} else {
		scard_log(SCARD_LOG_DEBUG, "tool_read_binary_complete failed: %d", ret);
	}
}

int scard_tool_read_binary(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	uint16_t offset;
	int r;

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}
	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
	
	offset = (uint16_t)strtoul(argv[0], NULL, 10);
	rbuf_len = (size_t)strtoul(argv[1], NULL, 10);
	if (rbuf_len > sizeof(rbuf)) {
		scard_log(SCARD_LOG_ERR, "Invalid len ( < %d)", sizeof(rbuf));
		return SCARD_ERR_INVALID_ARGS;
	}
	memset(rbuf, 0, sizeof(rbuf));
	r = scard_read_binary(card_handle, offset, rbuf, rbuf_len, 0,
			      tool_read_binary_complete, NULL);
	if (r != SCARD_SUCCESS) {
		scard_log(SCARD_LOG_ERR, "scard_read_binary failed: %d", r);
	}
	
	return r;
}

static void tool_write_binary_complete(void *user_data, int ret)
{
	if (ret >= SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "tool_write_binary_complete success");
	} else {
		scard_log(SCARD_LOG_DEBUG, "tool_write_binary_complete failed: %d", ret);
	}
}

int scard_tool_update_binary(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	uint16_t offset;
#if 0
	const char *data;
	size_t data_len;
#endif
	int r;
	
	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}
	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
		
	offset = (uint16_t)strtoul(argv[0], NULL, 10);

	memset(sbuf, 0, sizeof(sbuf));
#if 0
	data = argv[1];
	data_len = strlen(data);

	if (data_len > sizeof(sbuf)) {
		return SCARD_ERR_INVALID_ARGS;
	}
	
	memcpy(sbuf, data, data_len);
	sbuf_len = data_len;
#else
	for (sbuf_len = 0; sbuf_len < 256; sbuf_len++) {
		sbuf[sbuf_len] = sbuf_len;
	}
	for (; sbuf_len < 600; sbuf_len++) {
		sbuf[sbuf_len] = ~(sbuf_len & 0xFF);
	}
	
#endif
	
	r = scard_update_binary(card_handle, offset, sbuf, sbuf_len, 0,
			tool_write_binary_complete, NULL);
	if (r != SCARD_SUCCESS) 
		scard_log(SCARD_LOG_ERR, "scard_update_binary failed: %d", r);

	return r;
}

static void tool_read_record_complete(void *user_data, int ret)
{
	if (ret >= SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "tool_read_record_complete success");
		scard_log_xxd(SCARD_LOG_DEBUG, "Record: ", sbuf, ret);
	} else {
		scard_log(SCARD_LOG_DEBUG, "tool_read_record_complete failed: %d", ret);
	}
}

int scard_tool_read_record(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	uint8_t rec_nr;
	uint8_t *rec_buf = sbuf;
	size_t rec_len;
	int r;

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}
	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
	
	
	rec_nr = (uint8_t)atoi(argv[0]);
	rec_len = 0x0F;

	r = scard_read_record(card_handle, rec_nr, rec_buf, rec_len, SCARD_RECORD_BY_REC_NR, 
			tool_read_record_complete, NULL);
	if (r != SCARD_SUCCESS) 
		scard_log(SCARD_LOG_ERR, "scard_read_record failed: %d", r);

	return r;
}

static void tool_write_record_complete(void *user_data, int ret)
{
	if (ret >= SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "tool_write_record_complete success");
	} else {
		scard_log(SCARD_LOG_DEBUG, "tool_write_record_complete failed: %d", ret);
	}
}

int scard_tool_write_record(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	uint8_t rec_nr;
	uint8_t *rec_buf = sbuf;
	size_t rec_len;
	uint8_t i;
	int r;

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}
	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
	
	rec_nr = (uint8_t)atoi(argv[0]);
	rec_len = 0x0F;
	for(i = 0; i < rec_len; i++)
		rec_buf[i] = 0x0A;

	
	r = scard_write_record(card_handle, rec_nr, rec_buf, rec_len, SCARD_RECORD_BY_REC_NR, 
			tool_write_record_complete, NULL);
	if (r != SCARD_SUCCESS) 
		scard_log(SCARD_LOG_ERR, "scard_write_record failed: %d", r);

	return r;	
}

static void tool_append_record_complete(void *user_data, int ret)
{
	if (ret >= SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "tool_append_record_complete success");
	} else {
		scard_log(SCARD_LOG_DEBUG, "tool_append_record_complete failed: %d", ret);
	}
}

int scard_tool_append_record(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	uint8_t *rec_buf = sbuf;
	size_t rec_len;
	uint8_t i;
	int r;

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}
	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
	
	rec_len = 0x0F;
	for(i = 0; i < rec_len; i++)
		rec_buf[i] = 0x0B;

	
	r = scard_append_record(card_handle, rec_buf, rec_len, SCARD_RECORD_BY_REC_NR, 
			tool_append_record_complete, NULL);
	if (r != SCARD_SUCCESS) 
		scard_log(SCARD_LOG_ERR, "scard_append_record failed: %d", r);

	return r;	
}

static tool_update_record_complete(void *user_data, int ret)
{
	if (ret >= SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "tool_update_record_complete success");
	} else {
		scard_log(SCARD_LOG_DEBUG, "tool_update_record_complete failed: %d", ret);
	}
}

int scard_tool_update_record(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	uint8_t rec_nr;
	uint8_t *rec_buf = sbuf;
	size_t rec_len;
	uint8_t i;
	int r;

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}
	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
		
	rec_nr = (uint8_t)atoi(argv[0]);
	rec_len = 0x0F;
	for(i = 0; i < rec_len; i++)
		rec_buf[i] = 0x0C;
	
	r = scard_update_record(card_handle, rec_nr, rec_buf, rec_len, SCARD_RECORD_BY_REC_NR, 
			tool_update_record_complete, NULL);
	if (r != SCARD_SUCCESS) 
		scard_log(SCARD_LOG_ERR, "scard_update_record failed: %d", r);

	return r;		
}

static void tool_get_challenge_complete(void *user_data, int ret)
{
	if (ret >= SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "tool_get_challenge_complete success");
		scard_log_xxd(SCARD_LOG_DEBUG, "Challenge: ", sbuf, ret);
	} else {
		scard_log(SCARD_LOG_DEBUG, "tool_get_challenge_complete failed: %d", ret);
	}
}

int scard_tool_get_challenge(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	int rnd_len;
	uint8_t *rnd = sbuf;
	int r;

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}
	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
		
	rnd_len = atoi(argv[0]);
	
	BUG_ON(rnd_len > sizeof(sbuf));

	r = scard_get_challenge(card_handle, rnd, rnd_len, 
		tool_get_challenge_complete, NULL);
	if (r != SCARD_SUCCESS) 
		scard_log(SCARD_LOG_ERR, "scard_get_challenge failed: %d", r);

	return r;		
}

static void tool_pin_verify_complete(void *user_data, int ret)
{
	if (ret >= SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "tool_pin_verify_complete success");
	} else {
		scard_log(SCARD_LOG_DEBUG, "tool_pin_verify_complete failed: %d", ret);
	}
}

int scard_tool_pin_verify(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	uint8_t pin_ref;
	const uint8_t *pin_hex;
	uint8_t pin_bin[8];
	size_t pin_len;
	int r;

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}
	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
	
	pin_ref = (uint8_t)atoi(argv[0]);
	pin_hex = argv[1];
	
	pin_len = sizeof(pin_bin);
	scard_hex_to_bin(pin_hex, pin_bin, &pin_len);

	r = scard_verify(card_handle, SCARD_AC_CHV, pin_ref, pin_bin, pin_len,
		3, tool_pin_verify_complete, NULL);
	if (r != SCARD_SUCCESS) 
		scard_log(SCARD_LOG_ERR, "scard_get_challenge failed: %d", r);
	return r;
}

static void tool_pin_change_complete(void *user_data, int ret)
{
	if (ret >= SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "tool_pin_change_complete success");
	} else {
		scard_log(SCARD_LOG_DEBUG, "tool_pin_change_complete failed: %d", ret);
	}
}

int scard_tool_pin_change(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	uint8_t pin_ref;
	uint8_t pin1_bin[8], pin2_bin[8];
	size_t pin1_len, pin2_len;
	const uint8_t *pin1_hex, *pin2_hex;
	uint8_t old_cla;
	int r;

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}
	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
		
	pin_ref = (uint8_t)atoi(argv[0]);

	pin1_hex = argv[1];
	pin1_len = sizeof(pin1_bin);
	scard_hex_to_bin(pin1_hex, pin1_bin, &pin1_len);

	pin2_hex = argv[2];
	pin2_len = sizeof(pin2_bin);
	scard_hex_to_bin(pin2_hex, pin2_bin, &pin2_len);
	
	old_cla = card_handle->cla;
	card_handle->cla = 0x80;
	r = scard_change(card_handle, SCARD_AC_CHV, pin_ref, pin1_bin, pin1_len,
		pin2_bin, pin2_len, 3, tool_pin_change_complete, NULL);
	if (r != SCARD_SUCCESS) 
		scard_log(SCARD_LOG_ERR, "scard_change failed: %d", r);
	card_handle->cla = old_cla;

	return r;
}

static void tool_pin_unblock_complete(void *user_data, int ret)
{
	if (ret >= SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "tool_pin_unblock_complete success");
	} else {
		scard_log(SCARD_LOG_DEBUG, "tool_pin_unblock_complete failed: %d", ret);
	}
}

int scard_tool_pin_unblock(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	uint8_t pin_ref;
	uint8_t pin1_bin[8], pin2_bin[8];
	size_t pin1_len, pin2_len;
	const uint8_t *pin1_hex, *pin2_hex;
	uint8_t old_cla;
	int r;

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}
	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
		
	pin_ref = (uint8_t)atoi(argv[0]);

	pin1_hex = argv[1];
	pin1_len = sizeof(pin1_bin);
	scard_hex_to_bin(pin1_hex, pin1_bin, &pin1_len);

	pin2_hex = argv[2];
	pin2_len = sizeof(pin2_bin);
	scard_hex_to_bin(pin2_hex, pin2_bin, &pin2_len);

	old_cla = card_handle->cla;
	card_handle->cla = 0x80;
	r = scard_unblock(card_handle, SCARD_AC_CHV, pin_ref, pin1_bin, pin1_len,
		pin2_bin, pin2_len, 3, tool_pin_unblock_complete, NULL);
	if (r != SCARD_SUCCESS) 
		scard_log(SCARD_LOG_ERR, "scard_unblock failed: %d", r);
	card_handle->cla = old_cla;

	return r;
}

static void create_file_complete(void *user_data, int ret)
{
	if (ret >= SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "create_file_complete success");
	} else {
		scard_log(SCARD_LOG_DEBUG, "create_file_complete failed: %d", ret);
	}
}


int scard_tool_create_file(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	struct scard_file *filp;
	struct scard_acl_entry read_acl, write_acl;
	int fileid;
	int r;

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}
	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
	
	
	fileid = atoi(argv[0]);
	
	filp = scard_file_new();
	if (!filp)
		return SCARD_ERR_NO_MEM;

	filp->id = fileid;
	filp->type = SCARD_FILE_TYPE_WORKING_EF;
	filp->ef_structure = SCARD_FILE_EF_TRANSPARENT;
	filp->size = 50;
	
	read_acl.key_ref = 0x00;
	read_acl.method = SCARD_AC_CHV;
	filp->acl[SCARD_AC_OP_READ] = &read_acl;

	
	write_acl.key_ref = 0x00;
	write_acl.method = SCARD_AC_AUT;
	filp->acl[SCARD_AC_OP_WRITE] = &write_acl;

	r = scard_create_file(card_handle, filp, create_file_complete, NULL);
	if (r != SCARD_SUCCESS) 
		scard_log(SCARD_LOG_ERR, "scard_create_file failed: %d", r);

	scard_file_free(filp);
	return r;
}

static void delete_file_complete(void *user_data, int ret)
{
	if (ret >= SCARD_SUCCESS) {
		scard_log(SCARD_LOG_DEBUG, "delete_file_complete success");
	} else {
		scard_log(SCARD_LOG_DEBUG, "delete_file_complete failed: %d", ret);
	}
}

int scard_tool_delete_file(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	struct scard_path in_path;
	const uint8_t *file_id;
	int r;

	if (!card_handle) {
		scard_log(SCARD_LOG_ERR, "Please first connect.");
		return SCARD_ERR_UNSPECIFIED;
	}
	if (!scard_handle_check_valid(card_handle)) {
		scard_log(SCARD_LOG_ERR, "Handle is invalid");
		return SCARD_ERR_UNSPECIFIED;
	}

	r = scard_check_icc_present_pwd(card_handle);
	if (r <=0) {
		scard_log(SCARD_LOG_ERR, "icc not present or powered: %d", r);
		return SCARD_ERR_UNSPECIFIED;
	}
	
	file_id = argv[0];

	scard_format_path(file_id, &in_path);
	in_path.type = SCARD_PATH_TYPE_FILE_ID;

	r = scard_delete_file(card_handle, &in_path, delete_file_complete, NULL);
	if (r != SCARD_SUCCESS) 
		scard_log(SCARD_LOG_ERR, "scard_delete_file failed: %d", r);

	return r;
}

