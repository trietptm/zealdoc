#ifndef __SCARD_PRIV_H__
#define __SCARD_PRIV_H__
#include <sysdep.h>
#include <logger.h>
#include <panic.h>
#include <module.h>
#include <strutl.h>
#include <dfastm.h>
#include <eloop.h>
#include <service.h>
#include <list.h>
#include <scard.h>
#ifdef CONFIG_PCSC
#include <pcsc.h>
#endif

#define SCARD_APDU_BUFFER_MAX		258

struct scard_cmd_param {
	const uint8_t *sbuf;
	size_t sbuf_len;
	size_t sbuf_transmitted;
	void *priv_param;

	uint8_t *rbuf;
	size_t rbuf_len;
	size_t rbuf_actual;

	/* For SELECT FILE command */
	struct scard_path *path;
	struct scard_file **file_out;

	scard_cmd_complete callback;
	void *user_data;
	int ret;
};

#define SCARD_CARD_PARAM_FLAG_NOT_FREE_APDU	0x00000001

typedef void (*scard_card_cmd_complete)(struct scard_card_cmd_param *card_param);
struct scard_card_cmd_param {
	struct scard_handle *handle;
	struct scard_cmd_param *cmd_param;
	struct scard_apdu *apdu;

	scard_card_cmd_complete callback;
	int ret;
	uint32_t flags;
};


/*Logging operations*/
#define SCARD_LOG_CRIT	LOG_EMERG
#define SCARD_LOG_FAIL	LOG_CRIT
#define SCARD_LOG_ERR	LOG_ERR
#define SCARD_LOG_WARN	LOG_WARNING
#define SCARD_LOG_INFO	LOG_INFO
#define SCARD_LOG_DEBUG	LOG_DEBUG

void scard_log(int level, const char *format, ...);
void scard_log_xxd(int level, const char *msg, const uint8_t *buf, 
		   size_t buf_len);

int scard_bin_to_hex(const uint8_t *in, size_t in_len,
		     char *out, size_t out_len, uint8_t in_sep);
int scard_hex_to_bin(const char *in, uint8_t *out, size_t *outlen);
uint32_t bebytes2ulong(const uint8_t *buf);
uint16_t bebytes2ushort(const uint8_t *buf);
void ulong2bebytes(uint8_t *buf, uint32_t x);
void ushort2bebytes(uint8_t *buf, uint16_t x);

void scard_detect_apdu_cse(const struct scard_handle *handle, 
			   struct scard_apdu *apdu);
int scard_check_apdu(const struct scard_handle *handle, 
			   struct scard_apdu *apdu);
int scard_apdu_get_octets(const struct scard_apdu *apdu, uint8_t **rbuf,
			  size_t *rbuf_len, unsigned int proto);
int scard_match_atr_table(const struct scard_atr_table *atr_table, 
			  const uint8_t *atr_bin, size_t atr_bin_len);

int scard_file_add_acl_entry(struct scard_file *filp, unsigned int op, 
			     unsigned int method, unsigned int key_ref);
int scard_file_clear_acl_entries(struct scard_file *filp, unsigned int op);
const struct scard_acl_entry *scard_file_get_acl_entry(const struct scard_file *filp,
						  unsigned int op);


int scard_file_set_prop_attr(struct scard_file *file, const uint8_t *prop_attr,
			     size_t prop_attr_len);
int scard_file_set_sec_attr(struct scard_file *file, const uint8_t *sec_attr,
			    size_t sec_attr_len);

struct scard_card_driver *scard_card_driver_by_name(const char *name);
int scard_match_driver(struct scard_handle *card_handle,
		       struct scard_handle **out_handle,
		       scard_cmd_complete callback, void *user_data);

int scard_card_driver_register(const char *name, 
			       struct scard_card_operations *ops);
void scard_card_driver_unregister(const char *name);

int scard_register_card_iso7816 (void);
void scard_unregister_card_iso7816(void);
struct scard_card_operations *scard_get_iso7816_ops (void);

int scard_register_card_watchdata (void);
void scard_unregister_card_watchdata(void);

int scard_register_card_muscle (void);
void scard_unregister_card_muscle(void);

int scard_reader_connect(int reader_idx, int slot_idx, 
			 struct scard_handle *card_handle);
int scard_reader_disconnect(struct scard_handle *card_handle);
int scard_reader_icc_status(int reader_idx, int slot_idx, int *icc_status);

int scard_reader_transmit(struct scard_card_cmd_param *card_param);
int scard_check_sw(struct scard_handle *card_handle, uint8_t sw1, uint8_t sw2);

int scard_build_pin(uint8_t *rbuf, size_t rbuf_len, 
		    struct scard_pin_cmd_pin *pin, int pad);
int scard_reader_pin_cmd(struct scard_card_cmd_param *card_param, 
			 struct scard_pin_cmd_data *pin_cmd);

/*=========================TEST TOOLS========================================*/
int scard_tool_connect(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int scard_tool_disconnect(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int scard_tool_select(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int scard_tool_read_binary(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int scard_tool_update_binary(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv);
int scard_tool_read_record(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv);
int scard_tool_write_record(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv);
int scard_tool_append_record(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv);
int scard_tool_update_record(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv);
int scard_tool_get_challenge(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv);
int scard_tool_pin_verify(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv);
int scard_tool_pin_change(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv);
int scard_tool_pin_unblock(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv);
int scard_tool_create_file(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv);
int scard_tool_delete_file(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv);

#endif /*__SCARD_PRIV_H__*/
