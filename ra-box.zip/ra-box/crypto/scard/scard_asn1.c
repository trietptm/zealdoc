#include "scard_priv.h"
#include "scard_asn1.h"

/* Read the next TLV
 * cla_out | tag_out: the T of TLV
 * taglen: correspond to the L of TLV
 * return the V of TLV
 */
int scard_asn1_read_tag(const uint8_t **buf, size_t buflen, 
			unsigned int *cla_out, unsigned int *tag_out,
			size_t *taglen)
{
	const uint8_t *p = *buf;
	size_t left = buflen, len;
	unsigned int cla, tag, i;

	if (left < 2)
		return SCARD_ERR_INVALID_ASN1_OBJECT;
	*buf = NULL;
	if (*p == 0xff || *p == 0)/* end of data reached */
		return SCARD_SUCCESS;
	/* parse tag byte(s) */
	cla = (*p & SCARD_ASN1_TAG_CLASS_MASK) | (*p & SCARD_ASN1_TAG_CONSTRUCTED);
	tag = *p & SCARD_ASN1_TAG_PRIMITIVE;
	p++;
	left--;
	if (tag == SCARD_ASN1_TAG_PRIMITIVE) {
		/* high tag number */
		size_t n = sizeof(int) - 1;
		/* search the last tag octet */
		while (left-- != 0 && n != 0) {
			tag <<= 8;
			tag |= *p;
			if ((*p++ & 0x80) == 0)
				break;
			n--;
		}
		if (left == 0 || n == 0)
			/* either an invalid tag or it doesn't fit in
			 * unsigned int */
			return SCARD_ERR_INVALID_ASN1_OBJECT;
		
	}
	if (left == 0)
		return SCARD_ERR_INVALID_ASN1_OBJECT;
	/* parse length byte(s) */
	len = *p & 0x7f;
	if (*p++ & 0x80) {
		unsigned int a = 0;
		if (len > 4 || len > left)
			return SCARD_ERR_INVALID_ASN1_OBJECT;
		left -= len;
		for (i = 0; i < len; i++) {
			a <<= 8;
			a |= *p;
			p++;
		}
		len = a;
	}
	if (len > left)
		return SCARD_ERR_INVALID_ASN1_OBJECT;
	*cla_out = cla;
	*tag_out = tag;
	*taglen = len;
	*buf = p;
	return SCARD_SUCCESS;
}

const uint8_t *scard_asn1_find_tag(const uint8_t *buf, size_t buflen,
				   unsigned int tag_in, size_t *taglen_in)
{
	size_t left = buflen, taglen;
	const uint8_t *p = buf;

	*taglen_in = 0;
	while (left >= 2) {
		unsigned int cla, tag, mask = 0xff00;

		buf = p;
		/* read a tag */
		if (scard_asn1_read_tag(&p, left, &cla, &tag, &taglen) != SCARD_SUCCESS)
			return NULL;
		if (left < (size_t)(p - buf)) {
			return NULL;
		}
		left -= (p - buf);
		/* we need to shift the class byte to the leftmost
		 * byte of the tag */
		while ((tag & mask) != 0) {
			cla  <<= 8;
			mask <<= 8;
		}
		/* compare the read tag with the given tag */
		if ((tag | cla) == tag_in) {
			/* we have a match => return length and value part */
			if (taglen > left)
				return NULL;
			*taglen_in = taglen;
			return p;
		}
		/* otherwise continue reading tags */
		if (left < taglen) {
			return NULL;
		}
		left -= taglen;
		p += taglen;
	}
	return NULL;	
}

int scard_asn1_put_tag(int tag, const uint8_t *data, size_t data_len,
		       uint8_t *out, size_t out_len, uint8_t **ptr)
{
	uint8_t *p = out;

	if (out_len < 2)
		return SCARD_ERR_INVALID_ARGS;
	if (data_len > 127)
		return SCARD_ERR_INVALID_ARGS;

	*p++ = tag & 0xFF; /* FIXME: support longer tags */
	out_len--;

	*p++ = (uint8_t)data_len;
	out_len--;

	if (out_len < data_len)
		return SCARD_ERR_INVALID_ARGS;
	memcpy(p, data, data_len);
	p += data_len;

	if (ptr != NULL)
		*ptr = p;

	return 0;
}

