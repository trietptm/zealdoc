#include "scard_priv.h"
/* 
 * T = 0:
 *	CASE 1: 
 *		C-APDU:	CLA|INS|P1|P2
 *		TPDU:	CLA|INS|P1|P2|0x00
 *		
 *		R-TPDU: SW1|SW2
 *		R-APDU: SW1|SW2
 *	CASE2:(short)
 *		C-APDU:	CLA|INS|P1|P2|Le (1 <= Le <= 256, Le = 0x00 means maxinum 256)
 *		TPDU:	CLA|INS|P1|P2|Le
 *
 *		R-TPDU: Data|SW1|SW2
 *		R-APDU: Data|SW1|SW2
 *	CASE3:(short)
 *		C-APDU:	CLA|INS|P1|P2|Lc|Data 	1 <= Lc <= 255
 *		TPDU:	CLA|INS|P1|P2|Lc|Data
 *
 *		R-TPDU: SW1|SW2
 *		R-APDU: SW1|SW2
 *	CASE4:(short)
 *		C-APDU:	CLA|INS|P1|P2|Lc|Data|Le  1 <= Lc <= 255, 1 <= Le <= 256
 *		TPDU:	CLA|INS|P1|P2|Lc|Data
 *
 *		R-TPDU: Data|SW1|SW2
 *		R-APDU: Data|SW1|SW2
 *
 *	In Extended APDU, Lc and Le is 3 bytes, respecively represent
 *	Lc0 Lc1 Lc2 and Le0 Le1 Le2. Lc0 = 0x00, Le0 = 0x00
 *
 *	Case2(extended):
 *		C-APDU:	CLA|INS|P1|P2|Le0|Le1|Le2  1 <= Le <= 65536(Le =000000 means 65536)
 *		C-TPDU:
 *			Case2E-1: Le <= 256
 *				C-TPDU: CLA|INS|P1|P2|Le2
 *			Case2E-2: Le > 256
 *				C-TPDU: CLA|INS|P1|P2|0x00
  *		R-TPDU: Data|SW1|SW2
 *		R-APDU: Data|SW1|SW2
*	Case3(extended):		
 *		C-APDU:	CLA|INS|P1|P2|Lc0|Lc1|Lc2|Data
 *			Case3E-1: 0 < Lc < 256, Lc0 =0x00 Lc1 = 0x00 Lc2 != 0x00
 *				C-TPDU: CLA|INS|P1|P2|Lc2|Data
 *			Case3E-2: Lc >= 256, Lc0 =0x00 Lc1 != 0x00 Lc2 = any
 *				Must support ENVELOP command. INS = ENVELOPE 
 *				split the APDU into segments of length less than 256
 *				C-TPDU: CLA|INS|P1|P2|P3|Data
 *	Case4(extended):
 *		C-APDU:	CLA|INS|P1|P2|Lc0|Lc1|Lc2|Data|Le0|Le1|Le2	
 *			Case 4E-1: Lc < 256, Lc0 =0x00 Lc1 = 0x00 Lc2 != 0x00
 *				C-TPDU: CLA|INS|P1|P2|Lc2|Data
 *			Case 4E-2: Lc >= 256, Lc0 =0x00 Lc1 != 0x00 Lc2 = any
 *				see Case 3E-2
 * T = 1:
 *	Case 1:
 *		C-APDU:	CLA|INS|P1|P2		
 *		I-BLOCK:CLA|INS|P1|P2
 *		
 *		R-BLOCK:SW1|SW2		
 *		R-APDU:	SW1|SW2
 *	Case 2:(Short or extended)
 *		C-APDU:	CLA|INS|P1|P2|Le		
 *		I-BLOCK:CLA|INS|P1|P2|Le
 *		
 *		R-BLOCK:Data(le)|SW1|SW2 
 *		     or Data 
 *			...
 *			...|SW1|SW2
 *		R-APDU:	Data(le)|SW1|SW2
 *
 *	Case 3:(Short or extended)
 *		C-APDU:	CLA|INS|P1|P2|Lc|Data		
 *		I-BLOCK:CLA|INS|P1|P2|Lc|Data
 *		     or CLA|INS|P1|P2|Lc|Data
 *			...
 *			Data
 *
 *		R-BLOCK:SW1|SW2		
 *		R-APDU:	SW1|SW2
 *	Case 4:(Short or extended)
 *		C-APDU:	CLA|INS|P1|P2|Lc|Data|Le		
 *		I-BLOCK:CLA|INS|P1|P2|Lc|Data|Le
 *		     or CLA|INS|P1|P2|Lc|Data
 *			...
 *			Data|Le
 *		
 *		R-BLOCK:Data(le)|SW1|SW2 
 *		     or Data 
 *			...
 *			...|SW1|SW2
 *		R-APDU:	Data(le)|SW1|SW2
 *
 */


size_t scard_apdu_get_length(const struct scard_apdu *apdu, 
				    unsigned int proto)
{
	size_t ret = 4;

	switch (apdu->cse) {
	case SCARD_APDU_CASE_1:
		if (proto == SCARD_PROTOCOL_T0)
			ret++;
		break;
	case SCARD_APDU_CASE_2_SHORT:
		ret++;
		break;
	case SCARD_APDU_CASE_3_SHORT:
		ret += 1 + apdu->lc;
		break;
	case SCARD_APDU_CASE_4_SHORT:
		/* The command APDU is mapped onto the T=0 command TPDU by 
		 * cutting the last byte of the body.*/
		ret += 1 + apdu->lc + (proto == SCARD_PROTOCOL_T0 ? 0 : 1);
		break;

	case SCARD_APDU_CASE_2_EXT:
		ret += (proto == SCARD_PROTOCOL_T0 ? 1 : 3);
		break;
	case SCARD_APDU_CASE_3_EXT:
		ret += apdu->lc + (proto == SCARD_PROTOCOL_T0 ? 1 : 3);
		break;
	case SCARD_APDU_CASE_4_EXT:
		ret += apdu->lc + (proto == SCARD_PROTOCOL_T0 ? 1 : 5);/*FIXME: + 6(Lc + Le)?*/
		break;
	default:
		return 0;
	}
	return ret;
}

int scard_apdu2tpdu(const struct scard_apdu *apdu, uint32_t proto, 
		     uint8_t *out, size_t outlen)
{
	uint8_t     *p = out;
	size_t len = scard_apdu_get_length(apdu, proto);

	if (out == NULL || outlen < len)
		return SCARD_ERR_INVALID_ARGS;

	*p++ = apdu->cla;
	*p++ = apdu->ins;
	*p++ = apdu->p1;
	*p++ = apdu->p2;
	
	switch (apdu->cse) {
	case SCARD_APDU_CASE_1:
		/* T0 needs an additional 0x00 byte */
		if (proto == SCARD_PROTOCOL_T0)
			*p++ = 0x00;
		break;
	case SCARD_APDU_CASE_2_SHORT:
		*p++ = (uint8_t)apdu->le;
		break;
	case SCARD_APDU_CASE_3_SHORT:
		*p++ = (uint8_t)apdu->lc;
		memcpy(p, apdu->data, apdu->lc);
		p += apdu->lc;
		break;
	case SCARD_APDU_CASE_4_SHORT:
		*p++ = (uint8_t)apdu->lc;
		memcpy(p, apdu->data, apdu->lc);
		p += apdu->lc;
		/* in case of T0 no Le byte is added */
		if (proto != SCARD_PROTOCOL_T0)
			*p++ = (uint8_t)apdu->le;
		break;
	case SCARD_APDU_CASE_2_EXT:
		if (proto == SCARD_PROTOCOL_T0)
			/* T0 extended APDUs look just like short APDUs */
			*p++ = (uint8_t)apdu->le;
		else {
			/* in case of T1 always use 3 bytes for length */
			*p++ = (uint8_t)0x00;
			*p++ = (uint8_t)(apdu->le >> 8);
			*p++ = (uint8_t)apdu->le;
		}
		break;
	case SCARD_APDU_CASE_3_EXT:
		if (proto == SCARD_PROTOCOL_T0) {
			/* in case of T0 the command is transmitted in chunks
			 * < 255 using the ENVELOPE command ... */
			if (apdu->lc > 255) {
				/* ... so if Lc is greater than 255 bytes 
				 * an error has occurred on a higher level */
				scard_log(SCARD_LOG_ERR, "invalid Lc length for CASE 3 "
					"extended APDU (need ENVELOPE)");
				return SCARD_ERR_INVALID_ARGS;
			}
		} else {
			/* in case of T1 always use 3 bytes for length */
			*p++ = (uint8_t)0x00;
			*p++ = (uint8_t)(apdu->lc >> 8);
			*p++ = (uint8_t)apdu->lc;
		}
		memcpy(p, apdu->data, apdu->lc);
		p += apdu->lc;
		break;
	case SCARD_APDU_CASE_4_EXT:
		if (proto == SCARD_PROTOCOL_T0) {
			/* again a T0 extended case 4 APDU looks just
			 * like a short APDU, the additional data is
			 * transferred using ENVELOPE and GET RESPONSE */
			*p++ = (uint8_t)apdu->lc;
			memcpy(p, apdu->data, apdu->lc);
			p += apdu->lc & 0xff;
		} else {
			*p++ = (uint8_t)0x00;
			*p++ = (uint8_t)(apdu->lc >> 8);
			*p++ = (uint8_t)apdu->lc;
			memcpy(p, apdu->data, apdu->lc);
			p += apdu->lc;
			/* only 2 bytes are use to specify the length of the
			 * expected data */
			*p++ = (uint8_t)(apdu->le >> 8);
			*p++ = (uint8_t)apdu->le;
		}
		break;
	}

	return SCARD_SUCCESS;
}

int scard_apdu_get_octets(const struct scard_apdu *apdu, uint8_t **rbuf,
			  size_t *rbuf_len, unsigned int proto)
{
	size_t	nlen;
	uint8_t	*nbuf;

	if (apdu == NULL || rbuf == NULL || rbuf_len == NULL)
		return SCARD_ERR_INVALID_ARGS;

	nlen = scard_apdu_get_length(apdu, proto);
	if (nlen == 0)
		return SCARD_ERR_UNSPECIFIED;
	nbuf = malloc(nlen);
	if (nbuf == NULL)
		return SCARD_ERR_NO_MEM;
	/* encode the APDU in the buffer */
	if (scard_apdu2tpdu(apdu, proto, nbuf, nlen) != SCARD_SUCCESS)
		return SCARD_ERR_UNSPECIFIED;
	*rbuf = nbuf;
	*rbuf_len = nlen;

	return SCARD_SUCCESS;
}

void scard_detect_apdu_cse(const struct scard_handle *handle, 
			   struct scard_apdu *apdu)
{
	if (apdu->cse == SCARD_APDU_CASE_2 || apdu->cse == SCARD_APDU_CASE_3 ||
	    apdu->cse == SCARD_APDU_CASE_4) {
		int btype = apdu->cse & SCARD_APDU_SHORT_MASK;
		/* if either Lc or Le is bigger than the maximun for
		 * short APDUs and the card supports extended APDUs
		 * use extended APDUs (unless Lc is greater than
		 * 255 and command chaining is activated) */
		if ((apdu->le > 256 || (apdu->lc > 255 && (apdu->flags & SCARD_APDU_FLAG_CHAINING) == 0)) &&
		    (handle->caps & SCARD_CAPS_APDU_EXT) != 0)
			btype |= SCARD_APDU_EXT;
		apdu->cse = btype;
	}
}

int scard_check_apdu(const struct scard_handle *handle, 
			   struct scard_apdu *apdu)
{
	if ((apdu->cse & ~SCARD_APDU_SHORT_MASK) == 0) {
		if (apdu->le > SCARD_SHORT_LE_MAX ||
			(apdu->lc > SCARD_SHORT_LC_MAX && (apdu->flags & SCARD_APDU_FLAG_CHAINING) == 0))
			goto error;
	} else if ((apdu->cse & SCARD_APDU_EXT) != 0) {
		if ((handle->caps & SCARD_CAPS_APDU_EXT) == 0)
			goto error;
		if (apdu->le > SCARD_EXT_LE_MAX || apdu->lc > SCARD_EXT_LC_MAX)
			goto error;
	} else {
		goto error;
	}

	switch (apdu->cse & SCARD_APDU_SHORT_MASK) {
	case SCARD_APDU_CASE_1:
		if (apdu->datalen != 0 || apdu->lc != 0 || apdu->le != 0)
			goto error;
		break;
	case SCARD_APDU_CASE_2_SHORT:
		if (apdu->datalen != 0 || apdu->lc != 0)
			goto error;
		if (apdu->le == 0 || apdu->resplen == 0 || apdu->resp == NULL)
			goto error;
		if (apdu->resplen < apdu->le)
			goto error;
		break;
	case SCARD_APDU_CASE_3_SHORT:
		if (apdu->datalen == 0 || apdu->data == NULL || apdu->lc == 0)
			goto error;
		if (apdu->le != 0)
			goto error;
		if (apdu->datalen < apdu->lc)
			goto error;
		break;
	case SCARD_APDU_CASE_4_SHORT:
		if (apdu->datalen == 0 || apdu->data == NULL || apdu->lc == 0)
			goto error;
/*
		if (apdu->le == 0 || apdu->resplen == 0 || apdu->resp == NULL)
			goto error;
		if (apdu->resplen < apdu->le)
			goto error;
		if (apdu->datalen != apdu->lc)
			goto error;
*/
		break;
	default:
		return SCARD_ERR_INVALID_ARGS;
	}
	return SCARD_SUCCESS;
error:
	return SCARD_ERR_INVALID_ARGS;
}
