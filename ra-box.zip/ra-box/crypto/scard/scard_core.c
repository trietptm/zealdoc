#include "scard_priv.h"

int scard_logger = 0;
log_source_t scard_log_source = {
	"scard"
};

void scard_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(scard_logger, level, format, ap);
	va_end(ap);
}

void scard_log_xxd(int level, const char *msg, const uint8_t *buf, 
		   size_t buf_len)
{
	char buf_out[2048], *p = buf_out;

	memset(buf_out, 0, sizeof(buf_out));

	strncpy(p, msg, sizeof(buf_out) - 1);
	p += strlen(buf_out);
	scard_bin_to_hex(buf, buf_len, p, buf_out + sizeof(buf_out) - p, ':');
	printf("%s\n", buf_out);	
}

static int __init scard_log_init(void)
{
	scard_logger = log_register_source(&scard_log_source);
	return !scard_logger;
}

static void __exit scard_log_exit(void)
{
	log_unregister_source(scard_logger);
}

#define SCARD_TOOL_DESC		"Smart card devices"

ui_argument_t scard_fileid_args = {
	"fileid",
	"file id",
	NULL,
	UI_TYPE_STRING,
};

ui_argument_t scard_reader_args = {
	"idex",
	"reader index",
	NULL,
	UI_TYPE_INT,
};

ui_argument_t scard_rec_nr_args = {
	"number",
	"record number",
	NULL,
	UI_TYPE_INT,
};

ui_argument_t scard_num_args = {
	"num",
	 "number",
	 NULL,
	 UI_TYPE_INT,
};

ui_argument_t scard_read_bin_args[] = {
	{"offset",
	 "offset",
	 NULL,
	 UI_TYPE_INT,},
	{"len",
	 "length",
	 NULL, 
	 UI_TYPE_INT,},
};

ui_argument_t scard_write_bin_args[] = {
	{"offset",
	 "offset",
	 NULL,
	 UI_TYPE_INT,},
	{"data",
	 "data written to file",
	 NULL, 
	 UI_TYPE_STRING,},
};


ui_argument_t scard_pin_verify_args[] = {
	{"ref",
	 "pin reference",
	 NULL,
	 UI_TYPE_INT,},
	{"pin",
	 "pin data",
	 NULL, 
	 UI_TYPE_STRING,},
};

ui_argument_t scard_pin_modify_args[] = {
	{"ref",
	 "pin reference",
	 NULL,
	 UI_TYPE_INT,},
	{"pin1",
	 "pin1 data",
	 NULL, 
	 UI_TYPE_STRING,},
	{"pin2",
	 "pin2 data",
	 NULL, 
	 UI_TYPE_STRING,},
};


ui_command_t scard_connect_command = {
	"connect",
	"connect card",
	".scard",
	UI_CMD_SINGLE_INST,
	&scard_reader_args,
	1,
	LIST_HEAD_INIT(scard_connect_command.link),
	scard_tool_connect,
};

ui_command_t scard_disconnect_command = {
	"disconnect",
	"disconnect card",
	".scard",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(scard_disconnect_command.link),
	scard_tool_disconnect,
};

ui_command_t scard_select_command = {
	"select",
	"select file",
	".scard",
	UI_CMD_SINGLE_INST,
	&scard_fileid_args,
	1,
	LIST_HEAD_INIT(scard_select_command.link),
	scard_tool_select,
};

ui_command_t scard_read_bin_command = {
	"read_binary",
	"reader binary",
	".scard",
	UI_CMD_SINGLE_INST,
	scard_read_bin_args,
	2,
	LIST_HEAD_INIT(scard_read_bin_command.link),
	scard_tool_read_binary,
};

ui_command_t scard_update_bin_command = {
	"update_binary",
	"update binary",
	".scard",
	UI_CMD_SINGLE_INST,
	scard_write_bin_args,
	2,
	LIST_HEAD_INIT(scard_update_bin_command.link),
	scard_tool_update_binary,
};

ui_command_t scard_read_record_command = {
	"read_record",
	"read record",
	".scard",
	UI_CMD_SINGLE_INST,
	&scard_rec_nr_args,
	1,
	LIST_HEAD_INIT(scard_read_record_command.link),
	scard_tool_read_record,
};

ui_command_t scard_write_record_command = {
	"write_record",
	"write record",
	".scard",
	UI_CMD_SINGLE_INST,
	&scard_rec_nr_args,
	1,
	LIST_HEAD_INIT(scard_write_record_command.link),
	scard_tool_write_record,
};

ui_command_t scard_append_record_command = {
	"append_record",
	"append record",
	".scard",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(scard_append_record_command.link),
	scard_tool_append_record,
};

ui_command_t scard_update_record_command = {
	"update_record",
	"update record",
	".scard",
	UI_CMD_SINGLE_INST,
	&scard_rec_nr_args,
	1,
	LIST_HEAD_INIT(scard_update_record_command.link),
	scard_tool_update_record,
};

ui_command_t scard_get_challenge_command = {
	"get_challenge",
	"get challenge",
	".scard",
	UI_CMD_SINGLE_INST,
	&scard_num_args,
	1,
	LIST_HEAD_INIT(scard_get_challenge_command.link),
	scard_tool_get_challenge,
};

ui_command_t scard_pin_verify_command = {
	"pin_verify",
	"pin verify",
	".scard",
	UI_CMD_SINGLE_INST,
	scard_pin_verify_args,
	2,
	LIST_HEAD_INIT(scard_pin_verify_command.link),
	scard_tool_pin_verify,
};

ui_command_t scard_pin_change_command = {
	"pin_change",
	"pin change",
	".scard",
	UI_CMD_SINGLE_INST,
	scard_pin_modify_args,
	3,
	LIST_HEAD_INIT(scard_pin_change_command.link),
	scard_tool_pin_change,
};

ui_command_t scard_pin_unblock_command = {
	"pin_unblock",
	"pin unblock",
	".scard",
	UI_CMD_SINGLE_INST,
	scard_pin_modify_args,
	3,
	LIST_HEAD_INIT(scard_pin_unblock_command.link),
	scard_tool_pin_unblock,
};

ui_command_t scard_create_file_cmd = {
	"create_file",
	"create file",
	".scard",
	UI_CMD_SINGLE_INST,
	&scard_fileid_args,
	1,
	LIST_HEAD_INIT(scard_create_file_cmd.link),
	scard_tool_create_file,
};

ui_command_t scard_delete_file_cmd = {
	"delete_file",
	"delete file",
	".scard",
	UI_CMD_SINGLE_INST,
	&scard_fileid_args,
	1,
	LIST_HEAD_INIT(scard_delete_file_cmd.link),
	scard_tool_delete_file,
};

ui_schema_t scard_schema[] = {
	{ UI_TYPE_CLASS, 
	  UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, 
	  NULL, 
	  NULL,
	  ".scard", 
	  "scard", 
	  SCARD_TOOL_DESC },
	
	{ UI_TYPE_NONE },
};

static int __init scard_cmd_init(void)
{
	ui_register_schema(scard_schema);
	ui_register_command(&scard_select_command);
	ui_register_command(&scard_connect_command);
	ui_register_command(&scard_disconnect_command);
	ui_register_command(&scard_read_bin_command);
	ui_register_command(&scard_update_bin_command);
	ui_register_command(&scard_read_record_command);
	ui_register_command(&scard_write_record_command);
	ui_register_command(&scard_append_record_command);
	ui_register_command(&scard_update_record_command);
	ui_register_command(&scard_get_challenge_command);
	ui_register_command(&scard_pin_verify_command);
	ui_register_command(&scard_pin_change_command);
	ui_register_command(&scard_pin_unblock_command);
	ui_register_command(&scard_create_file_cmd);
	ui_register_command(&scard_delete_file_cmd);

	return 0;
}
	
static void __exit scard_cmd_exit(void)
{
	ui_unregister_command(&scard_delete_file_cmd);
	ui_unregister_command(&scard_create_file_cmd);
	ui_unregister_command(&scard_pin_unblock_command);
	ui_unregister_command(&scard_pin_change_command);
	ui_unregister_command(&scard_pin_verify_command);
	ui_unregister_command(&scard_get_challenge_command);
	ui_unregister_command(&scard_update_record_command);
	ui_unregister_command(&scard_append_record_command);
	ui_unregister_command(&scard_write_record_command);
	ui_unregister_command(&scard_read_record_command);
	ui_unregister_command(&scard_update_bin_command);
	ui_unregister_command(&scard_read_bin_command);
	ui_unregister_command(&scard_disconnect_command);
	ui_unregister_command(&scard_connect_command);
	ui_unregister_command(&scard_select_command);
	ui_unregister_schema(scard_schema);
}

static int __init scard_context_init(void)
{
	/* Add more card drivers */
	scard_register_card_muscle();
	scard_register_card_watchdata();
	
	/* Put the iso7816 last*/
	scard_register_card_iso7816();	

	return 0;
}

static void __exit scard_context_exit(void)
{
	scard_unregister_card_iso7816();
	scard_unregister_card_watchdata();
	scard_unregister_card_muscle();
}

modlinkage int __init scard_init(void)
{
	scard_log_init();
	scard_cmd_init();
	scard_context_init();

	return 0;
}

modlinkage void __exit scard_exit(void)
{
	scard_context_exit();
	scard_cmd_exit();
	scard_log_exit();
}

subsys_initcall(scard_init);
subsys_exitcall(scard_exit);
