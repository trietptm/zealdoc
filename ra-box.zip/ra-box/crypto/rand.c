#include "crypto_priv.h"
#include <isaac.h>

static isaac_t crypto_rand_pool;	/* across multiple calls */
static volatile int crypto_rand_index = -1;

#define FNV_MAGIC_INIT (0x811c9dc5)
#define FNV_MAGIC_PRIME (0x01000193)

static uint32_t crypto_rand_hash(const void *data, size_t size);
static uint32_t crypto_rand(void);

/*
 * A fast hash function.  For details, see:
 *
 * http://www.isthe.com/chongo/tech/comp/fnv/
 *
 * Which also includes public domain source.  We've re-written
 * it here for our purposes.
 */
uint32_t crypto_rand_hash(const void *data, size_t size)
{
	const uint8_t *p = data;
	const uint8_t *q = p + size;
	uint32_t hash = FNV_MAGIC_INIT;

	/* FNV-1 hash each octet in the buffer */
	while (p != q) {
		/* multiple by 32-bit magic FNV prime, mod 2^32 */
		hash *= FNV_MAGIC_PRIME;
#if 0
		/* potential optimization */
		hash += (hash<<1) + (hash<<4) + (hash<<7) + (hash<<8) + (hash<<24);
#endif
		/* XOR the 8-bit quantity into the bottom of the hash */
		hash ^= (uint32_t) (*p++);
	}
	return hash;
}

void crypto_rand_seed(const void *data, size_t size)
{
	uint32_t hash;

	/* ensure that the pool is initialized */
	if (crypto_rand_index < 0) {
		int fd = -1;
		
		memset(&crypto_rand_pool, 0, sizeof(crypto_rand_pool));

#ifndef WIN32
		fd = open("/dev/urandom", O_RDONLY);
#endif
		if (fd >= 0) {
			size_t total;
			ssize_t this;

			total = this = 0;
			while (total < sizeof(crypto_rand_pool.randrsl)) {
				this = read(fd, crypto_rand_pool.randrsl,
					    sizeof(crypto_rand_pool.randrsl) - total);
				if ((this < 0) && (errno != EINTR)) break;
				if (this > 0) total += this;
 			}
			close(fd);
		} else {
			crypto_rand_pool.randrsl[0] = fd;
			crypto_rand_pool.randrsl[1] = time(NULL);
			crypto_rand_pool.randrsl[2] = errno;
		}

		isaac_init(&crypto_rand_pool, 1);
		crypto_rand_index = 0;
	}

	if (!data) return;

	/* hash the user data */
	hash = crypto_rand_hash(data, size);
	
	crypto_rand_pool.randrsl[crypto_rand_index & 0xff] ^= hash;
	crypto_rand_index++;
	crypto_rand_index &= 0xff;

	/* churn the pool every so often after seeding it */
	if (((int) (hash & 0xff)) == crypto_rand_index)
		isaac_rand(&crypto_rand_pool);
}

/* return a 32-bit random number */
uint32_t crypto_rand(void)
{
	uint32_t num;

	/* ensure that the pool is initialized */
	if (crypto_rand_index < 0)
		crypto_rand_seed(NULL, 0);
	/*
	 * We don't return data directly from the pool.
	 * Rather, we return a summary of the data.
	 */
	num = crypto_rand_pool.randrsl[crypto_rand_index & 0xff];
	crypto_rand_index++;
	crypto_rand_index &= 0xff;

	/* every so often, churn the pool */
	if (((int) (num & 0xff)) == crypto_rand_index)
		isaac_rand(&crypto_rand_pool);
	return num;
}

/* magic_init - Initialize the magic number generator.
 *
 * Attempts to compute a random number seed which will not repeat.
 * The current method uses the current hostid, current process ID
 * and current time, currently.
 */
int crypto_rand_start(void)
{
	struct timeval t;
	const char *host;
	
	gettimeofday(&t, NULL);
	host = net_host_name();
	if (host)
		crypto_rand_seed(host, strlen(host));
	crypto_rand_seed(&t, sizeof (struct timeval));
	return 0;
}

/* magic - Returns the next magic number.
 */
uint32_t crypto_rand_number(void)
{
	return (uint32_t) crypto_rand();
}

/* crypto_rand_bytes - Fill a buffer with random bytes.
 */
void crypto_rand_bytes(uint8_t *buf, size_t len)
{
	int i;
	uint32_t rand_num;
	
	for (i = 0; i < (int)len; ++i) {
		rand_num = crypto_rand();
		buf[i] = (uint8_t)rand_num;
	}
}
