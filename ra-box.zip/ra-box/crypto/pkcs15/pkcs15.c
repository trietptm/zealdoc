#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"
#include "p15_obj.h"

DECLARE_LIST(p15_cards);

#define for_each_card(e)		\
	list_for_each_entry(struct p15_card, e, &p15_cards, link)
#define for_each_card_safe(e, n)	\
	list_for_each_entry_safe(struct p15_card, e, n, &p15_cards, link)

#define for_each_df(e, card)		\
	list_for_each_entry(struct pkcs15_df, e, &card->df_list, link)
#define for_each_df_safe(e, n, card)	\
	list_for_each_entry_safe(struct pkcs15_df, e, n, &card->df_list, link)

#define for_each_obj(o, card)		\
	list_for_each_entry(struct pkcs15_object, o, &card->obj_list, link)
#define for_each_obj_safe(o, n, card)	\
	list_for_each_entry_safe(struct pkcs15_object, o, n, &card->obj_list, link)

#define for_each_unu(o, card)		\
	list_for_each_entry(struct p15_unusedspace, o, &card->unused_list, link)
#define for_each_unu_safe(o, n, card)	\
	list_for_each_entry_safe(struct p15_unusedspace, o, n, &card->unused_list, link)

typedef int (*p15_obj_cb)(struct pkcs15_object *, void *);
typedef int (*p15_encode_func)(const struct pkcs15_object *obj,
			       uint8_t **buf, size_t *buflen);
typedef	int (*p15_decode_func)(struct p15_card *p15card,
			       struct pkcs15_object *obj,
			       const uint8_t ** buf, size_t *buflen);

static void pkcs15_free_object(struct pkcs15_object *obj);
static int pkcs15_encode_tokeninfo(struct pkcs15_tokeninfo *ti,
			    uint8_t **buf, size_t *buflen);
static int pkcs15_compare_id(const struct pkcs15_id *id1,
			     const struct pkcs15_id *id2);

static int pkcs15_get_objects_cond(struct p15_card *p15card, uint16_t type,
				   p15_obj_cb ocb, void *cb_arg,
				   struct pkcs15_object **ret, size_t ret_size,
				   p15_user_cb ucb, void *cbarg);

static int __p15_search_objects(struct p15_card *p15card,
				uint16_t class_mask, uint16_t type,
				p15_obj_cb obj_cb, void *objcb_arg,
				struct pkcs15_object **ret, size_t ret_size,
				p15_user_cb cb, void *cbarg);

static int compare_obj_id(struct pkcs15_object *obj, const struct pkcs15_id *id);
static int obj_app_oid(struct pkcs15_object *obj, const struct icc_object_id *app_oid);
static int compare_obj_usage(struct pkcs15_object *obj, 
			     unsigned int mask, unsigned int value);
static int compare_obj_flags(struct pkcs15_object *obj,
			     unsigned int mask, unsigned int value);
static int compare_obj_reference(struct pkcs15_object *obj, int value);
static int compare_obj_path(struct pkcs15_object *obj, const struct icc_path *path);
static int compare_obj_key(struct pkcs15_object *obj, void *arg);
static int pkcs15_add_object(struct p15_card *p15card, struct pkcs15_object *obj);

static int find_by_key(struct p15_card *p15card,
		       uint16_t type, struct pkcs15_search_key *sk,
		       struct pkcs15_object **out,
		       p15_user_cb ucb, void *cbarg);

static void pkcs15_free_object(struct pkcs15_object *obj);
static void pkcs15_delete_all_unused(struct p15_card *p15card);

static void p15_set_decode_func(p15_decode_func func, int type);
static void p15_set_encode_func(p15_encode_func func, int type);

static int p15_df_type_unknown(int type)
{
	/* PKCS15_PRKDF = 0
	 * PKCS15_DF_TYPE_COUNT	= 9
	 */
	if (type < PKCS15_PRKDF || type >= PKCS15_DF_TYPE_COUNT)
		return 1;
	return 0;
}

static void p15_set_encode_func(p15_encode_func func, int type)
{
	switch (type) {
	case PKCS15_PRKDF:
		func = pkcs15_encode_prkdf_entry;
		break;
	case PKCS15_PUKDF:
	case PKCS15_PUKDF_TRUSTED:
		func = pkcs15_encode_pukdf_entry;
		break;
	case PKCS15_CDF:
	case PKCS15_CDF_TRUSTED:
	case PKCS15_CDF_USEFUL:
		func = pkcs15_encode_cdf_entry;
		break;
	case PKCS15_DODF:
		func = pkcs15_encode_dodf_entry;
		break;
#if 0
	case PKCS15_AODF:
		func = pkcs15_encode_aodf_entry;
		break;
#endif
	}
}

static void p15_set_decode_func(p15_decode_func func, int type)
{
	switch (type) {
	case PKCS15_PRKDF:
		func = pkcs15_decode_prkdf_entry;
		break;
	case PKCS15_PUKDF:
		func = pkcs15_decode_pukdf_entry;
		break;
	case PKCS15_CDF:
	case PKCS15_CDF_TRUSTED:
	case PKCS15_CDF_USEFUL:
		func = pkcs15_decode_cdf_entry;
		break;
	case PKCS15_DODF:
		func = pkcs15_decode_dodf_entry;
		break;
#if 0
	case PKCS15_AODF:
		func = pkcs15_decode_aodf_entry;
		break;
#endif
	}
}

typedef struct p15_user_cb_t {
	p15_user_cb cb;
	void *arg;
	int ret;

	void *free_data;
} p15_cb_t;


static p15_cb_t *__make_cb_t(p15_user_cb cb, void *arg)
{
	p15_cb_t *t = malloc(sizeof (p15_cb_t));

	if (!t) return NULL;
	memset(t, 0, sizeof (p15_cb_t));

	t->cb = cb;
	t->arg = arg;
	t->ret = -1;
	t->free_data = NULL;
	return t;
}

static void __clean_cb_t_no_cb(p15_cb_t *t)
{
	if (t) {
		if (t->free_data) free(t->free_data);
		free(t);
	}
}

static void __clean_cb_t(p15_cb_t *t)
{
	if (!t)
		return;
	if (t->cb)
		t->cb(t->arg, t->ret);
	__clean_cb_t_no_cb(t);
}

static struct pkcs15_search_key *__new_search_key(void)
{
	struct pkcs15_search_key *sk;

	sk = malloc(sizeof (struct pkcs15_search_key));
	if (!sk)
		return NULL;
	memset(sk, 0, sizeof (struct pkcs15_search_key));
	return sk;
}

void p15_app_count_inc(struct p15_card *hd)
{
	if (hd)
		hd->app_count++;
}

void p15_app_count_dec(struct p15_card *hd)
{
	if (hd)
		hd->app_count--;
}

int p15_app_count(struct p15_card *hd)
{
	return hd->app_count;
}

int p15_app_is_exist(struct p15_card *hd, struct icc_app_info *app)
{
	struct icc_app_info *apps = hd->app[0];
	int i;

	for (i = 0; apps; i++) {
		if ((0 == memcmp(apps->aid, app->aid, app->aid_len)) &&
	    	    (0 == memcmp(apps->path.value, app->path.value, app->path.len)))
				return 1;
		apps = hd->app[i];
	}
	return 0;
}

struct icc_app_info **p15_app_poniter(struct p15_card *hd)
{
	return hd->app;
}

struct p15_card *pkcs15_card_new(void)
{
	struct p15_card *card;

	card = malloc(sizeof(struct p15_card));
	if (!card)
		return NULL;
	memset(card, 0, sizeof(struct p15_card));

	list_init(&card->df_list);
	list_init(&card->obj_list);

	list_init(&card->link);
	list_insert_before(&card->link, &p15_cards);

	return card;
}

void pkcs15_card_free(struct p15_card *p15_card)
{
	struct pkcs15_df *pos_df, *n_df;
	struct pkcs15_object *pos_obj, *n_obj;

	if (!p15_card) return;
	/* TODO: free members */

	list_for_each_entry_safe(struct pkcs15_df, pos_df, n_df,
				 &p15_card->df_list, link) {
		list_delete(&pos_df->link);
		if (pos_df->filp)
			icc_file_free(pos_df->filp);
		free(pos_df);
	}
	list_for_each_entry_safe(struct pkcs15_object, pos_obj, n_obj,
				 &p15_card->obj_list, link) {
		list_delete(&pos_obj->link);
		pkcs15_free_object(pos_obj);
	}
	
	if (p15_card->app_root)
		icc_file_free(p15_card->app_root);
	if (p15_card->odf)
		icc_file_free(p15_card->odf);
	if (p15_card->ef_dir)
		icc_file_free(p15_card->ef_dir);
	if (p15_card->tif)
		icc_file_free(p15_card->tif);
	if (p15_card->unused)
		icc_file_free(p15_card->unused);
	if (p15_card->tokeninfo.serial_num)
		free(p15_card->tokeninfo.serial_num);
	if (p15_card->tokeninfo.manufacturer_id)
		free(p15_card->tokeninfo.manufacturer_id);
	if (p15_card->tokeninfo.label)
		free(p15_card->tokeninfo.label);
	if (p15_card->tokeninfo.last_update)
		free(p15_card->tokeninfo.last_update);
	if (p15_card->tokeninfo.prefered_lang)
		free(p15_card->tokeninfo.prefered_lang);
	if (p15_card->tokeninfo.sec_info) {
		size_t i;

		for (i = 0; i < p15_card->tokeninfo.sec_info_num; i++)
			free(p15_card->tokeninfo.sec_info[i]);
		free(p15_card->tokeninfo.sec_info);
	}
	if (p15_card->app_count > 0) {
		int i = 0;
		for(; i < p15_card->app_count; i++)
			free(p15_card->app[i]);
	}
	list_delete(&p15_card->link);
	free(p15_card);
}

/* lets take over the PKCS#15 app */
int p15_card_start(struct p15_card *hd)
{
	return -1;
}


/* PKCS#15 general things */

static const struct pkcs15_asn1_entry c_asn1_twlabel[] = {
	{ "twlabel", PKCS15_ASN1_UTF8STRING, PKCS15_ASN1_TAG_UTF8STRING, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_toki[] = {
	{ "version",        PKCS15_ASN1_INTEGER,      PKCS15_ASN1_TAG_INTEGER, 0, NULL, NULL },
	{ "serialNumber",   PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_OCTET_STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "manufacturerID", PKCS15_ASN1_UTF8STRING,   PKCS15_ASN1_TAG_UTF8STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "label",	    PKCS15_ASN1_UTF8STRING,   PKCS15_ASN1_CTX | 0, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	/* XXX the Taiwanese ID card erroneously uses explicit tagging */
	{ "label-tw",       PKCS15_ASN1_STRUCT,       PKCS15_ASN1_CTX | 0 | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "tokenflags",	    PKCS15_ASN1_BIT_FIELD,    PKCS15_ASN1_TAG_BIT_STRING, 0, NULL, NULL },
	{ "seInfo",	    PKCS15_ASN1_SE_INFO,	  PKCS15_ASN1_CONS | PKCS15_ASN1_TAG_SEQUENCE, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "recordInfo",	    PKCS15_ASN1_STRUCT,       PKCS15_ASN1_CONS | PKCS15_ASN1_CTX | 1, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "supportedAlgorithms", PKCS15_ASN1_STRUCT,  PKCS15_ASN1_CONS | PKCS15_ASN1_CTX | 2, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "issuerId",       PKCS15_ASN1_UTF8STRING,   PKCS15_ASN1_CTX | 3, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "holderId",       PKCS15_ASN1_UTF8STRING,   PKCS15_ASN1_CTX | 4, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "lastUpdate",     PKCS15_ASN1_GENERALIZEDTIME, PKCS15_ASN1_CTX | 5, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "preferredLanguage", PKCS15_ASN1_PRINTABLESTRING, PKCS15_ASN1_TAG_PRINTABLESTRING, PKCS15_ASN1_OPTIONAL, NULL, NULL }, 
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_tokeninfo[] = {
	{ "TokenInfo", PKCS15_ASN1_STRUCT, PKCS15_ASN1_CONS | PKCS15_ASN1_TAG_SEQUENCE, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

int pkcs15_parse_tokeninfo(struct pkcs15_tokeninfo *ti,
			   const uint8_t *buf, size_t blen)
{
	int r;
	uint8_t serial[128];
	size_t i;
	size_t serial_len = sizeof(serial);
	uint8_t mnfid[PKCS15_LABEL_MAX];
	size_t mnfid_len  = sizeof(mnfid);
	uint8_t label[PKCS15_LABEL_MAX];
	size_t label_len = sizeof(label);
	uint8_t last_update[32];
	size_t lupdate_len = sizeof(last_update) - 1;
	size_t flags_len   = sizeof(ti->flags);
	struct pkcs15_asn1_entry asn1_toki[14], asn1_tokeninfo[3], asn1_twlabel[3];
	uint8_t preferred_language[3];
	size_t lang_length = sizeof(preferred_language);

	memset(last_update, 0, sizeof(last_update));
	pkcs15_copy_asn1_entry(c_asn1_twlabel, asn1_twlabel);
	pkcs15_copy_asn1_entry(c_asn1_toki, asn1_toki);
	pkcs15_copy_asn1_entry(c_asn1_tokeninfo, asn1_tokeninfo);
	pkcs15_format_asn1_entry(asn1_twlabel, label, &label_len, 0);
	pkcs15_format_asn1_entry(asn1_toki + 0, &ti->version, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 1, serial, &serial_len, 0);
	pkcs15_format_asn1_entry(asn1_toki + 2, mnfid, &mnfid_len, 0);
	pkcs15_format_asn1_entry(asn1_toki + 3, label, &label_len, 0);
	pkcs15_format_asn1_entry(asn1_toki + 4, asn1_twlabel, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 5, &ti->flags, &flags_len, 0);
	pkcs15_format_asn1_entry(asn1_toki + 6, &ti->sec_info, &ti->sec_info_num, 0);
	pkcs15_format_asn1_entry(asn1_toki + 7, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 8, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 9, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 10, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 11, last_update, &lupdate_len, 0);
	pkcs15_format_asn1_entry(asn1_toki + 12, preferred_language, &lang_length, 0);
	pkcs15_format_asn1_entry(asn1_tokeninfo, asn1_toki, NULL, 0);
	
	r = pkcs15_asn1_decode(asn1_tokeninfo, buf, blen, NULL, NULL);
	if (r)
		return r;
	
	ti->version += 1;
	ti->serial_num = (char *) malloc(serial_len * 2 + 1);
	if (ti->serial_num == NULL)
		return PKCS15_ERR_NO_MEM;
	ti->serial_num[0] = 0;
	for (i = 0; i < serial_len; i++) {
		char byte[3];

		sprintf(byte, "%02X", serial[i]);
		strcat(ti->serial_num, byte);
	}
	if (ti->manufacturer_id == NULL) {
		if (asn1_toki[2].flags & PKCS15_ASN1_PRESENT)
			ti->manufacturer_id = strdup((char *) mnfid);
		else
			ti->manufacturer_id = strdup("(unknown)");
		if (ti->manufacturer_id == NULL)
			return PKCS15_ERR_NO_MEM;
	}
	if (ti->label == NULL) {
		if (asn1_toki[3].flags & PKCS15_ASN1_PRESENT ||
		    asn1_toki[4].flags & PKCS15_ASN1_PRESENT)
			ti->label = strdup((char *) label);
		else
			ti->label = strdup("(unknown)");
		if (ti->label == NULL)
			return PKCS15_ERR_NO_MEM;
	}
	if (asn1_toki[11].flags & PKCS15_ASN1_PRESENT) {
		ti->last_update = strdup((char *)last_update);
		if (ti->last_update == NULL)
			return PKCS15_ERR_NO_MEM;
	}
	if (asn1_toki[12].flags & PKCS15_ASN1_PRESENT) {
		preferred_language[2] = 0;
		ti->prefered_lang = strdup((char *)preferred_language);
		if (ti->prefered_lang == NULL)
			return PKCS15_ERR_NO_MEM;
	}
	return PKCS15_SUCCESS;
}

static int pkcs15_encode_tokeninfo(struct pkcs15_tokeninfo *ti,
				   uint8_t **buf, size_t *buflen)
{
	int r;
	int version = ti->version;
	size_t serial_len, mnfid_len, label_len, flags_len, last_upd_len;
	
	struct pkcs15_asn1_entry asn1_toki[14], asn1_tokeninfo[2];

	pkcs15_copy_asn1_entry(c_asn1_toki, asn1_toki);
	pkcs15_copy_asn1_entry(c_asn1_tokeninfo, asn1_tokeninfo);
	version--;
	pkcs15_format_asn1_entry(asn1_toki + 0, &version, NULL, 1);
	if (ti->serial_num != NULL) {
		uint8_t serial[128];
		serial_len = 0;
		if (strlen(ti->serial_num)/2 > sizeof(serial))
			return PKCS15_ERR_INSUF_BUFFER;
		serial_len = sizeof(serial);
		if (icc_hex_to_bin(ti->serial_num, serial, &serial_len) < 0)
			return PKCS15_ERR_INVALID_ARGS;
		pkcs15_format_asn1_entry(asn1_toki + 1, serial, &serial_len, 1);
	} else
		pkcs15_format_asn1_entry(asn1_toki + 1, NULL, NULL, 0);
	if (ti->manufacturer_id != NULL) {
		mnfid_len = strlen(ti->manufacturer_id);
		pkcs15_format_asn1_entry(asn1_toki + 2, ti->manufacturer_id, &mnfid_len, 1);
	} else
		pkcs15_format_asn1_entry(asn1_toki + 2, NULL, NULL, 0);
	if (ti->label != NULL) {
		label_len = strlen(ti->label);
		pkcs15_format_asn1_entry(asn1_toki + 3, ti->label, &label_len, 1);
	} else
		pkcs15_format_asn1_entry(asn1_toki + 3, NULL, NULL, 0);
	if (ti->flags) {
		flags_len = sizeof(ti->flags);
		pkcs15_format_asn1_entry(asn1_toki + 5, &ti->flags, &flags_len, 1);
	} else
		pkcs15_format_asn1_entry(asn1_toki + 5, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 6, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 7, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 8, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 9, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 10, NULL, NULL, 0);
	if (ti->last_update != NULL) {
		last_upd_len = strlen(ti->last_update);
		pkcs15_format_asn1_entry(asn1_toki + 11, ti->last_update, &last_upd_len, 1);
	} else
		pkcs15_format_asn1_entry(asn1_toki + 11, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 12, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_tokeninfo, asn1_toki, NULL, 1);

	r = pkcs15_asn1_encode(asn1_tokeninfo, buf, buflen);
	if (r) {
		p15_log(P15_LOG_ERR, "sc_asn1_encode() failed");
		return r;
	}
	return 0;
}

static const struct pkcs15_asn1_entry c_asn1_ddo[] = {
	{ "oid",	   PKCS15_ASN1_OBJECT, PKCS15_ASN1_TAG_OBJECT, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "odfPath",	   PKCS15_ASN1_PATH, PKCS15_ASN1_CONS | PKCS15_ASN1_TAG_SEQUENCE, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "tokenInfoPath", PKCS15_ASN1_PATH, PKCS15_ASN1_CONS | PKCS15_ASN1_CTX | 0, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "unusedPath",    PKCS15_ASN1_PATH, PKCS15_ASN1_CONS | PKCS15_ASN1_CTX | 1, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

int pkcs15_parse_ddo(struct p15_card *p15_handle, const uint8_t * buf,
		     size_t buflen)
{
	struct pkcs15_asn1_entry asn1_ddo[5];
	struct icc_path odf_path, ti_path, us_path;
	int r;

	pkcs15_copy_asn1_entry(c_asn1_ddo, asn1_ddo);
	pkcs15_format_asn1_entry(asn1_ddo + 1, &odf_path, NULL, 0);
	pkcs15_format_asn1_entry(asn1_ddo + 2, &ti_path, NULL, 0);
	pkcs15_format_asn1_entry(asn1_ddo + 3, &us_path, NULL, 0);

	r = pkcs15_asn1_decode(asn1_ddo, buf, buflen, NULL, NULL);
	if (r)
		return r;

	if (asn1_ddo[1].flags & PKCS15_ASN1_PRESENT) {
		p15_handle->odf = icc_file_new();
		if (p15_handle->odf == NULL)
			goto mem_err;
		p15_handle->odf->path = odf_path;
	}
	if (asn1_ddo[2].flags & PKCS15_ASN1_PRESENT) {
		p15_handle->tif = icc_file_new();
		if (p15_handle->tif == NULL)
			goto mem_err;
		p15_handle->tif->path = ti_path;
	}
	if (asn1_ddo[3].flags & PKCS15_ASN1_PRESENT) {
		p15_handle->unused = icc_file_new();
		if (p15_handle->unused == NULL)
			goto mem_err;
		p15_handle->unused->path = us_path;
	}
	return 0;

mem_err:
	if (p15_handle->odf != NULL) {
		icc_file_free(p15_handle->odf);
		p15_handle->odf = NULL;
	}
	if (p15_handle->tif != NULL) {
		icc_file_free(p15_handle->tif);
		p15_handle->tif = NULL;
	}
	if (p15_handle->unused != NULL) {
		icc_file_free(p15_handle->unused);
		p15_handle->unused = NULL;
	}
	return PKCS15_ERR_NO_MEM;
}


static const struct pkcs15_asn1_entry c_asn1_odf[] = {
	{ "privateKeys",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 0 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "publicKeys",		 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 1 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "trustedPublicKeys",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 2 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "secretKeys",	 	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 3 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "certificates",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 4 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "trustedCertificates", PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 5 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "usefulCertificates",  PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 6 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "dataObjects",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 7 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "authObjects",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 8 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const unsigned int odf_indexes[] = {
	PKCS15_PRKDF,
	PKCS15_PUKDF,
	PKCS15_PUKDF_TRUSTED,
	PKCS15_SKDF,
	PKCS15_CDF,
	PKCS15_CDF_TRUSTED,
	PKCS15_CDF_USEFUL,
	PKCS15_DODF,
	PKCS15_AODF,
};

const char *p15_df_type2str(int t)
{
	switch (t) {
	case PKCS15_PRKDF: return "PrkDF";
	case PKCS15_PUKDF: return "PukDF";
	case PKCS15_CDF:
	case PKCS15_CDF_TRUSTED:
	case PKCS15_CDF_USEFUL: return "CDF";
	case PKCS15_AODF: return "AODF";
	default:
		return "unknown";
	}
}

int pkcs15_parse_odf(const uint8_t * buf, size_t buflen,
		     struct p15_card *p15_handle)
{
	const uint8_t *p = buf;
	size_t left = buflen;
	int r, i, type;
	struct icc_path path;
	struct pkcs15_asn1_entry asn1_obj_or_path[] = {
		{ "path", PKCS15_ASN1_PATH, PKCS15_ASN1_CONS | PKCS15_ASN1_SEQUENCE, 0, &path, NULL },
		{ NULL, 0, 0, 0, NULL, NULL }
	};
	struct pkcs15_asn1_entry asn1_odf[10];
	
	pkcs15_copy_asn1_entry(c_asn1_odf, asn1_odf);
	for (i = 0; asn1_odf[i].name != NULL; i++)
		pkcs15_format_asn1_entry(asn1_odf + i, asn1_obj_or_path, NULL, 0);
	while (left > 0) {
		r = pkcs15_asn1_decode_choice(asn1_odf, p, left, &p, &left);
		if (r == PKCS15_ERR_ASN1_END_OF_CONTENTS)
			break;
		if (r < 0)
			return r;
		type = r;
		r = icc_make_absolute_path(&p15_handle->app_root->path, &path);
		if (r < 0)
			return r;
		r = pkcs15_add_df(p15_handle, odf_indexes[type], &path, NULL);
		if (r)
			return r;
	}
	return 0;
}

int pkcs15_encode_odf(struct p15_card *p15card,
		      uint8_t **buf, size_t *buflen)
{
	struct icc_path path;
	struct pkcs15_asn1_entry asn1_obj_or_path[] = {
		{ "path", PKCS15_ASN1_PATH, PKCS15_ASN1_CONS | PKCS15_ASN1_SEQUENCE, 0, &path, NULL },
		{ NULL, 0, 0, 0, NULL, NULL }
	};
	struct pkcs15_asn1_entry *asn1_paths = NULL;
	struct pkcs15_asn1_entry *asn1_odf = NULL;
	int df_count = 0, r, c = 0;
	const int nr_indexes = sizeof(odf_indexes)/sizeof(odf_indexes[0]);
	struct pkcs15_df *df;
	
	for_each_df(df, p15card) {
		df_count++;
	}

	if (df_count == 0) {
		p15_log(P15_LOG_ERR, "No DF's found.\n");
		return PKCS15_ERR_ASN1_OBJ_NOT_FOUND;
	}
	asn1_odf = (struct pkcs15_asn1_entry *) malloc(sizeof(struct pkcs15_asn1_entry) * (df_count + 1));
	if (asn1_odf == NULL) {
		r = PKCS15_ERR_NO_MEM;
		goto err;
	}
	asn1_paths = (struct pkcs15_asn1_entry *) malloc(sizeof(struct pkcs15_asn1_entry) * (df_count * 2));
	if (asn1_paths == NULL) {
		r = PKCS15_ERR_NO_MEM;
		goto err;
	}
	for_each_df(df, p15card) {
		int j, type = -1;

		for (j = 0; j < nr_indexes; j++)
			if (odf_indexes[j] == df->type) {
				type = j;
				break;
			}
		if (type == -1) {
			p15_log(P15_LOG_ERR, "Unsupported DF type");
			continue;
		}
		asn1_odf[c] = c_asn1_odf[type];
		pkcs15_format_asn1_entry(asn1_odf + c, asn1_paths + 2*c, NULL, 1);
		pkcs15_copy_asn1_entry(asn1_obj_or_path, asn1_paths + 2*c);
		pkcs15_format_asn1_entry(asn1_paths + 2*c, &df->path, NULL, 1);
		c++;
	}
	asn1_odf[c].name = NULL;
	r = pkcs15_asn1_encode(asn1_odf, buf, buflen);
err:
	if (asn1_paths != NULL)
		free(asn1_paths);
	if (asn1_odf != NULL)
		free(asn1_odf);
	return r;
}

/* get first un enumed df */
static struct pkcs15_df *p15_unenumed_df(struct p15_card *card, uint16_t mask)
{	
	struct pkcs15_df *df;

	for_each_df(df, card) {
		if (!(mask & (1 << df->type)))
			continue;
		if (df->enumerated)
			continue;
		return df;
	}
	return NULL;
}

/* all dfs have benn enumed */
static int __p15_dfs_enumed(struct p15_card *p15card, uint16_t mask)
{
	return p15_unenumed_df(p15card, mask) ? 0 : 1;
}

typedef struct _p15_sear_t {
	uint16_t class_mask;
	uint16_t df_mask;
	uint16_t type;
	p15_obj_cb obj_cb;
	void *objcb_arg;
	struct pkcs15_object **ret;
	size_t ret_size;

	struct p15_card *card;
	p15_user_cb cb;
	void *cbarg;
} p15_sear_t;

static int __p15_find_obj(struct p15_card *p15card, uint16_t cls_mask,
			   uint16_t type, p15_obj_cb obj_cb, void *objcb_arg,
			   struct pkcs15_object **ret, size_t ret_size)
{
	struct pkcs15_object *obj;
	int match_count = 0;

	/* And now loop over all objects */
	for_each_obj(obj, p15card) {
		/* Check object type */
		if (!(cls_mask & PKCS15_TYPE_TO_CLASS(obj->type)))
			continue;
		if (type != 0
		 && obj->type != type
		 && (obj->type & PKCS15_TYPE_CLASS_MASK) != type)
			continue;

		/* Potential candidate, apply search function */
		if (obj_cb != NULL && obj_cb(obj, objcb_arg) <= 0)
			continue;
		/* Okay, we have a match. */
		match_count++;
		if (ret_size <= 0)
			continue;
		ret[match_count-1] = obj;
		if (ret_size <= (size_t)match_count)
			break;
	}
	return match_count;
}

static void __p15_sear_cb(void *d, int ret)
{
	p15_sear_t *sear = (p15_sear_t *)d;
	int match_count = -1;

	if (ret < 0)
		goto out;

	/* Make sure all the DFs we want to search have been
	 * enumerated. */
	if (!__p15_dfs_enumed(sear->card, sear->df_mask)) {
		struct pkcs15_df *df = p15_unenumed_df(sear->card, sear->df_mask);

		BUG_ON(!df);
		/* Enumerate the DF's, so p15card->obj_list is
		 * populated. */
		if (0 != pkcs15_parse_df(sear->card, df, __p15_sear_cb, sear)) {
			p15_log(P15_LOG_ERR, "DF parsing failed");
			goto out;
		}
		return;
	}
	match_count = __p15_find_obj(sear->card, sear->class_mask, sear->type, sear->obj_cb, sear->objcb_arg,
				     sear->ret, sear->ret_size);
out:
	if (sear->cb)
		sear->cb(sear->cbarg, match_count);
	free(sear);
	return;
}

static int __p15_search_objects(struct p15_card *p15card,
				uint16_t class_mask, uint16_t type,
				p15_obj_cb obj_cb, void *objcb_arg,
				struct pkcs15_object **ret, size_t ret_size,
				p15_user_cb cb, void *cbarg)
{
	uint16_t df_mask = 0;
	p15_sear_t *sear;

	if (type)
		class_mask |= PKCS15_TYPE_TO_CLASS(type);

	/* Make sure the class mask we have makes sense */
	if (class_mask == 0
	 || (class_mask & ~(PKCS15_SEARCH_CLASS_PRKEY |
			    PKCS15_SEARCH_CLASS_PUBKEY |
			    PKCS15_SEARCH_CLASS_CERT |
			    PKCS15_SEARCH_CLASS_DATA |
			    PKCS15_SEARCH_CLASS_AUTH))) {
		return PKCS15_ERR_INVALID_ARGS;
	}

	if (class_mask & PKCS15_SEARCH_CLASS_PRKEY)
		df_mask |= (1 << PKCS15_PRKDF);
	if (class_mask & PKCS15_SEARCH_CLASS_PUBKEY)
		df_mask |= (1 << PKCS15_PUKDF)
			 | (1 << PKCS15_PUKDF_TRUSTED);
	if (class_mask & PKCS15_SEARCH_CLASS_CERT)
		df_mask |= (1 << PKCS15_CDF)
			 | (1 << PKCS15_CDF_TRUSTED)
			 | (1 << PKCS15_CDF_USEFUL);
	if (class_mask & PKCS15_SEARCH_CLASS_DATA)
		df_mask |= (1 << PKCS15_DODF);
	if (class_mask & PKCS15_SEARCH_CLASS_AUTH)
		df_mask |= (1 << PKCS15_AODF);

	sear = malloc(sizeof (p15_sear_t));
	if (!sear)
		return -1;
	memset(sear, 0, sizeof (p15_sear_t));

	sear->class_mask = class_mask;
	sear->df_mask = df_mask;
	sear->obj_cb = obj_cb;
	sear->objcb_arg = objcb_arg;
	sear->ret = ret;
	sear->ret_size = ret_size;
	sear->type = type;
	sear->card = p15card;

	__p15_sear_cb(sear, 0);

	return 0;
}


int pkcs15_get_objects(struct p15_card *p15card, uint16_t type,
		       struct pkcs15_object **ret, size_t ret_size,
		       p15_user_cb ucb, void *cbarg)
{
	return pkcs15_get_objects_cond(p15card, type, NULL, NULL, ret, ret_size,
				       ucb, cbarg);
}

static int compare_obj_id(struct pkcs15_object *obj, 
			  const struct pkcs15_id *id)
{
	void *data = obj->data;
	
	switch (obj->type) {
	case PKCS15_TYPE_CERT_X509:
		return pkcs15_compare_id(&((struct pkcs15_cert_info *) data)->id, id);
	case PKCS15_TYPE_PRKEY_RSA:
	case PKCS15_TYPE_PRKEY_DSA:
		return pkcs15_compare_id(&((struct pkcs15_prkey_info *) data)->id, id);
	case PKCS15_TYPE_PUBKEY_RSA:
	case PKCS15_TYPE_PUBKEY_DSA:
		return pkcs15_compare_id(&((struct pkcs15_pubkey_info *) data)->id, id);
	case PKCS15_TYPE_AUTH_PIN:
		return pkcs15_compare_id(&((struct pkcs15_pin_info *) data)->auth_id, id);
	case PKCS15_TYPE_DATA_OBJECT:
		return pkcs15_compare_id(&((struct pkcs15_data_info *) data)->id, id);
	}
	return 0;
}

static int obj_app_oid(struct pkcs15_object *obj, 
		       const struct icc_object_id *app_oid)
{
	if (obj->type & PKCS15_TYPE_DATA_OBJECT)
		return icc_compare_oid(&((struct pkcs15_data_info *) obj->data)->app_oid, app_oid);
	return 0;
}

static int compare_obj_usage(struct pkcs15_object *obj, 
			     unsigned int mask, unsigned int value)
{
	void		*data = obj->data;
	unsigned int	usage;

	switch (obj->type) {
	case PKCS15_TYPE_PRKEY_RSA:
	case PKCS15_TYPE_PRKEY_DSA:
		usage = ((struct pkcs15_prkey_info *) data)->usage;
		break;
	case PKCS15_TYPE_PUBKEY_RSA:
	case PKCS15_TYPE_PUBKEY_DSA:
		usage = ((struct pkcs15_pubkey_info *) data)->usage;
		break;
	default:
		return 0;
	}
	return (usage & mask & value) != 0;
}

static int compare_obj_flags(struct pkcs15_object *obj,
			     unsigned int mask, unsigned int value)
{
	void		*data = obj->data;
	unsigned int	flags;

	switch (obj->type) {
	case PKCS15_TYPE_AUTH_PIN:
		flags = ((struct pkcs15_pin_info *) data)->flags;
		break;
	default:
		return 0;
	}
	return !((flags ^ value) & mask);
}

static int compare_obj_reference(struct pkcs15_object *obj, int value)
{
	void		*data = obj->data;
	int		reference;

	switch (obj->type) {
	case PKCS15_TYPE_AUTH_PIN:
		reference = ((struct pkcs15_pin_info *) data)->ref;
		break;
	case PKCS15_TYPE_PRKEY_RSA:
	case PKCS15_TYPE_PRKEY_DSA:
		reference = ((struct pkcs15_prkey_info *) data)->key_ref;
		break;
	default:
		return 0;
	}
	return reference == value;
}

static int compare_obj_path(struct pkcs15_object *obj, 
			    const struct icc_path *path)
{
	void *data = obj->data;
	
	switch (obj->type) {
	case PKCS15_TYPE_CERT_X509:
		return icc_compare_path(&((struct pkcs15_cert_info *) data)->path, path);
	case PKCS15_TYPE_PRKEY_RSA:
	case PKCS15_TYPE_PRKEY_DSA:
		return icc_compare_path(&((struct pkcs15_prkey_info *) data)->path, path);
	case PKCS15_TYPE_PUBKEY_RSA:
	case PKCS15_TYPE_PUBKEY_DSA:
		return icc_compare_path(&((struct pkcs15_pubkey_info *) data)->path, path);
	case PKCS15_TYPE_AUTH_PIN:
		return icc_compare_path(&((struct pkcs15_pin_info *) data)->path, path);
	case PKCS15_TYPE_DATA_OBJECT:
		return icc_compare_path(&((struct pkcs15_data_info *) data)->path, path);
	}
	return 0;
}

static int compare_obj_key(struct pkcs15_object *obj, void *arg)
{
	struct pkcs15_search_key *sk = (struct pkcs15_search_key *) arg;

	if (sk->id && !compare_obj_id(obj, sk->id))
		return 0;
	if (sk->app_oid && !obj_app_oid(obj, sk->app_oid))
		return 0;
	if (sk->usage_mask && !compare_obj_usage(obj, sk->usage_mask, sk->usage_value))
		return 0;
	if (sk->flags_mask && !compare_obj_flags(obj, sk->flags_mask, sk->flags_value))
		return 0;
	if (sk->match_reference && !compare_obj_reference(obj, sk->reference))
		return 0;
	if (sk->path && !compare_obj_path(obj, sk->path))
		return 0;
	return 1;
}


static void __find_common_cb(void *d, int ret)
{
	p15_cb_t *cb_t = (p15_cb_t *)d;
	if (ret > 0)
		cb_t->ret = 0;
	else
		cb_t->ret = PKCS15_ERR_ASN1_OBJ_NOT_FOUND;
	__clean_cb_t(cb_t);
}

static int find_by_key(struct p15_card *p15card,
		       uint16_t type, struct pkcs15_search_key *sk,
		       struct pkcs15_object **out,
		       p15_user_cb ucb, void *cbarg)
{
	return pkcs15_get_objects_cond(p15card, type, 
				       compare_obj_key, sk, out, 1,
				       ucb, cbarg);
}

int pkcs15_search_objects(struct p15_card *p15card, struct pkcs15_search_key *sk,
			  struct pkcs15_object **ret, size_t ret_size,
			  p15_user_cb cb, void *cbarg)
{
	return __p15_search_objects(p15card, sk->class_mask, sk->type,
				     compare_obj_key, (void *)sk, ret, ret_size,
				     cb, cbarg);
}

static int pkcs15_get_objects_cond(struct p15_card *p15card, uint16_t type,
				   p15_obj_cb ocb, void *ocb_arg,
				   struct pkcs15_object **ret, size_t ret_size,
				   p15_user_cb ucb, void *ucbarg)
{

	return __p15_search_objects(p15card, 0, type,
				    ocb, ocb_arg, ret, ret_size,
				    ucb, ucbarg);
}

int pkcs15_find_object_by_id(struct p15_card *p15card,
			     uint16_t type, const struct pkcs15_id *id,
			     struct pkcs15_object **out,
			     p15_user_cb ucb, void *cbarg)
{
	struct pkcs15_search_key *sk;
	int	r;
	p15_cb_t *cb_t = NULL;

	sk = __new_search_key();
	if (!sk)
		goto err;
	sk->id = id;

	cb_t = __make_cb_t(ucb, cbarg);
	if (!cb_t)
		goto err;

	cb_t->free_data = sk;

	r = __p15_search_objects(p15card, 0, type, compare_obj_key, (void *)sk,	out, 1,
				 __find_common_cb, cb_t);
	if (r < 0)
		goto err;
	return 0;
err:
	if (sk) free(sk);
	if (cb_t) __clean_cb_t_no_cb(cb_t);
	return -1;
}


int pkcs15_find_cert_by_id(struct p15_card *p15card,
			   const struct pkcs15_id *id,struct pkcs15_object **out,
			   p15_user_cb cb, void *arg)
{
	return pkcs15_find_object_by_id(p15card, PKCS15_TYPE_CERT, id, out, cb, arg);
}

int pkcs15_find_prkey_by_id(struct p15_card *p15card,
			    const struct pkcs15_id *id, struct pkcs15_object **out,
			    p15_user_cb cb, void *arg)
{
	return pkcs15_find_object_by_id(p15card, PKCS15_TYPE_PRKEY, id, out, cb, arg);
}

int pkcs15_find_pubkey_by_id(struct p15_card *p15card,
				const struct pkcs15_id *id, struct pkcs15_object **out,
				p15_user_cb cb, void *arg)
{
	return pkcs15_find_object_by_id(p15card, PKCS15_TYPE_PUBKEY, id, out, cb, arg);
}

int pkcs15_find_pin_by_auth_id(struct p15_card *p15card,
				  const struct pkcs15_id *id, struct pkcs15_object **out,
				  p15_user_cb cb, void *arg)
{
	return pkcs15_find_object_by_id(p15card, PKCS15_TYPE_AUTH_PIN, id, out, cb, arg);
}


int pkcs15_find_pin_by_reference(struct p15_card *p15card,
				 const struct icc_path *path, int reference,
				 struct pkcs15_object **out,
				 p15_user_cb cb, void *arg)
{
	struct pkcs15_search_key *sk;
	p15_cb_t *cb_t = NULL;

	sk = __new_search_key();
	if (!sk)
		goto err;

	sk->match_reference = 1;
	sk->reference = reference;
	sk->path = path;

	cb_t = __make_cb_t(cb, arg);
	if (!cb_t)
		goto err;

	cb_t->free_data = sk;

	if (0 != find_by_key(p15card, PKCS15_TYPE_AUTH_PIN, sk, out, __find_common_cb, cb_t))
		goto err;
	return 0;
err:
	if (sk) free(sk);
	if (cb_t) __clean_cb_t_no_cb(cb_t);
	return -1;

}

int pkcs15_find_data_object_by_id(struct p15_card *p15card,
				  const struct pkcs15_id *id, struct pkcs15_object **out,
				  p15_user_cb ucb, void *cbarg)
{
	return pkcs15_find_object_by_id(p15card, PKCS15_TYPE_DATA_OBJECT, id, out,
					ucb, cbarg);
}

int pkcs15_find_data_object_by_app_oid(struct p15_card *p15card,
				       const struct icc_object_id *app_oid,
				       struct pkcs15_object **out,
				       p15_user_cb ucb, void *cbarg)
{
	struct pkcs15_search_key *sk;
	p15_cb_t *cb_t = NULL;

	sk = __new_search_key();
	if (!sk)
		goto err;
	sk->app_oid = app_oid;

	cb_t = __make_cb_t(ucb, cbarg);
	if (!cb_t)
		goto err;

	cb_t->free_data = sk;

	if (0 != __p15_search_objects(p15card, 0, PKCS15_TYPE_DATA_OBJECT, compare_obj_key, (void *)sk, out, 1,
				      __find_common_cb, cb_t))
		goto err;
	return 0;
err:
	if (sk) free(sk);
	if (cb_t) __clean_cb_t_no_cb(cb_t);
	return -1;

}

int pkcs15_find_prkey_by_id_usage(struct p15_card *p15card,
				  const struct pkcs15_id *id,
				  unsigned int usage,
				  struct pkcs15_object **out,
				  p15_user_cb cb, void *arg)
{
	struct pkcs15_search_key *sk;
	p15_cb_t *cb_t = NULL;

	sk = __new_search_key();
	if (!sk)
		goto err;
	sk->id = id;
	sk->usage_mask = sk->usage_value = usage;

	cb_t = __make_cb_t(cb, arg);
	if (!cb_t)
		goto err;

	cb_t->free_data = sk;

	if (0 != find_by_key(p15card, PKCS15_TYPE_PRKEY, sk, out, __find_common_cb, cb_t))
		goto err;
	return 0;
err:
	if (sk) free(sk);
	if (cb_t) __clean_cb_t_no_cb(cb_t);
	return -1;
}

int pkcs15_find_prkey_by_reference(struct p15_card *p15card,
				   const struct icc_path *path,
				   int reference, struct pkcs15_object **out,
				   p15_user_cb cb, void *arg)
{
	struct pkcs15_search_key *sk;
	p15_cb_t *cb_t = NULL;

	sk = __new_search_key();
	if (!sk)
		goto err;
	sk->match_reference = 1;
	sk->reference = reference;
	sk->path = path;

	cb_t = __make_cb_t(cb, arg);
	if (!cb_t)
		goto err;

	cb_t->free_data = sk;

	if (0 != find_by_key(p15card, PKCS15_TYPE_PRKEY, sk, out, __find_common_cb, cb_t))
		goto err;
	return 0;
err:
	if (sk) free(sk);
	if (cb_t) __clean_cb_t_no_cb(cb_t);
	return -1;

}

int pkcs15_find_so_pin(struct p15_card *p15card,
			struct pkcs15_object **out, p15_user_cb cb, void *arg)
{

	struct pkcs15_search_key *sk;
	p15_cb_t *cb_t = NULL;
	
	sk = __new_search_key();
	if (!sk)
		goto err;
#if 0
	sk->flags_mask = sk->flags_value = PKCS15_PIN_FLAG_SO_PIN;
#endif
	cb_t = __make_cb_t(cb, arg);
	if (!cb_t)
		goto err;

	cb_t->free_data = sk;

	if (0 != find_by_key(p15card, PKCS15_TYPE_AUTH_PIN, sk, out,
			     __find_common_cb, cb_t))
		goto err;
	return 0;
err:
	if (sk) free(sk);
	if (cb_t) __clean_cb_t_no_cb(cb_t);
	return -1;
}

static int pkcs15_add_object(struct p15_card *p15card, struct pkcs15_object *obj)
{
	list_insert_before(&obj->link, &p15card->obj_list);

	return 0;
}

void pkcs15_remove_object(struct p15_card *p15card,
			  struct pkcs15_object *obj);
void pkcs15_remove_object(struct p15_card *p15card,
			  struct pkcs15_object *obj)
{
	struct pkcs15_object *to, *n;

	for_each_obj_safe(to, n, p15card) {
		if (to == obj) {
			list_delete(&to->link);
			pkcs15_free_object(obj);
			break;
		}

	}
}

static void pkcs15_free_object(struct pkcs15_object *obj)
{
	switch (obj->type & PKCS15_TYPE_CLASS_MASK) {
	case PKCS15_TYPE_PRKEY:
		pkcs15_free_prkey_info((struct pkcs15_prkey_info *)obj->data);
		break;
	case PKCS15_TYPE_PUBKEY:
		pkcs15_free_pubkey_info((struct pkcs15_pubkey_info *)obj->data);
		break;
	case PKCS15_TYPE_CERT:
		pkcs15_free_cert_info((struct pkcs15_cert_info *)obj->data);
		break;
	case PKCS15_TYPE_DATA_OBJECT:
		pkcs15_free_data_info((struct pkcs15_data_info *)obj->data);
		break;
#if 0	/* TODO */
	case PKCS15_TYPE_AUTH:
		pkcs15_free_pin_info((struct pkcs15_pin_info *)obj->data);
		break;
#endif
	default:
		free(obj->data);
	}

	if (obj->der.value)
		free(obj->der.value);
	free(obj);
}

int pkcs15_add_df(struct p15_card *p15card,
		  unsigned int type, const struct icc_path *path,
		  const struct icc_file *file)
{
	struct pkcs15_df *newdf;

	newdf = (struct pkcs15_df *) calloc(1, sizeof(struct pkcs15_df));
	if (newdf == NULL)
		return PKCS15_ERR_NO_MEM;

	newdf->path = *path;
	newdf->type = type;
	if (file != NULL) {
		icc_file_dup(&newdf->filp, file);
		if (newdf->filp == NULL) {
			free(newdf);
			return PKCS15_ERR_NO_MEM;
		}
			
	}
	list_init(&newdf->link);
	list_insert_before(&newdf->link, &p15card->df_list);

	return 0;
}

void pkcs15_remove_df(struct p15_card *p15card,
		      struct pkcs15_df *obj)
{
	struct pkcs15_df *to, *n;

	for_each_df_safe(to, n, p15card) {
		if (to == obj) {
			list_delete(&obj->link);
			if (obj->filp)
				icc_file_free(obj->filp);
			free(obj);
			break;
		}

	}
}

int pkcs15_encode_df(struct p15_card *p15card,
		     struct pkcs15_df *df,
		     uint8_t **buf_out, size_t *bufsize_out)
{
	uint8_t *buf = NULL, *tmp = NULL;
	size_t bufsize = 0, tmpsize;
	const struct pkcs15_object *obj;
	int r;
	p15_encode_func func = NULL;


	if (p15_df_type_unknown(df->type)) {
		p15_log(P15_LOG_ERR, "unknown DF type: %d", df->type);
		return PKCS15_ERR_INVALID_ARGS;
	}

	p15_set_encode_func(func, df->type);
	if (!func) {
		p15_log(P15_LOG_ERR, "unknown DF type: %d", df->type);
		*buf_out = NULL;
		*bufsize_out = 0;
		return 0;
	}
	for_each_obj(obj, p15card) {
		if (obj->df != df)
			continue;
		r = func(obj, &tmp, &tmpsize);
		if (r) {
			free(tmp);
			free(buf);
			return r;
		}
		buf = (uint8_t *) realloc(buf, bufsize + tmpsize);
		memcpy(buf + bufsize, tmp, tmpsize);
		free(tmp);
		bufsize += tmpsize;
	}
	*buf_out = buf;
	*bufsize_out = bufsize;
	
	return 0;	
}

static void __parse_df_cb(p15_trans_t *trans)
{
	struct p15_card *p15card = NULL;
	const uint8_t *p;
	size_t bufsize;
	int ret = trans->ret, r = -1;
	p15_decode_func func = NULL;
	struct pkcs15_df *df;

	if (ret < 0)
		goto out;

	p = trans->buf;
	bufsize = trans->actual;
	df = (struct pkcs15_df *)trans->u.priv_v;

	p15_set_decode_func(func, df->type);

	if (!func)
		goto out;

	/* FIXME: if error need rollback? */
	while (bufsize && *p != 0x00) {
		const uint8_t *oldp;
		size_t obj_len;
		struct pkcs15_object *obj = NULL;

		obj = (struct pkcs15_object *) calloc(1, sizeof(struct pkcs15_object));
		if (!obj) {
			r = PKCS15_ERR_NO_MEM;
			goto out;
		}
		oldp = p;
		r = func(p15card, obj, &p, &bufsize);
		if (r) {
			free(obj);
			if (r == PKCS15_ERR_ASN1_END_OF_CONTENTS) {
				r = 0;
				break;
			}
			p15_log(P15_LOG_ERR, "Error decoding DF entry");
			goto out;
		}
		obj_len = p - oldp;
		
		obj->der.value = (uint8_t *) malloc(obj_len);
		if (obj->der.value == NULL) {
			r = PKCS15_ERR_NO_MEM;
			goto out;
		}
		memcpy(obj->der.value, oldp, obj_len);
		obj->der.len = obj_len;

		obj->df = df;
		r = pkcs15_add_object(p15card, obj);
		if (r) {
			if (obj->data)
				free(obj->data);
			free(obj);
			p15_log(P15_LOG_ERR, "Error adding object");
			goto out;
		}
	}
	/* success */
	df->enumerated = 1;
out:
	if (trans->cb) trans->cb(trans->cb_arg, r);
	p15_destroy_trans(trans);
	return;
}

int pkcs15_parse_df(struct p15_card *p15card,
		    struct pkcs15_df *df, p15_user_cb cb, void *cbarg)
{
	int r;
	p15_trans_t *trans;

	if (p15_df_type_unknown(df->type)) {
		p15_log(P15_LOG_ERR, "unknown DF type: %d", df->type);
		return PKCS15_ERR_INVALID_ARGS;
	}

	trans = p15_build_trans(cb, cbarg, NULL, NULL);
	if (!trans)
		return -1;
	/* this is exist df, we can use it safety */
	trans->u.priv_v = df;

	r = pkcs15_read_file(p15card, &df->path,
			     &trans->buf, &trans->actual,
			     df->filp ? &df->filp : NULL,
			     __parse_df_cb, trans);
	if (r < 0) {
		p15_log(P15_LOG_ERR, "Failed to parse df.");
		cb(trans->cb_arg, -1);
		p15_destroy_trans(trans);
	}
	return r;
}

int pkcs15_add_unusedspace(struct p15_card *p15card,
			   const struct icc_path *path, const struct pkcs15_id *auth_id)
{
	struct p15_unusedspace *new_unusedspace;

	if (path->count == -1) {
		char pbuf[ICC_PATH_STRING_MAX];

		p15_log(P15_LOG_ERR, 
			"No offset and length present in path %s", pbuf);
		return PKCS15_ERR_INVALID_ARGS;
	}

	new_unusedspace = (struct p15_unusedspace *) calloc(1, sizeof(struct p15_unusedspace));
	if (new_unusedspace == NULL)
		return PKCS15_ERR_NO_MEM;
	new_unusedspace->path = *path;
	if (auth_id != NULL)
		new_unusedspace->auth_id = *auth_id;

	list_init(&new_unusedspace->link);
	list_insert_before(&new_unusedspace->link, &p15card->unused_list);

	return 0;
}

static void pkcs15_delete_all_unused(struct p15_card *p15card)
{
	struct p15_unusedspace *to, *n;

	for_each_unu_safe(to, n, p15card) {
		list_delete(&to->link);
		free(to);
	}
}

void pkcs15_remove_unusedspace(struct p15_card *p15card,
			       struct p15_unusedspace *obj)
{
	struct p15_unusedspace *to, *n;

	for_each_unu_safe(to, n, p15card) {
		if (to == obj) {
			list_delete(&obj->link);
			free(obj);
			break;
		}
	}
}

int pkcs15_encode_unusedspace(struct p15_card *p15card,
			      uint8_t **buf, size_t *buflen)
{
	struct icc_path dummy_path;

	static const struct pkcs15_asn1_entry c_asn1_unusedspace[] = {
		{ "UnusedSpace", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
		{ NULL, 0, 0, 0, NULL, NULL }
	};
	static const struct pkcs15_asn1_entry c_asn1_unusedspace_values[] = {
		{ "path", PKCS15_ASN1_PATH,	PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
		{ "authId", PKCS15_ASN1_PKCS15_ID, PKCS15_ASN1_TAG_OCTET_STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
		{ NULL, 0, 0, 0, NULL, NULL }
	};

	struct pkcs15_asn1_entry *asn1_unusedspace = NULL;
	struct pkcs15_asn1_entry *asn1_values = NULL;
	int unusedspace_count = 0, r, c = 0;

	struct p15_unusedspace *unusedspace;

	icc_format_path("3F00", &dummy_path);
	dummy_path.idx = dummy_path.count = 0;

	for_each_unu(unusedspace, p15card)
		unusedspace_count++;
	
	if (unusedspace_count == 0) {
		/* The standard says there has to be at least 1 entry,
		 * so we use a path with a length of 0 bytes */
		r = pkcs15_add_unusedspace(p15card, &dummy_path, NULL);
		if (r)
			return r;
		unusedspace_count = 1;
	}

	asn1_unusedspace = (struct pkcs15_asn1_entry *)
		malloc(sizeof(struct pkcs15_asn1_entry) * (unusedspace_count + 1));
	if (asn1_unusedspace == NULL) {
		r = PKCS15_ERR_NO_MEM;
		goto err;
	}
	asn1_values = (struct pkcs15_asn1_entry *)
		malloc(sizeof(struct pkcs15_asn1_entry) * (unusedspace_count * 3));
	if (asn1_values == NULL) {
		r = PKCS15_ERR_NO_MEM;
		goto err;
	}

	for_each_unu(unusedspace, p15card) {
		pkcs15_copy_asn1_entry(c_asn1_unusedspace, asn1_unusedspace + c);
		pkcs15_format_asn1_entry(asn1_unusedspace + c, asn1_values + 3*c, NULL, 1);
		pkcs15_copy_asn1_entry(c_asn1_unusedspace_values, asn1_values + 3*c);
		pkcs15_format_asn1_entry(asn1_values + 3*c, &unusedspace->path, NULL, 1);
		pkcs15_format_asn1_entry(asn1_values + 3*c+1, &unusedspace->auth_id, NULL, unusedspace->auth_id.len);
		c++;
	}
	asn1_unusedspace[c].name = NULL;

	r = pkcs15_asn1_encode(asn1_unusedspace, buf, buflen);

err:
	if (asn1_values != NULL)
		free(asn1_values);
	if (asn1_unusedspace != NULL)
		free(asn1_unusedspace);
#ifdef TODO
	/* If we added the dummy entry, remove it now */
	if (unusedspace_count == 1 && icc_compare_path(&p15card->unusedspace_list->path, &dummy_path))
		pkcs15_remove_unusedspace(p15card, p15card->unusedspace_list);
#endif
	return r;
}

int pkcs15_parse_unusedspace(const uint8_t * buf, size_t buflen, struct p15_card *card)
{
	const uint8_t *p = buf;
	size_t left = buflen;
	int r;
	struct icc_path path, dummy_path;
	struct pkcs15_id auth_id;
	struct pkcs15_asn1_entry asn1_unusedspace[] = {
		{ "UnusedSpace", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
		{ NULL, 0, 0, 0, NULL, NULL }
	};
	struct pkcs15_asn1_entry asn1_unusedspace_values[] = {
		{ "path", PKCS15_ASN1_PATH,	PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
		{ "authId", PKCS15_ASN1_PKCS15_ID, PKCS15_ASN1_TAG_OCTET_STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
		{ NULL, 0, 0, 0, NULL, NULL }
	};

	/* Clean the list if already present */
	pkcs15_delete_all_unused(card);

	icc_format_path("3F00", &dummy_path);
	dummy_path.idx = dummy_path.count = 0;

	pkcs15_format_asn1_entry(asn1_unusedspace, asn1_unusedspace_values, NULL, 1);
	pkcs15_format_asn1_entry(asn1_unusedspace_values, &path, NULL, 1);
	pkcs15_format_asn1_entry(asn1_unusedspace_values+1, &auth_id, NULL, 0);

	while (left > 0) {
		memset(&auth_id, 0, sizeof(auth_id));
		r = pkcs15_asn1_decode(asn1_unusedspace, p, left, &p, &left);
		if (r == PKCS15_ERR_ASN1_END_OF_CONTENTS)
			break;
		if (r < 0)
			return r;
		/* If the path length is 0, it's a dummy path then don't add it.
		 * If the path length isn't included (-1) then it's against the standard
		 *   but we'll just ignore it instead of returning an error. */
		if (path.count > 0) {
			r = icc_make_absolute_path(&card->app_root->path, &path);
			if (r < 0)
				return r;
			r = pkcs15_add_unusedspace(card, &path, &auth_id);
			if (r)
				return r;
		}
	}
	card->unusedspace_read = 1;

	return 0;
}

static int pkcs15_compare_id(const struct pkcs15_id *id1,
			     const struct pkcs15_id *id2)
{
	BUG_ON(!id1 || !id2);
	if (id1->len != id2->len)
		return 0;
	return memcmp(id1->value, id2->value, id1->len) == 0;
}

void pkcs15_format_id(const char *str, struct pkcs15_id *id);

void pkcs15_format_id(const char *str, struct pkcs15_id *id)
{
	size_t len = sizeof(id->value);

	if (icc_hex_to_bin(str, id->value, &len) >= 0)
		id->len = len;
}
const char *pkcs15_print_id(const struct pkcs15_id *id);
const char *pkcs15_print_id(const struct pkcs15_id *id)
{
	static char buffer[256];

	icc_bin_to_hex(id->value, id->len, buffer, sizeof(buffer), '\0');
	return buffer;
}
int pkcs15_hex_string_to_id(const char *in, struct pkcs15_id *out);
int pkcs15_hex_string_to_id(const char *in, struct pkcs15_id *out)
{
	out->len = sizeof(out->value);
	return icc_hex_to_bin(in, out->value, &out->len);
}

int pkcs15_make_absolute_path(const struct icc_path *parent, struct icc_path *child);
int pkcs15_make_absolute_path(const struct icc_path *parent, struct icc_path *child)
{
	/* a 0 length path stays a 0 length path */
	if (child->len == 0)
		return PKCS15_SUCCESS;

	if (icc_compare_path_prefix(icc_get_mf_path(), child))
		return PKCS15_SUCCESS;
	return icc_cat_path(child, parent, child);
}

uint8_t *gbuf;
size_t gbuflen;
p15_trans_t gt;

static void __test_read_cb(p15_trans_t *trans)
{
	int ret = trans->ret;
	if (ret >= 0) {
		p15_log(P15_LOG_INFO, "test_read success, len=%d", gbuflen);
	} else
		p15_log(P15_LOG_INFO, "test_read failure, len=%d", gbuflen);
}

void read_file_test(struct p15_card *p15card)
{
	struct icc_path path;

	icc_format_path("3f003f010008", &path);

	pkcs15_read_file(p15card, &path, &gbuf, &gbuflen, NULL, __test_read_cb, &gt);	

}

p15_trans_t *p15_build_trans(p15_user_cb cb, void *cbarg, 
			     void *outp, void **outpp)
{
	p15_trans_t *trans = malloc(sizeof (p15_trans_t));
	if (!trans)
		return NULL;
	memset(trans, 0, sizeof (p15_trans_t));

	trans->cb = cb;
	trans->cb_arg = cbarg;

	trans->out_p  = outp;
	trans->out_pp = outpp;

	/* when we pass data to user, should clear this */
	trans->self_free = 1;

	return trans;
}

void p15_destroy_trans(p15_trans_t *trans)
{
	if (trans->self_free) {
		if (trans->buf)
			free(trans->buf);
	}
	if (trans)
		free(trans);
}

static int p15card_dump(ui_session_t *sess, ui_entry_t *inst,
			     void *ctx, int argc, char **argv)
{
	ui_table_t *table = ui_table_by_name(sess, "p15card_list");
	int i = 0;
	char buf[3 * ICC_PATH_MAX];
	struct p15_card *card;

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "p15card_list");
	if (!table)
		return -1;

	ui_add_title(table, 0, "index");
	ui_add_title(table, 1, "EF(DIR)");
	ui_add_title(table, 2, "app_root");
	ui_add_title(table, 3, "ODF");
	ui_add_title(table, 4, "TIF");
	ui_add_title(table, 5, "Unused");

#define _TMP_BUILD_BUF(file)						\
		r = icc_fetch_file_path(file, buf, sizeof (buf));	\
		if (r)	snprintf(buf, sizeof(buf), "not found");	\

	i = 0;
	for_each_card(card) {
		int r;
		if (card->binded == 0)
			continue;
		//read_file_test(card);

		snprintf(buf, sizeof(buf), "%04x", card->idx);
		ui_add_value(table, "index", i, buf);

		_TMP_BUILD_BUF(card->ef_dir);
		ui_add_value(table, "EF(DIR)", i, buf);

		_TMP_BUILD_BUF(card->app_root);
		ui_add_value(table, "app_root", i, buf);

		_TMP_BUILD_BUF(card->odf);
		ui_add_value(table, "ODF", i, buf);

		_TMP_BUILD_BUF(card->tif);
		ui_add_value(table, "TIF", i, buf);

		_TMP_BUILD_BUF(card->unused);
		ui_add_value(table, "Unused", i, buf);
		i++;
	}
	sess->result_table = table;
	return 0;
}

static int p15card_cdf_dump(ui_session_t *sess, ui_entry_t *inst,
			     void *ctx, int argc, char **argv)
{
#if 1
	ui_table_t *table = ui_table_by_name(sess, "p15card_list");
	int i = 0;
	char buf[3 * ICC_PATH_MAX];
	struct p15_card *card;
	struct pkcs15_df *df;

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "p15card_list");
	if (!table)
		return -1;

	ui_add_title(table, 0, "index");
	ui_add_title(table, 1, "app_root");
	ui_add_title(table, 2, "DF");
	ui_add_title(table, 3, "PATH");

#define _TMP_BUILD_BUF(file)						\
		r = icc_fetch_file_path(file, buf, sizeof (buf));	\
		if (r)	snprintf(buf, sizeof(buf), "not found");	\

	i = 0;
	for_each_card(card) {
		for_each_df(df, card) {
			int r;
			if (card->binded == 0)
				continue;
			
			snprintf(buf, sizeof(buf), "%04x", card->idx);
			ui_add_value(table, "index", i, buf);
			
			_TMP_BUILD_BUF(card->app_root);
			ui_add_value(table, "app_root", i, buf);
			
			ui_add_value(table, "DF", i, p15_df_type2str(df->type));
			
			icc_deformat_path(&df->path, buf, sizeof (buf));
			ui_add_value(table, "PATH", i, buf);
			i++;
		}
	}

	sess->result_table = table;
#endif
	return 0;
}
ui_schema_t p15_card_scheme[] = {
	/* .pcsc.icc */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".pkcs15.card", "card", "PKCS#15 cards" },

	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".pkcs15.card.cdf", "cdf", "PKCS#15 app CDF" },

	{ UI_TYPE_NONE },
};

ui_command_t p15_card_command = {
	"dump",
	"dump card",
	".pkcs15.card",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(p15_card_command.link),
	p15card_dump,
};

ui_command_t p15_cdf_command = {
	"cdf",
	"dump cdf on the current app dir",
	".pkcs15.card",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(p15_cdf_command.link),
	p15card_cdf_dump,
};

int __init pkcs15_card_init(void)
{
	ui_register_schema(p15_card_scheme);

	ui_register_command(&p15_card_command);
	ui_register_command(&p15_cdf_command);

	return 0;
}

void __exit pkcs15_card_exit(void)
{
	ui_unregister_command(&p15_cdf_command);
	ui_unregister_command(&p15_card_command);

	ui_unregister_schema(p15_card_scheme);
}

