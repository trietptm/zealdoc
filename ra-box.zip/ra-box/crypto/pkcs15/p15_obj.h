#ifndef __P15_OBJ_H_
#define __P15_OBJ_H_

/* pkcs15.c */

typedef struct p15_trans {

	struct p15_card *card;

	/* user provide */
	p15_user_cb	cb;
	void		*cb_arg;
	void		**out_pp;
	void		*out_p;

	/* someone need this store private data */
	union {
		void	*priv_v;
		int	priv_i;
	} u;

	/* ours */
	int		self_free;	/* flag indicate whether free this buf byself */
	uint8_t		*buf;		/* rx/tx */
	int		buflen;		/* rx/tx: used when knew/expected the buf length in advance */
	int		actual;		/* rx: knew buf length or not, if not this keep actual length and updated by malloc() user */
	struct icc_file *file;
	struct icc_path *path;

	int		ret;		/* result to caller */

} p15_trans_t;

typedef void (*p15_trans_cb)(p15_trans_t *trans);


void p15_destroy_trans(p15_trans_t *trans);

p15_trans_t *p15_build_trans(struct p15_card *p15card,
			     p15_user_cb cb, void *cbarg, 
			     void *outp, void **outpp);

int pkcs15_read_file(struct p15_card *p15card, struct icc_path *in_path,
		     uint8_t **buf, size_t *buflen, struct icc_file **file_out,
		     p15_trans_cb cb, p15_trans_t *trans);

void pkcs15_free_obj(struct pkcs15_object *obj);

int pkcs15_parse_tokeninfo(struct pkcs15_tokeninfo *ti,
			   const uint8_t *buf, size_t blen);

int pkcs15_parse_odf(const uint8_t * buf, size_t buflen, 
		     struct p15_card *p15_handle);

int pkcs15_parse_ddo(struct p15_card *, const uint8_t * buf, size_t );

int pkcs15_encode_dir(struct p15_card *, uint8_t **out, size_t *out_len);

int pkcs15_encode_odf(struct p15_card *, uint8_t **out, size_t *out_len);

int pkcs15_encode_df(struct p15_card *p15card, struct pkcs15_df *df,
		     uint8_t **buf_out, size_t *bufsize_out);

/* Parse all unenumed df: 
 * When bind success, binder will call it. */
int pkcs15_all_parse_df(struct p15_card *card);

int pkcs15_parse_df(struct p15_card *p15card,
		    struct pkcs15_df *df,
		    p15_user_cb cb, void *cbarg);

int pkcs15_add_unusedspace(struct p15_card *, 
			   const struct icc_path *, const struct pkcs15_id *);

void pkcs15_remove_unusedspace(struct p15_card *p15card,
			       struct p15_unusedspace *obj);

int pkcs15_encode_unusedspace(struct p15_card *p15card,
			      uint8_t **buf, size_t *buflen);

int pkcs15_parse_unusedspace(const uint8_t * buf, size_t buflen,
			     struct p15_card *card);

/* p15_pubkey.c */
void pkcs15_erase_pubkey(struct pkcs15_pubkey *key);

void pkcs15_free_pubkey(struct pkcs15_pubkey *key);

void pkcs15_free_pubkey_info(struct pkcs15_pubkey_info *key);

int pkcs15_decode_pukdf_entry(struct p15_card *p15card,
			      struct pkcs15_object *obj,
			      const uint8_t ** buf, size_t *buflen);

int pkcs15_encode_pukdf_entry(const struct pkcs15_object *obj,
				 uint8_t **buf, size_t *buflen);

int pkcs15_encode_pubkey(struct pkcs15_pubkey *pubkey, 
			 uint8_t **out, size_t *out_len);

int pkcs15_decode_pubkey(struct pkcs15_pubkey *pubkey,
			 const uint8_t *in, size_t in_len);

void *p15_pubkey_info_attr(void *data, uint8_t type);

/* p15_prkey.c */
void pkcs15_free_prkey(struct pkcs15_prkey *key);

void pkcs15_free_prkey_info(struct pkcs15_prkey_info *key);

void pkcs15_erase_prkey(struct pkcs15_prkey *key);

int pkcs15_encode_prkdf_entry(const struct pkcs15_object *obj,
			      uint8_t **buf, size_t *buflen);

int pkcs15_decode_prkdf_entry(struct p15_card *p15card,
			      struct pkcs15_object *obj,
			      const uint8_t ** buf, size_t *buflen);

void *p15_prkey_info_attr(void *data, uint8_t type);

/* p15_cert.c */
void pkcs15_free_cert(struct pkcs15_cert *cert);

void pkcs15_free_cert_info(struct pkcs15_cert_info *cert);

int pkcs15_encode_cdf_entry(const struct pkcs15_object *obj,
			       uint8_t **buf, size_t *bufsize);

int pkcs15_decode_cdf_entry(struct p15_card *p15card, 
			    struct pkcs15_object *obj,
			    const uint8_t **buf, size_t *buflen);

void *p15_cert_info_attr(void *data, uint8_t type);

/* p15_auth.c */
int pkcs15_decode_aodf_entry(struct p15_card *, struct pkcs15_object *,
			     const uint8_t **buf, size_t *buflen);

int pkcs15_encode_aodf_entry(const struct pkcs15_object *obj,
			     uint8_t **buf, size_t *bufsize);

void *p15_auth_info_attr(void *info, uint8_t type);

void pkcs15_free_pin_info(struct pkcs15_pin_info *pin);


/* p15_data.c */
void pkcs15_free_data_object(struct pkcs15_data *data_object);

void pkcs15_free_data_info(struct pkcs15_data_info *data);

int pkcs15_encode_dodf_entry(const struct pkcs15_object *obj,
			     uint8_t **buf, size_t *bufsize);

int pkcs15_decode_dodf_entry(struct p15_card *p15card,
			     struct pkcs15_object *obj,
			     const uint8_t ** buf, size_t *buflen);

void *p15_data_info_attr(void *data, uint8_t type);

#endif	/* __P15_OBJ_H_ */
