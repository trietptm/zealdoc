#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

#include "p15_obj.h"

static const struct pkcs15_asn1_entry     c_asn1_data_object[] = {
        { "dataObject", PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_OCTET_STRING, 0, NULL, NULL },
        { NULL, 0, 0, 0, NULL, NULL }
};

static struct pkcs15_data *p15_new_data(void);

static void __read_data_cb(p15_trans_t *trans)
{
	struct pkcs15_data *data_object = NULL;
	int ret = trans->ret;

	if (ret >= 0) {
		data_object = p15_new_data();
		if (!data_object) {
			trans->ret = PKCS15_ERR_INVALID_ASN1_OBJ;
			goto fail;
		}
		data_object->data = trans->buf;
		data_object->data_len = trans->actual;
		trans->self_free = 0;
		*trans->out_pp = data_object;
		trans->ret = 0;
		goto succ;
	}
	return;
fail:
	/* FIXME: need free? */
	if (data_object) free(data_object);
succ:
	if (trans->cb) trans->cb(trans->cb_arg, trans->ret);
	p15_destroy_trans(trans);
	return;
}

int pkcs15_read_data_object(struct p15_card *p15card,
			    struct pkcs15_data_info *info,
			    struct pkcs15_data **data_object_out,
			    p15_user_cb cb, void *cbarg)
{
	p15_trans_t *trans;
	int r;

	if (p15card == NULL || info == NULL || data_object_out == NULL)
		return PKCS15_ERR_INVALID_ARGS;

	trans = p15_build_trans(cb, cbarg, NULL, (void **)data_object_out);

	if (!trans)
		return -1;

	r = pkcs15_read_file(p15card, &info->path, &trans->buf, &trans->actual, NULL,
			     __read_data_cb, trans);
	if (r < 0) {
		cb(trans->cb_arg, -1);
		p15_destroy_trans(trans);
	}

	return r;
}

static const struct pkcs15_asn1_entry c_asn1_data[] = {
	{ "data", PKCS15_ASN1_PKCS15_OBJECT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};
static const struct pkcs15_asn1_entry c_asn1_com_data_attr[] = {
	{ "appName", PKCS15_ASN1_UTF8STRING, PKCS15_ASN1_TAG_UTF8STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "appOID", PKCS15_ASN1_OBJECT, PKCS15_ASN1_TAG_OBJECT, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};
static const struct pkcs15_asn1_entry c_asn1_type_data_attr[] = {
	{ "path", PKCS15_ASN1_PATH, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

int pkcs15_decode_dodf_entry(struct p15_card *p15card,
			     struct pkcs15_object *obj,
			     const uint8_t ** buf, size_t *buflen)
{
	struct pkcs15_data_info info;
	struct pkcs15_asn1_entry
				asn1_com_data_attr[3],
				asn1_type_data_attr[2],
				asn1_data[2];
	struct asn1_pkcs15_object data_obj = { obj, asn1_com_data_attr, NULL,
					     asn1_type_data_attr };
	size_t label_len = sizeof(info.app_label);
	int r;

	pkcs15_copy_asn1_entry(c_asn1_com_data_attr, asn1_com_data_attr);
	pkcs15_copy_asn1_entry(c_asn1_type_data_attr, asn1_type_data_attr);
	pkcs15_copy_asn1_entry(c_asn1_data, asn1_data);
	
	pkcs15_format_asn1_entry(asn1_com_data_attr + 0, &info.app_label, &label_len, 0);
	pkcs15_format_asn1_entry(asn1_com_data_attr + 1, &info.app_oid, NULL, 0);
	pkcs15_format_asn1_entry(asn1_type_data_attr + 0, &info.path, NULL, 0);
	pkcs15_format_asn1_entry(asn1_data + 0, &data_obj, NULL, 0);

	/* Fill in defaults */
	memset(&info, 0, sizeof(info));
	info.app_oid.value[0] = -1;

	r = pkcs15_asn1_decode(asn1_data, *buf, *buflen, buf, buflen);
	if (r == PKCS15_ERR_ASN1_END_OF_CONTENTS)
		return r;
	if (r < 0) {
		p15_log(P15_LOG_ERR, "ASN.1 decoding failed");
		return r;
	}

	r = icc_make_absolute_path(&p15card->app_root->path, &info.path);
	if (r < 0)
		return r;
	obj->type = PKCS15_TYPE_DATA_OBJECT;
	obj->data = malloc(sizeof(info));
	if (obj->data == NULL) {
		return	PKCS15_ERR_NO_MEM;
	}
	memcpy(obj->data, &info, sizeof(info));

	return 0;
}

int pkcs15_encode_dodf_entry(const struct pkcs15_object *obj,
			     uint8_t **buf, size_t *bufsize)
{
	struct pkcs15_asn1_entry
				asn1_com_data_attr[4],
				asn1_type_data_attr[2],
				asn1_data[2];
	struct pkcs15_data_info *info;
	struct asn1_pkcs15_object data_obj = { (struct pkcs15_object *) obj,
							asn1_com_data_attr, NULL,
							asn1_type_data_attr };
	size_t label_len;

	info = (struct pkcs15_data_info *) obj->data;
	label_len = strlen(info->app_label);

	pkcs15_copy_asn1_entry(c_asn1_com_data_attr, asn1_com_data_attr);
	pkcs15_copy_asn1_entry(c_asn1_type_data_attr, asn1_type_data_attr);
	pkcs15_copy_asn1_entry(c_asn1_data, asn1_data);
	
	if (label_len) {
		pkcs15_format_asn1_entry(asn1_com_data_attr + 0,
				&info->app_label, &label_len, 1);
	}
	if (info->app_oid.value[0] != -1) {
		pkcs15_format_asn1_entry(asn1_com_data_attr + 1,
				&info->app_oid, NULL, 1);
	}
	pkcs15_format_asn1_entry(asn1_type_data_attr + 0, &info->path, NULL, 1);
	pkcs15_format_asn1_entry(asn1_data + 0, &data_obj, NULL, 1);

	return pkcs15_asn1_encode(asn1_data, buf, bufsize);
}

static struct pkcs15_data *p15_new_data(void)
{
	struct pkcs15_data *d = malloc(sizeof (struct pkcs15_data));
	if (!d) return NULL;
	memset(d, 0, sizeof (struct pkcs15_data));
	return d;
}

void pkcs15_free_data_object(struct pkcs15_data *data_object)
{
	if (!data_object)
		return;

	free(data_object->data);
	free(data_object);
}

void pkcs15_free_data_info(struct pkcs15_data_info *data)
{
	free(data);
}
