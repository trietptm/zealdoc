#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

struct pkcs15_app_entry {
	const uint8_t *aid;
	size_t aid_len;
	const char *desc;
};

static const struct pkcs15_app_entry g_apps[] = {
	{ (const uint8_t *) "\xA0\x00\x00\x00\x63PKCS-15", 12, "PKCS #15" },
	{ (const uint8_t *) "\xA0\x00\x00\x01\x77PKCS-15", 12, "Belgian eID" },
};

static const struct pkcs15_asn1_entry c_asn1_dirrecord[] = {
	{ "aid",   PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_APP | 15, 0, NULL, NULL },
	{ "label", PKCS15_ASN1_UTF8STRING,   PKCS15_ASN1_APP | 16, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "path",  PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_APP | 17, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "ddo",   PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_APP | 19 | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_dir[] = {
	{ "dirRecord", PKCS15_ASN1_STRUCT, PKCS15_ASN1_APP | 1 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_app_entry *
find_app_entry(const uint8_t *aid, size_t aid_len);
static struct icc_app_info *
pkcs15_find_app_by_id(struct p15_card *hd, int id);
static struct icc_app_info *pkcs15_get_first_app(struct p15_card *hd);
static struct icc_app_info *pkcs15_get_next_app(struct p15_card *hd, int id);
static struct icc_app_info *p15_get_curr_app(struct p15_card *hd);

static const struct pkcs15_app_entry *
find_app_entry(const uint8_t * aid, size_t aid_len)
{
	size_t i;

	for (i = 0; i < sizeof(g_apps)/sizeof(g_apps[0]); i++) {
		if (g_apps[i].aid_len == aid_len &&
		    memcmp(g_apps[i].aid, aid, aid_len) == 0)
			return &g_apps[i];
	}
	return NULL;
}

/* @id: if > 0 get next one */
static struct icc_app_info *
pkcs15_find_app_by_id(struct p15_card *hd, int id)
{
	int i, c;
	int app_count = p15_app_count(hd);
	struct icc_app_info **apps = p15_app_poniter(hd);
	/* ICC_APP_MAX */

	c = sizeof(g_apps)/sizeof(g_apps[0]);

	while (c--) {
		size_t aid_len = g_apps[c].aid_len;
		const uint8_t *aid = g_apps[c].aid;

		for (i = 0; i < app_count; i++) {
			if (apps[i]->aid_len == aid_len &&
			    memcmp(apps[i]->aid, aid, aid_len) == 0) {
				if ((id < 0) ||
				    (id >= 0 && apps[i]->id > id))
					return apps[i];
			}
		}
	}
	return NULL;
}

/* get the first app matched PKCS15 */
static struct icc_app_info *pkcs15_get_first_app(struct p15_card *hd)
{
	struct icc_app_info *app = NULL;

	app = pkcs15_find_app_by_id(hd, -1);

	return app;
}

struct icc_app_info *pkcs15_get_next_app(struct p15_card *hd, int id)
{
	struct icc_app_info *app = NULL;

	app = pkcs15_find_app_by_id(hd, id);

	return app;
}

struct icc_app_info *p15_get_curr_app(struct p15_card *hd)
{
	int i;
	int app_count = p15_app_count(hd);
	struct icc_app_info **apps = p15_app_poniter(hd);
	size_t len = hd->app_root->path.len;
	uint8_t *value = hd->app_root->path.value;
	/* ICC_APP_MAX */
	for (i = 0; i < app_count; i++) {
		if ((len == apps[i]->path.len) &&
		    (memcmp(apps[i]->path.value, value, len) == 0))
			return apps[i];
	}
	return NULL;
}

struct icc_app_info *p15_get_app(struct p15_card *hd)
{
	struct icc_app_info *curr_app = p15_get_curr_app(hd);
	if (!curr_app)
		return pkcs15_get_first_app(hd);
	return pkcs15_get_next_app(hd, curr_app->id);
}

/* PKCS15 5.4:
 * TAG 0x61 - application template 
 * TAG 0x4f - application identifier 
 * TAG 0x51 - path 
 * TAG 0x50 - application label 
 * TAG 0x73 - discretionary ASN.1 data objects
 */
int parse_dir_record(struct p15_card *card_handle, 
		     uint8_t **rbuf, size_t *rbuf_len, int rec_nr)
{
	struct pkcs15_asn1_entry asn1_dirrecord[5], asn1_dir[2];
	struct icc_app_info *app = NULL, **apps;
	const struct pkcs15_app_entry *ae;
	uint8_t aid[128], label[128], path[128], ddo[128];
	size_t aid_len = sizeof(aid), label_len = sizeof(label);
	size_t path_len = sizeof(path), ddo_len = sizeof(ddo);
	int r, app_count;

	pkcs15_copy_asn1_entry(c_asn1_dirrecord, asn1_dirrecord);
	pkcs15_copy_asn1_entry(c_asn1_dir, asn1_dir);
	pkcs15_format_asn1_entry(asn1_dir + 0, asn1_dirrecord, NULL, 0);
	pkcs15_format_asn1_entry(asn1_dirrecord + 0, aid, &aid_len, 0);
	pkcs15_format_asn1_entry(asn1_dirrecord + 1, label, &label_len, 0);
	pkcs15_format_asn1_entry(asn1_dirrecord + 2, path, &path_len, 0);
	pkcs15_format_asn1_entry(asn1_dirrecord + 3, ddo, &ddo_len, 0);

	r = pkcs15_asn1_decode(asn1_dir, *rbuf, *rbuf_len, 
			       (const uint8_t **)rbuf, rbuf_len);
	if (r == PKCS15_ERR_ASN1_END_OF_CONTENTS)
		return r;

	if (r) return r;
	if (aid_len > ICC_AID_MAX)
		return PKCS15_ERR_INVALID_ASN1_OBJ;

	app = (struct icc_app_info *)malloc(sizeof(struct icc_app_info));
	if (!app) 
		return PKCS15_ERR_NO_MEM;
	memset(app, 0, sizeof (struct icc_app_info));

	memcpy(app->aid, aid, aid_len);
	app->aid_len = aid_len;
	if (asn1_dirrecord[1].flags & PKCS15_ASN1_PRESENT)
		app->label = strdup((char *)label);
	else 
		app->label = NULL;

	if (asn1_dirrecord[2].flags & PKCS15_ASN1_PRESENT) {
		if (path_len > ICC_PATH_MAX) {
			free(app);
			return PKCS15_ERR_INVALID_ASN1_OBJ;
		}
		memcpy(app->path.value, path, path_len);
		app->path.len = path_len;
		app->path.type = ICC_PATH_TYPE_PATH;
	} else if (aid_len < sizeof(app->path.value)) {
		memcpy(app->path.value, aid, aid_len);
		app->path.len = aid_len;
		app->path.type = ICC_PATH_TYPE_DF_NAME;
	} else {
		app->path.len = 0;
	}
	if (asn1_dirrecord[3].flags & PKCS15_ASN1_PRESENT) {
		app->ddo = (uint8_t *)malloc(ddo_len);
		if (app->ddo == NULL) {
			if (app->label) free(app->label);
			free(app);
			return PKCS15_ERR_NO_MEM;
		}
		memcpy(app->ddo, ddo, ddo_len);
		app->ddo_len = ddo_len;
	} else {
		app->ddo = NULL;
		app->ddo_len = 0;
	}
	ae = find_app_entry(aid, aid_len);
	if (ae != NULL)
		app->desc = ae->desc;
	else
		app->desc = NULL;

	app->rec_nr = rec_nr;
	
	if (p15_app_is_exist(card_handle, app)) {
		if (app->label) free(app->label);
		free(app);
		goto out;
	}
	app_count = p15_app_count(card_handle);
	app->id = app_count;
	apps = p15_app_poniter(card_handle);
	apps[app_count] = app;
	p15_app_count_inc(card_handle);

	p15_log(P15_LOG_INFO, "DIR: add app=%02x %02x %02x %02x",
			app->path.value[0], app->path.value[1],
			app->path.value[2], app->path.value[3]);
out:
	return PKCS15_SUCCESS;
}





