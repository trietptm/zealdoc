#include "pkcs15_priv.h"

#define PKCS15_SERVICE_DESC	"Public-key cryptography standards 15"

int pkcs15_logger = 0;
log_source_t pkcs15_log_source = {
	"pkcs15"
};

void p15_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(pkcs15_logger, level, format, ap);
	va_end(ap);
}

static int __init pkcs15_log_init(void)
{
	pkcs15_logger = log_register_source(&pkcs15_log_source);
	return !pkcs15_logger;
}

static void __exit pkcs15_log_exit(void)
{
	log_unregister_source(pkcs15_logger);
}

ui_schema_t pkcs15_schema[] = {
	{ UI_TYPE_CLASS, 
	  UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, 
	  NULL, 
	  NULL,
	  ".pkcs15", 
	  "pkcs15", 
	  PKCS15_SERVICE_DESC},
	
	{ UI_TYPE_NONE },
};


modlinkage int __init pkcs15_init(void)
{
	pkcs15_log_init();
	pkcs15_bind_init();
	pkcs15_card_init();
	ui_register_schema(pkcs15_schema);
	

	return 0;
}

modlinkage void __exit pkcs15_exit(void)
{

	ui_unregister_schema(pkcs15_schema);
	pkcs15_card_exit();
	pkcs15_bind_exit();
	pkcs15_log_exit();
}

subsys_initcall(pkcs15_init);
subsys_exitcall(pkcs15_exit);
