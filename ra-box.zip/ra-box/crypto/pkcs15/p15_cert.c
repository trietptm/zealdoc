#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

#include "p15_obj.h"

static struct pkcs15_cert *p15_new_cert(void);
static int parse_x509_cert(const uint8_t *buf, size_t buflen, struct pkcs15_cert *cert);
static struct pkcs15_cert *p15_parse_new_x509_cert(uint8_t *data, int len);

static int parse_x509_cert(const uint8_t *buf, size_t buflen, struct pkcs15_cert *cert)
{
	int r;
	struct icc_algorithm_id pk_alg, sig_alg;
	struct pkcs15_der pk = { NULL, 0 };

	struct pkcs15_asn1_entry asn1_version[] = {
		{ "version", PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, 0, &cert->version, NULL },
		{ NULL, 0, 0, 0, NULL, NULL }
	};
	struct pkcs15_asn1_entry asn1_pkinfo[] = {
		{ "algorithm",		PKCS15_ASN1_ALGORITHM_ID,  PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, &pk_alg, NULL },
		{ "subjectPublicKey",	PKCS15_ASN1_BIT_STRING_NI, PKCS15_ASN1_TAG_BIT_STRING, PKCS15_ASN1_ALLOC, &pk.value, &pk.len },
		{ NULL, 0, 0, 0, NULL, NULL }
	};
	struct pkcs15_asn1_entry asn1_x509v3[] = {
		{ "certificatePolicies",	PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
		{ "subjectKeyIdentifier",	PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
		{ "crlDistributionPoints",	PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL | PKCS15_ASN1_ALLOC, &cert->crl, &cert->crl_len },
		{ "authorityKeyIdentifier",	PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
		{ "keyUsage",			PKCS15_ASN1_BOOLEAN, PKCS15_ASN1_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
		{ NULL, 0, 0, 0, NULL, NULL }
	};
	struct pkcs15_asn1_entry asn1_extensions[] = {
		{ "x509v3",		PKCS15_ASN1_STRUCT,    PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, asn1_x509v3, NULL },
		{ NULL, 0, 0, 0, NULL, NULL }
	};
	struct pkcs15_asn1_entry asn1_tbscert[] = {
		{ "version",		PKCS15_ASN1_STRUCT,    PKCS15_ASN1_CTX | 0 | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, asn1_version, NULL },
		{ "serialNumber",	PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_ALLOC, &cert->serial, &cert->serial_len },
		{ "signature",		PKCS15_ASN1_STRUCT,    PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
		{ "issuer",		PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_ALLOC, &cert->issuer, &cert->issuer_len },
		{ "validity",		PKCS15_ASN1_STRUCT,    PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
		{ "subject",		PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_ALLOC, &cert->subject, &cert->subject_len },
		{ "subjectPublicKeyInfo",PKCS15_ASN1_STRUCT,   PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, asn1_pkinfo, NULL },
		{ "extensions",		PKCS15_ASN1_STRUCT,    PKCS15_ASN1_CTX | 3 | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, asn1_extensions, NULL },
		{ NULL, 0, 0, 0, NULL, NULL }
	};
	struct pkcs15_asn1_entry asn1_cert[] = {
		{ "tbsCertificate",	PKCS15_ASN1_STRUCT,    PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, asn1_tbscert, NULL },
		{ "signatureAlgorithm",	PKCS15_ASN1_ALGORITHM_ID, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, &sig_alg, NULL },
		{ "signatureValue",	PKCS15_ASN1_BIT_STRING, PKCS15_ASN1_TAG_BIT_STRING, 0, NULL, NULL },
		{ NULL, 0, 0, 0, NULL, NULL }
	};
	const uint8_t *obj;
	size_t objlen;
	
	memset(cert, 0, sizeof(*cert));
	obj = p15_asn1_verify_tag(buf, buflen, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS,
				  &objlen);
	if (obj == NULL) {
		p15_log(P15_LOG_ERR, "X.509 certificate not found");
		return ICC_ERR_INVALID_ASN1_OBJECT;
	}
	cert->data_len = objlen + (obj - buf);
	r = pkcs15_asn1_decode(asn1_cert, obj, objlen, NULL, NULL);
	if (r < 0) {
		p15_log(P15_LOG_ERR, "ASN.1 parsing of certificate failed");
		return r;
	}

	cert->version++;

	cert->pubkey.algorithm = pk_alg.algorithm;
	pk.len >>= 3;	/* convert number of bits to bytes */
	cert->pubkey.data = pk;

	r = pkcs15_decode_pubkey(&cert->pubkey, pk.value, pk.len);
	if (r < 0)
		free(pk.value);
	pkcs15_asn1_clear_algorithm_id(&pk_alg);
	pkcs15_asn1_clear_algorithm_id(&sig_alg);

	return r;
}

static void __read_cert_cb(p15_trans_t *trans)
{
	int ret = trans->ret;
	struct pkcs15_cert *cert = NULL;

	if (ret >= 0) {
		cert = p15_parse_new_x509_cert(trans->buf, trans->actual);
		if (!cert) {
			trans->ret = PKCS15_ERR_INVALID_ASN1_OBJ;
			goto fail;
		}
		cert->data = trans->buf;
		*trans->out_pp = cert;
		trans->self_free = 0;
		trans->ret = 0;
		goto succ;
	}
fail:
	if (cert) free(cert);
succ:
	if (trans->cb) trans->cb(trans->cb_arg, trans->ret);
	p15_destroy_trans(trans);
	return;
}

/* user who call this fun() need check return value and the out param,
 * if return >=0 and @out has content means succeed do sync things.
 * if return >=0 and @out has no content means succeed do init things, we'll call
 * cb() later.
 * if return negative user should not use @out anymore and also do not wait cb().
 */
/* This call may need sync/async process: how to notify user the mode(sync/async)?
 * 1) He may check the @out like above words.
 * 2) Since the *info is coming from user, so he is sure the mode at the beginning.
 */
int pkcs15_read_cert(struct p15_card *p15card,
		     struct pkcs15_cert_info *info,
		     struct pkcs15_cert **cert_out,
		     p15_user_cb cb, void *cbarg)
{
	int r;
	struct pkcs15_cert *cert;
	uint8_t *data = NULL;
	size_t len;
	struct pkcs15_der copy;

	if (p15card == NULL || info == NULL || cert_out == NULL)
		return -1;

	
	/* async process */
	if (info->path.len) {
		p15_trans_t *trans = p15_build_trans(p15card, cb, cbarg, NULL, (void **)cert_out);

		if (!trans)
			return -1;
		
		r = pkcs15_read_file(p15card, &info->path, 
				     &trans->buf, &trans->actual, NULL,
				     __read_cert_cb, trans);
		if (r < 0) {
			cb(trans->cb_arg, -1);
			p15_destroy_trans(trans);
		}
		return r;
	}

	pkcs15_asn1_der_copy(&copy, &info->value);
	data = copy.value;
	len = copy.len;

	cert = p15_parse_new_x509_cert(data, len);
	if (!cert) {
		free(data);
		return PKCS15_ERR_NO_MEM;
	}
	cert->data = data;
	*cert_out = cert;
	return 0;
}

static const struct pkcs15_asn1_entry c_asn1_cred_ident[] = {
	{ "idType",	PKCS15_ASN1_INTEGER,      PKCS15_ASN1_TAG_INTEGER, 0, NULL, NULL },
	{ "idValue",	PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_OCTET_STRING, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};
static const struct pkcs15_asn1_entry c_asn1_com_cert_attr[] = {
	{ "iD",         PKCS15_ASN1_PKCS15_ID, PKCS15_ASN1_TAG_OCTET_STRING, 0, NULL, NULL },
	{ "authority",  PKCS15_ASN1_BOOLEAN,   PKCS15_ASN1_TAG_BOOLEAN, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "identifier", PKCS15_ASN1_STRUCT,    PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	/* FIXME: Add rest of the optional fields */
	{ NULL, 0, 0, 0, NULL, NULL }
};
static const struct pkcs15_asn1_entry c_asn1_x509_cert_value_choice[] = {
	{ "path",	PKCS15_ASN1_PATH,	   PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "direct",	PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_CTX | 0 | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL | PKCS15_ASN1_ALLOC, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};
static const struct pkcs15_asn1_entry c_asn1_x509_cert_attr[] = {
	{ "value",	PKCS15_ASN1_CHOICE, 0, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};
static const struct pkcs15_asn1_entry c_asn1_type_cert_attr[] = {
	{ "x509CertificateAttributes", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};
static const struct pkcs15_asn1_entry c_asn1_cert[] = {
	{ "x509Certificate", PKCS15_ASN1_PKCS15_OBJECT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

int pkcs15_decode_cdf_entry(struct p15_card *p15card, struct pkcs15_object *obj,
			    const uint8_t **buf, size_t *buflen)
{
	struct pkcs15_cert_info info;
	struct pkcs15_asn1_entry
				asn1_cred_ident[3], asn1_com_cert_attr[4],
				asn1_x509_cert_attr[2], asn1_type_cert_attr[2],
				asn1_cert[2], asn1_x509_cert_value_choice[3];

	struct asn1_pkcs15_object 
				cert_obj = { obj, asn1_com_cert_attr, NULL,
					     asn1_type_cert_attr };
	struct pkcs15_der *der = &info.value;
	uint8_t id_value[128];
	int id_type;
	size_t id_value_len = sizeof(id_value);
	int r;

	pkcs15_copy_asn1_entry(c_asn1_cred_ident, asn1_cred_ident);
	pkcs15_copy_asn1_entry(c_asn1_com_cert_attr, asn1_com_cert_attr);
	pkcs15_copy_asn1_entry(c_asn1_x509_cert_attr, asn1_x509_cert_attr);
	pkcs15_copy_asn1_entry(c_asn1_x509_cert_value_choice, asn1_x509_cert_value_choice);
	pkcs15_copy_asn1_entry(c_asn1_type_cert_attr, asn1_type_cert_attr);
	pkcs15_copy_asn1_entry(c_asn1_cert, asn1_cert);
	
	pkcs15_format_asn1_entry(asn1_cred_ident + 0, &id_type, NULL, 0);
	pkcs15_format_asn1_entry(asn1_cred_ident + 1, &id_value, &id_value_len, 0);
	pkcs15_format_asn1_entry(asn1_com_cert_attr + 0, &info.id, NULL, 0);
	pkcs15_format_asn1_entry(asn1_com_cert_attr + 1, &info.authority, NULL, 0);
	pkcs15_format_asn1_entry(asn1_com_cert_attr + 2, asn1_cred_ident, NULL, 0);
	pkcs15_format_asn1_entry(asn1_x509_cert_attr + 0, asn1_x509_cert_value_choice, NULL, 0);
	pkcs15_format_asn1_entry(asn1_x509_cert_value_choice + 0, &info.path, NULL, 0);
	pkcs15_format_asn1_entry(asn1_x509_cert_value_choice + 1, &der->value, &der->len, 0);
	pkcs15_format_asn1_entry(asn1_type_cert_attr + 0, asn1_x509_cert_attr, NULL, 0);
	pkcs15_format_asn1_entry(asn1_cert + 0, &cert_obj, NULL, 0);

        /* Fill in defaults */
        memset(&info, 0, sizeof(info));
	info.authority = 0;
	
	r = pkcs15_asn1_decode(asn1_cert, *buf, *buflen, buf, buflen);
	/* In case of error, trash the cert value (direct coding) */
	if (r < 0 && der->value)
		free(der->value);
	if (r == PKCS15_ERR_ASN1_END_OF_CONTENTS)
		return r;
	if (r < 0) {
		p15_log(P15_LOG_ERR, "ASN.1 decoding failed");
		return r;
	}
	r = icc_make_absolute_path(&p15card->app_root->path, &info.path);
	if (r < 0)
		return r;
	obj->type = PKCS15_TYPE_CERT_X509;
	obj->data = malloc(sizeof(info));
	if (obj->data == NULL) {
		return PKCS15_ERR_NO_MEM;
	}
	memcpy(obj->data, &info, sizeof(info));

	return 0;
}

int pkcs15_encode_cdf_entry(const struct pkcs15_object *obj,
			       uint8_t **buf, size_t *bufsize)
{
	struct pkcs15_asn1_entry
				asn1_cred_ident[3], asn1_com_cert_attr[4],
				asn1_x509_cert_attr[2], asn1_type_cert_attr[2],
				asn1_cert[2], asn1_x509_cert_value_choice[3];

	struct pkcs15_cert_info *infop = (struct pkcs15_cert_info *) obj->data;
	struct pkcs15_der *der = &infop->value;
	struct asn1_pkcs15_object cert_obj = { (struct pkcs15_object *) obj,
							asn1_com_cert_attr, NULL,
							asn1_type_cert_attr };
	int r;

	pkcs15_copy_asn1_entry(c_asn1_cred_ident, asn1_cred_ident);
	pkcs15_copy_asn1_entry(c_asn1_com_cert_attr, asn1_com_cert_attr);
	pkcs15_copy_asn1_entry(c_asn1_x509_cert_attr, asn1_x509_cert_attr);
	pkcs15_copy_asn1_entry(c_asn1_x509_cert_value_choice, asn1_x509_cert_value_choice);
	pkcs15_copy_asn1_entry(c_asn1_type_cert_attr, asn1_type_cert_attr);
	pkcs15_copy_asn1_entry(c_asn1_cert, asn1_cert);
	
	pkcs15_format_asn1_entry(asn1_com_cert_attr + 0, (void *) &infop->id, NULL, 1);
	if (infop->authority)
		pkcs15_format_asn1_entry(asn1_com_cert_attr + 1, (void *) &infop->authority, NULL, 1);
	if (infop->path.len || !der->value) {
		pkcs15_format_asn1_entry(asn1_x509_cert_value_choice + 0, &infop->path, NULL, 1);
	} else {
		pkcs15_format_asn1_entry(asn1_x509_cert_value_choice + 1, der->value, &der->len, 1);
	}
	pkcs15_format_asn1_entry(asn1_type_cert_attr + 0, &asn1_x509_cert_value_choice, NULL, 1);
	pkcs15_format_asn1_entry(asn1_cert + 0, (void *) &cert_obj, NULL, 1);

	r = pkcs15_asn1_encode(asn1_cert, buf, bufsize);

	return r;
}

	
static struct pkcs15_cert *p15_parse_new_x509_cert(uint8_t *data, int len)
{
	struct pkcs15_cert *c = p15_new_cert();
	if (!c) return NULL;

	if (parse_x509_cert(data, len, c)) {
		pkcs15_free_cert(c);
		return NULL;
	}
	return c;
}

static struct pkcs15_cert *p15_new_cert(void)
{
	struct pkcs15_cert *c = malloc(sizeof (struct pkcs15_cert));
	if (!c) return NULL;
	memset(c, 0, sizeof (struct pkcs15_cert));
	return c;
}

void pkcs15_free_cert(struct pkcs15_cert *cert)
{
	if (!cert) return;

	pkcs15_erase_pubkey(&cert->pubkey);
	if (cert->subject) free(cert->subject);
	if (cert->issuer)  free(cert->issuer);
	if (cert->serial)  free(cert->serial);
	if (cert->data)    free(cert->data);
	if (cert->crl)     free(cert->crl);
	if (cert)	   free(cert);
}

void pkcs15_free_cert_info(struct pkcs15_cert_info *cert)
{
	if (!cert)
		return;
	if (cert->value.value)
		free(cert->value.value);
	free(cert);
}

void *p15_cert_info_attr(void *data, uint8_t type)
{
	struct pkcs15_cert_info *info = (struct pkcs15_cert_info *)data;
	if (!info)
		return NULL;
	switch (type) {
	case P15_INFO_ATTR_PATH:
		return &info->path;
	default:
		return NULL;
	}
}
