#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

#include "p15_obj.h"

static struct pkcs15_pubkey *p15_new_pubkey(void);
static struct pkcs15_pubkey *p15_decode_new_pubkey(int algo, uint8_t *data, int len);

static int pkcs15_decode_pubkey_dsa(struct pkcs15_pubkey_dsa *key,
			     const uint8_t *buf, size_t buflen);
static int pkcs15_encode_pubkey_dsa(struct pkcs15_pubkey_dsa *key,
				uint8_t **buf, size_t *buflen);
static int pkcs15_encode_pubkey_rsa(struct pkcs15_pubkey_rsa *key,
				uint8_t **buf, size_t *buflen);
static int pkcs15_decode_pubkey_rsa(struct pkcs15_pubkey_rsa *key,
			     const uint8_t *buf, size_t buflen);

static const struct pkcs15_asn1_entry c_asn1_com_key_attr[] = {
	{ "iD",		 PKCS15_ASN1_PKCS15_ID, PKCS15_ASN1_TAG_OCTET_STRING, 0, NULL, NULL },
	{ "usage",	 PKCS15_ASN1_BIT_FIELD, PKCS15_ASN1_TAG_BIT_STRING, 0, NULL, NULL },
	{ "native",	 PKCS15_ASN1_BOOLEAN, PKCS15_ASN1_TAG_BOOLEAN, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "accessFlags", PKCS15_ASN1_BIT_FIELD, PKCS15_ASN1_TAG_BIT_STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "keyReference",PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_com_pubkey_attr[] = {
        /* FIXME */
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_rsakey_attr[] = {
	{ "value",	   PKCS15_ASN1_PATH, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "modulusLength", PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, 0, NULL, NULL },
	{ "keyInfo",	   PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_rsa_type_attr[] = {
	{ "publicRSAKeyAttributes", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_dsakey_attr[] = {
	{ "value",	   PKCS15_ASN1_PATH, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_dsa_type_attr[] = {
	{ "publicDSAKeyAttributes", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_pubkey_choice[] = {
	{ "publicRSAKey", PKCS15_ASN1_PKCS15_OBJECT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "publicDSAKey", PKCS15_ASN1_PKCS15_OBJECT, 2 | PKCS15_ASN1_CTX | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_pubkey[] = {
	{ "publicKey",	PKCS15_ASN1_CHOICE, 0, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

int pkcs15_decode_pukdf_entry(struct p15_card *p15card,
			      struct pkcs15_object *obj,
			      const uint8_t ** buf, size_t *buflen)
{
        struct pkcs15_pubkey_info info;
	int r;
	size_t usage_len = sizeof(info.usage);
	size_t af_len = sizeof(info.access_flags);
	struct pkcs15_asn1_entry asn1_com_key_attr[6], asn1_com_pubkey_attr[1];
	struct pkcs15_asn1_entry asn1_rsakey_attr[4], asn1_rsa_type_attr[2];
	struct pkcs15_asn1_entry asn1_dsakey_attr[2], asn1_dsa_type_attr[2];
	struct pkcs15_asn1_entry asn1_pubkey_choice[3];
	struct pkcs15_asn1_entry asn1_pubkey[2];
	struct asn1_pkcs15_object rsakey_obj = { obj, asn1_com_key_attr,
						    asn1_com_pubkey_attr, asn1_rsa_type_attr };
	struct asn1_pkcs15_object dsakey_obj = { obj, asn1_com_key_attr,
						    asn1_com_pubkey_attr, asn1_dsa_type_attr };

        pkcs15_copy_asn1_entry(c_asn1_pubkey, asn1_pubkey);
        pkcs15_copy_asn1_entry(c_asn1_pubkey_choice, asn1_pubkey_choice);
        pkcs15_copy_asn1_entry(c_asn1_rsa_type_attr, asn1_rsa_type_attr);
        pkcs15_copy_asn1_entry(c_asn1_rsakey_attr, asn1_rsakey_attr);
        pkcs15_copy_asn1_entry(c_asn1_dsa_type_attr, asn1_dsa_type_attr);
        pkcs15_copy_asn1_entry(c_asn1_dsakey_attr, asn1_dsakey_attr);
        pkcs15_copy_asn1_entry(c_asn1_com_pubkey_attr, asn1_com_pubkey_attr);
        pkcs15_copy_asn1_entry(c_asn1_com_key_attr, asn1_com_key_attr);

	pkcs15_format_asn1_entry(asn1_pubkey_choice + 0, &rsakey_obj, NULL, 0);
	pkcs15_format_asn1_entry(asn1_pubkey_choice + 1, &dsakey_obj, NULL, 0);

	pkcs15_format_asn1_entry(asn1_rsa_type_attr + 0, asn1_rsakey_attr, NULL, 0);

	pkcs15_format_asn1_entry(asn1_rsakey_attr + 0, &info.path, NULL, 0);
	pkcs15_format_asn1_entry(asn1_rsakey_attr + 1, &info.modulus_length, NULL, 0);

	pkcs15_format_asn1_entry(asn1_dsa_type_attr + 0, asn1_dsakey_attr, NULL, 0);

	pkcs15_format_asn1_entry(asn1_dsakey_attr + 0, &info.path, NULL, 0);

	pkcs15_format_asn1_entry(asn1_com_key_attr + 0, &info.id, NULL, 0);
	pkcs15_format_asn1_entry(asn1_com_key_attr + 1, &info.usage, &usage_len, 0);
	pkcs15_format_asn1_entry(asn1_com_key_attr + 2, &info.native, NULL, 0);
	pkcs15_format_asn1_entry(asn1_com_key_attr + 3, &info.access_flags, &af_len, 0);
	pkcs15_format_asn1_entry(asn1_com_key_attr + 4, &info.key_ref, NULL, 0);

	pkcs15_format_asn1_entry(asn1_pubkey + 0, asn1_pubkey_choice, NULL, 0);

        /* Fill in defaults */
        memset(&info, 0, sizeof(info));
	info.key_ref = -1;
	info.native = 1;

	r = pkcs15_asn1_decode(asn1_pubkey, *buf, *buflen, buf, buflen);
	if (r == PKCS15_ERR_INVALID_ASN1_OBJ)
		return r;
	if (r < 0) {
		p15_log(P15_LOG_ERR, "ASN.1 decoding failed");
		return r;
	}

	if (asn1_pubkey_choice[0].flags & PKCS15_ASN1_PRESENT) {
		obj->type = PKCS15_TYPE_PUBKEY_RSA;
	} else {
		obj->type = PKCS15_TYPE_PUBKEY_DSA;
	}
	r = icc_make_absolute_path(&p15card->app_root->path, &info.path);
	if (r < 0)
		return r;
	obj->data = malloc(sizeof(info));
	if (obj->data == NULL) {
		return PKCS15_ERR_NO_MEM;
	}
	memcpy(obj->data, &info, sizeof(info));

	return 0;
}

int pkcs15_encode_pukdf_entry(const struct pkcs15_object *obj,
				 uint8_t **buf, size_t *buflen)
{
	struct pkcs15_asn1_entry asn1_com_key_attr[6], asn1_com_pubkey_attr[1];
	struct pkcs15_asn1_entry asn1_rsakey_attr[4], asn1_rsa_type_attr[2];
	struct pkcs15_asn1_entry asn1_dsakey_attr[2], asn1_dsa_type_attr[2];
	struct pkcs15_asn1_entry asn1_pubkey_choice[3];
	struct pkcs15_asn1_entry asn1_pubkey[2];
	struct pkcs15_pubkey_info *pubkey =
                (struct pkcs15_pubkey_info *) obj->data;
	struct asn1_pkcs15_object rsakey_obj = { (struct pkcs15_object *) obj,
						    asn1_com_key_attr,
						    asn1_com_pubkey_attr, asn1_rsa_type_attr };
	struct asn1_pkcs15_object dsakey_obj = { (struct pkcs15_object *) obj,
						    asn1_com_key_attr,
						    asn1_com_pubkey_attr, asn1_dsa_type_attr };
	int r;
	size_t af_len, usage_len;

        pkcs15_copy_asn1_entry(c_asn1_pubkey, asn1_pubkey);
        pkcs15_copy_asn1_entry(c_asn1_pubkey_choice, asn1_pubkey_choice);
        pkcs15_copy_asn1_entry(c_asn1_rsa_type_attr, asn1_rsa_type_attr);
        pkcs15_copy_asn1_entry(c_asn1_rsakey_attr, asn1_rsakey_attr);
        pkcs15_copy_asn1_entry(c_asn1_dsa_type_attr, asn1_dsa_type_attr);
        pkcs15_copy_asn1_entry(c_asn1_dsakey_attr, asn1_dsakey_attr);
        pkcs15_copy_asn1_entry(c_asn1_com_pubkey_attr, asn1_com_pubkey_attr);
        pkcs15_copy_asn1_entry(c_asn1_com_key_attr, asn1_com_key_attr);

	switch (obj->type) {
	case PKCS15_TYPE_PUBKEY_RSA:
		pkcs15_format_asn1_entry(asn1_pubkey_choice + 0, &rsakey_obj, NULL, 1);

		pkcs15_format_asn1_entry(asn1_rsa_type_attr + 0, asn1_rsakey_attr, NULL, 1);

		pkcs15_format_asn1_entry(asn1_rsakey_attr + 0, &pubkey->path, NULL, 1);
		pkcs15_format_asn1_entry(asn1_rsakey_attr + 1, &pubkey->modulus_length, NULL, 1);
		break;

	case PKCS15_TYPE_PUBKEY_DSA:
		pkcs15_format_asn1_entry(asn1_pubkey_choice + 1, &dsakey_obj, NULL, 1);

		pkcs15_format_asn1_entry(asn1_dsa_type_attr + 0, asn1_dsakey_attr, NULL, 1);

		pkcs15_format_asn1_entry(asn1_dsakey_attr + 0, &pubkey->path, NULL, 1);
		break;
	default:
		p15_log(P15_LOG_ERR, "Unsupported public key type: %X", obj->type);
		return PKCS15_ERR_OTHER;
		break;
	}

	pkcs15_format_asn1_entry(asn1_com_key_attr + 0, &pubkey->id, NULL, 1);
	usage_len = sizeof(pubkey->usage);
	pkcs15_format_asn1_entry(asn1_com_key_attr + 1, &pubkey->usage, &usage_len, 1);
	if (pubkey->native == 0)
		pkcs15_format_asn1_entry(asn1_com_key_attr + 2, &pubkey->native, NULL, 1);
	if (pubkey->access_flags) {
		af_len = sizeof(pubkey->access_flags);
		pkcs15_format_asn1_entry(asn1_com_key_attr + 3, &pubkey->access_flags, &af_len, 1);
	}
	if (pubkey->key_ref >= 0)
		pkcs15_format_asn1_entry(asn1_com_key_attr + 4, &pubkey->key_ref, NULL, 1);
	pkcs15_format_asn1_entry(asn1_pubkey + 0, asn1_pubkey_choice, NULL, 1);

	r = pkcs15_asn1_encode(asn1_pubkey, buf, buflen);

	return r;
}

/* this should be required, not optional. But it is missing in some siemens cards and thus causes warnings */
/* so we silence these warnings by making it optional - the card works ok without. :/ */
static struct pkcs15_asn1_entry c_asn1_public_key[2] = {
	{ "publicKeyCoefficients", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static struct pkcs15_asn1_entry c_asn1_rsa_pub_coefficients[3] = {
	{ "modulus",  PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_ALLOC|PKCS15_ASN1_UNSIGNED, NULL, NULL },
	{ "exponent", PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_ALLOC|PKCS15_ASN1_UNSIGNED, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static struct pkcs15_asn1_entry c_asn1_dsa_pub_coefficients[5] = {
	{ "publicKey",PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_ALLOC|PKCS15_ASN1_UNSIGNED, NULL, NULL },
	{ "paramP",   PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_ALLOC|PKCS15_ASN1_UNSIGNED, NULL, NULL },
	{ "paramQ",   PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_ALLOC|PKCS15_ASN1_UNSIGNED, NULL, NULL },
	{ "paramG",   PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_ALLOC|PKCS15_ASN1_UNSIGNED, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL },
};

static int pkcs15_decode_pubkey_rsa(struct pkcs15_pubkey_rsa *key,
			     const uint8_t *buf, size_t buflen)
{
	struct pkcs15_asn1_entry asn1_public_key[2];
	struct pkcs15_asn1_entry asn1_rsa_coeff[3];
	int r;
	
	pkcs15_copy_asn1_entry(c_asn1_public_key, asn1_public_key);
	pkcs15_format_asn1_entry(asn1_public_key + 0, asn1_rsa_coeff, NULL, 0);

	pkcs15_copy_asn1_entry(c_asn1_rsa_pub_coefficients, asn1_rsa_coeff);
	pkcs15_format_asn1_entry(asn1_rsa_coeff + 0,
				&key->modulus.data, &key->modulus.len, 0);
	pkcs15_format_asn1_entry(asn1_rsa_coeff + 1,
				&key->exponent.data, &key->exponent.len, 0);

	r = pkcs15_asn1_decode(asn1_public_key, buf, buflen, NULL, NULL);
	if (r < 0) {
		p15_log(P15_LOG_ERR, "ASN.1 parsing of public key failed");
		return r;
	}

	return 0;
}

static int pkcs15_encode_pubkey_rsa(struct pkcs15_pubkey_rsa *key,
				uint8_t **buf, size_t *buflen)
{
	struct pkcs15_asn1_entry asn1_public_key[2];
	struct pkcs15_asn1_entry asn1_rsa_pub_coeff[3];
	int r;
	
	pkcs15_copy_asn1_entry(c_asn1_public_key, asn1_public_key);
	pkcs15_format_asn1_entry(asn1_public_key + 0, asn1_rsa_pub_coeff, NULL, 1);

	pkcs15_copy_asn1_entry(c_asn1_rsa_pub_coefficients, asn1_rsa_pub_coeff);
	pkcs15_format_asn1_entry(asn1_rsa_pub_coeff + 0,
				key->modulus.data, &key->modulus.len, 1);
	pkcs15_format_asn1_entry(asn1_rsa_pub_coeff + 1,
				key->exponent.data, &key->exponent.len, 1);

	r = pkcs15_asn1_encode(asn1_public_key, buf, buflen);
	if (r < 0) {
		p15_log(P15_LOG_ERR, "ASN.1 encoding failed");
		return r;
	}

	return 0;
}

static int pkcs15_decode_pubkey_dsa(struct pkcs15_pubkey_dsa *key,
			     const uint8_t *buf, size_t buflen)
{
	struct pkcs15_asn1_entry asn1_public_key[2];
	struct pkcs15_asn1_entry asn1_dsa_pub_coeff[5];
	int r;
	
	pkcs15_copy_asn1_entry(c_asn1_public_key, asn1_public_key);
	pkcs15_copy_asn1_entry(c_asn1_dsa_pub_coefficients, asn1_dsa_pub_coeff);

	pkcs15_format_asn1_entry(asn1_public_key + 0, asn1_dsa_pub_coeff, NULL, 1);
	pkcs15_format_asn1_entry(asn1_dsa_pub_coeff + 0,
				&key->pub.data, &key->pub.len, 0);
	pkcs15_format_asn1_entry(asn1_dsa_pub_coeff + 1,
				&key->g.data, &key->g.len, 0);
	pkcs15_format_asn1_entry(asn1_dsa_pub_coeff + 2,
				&key->p.data, &key->p.len, 0);
	pkcs15_format_asn1_entry(asn1_dsa_pub_coeff + 3,
				&key->q.data, &key->q.len, 0);

	r = pkcs15_asn1_decode(asn1_public_key, buf, buflen,
				NULL, NULL);
	if (r < 0) {
		p15_log(P15_LOG_ERR, "ASN.1 decoding failed");
		return r;
	}
	return 0;
}

static int pkcs15_encode_pubkey_dsa(struct pkcs15_pubkey_dsa *key,
				uint8_t **buf, size_t *buflen)
{
	struct pkcs15_asn1_entry asn1_public_key[2];
	struct pkcs15_asn1_entry asn1_dsa_pub_coeff[5];
	int r;
	
	pkcs15_copy_asn1_entry(c_asn1_public_key, asn1_public_key);
	pkcs15_copy_asn1_entry(c_asn1_dsa_pub_coefficients, asn1_dsa_pub_coeff);

	pkcs15_format_asn1_entry(asn1_public_key + 0, asn1_dsa_pub_coeff, NULL, 1);
	pkcs15_format_asn1_entry(asn1_dsa_pub_coeff + 0,
				key->pub.data, &key->pub.len, 1);
	pkcs15_format_asn1_entry(asn1_dsa_pub_coeff + 1,
				key->g.data, &key->g.len, 1);
	pkcs15_format_asn1_entry(asn1_dsa_pub_coeff + 2,
				key->p.data, &key->p.len, 1);
	pkcs15_format_asn1_entry(asn1_dsa_pub_coeff + 3,
				key->q.data, &key->q.len, 1);

	r = pkcs15_asn1_encode(asn1_public_key, buf, buflen);
	if (r < 0) {
		p15_log(P15_LOG_ERR, "ASN.1 encoding failed");
		return r;
	}

	return 0;
}

int pkcs15_encode_pubkey(struct pkcs15_pubkey *key,
			    uint8_t **buf, size_t *len)
{
	if (key->algorithm == ICC_ALGORITHM_RSA)
		return pkcs15_encode_pubkey_rsa(&key->u.rsa, buf, len);
	if (key->algorithm == ICC_ALGORITHM_DSA)
		return pkcs15_encode_pubkey_dsa(&key->u.dsa, buf, len);
	p15_log(P15_LOG_ERR, "Encoding of public key type %u not supported\n",
			key->algorithm);
	return PKCS15_ERR_NOT_SUPPORTED;
}

int pkcs15_decode_pubkey(struct pkcs15_pubkey *key, const uint8_t *buf, size_t len)
{
	if (key->algorithm == ICC_ALGORITHM_RSA)
		return pkcs15_decode_pubkey_rsa(&key->u.rsa, buf, len);
	if (key->algorithm == ICC_ALGORITHM_DSA)
		return pkcs15_decode_pubkey_dsa(&key->u.dsa, buf, len);
	p15_log(P15_LOG_ERR, "Decoding of public key type %u not supported",
			key->algorithm);
	return PKCS15_ERR_NOT_SUPPORTED;
}

static void __read_pubkey_cb(p15_trans_t *trans)
{
	int ret = trans->ret;
	struct pkcs15_pubkey *pkey = NULL;

	if (ret >= 0) {
		pkey = p15_decode_new_pubkey(trans->u.priv_i,
					     trans->buf,
					     trans->actual);
		if (!pkey) {
			trans->ret = PKCS15_ERR_INVALID_ASN1_OBJ;
			goto fail;
		}
		*trans->out_pp = pkey;
		trans->self_free = 0;
		goto succ;
	}
fail:
	if (pkey) free(pkey);
succ:
	if (trans->cb) trans->cb(trans->cb_arg, trans->ret);
	p15_destroy_trans(trans);
	return;
}

/*
 * Read public key.
 */
int pkcs15_read_pubkey(struct p15_card *p15card, struct pkcs15_object *obj,
		       struct pkcs15_pubkey **out, p15_user_cb cb, void *cbarg)
{
	struct pkcs15_pubkey_info *info;
	int	algorithm, r;
	p15_trans_t *trans;

	BUG_ON(p15card != NULL && obj != NULL && out != NULL);
	
	switch (obj->type) {
	case PKCS15_TYPE_PUBKEY_RSA:
		algorithm = ICC_ALGORITHM_RSA;
		break;
	case PKCS15_TYPE_PUBKEY_DSA:
		algorithm = ICC_ALGORITHM_DSA;
		break;
	default:
		p15_log(P15_LOG_ERR, "Unsupported public key type.");
		return PKCS15_ERR_NOT_SUPPORTED;
	}
	info = (struct pkcs15_pubkey_info *) obj->data;

	trans = p15_build_trans(p15card, cb, cbarg, NULL, (void **)out);
	if (!trans)
		return -1;

	trans->u.priv_i = algorithm;

	r = pkcs15_read_file(p15card, &info->path, &trans->buf, &trans->actual, NULL,
			     __read_pubkey_cb, trans);
	if (r < 0) {
		p15_log(P15_LOG_ERR, "Failed to read public key file.");
		cb(trans->cb_arg, -1);
		p15_destroy_trans(trans);
	}
	return r;
}

void pkcs15_erase_pubkey(struct pkcs15_pubkey *key)
{
	if (!key)
		return;
	
	switch (key->algorithm) {
	case ICC_ALGORITHM_RSA:
		free(key->u.rsa.modulus.data);
		free(key->u.rsa.exponent.data);
		break;
	case ICC_ALGORITHM_DSA:
		free(key->u.dsa.pub.data);
		free(key->u.dsa.g.data);
		free(key->u.dsa.p.data);
		free(key->u.dsa.q.data);
		break;
	}
	free(key->data.value);
	icc_mem_clear(key, sizeof(*key));
}

static struct pkcs15_pubkey *p15_decode_new_pubkey(int algo, uint8_t *data, int len)
{
	struct pkcs15_pubkey *pubkey = p15_new_pubkey();
	if (!pubkey) return NULL;

	pubkey->algorithm = algo;
	pubkey->data.value = data;
	pubkey->data.len = len;

	if (pkcs15_decode_pubkey(pubkey, data, len)) {
		pkcs15_free_pubkey(pubkey);
		return NULL;
	}
	return pubkey;
}

static struct pkcs15_pubkey *p15_new_pubkey(void)
{
	struct pkcs15_pubkey *c = malloc(sizeof (struct pkcs15_pubkey));
	if (!c) return NULL;
	memset(c, 0, sizeof (struct pkcs15_pubkey));
	return c;
}

void pkcs15_free_pubkey(struct pkcs15_pubkey *key)
{
	pkcs15_erase_pubkey(key);
	free(key);
}

void pkcs15_free_pubkey_info(struct pkcs15_pubkey_info *key)
{
	if (key->subject)
		free(key->subject);
	free(key);
}

void *p15_pubkey_info_attr(void *data, uint8_t type)
{
	struct pkcs15_pubkey_info *info = (struct pkcs15_pubkey_info *)data;
	if (!info)
		return NULL;
	switch (type) {
	case P15_INFO_ATTR_PATH:
		return &info->path;
	default:
		return NULL;
	}
}
