#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"
#include "p15_obj.h"

typedef struct _p15_read_trans {

	struct p15_card *card;

	p15_trans_t *trans;
	p15_trans_cb cb;	/* cb(trans) when finish operations */

	/* param */
	uint8_t **buf;
	size_t *buflen;
	struct icc_file **out_file;

	/* self, NOTE free */
	int ret;
	int alloced;
	int rec_nr;		/* read record */
	uint16_t rd_off;	/* read offset */
	struct icc_path *path;
	struct icc_file *file;	/* to **out_file */

	int self_free;
	uint8_t *data;		/* to **buf */
	uint8_t *head;
	int datalen;
	int actual;		/* actual file length(recv) */

	stm_instance_t *fsmi;

} p15_read_trans;

static void __read_record_cb(p15_read_trans *t, int ret);
static void __read_binary_cb(p15_read_trans *t, int ret);

static void p15_read_raise_start(p15_read_trans *s);
static void p15_read_raise_rs(p15_read_trans *t);
static void p15_read_raise_rf(p15_read_trans *t);

static void p15_read_raise_sf(p15_read_trans *t);
static void p15_read_raise_ss(p15_read_trans *t);

static void p15_read_raise_event(p15_read_trans *t, int event);

static p15_read_trans *p15_build_read_trans(p15_trans_cb cb, p15_trans_t *trans, 
					    uint8_t **buf, size_t *buflen,
					    struct icc_file **out, struct icc_path *in_path)
{
	p15_read_trans *t = malloc(sizeof (p15_read_trans));
	if (!t) return NULL;
	memset(t, 0, sizeof (p15_read_trans));

	t->buf = buf;
	t->buflen = buflen;
	t->cb = cb;
	t->trans = trans;
	t->out_file = out;
	t->path = icc_path_dup(in_path);
	
	/* from 1~N */
	t->rec_nr = 1;

	t->self_free = 1;
	return t;
}

static void p15_destroy_read_trans(p15_read_trans *t)
{
	if (t->path) free(t->path);
	if (t->self_free == 1) {
		if (t->data)
			free(t->data);
		if (t->file)
			icc_file_free(t->file);
	}
	if (t->fsmi) {
		eloop_delete_automaton(t->fsmi);
		t->fsmi = NULL;
	}

	free(t);
}

static void p15_read_trans_free(void *eloop, void *user)
{
	p15_read_trans *t = (p15_read_trans *)user;

	eloop_cancel_timeout(NULL, p15_read_trans_free, NULL, t);
	p15_destroy_read_trans(t);
}

static int __read_alloc(p15_read_trans *trans)
{
	struct icc_file *file = trans->file;
	struct icc_path *path = trans->path;
	size_t len, offset;
	uint8_t *data;

	if (path->count <= 0) {
		len = file->size;
		offset = 0;
	} else {
		len = path->count;
		offset = path->idx;
		if (offset >= file->size ||
		    offset + len > file->size)
			return PKCS15_ERR_INVALID_ASN1_OBJ;
	}

	data = (uint8_t *) malloc(len);
	if (!data)
		return PKCS15_ERR_NO_MEM;

	memset(data, 0, len);
	trans->head = trans->data = data;
	trans->datalen = len;
	trans->rd_off = offset;

	trans->alloced = 1;
	return 0;
}

/* ============================================================ *
 * read TRANS stm
 * ============================================================ */
static void p15_read_stm_log(const stm_instance_t *fsmi,
			     int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

#define P15_READ_STATE_INIT		0
#define P15_READ_STATE_SELECT		1
#define P15_READ_STATE_READ		2
#define P15_READ_STATE_EXIT		3

#define P15_READ_STATE_COUNT		4

#define P15_READ_STATE_NAMES {		\
	"init",				\
	"select",			\
	"read",				\
	"exit",				\
}

#define P15_READ_EVENT_START		0
#define P15_READ_EVENT_SS		1	/* Select Success */
#define P15_READ_EVENT_SF		2	/* Select Failure */
#define P15_READ_EVENT_RS		3	/* Read Success */
#define P15_READ_EVENT_RF		4	/* Read Failure */
#define P15_READ_EVENT_RSW		5	/* Read Struct Wrong - update */
#define P15_READ_EVENT_RLW		6	/* Read Length Wrong - update */

#define P15_READ_EVENT_COUNT		7

#define P15_READ_EVENT_NAMES {		\
	"START",			\
	"SS",				\
	"SF",				\
	"RS",				\
	"RF",				\
	"RSW",				\
	"RLW",				\
}

#define STATE(state)			P15_READ_STATE_##state
#define EVENT(event)			P15_READ_EVENT_##event
#define ACTION(stem)			\
	p15_read_act_##stem,sizeof(p15_read_act_##stem)/sizeof(stm_action_fn)

static const char *p15_read_state_names[] = P15_READ_STATE_NAMES;
static const char *p15_read_event_names[] = P15_READ_EVENT_NAMES;

static int p15_read_action_null(stm_instance_t *fsmi, void *insti)
{
	return 1;
}

static void __select_cb(void *data, int ret)
{
	p15_read_trans *t = (p15_read_trans *)data;
	if (ret < 0)
		p15_read_raise_sf(t);
	else {
		p15_read_raise_ss(t);
	}
}

static int p15_read_action_select(stm_instance_t *fsmi, void *insti)
{
	p15_read_trans *t = (p15_read_trans *)insti;
	struct p15_card *card = t->card;
	int r;

	r = pcsc_select_file(card->slot, t->path, &t->file, __select_cb, t);
	if (r) {
		t->ret = -1;
		p15_read_raise_sf(t);
	}
	return 1;
}

static void __read_cb(void *data, int ret)
{
	p15_read_trans *t = (p15_read_trans *)data;
	struct icc_file *file = t->file;

	/* support update when: wrong length, wrong ins */
	if (file->ef_structure == ICC_FILE_EF_LINEAR_VARIABLE_TLV) {
		__read_record_cb(t, ret);
	} else {
		__read_binary_cb(t, ret);
	}
}

static void __read_record_cb(p15_read_trans *t, int ret)
{
	int l, record_len;
	struct p15_card *card = t->card;
	uint8_t *head = t->head;
	uint8_t *data = t->data;
	int dlen = t->datalen;
	int r = ret;
	
	if (r < 0) {
		/* finish EOF */
		if (r == ICC_ERR_RECORD_NOT_FOUND)
			r = 0;
		goto out;
	}

	if (r < 2) {
		r = 0;
		goto out;
	}

	record_len = head[1];
	if (record_len != 0xff) {
		memmove(head,head+2,r-2);
		head += (r-2);
		t->actual += (r-2);
	} else {
		if (r < 4) {
			r = -1;
			goto out;
		}
		record_len = head[2] * 256 + head[3];
		memmove(head,head+4,r-4);
		head += (r-4);
		t->actual += (r-4);
	}
	l = dlen - (head - data);
	if (l > 256) { l = 256; }

	/* go on */
	pcsc_read_record(card->slot, t->rec_nr++, t->head, l,
			 ICC_RECORD_BY_REC_NR, __read_cb, t);
	return;
out:
	if (r == 0)
		p15_read_raise_rs(t);
	else
		p15_read_raise_rf(t);
}

static int __read_record(p15_read_trans *t)
{
	struct p15_card *card = t->card;

	int l, dlen = t->datalen;

	l = dlen - (t->head - t->data);
	if (l > 256) { l = 256; }

	return pcsc_read_record(card->slot, t->rec_nr++, t->head, l,
				ICC_RECORD_BY_REC_NR,
				__read_cb, t);
}

static void __read_binary_cb(p15_read_trans *t, int ret)
{
	if (ret >= 0) {
		t->actual = ret;
		p15_read_raise_rs(t);
	}
	else {
		/* TODO: watchdata will not return FCI in select_file cmd,
		 * so we cannot get the true file type, in that case, we may 
		 * loop all file type and try again, but its not well.
		 */
		p15_read_raise_rf(t);

	}
}

static int __read_binary(p15_read_trans *t)
{	
	return pcsc_read_binary(t->card->slot, t->rd_off, t->data, t->datalen, 0,
				__read_cb, t);
}

static int p15_read_by_type(p15_read_trans *t)
{
	struct icc_file *file = t->file;

	if (t->alloced == 0) {
		if (__read_alloc(t))
			return 1;
	}
	if (file->ef_structure == ICC_FILE_EF_LINEAR_VARIABLE_TLV) {
		return __read_record(t);
	} else {
		return __read_binary(t);
	}
}

static int p15_read_action_read(stm_instance_t *fsmi, void *insti)
{
	p15_read_trans *t = (p15_read_trans *)insti;

	if (p15_read_by_type(t))
		p15_read_raise_rf(t);
	return 1;
}

static int p15_read_action_etc(stm_instance_t *fsmi, void *insti)
{
	p15_read_trans *t = (p15_read_trans *)insti;

	if (t->cb) {
		t->trans->ret = t->ret;
		if (t->ret >= 0) {
			if (t->buf && t->data) {
				*t->buf = t->data;
				*t->buflen = t->actual;
				t->self_free = 0;
			}
			if (t->out_file && t->file) {
				*t->out_file = t->file;
				t->self_free = 0;				
			}
		}
		t->cb(t->trans);
		t->cb = NULL;
	}
	eloop_register_timeout(NULL, 0, 0, p15_read_trans_free, NULL, t);

	return 1;
}

static int p15_read_action_us(stm_instance_t *fsmi, void *insti)
{
	return 0;
}

static int p15_read_action_ul(stm_instance_t *fsmi, void *insti)
{
	return 0;
}

static const stm_action_fn p15_read_act_null[] = {
	p15_read_action_null,
};

static const stm_action_fn p15_read_act_select[] = {
	p15_read_action_select,
};

static const stm_action_fn p15_read_act_read[] = {
	p15_read_action_read,
};

static const stm_action_fn p15_read_act_etc[] = {
	p15_read_action_etc,
};

static const stm_action_fn p15_read_act_us_read[] = {
	p15_read_action_us,
	p15_read_action_read,
};

static const stm_action_fn p15_read_act_ul_read[] = {
	p15_read_action_ul,
	p15_read_action_read,
};

static const stm_entry_t p15_read_trans_entries[] = {
	/* state	event		action		new state */
	{ STATE(INIT),	EVENT(START),	ACTION(select),	STATE(SELECT) },
		
	{ STATE(SELECT),EVENT(SS),	ACTION(read),	STATE(READ) },
	{ STATE(SELECT),EVENT(SF),	ACTION(etc),	STATE(EXIT) },
	
	{ STATE(READ),	EVENT(RS),	ACTION(etc),	STATE(EXIT) },
	{ STATE(READ),	EVENT(RF),	ACTION(etc),	STATE(EXIT) },
	{ STATE(READ),	EVENT(RSW),	ACTION(us_read),STATE(READ) },
	{ STATE(READ),	EVENT(RLW),	ACTION(ul_read),STATE(READ) },
	
	{ 0,		0,		NULL,		0 }
};

const stm_table_t p15_read_trans_table = {
	"P15_READ",
	p15_read_stm_log,
	P15_READ_STATE_COUNT,
	&p15_read_state_names[0],
	P15_READ_EVENT_COUNT, 
	&p15_read_event_names[0],
	p15_read_trans_entries,
};

static void p15_read_raise_ss(p15_read_trans *t)
{
	p15_read_raise_event(t, P15_READ_EVENT_SS);
}

static void p15_read_raise_sf(p15_read_trans *t)
{
	p15_read_raise_event(t, P15_READ_EVENT_SF);
}

static void p15_read_raise_start(p15_read_trans *t)
{
	p15_read_raise_event(t, P15_READ_EVENT_START);
}

static void p15_read_raise_rs(p15_read_trans *t)
{
	p15_read_raise_event(t, P15_READ_EVENT_RS);
}

static void p15_read_raise_rf(p15_read_trans *t)
{
	p15_read_raise_event(t, P15_READ_EVENT_RS);
}

/* post an event */
static void p15_read_raise_event(p15_read_trans *t, int event)
{
	eloop_schedule_event(NULL, t->fsmi, event, t);
}

#undef STATE
#undef EVENT
#undef ACTION


/* PKCS#15 common read operations */
int pkcs15_read_file(struct p15_card *p15card, struct icc_path *in_path,
		     uint8_t **buf, size_t *buflen, struct icc_file **file_out,
		     p15_trans_cb cb, p15_trans_t *trans)
{
	p15_read_trans *t;

	assert(p15card != NULL && in_path != NULL && buf != NULL);

	t = p15_build_read_trans(cb, trans, buf, buflen, file_out, in_path);
	if (!t)
		return -1;

	t->fsmi = eloop_create_automaton(&p15_read_trans_table,
					 "P15_READ",
					 P15_READ_STATE_INIT);
	t->card = p15card;

	if (!t->fsmi)
		goto out;

	p15_read_raise_start(t);
	return 0;
out:
	/* do not call cb(trans) when select fail at here */
	p15_destroy_read_trans(t);
	return -1;
}
