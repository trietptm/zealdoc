#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

#include "p15_obj.h"


static int pkcs15_encode_prkey(struct pkcs15_prkey *prkey, uint8_t **out, size_t *out_len);
static int pkcs15_decode_prkey(struct pkcs15_prkey *key,
			const uint8_t *buf, size_t len);

static int pkcs15_encode_prkey_dsa(struct pkcs15_prkey_dsa *key,
				   uint8_t **buf, size_t *buflen);
static int pkcs15_decode_prkey_dsa(struct pkcs15_prkey_dsa *key,
				   const uint8_t *buf, size_t buflen);
static struct pkcs15_prkey *
p15_decode_new_prkey(int algo, uint8_t *data, int len);
static struct pkcs15_prkey *p15_new_prkey(void);

static const struct pkcs15_asn1_entry c_asn1_com_key_attr[] = {
	{ "iD",		 PKCS15_ASN1_PKCS15_ID, PKCS15_ASN1_TAG_OCTET_STRING, 0, NULL, NULL },
	{ "usage",	 PKCS15_ASN1_BIT_FIELD, PKCS15_ASN1_TAG_BIT_STRING, 0, NULL, NULL },
	{ "native",	 PKCS15_ASN1_BOOLEAN, PKCS15_ASN1_TAG_BOOLEAN, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "accessFlags", PKCS15_ASN1_BIT_FIELD, PKCS15_ASN1_TAG_BIT_STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "keyReference",PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_com_prkey_attr[] = {
        /* FIXME */
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_rsakey_attr[] = {
	{ "value",	   PKCS15_ASN1_PATH, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "modulusLength", PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, 0, NULL, NULL },
	{ "keyInfo",	   PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_prk_rsa_attr[] = {
	{ "privateRSAKeyAttributes", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_dsakey_i_p_attr[] = {
	{ "path",	PKCS15_ASN1_PATH, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_dsakey_value_attr[] = {
	{ "path",	PKCS15_ASN1_PATH, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "pathProtected",PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 1 | PKCS15_ASN1_CONS, 0, NULL, NULL},
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_dsakey_attr[] = {
	{ "value",	PKCS15_ASN1_CHOICE, 0, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_prk_dsa_attr[] = {
	{ "privateDSAKeyAttributes", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_prkey[] = {
	{ "privateRSAKey", PKCS15_ASN1_PKCS15_OBJECT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "privateDSAKey", PKCS15_ASN1_PKCS15_OBJECT,  2 | PKCS15_ASN1_CTX | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};		

int pkcs15_decode_prkdf_entry(struct p15_card *p15card,
			      struct pkcs15_object *obj,
			      const uint8_t ** buf, size_t *buflen)
{
        struct pkcs15_prkey_info info;
	int r;
	size_t usage_len = sizeof(info.usage);
	size_t af_len = sizeof(info.access_flags);
	struct pkcs15_asn1_entry asn1_com_key_attr[6], asn1_com_prkey_attr[1];
	struct pkcs15_asn1_entry asn1_rsakey_attr[4], asn1_prk_rsa_attr[2];
	struct pkcs15_asn1_entry asn1_dsakey_attr[2], asn1_prk_dsa_attr[2],
			asn1_dsakey_i_p_attr[2],
			asn1_dsakey_value_attr[3];
	struct pkcs15_asn1_entry asn1_prkey[3];
	struct asn1_pkcs15_object rsa_prkey_obj = { obj, asn1_com_key_attr,
						       asn1_com_prkey_attr, asn1_prk_rsa_attr };
	struct asn1_pkcs15_object dsa_prkey_obj = { obj, asn1_com_key_attr,
						       asn1_com_prkey_attr, asn1_prk_dsa_attr };

        pkcs15_copy_asn1_entry(c_asn1_prkey, asn1_prkey);

        pkcs15_copy_asn1_entry(c_asn1_prk_rsa_attr, asn1_prk_rsa_attr);
        pkcs15_copy_asn1_entry(c_asn1_rsakey_attr, asn1_rsakey_attr);
        pkcs15_copy_asn1_entry(c_asn1_prk_dsa_attr, asn1_prk_dsa_attr);
        pkcs15_copy_asn1_entry(c_asn1_dsakey_attr, asn1_dsakey_attr);
	pkcs15_copy_asn1_entry(c_asn1_dsakey_value_attr, asn1_dsakey_value_attr);
	pkcs15_copy_asn1_entry(c_asn1_dsakey_i_p_attr,
					asn1_dsakey_i_p_attr);

        pkcs15_copy_asn1_entry(c_asn1_com_prkey_attr, asn1_com_prkey_attr);
        pkcs15_copy_asn1_entry(c_asn1_com_key_attr, asn1_com_key_attr);

	pkcs15_format_asn1_entry(asn1_prkey + 0, &rsa_prkey_obj, NULL, 0);
	pkcs15_format_asn1_entry(asn1_prkey + 1, &dsa_prkey_obj, NULL, 0);

	pkcs15_format_asn1_entry(asn1_prk_rsa_attr + 0, asn1_rsakey_attr, NULL, 0);
	pkcs15_format_asn1_entry(asn1_prk_dsa_attr + 0, asn1_dsakey_attr, NULL, 0);

	pkcs15_format_asn1_entry(asn1_rsakey_attr + 0, &info.path, NULL, 0);
	pkcs15_format_asn1_entry(asn1_rsakey_attr + 1, &info.modulus_length, NULL, 0);

	pkcs15_format_asn1_entry(asn1_dsakey_attr + 0, asn1_dsakey_value_attr, NULL, 0);
	pkcs15_format_asn1_entry(asn1_dsakey_value_attr + 0, &info.path, NULL, 0);
	pkcs15_format_asn1_entry(asn1_dsakey_value_attr + 1, asn1_dsakey_i_p_attr, NULL, 0);
	pkcs15_format_asn1_entry(asn1_dsakey_i_p_attr + 0, &info.path, NULL, 0);


	pkcs15_format_asn1_entry(asn1_com_key_attr + 0, &info.id, NULL, 0);
	pkcs15_format_asn1_entry(asn1_com_key_attr + 1, &info.usage, &usage_len, 0);
	pkcs15_format_asn1_entry(asn1_com_key_attr + 2, &info.native, NULL, 0);
	pkcs15_format_asn1_entry(asn1_com_key_attr + 3, &info.access_flags, &af_len, 0);
	pkcs15_format_asn1_entry(asn1_com_key_attr + 4, &info.key_ref, NULL, 0);

        /* Fill in defaults */
        memset(&info, 0, sizeof(info));
	info.key_ref = -1;
	info.native = 1;

	r = pkcs15_asn1_decode_choice(asn1_prkey, *buf, *buflen, buf, buflen);
	if (r == PKCS15_ERR_ASN1_END_OF_CONTENTS)
		return r;
	if (r < 0) {
		p15_log(P15_LOG_ERR, "ASN.1 decoding failed");
		return r;
	}

	if (asn1_prkey[0].flags & PKCS15_ASN1_PRESENT) {
		obj->type = PKCS15_TYPE_PRKEY_RSA;
	} else if (asn1_prkey[1].flags & PKCS15_ASN1_PRESENT) {
		obj->type = PKCS15_TYPE_PRKEY_DSA;
		/* If the value was indirect-protected, mark the path */
		if (asn1_dsakey_i_p_attr[0].flags & PKCS15_ASN1_PRESENT)
			info.path.type = ICC_PATH_TYPE_PATH_PROT;
	} else {
		p15_log(P15_LOG_ERR, "Neither RSA or DSA key in PrKDF entry.\n");
		return PKCS15_ERR_INVALID_ASN1_OBJ;
	}
	r = icc_make_absolute_path(&p15card->app_root->path, &info.path);
	if (r < 0)
		return r;
	obj->data = malloc(sizeof(info));
	if (obj->data == NULL)
		return PKCS15_ERR_NO_MEM;

	memcpy(obj->data, &info, sizeof(info));

	return 0;
}

int pkcs15_encode_prkdf_entry(const struct pkcs15_object *obj,
			      uint8_t **buf, size_t *buflen)
{
	struct pkcs15_asn1_entry asn1_com_key_attr[6], asn1_com_prkey_attr[1];
	struct pkcs15_asn1_entry asn1_rsakey_attr[4], asn1_prk_rsa_attr[2];
	struct pkcs15_asn1_entry asn1_dsakey_attr[2], asn1_prk_dsa_attr[2],
			asn1_dsakey_value_attr[3],
			asn1_dsakey_i_p_attr[2];
	struct pkcs15_asn1_entry asn1_prkey[3];
	struct asn1_pkcs15_object rsa_prkey_obj = { (struct pkcs15_object *) obj, asn1_com_key_attr,
						       asn1_com_prkey_attr, asn1_prk_rsa_attr };
	struct asn1_pkcs15_object dsa_prkey_obj = { (struct pkcs15_object *) obj, asn1_com_key_attr,
						       asn1_com_prkey_attr, asn1_prk_dsa_attr };
	struct pkcs15_prkey_info *prkey =
                (struct pkcs15_prkey_info *) obj->data;
	int r;
	size_t af_len, usage_len;

        pkcs15_copy_asn1_entry(c_asn1_prkey, asn1_prkey);

        pkcs15_copy_asn1_entry(c_asn1_prk_rsa_attr, asn1_prk_rsa_attr);
        pkcs15_copy_asn1_entry(c_asn1_rsakey_attr, asn1_rsakey_attr);
        pkcs15_copy_asn1_entry(c_asn1_prk_dsa_attr, asn1_prk_dsa_attr);
        pkcs15_copy_asn1_entry(c_asn1_dsakey_attr, asn1_dsakey_attr);
	pkcs15_copy_asn1_entry(c_asn1_dsakey_value_attr, asn1_dsakey_value_attr);
	pkcs15_copy_asn1_entry(c_asn1_dsakey_i_p_attr, asn1_dsakey_i_p_attr);

        pkcs15_copy_asn1_entry(c_asn1_com_prkey_attr, asn1_com_prkey_attr);
        pkcs15_copy_asn1_entry(c_asn1_com_key_attr, asn1_com_key_attr);

	switch (obj->type) {
	case PKCS15_TYPE_PRKEY_RSA:
		pkcs15_format_asn1_entry(asn1_prkey + 0, &rsa_prkey_obj, NULL, 1);
		pkcs15_format_asn1_entry(asn1_prk_rsa_attr + 0, asn1_rsakey_attr, NULL, 1);
		pkcs15_format_asn1_entry(asn1_rsakey_attr + 0, &prkey->path, NULL, 1);
		pkcs15_format_asn1_entry(asn1_rsakey_attr + 1, &prkey->modulus_length, NULL, 1);
		break;
	case PKCS15_TYPE_PRKEY_DSA:
		pkcs15_format_asn1_entry(asn1_prkey + 1, &dsa_prkey_obj, NULL, 1);
		pkcs15_format_asn1_entry(asn1_prk_dsa_attr + 0, asn1_dsakey_value_attr, NULL, 1);
		if (prkey->path.type != ICC_PATH_TYPE_PATH_PROT) {
			/* indirect: just add the path */
			pkcs15_format_asn1_entry(asn1_dsakey_value_attr + 0,
					&prkey->path, NULL, 1);
		} else {
			/* indirect-protected */
			pkcs15_format_asn1_entry(asn1_dsakey_value_attr + 1,
					asn1_dsakey_i_p_attr, NULL, 1);
			pkcs15_format_asn1_entry(asn1_dsakey_i_p_attr + 0,
					&prkey->path, NULL, 1);
		}
                break;
	default:
		p15_log(P15_LOG_ERR, "Invalid private key type: %X", obj->type);
		return PKCS15_ERR_OTHER;
		break;
	}
	pkcs15_format_asn1_entry(asn1_com_key_attr + 0, &prkey->id, NULL, 1);
	usage_len = sizeof(prkey->usage);
	pkcs15_format_asn1_entry(asn1_com_key_attr + 1, &prkey->usage, &usage_len, 1);
	if (prkey->native == 0)
		pkcs15_format_asn1_entry(asn1_com_key_attr + 2, &prkey->native, NULL, 1);
	if (prkey->access_flags) {
		af_len = sizeof(prkey->access_flags);
		pkcs15_format_asn1_entry(asn1_com_key_attr + 3, &prkey->access_flags, &af_len, 1);
	}
	if (prkey->key_ref >= 0)
		pkcs15_format_asn1_entry(asn1_com_key_attr + 4, &prkey->key_ref, NULL, 1);
	r = pkcs15_asn1_encode(asn1_prkey, buf, buflen);

	return r;
}

/*
 * Store private keys on the card, encrypted
 */
static const struct pkcs15_asn1_entry	c_asn1_dsa_prkey_obj[] = {
	{ "privateKey", PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_ALLOC, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static int pkcs15_encode_prkey_dsa(struct pkcs15_prkey_dsa *key,
				   uint8_t **buf, size_t *buflen)
{
	struct pkcs15_asn1_entry	asn1_dsa_prkey_obj[2];

	pkcs15_copy_asn1_entry(c_asn1_dsa_prkey_obj, asn1_dsa_prkey_obj);
	pkcs15_format_asn1_entry(asn1_dsa_prkey_obj + 0,
			key->priv.data, &key->priv.len, 1);

	return pkcs15_asn1_encode(asn1_dsa_prkey_obj, buf, buflen);
}

static int pkcs15_decode_prkey_dsa(struct pkcs15_prkey_dsa *key,
				   const uint8_t *buf, size_t buflen)
{
	struct pkcs15_asn1_entry	asn1_dsa_prkey_obj[2];

	pkcs15_copy_asn1_entry(c_asn1_dsa_prkey_obj, asn1_dsa_prkey_obj);
	pkcs15_format_asn1_entry(asn1_dsa_prkey_obj + 0,
			&key->priv.data, &key->priv.len, 0);

	return pkcs15_asn1_decode(asn1_dsa_prkey_obj, buf, buflen, NULL, NULL);
}

static int pkcs15_encode_prkey(struct pkcs15_prkey *key,
			uint8_t **buf, size_t *len)
{
	if (key->algorithm == ICC_ALGORITHM_DSA)
		return pkcs15_encode_prkey_dsa(&key->u.dsa, buf, len);
	p15_log(P15_LOG_ERR, "Cannot encode private key type %u.",
			key->algorithm);
	return PKCS15_ERR_NOT_SUPPORTED;
}

static int pkcs15_decode_prkey(struct pkcs15_prkey *key,
			const uint8_t *buf, size_t len)
{
	if (key->algorithm == ICC_ALGORITHM_DSA)
		return pkcs15_decode_prkey_dsa(&key->u.dsa, buf, len);
	p15_log(P15_LOG_ERR, "Cannot decode private key type %u.",
			key->algorithm);
	return PKCS15_ERR_NOT_SUPPORTED;
}

static void __read_prkey_cb(p15_trans_t *trans)
{
	int ret = trans->ret;
	struct pkcs15_prkey *pkey = NULL;

	if (ret >= 0) {
		pkey = p15_decode_new_prkey(trans->u.priv_i,
					    trans->buf,
					    trans->actual);
		if (!pkey) {
			trans->ret = PKCS15_ERR_INVALID_ASN1_OBJ;
			goto fail;
		}
		*trans->out_pp = pkey;
		trans->self_free = 0;
		goto succ;
	}
fail:
	/* FIXME: need free? */
	if (pkey) free(pkey);
succ:
	if (trans->cb) trans->cb(trans->cb_arg, trans->ret);
	p15_destroy_trans(trans);
	return;
}

int pkcs15_read_prkey(struct p15_card *p15card, struct pkcs15_object *obj,
		      const char *passphrase, struct pkcs15_prkey **ppout,
		      p15_user_cb cb, void *cbarg)
{
	struct pkcs15_prkey_info *info;
	int algorithm;
	struct icc_path path;
	int r;
	p15_trans_t *trans;

	switch (obj->type) {
	case PKCS15_TYPE_PRKEY_RSA:
		algorithm = ICC_ALGORITHM_RSA;
		break;
	case PKCS15_TYPE_PRKEY_DSA:
		algorithm = ICC_ALGORITHM_DSA;
		break;
	default:
		p15_log(P15_LOG_ERR, "Unsupported object type");
		return PKCS15_ERR_NOT_SUPPORTED;
	}
	info = (struct pkcs15_prkey_info *) obj->data;
	if (info->native) {
		p15_log(P15_LOG_ERR, "Private key is native, will not read");
		return PKCS15_ERR_NOT_SUPPORTED;
	}

	path = info->path;
	if (path.type == ICC_PATH_TYPE_PATH_PROT)
		path.type = ICC_PATH_TYPE_PATH;

	trans = p15_build_trans(cb, cbarg, NULL, (void **)ppout);

	if (!trans)
		return -1;
	
	trans->u.priv_i = algorithm;
	
	r = pkcs15_read_file(p15card, &path, &trans->buf, &trans->actual, NULL,
			     __read_prkey_cb, trans);
	if (r < 0) {
		p15_log(P15_LOG_ERR, "Unable to read private key file");
		cb(trans->cb_arg, -1);
		p15_destroy_trans(trans);
	}
	return r;

#ifdef TODO

	/* Is this a protected file? */
	if (info->path.type == ICC_PATH_TYPE_PATH_PROT) {
		uint8_t *clear;
		size_t clear_len;

		if (passphrase == NULL) {
			r = PKCS15_ERR_OTHER;
			goto fail;
		}
		r = sc_pkcs15_unwrap_data(ctx,
				passphrase,
				data, len,
				&clear, &clear_len);
		r = -1;
		if (r < 0)  {
			p15_log(P15_LOG_ERR, "Failed to unwrap privat key.");
			goto fail;
		}
		free(data);
		data = clear;
		len = clear_len;
	}
#endif
}

void pkcs15_erase_prkey(struct pkcs15_prkey *key)
{
	assert(key != NULL);
	switch (key->algorithm) {
	case ICC_ALGORITHM_RSA:
		free(key->u.rsa.modulus.data);
		free(key->u.rsa.exponent.data);
		free(key->u.rsa.p.data);
		free(key->u.rsa.q.data);
		free(key->u.rsa.iqmp.data);
		free(key->u.rsa.dmp1.data);
		free(key->u.rsa.dmq1.data);
		break;
	case ICC_ALGORITHM_DSA:
		free(key->u.dsa.pub.data);
		free(key->u.dsa.p.data);
		free(key->u.dsa.q.data);
		free(key->u.dsa.g.data);
		free(key->u.dsa.priv.data);
		break;
	}
	icc_mem_clear(key, sizeof(key));
}

static struct pkcs15_prkey *p15_decode_new_prkey(int algo, uint8_t *data, int len)
{
	struct pkcs15_prkey *prkey = p15_new_prkey();
	if (!prkey) return NULL;

	prkey->algorithm = algo;

	if (pkcs15_decode_prkey(prkey, data, len)) {
		pkcs15_free_prkey(prkey);
		return NULL;
	}
	return prkey;
}

static struct pkcs15_prkey *p15_new_prkey(void)
{
	struct pkcs15_prkey *c = malloc(sizeof (struct pkcs15_prkey));
	if (!c) return NULL;
	memset(c, 0, sizeof (struct pkcs15_prkey));
	return c;
}

void pkcs15_free_prkey(struct pkcs15_prkey *key)
{
	pkcs15_erase_prkey(key);
	free(key);
}

void pkcs15_free_prkey_info(struct pkcs15_prkey_info *key)
{
	if (key->subject)
		free(key->subject);
	free(key);
}
