#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

#include "p15_obj.h"

/*
 * pkcs15-pin.c: PKCS #15 PIN functions
 */

static const struct pkcs15_asn1_entry c_asn1_com_ao_attr[] = {
	{ "authId",       PKCS15_ASN1_PKCS15_ID, PKCS15_ASN1_TAG_OCTET_STRING, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_pin_attr[] = {
	{ "pinFlags",	  PKCS15_ASN1_BIT_FIELD, PKCS15_ASN1_TAG_BIT_STRING, 0, NULL, NULL },
	{ "pinType",      PKCS15_ASN1_ENUMERATED, PKCS15_ASN1_TAG_ENUMERATED, 0, NULL, NULL },
	{ "minLength",    PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, 0, NULL, NULL },
	{ "storedLength", PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, 0, NULL, NULL },
	{ "maxLength",    PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "pinReference", PKCS15_ASN1_INTEGER, PKCS15_ASN1_CTX | 0, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "padChar",      PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_OCTET_STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "lastPinChange",PKCS15_ASN1_GENERALIZEDTIME, PKCS15_ASN1_TAG_GENERALIZEDTIME, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "path",         PKCS15_ASN1_PATH, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_type_pin_attr[] = {
	{ "pinAttributes", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_pin[] = {
	{ "pin", PKCS15_ASN1_PKCS15_OBJECT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

#ifdef OPENPKCS15_PORTING

int sc_pkcs15_decode_aodf_entry(struct sc_pkcs15_card *p15card,
				struct sc_pkcs15_object *obj,
				const uint8_t ** buf, size_t *buflen)
{
	sc_context_t *ctx = p15card->card->ctx;
	struct sc_pkcs15_pin_info info;
	int r;
	size_t flags_len = sizeof(info.flags);
	size_t padchar_len = 1;
	struct pkcs15_asn1_entry asn1_com_ao_attr[2], asn1_pin_attr[10], asn1_type_pin_attr[2];
	struct pkcs15_asn1_entry asn1_pin[2];
	struct sc_asn1_pkcs15_object pin_obj = { obj, asn1_com_ao_attr, NULL, asn1_type_pin_attr };
	
	sc_copy_asn1_entry(c_asn1_pin, asn1_pin);
	sc_copy_asn1_entry(c_asn1_type_pin_attr, asn1_type_pin_attr);
	sc_copy_asn1_entry(c_asn1_pin_attr, asn1_pin_attr);
	sc_copy_asn1_entry(c_asn1_com_ao_attr, asn1_com_ao_attr);

	sc_format_asn1_entry(asn1_pin + 0, &pin_obj, NULL, 0);

	sc_format_asn1_entry(asn1_type_pin_attr + 0, asn1_pin_attr, NULL, 0);

	sc_format_asn1_entry(asn1_pin_attr + 0, &info.flags, &flags_len, 0);
	sc_format_asn1_entry(asn1_pin_attr + 1, &info.type, NULL, 0);
	sc_format_asn1_entry(asn1_pin_attr + 2, &info.min_length, NULL, 0);
	sc_format_asn1_entry(asn1_pin_attr + 3, &info.stored_length, NULL, 0);
	sc_format_asn1_entry(asn1_pin_attr + 4, &info.max_length, NULL, 0);
	sc_format_asn1_entry(asn1_pin_attr + 5, &info.reference, NULL, 0);
	sc_format_asn1_entry(asn1_pin_attr + 6, &info.pad_char, &padchar_len, 0);
	/* We don't support lastPinChange yet. */
	sc_format_asn1_entry(asn1_pin_attr + 8, &info.path, NULL, 0);

	sc_format_asn1_entry(asn1_com_ao_attr + 0, &info.auth_id, NULL, 0);

	/* Fill in defaults */
	memset(&info, 0, sizeof(info));
	info.reference = 0;
	info.tries_left = -1;

	r = sc_asn1_decode(ctx, asn1_pin, *buf, *buflen, buf, buflen);
	if (r == PKCS15_ERROR_ASN1_END_OF_CONTENTS)
		return r;
	PKCS15_TEST_RET(ctx, r, "ASN.1 decoding failed");
	info.magic = PKCS15_PKCS15_PIN_MAGIC;
	obj->type = PKCS15_PKCS15_TYPE_AUTH_PIN;
	obj->data = malloc(sizeof(info));
	if (obj->data == NULL)
		PKCS15_FUNC_RETURN(ctx, 0, PKCS15_ERROR_OUT_OF_MEMORY);
	if (info.max_length == 0) {
		if (p15card->card->max_pin_len != 0)
			info.max_length = p15card->card->max_pin_len;
		else if (info.stored_length != 0)
			info.max_length = info.type != PKCS15_PKCS15_PIN_TYPE_BCD ?
				info.stored_length : 2 * info.stored_length;
		else
			info.max_length = 8; /* shouldn't happen */
	}
	memcpy(obj->data, &info, sizeof(info));

	return 0;
}

int sc_pkcs15_encode_aodf_entry(sc_context_t *ctx,
				 const struct sc_pkcs15_object *obj,
				 uint8_t **buf, size_t *buflen)
{
	struct pkcs15_asn1_entry asn1_com_ao_attr[2], asn1_pin_attr[10], asn1_type_pin_attr[2];
	struct pkcs15_asn1_entry asn1_pin[2];
	struct sc_pkcs15_pin_info *pin =
                (struct sc_pkcs15_pin_info *) obj->data;
	struct sc_asn1_pkcs15_object pin_obj = { (struct sc_pkcs15_object *) obj,
						 asn1_com_ao_attr, NULL, asn1_type_pin_attr };
	int r;
	size_t flags_len;
	size_t padchar_len = 1;

	sc_copy_asn1_entry(c_asn1_pin, asn1_pin);
        sc_copy_asn1_entry(c_asn1_type_pin_attr, asn1_type_pin_attr);
        sc_copy_asn1_entry(c_asn1_pin_attr, asn1_pin_attr);
        sc_copy_asn1_entry(c_asn1_com_ao_attr, asn1_com_ao_attr);

	sc_format_asn1_entry(asn1_pin + 0, &pin_obj, NULL, 1);

	sc_format_asn1_entry(asn1_type_pin_attr + 0, asn1_pin_attr, NULL, 1);

	flags_len = sizeof(pin->flags);
	sc_format_asn1_entry(asn1_pin_attr + 0, &pin->flags, &flags_len, 1);
	sc_format_asn1_entry(asn1_pin_attr + 1, &pin->type, NULL, 1);
	sc_format_asn1_entry(asn1_pin_attr + 2, &pin->min_length, NULL, 1);
	sc_format_asn1_entry(asn1_pin_attr + 3, &pin->stored_length, NULL, 1);
	if (pin->max_length > 0)
		sc_format_asn1_entry(asn1_pin_attr + 4, &pin->max_length, NULL, 1);
	if (pin->reference >= 0)
		sc_format_asn1_entry(asn1_pin_attr + 5, &pin->reference, NULL, 1);
	/* FIXME: check if pad_char present */
	sc_format_asn1_entry(asn1_pin_attr + 6, &pin->pad_char, &padchar_len, 1);
	sc_format_asn1_entry(asn1_pin_attr + 8, &pin->path, NULL, 1);

	sc_format_asn1_entry(asn1_com_ao_attr + 0, &pin->auth_id, NULL, 1);

	assert(pin->magic == PKCS15_PKCS15_PIN_MAGIC);
	r = sc_asn1_encode(ctx, asn1_pin, buf, buflen);

	return r;
}

static int _validate_pin(struct sc_pkcs15_card *p15card,
                         struct sc_pkcs15_pin_info *pin,
                         size_t pinlen)
{
	size_t max_length;
	assert(p15card != NULL);
	
	if (pin->magic != PKCS15_PKCS15_PIN_MAGIC)
		return PKCS15_ERROR_OBJECT_NOT_VALID;
		
	/* prevent buffer overflow from hostile card */	
	if (pin->stored_length > PKCS15_MAX_PIN_SIZE)
		return PKCS15_ERROR_BUFFER_TOO_SMALL;

	/* if we use pinpad, no more checks are needed */
	if (p15card->card->slot->capabilities & PKCS15_SLOT_CAP_PIN_PAD)
		return PKCS15_SUCCESS;
		
	/* If pin is given, make sure it is within limits */
	max_length = pin->max_length != 0 ? pin->max_length : PKCS15_MAX_PIN_SIZE;
	if (pinlen > max_length || pinlen < pin->min_length)
		return PKCS15_ERROR_INVALID_PIN_LENGTH;

	return PKCS15_SUCCESS;
}

/*
 * Verify a PIN.
 *
 * If the code given to us has zero length, this means we
 * should ask the card reader to obtain the PIN from the
 * reader's PIN pad
 */
int sc_pkcs15_verify_pin(struct sc_pkcs15_card *p15card,
			 struct sc_pkcs15_pin_info *pin,
			 const uint8_t *pincode, size_t pinlen)
{
	int r;
	sc_card_t *card;
	struct sc_pin_cmd_data data;

	if ((r = _validate_pin(p15card, pin, pinlen)) != PKCS15_SUCCESS)
		return r;

	card = p15card->card;
	r = sc_lock(card);
	PKCS15_TEST_RET(card->ctx, r, "sc_lock() failed");
	/* the path in the pin object is optional */
	if (pin->path.len > 0) {
		r = sc_select_file(card, &pin->path, NULL);
		if (r)
			goto out;
	}

	/* Initialize arguments */
	memset(&data, 0, sizeof(data));
	data.cmd = PKCS15_PIN_CMD_VERIFY;
	data.pin_type = PKCS15_AC_CHV;
	data.pin_reference = pin->reference;
	data.pin1.min_length = pin->min_length;
	data.pin1.max_length = pin->max_length;
	data.pin1.pad_length = pin->stored_length;
	data.pin1.pad_char = pin->pad_char;
	data.pin1.data = pincode;
	data.pin1.len = pinlen;

	if (pin->flags & PKCS15_PKCS15_PIN_FLAG_NEEDS_PADDING)
		data.flags |= PKCS15_PIN_CMD_NEED_PADDING;

	switch (pin->type) {
	case PKCS15_PKCS15_PIN_TYPE_BCD:
		data.pin1.encoding = PKCS15_PIN_ENCODING_BCD;
		break;
	case PKCS15_PKCS15_PIN_TYPE_ASCII_NUMERIC:
		data.pin1.encoding = PKCS15_PIN_ENCODING_ASCII;
		break;
	default:
		/* assume/hope the card driver knows how to encode the pin */
		data.pin1.encoding = 0;
	}

	if(p15card->card->slot->capabilities & PKCS15_SLOT_CAP_PIN_PAD) {
		data.flags |= PKCS15_PIN_CMD_USE_PINPAD;
		if (pin->flags & PKCS15_PKCS15_PIN_FLAG_SO_PIN)
			data.pin1.prompt = "Please enter SO PIN";
		else
			data.pin1.prompt = "Please enter PIN";
	}

	r = sc_pin_cmd(card, &data, &pin->tries_left);
out:
	sc_unlock(card);
	return r;
}

/*
 * Change a PIN.
 */
int sc_pkcs15_change_pin(struct sc_pkcs15_card *p15card,
			 struct sc_pkcs15_pin_info *pin,
			 const uint8_t *oldpin, size_t oldpinlen,
			 const uint8_t *newpin, size_t newpinlen)
{
	int r;
	sc_card_t *card;
	struct sc_pin_cmd_data data;
	
	/* make sure the pins are in valid range */
	if ((r = _validate_pin(p15card, pin, oldpinlen)) != PKCS15_SUCCESS)
		return r;
	if ((r = _validate_pin(p15card, pin, newpinlen)) != PKCS15_SUCCESS)
		return r;

	card = p15card->card;
	r = sc_lock(card);
	PKCS15_TEST_RET(card->ctx, r, "sc_lock() failed");
	/* the path in the pin object is optional */
	if (pin->path.len > 0) {
		r = sc_select_file(card, &pin->path, NULL);
		if (r)
			goto out;
	}

	/* set pin_cmd data */
	memset(&data, 0, sizeof(data));
	data.cmd             = PKCS15_PIN_CMD_CHANGE;
	data.pin_type        = PKCS15_AC_CHV;
	data.pin_reference   = pin->reference;
	data.pin1.data       = oldpin;
	data.pin1.len        = oldpinlen;
	data.pin1.pad_char   = pin->pad_char;
	data.pin1.min_length = pin->min_length;
	data.pin1.max_length = pin->max_length;
	data.pin1.pad_length = pin->stored_length;
	data.pin2.data       = newpin;
	data.pin2.len        = newpinlen;
	data.pin2.pad_char   = pin->pad_char;
	data.pin2.min_length = pin->min_length;
	data.pin2.max_length = pin->max_length;
	data.pin2.pad_length = pin->stored_length;

	if (pin->flags & PKCS15_PKCS15_PIN_FLAG_NEEDS_PADDING)
		data.flags |= PKCS15_PIN_CMD_NEED_PADDING;

	switch (pin->type) {
	case PKCS15_PKCS15_PIN_TYPE_BCD:
		data.pin1.encoding = PKCS15_PIN_ENCODING_BCD;
		data.pin2.encoding = PKCS15_PIN_ENCODING_BCD;
		break;
	case PKCS15_PKCS15_PIN_TYPE_ASCII_NUMERIC:
		data.pin1.encoding = PKCS15_PIN_ENCODING_ASCII;
		data.pin2.encoding = PKCS15_PIN_ENCODING_ASCII;
		break;
	}
	
	if(p15card->card->slot->capabilities & PKCS15_SLOT_CAP_PIN_PAD) {
		data.flags |= PKCS15_PIN_CMD_USE_PINPAD;
		if (pin->flags & PKCS15_PKCS15_PIN_FLAG_SO_PIN) {
			data.pin1.prompt = "Please enter SO PIN";
			data.pin2.prompt = "Please enter new SO PIN";
		} else {
			data.pin1.prompt = "Please enter PIN";
			data.pin2.prompt = "Please enter new PIN";
		}
	}

	r = sc_pin_cmd(card, &data, &pin->tries_left);

out:
	sc_unlock(card);
	return r;
}

/*
 * Unblock a PIN.
 */
int sc_pkcs15_unblock_pin(struct sc_pkcs15_card *p15card,
			 struct sc_pkcs15_pin_info *pin,
			 const uint8_t *puk, size_t puklen,
			 const uint8_t *newpin, size_t newpinlen)
{
	int r;
	sc_card_t *card;
	struct sc_pin_cmd_data data;
	struct sc_pkcs15_object *pin_obj, *puk_obj;
	struct sc_pkcs15_pin_info *puk_info = NULL;

	/* make sure the pins are in valid range */
	if ((r = _validate_pin(p15card, pin, newpinlen)) != PKCS15_SUCCESS)
		return r;

	card = p15card->card;
	/* get pin_info object of the puk (this is a little bit complicated
	 * as we don't have the id of the puk (at least now))
	 * note: for compatibility reasons we give no error if no puk object
	 * is found */
	/* first step:  get the pkcs15 object of the pin */
	r = sc_pkcs15_find_pin_by_auth_id(p15card, &pin->auth_id, &pin_obj);
	if (r >= 0 && pin_obj) {
		/* second step: try to get the pkcs15 object of the puk */
		r = sc_pkcs15_find_pin_by_auth_id(p15card, &pin_obj->auth_id, &puk_obj);
		if (r >= 0 && puk_obj) {
			/* third step:  get the pkcs15 info object of the puk */
			puk_info = (struct sc_pkcs15_pin_info *)puk_obj->data;
		}
	}
	if (!puk_info) {
		sc_debug(card->ctx, "Unable to get puk object, using pin object instead!\n");
		puk_info = pin;
	}
	
	/* make sure the puk is in valid range */
	if ((r = _validate_pin(p15card, puk_info, puklen)) != PKCS15_SUCCESS)
		return r;

	r = sc_lock(card);
	PKCS15_TEST_RET(card->ctx, r, "sc_lock() failed");
	/* the path in the pin object is optional */
	if (pin->path.len > 0) {
		r = sc_select_file(card, &pin->path, NULL);
		if (r)
			goto out;
	}

	/* set pin_cmd data */
	memset(&data, 0, sizeof(data));
	data.cmd             = PKCS15_PIN_CMD_UNBLOCK;
	data.pin_type        = PKCS15_AC_CHV;
	data.pin_reference   = pin->reference;
	data.pin1.data       = puk;
	data.pin1.len        = puklen;
	data.pin1.pad_char   = pin->pad_char;
	data.pin1.min_length = pin->min_length;
	data.pin1.max_length = pin->max_length;
	data.pin1.pad_length = pin->stored_length;
	data.pin2.data       = newpin;
	data.pin2.len        = newpinlen;
	data.pin2.pad_char   = puk_info->pad_char;
	data.pin2.min_length = puk_info->min_length;
	data.pin2.max_length = puk_info->max_length;
	data.pin2.pad_length = puk_info->stored_length;

	if (pin->flags & PKCS15_PKCS15_PIN_FLAG_NEEDS_PADDING)
		data.flags |= PKCS15_PIN_CMD_NEED_PADDING;

	switch (pin->type) {
	case PKCS15_PKCS15_PIN_TYPE_BCD:
		data.pin1.encoding = PKCS15_PIN_ENCODING_BCD;
		break;
	case PKCS15_PKCS15_PIN_TYPE_ASCII_NUMERIC:
		data.pin1.encoding = PKCS15_PIN_ENCODING_ASCII;
		break;
	}

	switch (puk_info->type) {
	case PKCS15_PKCS15_PIN_TYPE_BCD:
		data.pin2.encoding = PKCS15_PIN_ENCODING_BCD;
		break;
	case PKCS15_PKCS15_PIN_TYPE_ASCII_NUMERIC:
		data.pin2.encoding = PKCS15_PIN_ENCODING_ASCII;
		break;
	}
	
	if(p15card->card->slot->capabilities & PKCS15_SLOT_CAP_PIN_PAD) {
		data.flags |= PKCS15_PIN_CMD_USE_PINPAD;
		if (pin->flags & PKCS15_PKCS15_PIN_FLAG_SO_PIN) {
			data.pin1.prompt = "Please enter PUK";
			data.pin2.prompt = "Please enter new SO PIN";
		} else {
			data.pin1.prompt = "Please enter PUK";
			data.pin2.prompt = "Please enter new PIN";
		}
	}

	r = sc_pin_cmd(card, &data, &pin->tries_left);

out:
	sc_unlock(card);
	return r;
}

void sc_pkcs15_free_pin_info(sc_pkcs15_pin_info_t *pin)
{
	free(pin);
}

#endif