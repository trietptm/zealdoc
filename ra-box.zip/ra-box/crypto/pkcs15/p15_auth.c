#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

#include "p15_obj.h"

/*
 * pkcs15-pin.c: PKCS #15 PIN functions
 */
#define PROMPT_EN_PUK		"Please enter PUK"
#define PROMPT_EN_PIN		"Please enter PIN"
#define PROMPT_EN_NEW_PIN	"Please enter new PIN"
#define PROMPT_EN_SO_PIN	"Please enter SO PIN"
#define PROMPT_EN_NEW_SO_PIN	"Please enter new SO PIN"

typedef struct _p15_pin_trans {

	uint8_t			type;
	struct p15_card		*card;
	
	void			*cbarg;
	p15_user_cb		cb;	/* cb(trans) when finish operations */

	struct pkcs15_pin_info  *pin_info;
	struct pkcs15_pin_info  *puk_info;
	const uint8_t		*oldpin;	/* in verify this keep the 'pin', unlock keep 'puk' */
	const uint8_t		*newpin;
	size_t			opinlen;
	size_t			npinlen;

	int			ll_stm_closed;	/* unlock use a little stm */
	struct icc_pin_cmd_data data;

	/* self, NOTE free */
	int			self_free;
	struct pkcs15_object	*pin_obj, *puk_obj;
	stm_instance_t		*fsmi;
} p15_pin_trans;

static void __pin_fmt_verify(p15_pin_trans *trans);
static void __pin_fmt_change(p15_pin_trans *trans);
static void __pin_fmt_unlock(p15_pin_trans *trans);

static void p15_pin_trans_free(void *, void *);
static void p15_destroy_pin_trans(p15_pin_trans *t);
static p15_pin_trans *p15_build_pin_trans(uint8_t type, p15_user_cb cb, void *cbarg,
					  struct pkcs15_pin_info *,
					  const uint8_t *opin, size_t oplen,
					  const uint8_t *npin, size_t nplen);


static void p15_pin_raise_event(p15_pin_trans *t, int e);
static void p15_pin_raise_start(p15_pin_trans *t);
static void p15_pin_raise_cs(p15_pin_trans *t);
static void p15_pin_raise_cf(p15_pin_trans *t);
static void p15_pin_raise_sf(p15_pin_trans *t);
static void p15_pin_raise_ss(p15_pin_trans *t);

static const struct pkcs15_asn1_entry c_asn1_com_ao_attr[] = {
	{ "authId",       PKCS15_ASN1_PKCS15_ID, PKCS15_ASN1_TAG_OCTET_STRING, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_pin_attr[] = {
	{ "pinFlags",	  PKCS15_ASN1_BIT_FIELD, PKCS15_ASN1_TAG_BIT_STRING, 0, NULL, NULL },
	{ "pinType",      PKCS15_ASN1_ENUMERATED, PKCS15_ASN1_TAG_ENUMERATED, 0, NULL, NULL },
	{ "minLength",    PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, 0, NULL, NULL },
	{ "storedLength", PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, 0, NULL, NULL },
	{ "maxLength",    PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "pinReference", PKCS15_ASN1_INTEGER, PKCS15_ASN1_CTX | 0, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "padChar",      PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_OCTET_STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "lastPinChange",PKCS15_ASN1_GENERALIZEDTIME, PKCS15_ASN1_TAG_GENERALIZEDTIME, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "path",         PKCS15_ASN1_PATH, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_type_pin_attr[] = {
	{ "pinAttributes", PKCS15_ASN1_STRUCT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_pin[] = {
	{ "pin", PKCS15_ASN1_PKCS15_OBJECT, PKCS15_ASN1_TAG_SEQUENCE | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

int pkcs15_decode_aodf_entry(struct p15_card *p15card, struct pkcs15_object *obj,
			     const uint8_t **buf, size_t *buflen)
{
	struct pkcs15_pin_info info;
	int r;
	size_t flags_len = sizeof(info.flags);
	size_t padchar_len = 1;
	struct pkcs15_asn1_entry asn1_com_ao_attr[2], asn1_pin_attr[10], asn1_type_pin_attr[2];
	struct pkcs15_asn1_entry asn1_pin[2];
	struct asn1_pkcs15_object pin_obj = { obj, asn1_com_ao_attr, NULL, asn1_type_pin_attr };
	
	pkcs15_copy_asn1_entry(c_asn1_pin, asn1_pin);
	pkcs15_copy_asn1_entry(c_asn1_type_pin_attr, asn1_type_pin_attr);
	pkcs15_copy_asn1_entry(c_asn1_pin_attr, asn1_pin_attr);
	pkcs15_copy_asn1_entry(c_asn1_com_ao_attr, asn1_com_ao_attr);

	pkcs15_format_asn1_entry(asn1_pin + 0, &pin_obj, NULL, 0);

	pkcs15_format_asn1_entry(asn1_type_pin_attr + 0, asn1_pin_attr, NULL, 0);

	pkcs15_format_asn1_entry(asn1_pin_attr + 0, &info.flags, &flags_len, 0);
	pkcs15_format_asn1_entry(asn1_pin_attr + 1, &info.type, NULL, 0);
	pkcs15_format_asn1_entry(asn1_pin_attr + 2, &info.min_length, NULL, 0);
	pkcs15_format_asn1_entry(asn1_pin_attr + 3, &info.stored_length, NULL, 0);
	pkcs15_format_asn1_entry(asn1_pin_attr + 4, &info.max_length, NULL, 0);
	pkcs15_format_asn1_entry(asn1_pin_attr + 5, &info.reference, NULL, 0);
	pkcs15_format_asn1_entry(asn1_pin_attr + 6, &info.pad_char, &padchar_len, 0);
	/* We don't support lastPinChange yet. */
	pkcs15_format_asn1_entry(asn1_pin_attr + 8, &info.path, NULL, 0);

	pkcs15_format_asn1_entry(asn1_com_ao_attr + 0, &info.auth_id, NULL, 0);

	/* Fill in defaults */
	memset(&info, 0, sizeof(info));
	info.reference = 0;
	info.tries_left = -1;

	r = pkcs15_asn1_decode(asn1_pin, *buf, *buflen, buf, buflen);
	if (r == PKCS15_ERR_ASN1_END_OF_CONTENTS)
		return r;
	if (r < 0) {
		p15_log(P15_LOG_ERR, "ASN.1 decoding failed");
		return r;
	}

	obj->type = PKCS15_TYPE_AUTH_PIN;
	obj->data = malloc(sizeof(info));
	if (obj->data == NULL)
		return	PKCS15_ERR_NO_MEM;

	if (info.max_length == 0) {
		/* TODO: configure
		if (p15card->card->max_pin_len != 0)
			info.max_length = p15card->card->max_pin_len;
		else */if (info.stored_length != 0)
			info.max_length = info.type != P15_PIN_TYPE_BCD ?
				info.stored_length : 2 * info.stored_length;
		else
			info.max_length = 8; /* shouldn't happen */
	}
	memcpy(obj->data, &info, sizeof(info));

	return 0;
}

int pkcs15_encode_aodf_entry(const struct pkcs15_object *obj,
			     uint8_t **buf, size_t *bufsize)
{
	struct pkcs15_asn1_entry 
				asn1_com_ao_attr[2],
				asn1_pin_attr[10],
				asn1_type_pin_attr[2];
	struct pkcs15_asn1_entry asn1_pin[2];
	struct pkcs15_pin_info *pin = (struct pkcs15_pin_info *) obj->data;
	struct asn1_pkcs15_object pin_obj = { (struct pkcs15_object *) obj,
						 asn1_com_ao_attr, NULL, asn1_type_pin_attr };
	int r;
	size_t flags_len;
	size_t padchar_len = 1;

	pkcs15_copy_asn1_entry(c_asn1_pin, asn1_pin);
        pkcs15_copy_asn1_entry(c_asn1_type_pin_attr, asn1_type_pin_attr);
        pkcs15_copy_asn1_entry(c_asn1_pin_attr, asn1_pin_attr);
        pkcs15_copy_asn1_entry(c_asn1_com_ao_attr, asn1_com_ao_attr);

	pkcs15_format_asn1_entry(asn1_pin + 0, &pin_obj, NULL, 1);

	pkcs15_format_asn1_entry(asn1_type_pin_attr + 0, asn1_pin_attr, NULL, 1);

	flags_len = sizeof(pin->flags);
	pkcs15_format_asn1_entry(asn1_pin_attr + 0, &pin->flags, &flags_len, 1);
	pkcs15_format_asn1_entry(asn1_pin_attr + 1, &pin->type, NULL, 1);
	pkcs15_format_asn1_entry(asn1_pin_attr + 2, &pin->min_length, NULL, 1);
	pkcs15_format_asn1_entry(asn1_pin_attr + 3, &pin->stored_length, NULL, 1);
	if (pin->max_length > 0)
		pkcs15_format_asn1_entry(asn1_pin_attr + 4, &pin->max_length, NULL, 1);
	if (pin->reference >= 0)
		pkcs15_format_asn1_entry(asn1_pin_attr + 5, &pin->reference, NULL, 1);
	/* FIXME: check if pad_char present */
	pkcs15_format_asn1_entry(asn1_pin_attr + 6, &pin->pad_char, &padchar_len, 1);
	pkcs15_format_asn1_entry(asn1_pin_attr + 8, &pin->path, NULL, 1);

	pkcs15_format_asn1_entry(asn1_com_ao_attr + 0, &pin->auth_id, NULL, 1);

	r = pkcs15_asn1_encode(asn1_pin, buf, bufsize);

	return r;
}

static int _validate_pin(struct p15_card *p15card,
                         struct pkcs15_pin_info *pin,
                         size_t pinlen)
{
	size_t max_length;
			
	/* prevent buffer overflow from hostile card */	
	if (pin->stored_length > ICC_PIN_SIZE_MAX)
		return PKCS15_ERR_INSUF_BUFFER;

	/* if we use pinpad, no more checks are needed */
	if (pcsc_slot_cap(p15card->slot) & PCSC_SLOT_CAP_PIN_PAD)
		return PKCS15_SUCCESS;

	/* If pin is given, make sure it is within limits */
	max_length = pin->max_length != 0 ? pin->max_length : ICC_PIN_SIZE_MAX;
	if (pinlen > max_length || pinlen < pin->min_length)
		return PKCS15_ERR_INVALID_PIN_LENGTH;

	return PKCS15_SUCCESS;
}

void pkcs15_free_pin_info(struct pkcs15_pin_info *pin)
{
	free(pin);
}

void *p15_auth_info_attr(void *data, uint8_t type)
{
	struct pkcs15_pin_info *info = (struct pkcs15_pin_info *)data;
	if (!info)
		return NULL;
	switch (type) {
	case P15_INFO_ATTR_PATH:
		return &info->path;
	default:
		return NULL;
	}
}
/* ============================================================ *
 * pin TRANS stm
 * ============================================================ */

static void __select_cb(void *data, int ret)
{
	p15_pin_trans *t = (p15_pin_trans *)data;
	if (ret < 0)
		p15_pin_raise_sf(t);
	else {
		p15_pin_raise_ss(t);
	}
}

static int p15_pin_action_select(stm_instance_t *fsmi, void *insti)
{
	p15_pin_trans *t = (p15_pin_trans *)insti;
	struct p15_card *card = t->card;
	int r;

	/* the path in the pin object is optional */
	if (t->pin_info->path.len <= 0) {
		/* need not select */
		p15_pin_raise_ss(t);
		goto out;
	}

	r = pcsc_select_file(card->slot, &t->pin_info->path, NULL, __select_cb, t);
	if (r) {
		p15_pin_raise_sf(t);
	}
out:
	return 1;
}

static int p15_pin_action_fmt(stm_instance_t *fsmi, void *insti)
{
	p15_pin_trans *t = (p15_pin_trans *)insti;
	
	switch (t->type) {
	case ICC_PIN_CMD_VERIFY:
		__pin_fmt_verify(t);
		break;
	case ICC_PIN_CMD_CHANGE:
		__pin_fmt_change(t);
		break;
	case ICC_PIN_CMD_UNLOCK:
		__pin_fmt_unlock(t);
		break;
	default:
		p15_log(P15_LOG_ERR, "PIN: unknown cmd type");
		return 0;
	}
	return 1;
}

static void __pin_cmd_cb(void *data, int ret)
{
	p15_pin_trans *t = (p15_pin_trans *)data;
	if (ret < 0)
		p15_pin_raise_cf(t);
	else {
		p15_pin_raise_cs(t);
	}
}

static int p15_pin_action_cmd(stm_instance_t *fsmi, void *insti)
{
	int r;
	p15_pin_trans *t = (p15_pin_trans *)insti;
	
	r = pcsc_pin_cmd(t->card->slot, &t->data, &t->pin_info->tries_left,
			 __pin_cmd_cb, t);

	if (r)
		p15_pin_raise_cf(t);
	return 1;
}

static int p15_pin_action_etc(stm_instance_t *fsmi, void *insti)
{
	p15_pin_trans *t = (p15_pin_trans *)insti;

	if (t->cb) {
		t->cb(t->cbarg, -1);
		t->cb = NULL;
	}
	eloop_register_timeout(NULL, 0, 0, p15_pin_trans_free, NULL, t);
	return 1;
}

static void p15_pin_stm_log(const stm_instance_t *fsmi,
			     int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

#define P15_PIN_STATE_INIT		0
#define P15_PIN_STATE_SELECT		1
#define P15_PIN_STATE_CMD		2
#define P15_PIN_STATE_EXIT		3

#define P15_PIN_STATE_COUNT		4

#define P15_PIN_STATE_NAMES {		\
	"init",				\
	"select",			\
	"cmd",				\
	"exit",				\
}

#define P15_PIN_EVENT_START		0
#define P15_PIN_EVENT_SS		1	/* Select Success */
#define P15_PIN_EVENT_SF		2	/* Select Failure */
#define P15_PIN_EVENT_CS		3	/* Cmd Success */
#define P15_PIN_EVENT_CF		4	/* Cmd Failure */

#define P15_PIN_EVENT_COUNT		5

#define P15_PIN_EVENT_NAMES {		\
	"START",			\
	"SS",				\
	"SF",				\
	"CS",				\
	"CF",				\
}

#define STATE(state)			P15_PIN_STATE_##state
#define EVENT(event)			P15_PIN_EVENT_##event
#define ACTION(stem)			\
	p15_pin_act_##stem,sizeof(p15_pin_act_##stem)/sizeof(stm_action_fn)

static const char *p15_pin_state_names[] = P15_PIN_STATE_NAMES;
static const char *p15_pin_event_names[] = P15_PIN_EVENT_NAMES;

static int p15_pin_action_null(stm_instance_t *fsmi, void *insti)
{
	return 1;
}

static const stm_action_fn p15_pin_act_null[] = {
	p15_pin_action_null,
};

static const stm_action_fn p15_pin_act_select[] = {
	p15_pin_action_select,
};

static const stm_action_fn p15_pin_act_fmt_cmd[] = {
	p15_pin_action_fmt,
	p15_pin_action_cmd,
};

static const stm_action_fn p15_pin_act_etc[] = {
	p15_pin_action_etc,
};

static const stm_entry_t p15_pin_trans_entries[] = {
	/* state	event		action		new state */
	{ STATE(INIT),	EVENT(START),	ACTION(select),	STATE(SELECT) },
		
	{ STATE(SELECT),EVENT(SS),	ACTION(fmt_cmd),STATE(CMD) },
	{ STATE(SELECT),EVENT(SF),	ACTION(etc),	STATE(EXIT) },
	
	{ STATE(CMD),	EVENT(CS),	ACTION(etc),	STATE(EXIT) },
	{ STATE(CMD),	EVENT(CF),	ACTION(etc),	STATE(EXIT) },
	
	{ 0,		0,		NULL,		0 }
};

const stm_table_t p15_pin_trans_table = {
	"P15_PIN",
	p15_pin_stm_log,
	P15_PIN_STATE_COUNT,
	&p15_pin_state_names[0],
	P15_PIN_EVENT_COUNT, 
	&p15_pin_event_names[0],
	p15_pin_trans_entries,
};

static void p15_pin_raise_ss(p15_pin_trans *t)
{
	p15_pin_raise_event(t, P15_PIN_EVENT_SS);
}

static void p15_pin_raise_sf(p15_pin_trans *t)
{
	p15_pin_raise_event(t, P15_PIN_EVENT_SF);
}

static void p15_pin_raise_start(p15_pin_trans *t)
{
	p15_pin_raise_event(t, P15_PIN_EVENT_START);
}

static void p15_pin_raise_cs(p15_pin_trans *t)
{
	p15_pin_raise_event(t, P15_PIN_EVENT_CS);
}

static void p15_pin_raise_cf(p15_pin_trans *t)
{
	p15_pin_raise_event(t, P15_PIN_EVENT_CF);
}

/* post an event */
static void p15_pin_raise_event(p15_pin_trans *t, int event)
{
	eloop_schedule_event(NULL, t->fsmi, event, t);
}

#undef STATE
#undef EVENT
#undef ACTION

static p15_pin_trans *p15_build_pin_trans(uint8_t type, p15_user_cb cb, void *cbarg,
					  struct pkcs15_pin_info *pin_info,
					  const uint8_t *opin, size_t oplen,
					  const uint8_t *npin, size_t nplen)
{
	p15_pin_trans *t = malloc(sizeof (p15_pin_trans));
	if (!t) return NULL;
	memset(t, 0, sizeof (p15_pin_trans));
	memset(&t->data, 0, sizeof(t->data));

	t->type = type;

	t->cb = cb;
	t->cbarg = cbarg;

	t->pin_info = pin_info;

	t->oldpin = opin;
	t->opinlen = oplen;

	t->newpin = npin;
	t->npinlen = nplen;
	
	t->self_free = 1;
	return t;
}

static void p15_destroy_pin_trans(p15_pin_trans *t)
{
	if (t->self_free == 1) {
	}
	if (t->fsmi) {
		eloop_delete_automaton(t->fsmi);
		t->fsmi = NULL;
	}
	if (t->pin_obj) pkcs15_free_obj(t->pin_obj);
	if (t->puk_obj) pkcs15_free_obj(t->puk_obj);
	free(t);
}

static void p15_pin_trans_free(void *eloop, void *user)
{
	p15_pin_trans *t = (p15_pin_trans *)user;

	eloop_cancel_timeout(NULL, p15_pin_trans_free, NULL, t);
	p15_destroy_pin_trans(t);
}
/*
 * Verify a PIN.
 *
 * If the code given to us has zero length, this means we
 * should ask the card reader to obtain the PIN from the
 * reader's PIN pad
 */
int pkcs15_verify_pin(struct p15_card *p15card, 
		      struct pkcs15_pin_info *pin_info,
		      const uint8_t *pin, size_t pinlen, 
		      p15_user_cb cb, void *cbarg)
{
	int r;
	pcsc_slot_t *slot;
	p15_pin_trans *pin_trans;

	if ((r = _validate_pin(p15card, pin_info, pinlen)) != PKCS15_SUCCESS)
		return r;

	slot = p15card->slot;
	pin_trans = p15_build_pin_trans(ICC_PIN_CMD_VERIFY, cb, cbarg,
					pin_info, pin, pinlen, NULL, 0);
	if (!pin_trans)
		return -1;

	pin_trans->card = p15card;
	pin_trans->fsmi = eloop_create_automaton(&p15_pin_trans_table,
						 "P15_PIN_VE",
						 P15_PIN_STATE_INIT);
	if (!pin_trans->fsmi)
		goto out;

	p15_pin_raise_start(pin_trans);
	return 0;
out:
	p15_destroy_pin_trans(pin_trans);
	return -1;
}

/*
 * Change a PIN.
 */
int pkcs15_change_pin(struct p15_card *p15card, struct pkcs15_pin_info *pin_info,
		      const uint8_t *oldpin, size_t oldpinlen,
		      const uint8_t *newpin, size_t newpinlen,
		      p15_user_cb cb, void *cbarg)
{
	int r;
	pcsc_slot_t *slot;
	p15_pin_trans *pin_trans;

	/* make sure the pins are in valid range */
	if ((r = _validate_pin(p15card, pin_info, oldpinlen)) != PKCS15_SUCCESS)
		return r;
	if ((r = _validate_pin(p15card, pin_info, newpinlen)) != PKCS15_SUCCESS)
		return r;

	slot = p15card->slot;
	pin_trans = p15_build_pin_trans(ICC_PIN_CMD_CHANGE, cb, cbarg,
					pin_info, oldpin, oldpinlen,
					newpin, newpinlen);
	if (!pin_trans)
		return -1;

	pin_trans->card = p15card;
	pin_trans->fsmi = eloop_create_automaton(&p15_pin_trans_table,
						 "P15_PIN_CH",
						 P15_PIN_STATE_INIT);
	if (!pin_trans->fsmi)
		goto out;

	p15_pin_raise_start(pin_trans);
	return 0;
out:
	p15_destroy_pin_trans(pin_trans);
	return -1;
}

static void __unblock_pin_cb(void *data, int ret)
{
	p15_pin_trans *pin_trans = (p15_pin_trans *)data;
	int r;

	if (ret < 0)
		goto err;

	if (pin_trans->ll_stm_closed == 0 && pin_trans->pin_obj) {
		/* only into here once */
		pin_trans->ll_stm_closed = 1;
		if (!pin_trans->puk_info) {
			/* second step: try to get the pkcs15 object of the puk */
			pkcs15_find_pin_by_auth_id(pin_trans->card, 
					           &pin_trans->pin_obj->auth_id,
						   &pin_trans->puk_obj, __unblock_pin_cb, pin_trans);
		}
		goto out;
	} else {
		pin_trans->ll_stm_closed = 1;
		if (!pin_trans->puk_info) {
			p15_log(P15_LOG_INFO, "Unable to get puk object, using pin object instead!\n");
			pin_trans->puk_info = pin_trans->pin_info;
		} else {
			/* third step:  get the pkcs15 info object of the puk */
			pin_trans->puk_info = (struct pkcs15_pin_info *)pin_trans->puk_obj->data;
		}
	}
	if ((r = _validate_pin(pin_trans->card, pin_trans->puk_info, pin_trans->opinlen)) != PKCS15_SUCCESS)
		goto err;

	/* start the second stm */
	p15_pin_raise_start(pin_trans);
out:
	return;
err:
	p15_destroy_pin_trans(pin_trans);
	return;
}

int pkcs15_unblock_pin(struct p15_card *p15card, struct pkcs15_pin_info *pin_info,
		       const uint8_t *puk, size_t puklen,
		       const uint8_t *newpin, size_t newpinlen,
		       p15_user_cb cb, void *cbarg)
{
	int r;
	p15_pin_trans *pin_trans;

	/* make sure the pins are in valid range */
	if ((r = _validate_pin(p15card, pin_info, newpinlen)) != PKCS15_SUCCESS)
		return r;

	pin_trans = p15_build_pin_trans(ICC_PIN_CMD_UNLOCK, cb, cbarg,
					pin_info, puk, puklen,
					newpin, newpinlen);

	pin_trans->card = p15card;
	pin_trans->fsmi = eloop_create_automaton(&p15_pin_trans_table,
						 "P15_PIN_UN",
						 P15_PIN_STATE_INIT);
	if (!pin_trans->fsmi)
		goto out;

	/* get pin_info object of the puk (this is a little bit complicated
	 * as we don't have the id of the puk (at least now))
	 * note: for compatibility reasons we give no error if no puk object
	 * is found */

	/* first step:  get the pkcs15 object of the pin */
	r = pkcs15_find_pin_by_auth_id(p15card, &pin_info->auth_id, &pin_trans->pin_obj,
				       __unblock_pin_cb, pin_trans);

	if (r < 0)
		goto out;
	/* start the little stm first. */
	pin_trans->ll_stm_closed = 0;

	return 0;
out:
	p15_destroy_pin_trans(pin_trans);
	return -1;
}

static void __pin_fmt_verify(p15_pin_trans *trans)
{
	struct icc_pin_cmd_data *data = &trans->data;
	struct pkcs15_pin_info *pin_info = trans->pin_info;
	const uint8_t *pin = trans->oldpin;
	size_t pinlen = trans->opinlen;

	data->cmd = ICC_PIN_CMD_VERIFY;
	data->pin_type = ICC_AC_CHV;

	data->pin_ref = pin_info->reference;
	data->pin1.max_len = pin_info->min_length;
	data->pin1.max_len = pin_info->max_length;
	data->pin1.pad_len = pin_info->stored_length;
	data->pin1.pad_char = pin_info->pad_char;
	data->pin1.data = pin;
	data->pin1.len = pinlen;

	if (pin_info->flags & P15_PIN_FLAG_NEEDS_PADDING)
		data->flags |= P15_PIN_CMD_NEED_PADDING;

	switch (pin_info->type) {
	case P15_PIN_TYPE_BCD:
		data->pin1.encode_type = ICC_PIN_ENCODING_BCD;
		break;
	case P15_PIN_TYPE_ASCII_NUMERIC:
		data->pin1.encode_type = ICC_PIN_ENCODING_ASCII;
		break;
	default:
		/* assume/hope the card driver knows how to encode the pin */
		data->pin1.encode_type = 0;
	}

	if (pcsc_slot_cap(trans->card->slot) & PCSC_SLOT_CAP_PIN_PAD) {
		data->flags |= P15_PIN_CMD_USE_PINPAD;
		if (pin_info->flags & P15_PIN_FLAG_SO_PIN)
			data->pin1.prompt = PROMPT_EN_SO_PIN;
		else
			data->pin1.prompt = PROMPT_EN_PIN;
	}
}

static void __pin_fmt_change(p15_pin_trans *trans)
{
	struct icc_pin_cmd_data *data = &trans->data;
	struct pkcs15_pin_info *pin_info = trans->pin_info;

	const uint8_t *newpin = trans->newpin;
	const uint8_t *oldpin = trans->oldpin;
	size_t newpinlen = trans->npinlen;
	size_t oldpinlen = trans->opinlen;

	data->cmd             = ICC_PIN_CMD_CHANGE;
	data->pin_type        = ICC_AC_CHV;
	data->pin_ref	      = pin_info->reference;
	data->pin1.data       = oldpin;
	data->pin1.len        = oldpinlen;
	data->pin1.pad_char   = pin_info->pad_char;
	data->pin1.min_len    = pin_info->min_length;
	data->pin1.max_len    = pin_info->max_length;
	data->pin1.pad_len    = pin_info->stored_length;

	data->pin2.data       = newpin;
	data->pin2.len        = newpinlen;
	data->pin2.pad_char   = pin_info->pad_char;
	data->pin2.min_len    = pin_info->min_length;
	data->pin2.max_len    = pin_info->max_length;
	data->pin2.pad_len    = pin_info->stored_length;

	if (pin_info->flags & P15_PIN_FLAG_NEEDS_PADDING)
		data->flags |= ICC_PIN_CMD_NEED_PADDING;

	switch (pin_info->type) {
	case P15_PIN_TYPE_BCD:
		data->pin1.encode_type = ICC_PIN_ENCODING_BCD;
		data->pin2.encode_type = ICC_PIN_ENCODING_BCD;
		break;
	case P15_PIN_TYPE_ASCII_NUMERIC:
		data->pin1.encode_type = ICC_PIN_ENCODING_ASCII;
		data->pin2.encode_type = ICC_PIN_ENCODING_ASCII;
		break;
	}
	
	if(pcsc_slot_cap(trans->card->slot) & PCSC_SLOT_CAP_PIN_PAD) {
		data->flags |= P15_PIN_CMD_USE_PINPAD;
		if (pin_info->flags & P15_PIN_FLAG_SO_PIN) {
			data->pin1.prompt = PROMPT_EN_SO_PIN;
			data->pin2.prompt = PROMPT_EN_NEW_SO_PIN;
		} else {
			data->pin1.prompt = PROMPT_EN_PIN;
			data->pin2.prompt = PROMPT_EN_NEW_PIN;
		}
	}
}

static void __pin_fmt_unlock(p15_pin_trans *trans)
{
	struct icc_pin_cmd_data *data = &trans->data;
	struct pkcs15_pin_info *pin_info = trans->pin_info;
	struct pkcs15_pin_info *puk_info = trans->puk_info;

	const uint8_t *newpin = trans->newpin;
	const uint8_t *oldpin = trans->oldpin;
	size_t newpinlen = trans->npinlen;
	size_t oldpinlen = trans->opinlen;

	data->cmd             = ICC_PIN_CMD_UNLOCK;
	data->pin_type        = ICC_AC_CHV;
	data->pin_ref	      = pin_info->reference;
	data->pin1.data       = oldpin;
	data->pin1.len        = oldpinlen;
	data->pin1.pad_char   = pin_info->pad_char;
	data->pin1.min_len    = pin_info->min_length;
	data->pin1.max_len    = pin_info->max_length;
	data->pin1.pad_len    = pin_info->stored_length;

	data->pin2.data       = newpin;
	data->pin2.len        = newpinlen;
	data->pin2.pad_char   = puk_info->pad_char;
	data->pin2.min_len    = puk_info->min_length;
	data->pin2.max_len    = puk_info->max_length;
	data->pin2.pad_len    = puk_info->stored_length;

	if (pin_info->flags & P15_PIN_FLAG_NEEDS_PADDING)
		data->flags |= ICC_PIN_CMD_NEED_PADDING;

	switch (pin_info->type) {
	case P15_PIN_TYPE_BCD:
		data->pin1.encode_type = ICC_PIN_ENCODING_BCD;
		break;
	case P15_PIN_TYPE_ASCII_NUMERIC:
		data->pin1.encode_type = ICC_PIN_ENCODING_ASCII;
		break;
	}

	switch (puk_info->type) {
	case P15_PIN_TYPE_BCD:
		data->pin2.encode_type = ICC_PIN_ENCODING_BCD;
		break;
	case P15_PIN_TYPE_ASCII_NUMERIC:
		data->pin2.encode_type = ICC_PIN_ENCODING_ASCII;
		break;
	}
	
	if(pcsc_slot_cap(trans->card->slot) & PCSC_SLOT_CAP_PIN_PAD) {
		data->flags |= P15_PIN_CMD_USE_PINPAD;
		if (pin_info->flags & P15_PIN_FLAG_SO_PIN) {
			data->pin1.prompt = PROMPT_EN_PUK;
			data->pin2.prompt = PROMPT_EN_NEW_SO_PIN;
		} else {
			data->pin1.prompt = PROMPT_EN_PUK;
			data->pin2.prompt = PROMPT_EN_NEW_PIN;
		}
	}
}
