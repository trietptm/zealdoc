#ifndef __PCSC_ICC_H__
#define __PCSC_ICC_H__

typedef struct _icc_driver_ops_t	icc_driver_ops_t;
typedef struct _icc_card_error_t	icc_card_error_t;
typedef struct _icc_driver_t		icc_driver_t;
typedef struct _pcsc_trans_param 	pcsc_icc_trans_param;

struct _icc_card_error_t {
	uint16_t SWs;
	int errorno;
	const char *errorstr;
};

struct icc_apdu {
	int cse;		/*apdu case*/
	uint8_t cla, ins, p1, p2;
	uint32_t lc, le;	/*1 or 3 bytes*/

	uint8_t *tx_buf;
	size_t tx_buflen;

	uint8_t *rx_buf;	/* user rx_buf, e.g read cmd */
	size_t rx_buflen;	/* if has rx_buf, store length that user expect */

	size_t actual_recv;	/* real rx length, useful in multi recv case */

	uint8_t sw1, sw2;
	unsigned long flags;
};

struct icc_atr_table {
	const char *name;

	const uint8_t *atr;
	const uint8_t *atr_mask;
	
	list_t link;
};



struct icc_algorithm_info {
	unsigned int algorithm;
	unsigned int key_length;
	unsigned int flags;

	union {
		struct icc_rsa_info {
			unsigned long exponent;
		} _rsa;
	} u;
};

struct _icc_driver_ops_t {
	/* ISO 7816 - 4 */
	int (*read_binary)(pcsc_slot_t *, uint32_t offset,
			   uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
			   pcsc_trans_cb callback, pcsc_transfer_t *card_param);

	int (*write_binary)(pcsc_slot_t *, uint32_t offset,
			    uint8_t *sbuf, size_t sbuf_len, uint32_t flags,
			    pcsc_trans_cb callback, pcsc_transfer_t *card_param);

	int (*update_binary)(pcsc_slot_t *, uint32_t offset,
			     uint8_t *sbuf, size_t sbuf_len, uint32_t flags,
			     pcsc_trans_cb callback, pcsc_transfer_t *card_param);

	int (*erase_binary)(void);

	int (*read_record)(pcsc_slot_t *cd, int rec_nr, 
			   uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		           pcsc_trans_cb callback, pcsc_transfer_t *card_param);

	int (*write_record)(pcsc_slot_t *, uint8_t rec_nr,
			    uint8_t *rec_buf, size_t rec_len, uint32_t flags,
			    pcsc_trans_cb callback, pcsc_transfer_t *card_param);

	int (*append_record)(pcsc_slot_t *,
		             uint8_t *rec_buf, size_t rec_len, uint32_t flags,
			     pcsc_trans_cb callback, pcsc_transfer_t *card_param);

	int (*update_record)(pcsc_slot_t *, uint8_t rec_nr,
		             uint8_t *rec_buf, size_t rec_len, uint32_t flags,
			     pcsc_trans_cb callback, pcsc_transfer_t *card_param);

	int (*get_data)(void);

	int (*put_data)(void);
	
	int (*select_file)(pcsc_slot_t *, struct icc_path *in_path,
			   struct icc_file **file_out, pcsc_trans_cb callback, 
			   pcsc_transfer_t *t);

	/* Protocol-T0 oriented */
	int (*get_response)(pcsc_transfer_t *card_param, uint8_t *resp,
			    size_t resp_len, uint32_t le);

	int (*envelope)(void);

	/* ISO 7816 - 8 */
	int (*pin_cmd)(pcsc_slot_t *, struct icc_pin_cmd_data *data, 
		       int *tries_left, pcsc_trans_cb callback, pcsc_transfer_t *t);

	int (*inter_auth)(void);

	int (*exter_auth)(pcsc_slot_t *, const uint8_t *key, size_t key_len,
			  int kid, pcsc_trans_cb cb, pcsc_transfer_t *);

	int (*get_challenge)(pcsc_slot_t *, uint8_t *rnd, size_t rnd_len,
			     pcsc_trans_cb callback, pcsc_transfer_t *);

	int (*manage_channel)(void);
	
	int (*computer_signature)(void);

	/* ISO 7816 - 9 */
	int (*create_file)(pcsc_slot_t *, struct icc_file *filp,
			   pcsc_trans_cb callback, pcsc_transfer_t *card_param);

	int (*delete_file)(pcsc_slot_t *, const struct icc_path *path,
			   pcsc_trans_cb callback, pcsc_transfer_t *card_param);

	int (*list_file)(void);

	int (*check_sw)(pcsc_icc_t *icc, uint8_t sw1, uint8_t sw2);

	int (*card_ctl)(void);

	int (*process_fci)(pcsc_slot_t *, struct icc_file *file_out,
			   const uint8_t *buf, size_t buf_len);

	int (*construct_fci)(pcsc_slot_t *card_handle, struct icc_file *filp,
			     uint8_t *fci_buf, size_t *fci_buflen);

	void *(*extension_op)(void);
};

struct _icc_driver_t {

	const char *name;

	uint32_t match_flags;
#define ICC_DRV_NO_MATCH	0x00	/* common, can it? */
#define	ICC_DRV_SYNC_MATCH	0x01	/* sync match */
#define ICC_DRV_ASYNC_MATCH	0x02	/* async match */
	/* muscle card will use async mode to match,
	 * watchdata card use sync match mode(just lookup id table)
	 */
	int (*match)(pcsc_icc_t *);
	int (*open)(pcsc_icc_t *);	/* call-chain */
	int (*close)(pcsc_icc_t *);	/* call-chain */
	/* function used after lowerup == 1 */
	icc_driver_ops_t *ops;
	void *priv;	/* driver private data */
	list_t link;
};

struct _pcsc_icc {

	uint16_t idx;
	uint8_t atr[PCSC_MAX_ATR];
	size_t atr_len;
	int proto;
	int proto_supported;
	icc_driver_t *drv;
	int lowerup;	/* 1 means can use this card's service */

	uint16_t status;

	/* from scard handle */
	struct icc_path curr_path;
	uint32_t active_proto;
	int flags;
	uint8_t cla;
	size_t max_send;
	size_t max_recv;

	atomic_t refcnt;
	list_t async_drvs;
	list_t link;
};

typedef struct _icc_atr_table {
	const char *name;
	const uint8_t *atr;
	const uint8_t *atr_mask;
} icc_atr_table;

const char *pcsc_card_status_str(uint32_t status);
int icc_match_atr(icc_atr_table *atr_table, const uint8_t *atr_bin,
			size_t atr_bin_len);

int pcsc_icc_up(pcsc_icc_t *);
void pcsc_icc_down(pcsc_icc_t *);

pcsc_icc_t *pcsc_icc_get(pcsc_icc_t *icc);
void pcsc_icc_put(pcsc_icc_t *icc);

/* handle call */
pcsc_icc_t *pcsc_icc_new(uint16_t idx);
void pcsc_icc_free(pcsc_icc_t *icc);

int icc_register_driver(icc_driver_t *);
void icc_unregister_driver(icc_driver_t *);

/* card driver */
int __init icc_wd_init(void);
void __exit icc_wd_exit(void);
int __init icc_muscle_init(void);
void __exit icc_muscle_exit(void);
int __init icc_iso7816_init(void);
void __exit icc_iso7816_exit(void);

void icc_up(pcsc_icc_t *);
void icc_down(pcsc_icc_t *);

/* ICC API */
void icc_async_matched(pcsc_icc_t *, const char *name, int match);
static inline void icc_bind_drv_priv(pcsc_icc_t *icc, void *priv)
{
	icc->drv->priv = priv;
}

static inline void icc_unbind_drv_priv(pcsc_icc_t *icc)
{
	icc->drv->priv = NULL;
}

static inline void *ICC_DRV_PRIV(pcsc_icc_t *icc)
{
	return icc->drv->priv;
}

static inline int ICC_RECV_MAX(pcsc_icc_t *icc)
{
	return icc->max_recv;
}

static inline int ICC_SEND_MAX(pcsc_icc_t *icc)
{
	return icc->max_send;
}


pcsc_icc_trans_param *icc_trans_param_new(void);
void icc_trans_param_free(pcsc_icc_trans_param *param);

uint16_t pcsc_icc_status(pcsc_icc_t *icc);
int icc_check_sw(pcsc_icc_t *icc, uint8_t sw1, uint8_t sw2);
const struct icc_acl_entry *icc_file_get_acl_entry(const struct icc_file *filp,
						  unsigned int op);
int icc_file_clear_acl_entries(struct icc_file *filp, unsigned int op);
int icc_file_add_acl_entry(struct icc_file *filp, unsigned int op, 
			     unsigned int method, unsigned int key_ref);
int icc_asn1_put_tag(int tag, const uint8_t *data, size_t data_len,
		       uint8_t *out, size_t out_len, uint8_t **ptr);
int icc_build_pin(uint8_t *rbuf, size_t rbuf_len, 
		    struct icc_pin_cmd_pin *pin, int pad);
int icc_file_set_prop_attr(struct icc_file *file, const uint8_t *prop_attr,
			     size_t prop_attr_len);
int icc_file_set_sec_attr(struct icc_file *file, const uint8_t *sec_attr,
				 size_t sec_attr_len);
struct icc_apdu *pcsc_build_apdu(int cse, uint8_t cla, uint8_t ins,
				 uint8_t p1, uint8_t p2,
				 uint32_t lc, uint32_t le,
				 uint8_t *data, size_t datalen);

int icc_check_path(struct icc_path *path);

/* ISO7816 API */
int iso7816_read_binary(pcsc_slot_t *, uint32_t offset,
			uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
			pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param);

int iso7816_write_binary(pcsc_slot_t *, uint32_t offset,
			 uint8_t *sbuf, size_t sbuf_len, uint32_t flags,
			 pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param);

int iso7816_update_binary(pcsc_slot_t *, uint32_t offset,
			  uint8_t *sbuf, size_t sbuf_len, uint32_t flags,
			  pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param);

int iso7816_read_record(pcsc_slot_t *, int rec_nr, 
			uint8_t *rec_buf, size_t rec_len, uint32_t flags,
			pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param);

int iso7816_write_record(pcsc_slot_t *, uint8_t rec_nr, 
		         uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		         pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param);

int iso7816_append_record(pcsc_slot_t *, uint8_t *rec_buf, size_t rec_len, uint32_t flags,
			  pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param);

int iso7816_update_record (pcsc_slot_t *, uint8_t rec_nr,
		           uint8_t *rec_buf, size_t rec_len, uint32_t flags,
		           pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param);

int iso7816_process_fci(pcsc_slot_t *handle, 
			struct icc_file *file_out,
			const uint8_t *buf, size_t buf_len);

int iso7816_select_file(pcsc_slot_t *, struct icc_path *in_path,
			struct icc_file **file_out, 
			pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param);

/* get response need not callback since its not the first call */
int iso7816_get_response(pcsc_transfer_t *, uint8_t *resp, size_t resp_len, uint32_t le);

int iso7816_get_challenge(pcsc_slot_t *, uint8_t *rnd, size_t rnd_len,
			  pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param);

int iso7816_construct_fci(pcsc_slot_t *card_handle, 
				 struct icc_file *filp,
				 uint8_t *fci_buf, size_t *fci_buflen);

int iso7816_create_file(pcsc_slot_t *, struct icc_file *filp,
			pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param);

int iso7816_delete_file(pcsc_slot_t *, const struct icc_path *path,
			pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param);

int iso7816_check_sw(pcsc_icc_t *icc, uint8_t sw1, uint8_t sw2);

#endif	/* __PCSC_ICC_H__ */

