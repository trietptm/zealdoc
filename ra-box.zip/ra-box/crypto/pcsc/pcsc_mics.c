#include "pcsc_priv.h"

/* in enum pcsc_card_status  */
const char *pcsc_card_status_str(uint32_t status)
{
	switch (status) {
	case PCSC_ICC_PRESENT_POWERUP:
		return "poweron";
	case PCSC_ICC_PRESENT_POWERDOWN:
		return "powerdown";
	case PCSC_ICC_ABSENT:
		return "absent";
	case PCSC_ICC_STATUS_NEGOTIABLE:
		return "negotiable";
	case PCSC_ICC_STATUS_SPECIFIC:
		return "specific";
	case PCSC_ICC_STATUS_UNKNOWN:
	default:
		return "Unknokn status";
	}
}

int pcsc_parse_atr(const char *atr, size_t atr_len, 
		   struct pcsc_atr_info *atr_info)
{
	uint16_t p;
	uint8_t K, TCK;	/* MSN of T0/Check Sum */
	uint8_t Y1i, T;	/* MSN/LSN of TDi */
	int i = 1;	/* value of the index in TAi, TBi, etc. */

	p = K = TCK = Y1i = T = 0;

	atr_info->default_proto = PCSC_PROTOCOL_UNKNOWN;
	atr_info->supported_protos = PCSC_PROTOCOL_UNKNOWN;

	if (atr_len < 2)
		return PCSC_E_INVALID_ATR;

	BUG_ON(atr[0] != 0x3F &&
	       atr[0] != 0x3B);

	if (atr[0] == 0x3F)
		atr_info->TS = PCSC_ATR_TS_INVERSE;
	else if (atr[0] == 0x3B)
		atr_info->TS = PCSC_ATR_TS_DIRECT;
	else 
		return PCSC_E_INVALID_ATR;

	Y1i = atr[1] >> 4;
	K = atr[1] & 0x0F;

	p = 2;

	do {
		short TAi, TBi, TCi, TDi;

		TAi = (Y1i & 0x01) ? atr[p++] : -1;
		TBi = (Y1i & 0x02) ? atr[p++] : -1;
		TCi = (Y1i & 0x04) ? atr[p++] : -1;
		TDi = (Y1i & 0x08) ? atr[p++] : -1;
		
		if (TDi >= 0) {
			Y1i = TDi >> 4;
			T = TDi & 0x0F;

			if (atr_info->default_proto == PCSC_PROTOCOL_UNKNOWN) {
				switch (T) {
				case 0: 
					atr_info->default_proto = PCSC_PROTOCOL_T0;
					break;
				case 1:
					atr_info->default_proto = PCSC_PROTOCOL_T1;
					break;
				default:
					return PCSC_E_NOT_SUPPORTED;
				}
			}

			if (T == 0) {
				atr_info->supported_protos |= PCSC_PROTOCOL_T0;
			} else if (T == 1) {
				atr_info->supported_protos |= PCSC_PROTOCOL_T1;
			} else if (T == 15) {
				atr_info->supported_protos |= PCSC_PROTOCOL_T15;
			} else {
				/* Do nothing for now since other protocols are not 
				 * supported at this time. */
			}
			
			if ((i == 2) && (TAi >= 0)) {
				T = TAi & 0x0F;
				switch (T) {
				case 0:
					atr_info->default_proto = 
						atr_info->supported_protos = 
						PCSC_PROTOCOL_T0;
					break;
				case 1:
					atr_info->default_proto = 
						atr_info->supported_protos = 
						PCSC_PROTOCOL_T1;
					break;
				default:
					return	PCSC_E_NOT_SUPPORTED;
				}
			}
		} else {
			Y1i = 0;
		}

		if (p > PCSC_MAX_ATR)
			return PCSC_E_INVALID_ATR;
		i++;
	} while (Y1i != 0);
	
	if (atr_info->default_proto == PCSC_PROTOCOL_UNKNOWN) {
		atr_info->default_proto = PCSC_PROTOCOL_T0;
		atr_info->supported_protos |= PCSC_PROTOCOL_T0;
	}

	atr_info->history_len = K;
	p += K;

	if (atr_info->supported_protos & PCSC_PROTOCOL_T1)
		TCK = atr[p++];

	return PCSC_S_SUCCESS;
}

int pcsc_default_proto(const uint8_t *atr, size_t atr_len, 
		       int *default_proto) 
{
	struct pcsc_atr_info atr_info;
	int r;
	
	r = pcsc_parse_atr(atr, atr_len, &atr_info);
	if (r == PCSC_S_SUCCESS) {
		*default_proto = atr_info.default_proto;
		return PCSC_S_SUCCESS;
	} else {
		return r;
	}
}

/* support protocol */
int pcsc_support_proto(const uint8_t *atr, size_t atr_len, 
		       int *supported_proto) 
{
	struct pcsc_atr_info atr_info;
	int r;

	r = pcsc_parse_atr(atr, atr_len, &atr_info);
	if (r == PCSC_S_SUCCESS) {
		*supported_proto = atr_info.supported_protos;
		return PCSC_S_SUCCESS;
	} else {
		return r;
	}
}

void icc_detect_apdu_cse(pcsc_slot_t *handle, 
			 struct icc_apdu *apdu)
{
	if (apdu->cse == ICC_APDU_CASE_2 || apdu->cse == ICC_APDU_CASE_3 ||
	    apdu->cse == ICC_APDU_CASE_4) {

		int btype = apdu->cse & ICC_APDU_SHORT_MASK;
#if 1
		/* if either Lc or Le is bigger than the maximun for
		 * short APDUs and the card supports extended APDUs
		 * use extended APDUs (unless Lc is greater than
		 * 255 and command chaining is activated) */
		if ((apdu->le > 256 || 
		    (apdu->lc > 255 && (apdu->flags & ICC_APDU_FLAG_CHAINING) == 0))/* &&
		    (handle->caps & ICC_CAPS_APDU_EXT) != 0*/)
			btype |= ICC_APDU_EXT;
#endif
		apdu->cse = btype;
	}
}

int icc_check_apdu(pcsc_slot_t *handle, struct icc_apdu *apdu)
{
	if ((apdu->cse & ~ICC_APDU_SHORT_MASK) == 0) {
		if (apdu->le > ICC_SHORT_LE_MAX ||
			(apdu->lc > ICC_SHORT_LC_MAX &&
			 (apdu->flags & ICC_APDU_FLAG_CHAINING) == 0))
			goto error;
	} else if ((apdu->cse & ICC_APDU_EXT) != 0) {
#if 0
		if ((handle->caps & ICC_CAPS_APDU_EXT) == 0)
			goto error;
#endif
		if (apdu->le > ICC_EXT_LE_MAX || apdu->lc > ICC_EXT_LC_MAX)
			goto error;
	} else {
		goto error;
	}

	switch (apdu->cse & ICC_APDU_SHORT_MASK) {
	case ICC_APDU_CASE_1:
		if (apdu->tx_buflen != 0 || apdu->lc != 0 || apdu->le != 0)
			goto error;
		break;
	case ICC_APDU_CASE_2_SHORT:
		if (apdu->tx_buflen != 0 || apdu->lc != 0)
			goto error;
		if (apdu->le == 0)/* || apdu->resplen == 0 || apdu->resp == NULL)*/
			goto error;
		if (apdu->rx_buflen < apdu->le)
			goto error;
		break;
	case ICC_APDU_CASE_3_SHORT:
		if (apdu->tx_buflen == 0 || apdu->tx_buf == NULL || apdu->lc == 0)
			goto error;
		if (apdu->le != 0)
			goto error;
		if (apdu->tx_buflen < apdu->lc)
			goto error;
		break;
	case ICC_APDU_CASE_4_SHORT:
		if (apdu->tx_buflen == 0 || apdu->tx_buf == NULL || apdu->lc == 0)
			goto error;
/*
		if (apdu->le == 0 || apdu->resplen == 0 || apdu->resp == NULL)
			goto error;
		if (apdu->resplen < apdu->le)
			goto error;
		if (apdu->datalen != apdu->lc)
			goto error;
*/
		break;
	default:
		return ICC_ERR_INVALID_ARGS;
	}
	return ICC_SUCCESS;
error:
	return ICC_ERR_INVALID_ARGS;
}

size_t icc_apdu_get_length(const struct icc_apdu *apdu, unsigned int proto)
{
	/* CLA | INS | P1 | P2 */
	size_t ret = 4;

	switch (apdu->cse) {
	case ICC_APDU_CASE_1:
		if (proto == ICC_PROTOCOL_T0)
			ret++;
		break;
	case ICC_APDU_CASE_2_SHORT:
	/* FIXME: this case may use short or ext length */
	case ICC_APDU_CASE_2:
		ret++;
		break;
	case ICC_APDU_CASE_3_SHORT:
		ret += 1 + apdu->lc;
		break;
	case ICC_APDU_CASE_4_SHORT:
		/* The command APDU is mapped onto the T=0 command TPDU by 
		 * cutting the last byte of the body.*/
		ret += 1 + apdu->lc + (proto == ICC_PROTOCOL_T0 ? 0 : 1);
		break;

	case ICC_APDU_CASE_2_EXT:
		ret += (proto == ICC_PROTOCOL_T0 ? 1 : 3);
		break;
	case ICC_APDU_CASE_3_EXT:
		ret += apdu->lc + (proto == ICC_PROTOCOL_T0 ? 1 : 3);
		break;
	case ICC_APDU_CASE_4_EXT:
		ret += apdu->lc + (proto == ICC_PROTOCOL_T0 ? 1 : 5);/*FIXME: + 6(Lc + Le)?*/
		break;
	default:
		return 0;
	}
	return ret;
}

/* just to bytes not TPDU */
int icc_apdu2bytes(const struct icc_apdu *apdu, uint32_t proto,
			uint8_t *out, size_t outlen)
{
	uint8_t     *p = out;

	if (out == NULL)
		return ICC_ERR_INVALID_ARGS;

	*p++ = apdu->cla;
	*p++ = apdu->ins;
	*p++ = apdu->p1;
	*p++ = apdu->p2;
	
	switch (apdu->cse) {
	case ICC_APDU_CASE_1:
		/* T0 needs an additional 0x00 byte */
		if (proto == ICC_PROTOCOL_T0)
			*p++ = 0x00;
		break;
	case ICC_APDU_CASE_2_SHORT:
		*p++ = (uint8_t)apdu->le;
		break;
	case ICC_APDU_CASE_3_SHORT:
		*p++ = (uint8_t)apdu->lc;
		memcpy(p, apdu->tx_buf, apdu->lc);
		p += apdu->lc;
		break;
	case ICC_APDU_CASE_4_SHORT:
		*p++ = (uint8_t)apdu->lc;
		memcpy(p, apdu->tx_buf, apdu->lc);
		p += apdu->lc;
		/* in case of T0 no Le byte is added */
		if (proto != ICC_PROTOCOL_T0)
			*p++ = (uint8_t)apdu->le;
		break;
	case ICC_APDU_CASE_2_EXT:
		if (proto == ICC_PROTOCOL_T0)
			/* T0 extended APDUs look just like short APDUs */
			*p++ = (uint8_t)apdu->le;
		else {
			/* in case of T1 always use 3 bytes for length */
			*p++ = (uint8_t)0x00;
			*p++ = (uint8_t)(apdu->le >> 8);
			*p++ = (uint8_t)apdu->le;
		}
		break;
	case ICC_APDU_CASE_3_EXT:
		if (proto == ICC_PROTOCOL_T0) {
			/* in case of T0 the command is transmitted in chunks
			 * < 255 using the ENVELOPE command ... */
			if (apdu->lc > 255) {
				/* ... so if Lc is greater than 255 bytes 
				 * an error has occurred on a higher level */
				pcsc_log(PCSC_LOG_ERR, "invalid Lc length for CASE 3 "
					"extended APDU (need ENVELOPE)");
				return ICC_ERR_INVALID_ARGS;
			}
		} else {
			/* in case of T1 always use 3 bytes for length */
			*p++ = (uint8_t)0x00;
			*p++ = (uint8_t)(apdu->lc >> 8);
			*p++ = (uint8_t)apdu->lc;
		}
		memcpy(p, apdu->tx_buf, apdu->lc);
		p += apdu->lc;
		break;
	case ICC_APDU_CASE_4_EXT:
		if (proto == ICC_PROTOCOL_T0) {
			/* again a T0 extended case 4 APDU looks just
			 * like a short APDU, the additional data is
			 * transferred using ENVELOPE and GET RESPONSE */
			*p++ = (uint8_t)apdu->lc;
			memcpy(p, apdu->tx_buf, apdu->lc);
			p += apdu->lc & 0xff;
		} else {
			*p++ = (uint8_t)0x00;
			*p++ = (uint8_t)(apdu->lc >> 8);
			*p++ = (uint8_t)apdu->lc;
			memcpy(p, apdu->tx_buf, apdu->lc);
			p += apdu->lc;
			/* only 2 bytes are use to specify the length of the
			 * expected data */
			*p++ = (uint8_t)(apdu->le >> 8);
			*p++ = (uint8_t)apdu->le;
		}
		break;
	}

	return ICC_SUCCESS;
}

void ulong2bebytes(uint8_t *buf, uint32_t x)
{
	buf[3] = (uint8_t) (x & 0xff);
	buf[2] = (uint8_t) ((x >> 8) & 0xff);
	buf[1] = (uint8_t) ((x >> 16) & 0xff);
	buf[0] = (uint8_t) ((x >> 24) & 0xff);
}

void ushort2bebytes(uint8_t *buf, uint16_t x)
{
	buf[1] = (uint8_t) (x & 0xff);
	buf[0] = (uint8_t) ((x >> 8) & 0xff);
}

uint32_t bebytes2ulong(const uint8_t *buf)
{
	return (uint32_t)(buf[0] << 24 | buf[1] << 16
		| buf[2] << 8 | buf[3]);
}

/* FIXME: different from opensc */
uint16_t bebytes2ushort(const uint8_t *buf)
{
	return (uint16_t)(buf[0] << 16 | buf[1]);
}
