#include "pcsc_priv.h"

DECLARE_LIST(pcsc_icc_list);
DECLARE_LIST(icc_drv_list);
DECLARE_LIST(pcsc_binder_list);

#define for_each_binder(e)	\
	list_for_each_entry(pcsc_binder_t, e, &pcsc_binder_list, link)

#define for_each_icc(e)	\
	list_for_each_entry(pcsc_icc_t, e, &pcsc_icc_list, link)

#define for_each_driver(e)	\
	list_for_each_entry(icc_driver_t, e, &icc_drv_list, link)


static icc_driver_t *icc_driver_by_name(const char *name);
static int icc_match_one_driver(pcsc_icc_t *icc);
static pcsc_binder_t *pcsc_binder_by_name(const char *name);

#ifdef NO_REF
static int icc_append_file_id(struct icc_path *dest, uint16_t fid);
#endif
static int __match_one_atr(icc_atr_table *, const uint8_t *bin, size_t bin_len);
static void __icc_create(pcsc_icc_t *icc);
static void __icc_delete(pcsc_icc_t *icc);
static void __icc_free_delay(void *, void *);

static void __icc_free_delay(void *eloop_data, void *user_data)
{
	pcsc_icc_t *icc = (pcsc_icc_t *)user_data;
	
	/* no one refer to me */
	if (atomic_read(&icc->refcnt) == 1) {
		eloop_cancel_timeout(NULL, __icc_free_delay, NULL, icc);
		list_delete(&icc->link);
		free(icc);
		pcsc_log(PCSC_LOG_DEBUG, "ICC: delete ICC");
	} else
		eloop_register_timeout(NULL, 1, 0, __icc_free_delay, NULL, icc);
}

pcsc_icc_t *pcsc_icc_get(pcsc_icc_t *icc)
{
	atomic_inc(&icc->refcnt);
	return icc;
}

void pcsc_icc_put(pcsc_icc_t *icc)
{
	atomic_dec(&icc->refcnt);
}

pcsc_icc_t *pcsc_icc_new(uint16_t idx)
{
	pcsc_icc_t *icc = malloc(sizeof (pcsc_icc_t));

	if (!icc)
		return NULL;
	memset(icc, 0, sizeof (pcsc_icc_t));

	list_init(&icc->link);
	list_insert_before(&icc->link, &pcsc_icc_list);
	icc->status = PCSC_ICC_STATUS_UNKNOWN;
	icc->idx = idx;
	icc->max_send = ICC_DEFAULT_SEND_MAX;
	icc->max_recv = ICC_DEFAULT_RECV_MAX;
	atomic_set(&icc->refcnt, 1);

	pcsc_log(PCSC_LOG_DEBUG, "ICC: create ICC");

	return icc;
}

void pcsc_icc_free(pcsc_icc_t *icc)
{
	eloop_register_timeout(NULL, 1, 0, __icc_free_delay, NULL, icc);
}

static pcsc_binder_t *pcsc_binder_by_name(const char *name)
{
	pcsc_binder_t *binder;

	for_each_binder(binder) {
		if (name && strcmp(name, binder->name) == 0)
			return binder;
	}
	return NULL;
}

int pcsc_register_binder(pcsc_binder_t *type)
{
	pcsc_binder_t *tmp;

	tmp = pcsc_binder_by_name(type->name);
	if (!tmp) {
		list_init(&type->link);
		list_insert_before(&type->link, &pcsc_binder_list);
	}
	return 0;
}

void pcsc_unregister_binder(pcsc_binder_t *phys)
{
	pcsc_binder_t *tmp;

	tmp = pcsc_binder_by_name(phys->name);
	if (tmp) {
		list_delete(&tmp->link);
	}
}

int pcsc_icc_up(pcsc_icc_t *icc)
{
	int ret;

	icc->status = PCSC_ICC_PRESENT_POWERUP;
	if (icc->lowerup == 1)
		return 1;
	pcsc_log(PCSC_LOG_INFO, "ICC: up ICC");

	/* match and/or bind(pointer assign) */
	ret = icc_match_one_driver(icc);

	if (ret == ICC_DRV_ASYNC_MATCH) {
		return 0;
	} else if (ret == ICC_DRV_NO_MATCH) {
		pcsc_log(PCSC_LOG_WARN,
			 "ICC: cannot find a driver for this card");
		return 4;
	}
	/* ICC_DRV_SYNC_MATCH */
	/* call-chain start */
	__icc_create(icc);
	return 0;
}

void pcsc_icc_down(pcsc_icc_t *icc)
{
	icc->status = PCSC_ICC_ABSENT;
	if (icc->lowerup == 0)
		return;
	pcsc_log(PCSC_LOG_INFO, "ICC: down ICC");
	__icc_delete(icc);
}

static icc_driver_t *icc_driver_by_name(const char *name)
{
	icc_driver_t *drv;

	for_each_driver(drv) {
		if (name && strcmp(name, drv->name) == 0)
			return drv;
	}
	return NULL;
}

int icc_register_driver(icc_driver_t *type)
{
	icc_driver_t *tmp;

	tmp = icc_driver_by_name(type->name);
	if (!tmp) {
		list_init(&type->link);
		list_insert_before(&type->link, &icc_drv_list);
	}
	return 0;
}

void icc_unregister_driver(icc_driver_t *phys)
{
	icc_driver_t *tmp;

	tmp = icc_driver_by_name(phys->name);
	if (tmp) {
		list_delete(&tmp->link);
	}
}

static void icc_async_no_response(void *e, void *icc)
{
	eloop_cancel_timeout(NULL, icc_async_no_response, NULL, icc);
	pcsc_log(PCSC_LOG_ERR, "ICC: fatal error, no one async driver response match");
	/* TODO: notify upper ? */
}

/* XXX: async driver do not use icc->drv to get ops */
static void icc_async_match_start(pcsc_icc_t *icc)
{
	icc_driver_t *drv;

	for_each_driver(drv) {
		if (drv->match_flags == ICC_DRV_ASYNC_MATCH &&
		    drv->match) {
			drv->match(icc);
		}
	}
	eloop_register_timeout(NULL, 10, 0,
			       icc_async_no_response, NULL, icc);
}

void icc_async_matched(pcsc_icc_t *icc, const char *name, int match)
{
	icc_driver_t *drv = icc_driver_by_name(name);
	
	BUG_ON(!drv);

	if (match) {
		eloop_cancel_timeout(NULL, icc_async_no_response, NULL, icc);
		icc->drv = drv;
		__icc_create(icc);
	}
}

/* Only call match() when drv is a sync one.
 * if not match and found async driver in list, call it after.
 */
static int icc_match_one_driver(pcsc_icc_t *icc)
{
	icc_driver_t *drv;
	int match, async_found = 0;

	for_each_driver(drv) {
		if (!drv->match)
			continue;

		if (drv->match_flags == ICC_DRV_SYNC_MATCH) {
			match = drv->match(icc);
			if (match) {
				icc->drv = drv;
				return ICC_DRV_SYNC_MATCH;
			}
		} else if (drv->match_flags == ICC_DRV_ASYNC_MATCH)
			async_found = 1;
	}

	/* arrive here means sync driver are not match */
	if (async_found) {
		icc_async_match_start(icc);
		return ICC_DRV_ASYNC_MATCH;
	}
	/* not find */
	return ICC_DRV_NO_MATCH;
}

/* icc is exist */
static void __icc_create(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "ICC_P: __create");

	/* ICC has found driver and 
	 * the driver must support open() */
	BUG_ON(!icc->drv || !icc->drv->open);
	icc->drv->open(icc);
}

static void __icc_delete(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "ICC_P: __delete");
	BUG_ON(!icc->drv || !icc->drv->close);
	icc->drv->close(icc);
}

/* call from lower */
void icc_up(pcsc_icc_t *icc)
{
	pcsc_binder_t *binder;

	pcsc_log(LOG_CALL_CHAIN, "ICC_P: up");
	icc->lowerup = 1;
	
	for_each_binder(binder) {
		BUG_ON(!binder->bind);
		/* async bind procedure */
		binder->bind(pcsc_idx_by_iccidx(icc->idx));
	}
}

/* call from lower */
void icc_down(pcsc_icc_t *icc)
{
	pcsc_log(LOG_CALL_CHAIN, "ICC_P: down");
	icc->lowerup = 0;
}



uint16_t pcsc_icc_status(pcsc_icc_t *icc)
{
	return icc->status;
}

int icc_check_sw(pcsc_icc_t *icc, uint8_t sw1, uint8_t sw2)
{
	if (!icc->drv->ops->check_sw)
		return ICC_ERR_NOT_SUPPORTED;

	return icc->drv->ops->check_sw(icc, sw1, sw2);
}

pcsc_icc_trans_param *icc_trans_param_new(void)
{
	pcsc_icc_trans_param *icc_param;

	icc_param = malloc(sizeof(pcsc_icc_trans_param));
	if (!icc_param)
		return NULL;
	memset(icc_param, 0, sizeof(pcsc_icc_trans_param));
	return icc_param;
}

void icc_trans_param_free(pcsc_icc_trans_param *param)
{
	if (param) {
		if (param->apdu) free(param->apdu);
		free(param);
	}
}
/*
 * This function will copy a PIN, convert and pad it as required
 *
 * Note about the SC_PIN_ENCODING_GLP encoding:
 * PIN buffers are allways 16 nibbles (8 bytes) and look like this:
 *   0x2 + len + pin_in_BCD + paddingnibbles
 * in which the paddingnibble = 0xF
 * E.g. if PIN = 12345, then sbuf = {0x24, 0x12, 0x34, 0x5F, 0xFF, 0xFF, 0xFF, 0xFF}
 * E.g. if PIN = 123456789012, then sbuf = {0x2C, 0x12, 0x34, 0x56, 0x78, 0x90, 0x12, 0xFF}
 * Reference: Global Platform - Card Specification - version 2.0.1' - April 7, 2000
 */
int icc_build_pin(uint8_t *rbuf, size_t rbuf_len, 
		    struct icc_pin_cmd_pin *pin, int pad)
{
	size_t i = 0, j, pin_len = pin->len;

	if (pin->max_len && pin_len > pin->max_len)
		return ICC_ERR_INVALID_ARGS;
	if (pin->encode_type == ICC_PIN_ENCODING_GLP) {
		while (pin_len > 0 && pin->data[pin_len - 1] == 0xFF)
			pin_len--;
		if (pin_len > 12)
			return ICC_ERR_INVALID_ARGS;
		for (i = 0; i < pin_len; i++) {
			if (pin->data[i] < '0' || pin->data[i] > '9')
				return ICC_ERR_INVALID_ARGS;
		}
		rbuf[0] = 0x20 | pin_len;
		rbuf++;
		rbuf_len--;
	}

	if (pin->encode_type == ICC_PIN_ENCODING_ASCII) {
		if (pin_len > rbuf_len)
			return ICC_ERR_INSUF_BUFFER;
		memcpy(rbuf, pin->data, pin_len);
		i = pin_len;
	} else if (pin->encode_type == ICC_PIN_ENCODING_BCD ||
		pin->encode_type == ICC_PIN_ENCODING_GLP) {
		if (pin_len > 2 *rbuf_len)
			return ICC_ERR_INSUF_BUFFER;
		for (i = j = 0; j < pin_len; j++) {
			rbuf[i] <<= 4;
			rbuf[i] |= pin->data[j] & 0x0F;
			if (j & 1) i++;
		}
		if (j & 1) {
			rbuf[i] <<= 4;
			rbuf[i] |= pin->pad_char & 0x0F;
			i++;
		}
	}
	if (pad || pin->encode_type == ICC_PIN_ENCODING_GLP) {
		size_t pad_len = pin->pad_len;
		uint8_t pad_char = pin->encode_type == ICC_PIN_ENCODING_GLP ? 0xFF: pin->pad_char;

		if (pin->encode_type == ICC_PIN_ENCODING_BCD)
			pad_len >>= 1;
		if (pin->encode_type == ICC_PIN_ENCODING_GLP)
			pad_len = 8;

		if (pad_len > rbuf_len)
			return ICC_ERR_INSUF_BUFFER;
		if (pad_len && i < pad_len) {
			memset(rbuf + i, pad_char, pad_len - i);
			i = pad_len;
		}
	}

	return i;
}

/* Read the next TLV
 * cla_out | tag_out: the T of TLV
 * taglen: correspond to the L of TLV
 * return the V of TLV
 */
int icc_asn1_read_tag(const uint8_t **buf, size_t buflen, 
			unsigned int *cla_out, unsigned int *tag_out,
			size_t *taglen)
{
	const uint8_t *p = *buf;
	size_t left = buflen, len;
	unsigned int cla, tag, i;

	if (left < 2)
		return ICC_ERR_INVALID_ASN1_OBJECT;
	*buf = NULL;
	if (*p == 0xff || *p == 0)/* end of data reached */
		return ICC_SUCCESS;
	/* parse tag byte(s) */
	cla = (*p & ICC_ASN1_TAG_CLASS_MASK) | (*p & ICC_ASN1_TAG_CONSTRUCTED);
	tag = *p & ICC_ASN1_TAG_PRIMITIVE;
	p++;
	left--;
	if (tag == ICC_ASN1_TAG_PRIMITIVE) {
		/* high tag number */
		size_t n = sizeof(int) - 1;
		/* search the last tag octet */
		while (left-- != 0 && n != 0) {
			tag <<= 8;
			tag |= *p;
			if ((*p++ & 0x80) == 0)
				break;
			n--;
		}
		if (left == 0 || n == 0)
			/* either an invalid tag or it doesn't fit in
			 * unsigned int */
			return ICC_ERR_INVALID_ASN1_OBJECT;
		
	}
	if (left == 0)
		return ICC_ERR_INVALID_ASN1_OBJECT;
	/* parse length byte(s) */
	len = *p & 0x7f;
	if (*p++ & 0x80) {
		unsigned int a = 0;
		if (len > 4 || len > left)
			return ICC_ERR_INVALID_ASN1_OBJECT;
		left -= len;
		for (i = 0; i < len; i++) {
			a <<= 8;
			a |= *p;
			p++;
		}
		len = a;
	}
	if (len > left)
		return ICC_ERR_INVALID_ASN1_OBJECT;
	*cla_out = cla;
	*tag_out = tag;
	*taglen = len;
	*buf = p;
	return ICC_SUCCESS;
}

const uint8_t *icc_asn1_find_tag(const uint8_t *buf, size_t buflen,
				   unsigned int tag_in, size_t *taglen_in)
{
	size_t left = buflen, taglen;
	const uint8_t *p = buf;

	*taglen_in = 0;
	while (left >= 2) {
		unsigned int cla, tag, mask = 0xff00;

		buf = p;
		/* read a tag */
		if (icc_asn1_read_tag(&p, left, &cla, &tag, &taglen) != ICC_SUCCESS)
			return NULL;
		if (left < (size_t)(p - buf)) {
			return NULL;
		}
		left -= (p - buf);
		/* we need to shift the class byte to the leftmost
		 * byte of the tag */
		while ((tag & mask) != 0) {
			cla  <<= 8;
			mask <<= 8;
		}
		/* compare the read tag with the given tag */
		if ((tag | cla) == tag_in) {
			/* we have a match => return length and value part */
			if (taglen > left)
				return NULL;
			*taglen_in = taglen;
			return p;
		}
		/* otherwise continue reading tags */
		if (left < taglen) {
			return NULL;
		}
		left -= taglen;
		p += taglen;
	}
	return NULL;	
}

int icc_asn1_put_tag(int tag, const uint8_t *data, size_t data_len,
		       uint8_t *out, size_t out_len, uint8_t **ptr)
{
	uint8_t *p = out;

	if (out_len < 2)
		return ICC_ERR_INVALID_ARGS;
	if (data_len > 127)
		return ICC_ERR_INVALID_ARGS;

	*p++ = tag & 0xFF; /* FIXME: support longer tags */
	out_len--;

	*p++ = (uint8_t)data_len;
	out_len--;

	if (out_len < data_len)
		return ICC_ERR_INVALID_ARGS;
	memcpy(p, data, data_len);
	p += data_len;

	if (ptr != NULL)
		*ptr = p;

	return 0;
}

const struct icc_acl_entry *icc_file_get_acl_entry(const struct icc_file *filp,
						  unsigned int op)
{
	BUG_ON(op >= ICC_AC_OP_MAX);

	return filp->acl[op];
}

int icc_file_clear_acl_entries(struct icc_file *filp, unsigned int op)
{
	struct icc_acl_entry *p1, *p2;

	BUG_ON(op >= ICC_AC_OP_MAX);

	p1 = filp->acl[op];

	while (p1) {
		p2 = p1->next;
		free(p1);
		p1 = p2;
	}
	filp->acl[op] = NULL;

	return ICC_SUCCESS;
}

int icc_file_add_acl_entry(struct icc_file *filp, unsigned int op, 
			     unsigned int method, unsigned int key_ref)
{
	struct icc_acl_entry *p, *new_acl;

	BUG_ON(op >= ICC_AC_OP_MAX);

	switch (method) {
	case ICC_AC_NONE:
	case ICC_AC_NEVER:
	case ICC_AC_UNKNOWN:
		icc_file_clear_acl_entries(filp, op);
		key_ref = ICC_AC_KEY_REF_NONE;
		break;
	}

	for (p = filp->acl[op]; p != NULL; p = p->next) {
		if ((p->method == method) && (p->key_ref == key_ref))
			return 0;
	}
	
	new_acl = malloc(sizeof(struct icc_acl_entry));
	if (!new_acl)
		return ICC_ERR_NO_MEM;
	new_acl->method = method;
	new_acl->key_ref = key_ref;
	new_acl->next = NULL;

	p = filp->acl[op];
	if (!p) {
		filp->acl[op] = new_acl;
	} else {
		while (p->next != NULL)
			p = p->next;
		p->next = new_acl;
	}

	return ICC_SUCCESS;
}

int icc_check_path(struct icc_path *path)
{
	if (path->len > ICC_PATH_MAX)
		return ICC_ERR_INVALID_ARGS;
	if (path->type == ICC_PATH_TYPE_PATH) {
		size_t i;
		if ((path->len & 1) != 0)
			return ICC_ERR_INVALID_ARGS;
		for (i = 0; i < path->len/2; i++) {
			uint8_t p1 = path->value[2 * i];
			uint8_t p2 = path->value[2 * i + 1];
			if (p1 == 0x3F && p2 == 0x00  && i != 0)
				return ICC_ERR_INVALID_ARGS;
		}
	}
	return ICC_SUCCESS;
}

int icc_fetch_file_path(struct icc_file *file, uint8_t *out, int outlen)
{
	if (!file)
		return 1;
	if (file->path.len <= 0)
		return 1;
	icc_bin_to_hex(file->path.value, file->path.len, out, outlen, 0);			
	return 0;
}

void icc_deformat_path(struct icc_path *path, char *out, int olen)
{
	icc_bin_to_hex(path->value, path->len, out, olen, 0);			
}

void icc_format_path(const char *str, struct icc_path *path)
{
	int type = ICC_PATH_TYPE_PATH;

	memset(path, 0, sizeof(*path));
	path->len = sizeof(path->value);
	if (icc_hex_to_bin(str, path->value, &path->len) >= 0)
		path->type = type;
}

int icc_is_same_path_str(uint8_t *s1, uint8_t *s2, size_t len)
{
	if (s1 && s2)
		return !memcmp(s1, s2, len);
	else
		return 0;
}

int icc_is_same_path(struct icc_path *p1, struct icc_path *p2)
{
	if (p1->len != p2->len)
		return 0;
	return !memcmp(p1->value, p2->value, p1->len);
}

int icc_have_same_root(struct icc_path *p1, struct icc_path *p2)
{
	if (p1->len != p2->len)
		return 0;
	return !memcmp(p1->value, p2->value, p1->len - 2);
}

/* true:
 * @upper: 3F002F00 
 * @lower: 3F002F001234
 */
int icc_is_upper(struct icc_path *upper, struct icc_path *lower)
{
	if (upper->len >= lower->len)
		return 0;
	return memcmp(upper->value, lower->value, upper->len) ? 0 : 1;
}

int icc_cat_path(struct icc_path *d, 
				const struct icc_path *p1, 
				const struct icc_path *p2)
{
	struct icc_path tpath;

	if (!d || !p1 || !p2)
		return ICC_ERR_INVALID_ARGS;
	if (p1->type == ICC_PATH_TYPE_DF_NAME
		|| p2->type == ICC_PATH_TYPE_DF_NAME)
		return ICC_ERR_INVALID_ARGS;
	if (p1->len + p2->len > ICC_PATH_MAX)
		return ICC_ERR_INVALID_ARGS;
	
	memset(&tpath, 0, sizeof(struct icc_path));
	memcpy(tpath.value, p1->value, p1->len);
	memcpy(tpath.value + p1->len, p2->value, p2->len);
	tpath.len = p1->len + p2->len;
	tpath.type = ICC_PATH_TYPE_PATH;

	*d = tpath;

	return ICC_SUCCESS;
}

int icc_append_path(struct icc_path *dest, const struct icc_path *src)
{
	return icc_cat_path(dest, dest, src);
}

int icc_append_path_id(struct icc_path *dest, const uint8_t *id, size_t idlen)
{
	if (dest->len + idlen > ICC_PATH_MAX)
		return ICC_ERR_INVALID_ARGS;
	memcpy(dest->value + dest->len, id, idlen);
	dest->len += idlen;

	return ICC_SUCCESS;
}

int icc_compare_path(const struct icc_path *path1,
		     const struct icc_path *path2)
{
	return path1->len == path2->len
		&& !memcmp(path1->value, path2->value, path1->len);
}

int icc_compare_path_prefix(const struct icc_path *prefix, 
			      const struct icc_path *path)
{
	struct icc_path tpath;

	if (prefix->len > path->len)
		return 0;

	tpath     = *path;
	tpath.len = prefix->len;

	return icc_compare_path(&tpath, prefix);
}

const struct icc_path *icc_get_mf_path(void)
{
	static const struct icc_path mf_path = 
		{ICC_PATH_TYPE_PATH, {0x3f, 0x00,}, 2, 0, 0, 0, };
	return &mf_path;
}

int icc_make_absolute_path(const struct icc_path *parent, 
			     struct icc_path *child)
{
	/* a 0 length path stays a 0 length path */
	if (child->len == 0)
		return ICC_SUCCESS;

	if (icc_compare_path_prefix(icc_get_mf_path(), child))
		return ICC_SUCCESS;
	return icc_cat_path(child, parent, child);
}

#ifdef NO_REF
static int icc_append_file_id(struct icc_path *dest, uint16_t fid)
{
	uint8_t id[2] = {fid >> 8, fid & 0xff};

	return icc_append_path_id(dest, id, 2);
}
#endif

struct icc_path *icc_path_dup(struct icc_path *src)
{
	struct icc_path *newp = malloc (sizeof (struct icc_path));

	if (newp == NULL)
		return NULL;
	memcpy(newp, src, sizeof (struct icc_path));
	return newp;
}


void icc_file_dup(struct icc_file **dest, 
		    const struct icc_file *src)
{
	struct icc_file *newf;
	const struct icc_acl_entry *e;
	unsigned int op;

	*dest = NULL;
	newf = icc_file_new();
	if (newf == NULL)
		return;
	*dest = newf;

	memcpy(&newf->path, &src->path, sizeof(struct icc_path));
	memcpy(&newf->df_name, &src->df_name, sizeof(src->df_name));
	newf->df_name_len = src->df_name_len;
	newf->type    = src->type;
	newf->shareable    = src->shareable;
	newf->ef_structure = src->ef_structure;
	newf->size    = src->size;
	newf->id      = src->id;
	newf->status  = src->status;
	for (op = 0; op < ICC_AC_OP_MAX; op++) {
		newf->acl[op] = NULL;
		e = icc_file_get_acl_entry(src, op);
		if (e != NULL) {
			if (icc_file_add_acl_entry(newf, op, e->method, e->key_ref) < 0)
				goto err;
		}
	}
	newf->record_length = src->record_length;
	newf->record_count  = src->record_count;

	if (icc_file_set_sec_attr(newf, src->sec_attr, src->sec_attr_len) < 0)
		goto err;
	if (icc_file_set_sec_attr(newf, src->prop_attr, src->prop_attr_len) < 0)
		goto err;
	if (icc_file_set_sec_attr(newf, src->type_attr, src->type_attr_len) < 0)
		goto err;
	return;
err:
	if (newf != NULL)
		icc_file_free(newf);
	*dest = NULL;
}

int icc_file_set_prop_attr(struct icc_file *file, const uint8_t *prop_attr,
			     size_t prop_attr_len)
{
	uint8_t *tmp;

	if (prop_attr == NULL) {
		if (file->prop_attr != NULL)
			free(file->prop_attr);
		file->prop_attr = NULL;
		file->prop_attr_len = 0;

		return ICC_SUCCESS;
	}
	tmp = (uint8_t *)realloc(file->prop_attr, prop_attr_len);
	if (!tmp) {
		if (file->prop_attr)
			free(file->prop_attr);
		file->prop_attr = NULL;
		file->prop_attr_len = 0;

		return ICC_ERR_NO_MEM;
	}
	file->prop_attr = tmp;
	memcpy(file->prop_attr, prop_attr, prop_attr_len);
	file->prop_attr_len = prop_attr_len;

	return ICC_SUCCESS;
}

int icc_file_set_sec_attr(struct icc_file *file, const uint8_t *sec_attr,
				 size_t sec_attr_len)
{
	uint8_t *tmp;

	if (sec_attr == NULL) {
		if (file->sec_attr != NULL)
			free(file->sec_attr);
		file->sec_attr = NULL;
		file->sec_attr_len = 0;

		return ICC_SUCCESS;
	}
	tmp = (uint8_t *)realloc(file->sec_attr, sec_attr_len);
	if (!tmp) {
		if (file->sec_attr)
			free(file->sec_attr);
		file->sec_attr = NULL;
		file->sec_attr_len = 0;

		return ICC_ERR_NO_MEM;
	}
	file->sec_attr = tmp;
	memcpy(file->sec_attr, sec_attr, sec_attr_len);
	file->sec_attr_len = sec_attr_len;

	return ICC_SUCCESS;	
}

struct icc_file *icc_file_new(void)
{
	struct icc_file *filp;

	filp = calloc(1, sizeof(struct icc_file));
	if (!filp)
		return NULL;

	return filp;
}

void icc_file_free(struct icc_file *filp)
{
	int i;

	for (i = 0; i < ICC_AC_OP_MAX; i++)
		icc_file_clear_acl_entries(filp, i);

	if (filp->sec_attr) free(filp->sec_attr);
	if (filp->prop_attr) free(filp->prop_attr);
	if (filp->type_attr) free(filp->type_attr);
	free(filp);
}

void icc_mem_clear(void *ptr, size_t len)
{
#ifdef HAVE_OPENSSL
	OPENSSL_cleanse(ptr, len);
#else
	memset(ptr, 0, len);
#endif
}

/* apdu can be free() directly */
struct icc_apdu *pcsc_build_apdu(int cse, uint8_t cla, uint8_t ins,
				 uint8_t p1, uint8_t p2,
				 uint32_t lc, uint32_t le,
				 uint8_t *data, size_t datalen)
{
	struct icc_apdu *apdu = malloc(sizeof (struct icc_apdu));

	if (!apdu) {
		pcsc_log(PCSC_LOG_ERR, "ICC: build apdu fail, out of memory");
		return NULL;
	}
	memset(apdu, 0, sizeof (struct icc_apdu));

	apdu->cse = cse;
	apdu->cla = cla;
	apdu->ins = ins;
	apdu->p1 = p1;
	apdu->p2 = p2;
	apdu->lc = lc;
	apdu->le = le;
	if (data) {
		/* user data, not free by us */
		apdu->tx_buf = data;
		apdu->tx_buflen = datalen;
	}
	return apdu;
}

int icc_compare_oid(const struct icc_object_id *oid1, 
		    const struct icc_object_id *oid2)
{
	int i;
	BUG_ON(oid1 != NULL && oid2 != NULL);

	for (i = 0; i < ICC_OBJECT_ID_OCTETS_MAX; i++) {
		if (oid1->value[i] != oid2->value[i])
			return 0;
		if (oid1->value[i] < 0)
			return 1;
	}
	return 1;
}

/* If there is not sep, set in_sep = 0 */
int icc_bin_to_hex(const uint8_t *in, size_t in_len,
		        char *out, size_t out_len, uint8_t in_sep)
{
	size_t n, sep_len;
	uint8_t *pos, *end, sep;

	sep = in_sep;
	sep_len = sep > 0 ? 1 : 0;
	pos = out;
	end = out + out_len;

	for (n = 0; n < in_len; n++) {
		if (pos + 3 + sep_len >= end)
			return ICC_ERR_INSUF_BUFFER;
		if (n && sep_len)
			*pos++ = sep;
		sprintf(pos, "%02x", in[n]);
		pos += 2;
	}
	*pos = '\0';

	return 0;
}

int icc_hex_to_bin(const char *in, uint8_t *out, size_t *outlen)
{
	int err = ICC_SUCCESS;
	size_t left, count = 0;

	BUG_ON(!in || !out || !outlen);

	left = *outlen;

	while (*in != '\0') {
		uint8_t byte = 0, nybbles = 2;

		while (nybbles-- && *in && *in != ':') {
			char c;

			byte <<= 4;
			c = *in++;
			if ('0' <= c && c <= '9')
				c -= '0';
			else if ('a' <= c && c <= 'f')
				c = c - 'a' + 10;
			else if ('A' <= c && c <= 'F')
				c = c- 'A' + 10;
			else {
				err = ICC_ERR_INVALID_ARGS;
				goto out;
			}
			byte |= c;
		}
		if (*in == ':')
			in++;
		if (left <= 0) {
			err = ICC_ERR_INSUF_BUFFER;
			break;
		}
		out[count++] = byte;
		left--;
	}
out:
	*outlen = count;
	return err;
}

static int __match_one_atr(icc_atr_table *atr_table, const uint8_t *atr_bin,
		 	   size_t atr_bin_len)
{
	const uint8_t *tatr, *matr;
	size_t tatr_len;
	const uint8_t *card_atr_bin = atr_bin;
	size_t card_atr_bin_len = atr_bin_len;
	char card_atr_hex[3 * PCSC_MAX_ATR];
	size_t card_atr_hex_len;

	icc_bin_to_hex(card_atr_bin, card_atr_bin_len, card_atr_hex,
		     sizeof(card_atr_hex), ':');
	card_atr_hex_len = strlen(card_atr_hex);

	tatr = atr_table->atr;
	matr = atr_table->atr_mask;
	tatr_len = strlen(tatr);
				
	if (tatr_len != card_atr_hex_len)
		return 0;
	if (matr == NULL) {
		if (strncasecmp(tatr, card_atr_hex, tatr_len) != 0)
			return 0;
	} else {
		uint8_t mbin[PCSC_MAX_ATR], tbin[PCSC_MAX_ATR];
		size_t mbin_len, tbin_len, s, matr_len;

		matr_len = strlen(matr);
		if (tatr_len != matr_len)
			return 0;
		tbin_len = sizeof(tbin);
		icc_hex_to_bin(tatr, tbin, &tbin_len);
		mbin_len = sizeof(mbin);
		icc_hex_to_bin(matr, mbin, &mbin_len);
		if (mbin_len != card_atr_bin_len)
			return 0;
		for (s = 0; s < tbin_len; s++) {
			tbin[s] = tbin[s] & mbin[s];
			mbin[s] = card_atr_bin[s] & mbin[s];
		}
		if (memcmp(tbin, mbin, tbin_len) != 0)
			return 0;
	}

	return 1;
}

/* lookup/compare art in a tabele, if match return 1 else 0 */
int icc_match_atr(icc_atr_table *atr_table, const uint8_t *atr_bin,
		  size_t atr_bin_len)
{
	for ( ; atr_table && atr_table->name; atr_table++) {
		if (__match_one_atr(atr_table, atr_bin, atr_bin_len))
			return 1;
	}
	return 0;
}

static const char *icc_proto_str(uint32_t l)
{
	if (l == PCSC_PROTOCOL_T0)
		return "T0";
	else if (l == PCSC_PROTOCOL_T1)
		return "T1";
	return "unknown";
}

struct __test_t {
	pcsc_slot_t *slot;
	struct icc_path *path;
};

static void __icc_cmd_select_path_cb(void *user, int ret)
{
	struct __test_t *tt = (struct __test_t *)user;
	if (tt) {
		pcsc_slot_put(tt->slot);
		free(tt->path);
		free(tt);
	}
	pcsc_log(PCSC_LOG_ERR, "ICC: select path ret=%d", ret);
}

static int icc_cmd_select_path(ui_session_t *sess, ui_entry_t *inst,
			       void *ctx, int argc, char **argv)
{
	uint16_t idx;
	int ret;
	struct icc_path *ipath;
	pcsc_slot_t *slot;
	struct __test_t *tt = malloc(sizeof (struct __test_t));

	if (!tt)
		goto out;

	idx = atoi(argv[1]);
	ipath = malloc(sizeof (struct icc_path));
	if (!ipath)
		goto out;
	memset(ipath, 0, sizeof (struct icc_path));
	icc_format_path(argv[0], ipath);
	slot = pcsc_handle_get_by_idx(idx);

	if (!slot)
		goto out;

	tt->slot = slot;
	tt->path = ipath;
	ret = pcsc_select_file(slot, ipath, 
			       NULL, __icc_cmd_select_path_cb, tt);
	if (ret)
		goto out;
	return 0;
out:
	return -1;
}

#if 0
struct icc_file *__build_file(void)
{
	struct icc_file *file = malloc(sizeof (struct icc_file));
	if (!file)
		return NULL;
	memset(file, 0, sizeof (struct icc_file));

	filp->type = ICC_FILE_TYPE_WORKING_EF;
	file->ef_structure = ICC_FILE_EF_TRANSPARENT;

}
#endif

static int icc_cmd_dump(ui_session_t *sess, ui_entry_t *inst,
			     void *ctx, int argc, char **argv)
{
	ui_table_t *table = ui_table_by_name(sess, "pcsc_icc_list");
	int i = 0, j;
	char buf[3 * PCSC_MAX_ATR];
	pcsc_icc_t *icc;
	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "pcsc_icc_list");
	if (!table)
		return -1;

	ui_add_title(table, 0, "type");	/* use driver name */
	ui_add_title(table, 1, "proto");
	ui_add_title(table, 2, "status");
	ui_add_title(table, 3, "atr");
	ui_add_title(table, 4, "curr_path");
	OBJ_UI_TABLE_TITLE(table, 5);

#define ICC_LIST(foreach, gc)									\
	foreach(icc) {										\
		ui_add_value(table, "type", i, icc->lowerup ? icc->drv->name : "unknown");	\
		ui_add_value(table, "proto", i, icc->lowerup ? icc_proto_str(icc->proto) : "NULL");	\
		ui_add_value(table, "status", i,						\
			     pcsc_card_status_str(icc->status));				\
		icc_bin_to_hex(icc->atr, icc->atr_len, buf, sizeof(buf), ':');			\
		if (strlen(buf) > 20)	\
			buf[17] = '.';	\
			buf[18] = '.';	\
			buf[19] = '.';	\
			buf[20] = 0;	\
		ui_add_value(table, "atr", i, icc->lowerup ? buf : "NULL");			\
		if (icc->curr_path.len == 0)							\
			sprintf(buf, "not support");						\
		for (j = 0; j < (int)icc->curr_path.len; j++)					\
			sprintf(buf + 2 * j, "%02X", icc->curr_path.value[j]);			\
		ui_add_value(table, "curr_path", i, icc->lowerup ? buf : "NULL");		\
		OBJ_UI_TABLE_VALUE(table, icc, i, gc);						\
		i++;										\
	}
	ICC_LIST(for_each_icc, "x");
//	ICC_LIST(for_each_icc_gc, "o")

	sess->result_table = table;
	return 0;
}

ui_schema_t pscs_icc_scheme[] = {
	/* .pcsc.icc */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".pcsc.card", "card", "PCSC smart cards" },

	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".pcsc.card.select", "select", "select icc path" },

	{ UI_TYPE_NONE },
};

ui_argument_t __select_args[] = {
	{ "path", "icc path", NULL, UI_TYPE_STRING, },
	{ "index", "reader index", NULL, UI_TYPE_STRING, },
};

ui_command_t pcsc_select_cmd = {
	"select",
	"select path",
	".pcsc.card",
	UI_CMD_SINGLE_INST,
	__select_args,
	2,
	LIST_HEAD_INIT(pcsc_select_cmd.link),
	icc_cmd_select_path,
};

ui_command_t pscs_icc_command = {
	"dump",
	"dump card",
	".pcsc.card",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(pscs_icc_command.link),
	icc_cmd_dump,
};

int __init pcsc_icc_init(void)
{
	ui_register_schema(pscs_icc_scheme);
	ui_register_command(&pscs_icc_command);
	ui_register_command(&pcsc_select_cmd);
	/* icc driver init */
	icc_wd_init();
	icc_muscle_init();

	return 0;
}

void __exit pcsc_icc_exit(void)
{
	icc_muscle_exit();
	icc_wd_exit();

	ui_unregister_command(&pcsc_select_cmd);
	ui_unregister_command(&pscs_icc_command);
	ui_unregister_schema(pscs_icc_scheme);

}

