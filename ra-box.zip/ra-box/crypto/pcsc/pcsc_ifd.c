#include "pcsc_priv.h"

DECLARE_BITMAP(pcsc_reader_idx, PCSC_MAX_READERS);

DECLARE_LIST(pcsc_ifd_list);

#define for_each_ifd(e)		\
	list_for_each_entry(pcsc_ifd_t, e, &pcsc_ifd_list, link)

static int ifd_idx_alloc(void);
static void ifd_idx_free(int idx);

static void __ifd_free_stop(pcsc_ifd_t *ifd);
static void __ifd_free_start(pcsc_ifd_t *ifd);
static void __ifd_free_timeout(void *e, void *data);

static void ifd_free(pcsc_ifd_t *);
static void ifd_stop(pcsc_ifd_t *);
static void ifd_start(pcsc_ifd_t *);
static pcsc_ifd_t *ifd_find(const char *name, int type);
static pcsc_ifd_t *ifd_new(const char *name, int type, int slot_num,
			   void *lower, ifd_driver_t *ops);

void ifd_destroy_param(pcsc_ifd_trans_param *param)
{
	if (param) {
		if (param->sbuf) free(param->sbuf);
		free(param);	
	}
}

int ifd_build_param(pcsc_transfer_t *trans, pcsc_trans_cb cb)
{
	pcsc_ifd_trans_param *ifd_param;
	struct icc_apdu *apdu;
	int proto, r, sbuf_len;
	uint8_t *sbuf = NULL;

	apdu = pcsc_trans_apdu(trans);
	if (!apdu)
		return -1;
	proto = pcsc_trans_proto(trans);

	icc_detect_apdu_cse(trans->handle, apdu);
	r = icc_check_apdu(trans->handle, apdu);

	if (r != ICC_SUCCESS)
		return r;
	
	ifd_param = malloc(sizeof(pcsc_ifd_trans_param));
	if (!ifd_param)
		return ICC_ERR_NO_MEM;

	memset(ifd_param, 0, sizeof(pcsc_ifd_trans_param));

	sbuf_len = icc_apdu_get_length(apdu, proto);
	if (sbuf_len == 0)
		goto err;

	sbuf = malloc(sbuf_len);
	if (!sbuf)
		goto err;

	r = icc_apdu2bytes(apdu, proto, sbuf, sbuf_len);

	if (r != ICC_SUCCESS)
		goto err;

	ifd_param->sbuf = sbuf;
	ifd_param->sbuf_len = sbuf_len;
	ifd_param->callback = cb;

	trans->ifd_param = ifd_param;

	return 0;
err:
	if (sbuf) free(sbuf);
	if (ifd_param) free(ifd_param);
	return -1;
}

static int ifd_idx_alloc(void)
{
	int i = __find_first_zero_bit(pcsc_reader_idx, PCSC_MAX_READERS);
	if (i >= PCSC_MAX_READERS) {
		pcsc_log(PCSC_LOG_ERR, "IFD: too many reader index allocated");
		return 0xff;
	}
	__set_bit(i, pcsc_reader_idx);
	return (i);
}

static void ifd_idx_free(int unit)
{
	if (unit >= 0 && unit < PCSC_MAX_READERS)
		__clear_bit(unit, pcsc_reader_idx);
}


static void __ifd_free_timeout(void *e, void *data)
{
	pcsc_ifd_t *ifd = (pcsc_ifd_t *)data;

	if (atomic_read(&ifd->refcnt) == 1) {
		__ifd_free_stop(ifd);
		ifd_free(ifd);
	}
	else
		__ifd_free_start(ifd);
}

static void __ifd_free_start(pcsc_ifd_t *ifd)
{
	eloop_register_timeout(NULL, 2, 0, __ifd_free_timeout, NULL, ifd);
}

static void __ifd_free_stop(pcsc_ifd_t *ifd)
{
	eloop_cancel_timeout(NULL, __ifd_free_timeout, NULL, ifd);
}

static pcsc_ifd_t *ifd_find(const char *name, int type)
{
	pcsc_ifd_t *rdr;

	for_each_ifd(rdr) {
		if (strcasecmp(rdr->name, name) == 0 &&
		    rdr->type == type)
		    return rdr;
	}
	return NULL;
}

/*
 * create/initial ifd 
 * and its slot(s) which number depends on slot_num.
 */
static pcsc_ifd_t *ifd_new(const char *name, int type, int slot_num,
			   void *lower, ifd_driver_t *ops)
{
	pcsc_ifd_t *rdr;
	int i;

	rdr = malloc(sizeof (pcsc_ifd_t));
	if (!rdr)
		goto err;

	memset(rdr, 0, sizeof (pcsc_ifd_t));

	rdr->ifd_status = PCSC_IFD_STATUS_PRESENT;
	rdr->nslots = slot_num;
	rdr->type = type;
	rdr->name = strdup(name);
	rdr->drv = ops;
	rdr->lower = lower;

	list_init(&rdr->link);
	list_insert_before(&rdr->link, &pcsc_ifd_list);

	atomic_set(&rdr->refcnt, 1);

	rdr->idx  = ifd_idx_alloc();
	if (rdr->idx == 0xff) {
		pcsc_log(PCSC_LOG_WARN, "IFD: max IFD reached");
		goto err;
	}

	for (i = 0; i < slot_num; i++) {
		pcsc_slot_t *hd = pcsc_slot_new(rdr, i);

		if (!hd)
			goto err;
	}
	pcsc_log(PCSC_LOG_DEBUG,
		 "IFD: new IFD=%d, slot num=%d", rdr->idx, rdr->nslots);

	return rdr;
err:
	ifd_free(rdr);
	return NULL;
}

static void ifd_free(pcsc_ifd_t *rdr)
{
	pcsc_slot_free_all(rdr);

	if (atomic_dec_and_test(&rdr->refcnt)) {
		pcsc_log(PCSC_LOG_DEBUG, "IFD: free IFD=%d", rdr->idx);
		if (rdr->name) free(rdr->name);
		ifd_idx_free(rdr->idx);
		list_delete(&rdr->link);
		free(rdr);
	}
}

static void ifd_stop(pcsc_ifd_t *ifd)
{
	pcsc_stop_by_ifd(ifd);
	__ifd_free_start(ifd);
}

static void ifd_start(pcsc_ifd_t *ifd)
{
	pcsc_get_feature(ifd);
	/* prepare start STM which is in the slot */
	pcsc_start_by_ifd(ifd);
}

pcsc_ifd_t *pcsc_ifd_get(pcsc_ifd_t *rdr)
{
	atomic_inc(&rdr->refcnt);
	return rdr;
}

void pcsc_ifd_put(pcsc_ifd_t *rdr)
{
	atomic_dec(&rdr->refcnt);
}


int pcsc_ifd_create(const char *name, int type, void *lower, ifd_driver_t *ops)
{
	pcsc_ifd_t *rdr = ifd_find(name, type);
	uint8_t slot_num;
	int ret;

	if (rdr) {
		pcsc_log(PCSC_LOG_INFO, "IFD: ifd=%s/%d has up before",
			name, type);
		BUG();
	}

	if (ops->get_desc_attr) {
		ret = ops->get_desc_attr(lower, PCSC_GET_ATTR_NSLOT, (void *)&slot_num);
		pcsc_log(PCSC_LOG_INFO, "IFD: has %d slot(s)", slot_num);
	} else
		slot_num = 1;	/* force set */

	/* create ifd, icc and slot */
	rdr = ifd_new(name, type, slot_num, lower, ops);
	
	if (rdr)
		ifd_start(rdr);

	return 0;
}

int pcsc_ifd_delete(const char *name, int type, void *lower)
{
	pcsc_ifd_t *rdr = ifd_find(name, type);
	
	if (rdr)
		ifd_stop(rdr);
	return 0;
}

ui_schema_t pscs_ifd_scheme[] = {
	/* .pcsc.ifd */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".pcsc.reader", "reader", "PC/SC readers" },

	{ UI_TYPE_NONE },
};

static int ifd_cmd_dump(ui_session_t *sess, ui_entry_t *inst,
			     void *ctx, int argc, char **argv)
{
	pcsc_ifd_t *ifd;
	ui_table_t *table = ui_table_by_name(sess, "pcsc_ifd_list");
	char buf[25] = "";
	int i = 0;

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "pcsc_ifd_list");
	if (!table)
		return -1;

	ui_add_title(table, 0, "name");
	ui_add_title(table, 1, "index");
	ui_add_title(table, 2, "nslot");
	ui_add_title(table, 3, "driver");
	OBJ_UI_TABLE_TITLE(table, 4);

	i = 0;

	for_each_ifd(ifd) {
		ui_add_value(table, "name", i, "whichname");
		snprintf(buf, sizeof(buf), "%d", ifd->idx);
		ui_add_value(table, "index", i, buf);
		snprintf(buf, sizeof(buf), "%d", ifd->nslots);
		ui_add_value(table, "nslot", i, buf);
		ui_add_value(table, "driver", i, ifd->drv->name);
		OBJ_UI_TABLE_VALUE(table, ifd, i, "x");
		i++;
	}
	sess->result_table = table;
	return 0;
}

ui_command_t pscs_ifd_command = {
	"dump",
	"dump reader on the system",
	".pcsc.reader",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(pscs_ifd_command.link),
	ifd_cmd_dump,
};

int __init pcsc_ifd_init(void)
{
	ui_register_schema(pscs_ifd_scheme);
	ui_register_command(&pscs_ifd_command);

	/* reader driver init */
	ifd_ccid_init();

	return 0;
}

void __exit pcsc_ifd_exit(void)
{
	ifd_ccid_exit();

	ui_unregister_command(&pscs_ifd_command);
	ui_unregister_schema(pscs_ifd_scheme);
}
