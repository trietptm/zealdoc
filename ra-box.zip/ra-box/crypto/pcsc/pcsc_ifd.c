#include "pcsc_priv.h"
#ifdef CONFIG_USB
#include <usb.h>
#endif

/* TODO: assume all reader only have one slot */

#define PCSC_ERR_PRINT(ret)	\
		pcsc_log(PCSC_LOG_ERR, "PCSC_IFD: return err=%d at line=%d", ret, __LINE__)


struct pcsc_reader_context *pcsc_reader_ctx_by_filename(const char *filename)
{
#if 0
	int i;
	struct pcsc_reader_context *rd_ctx;

	for (i = 0; i < PCSC_MAX_READERS; i++) {
		rd_ctx = reader_ctx[i];
		if (rd_ctx
			&& !strcmp(rd_ctx->handle.reader.file_name, filename))
			return rd_ctx;
	}
#endif
	return NULL;
}

int pcsc_release_reader_ctx(struct pcsc_reader_context *rd_ctx)
{
#if 0
	int i;

	for (i = 0; i < PCSC_MAX_READERS; i++) {
		if (reader_ctx[i] && (reader_ctx[i] == rd_ctx)) {
			if (rd_ctx->handle.reader.slot)
				free(rd_ctx->handle.reader.slot);
			if (rd_ctx->handle.reader.file_name)
				free(rd_ctx->handle.reader.file_name);
			if (rd_ctx->handle.reader.name)
				free(rd_ctx->handle.reader.name);
			if(rd_ctx->name) free(rd_ctx->name);
			free(rd_ctx);
			reader_ctx[i] = NULL;
			return PCSC_S_SUCCESS;
		}
	}
#endif
	return PCSC_E_INVALID_PARAMETER;
}

static void pcsc_stm_exit_delay(void *eloop, void *user_ctx);

static void pcsc_stm_log(const stm_instance_t *fsmi,
			int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

#define PCSC_STATE_INIT		0
#define PCSC_STATE_OPEN		1	/* Reader Opening */
#define PCSC_STATE_CSTATUSING	2	/* ICC statusing */
#define PCSC_STATE_CSTATUSED	3	/* ICC statused */
#define PCSC_STATE_PRESENT	4	/* ICC present */
#define PCSC_STATE_ABSENT	5	/* ICC absent */
#define PCSC_STATE_POWERUP	6	/* ICC powerup(actived) */
#define PCSC_STATE_DEACTIVE	7	/* ICC deactive */
#define PCSC_STATE_POWERDOWN	8	/* ICC powerdown(deactived) */
#define PCSC_STATE_EXIT		9	

#define PCSC_STATE_COUNT	10

#define PCSC_STATE_NAMES {	\
	"INIT",			\
	"OPEN",			\
	"CSTATUSING",		\
	"CSTATUSED",		\
	"PRESENT",		\
	"ABSENT",		\
	"POWERUP",		\
	"DEACTIVE",		\
	"POWERDOWN",		\
	"EXIT",			\
}

#define PCSC_EVENT_RIS		0	/* Reader InSerted*/
#define PCSC_EVENT_ORS		1	/* Open Reader Success */
#define PCSC_EVENT_ORF		2	/* Open Reader Failed */
#define PCSC_EVENT_CSS		3	/* icC Status Success */
#define PCSC_EVENT_CSF		4	/* icC Status Failed */
#define PCSC_EVENT_TO		5	/* Time Out*/
#define PCSC_EVENT_ICCP		6	/* ICC Present */
#define PCSC_EVENT_ICCNP	7	/* ICC Not Present */
#define PCSC_EVENT_CAS		8	/* Card Active Success */
#define PCSC_EVENT_CAF		9	/* Card Active Failed */
#define PCSC_EVENT_ICCA		10	/* ICC active */
#define PCSC_EVENT_ICCD		11	/* Card deactive */
#define PCSC_EVENT_ICCR		12	/* ICC removed */
#define PCSC_EVENT_CIS		13	/* Card InSerted */	
#define PCSC_EVENT_RRM		14	/* Reader ReMoved */
#define PCSC_EVENT_CDS		15	/* Card Deactive Success */
#define PCSC_EVENT_CDF		16	/* Card Deactive Failed */

#define PCSC_EVENT_COUNT	17

#define PCSC_EVENT_NAMES {	\
	"RIS",			\
	"ORS",			\
	"ORF",			\
	"CSS",			\
	"CSF",			\
	"TO",			\
	"ICCP",			\
	"ICCNP",		\
	"CAS",			\
	"CAF",			\
	"ICCA",			\
	"ICCD",			\
	"ICCR",			\
	"CIS",			\
	"RRM",			\
	"CDS",			\
	"CDF",			\
}

static void pcsc_raise_event(pcsc_reader_t *rd_ctx, int event)
{
	eloop_schedule_event(NULL, rd_ctx->fsmi, event, rd_ctx);
}

/* reader insert */
static void pcsc_raise_ris(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_RIS);
}

/* Open Reader Success */
static void pcsc_raise_ors(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ORS);
}
#ifdef NO_EVENT_ORF
/* Open Reader Failed */
static void pcsc_raise_orf(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ORF);
}
#endif

/* icC Status Success */
static void pcsc_raise_css(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CSS);
}

/* icC Status Failed */
static void pcsc_raise_csf(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CSF);
}

/* Time Out */
static void pcsc_raise_to(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_TO);
}

/* ICC Present */
static void pcsc_raise_iccp(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCP);
}

/* ICC Not Present */
static void pcsc_raise_iccnp(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCNP);
}

/* Card Active Success */
static void pcsc_raise_cas(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CAS);
}

/* Card Active Failed */
static void pcsc_raise_caf(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CAF);
}

/* ICC active */
static void pcsc_raise_icca(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCA);
}

/* ICC Deactive*/
static void pcsc_raise_iccd(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCD);
}

/* ICC removed*/
static void pcsc_raise_iccr(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCR);
}

/* Card InSerted */
static void pcsc_raise_cis(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CIS);
}

/* Reader ReMoved */
static void pcsc_raise_rrm(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_RRM);
}

/* Card Deactive Success */
static void pcsc_raise_cds(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CDS);
}

/* Card Deactive Fail */
static void pcsc_raise_cdf(pcsc_reader_t *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CDF);
}

static int pcsc_action_open(stm_instance_t *fsmi, void *data)
{
	pcsc_raise_ors(data);

	return 1;
}

static int pcsc_action_close(stm_instance_t *fsmi, void *data)
{
	pcsc_reader_t *rd_ctx;
	
	rd_ctx = (pcsc_reader_t *)data;
	rd_ctx->ops->close(-1);
	
	return 1;
}


static int pcsc_action_erc(stm_instance_t *fsmi, void *data)
{	
	eloop_register_timeout(NULL, 0, 0, pcsc_stm_exit_delay, NULL, data);

	return 1;
}

/* This "warm up" sequence is sometimes needed when pcscd is
 * restarted with the reader already connected. We get some
 * "usb_bulk_read: Resource temporarily unavailable" on the 
 * first few tries. It is an empirical hack*/
#define ICC_STATUS_RETRY_MAX	3
static int icc_status_retry = ICC_STATUS_RETRY_MAX;

static void icc_status_complete(pcsc_reader_t *rd_ctx)
{
	uint32_t icc_status;

	if (rd_ctx->ret != PCSC_S_SUCCESS) {
		if ((--icc_status_retry) > 0) {
			pcsc_raise_to(rd_ctx);
		} else {
			pcsc_raise_csf(rd_ctx);
			icc_status_retry = ICC_STATUS_RETRY_MAX;
		}
	} else {
		icc_status = rd_ctx->slot->card_status;
		if (icc_status & PCSC_CARD_PRESENT_MASK) {
			pcsc_raise_iccp(rd_ctx);
			/* FIXME: which icc_seq */
			rd_ctx->icc_seq++;
			/*
				rd_ctx->handle.reader.icc_seq++;
			*/
		} else {
			pcsc_raise_iccnp(rd_ctx);
		}
		icc_status_retry = ICC_STATUS_RETRY_MAX;
	}
}

static int pcsc_action_icc_status(stm_instance_t *fsmi, void *data)
{
	pcsc_ifd_t *rdr = (pcsc_ifd_t *)data;
	int r;
	
	rdr->cb = icc_status_complete;
	r = rdr->ops->icc_status(rdr);
	if (r == PCSC_S_SUCCESS)
		pcsc_raise_css(rdr);
	else
		pcsc_raise_csf(rdr);
	return 1;
}

static void power_on_complete(pcsc_reader_t *rd_ctx)
{
	struct pcsc_slot *slot;
	struct pcsc_atr_info atr_info;
	uint8_t atr[PCSC_MAX_ATR * 3];
	size_t i;

	if (rd_ctx->ret < 0) {
		if (rd_ctx->ret == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_caf(rd_ctx);
	} else {
		slot = rd_ctx->slot;
		slot->atr_len = rd_ctx->ret;
		if (pcsc_parse_atr(slot->atr, slot->atr_len, &atr_info) 
			== PCSC_S_SUCCESS) {
			slot->proto = atr_info.default_proto;
			slot->proto_supported = atr_info.supported_protos;

			for (i = 0; i < slot->atr_len; i++) {
				if (i == slot->atr_len - 1)
					sprintf(atr + i * 3, "%02X", slot->atr[i]);
				else 
					sprintf(atr + i * 3, "%02X:", slot->atr[i]);
			}
			pcsc_log(PCSC_LOG_DEBUG, "ATR: %s", atr);
			if (slot->proto_supported & PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_DEBUG, "Support protocol: T0");
			if (slot->proto_supported & PCSC_PROTOCOL_T1)
				pcsc_log(PCSC_LOG_DEBUG, "Support protocol: T1");

			if (slot->proto == PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_DEBUG, "Default protocol: T0");
		} else {
			slot->proto = PCSC_PROTOCOL_UNKNOWN;
			slot->proto_supported = PCSC_PROTOCOL_UNKNOWN;
		}	
		slot->card_status = PCSC_CARD_PRESENT_POWERUP;
		pcsc_raise_cas(rd_ctx);
	}
}

/* Active ICC*/
static int pcsc_action_aicc(stm_instance_t *fsmi, void *data)
{
	pcsc_reader_t *rd_ctx = (pcsc_reader_t *)data;
	int r;

	rd_ctx->cb = power_on_complete;
	r = rd_ctx->ops->power_on(rd_ctx);
	if (r == PCSC_S_SUCCESS)
		pcsc_raise_cas(rd_ctx);
	else {
		if (r == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_caf(rd_ctx);
	}	
	return 1;
}

static void power_off_complete(struct pcsc_reader_context *rd_ctx)
{
	if (rd_ctx->ret != PCSC_S_SUCCESS) {
		if (rd_ctx->ret == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_cdf(rd_ctx);
	} else {
		pcsc_raise_cds(rd_ctx);
	}
}

/* Deactive ICC*/
static int pcsc_action_dicc(stm_instance_t *fsmi, void *data)
{
	pcsc_reader_t *rd_ctx = (pcsc_reader_t *)data;
	int r;

	rd_ctx->cb = power_off_complete;
	r = rd_ctx->ops->power_off(rd_ctx);
	if (r != PCSC_S_SUCCESS) {
		if (r == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_cdf(rd_ctx);
	}	
	return 1;
}

/* Card Not Present*/
static int pcsc_action_cnp(stm_instance_t *fsmi, void *data)
{
	pcsc_reader_t *rd_ctx = (pcsc_reader_t *)data;
	int conn_num;

	rd_ctx->slot->card_status = PCSC_CARD_ABSENT;
#if 0
	conn_num = atomic_read(&rd_ctx->handle.refcnt);
	while (conn_num--) {
		pcsc_disconnect(&rd_ctx->handle);
	}
#endif
	return 1;
}

/* Clear handle*/
static int pcsc_action_chd(stm_instance_t *fsmi, void *data)
{
	pcsc_ifd_t *ifd = (pcsc_ifd_t *)data;
	
	ifd->ops->cancel(ifd);
	return 1;
}

static int pcsc_action_null(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static const stm_action_fn pcsc_act_open [] = {
	pcsc_action_open,
};

static const stm_action_fn pcsc_act_erc [] = {
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_close_erc [] = {
	pcsc_action_close,
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_icc_status [] = {
	pcsc_action_icc_status,
};

static const stm_action_fn pcsc_act_aicc [] = {
	pcsc_action_aicc,
};

static const stm_action_fn pcsc_act_cnp [] = {
	pcsc_action_cnp,
};

static const stm_action_fn pcsc_act_chd_cnp [] = {
	pcsc_action_chd,
	pcsc_action_cnp,
};

static const stm_action_fn pcsc_act_chd_dicc [] = {
	pcsc_action_chd,
	pcsc_action_dicc,
};


static const stm_action_fn pcsc_act_null [] = {
	pcsc_action_null,
};


#define STATE(state)	PCSC_STATE_##state
#define EVENT(event)	PCSC_EVENT_##event
#define ACTION(stem)	pcsc_act_##stem, \
		sizeof(pcsc_act_##stem) / sizeof(stm_action_fn) 

static const stm_entry_t pcsc_stm_entries[] = {
	/* state	event		action			new_state */
	{STATE(INIT),	EVENT(RIS),	ACTION(open),		STATE(OPEN),},

	{STATE(OPEN),	EVENT(ORS),	ACTION(icc_status),	STATE(CSTATUSING),},
#if 0
	{STATE(OPEN),	EVENT(ORF),	ACTION(erc),		STATE(EXIT),},
#endif
	{STATE(CSTATUSING),EVENT(CSS),	ACTION(null),		STATE(CSTATUSED),},
	{STATE(CSTATUSING),EVENT(CSF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(CSTATUSING),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(CSTATUSED),EVENT(CSF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(CSTATUSED),EVENT(TO),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(CSTATUSED),EVENT(ICCP),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(CSTATUSED),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(CSTATUSED),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},
	
	{STATE(PRESENT),EVENT(CAS),	ACTION(null),		STATE(POWERUP),},
	{STATE(PRESENT),EVENT(CAF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(PRESENT),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(PRESENT),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(PRESENT),EVENT(RRM),	ACTION(erc),		STATE(EXIT),},

	{STATE(ABSENT),	EVENT(CIS),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(ABSENT),	EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(POWERUP),EVENT(ICCA),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(POWERUP),EVENT(ICCD),	ACTION(chd_dicc),	STATE(DEACTIVE),},
	{STATE(POWERUP),EVENT(ICCR),	ACTION(chd_cnp),	STATE(ABSENT),},
	{STATE(POWERUP),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(DEACTIVE),EVENT(CDS),	ACTION(null),		STATE(POWERDOWN),},
	{STATE(DEACTIVE),EVENT(CDF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(DEACTIVE),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(DEACTIVE),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(DEACTIVE),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(POWERDOWN),EVENT(ICCA),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(POWERDOWN),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(POWERDOWN),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{0,		0,		ACTION(null),		0,},
};

static const char *pcsc_state_names[] = PCSC_STATE_NAMES;
static const char *pcsc_event_names[] = PCSC_EVENT_NAMES;

const stm_table_t pcsc_stm_table = {
	"pcsc",
	pcsc_stm_log,
	PCSC_STATE_COUNT,
	&pcsc_state_names[0],
	PCSC_EVENT_COUNT,
	&pcsc_event_names[0],
	pcsc_stm_entries,	
};

#undef STATE
#undef EVENT
#undef ACTION

int pcsc_reader_down(const char *filename)
{
#if 0
	int i;

	for(i = 0; i < PCSC_MAX_READERS;i ++) {
		if (reader_ctx[i]) {
			pcsc_raise_rrm(reader_ctx[i]);
		}
	}
#endif
	return PCSC_S_SUCCESS;
}

int pcsc_icc_poweron(int reader_idx)
{
#if 0
	if (reader_idx > PCSC_MAX_READERS)
		return PCSC_E_INVALID_PARAMETER;
	if (reader_ctx[reader_idx] == NULL)
		return PCSC_E_INVALID_HANDLE;
	pcsc_raise_icca(reader_ctx[reader_idx]);
#endif
	return PCSC_S_SUCCESS;
}

int pcsc_icc_poweroff(int reader_idx)
{
#if 0
	if (reader_idx > PCSC_MAX_READERS)
		return PCSC_E_INVALID_PARAMETER;
	if (reader_ctx[reader_idx] == NULL)
		return PCSC_E_INVALID_HANDLE;
	pcsc_raise_iccd(reader_ctx[reader_idx]);
#endif
	return PCSC_S_SUCCESS;
}

int pcsc_icc_insert(int reader_idx)
{
#if 0
	if (reader_idx > PCSC_MAX_READERS)
		return PCSC_E_INVALID_PARAMETER;
	if (reader_ctx[reader_idx] == NULL)
		return PCSC_E_INVALID_HANDLE;
	pcsc_raise_cis(reader_ctx[reader_idx]);
#endif
	return PCSC_S_SUCCESS;
}

int pcsc_icc_remove(int reader_idx)
{
#if 0
	if (reader_idx > PCSC_MAX_READERS)
		return PCSC_E_INVALID_PARAMETER;
	if (reader_ctx[reader_idx] == NULL)
		return PCSC_E_INVALID_HANDLE;
	pcsc_raise_iccr(reader_ctx[reader_idx]);
#endif
	return PCSC_S_SUCCESS;
}


static void pcsc_stm_exit(struct pcsc_reader_context *rd_ctx)
{
	if (rd_ctx->fsmi) {
		eloop_cleanup_events(NULL, rd_ctx->fsmi);
		stm_table_free(rd_ctx->fsmi);
	}
#if 0
	pcsc_release_reader_ctx(rd_ctx);
#endif
}

static void pcsc_stm_exit_delay(void *eloop, void *user_ctx) 
{
	pcsc_stm_exit((struct pcsc_reader_context *)user_ctx);
}


int pcsc_card_status(int reader_idx, int slot_idx, 
		     uint32_t *icc_status)
{
#if 0
	struct pcsc_reader *reader;

	if (reader_idx >= PCSC_MAX_READERS) {
		pcsc_log(PCSC_LOG_WARN, "There is not reader %d", reader_idx);
		return PCSC_E_INVALID_PARAMETER;
	}
	if (!reader_ctx[reader_idx])
		return PCSC_E_INVALID_HANDLE;
	reader = &reader_ctx[reader_idx]->handle.reader;

	if (slot_idx >= reader->nslots)
		return PCSC_E_INVALID_PARAMETER;
	*icc_status = reader->slot[slot_idx].card_status;
#endif
	return PCSC_S_SUCCESS;
}

pcsc_ifd_hd_t *pcsc_connect(int reader_idx, int slot_idx)
{
#if 0
	uint32_t icc_status;

	if (reader_idx >= PCSC_MAX_READERS)
		return NULL;
	if ( reader_ctx[reader_idx] == NULL)
		return NULL;
	if (atomic_read(&reader_ctx[reader_idx]->handle.refcnt) > 0)
		return NULL;
	if (slot_idx >= reader_ctx[reader_idx]->handle.reader.nslots)
		return NULL;
	icc_status = reader_ctx[reader_idx]->handle.reader.slot[slot_idx].card_status;
	if (!(icc_status & PCSC_CARD_PRESENT_MASK))
		return NULL;

	atomic_inc(&reader_ctx[reader_idx]->handle.refcnt);
	reader_ctx[reader_idx]->handle.icc_seq = 
			reader_ctx[reader_idx]->handle.reader.icc_seq;

	return &reader_ctx[reader_idx]->handle;
#endif
	return -1;
}

int pcsc_check_handle_valid(pcsc_ifd_hd_t *handle)
{
	if (!handle) return 0;

	return (handle->icc_seq == handle->reader->icc_seq);
}

int pcsc_disconnect(pcsc_ifd_hd_t *handle)
{
#if 0
	int i;

	for (i = 0; i < PCSC_MAX_READERS; i++) {
		if (reader_ctx[i] && &reader_ctx[i]->handle == handle) {
			atomic_dec(&reader_ctx[i]->handle.refcnt);
			return PCSC_S_SUCCESS;
		}
	}
#endif
	return PCSC_E_INVALID_HANDLE;
}

int pcsc_transmit(struct pcsc_transmit_param *param)
{
	pcsc_reader_t *rdr = param->handle->reader;

	return rdr->ops->xfr_block(-1, param);
}

int pcsc_ifd_control(struct pcsc_transmit_param *param)
{
	pcsc_ifd_ops *ops = param->handle->reader->ops;

	return ops->ifd_ctl(-1, param);		
}

/*
int pcsc_pin_verify(struct pcsc_transmit_param *param)
{
	const struct pcsc_ifd_driver *driver = param->handle->reader.driver;

	return driver->ops->pin_verify(param->handle->hd, param);
}

int pcsc_pin_modify(struct pcsc_transmit_param *param)
{
	const struct pcsc_ifd_driver *driver = param->handle->reader.driver;

	return driver->ops->pin_modify(param->handle->hd, param);
}
*/

DECLARE_LIST(pcsc_ifd_list);

#define for_each_ifd(rdr)	\
	list_for_each_entry(pcsc_ifd_t, rdr, &pcsc_ifd_list, link)

pcsc_reader_t *ifd_rdr_get(pcsc_reader_t *rdr)
{
	atomic_inc(&rdr->refcnt);
	return rdr;
}

void ifd_rdr_put(pcsc_reader_t *rdr)
{
	atomic_dec(&rdr->refcnt);
}

pcsc_ifd_t *ifd_find(const char *name, int type)
{
	pcsc_ifd_t *rdr;

	for_each_ifd(rdr) {
		if (strcasecmp(rdr->name, name) == 0 &&
		    rdr->type == type)
		    return rdr;
	}
	return NULL;
}

static pcsc_ifd_t *ifd_new(const char *name, int type, void *lower,
			   pcsc_ifd_ops *ops)
{
	pcsc_reader_t *rdr;

	rdr = malloc(sizeof (pcsc_reader_t));
	if (!rdr)
		goto err;

	memset(rdr, 0, sizeof (pcsc_reader_t));

	/* Here we only support one slot. 
	 * TODO: support multi-slots reader */
	rdr->slot = malloc(sizeof(struct pcsc_slot));
	if (!rdr->slot)
		goto err;
	memset(rdr->slot, 0, sizeof(struct pcsc_slot));
	rdr->slot[0].card_status = PCSC_CARD_STATUS_UNKNOWN;
	rdr->nslots = 1;

	atomic_set(&rdr->refcnt, 1);
	list_init(&rdr->link);
	rdr->type = type;
	rdr->name = strdup(name);
	rdr->lower = lower;
	rdr->reader_status = PCSC_READER_STATUS_PRESENT;
	rdr->icc_seq = 0;

	rdr->ops = ops;

	rdr->fsmi = stm_table_new(&pcsc_stm_table, rdr->name, PCSC_STATE_INIT);
	if (!rdr->fsmi)
		goto err;
	list_insert_before(&rdr->link, &pcsc_ifd_list);
	return rdr;
err:
	if (rdr->slot)
		free(rdr->slot);
	if (rdr->name) 
		free(rdr->name);
	free(rdr);
	return NULL;
}

static void ifd_free(pcsc_ifd_t *rdr)
{
	if (rdr->name) free(rdr->name);
	list_delete(&rdr->link);
	free(rdr);
}

/* lower reader up */
int ifd_handle_up(const char *name, int type, void *lower,
		  pcsc_ifd_ops *ops)
{
	pcsc_ifd_t *rdr = ifd_find(name, type);

	if (rdr) {
		pcsc_log(PCSC_LOG_INFO, "IFD: handle=%s/%d has up before",
			name, type);
		BUG();
	}
	
	rdr = ifd_new(name, type, lower, ops);
	
	if (rdr) {
		/* check whether support PinPad/Display */
		if (rdr->ops->get_feature)
			rdr->ops->get_feature(-1, rdr);
		/* reader sm start - reader insert event */
		pcsc_raise_ris(rdr);
	}

	return -1;
}

int ifd_handle_down(const char *name, int type, void *lower)
{
	pcsc_reader_t *rdr = ifd_find(name, type);
	
	/* reader sm stop  - reader remove event */
	if (rdr) {
		pcsc_raise_rrm(rdr);
		ifd_free(rdr);
	}
	return -1;
}

int ifd_icc_insert(void)
{
	return -1;
}

int ifd_icc_remove(void)
{
	return -1;
}