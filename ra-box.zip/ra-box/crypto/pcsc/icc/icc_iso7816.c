#include "../pcsc_priv.h"

#define ICC_DRIVER_7816_NAME		"ISO7816"

static int iso7816_drv_open(pcsc_icc_t *icc);
static int iso7816_drv_close(pcsc_icc_t *icc);

static icc_card_error_t iso7816_errors[] = {
	{ 0x6200, ICC_ERR_MEMORY_FAILURE,	"State of non-volatile memory unchanged" },
	{ 0x6281, ICC_ERR_MEMORY_FAILURE,	"Part of returned data may be corrupted" },
	{ 0x6282, ICC_ERR_CARD_CMD_FAILED,	"End of file/record reached before reading Le bytes" },
	{ 0x6283, ICC_ERR_CARD_CMD_FAILED,	"Selected file invalidated" },
	{ 0x6284, ICC_ERR_CARD_CMD_FAILED,	"FCI not formatted according to ISO 7816-4" },

	{ 0x6300, ICC_ERR_MEMORY_FAILURE,	"State of non-volatile memory changed" },
	{ 0x6381, ICC_ERR_CARD_CMD_FAILED,	"File filled up by last write" },

	{ 0x6581, ICC_ERR_MEMORY_FAILURE,	"Memory failure" },

	{ 0x6700, ICC_ERR_WRONG_LENGTH,		"Wrong length" },

	{ 0x6800, ICC_ERR_NO_CARD_SUPPORT,	"Functions in CLA not supported" },
	{ 0x6881, ICC_ERR_NO_CARD_SUPPORT,	"Logical channel not supported" },
	{ 0x6882, ICC_ERR_NO_CARD_SUPPORT,	"Secure messaging not supported" },

	{ 0x6900, ICC_ERR_NOT_ALLOWED,		"Command not allowed" },
	{ 0x6981, ICC_ERR_CARD_CMD_FAILED,	"Command incompatible with file structure" },
	{ 0x6982, ICC_ERR_UNAUTHORIZED,		"Security status not satisfied" },
	{ 0x6983, ICC_ERR_AUTH_BLOCKED,		"Authentication method blocked" },
	{ 0x6984, ICC_ERR_CARD_CMD_FAILED,	"Referenced data invalidated" },
	{ 0x6985, ICC_ERR_NOT_ALLOWED,		"Conditions of use not satisfied" },
	{ 0x6986, ICC_ERR_NOT_ALLOWED,		"Command not allowed (no current EF)" },
	{ 0x6987, ICC_ERR_INCORRECT_PARAM,	"Expected SM data objects missing" },
	{ 0x6988, ICC_ERR_INCORRECT_PARAM,	"SM data objects incorrect" },

	{ 0x6A00, ICC_ERR_INCORRECT_PARAM,	"Wrong parameter(s) P1-P2" },
	{ 0x6A80, ICC_ERR_INCORRECT_PARAM,	"Incorrect parameters in the data field" },
	{ 0x6A81, ICC_ERR_NO_CARD_SUPPORT,	"Function not supported" },
	{ 0x6A82, ICC_ERR_FILE_NOT_FOUND,	"File not found" },
	{ 0x6A83, ICC_ERR_RECORD_NOT_FOUND,	"Record not found" },
	{ 0x6A84, ICC_ERR_CARD_CMD_FAILED,	"Not enough memory space in the file" },
	{ 0x6A85, ICC_ERR_INCORRECT_PARAM,	"Lc inconsistent with TLV structure" },
	{ 0x6A86, ICC_ERR_INCORRECT_PARAM,	"Incorrect parameters P1-P2" },
	{ 0x6A87, ICC_ERR_INCORRECT_PARAM,	"Lc inconsistent with P1-P2" },
	{ 0x6A88, ICC_ERR_DATA_OBJ_NOT_FOUND,	"Referenced data not found" },

	{ 0x6B00, ICC_ERR_INCORRECT_PARAM,	"Wrong parameter(s) P1-P2" },
	{ 0x6D00, ICC_ERR_INS_NOT_SUPPORTED,	"Instruction code not supported or invalid" },
	{ 0x6E00, ICC_ERR_CLASS_NOT_SUPPORTED,	"Class not supported" },
	{ 0x6F00, ICC_ERR_CARD_CMD_FAILED,	"No precise diagnosis" },

	/* Possibly TCOS / Micardo specific errors */
	{ 0x6600, ICC_ERR_INCORRECT_PARAM,	"Error setting the security env"},
	{ 0x66F0, ICC_ERR_INCORRECT_PARAM,	"No space left for padding"},
	{ 0x69F0, ICC_ERR_NOT_ALLOWED,		"Command not allowed"},
	{ 0x6A89, ICC_ERR_FILE_EXISTS,		"Files exists"},
	{ 0x6A8A, ICC_ERR_FILE_EXISTS,		"Application exists"},
};

int iso7816_check_sw(pcsc_icc_t *icc, uint8_t sw1, uint8_t sw2)
{
	int err_count = sizeof(iso7816_errors)/sizeof(iso7816_errors[0]);
	int i;

	if (sw1 == 0x6C)
		return ICC_ERR_WRONG_LENGTH;
	if (sw1 == 0x90 || sw1 == 0x61)
		return ICC_SUCCESS;
	if (sw1 == 0x63 && (sw2 & ~0x0FU) == 0xC0U) 
		return ICC_ERR_PIN_CODE_INCORRECT;
	for (i = 0; i < err_count; i++) {
		if (iso7816_errors[i].SWs == ((sw1 << 8) | sw2))
			return iso7816_errors[i].errorno;
	}
	return ICC_ERR_CARD_CMD_FAILED;
}

static void iso7816_read_binary_complete(pcsc_transfer_t *transfer)
{
	pcsc_icc_trans_param *cmd_param = transfer->icc_param;
	struct icc_apdu *apdu = cmd_param->apdu;
	uint16_t offset;
	size_t rbuf_actual;
	int left, max_le = transfer->handle->icc->max_recv;

	if (transfer->ret != 0) {
		cmd_param->ret = transfer->ret;
	} else {

		cmd_param->ret = pcsc_fetch_check_sw(transfer);

		rbuf_actual = transfer->rbuf_actual - 2;

		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {

			if (rbuf_actual == 0)
				goto ret;
			
			memcpy(apdu->rx_buf, transfer->rbuf, rbuf_actual);
			apdu->actual_recv += rbuf_actual;
			cmd_param->ret = apdu->actual_recv;
			/* receive finished */
			if (apdu->actual_recv == apdu->rx_buflen)
				goto ret;
			/* left to send */
			left = apdu->rx_buflen - apdu->actual_recv;

			apdu->rx_buf += rbuf_actual;
			
			apdu->le = left > max_le ? max_le : left;
			offset = (apdu->p1 << 8) + apdu->p2 + rbuf_actual;
			apdu->p1 = (offset >> 8) & 0x7F;
			apdu->p2 = offset & 0xFF;
			pcsc_update_tpdu(transfer);
			if (pcsc_transmit(transfer) == 0)
				return;
			else
				cmd_param->ret = -1;
		} else if (apdu->sw1 == 0x6C) {
			/* FIXME: need realloc? */
			BUG_ON(apdu->sw2 > apdu->rx_buflen);
			/* wrong le, retry with new length */
			apdu->le = apdu->sw2;
			/* XXX: update rx_buflen be cardful */
			apdu->rx_buflen = apdu->sw2;
			pcsc_update_tpdu(transfer);
			if (pcsc_transmit(transfer) == 0)
				return;
			else
				cmd_param->ret = -1;
		}
	}
ret:
	transfer->ret = cmd_param->ret;
	cmd_param->callback(transfer);
	icc_trans_param_free(cmd_param);
}

int iso7816_read_binary(pcsc_slot_t *slot, uint32_t offset,
			uint8_t *rbuf, size_t rbuf_len, uint32_t flags,
			pcsc_trans_cb callback,	pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	const uint32_t max_le = slot->icc->max_recv;
	int r;
	int cse;	/*apdu case*/
	uint8_t cla, ins, p1, p2;
	uint32_t lc, le;

	if (offset > 0x7FFF)
		return -1;

	cmd_param = icc_trans_param_new();
	if (!cmd_param)
		return -1;


	cse = ICC_APDU_CASE_2_SHORT;
	cla = slot->icc->cla;
	ins = ICC_APDU_INS_READ_BINARY;
	p1 = (uint8_t)((offset >> 8) & 0x7F);
	p2 = (uint8_t)(offset & 0xFF);
	le = rbuf_len > max_le ? max_le : rbuf_len;
	lc = 0;

	apdu = pcsc_build_apdu(cse, cla, ins, p1, p2, lc, le, NULL, 0);
	if (!apdu) {
		icc_trans_param_free(cmd_param);
		return -2;	
	}
	apdu->rx_buf = rbuf;
	apdu->rx_buflen = rbuf_len;
	cmd_param->apdu = apdu;
	cmd_param->callback = callback;
	card_param->icc_param = cmd_param;

	r = pcsc_transmit_from_icc(card_param,
				   iso7816_read_binary_complete);	
	if (r != 0)
		icc_trans_param_free(cmd_param);
	return r;
}

static void iso7816_write_update_binary_complete(pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param = card_param->icc_param;
	struct icc_apdu *apdu = cmd_param->apdu;
	pcsc_slot_t *card_handle = card_param->handle;
	uint32_t max_lc = card_handle->icc->max_send;
	size_t transmitted;
	uint16_t offset;
	int r;

	if (card_param->ret != 0) {
		cmd_param->ret = card_param->ret;
	} else {
		cmd_param->ret = pcsc_fetch_check_sw(card_param);
		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
			transmitted = apdu->lc;
			if (transmitted == 0) {
				cmd_param->ret = cmd_param->sbuf_transmitted;
				goto ret;
			}
			cmd_param->sbuf_transmitted += transmitted;
			if (cmd_param->sbuf_transmitted == cmd_param->sbuf_len) {
				cmd_param->ret = cmd_param->sbuf_transmitted;
				goto ret;
			}

			apdu->tx_buflen -= transmitted;
			apdu->tx_buf += transmitted;
			apdu->lc = MIN(apdu->tx_buflen, max_lc);

			offset = (apdu->p1 << 8) + apdu->p2 + transmitted;
			apdu->p1 = (offset >> 8) & 0x7F;
			apdu->p2 = offset & 0xFF;
			
			r = pcsc_transmit_from_icc(card_param, iso7816_write_update_binary_complete);
			if (0 == r)
				return;
			else
				cmd_param->ret = r;
		}
	}
ret:
	card_param->ret = cmd_param->ret;
	cmd_param->callback(card_param);
	free(apdu);	
	free(cmd_param);
}

int iso7816_write_binary(pcsc_slot_t *card_handle, uint32_t offset,
			 uint8_t *sbuf, size_t sbuf_len, uint32_t flags,
			 pcsc_trans_cb callback, 
			 pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	uint32_t max_lc = card_handle->icc->max_send;
	int r;
	int cse;	/*apdu case*/
	uint8_t cla, ins, p1, p2;
	uint32_t lc, le;
	uint8_t *data;
	size_t datalen;

	if (offset > 0x7FFF)
		return -1;

	cmd_param = malloc(sizeof (pcsc_icc_trans_param));
	if (!cmd_param)
		return -1;
	memset(cmd_param, 0, sizeof (pcsc_icc_trans_param));
	cmd_param->sbuf = sbuf;
	cmd_param->sbuf_len = sbuf_len;
	cmd_param->sbuf_transmitted = 0;
	cmd_param->callback = callback;

	cse = ICC_APDU_CASE_3_SHORT;
	cla = card_handle->icc->cla;
	ins = 0xD0;
	p1 =  (uint8_t)((offset >> 8) & 0x7F);
	p2 = (uint8_t)(offset & 0xFF);
	lc = MIN(cmd_param->sbuf_len, max_lc);
	data = cmd_param->sbuf;
	datalen = cmd_param->sbuf_len;
	le = 0;
	apdu = pcsc_build_apdu(cse, cla, ins, p1, p2, lc, le, data, datalen);
	if (!apdu) {
		free(cmd_param);
		return -1;
	}

	cmd_param->apdu = apdu;
	card_param->icc_param = cmd_param;

	r = pcsc_transmit_from_icc(card_param, iso7816_write_update_binary_complete);	
	if (r != 0) {
		free(apdu);
		free(cmd_param);
	}

	return r;
}

int iso7816_update_binary(pcsc_slot_t *card_handle, uint32_t offset,
			  uint8_t *sbuf, size_t sbuf_len, uint32_t flags,
			  pcsc_trans_cb callback, 
			  pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	uint32_t max_lc = card_handle->icc->max_send;
	int r;
	int cse;	/*apdu case*/
	uint8_t cla, ins, p1, p2;
	uint32_t lc, le;
	uint8_t *data;
	size_t datalen;

	if (offset > 0x7FFF)
		return -1;

	cmd_param = malloc(sizeof(pcsc_trans_param));
	if (!cmd_param)
		return -1;
	memset(cmd_param, 0, sizeof(pcsc_trans_param));
	cmd_param->sbuf = sbuf;
	cmd_param->sbuf_len = sbuf_len;
	cmd_param->sbuf_transmitted = 0;
	cmd_param->callback = callback;

	cse = ICC_APDU_CASE_3_SHORT;
	cla = card_handle->icc->cla;
	ins = 0xD6;
	p1 =  (uint8_t)((offset >> 8) & 0x7F);
	p2 = (uint8_t)(offset & 0xFF);
	lc = (cmd_param->sbuf_len > max_lc) ? max_lc : cmd_param->sbuf_len;
	data = cmd_param->sbuf;
	datalen = cmd_param->sbuf_len;
	le = 0;

	apdu = pcsc_build_apdu(cse, cla, ins, p1, p2, lc, le, data, datalen);
	if (!apdu) {
		free(cmd_param);
		return -1;
	}

	cmd_param->apdu = apdu;
	card_param->icc_param = cmd_param;

	r = pcsc_transmit_from_icc(card_param, iso7816_write_update_binary_complete);	
	if (r != 0) {
		free(apdu);
		free(cmd_param);
	}

	return r;
}

static void iso7816_read_record_complete(pcsc_transfer_t *card_param)
{
	pcsc_trans_param *cmd_param = card_param->icc_param;
	struct icc_apdu *apdu = cmd_param->apdu;
	int r, rbuf_actual;

	if (card_param->ret != 0) {
		cmd_param->ret = card_param->ret;
		goto out;
	}
	
	cmd_param->ret = pcsc_fetch_check_sw(card_param);
	rbuf_actual = card_param->rbuf_actual - 2;

	if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
		cmd_param->ret = apdu->le;
		memcpy(apdu->rx_buf, card_param->rbuf, rbuf_actual);
	} else if (apdu->sw1 == 0x6C) {
		/* wrong le, retry with new length */
		apdu->le = apdu->sw2;
		pcsc_update_tpdu(card_param);
		r = pcsc_transmit(card_param);
		if (r != 0) {
			cmd_param->ret = r;
			goto out;
		}
		return;
	}
out:
	card_param->ret = cmd_param->ret;
	cmd_param->callback(card_param);
	free(apdu);
	free(cmd_param);
}

int iso7816_read_record(pcsc_slot_t *card_handle, int rec_nr, 
			uint8_t *rec_buf, size_t rec_len, uint32_t flags,
			pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	int r;

	cmd_param = malloc(sizeof(pcsc_icc_trans_param));
	if (!cmd_param)
		return -3;
	memset(cmd_param, 0, sizeof(pcsc_icc_trans_param));
	cmd_param->callback = callback;

	apdu = malloc(sizeof(struct icc_apdu));
	if (!apdu) {
		free(cmd_param);
		return -3;
	}
	memset(apdu, 0, sizeof(struct icc_apdu));
	apdu->cse = ICC_APDU_CASE_2_SHORT;
	apdu->cla = card_handle->icc->cla;
	apdu->ins = 0xB2;
	apdu->p1 = rec_nr;
	apdu->p2 = (uint8_t)((flags & ICC_RECORD_EF_ID_MASK) << 3);
	if (flags & ICC_RECORD_BY_REC_NR)
		apdu->p2 |= 0x04;
	apdu->le = rec_len;
	apdu->rx_buf = rec_buf;
	apdu->rx_buflen = rec_len;

	cmd_param->apdu = apdu;
	card_param->icc_param = cmd_param;

	r = pcsc_transmit_from_icc(card_param, iso7816_read_record_complete);	
	if (r != 0) {
		free(apdu);
		free(cmd_param);
	}

	return r;
}

static void iso7816_write_record_complete(pcsc_transfer_t *card_param)
{
	pcsc_trans_param *cmd_param = card_param->icc_param;
	struct icc_apdu *apdu = cmd_param->apdu;

	if (card_param->ret != 0) {
		cmd_param->ret = card_param->ret;
	} else {
		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00)
			cmd_param->ret = apdu->lc;
		else 
			cmd_param->ret = pcsc_fetch_check_sw(card_param);
	}

	card_param->ret = cmd_param->ret;
	cmd_param->callback(card_param);
	free(apdu);
	free(cmd_param);
}

int iso7816_write_record(pcsc_slot_t *card_handle, uint8_t rec_nr, 
		      uint8_t *rec_buf, size_t rec_len, uint32_t flags,
			pcsc_trans_cb callback, 
			pcsc_transfer_t *card_param)
{	
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	int r;

	cmd_param = malloc(sizeof(pcsc_icc_trans_param));
	if (!cmd_param) 
		return -3;
	memset(cmd_param, 0, sizeof(pcsc_icc_trans_param));
	cmd_param->sbuf = rec_buf;
	cmd_param->sbuf_len = rec_len;
	cmd_param->callback = callback;

	apdu = malloc(sizeof(struct icc_apdu));
	if (!apdu) {
		free(cmd_param);
		return -3;
	}
	memset(apdu, 0, sizeof(struct icc_apdu));
	apdu->cse = ICC_APDU_CASE_3_SHORT;
	apdu->cla = card_handle->icc->cla;
	apdu->ins = 0xD2;
	apdu->p1 = rec_nr;
	apdu->p2 = (uint8_t)((flags & ICC_RECORD_EF_ID_MASK) << 3);
	if (flags & ICC_RECORD_BY_REC_NR)
		apdu->p2 |= 0x04;
	apdu->lc = cmd_param->sbuf_len;
	apdu->tx_buf = cmd_param->sbuf;
	apdu->tx_buflen = cmd_param->sbuf_len;

	cmd_param->apdu = apdu;
	card_param->icc_param = cmd_param;

	r = pcsc_transmit_from_icc(card_param, iso7816_write_record_complete);	
	if (r != 0) {
		free(apdu);
		free(cmd_param);
	}

	return r;
}

static void iso7816_append_record_complete(pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param = card_param->icc_param;
	struct icc_apdu *apdu = cmd_param->apdu;

	if (card_param->ret != 0){
		cmd_param->ret = card_param->ret;
	} else {
		cmd_param->ret = pcsc_fetch_check_sw(card_param);
		if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00)
			cmd_param->ret = apdu->lc;			
	}
	card_param->ret = cmd_param->ret;
	cmd_param->callback(card_param);
	free(apdu);
	free(cmd_param);
}

int iso7816_append_record(pcsc_slot_t *card_handle,
			  uint8_t *rec_buf, size_t rec_len, uint32_t flags,
			  pcsc_trans_cb callback, 
			  pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	int r;

	cmd_param = malloc(sizeof(pcsc_icc_trans_param));
	if (!cmd_param)
		return -3;
	memset(cmd_param, 0, sizeof(pcsc_icc_trans_param));
	cmd_param->sbuf = rec_buf;
	cmd_param->sbuf_len = rec_len;
	cmd_param->callback = callback;

	apdu = malloc(sizeof(struct icc_apdu));
	if (!apdu) {
		free(cmd_param);
		return -3;
	}
	memset(apdu, 0, sizeof(struct icc_apdu));
	apdu->cse = ICC_APDU_CASE_3_SHORT;
	apdu->cla = card_handle->icc->cla;
	apdu->ins = 0xE2;
	apdu->p1 = 0x00;
	apdu->p2 = (uint8_t)((flags & ICC_RECORD_EF_ID_MASK) << 3);
	apdu->lc = rec_len;
	apdu->tx_buf = cmd_param->sbuf;
	apdu->tx_buflen = cmd_param->sbuf_len;

	cmd_param->apdu = apdu;
	card_param->icc_param = cmd_param;

	r = pcsc_transmit_from_icc(card_param, iso7816_append_record_complete);	
	if (r != 0) {
		free(cmd_param);
		free(apdu);
	}

	return r;
}

static void iso7816_update_record_complete(pcsc_transfer_t *transfer)
{
	pcsc_icc_trans_param *icc_param = transfer->icc_param;
	struct icc_apdu *apdu = icc_param->apdu;
	int rbuf_actual;

	if (transfer->ret < PCSC_S_SUCCESS) {
		icc_param->ret = transfer->ret;
		goto out;
	}
	icc_param->ret = pcsc_fetch_check_sw(transfer);
	/* skip sw1, sw2 */
	rbuf_actual = transfer->rbuf_actual - 2;

	if (icc_param->ret != 0)
		goto out;

	if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) 
		icc_param->ret = apdu->lc;
	else {
	}
		/* TODO */;
out:
	transfer->ret = icc_param->ret;
	icc_param->callback(transfer);
	free(apdu);
	free(icc_param);
}

/* update or add record */
/* make sure the TLV record is right and 
 * if update record the length must fix the older one */
int iso7816_update_record(pcsc_slot_t *card_handle, uint8_t rec_nr,
		          uint8_t *rec_buf, size_t rec_len, uint32_t flags,
			  pcsc_trans_cb callback, 
			  pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	int r;

	cmd_param = malloc(sizeof(pcsc_icc_trans_param));
	if (!cmd_param) 
		return -3;
	memset(cmd_param, 0, sizeof(pcsc_icc_trans_param));
	cmd_param->sbuf = rec_buf;
	cmd_param->sbuf_len = rec_len;
	cmd_param->callback = callback;

	apdu = malloc(sizeof(struct icc_apdu));
	if (!apdu) {
		free(cmd_param);
		return -3;
	}
	memset(apdu, 0, sizeof(struct icc_apdu));
	apdu->cse = ICC_APDU_CASE_3_SHORT;
	apdu->cla = card_handle->icc->cla;
	apdu->ins = ICC_APDU_INS_UPDATE_RECORD;
	apdu->p1 = rec_nr;
	apdu->p2 = (uint8_t)((flags & ICC_RECORD_EF_ID_MASK) << 3);
	if (flags & ICC_RECORD_BY_REC_NR)
		apdu->p2 |= 0x04;
	apdu->lc = rec_len;
	apdu->tx_buf = cmd_param->sbuf;
	apdu->tx_buflen = cmd_param->sbuf_len;
	
	cmd_param->apdu = apdu;
	card_param->icc_param = cmd_param;

	r = pcsc_transmit_from_icc(card_param, iso7816_update_record_complete);	
	if (r != 0) {
		free(apdu);
		free(cmd_param);
	}

	return r;
}

int iso7816_process_fci(pcsc_slot_t *handle, 
			struct icc_file *file_out,
			const uint8_t *buf, size_t buf_len)
{
	size_t L, len = buf_len;
	const uint8_t *V = NULL, *p = buf;
	int fcilen;
	
	BUG_ON(p[0] != ICC_FCI_TAG_FCI);

	fcilen = p[1];
	p++;
	p++;

	V = icc_asn1_find_tag(p, len, ICC_FCI_TAG_FID, &L);
	if (V != NULL && L == 2)
		file_out->id = (V[0] << 8) | V[1];
	
	V = icc_asn1_find_tag(p, len, ICC_FCI_TAG_SIZE, &L);
	if (V != NULL && L >= 2)
		file_out->size = (V[0] << 8) + V[1];
	if (V == NULL) {
		V = icc_asn1_find_tag(p, len, ICC_FCI_TAG_ANY, &L);
		if (V && L >= 2)
			file_out->size = (V[0] << 8) + V[1];
	}

	V = icc_asn1_find_tag(p, len, ICC_FCI_TAG_FD, &L);
	if (V) {
		uint8_t byte = V[0];

		file_out->shareable = byte & 0x40 ? 1 : 0;
		file_out->ef_structure = byte & 0x07;
		switch ((byte >> 3) & 7) {
		case 0:
			file_out->type = ICC_FILE_TYPE_WORKING_EF;
			break;
		case 1:
			file_out->type = ICC_FILE_TYPE_INTERNAL_EF;
			break;
		case 7:
			file_out->type = ICC_FILE_TYPE_DF;
			break;
		default:
			break;
		}
	}

	V = icc_asn1_find_tag(p, len, ICC_FCI_TAG_DF_NAME, &L);
	if (V && L > 0 && L <= 16) {
		memcpy(file_out->df_name, V, L);
		file_out->df_name_len = L;
	}

	V = icc_asn1_find_tag(p, len, ICC_FCI_TAG_PROPRIETARY, &L);
	if (V && L)
		icc_file_set_prop_attr(file_out, V, L);
	else
		file_out->prop_attr_len = 0;
	
	V = icc_asn1_find_tag(p, len, ICC_FCI_TAG_SPEC, &L);
	if (V && L)
		icc_file_set_prop_attr(file_out, V, L);

	V = icc_asn1_find_tag(p, len, ICC_FCI_TAG_SECURITY, &L);
	if (V && L)
		icc_file_set_sec_attr(file_out, V, L);

	return ICC_SUCCESS;
}

static void iso7826_select_file_complete(pcsc_transfer_t *card_param)
{
#if 0
	pcsc_trans_param *cmd_param = card_param->cmd_param;
	struct icc_apdu *apdu = card_param->apdu;
	pcsc_slot_t *card_handle = card_param->handle;

	if (card_param->ret != ICC_SUCCESS) {
		cmd_param->ret = card_param->ret;
	} else {
		cmd_param->ret = pcsc_fetch_check_sw(card_param);

		if (cmd_param->file_out && 
				(apdu->sw1 == 0x90 &&  apdu->sw2 == 0x00)) {
			struct icc_file *file;

			cmd_param->rbuf_actual = cmd_param->rbuf_len 
						- apdu->resplen;
#if 0
			scard_log_xxd(SCARD_LOG_DEBUG, "FCI: ", 
				cmd_param->rbuf, cmd_param->rbuf_actual);
#endif
			file = icc_file_new();
			if (!file) {
				cmd_param->ret = ICC_ERR_NO_MEM;
			} else {
				cmd_param->ret = pcsc_icc_ops(card_handle)->process_fci(card_param->handle,
					file, cmd_param->rbuf, cmd_param->rbuf_actual);
				if (cmd_param->ret == ICC_SUCCESS)
					*cmd_param->file_out = file;
				else
					icc_file_free(file);
			}
		}
	
	}
	card_param->ret = cmd_param->ret;
	cmd_param->callback(card_param);

	if (cmd_param->rbuf) free(cmd_param->rbuf);
	free(apdu);	
	free(cmd_param);

#endif
}

int iso7816_select_file(pcsc_slot_t *card_handle, 
			struct icc_path *in_path,
			struct icc_file **file_out, 
			pcsc_trans_cb callback, pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	uint8_t pathbuf[ICC_PATH_MAX], *path = pathbuf;
	int pathlen;
	uint8_t *fci_buf = NULL;
	size_t fcibuf_len = 0;
	int r;

	cmd_param = malloc(sizeof(pcsc_icc_trans_param));
	if (!cmd_param) {
		return ICC_ERR_NO_MEM;
	}
	memset(cmd_param, 0, sizeof(pcsc_icc_trans_param));
	
	cmd_param->file_out = file_out;
	cmd_param->callback = callback;
	if (file_out != NULL) {
		fcibuf_len = ICC_APDU_BUFFER_MAX;
		fci_buf = malloc(fcibuf_len);
		if (!fci_buf) {
			free(cmd_param);
			return ICC_ERR_NO_MEM;
		}
	}
	apdu = malloc(sizeof(struct icc_apdu));
	if (!apdu) {
		if (fci_buf) free(fci_buf);
		free(cmd_param);
		return ICC_ERR_NO_MEM;
	}
	memset(apdu, 0, sizeof(struct icc_apdu));

	apdu->cse = ICC_APDU_CASE_4_SHORT;
	apdu->cla = card_handle->icc->cla;
	apdu->ins = 0xA4;

	memcpy(path, in_path->value, in_path->len);
	pathlen = in_path->len;

	switch(in_path->type) {
	case ICC_PATH_TYPE_FILE_ID:
		apdu->p1 = 0x00;
		if (pathlen != 2) {
			if (fci_buf) free(fci_buf);
			free(cmd_param);
			free(apdu);
			return ICC_ERR_INVALID_ARGS;
		}
		break;
	case ICC_PATH_TYPE_DF_NAME:
		apdu->p1 = 0x04;
		break;
	case ICC_PATH_TYPE_PATH:
		apdu->p1 = 0x08;
		if (pathlen >= 2 && memcmp(path, "\x3F\x00", 2) == 0) {
			if (pathlen == 2) {
				apdu->p1 = 0x00;
				break;
			}
			path += 2;
			pathlen -= 2;
		}
		break;
	case ICC_PATH_TYPE_FROM_CURRENT:
		apdu->p1 = 9;
		break;
	case ICC_PATH_TYPE_PARENT:
		apdu->p1 = 0x03;
		pathlen = 0;
		apdu->cse = ICC_APDU_CASE_2_SHORT;
		break;
	default:
		free(cmd_param);
		free(apdu);
		return ICC_ERR_INVALID_ARGS;
	}
	apdu->p2 = 0;
	apdu->lc = pathlen;
	apdu->tx_buf = path;
	apdu->tx_buflen = pathlen;
	if (file_out) {
		apdu->rx_buf = fci_buf;
		apdu->rx_buflen = fcibuf_len;
		apdu->le = fcibuf_len - 2; /* FIXME: why - 2 ? */
	}

	cmd_param->apdu = apdu;
	card_param->icc_param = cmd_param;

	r = pcsc_transmit_from_icc(card_param, iso7826_select_file_complete);	
	if (r != ICC_SUCCESS) {
		if (fci_buf) free(fci_buf);
		free(cmd_param);
		free(apdu);
	}

	return r;
}

int iso7816_get_response(pcsc_transfer_t *card_param, 
				uint8_t *resp, size_t resp_len, uint32_t le)
{
	struct icc_apdu *apdu = card_param->icc_param->apdu;
	
	/* XXX: do not clear */
	/* memset(apdu, 0, sizeof(struct icc_apdu)); */

	apdu->cse = ICC_APDU_CASE_2_SHORT;
	apdu->cla = card_param->handle->icc->cla;
	apdu->ins = 0xC0;
	apdu->p1 = 0x00;
	apdu->p2 = 0x00;
	apdu->lc = 0;
	apdu->tx_buf = NULL;
	apdu->le = le;
	
	pcsc_update_tpdu(card_param);
	return pcsc_transmit(card_param);
}
static void iso7816_get_challenge_complete(pcsc_transfer_t *card_param)
{
	pcsc_trans_param *cmd_param = card_param->icc_param;
	struct icc_apdu *apdu = cmd_param->apdu;

	if (card_param->ret != 0) {
		cmd_param->ret = card_param->ret;
	} else {
		cmd_param->ret = pcsc_fetch_check_sw(card_param);
		if (apdu->rx_buflen != 0) { /* left 0, that is there are 8 bytes in resp */
			/* TODO */;

		} else if (apdu->sw1 == 0x90 && apdu->sw2 == 0x00) {
			size_t left = card_param->rbuf_len - card_param->rbuf_actual;
			size_t n = left > 8 ? 8 : left;
			
			apdu->rx_buf -= 8;
			memcpy(card_param->rbuf + card_param->rbuf_actual, 
				apdu->rx_buf, n);
			card_param->rbuf_actual += n;

			if (card_param->rbuf_actual == card_param->rbuf_len) {
				cmd_param->ret = card_param->rbuf_actual;
			} else {
				memset(apdu->rx_buf, 0, 8);
				apdu->rx_buflen = 8;
				/**/
				BUG();
				cmd_param->ret = pcsc_transmit(card_param);
				if (cmd_param->ret == 0)
					return;
			}
		} else {
			cmd_param->ret = pcsc_fetch_check_sw(card_param);
		}
	}

	card_param->ret = cmd_param->ret;
	cmd_param->callback(card_param);
	free(apdu->rx_buf);
	free(apdu);
	free(cmd_param);
}

int iso7816_get_challenge(pcsc_slot_t *card_handle,
			  uint8_t *rnd, size_t rnd_len,
			  pcsc_trans_cb callback, pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	int r;

	cmd_param = malloc(sizeof(pcsc_icc_trans_param));
	if (!cmd_param)
		return -3;
	memset(cmd_param, 0, sizeof(pcsc_icc_trans_param));
#if 0
	cmd_param->rbuf = rnd;
	cmd_param->rbuf_len = rnd_len;
#endif
	cmd_param->callback = callback;

	apdu = malloc(sizeof(struct icc_apdu));
	if (!apdu) {
		free(cmd_param);
		return -3;
	}
	memset(apdu, 0, sizeof(struct icc_apdu));
	apdu->cse = ICC_APDU_CASE_2_SHORT;
	apdu->cla = card_handle->icc->cla;
	apdu->ins = 0x84;
	apdu->le = 0x08;
	apdu->rx_buf = malloc(8 *sizeof(uint8_t));
	if (apdu->rx_buf == NULL) {
		free(apdu);
		free(cmd_param);
		return -3;
	}
	memset(apdu->rx_buf, 0, 8 *sizeof(uint8_t));
	apdu->rx_buflen = 0x08;

	cmd_param->apdu = apdu;
	card_param->icc_param = cmd_param;

	r = pcsc_transmit_from_icc(card_param, iso7816_get_challenge_complete);
	if (r != 0) {
		free(apdu->rx_buf);
		free(apdu);
		free(cmd_param);
	}
	return r;
}

#ifdef NO_REF
static int iso7816_build_pin_apdu(pcsc_slot_t *card_handle, 
				  struct icc_apdu *apdu, 
				  struct icc_pin_cmd_data *pin_cmd,
				  uint8_t *sbuf, size_t sbuf_len)
{
	int r, len = 0, pad = 0, use_pin_pad = 0;
	uint8_t ins, p1 = 0;

	switch (pin_cmd->pin_type) {
	case ICC_AC_CHV:
		break;
	default:
		return ICC_ERR_INVALID_ARGS;
	}

	if (pin_cmd->flags & ICC_PIN_CMD_NEED_PADDING)
		pad = 1;
	if (pin_cmd->flags & ICC_PIN_CMD_USE_PINPAD)
		use_pin_pad = 1;
	
	pin_cmd->pin1.offset = 5;
	
	switch (pin_cmd->cmd) {
	case ICC_PIN_CMD_VERIFY:
		ins = 0x20;
		if ((r = icc_build_pin(sbuf, sbuf_len, &pin_cmd->pin1, pad)) < 0)
			return r;
		len = r;
		break;
	case ICC_PIN_CMD_CHANGE:
		ins = 0x24;
		if (pin_cmd->pin1.len != 0 || use_pin_pad) {
			if ((r = icc_build_pin(sbuf, sbuf_len, &pin_cmd->pin1,
					pad)) < 0)
					return r;
			len += r;		
		} else {
			/* Implicit test */
			p1 = 1;
		}
		pin_cmd->pin2.offset = pin_cmd->pin1.offset + len;
		if ((r = icc_build_pin(sbuf + len, sbuf_len - len, &pin_cmd->pin2,
			pad)) < 0)
			return r;
		len += r;
		break;
	case ICC_PIN_CMD_UNBLOCK:
		ins = 0x2C;
		if (pin_cmd->pin1.len != 0 || use_pin_pad) {
			if ((r = icc_build_pin(sbuf, sbuf_len, &pin_cmd->pin1, pad)) < 0)
				return r;
			len += r;
		} else {
			p1 += 0x02;
		}
		if (pin_cmd->pin2.len != 0 || use_pin_pad) {
			pin_cmd->pin2.offset = pin_cmd->pin1.offset + len;
			if ((r = icc_build_pin(sbuf + len, sbuf_len - len, 
					&pin_cmd->pin2, pad)) < 0)
					return r;
			len += r;
		} else {
			p1 |= 0x01;
		}
		break;
	default:
		return ICC_ERR_NOT_SUPPORTED;
	}
	
	apdu->cse = ICC_APDU_CASE_3_SHORT;
	apdu->cla = card_handle->cla;
	apdu->ins = ins;
	apdu->p1 = p1;
	apdu->p2 = pin_cmd->pin_ref;
	apdu->lc = len;
	apdu->data = sbuf;
	apdu->datalen = len;
	apdu->resplen = 0;
	
	return 0;
}
static void iso7816_pin_cmd_complete(pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param = card_param->icc_trans;
	struct icc_apdu *apdu = cmd_param->apdu;

	if (card_param->ret != 0)
		cmd_param->ret = card_param->ret;
	else {
		cmd_param->ret = pcsc_fetch_check_sw(card_param);
	}
	card_param->ret = cmd_param->ret;
	cmd_param->callback(card_param);
	free(apdu->resp);
/*	if (!(card_param->flags & SCARD_CARD_PARAM_FLAG_NOT_FREE_APDU))*/
	free(apdu);
	free(cmd_param);
}

static int iso7816_pin_cmd(pcsc_slot_t *card_handle,
			   struct icc_pin_cmd_data *pin_cmd, int tries_left, 
			   pcsc_trans_cb callback, pcsc_transfer_t *card_param)
{
#if 0
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	uint8_t pin_buf[ICC_APDU_BUFFER_MAX];
	int r;
	
	cmd_param = malloc(sizeof(pcsc_icc_trans_param));
	if (!cmd_param) 
		return -3;
	memset(cmd_param, 0, sizeof(pcsc_icc_trans_param));
	cmd_param->callback = callback;
	
	/* See if we've been called from another card driver, which is
	 * passing an APDU to us (this allows to write card drivers
	 * whose PIN functions behave "mostly like ISO" except in some
	 * special circumstances.
	 */
	if (pin_cmd->apdu == NULL) {
		apdu = malloc(sizeof(struct icc_apdu));
		if (!apdu) {
			free(cmd_param);
			return -3;
		}
		memset(apdu, 0, sizeof(struct icc_apdu));
		r = iso7816_build_pin_apdu(card_handle, apdu, pin_cmd,  
			pin_buf, sizeof(pin_buf));
		if (r < 0) {
			free(cmd_param);
			free(apdu);
			return r;
		}
	} else {
		apdu = pin_cmd->apdu;
	}
	
	cmd_param->apdu = apdu;
	card_param->icc_trans = cmd_param;

/*
	if (pin_cmd->apdu)
		card_param->flags |= SCARD_CARD_PARAM_FLAG_NOT_FREE_APDU;
*/	
	if (!(pin_cmd->flags & ICC_PIN_CMD_USE_PINPAD)) {
		r = pcsc_transmit_from_icc(card_param, iso7816_pin_cmd_complete);
		memset(pin_buf, 0, sizeof(pin_buf));
	} else {
		/* Call the reader driver to collect
		 * the PIN and pass on the APDU to the card 
		 */
		if (pin_cmd->pin1.offset == 0) {
			pcsc_log(PCSC_LOG_ERR, "ICC: Card driver didn't set PIN offset ");
			free(cmd_param);
			if (pin_cmd->apdu = NULL) free(apdu);
			return SCARD_ERR_INVALID_ARGS;
		}
		r = scard_reader_pin_cmd(card_param, pin_cmd);
	}

	if (r != 0) {
		free(cmd_param);
		if (pin_cmd->apdu = NULL) free(apdu);
		free(card_param);
	}

	return r;
#endif
	return -1;
}
#endif

int iso7816_construct_fci(pcsc_slot_t *card_handle, 
				 struct icc_file *filp,
				 uint8_t *fci_buf, size_t *fci_buflen)
{
	uint8_t *p = fci_buf;
	uint8_t buf[64];

	*p++ = 0x6F;
	p++;

	buf[0] = (filp->size >> 8) &0xFF;
	buf[1] = filp->size & 0xFF;
	icc_asn1_put_tag(0x81, buf, 2, p, 16, &p);

	if (filp->type_attr_len) {
		memcpy(buf, filp->type_attr, filp->type_attr_len);
		icc_asn1_put_tag(0x82, buf, filp->type_attr_len, p, 16, &p);
	} else {
		buf[0] = filp->shareable ? 0x40 : 0;
		switch (filp->type) {
		case ICC_FILE_TYPE_INTERNAL_EF:
			buf[0] |= 0x80;
		case ICC_FILE_TYPE_WORKING_EF:
			buf[0] |= filp->ef_structure & 7;
			break;
		case ICC_FILE_TYPE_DF:
			buf[0] = 0x38;
			break;
		default:
			return ICC_ERR_NOT_SUPPORTED;
		}
		icc_asn1_put_tag(0x82, buf, 1, p, 16, &p);
	}

	buf[0] = (filp->id >> 8) & 0xFF;
	buf[1] = filp->id & 0xFF;
	icc_asn1_put_tag(0x83, buf, 2, p, 16, &p);

	if(filp->prop_attr_len) {
		memcpy(buf, filp->prop_attr, filp->prop_attr_len);
		icc_asn1_put_tag(0x85, buf, filp->prop_attr_len, p, 18, &p);
	}
	if (filp->sec_attr_len) {
		memcpy(buf, filp->sec_attr, filp->sec_attr_len);
		icc_asn1_put_tag(0x86, buf, filp->sec_attr_len, p, 18, &p);
	}

	fci_buf[1] = p - fci_buf - 2;
	*fci_buflen = p - fci_buf;
	
	return 0;
}

static void iso7816_create_file_complete(pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param = card_param->icc_param;
	struct icc_apdu *apdu = cmd_param->apdu;

	if (card_param->ret != 0)
		cmd_param->ret = card_param->ret;
	else {
		cmd_param->ret = pcsc_fetch_check_sw(card_param);
	}
	card_param->ret = cmd_param->ret;
	cmd_param->callback(card_param);

	free(apdu);
	free(cmd_param);
}

/* FIXME: cannot find this cmd in 7816 */
int iso7816_create_file(pcsc_slot_t *card_handle, 
			struct icc_file *filp,
			pcsc_trans_cb callback, pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	uint8_t fci_buf[ICC_APDU_BUFFER_MAX];
	size_t fci_buflen;
	int r;

	cmd_param = malloc(sizeof(pcsc_icc_trans_param));
	if (!cmd_param) 
		return -3;
	memset(cmd_param, 0, sizeof(pcsc_icc_trans_param));
	cmd_param->callback = callback;
	
	fci_buflen = sizeof(fci_buf);
	r = pcsc_icc_ops(card_handle)->construct_fci(card_handle, filp, 
							 fci_buf, &fci_buflen);
	if (r != 0) {
		free(cmd_param);
		return r;
	}

	apdu = malloc(sizeof(struct icc_apdu));
	if (!apdu) {
		free(cmd_param);
		return -3;	
	}
	memset(apdu, 0, sizeof(struct icc_apdu));
	apdu->cse = ICC_APDU_CASE_3_SHORT;
	apdu->cla = card_handle->icc->cla;
	apdu->ins = 0xE0;
	apdu->p1 = 0x00;
	apdu->p2 = 0x00;
	apdu->lc = fci_buflen;
	apdu->tx_buf = fci_buf;
	apdu->tx_buflen = fci_buflen;

	card_param->icc_param = cmd_param;
	cmd_param->apdu = apdu;

	r = pcsc_transmit_from_icc(card_param, iso7816_create_file_complete);
	if (r != 0) {
		free(cmd_param);
		free(apdu);
	}

	return r;	
}

static void iso7816_delete_file_complete(pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param = card_param->icc_param;
	struct icc_apdu *apdu = cmd_param->apdu;

	if (card_param->ret != 0) {
		cmd_param->ret = card_param->ret;
	} else {
		cmd_param->ret = pcsc_fetch_check_sw(card_param);
	}
	card_param->ret = cmd_param->ret;
	cmd_param->callback(card_param);

	free(apdu);
	free(cmd_param);
}

int iso7816_delete_file(pcsc_slot_t *card_handle, 
			const struct icc_path *path,
			pcsc_trans_cb callback, pcsc_transfer_t *card_param)
{
	pcsc_icc_trans_param *cmd_param;
	struct icc_apdu *apdu;
	uint8_t sbuf[2];
	int r;

	if (path->type != ICC_PATH_TYPE_FILE_ID 
		|| (path->len != 0 && path->len != 2)) {
		pcsc_log(PCSC_LOG_WARN, 
			  "You should enter the directory.");
		return -2;
	}

	cmd_param = malloc(sizeof(pcsc_icc_trans_param));
	if (!cmd_param)
		return -3;
	memset(cmd_param, 0, sizeof(pcsc_icc_trans_param));
	cmd_param->callback = callback;

	apdu = malloc(sizeof(struct icc_apdu));
	if (!apdu) {
		free(cmd_param);
		return -3;
	}
	memset(apdu, 0, sizeof(struct icc_apdu));

	if (path->len == 2) {
		sbuf[0] = path->value[0];
		sbuf[1] = path->value[1];

		apdu->cse = ICC_APDU_CASE_3_SHORT;
		apdu->cla = card_handle->icc->cla;
		apdu->ins = 0xE4;
		apdu->p1 = 0x00;
		apdu->p2 = 0x00;
		apdu->lc = 2;
		apdu->tx_buflen = 2;
	} else { /* No file ID given: means currently selected file */
		apdu->cse = ICC_APDU_CASE_1;
		apdu->cla = card_handle->icc->cla;
		apdu->ins = 0xE4;
		apdu->p1 = 0x00;
		apdu->p2 = 0x00;
	}
	apdu->tx_buf = sbuf;

	cmd_param->apdu = apdu;
	card_param->icc_param = cmd_param;

	r = pcsc_transmit_from_icc(card_param, iso7816_delete_file_complete);
	if (r != 0) {
		free(apdu);
		free(cmd_param);
	}

	return r;
}
static icc_driver_ops_t iso7816_ops = {

	iso7816_read_binary,	/* read_binary */
	iso7816_write_binary,	/* write_binary */
	iso7816_update_binary,	/* update_binary */
	NULL,			/* erase_binary */
	iso7816_read_record,	/* read_record */
	iso7816_write_record,	/* write_record */
	iso7816_append_record,	/* append_record */
	iso7816_update_record,	/* update_record */
	NULL,			/* get_data */
	NULL,			/* put_data */
	iso7816_select_file,	/* select_file */
	iso7816_get_response,	/* get_response */
	NULL,			/* envelope */
	NULL,			/* pin_cmd */
	NULL,			/* inter_auth */
	NULL,			/* exter_auth */
	iso7816_get_challenge,	/* get_challenge */
	NULL,			/* manage_channel */
	NULL,			/* computer_signature */
	iso7816_create_file,	/* create_file */
	iso7816_delete_file,	/* delete_file */
	NULL,			/* list_file */
	iso7816_check_sw,	/* check_sw */
	NULL,			/* card_ctl */
	iso7816_process_fci,	/* process_fci */
	iso7816_construct_fci,	/* construct_fci */

	NULL,
};

static int iso7816_drv_open(pcsc_icc_t *icc)
{
	return -1;
}

static int iso7816_drv_close(pcsc_icc_t *icc)
{
	return -1;
}

static icc_driver_t iso7816_drvier = {
	ICC_DRIVER_7816_NAME,
	ICC_DRV_NO_MATCH,
	NULL,		/* no match */
	iso7816_drv_open,	/* call-chain */
	iso7816_drv_close,	/* call-chain */
	&iso7816_ops,
};

int __init icc_iso7816_init(void)
{
	icc_register_driver(&iso7816_drvier);
	return 0;
}

void __exit icc_iso7816_exit(void)
{
	icc_unregister_driver(&iso7816_drvier);
}

