#ifndef __PCSC_PRIV_H__
#define __PCSC_PRIV_H__

#include <sysdep.h>
#include <logger.h>
#include <panic.h>
#include <module.h>
#include <strutl.h>
#include <dfastm.h>
#include <eloop.h>
#include <service.h>
#include <list.h>
#include <pcsc.h>

/*Logging operations*/
#define PCSC_LOG_CRIT	LOG_EMERG
#define PCSC_LOG_FAIL	LOG_CRIT
#define PCSC_LOG_ERR	LOG_ERR
#define PCSC_LOG_WARN	LOG_WARNING
#define PCSC_LOG_INFO	LOG_INFO
#define PCSC_LOG_DEBUG	LOG_DEBUG

void pcsc_log(int level, const char *format, ...);
void pcsc_log_xxd(int level, const char *msg, const unsigned char *buffer,
	const int len);

enum atr_info_ts {
	PCSC_ATR_TS_DIRECT	= 0x01,
	PCSC_ATR_TS_INVERSE	= 0x02,
};

struct pcsc_atr_info {
	uint8_t TS;
	uint8_t T0;
	uint8_t history_len;

	int supported_protos;
	int default_proto;
	
};

int pcsc_parse_atr(const char *atr, size_t atr_len, 
		   struct pcsc_atr_info *atr_info);
int pcsc_get_default_protocol(const uint8_t *atr, size_t atr_len, 
			      int *default_protol);
int pcsc_get_supported_protocol(const uint8_t *atr, size_t atr_len, 
			      int *supported_protol);

struct pcsc_reader_context *pcsc_reader_ctx_by_filename(const char *filename);
int pcsc_release_reader_ctx(struct pcsc_reader_context *rd_ctx);

int pcsc_reader_down(const char *filename);
int pcsc_icc_poweron(int reader_idx);
int pcsc_icc_poweroff(int reader_idx);
int pcsc_icc_insert(int reader_idx);
int pcsc_icc_remove(int reader_idx);

struct pcsc_ifd_driver *pcsc_driver_by_name(const char *name);
int pcsc_device_id_match(const struct pcsc_devid *match, 
			 const struct pcsc_devid *id);
const struct pcsc_ifd_driver *pcsc_driver_by_devid(const struct pcsc_devid *devid);
int pcsc_driver_add_id(const char *driver_name, struct pcsc_devid *devid);
int pcsc_driver_register(const char *name, struct pcsc_ifd_driver_ops *ops);
void pcsc_driver_unregister(const char *name);

/* IFD-CCID */
int pcsc_driver_register_ccid(void);
void pcsc_driver_unregister_ccid(void);
void ccid_register_devids(void);
void ccid_unregister_devids(void);


#endif /*__PCSC_PRIV_H__*/
