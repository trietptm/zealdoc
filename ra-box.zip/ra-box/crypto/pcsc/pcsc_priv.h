#ifndef __PCSC_PRIV_H__
#define __PCSC_PRIV_H__

#include <sysdep.h>
#include <logger.h>
#include <panic.h>
#include <module.h>
#include <strutl.h>
#include <dfastm.h>
#include <eloop.h>
#include <service.h>
#include <list.h>
#include <pcsc.h>
#include <bitops.h>

#define PCSC_LOG_CRIT	LOG_EMERG
#define PCSC_LOG_FAIL	LOG_CRIT
#define PCSC_LOG_ERR	LOG_ERR
#define PCSC_LOG_WARN	LOG_WARNING
#define PCSC_LOG_INFO	LOG_INFO
#define PCSC_LOG_DEBUG	LOG_DEBUG

#define LOG_CALL_CHAIN	PCSC_LOG_INFO
//#define LOG_CALL_CHAIN	PCSC_LOG_DEBUG
#define PCSC_SHOW	PCSC_LOG_INFO

void pcsc_log(int level, const char *format, ...);

struct pcsc_atr_info {
	uint8_t TS;
	uint8_t T0;
	uint8_t history_len;

	int supported_protos;
	int default_proto;	
};

typedef struct _pcsc_ifd pcsc_ifd_t;

typedef void (*pcsc_trans_cb)(pcsc_transfer_t *trans);
typedef void (*pcsc_slot_cb)(pcsc_slot_t *hd);

typedef pcsc_appcmd_complete pcsc_ll_cb /* cb(void *, int res)*/;

#include "pcsc_ifd.h"
#include "pcsc_icc.h"

struct _pcsc_slot {
	uint16_t idx;	/* XXYY: XX - IFD idx, YY IFD_SLOT idx */
	pcsc_ifd_t *ifd;
	pcsc_icc_t *icc;

	uint16_t old_icc_status;	/* for detect ICC state change */

	pcsc_slot_cb cb;
	int ret;
	stm_instance_t *fsmi;
	
	int locked;
	atomic_t refcnt;
	list_t link;
};

typedef struct _pcsc_trans_param {
	uint8_t *sbuf;
	size_t sbuf_len;
	size_t sbuf_transmitted;

	/* icc trans */
	struct icc_apdu *apdu;
	struct icc_path *path;
	struct icc_path *full_path;

	struct icc_file **file_out;

	/* muscle - file, wd - ext */
	void *priv;

	pcsc_trans_cb callback;
	int ret;
} pcsc_trans_param;


struct _pcsc_transfer {

	pcsc_slot_t *handle;
	uint32_t ioctl;

	pcsc_trans_param *icc_param;
	pcsc_trans_param *ifd_param;

	/* response APDU(R)  */
	uint8_t *rbuf;
	size_t rbuf_len;
	size_t rbuf_actual;

	/* application data */
	pcsc_appcmd_complete callback;
	void *user_data;
	/* by app/icc/ifd */
	int ret;
};

int		pcsc_parse_atr(const char *atr, size_t atr_len, struct pcsc_atr_info *atr_info);
int		pcsc_default_proto(const uint8_t *atr, size_t atr_len, int *def_pro);
int		pcsc_support_proto(const uint8_t *atr, size_t atr_len, int *supp_proto);
int		pcsc_sync_apdu(pcsc_transfer_t *trans);

void		icc_detect_apdu_cse(pcsc_slot_t *handle, struct icc_apdu *apdu);
int		icc_check_apdu(pcsc_slot_t *handle, struct icc_apdu *apdu);
size_t		icc_apdu_get_length(const struct icc_apdu *apdu, unsigned int proto);
int		icc_apdu2bytes(const struct icc_apdu *apdu, uint32_t proto,
			       uint8_t *out, size_t outlen);
void		ulong2bebytes(uint8_t *buf, uint32_t x);
void		ushort2bebytes(uint8_t *buf, uint16_t x);
uint32_t	bebytes2ulong(const uint8_t *buf);
uint16_t	bebytes2ushort(const uint8_t *buf);

int __init	pcsc_handle_init(void);
void __exit	pcsc_handle_exit(void);
int __init	pcsc_ifd_init(void);
void __exit	pcsc_ifd_exit(void);

int __init	pcsc_icc_init(void);
void __exit	pcsc_icc_exit(void);

int __init	pcsc_explorer_init(void);
void __exit	pcsc_explorer_exit(void);


pcsc_transfer_t *pcsc_lower_need_transfer(pcsc_slot_t *hd, 
					  pcsc_appcmd_complete cb, 
					  void *user_data);
void		pcsc_slot_free_all(pcsc_ifd_t *f);
void		pcsc_start_by_ifd(pcsc_ifd_t *fd);
void		pcsc_stop_by_ifd(pcsc_ifd_t *ifd);
void		pcsc_get_feature(pcsc_ifd_t *ifd);
void		pcsc_lower_noneed_transfer(pcsc_transfer_t *trans);
void		pcsc_slot_put(pcsc_slot_t *hd);
uint16_t	pcsc_idx_by_iccidx(uint16_t iccidx);
pcsc_slot_t	*pcsc_slot_by_icc(pcsc_icc_t *icc, int get);
pcsc_slot_t	*pcsc_slot_get(pcsc_slot_t *hd);
pcsc_slot_t	*pcsc_internel_first_slot(void);
pcsc_slot_t	*pcsc_slot_new(pcsc_ifd_t *, int idx);
pcsc_slot_t	*pcsc_handle_get_by_idx(uint16_t idx);


/* for ifd */
int		pcsc_trans_proto(pcsc_transfer_t *t);
int		pcsc_ll_transmit(pcsc_transfer_t *trans);
struct icc_apdu *pcsc_trans_apdu(pcsc_transfer_t *trans);

/* for icc */
int pcsc_transmit(pcsc_transfer_t *trans);
int pcsc_transmit_from_icc(pcsc_transfer_t *trans, pcsc_trans_cb cb);
int pcsc_fetch_check_sw(pcsc_transfer_t *card_param);
int pcsc_fetch_sw(pcsc_transfer_t *card_param);

static inline icc_driver_ops_t *pcsc_icc_ops(pcsc_slot_t *slot)
{
	return slot->icc->drv->ops;
}

static inline ifd_driver_t *pcsc_ifd_ops(pcsc_slot_t *slot)
{
	return slot->ifd->drv;
}

#endif /*__PCSC_PRIV_H__*/
