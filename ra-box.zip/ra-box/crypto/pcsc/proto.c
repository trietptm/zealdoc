
DECLARE_LIST(trans_protos);

typedef struct __trans_proto		trans_proto_t;

typedef void (*ifd_send_comp)(void *user_data, int ret);

struct __trans_proto {
	int id;
	const char *name;

	int (*init) (void *);
	int (*send) (void *);
	list_t link;
};


#define for_each_proto(e)		\
	list_for_each_entry(trans_proto_t, e, &trans_protos, link)

static trans_proto_t *ifd_proto_by_id(int id);

static int t0_init(void *s)
{
	return -1;
}

static void __t0_send_cb(void *d, int ret)
{
	if (ret < 0) {
		pcsc_log(PCSC_LOG_INFO, "t0 send err");
	} else {
		pcsc_log(PCSC_LOG_INFO, "t0 send succ");
	}

}

static int t0_send(void *d)
{
	return -1;
}

static trans_proto_t __protocol_t0 = {
	PCSC_PROTOCOL_T0,	/* id */
	"T=0",			/* name */
	t0_init,		/* init */
	t0_send,		/* send */
};


static int t0_send_s_apdu(pcsc_transfer_t *trans)
{
}

int ifd_register_proto(trans_proto_t *p);
void ifd_unregister_proto(trans_proto_t *p);

int __init ifd_proto_init(void);
void __exit ifd_proto_exit(void);


int ifd_proto_transmit(pcsc_transfer_t *trans)
{
	int id;
	trans_proto_t *proto;
	ccid_desc_t *desc;

	id = pcsc_trans_proto(trans);
	proto = ifd_proto_by_id(id);
	
	desc = ccid_desc_get(trans->handle->ifd->lower);

	if (!proto)
		return -1;

	switch (desc->dwFeatures & CCID_CLASS_EXCHANGE_MASK) {
	case CCID_CLASS_SHORT_APDU:
		return t0_send_s_apdu(trans);
	/* not support */
	case CCID_CLASS_TPDU:
	case CCID_CLASS_EXTENDED_APDU:
	case CCID_CLASS_CHARACTER:
	default:
		return -3;
	}
	return -2;
}

static trans_proto_t *ifd_proto_by_id(int id)
{
	trans_proto_t *c;

	for_each_proto(c) {
		if (c->id == id)
			return c;
	}
	return NULL;
}

/* transmit protocol - T0 / T1 ... */
int ifd_register_proto(trans_proto_t *proto)
{
	trans_proto_t *tmp;

	tmp = ifd_proto_by_id(proto->id);
	if (!tmp) {
		log_kern(LOG_INFO, "CCID: protocol registered, proto=%s",
			 proto->name);
		list_init(&proto->link);
		list_insert_before(&proto->link, &trans_protos);
	}
	return 0;
}

void ifd_unregister_proto(trans_proto_t *drv)
{
	if (drv) {
		log_kern(LOG_INFO, "CCID: protocol unregistered, proto=%s",
			 drv->name);
		list_delete_init(&drv->link);
	}
}

int __init ifd_proto_init(void)
{
	ifd_register_proto(&__protocol_t0);
	return 0;
}

void __exit ifd_proto_exit(void)
{
	ifd_unregister_proto(&__protocol_t0);
}
