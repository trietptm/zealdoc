/*
 * Cryptographic API.
 *
 * Digest operations.
 *
 * Copyright (c) 2002 James Morris <jmorris@intercode.com.au>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option) 
 * any later version.
 *
 */

#include "crypto_priv.h"

static int init(struct hash_desc *desc)
{
	crypto_tfm_t *tfm = crypto_hash_tfm(desc->tfm);

	tfm->__crt_alg->cra_digest.dia_init(tfm);
	return 0;
}

static int update2(struct hash_desc *desc,
		   struct iovec *sg, unsigned int nbytes)
{
	crypto_tfm_t *tfm = crypto_hash_tfm(desc->tfm);
	struct iovec *v = sg;

	if (!nbytes)
		return 0;

	for (;;) {
		unsigned int l = v->iov_len;
		char *p = v->iov_base;

		if (l > nbytes)
			l = nbytes;
		nbytes -= l;

		tfm->__crt_alg->cra_digest.dia_update(tfm, p, l);

		if (!nbytes)
			break;

		v = sg++;
	}

	return 0;
}

static int update(struct hash_desc *desc,
		  struct iovec *sg, unsigned int nbytes)
{
	return update2(desc, sg, nbytes);
}

static int final(struct hash_desc *desc, uint8_t *out)
{
	crypto_tfm_t *tfm = crypto_hash_tfm(desc->tfm);
	struct digest_alg *digest = &tfm->__crt_alg->cra_digest;

	digest->dia_final(tfm, out);
	return 0;
}

static int crypto_nosetkey(struct crypto_hash *tfm, const uint8_t *key, unsigned int keylen)
{
	crypto_hash_clear_flags(tfm, CRYPTO_TFM_RES_MASK);
	return -ENOSYS;
}

static int crypto_setkey(struct crypto_hash *hash, const uint8_t *key, unsigned int keylen)
{
	crypto_tfm_t *tfm = crypto_hash_tfm(hash);

	crypto_hash_clear_flags(hash, CRYPTO_TFM_RES_MASK);
	return tfm->__crt_alg->cra_digest.dia_setkey(tfm, key, keylen);
}

static int digest(struct hash_desc *desc,
		  struct iovec *sg, unsigned int nbytes, uint8_t *out)
{
	init(desc);
	update2(desc, sg, nbytes);
	return final(desc, out);
}

int crypto_init_digest_ops(crypto_tfm_t *tfm)
{
	struct hash_tfm *ops = &tfm->crt_hash;
	struct digest_alg *dalg = &tfm->__crt_alg->cra_digest;

	if (dalg->dia_digestsize > crypto_tfm_alg_blocksize(tfm))
		return -EINVAL;
	
	ops->init	= init;
	ops->update	= update;
	ops->final	= final;
	ops->digest	= digest;
	ops->setkey	= dalg->dia_setkey ? crypto_setkey : crypto_nosetkey;
	ops->digestsize	= dalg->dia_digestsize;
	
	return 0;
}

void crypto_exit_digest_ops(crypto_tfm_t *tfm)
{
}
