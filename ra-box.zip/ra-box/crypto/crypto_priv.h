#ifndef __CRYPTO_PRIV_H_INCLUDE__
#define __CRYPTO_PRIV_H_INCLUDE__

#include <crypto.h>
#include <strutl.h>
#include <module.h>
#include <netsvc.h>
#include <panic.h>
#include <service.h>
#include <logger.h>
#include <udev.h>

#define CRYPTO_LOG_CRIT		LOG_EMERG
#define CRYPTO_LOG_FAIL		LOG_CRIT
#define CRYPTO_LOG_ERR		LOG_ERR
#define CRYPTO_LOG_WARN		LOG_WARNING
#define CRYPTO_LOG_INFO		LOG_INFO
#define CRYPTO_LOG_DEBUG	LOG_DEBUG

void crypto_log(int level, const char *format, ...);

static inline unsigned int crypto_digest_ctxsize(crypto_alg_t *alg)
{
	unsigned int len = alg->cra_ctxsize;
	return len;
}

static inline unsigned int crypto_cipher_ctxsize(crypto_alg_t *alg)
{
	return alg->cra_ctxsize;
}

static inline unsigned int crypto_compress_ctxsize(crypto_alg_t *alg)
{
	return alg->cra_ctxsize;
}

crypto_alg_t *crypto_alg_mod_lookup(const char *name,
				    uint32_t type,
				    uint32_t mask);
void crypto_shoot_alg(crypto_alg_t *alg);
crypto_tfm_t *__crypto_alloc_tfm(crypto_alg_t *alg, uint32_t type,
				 uint32_t mask);
crypto_alg_t *__crypto_alg_lookup(const char *name,
				  uint32_t type, uint32_t mask);

int crypto_register_instance(struct crypto_template *tmpl,
			     struct crypto_instance *inst);

int crypto_init_digest_ops(crypto_tfm_t *tfm);
void crypto_exit_digest_ops(crypto_tfm_t *tfm);
int crypto_init_cipher_ops(crypto_tfm_t *tfm);
void crypto_exit_cipher_ops(crypto_tfm_t *tfm);
int crypto_init_compress_ops(crypto_tfm_t *tfm);
void crypto_exit_compress_ops(crypto_tfm_t *tfm);

int crypto_rand_start(void);

#endif /* __CRYPTO_PRIV_H_INCLUDE__ */
