#include <rsa.h>
#include <crypto.h>

static const unsigned int rsa_small_primes[]= { 3, 5, 7, 11 };

#define RSA_SMALL_PRIME_COUNT		sizeof(rsa_small_primes)/sizeof(unsigned int)

static int rsa_prime_ok(mpi_t *, unsigned int, mpi_t *, unsigned int);
static int rsa_probable_prime(mpi_t *, unsigned int);
static int rsa_small_factor(mpi_t *, unsigned int);
static int rsa_fermat_test(mpi_t *, unsigned int);
static int rsa_relatively_prime(mpi_t *, unsigned int, mpi_t *, unsigned int);

static int _rsa_generate_digits(mpi_t *, unsigned int);
static int _rsa_public_block(rsa_public_t *, uint8_t *, size_t *,
			     uint8_t *, size_t);
static int _rsa_private_block(rsa_private_t *, uint8_t *, size_t *,
			      uint8_t *, size_t);

/* Find a probable prime a between 3*2^(b-2) and 2^b-1, starting at
 * 3*2^(b-2) + (c mod 2^(b-2)), such that gcd (a-1, d) = 1.
 *
 * Lengths: a[cDigits], c[cDigits], d[dDigits].
 * Assumes b > 2, b < cDigits * MPI_DIGIT_BITS, d is odd,
 *         cDigits < MAX_MPI_DIGITS, dDigits < MAX_MPI_DIGITS, and a
 *         probable prime can be found.
 */
void rsa_prime_find(mpi_t *a, unsigned int b, mpi_t *c,
		    unsigned int cDigits, mpi_t *d,
		    unsigned int dDigits)
{
	mpi_t t[MAX_MPI_DIGITS], u[MAX_MPI_DIGITS];
	mpi_t v[MAX_MPI_DIGITS], w[MAX_MPI_DIGITS];
	
	/* compute t = 2^(b-2), u = 3*2^(b-2) */
	mpi_assign_2exp(t, b-2, cDigits);
	mpi_assign_2exp(u, b-1, cDigits);
	mpi_add(u, u, t, cDigits);
	
	/* compute v = 3*2^(b-2) + (c mod 2^(b-2)); add one if even */
	mpi_mod(v, c, cDigits, t, cDigits);
	mpi_add(v, v, u, cDigits);
	if (mpi_even(v, cDigits)) {
		mpi_assign_digit(w, 1, cDigits);
		mpi_add(v, v, w, cDigits);
	}
	
	/* compute w = 2, u = 2^b - 2 */
	mpi_assign_digit(w, 2, cDigits);
	mpi_sub(u, u, w, cDigits);
	mpi_add(u, u, t, cDigits);
	
	/* search to 2^b-1 from starting point, then from 3*2^(b-2)+1 */
	while (!rsa_prime_ok(v, cDigits, d, dDigits)) {
		if (mpi_cmp(v, u, cDigits) > 0)
			mpi_sub(v, v, t, cDigits);
		mpi_add(v, v, w, cDigits);
	}
	
	mpi_assign(a, v, cDigits);
	
	/* burn sensitive information */
	memset(v, 0, sizeof (v));
}

/* Returns nonzero iff a is a probable prime and GCD (a-1, b) = 1.
 *
 * Lengths: a[aDigits], b[bDigits].
 * Assumes aDigits < MAX_MPI_DIGITS, bDigits < MAX_MPI_DIGITS.
 */
static int rsa_prime_ok(mpi_t *a, unsigned int aDigits,
			mpi_t *b, unsigned int bDigits)
{
	int status;
	mpi_t aMinus1[MAX_MPI_DIGITS], t[MAX_MPI_DIGITS];
	
	mpi_assign_digit(t, 1, aDigits);
	mpi_sub(aMinus1, a, t, aDigits);
	
	status = rsa_probable_prime(a, aDigits) &&
	         rsa_relatively_prime(aMinus1, aDigits, b, bDigits);
	
	/* burn sensitive information */
	memset(aMinus1, 0, sizeof (aMinus1));
	return status;
}

/* Returns nonzero iff a is a probable prime.
 *
 * Lengths: a[aDigits].
 * Assumes aDigits < MAX_MPI_DIGITS.
 */
static int rsa_probable_prime(mpi_t *a, unsigned int aDigits)
{
	return (!rsa_small_factor(a, aDigits) && rsa_fermat_test(a, aDigits));
}

/* Returns nonzero iff a has a prime factor in rsa_small_primes.
 *
 * Lengths: a[aDigits].
 * Assumes aDigits < MAX_MPI_DIGITS.
 */
static int rsa_small_factor(mpi_t *a, unsigned int aDigits)
{
	int status;
	mpi_t t[1];
	unsigned int i;
	
	status = 0;
	
	for (i = 0; i < RSA_SMALL_PRIME_COUNT; i++) {
		mpi_assign_digit(t, rsa_small_primes[i], 1);
		mpi_mod(t, a, aDigits, t, 1);
		if (mpi_zero(t, 1)) {
			status = 1;
			break;
		}
	}
	
	/* burn sensitive information */
	i = 0;
	memset(t, 0, sizeof (t));
	return status;
}

/* Returns nonzero iff a passes Fermat's test for witness 2.
 * (All primes pass the test, and nearly all composites fail.)
 *
 * Lengths: a[aDigits].
 * Assumes aDigits < MAX_MPI_DIGITS.
 */
static int rsa_fermat_test(mpi_t *a, unsigned int aDigits)
{
	int status;
	mpi_t t[MAX_MPI_DIGITS], u[MAX_MPI_DIGITS];
	
	mpi_assign_digit(t, 2, aDigits);
	mpi_mod_exp(u, t, a, aDigits, a, aDigits);
	
	status = mpi_equal(t, u, aDigits);
	
	/* burn sensitive information */
	memset(u, 0, sizeof (u));
	return status;
}

/* Returns nonzero iff a and b are relatively prime.
 *
 * Lengths: a[aDigits], b[bDigits].
 * Assumes aDigits >= bDigits, aDigits < MAX_MPI_DIGITS.
 */
static int rsa_relatively_prime(mpi_t *a, unsigned int aDigits,
				mpi_t *b, unsigned int bDigits)
{
	int status;
	mpi_t t[MAX_MPI_DIGITS], u[MAX_MPI_DIGITS];
	
	mpi_assign_zero(t, aDigits);
	mpi_assign(t, b, bDigits);
	mpi_gcd(t, a, t, aDigits);
	mpi_assign_digit(u, 1, aDigits);
	
	status = mpi_equal(t, u, aDigits);
	
	/* burn sensitive information */
	memset(t, 0, sizeof (t));
	return status;
}

/* Generates an RSA key pair with a given length and public exponent.
 */
int rsa_gen_pem_keys(rsa_public_t *publicKey,
		     rsa_private_t *privateKey,
		     rsa_param_t *protoKey)
{
	mpi_t d[MAX_MPI_DIGITS], dP[MAX_MPI_DIGITS], dQ[MAX_MPI_DIGITS];
	mpi_t e[MAX_MPI_DIGITS], n[MAX_MPI_DIGITS], p[MAX_MPI_DIGITS];
	mpi_t phiN[MAX_MPI_DIGITS];
	mpi_t pMinus1[MAX_MPI_DIGITS], q[MAX_MPI_DIGITS], qInv[MAX_MPI_DIGITS];
	mpi_t qMinus1[MAX_MPI_DIGITS], t[MAX_MPI_DIGITS];
	int status;
	unsigned int nDigits, pDigits;
	
	if ((protoKey->bits < MIN_RSA_MODULUS_BITS) || 
	    (protoKey->bits > MAX_RSA_MODULUS_BITS))
		return (RSA_ERROR_MODULUS_LEN);
	nDigits = (protoKey->bits + MPI_DIGIT_BITS - 1) / MPI_DIGIT_BITS;
	pDigits = (nDigits + 1) / 2;
	
	/* generate random RSA primes p and q so that product has correct length */
	if ((status = _rsa_generate_digits(p, pDigits)) ||
	    (status = _rsa_generate_digits(q, pDigits)))
		return (status);
	
	/* NOTE: for 65537, this assumes mpi_t is at least 17 bits. */
	mpi_assign_digit(e,
			 protoKey->useFermat4 ? (mpi_t)65537 : (mpi_t)3,
			 nDigits);
	rsa_prime_find(p, (protoKey->bits + 1) / 2, p, pDigits, e, 1);
	rsa_prime_find(q, protoKey->bits / 2, q, pDigits, e, 1);
	
	/* Sort so that p > q. (p = q case is extremely unlikely.)
	*/
	if (mpi_cmp(p, q, pDigits) < 0) {
		mpi_assign(t, p, pDigits);
		mpi_assign(p, q, pDigits);
		mpi_assign(q, t, pDigits);
	}
	
	/* Compute n = pq, qInv = q^{-1} mod p, d = e^{-1} mod (p-1)(q-1),
	 * dP = d mod p-1, dQ = d mod q-1.
	 */
	mpi_mult(n, p, q, pDigits);
	mpi_mod_inv(qInv, q, p, pDigits);
	
	mpi_assign_digit(t, 1, pDigits);
	mpi_sub(pMinus1, p, t, pDigits);
	mpi_sub(qMinus1, q, t, pDigits);
	mpi_mult(phiN, pMinus1, qMinus1, pDigits);
	
	mpi_mod_inv(d, e, phiN, nDigits);
	mpi_mod(dP, d, nDigits, pMinus1, pDigits);
	mpi_mod(dQ, d, nDigits, qMinus1, pDigits);
	
	publicKey->bits = privateKey->bits = protoKey->bits;
	mpi_encode(publicKey->n, MAX_RSA_MODULUS_LEN, n, nDigits);
	mpi_encode(publicKey->e, MAX_RSA_MODULUS_LEN, e, 1);
	memcpy(privateKey->n, publicKey->n, MAX_RSA_MODULUS_LEN);
	memcpy(privateKey->e, publicKey->e, MAX_RSA_MODULUS_LEN);
	mpi_encode(privateKey->d, MAX_RSA_MODULUS_LEN, d, nDigits);
	mpi_encode(privateKey->r[0], MAX_RSA_PRIME_LEN, p, pDigits);
	mpi_encode(privateKey->r[1], MAX_RSA_PRIME_LEN, q, pDigits);
	mpi_encode(privateKey->dR[0], MAX_RSA_PRIME_LEN, dP, pDigits);
	mpi_encode(privateKey->dR[1], MAX_RSA_PRIME_LEN, dQ, pDigits);
	mpi_encode(privateKey->t, MAX_RSA_PRIME_LEN, qInv, pDigits);
	
	/* burn sensitive information */
	memset(d, 0, sizeof (d));
	memset(dP, 0, sizeof (dP));
	memset(dQ, 0, sizeof (dQ));
	memset(p, 0, sizeof (p));
	memset(phiN, 0, sizeof (phiN));
	memset(pMinus1, 0, sizeof (pMinus1));
	memset(q, 0, sizeof (q));
	memset(qInv, 0, sizeof (qInv));
	memset(qMinus1, 0, sizeof (qMinus1));
	memset(t, 0, sizeof (t));
	return (0);
}

static int _rsa_generate_digits(mpi_t *a, unsigned int digits)
{
	uint8_t t[MAX_RSA_MODULUS_LEN];

	crypto_rand_bytes(t, digits * MPI_DIGIT_BYTES);
	mpi_decode(a, digits, t, digits * MPI_DIGIT_BYTES);
	
	/* burn sensitive information */
	memset(t, 0, sizeof (t));
	return (0);
}

/* RSA public-key encryption, according to PKCS #1.
 */
int rsa_public_encrypt(rsa_public_t *publicKey,
		       uint8_t *output, size_t *outputLen,
		       uint8_t *input, size_t inputLen)
{
	int status;
	unsigned char byte, pkcsBlock[MAX_RSA_MODULUS_LEN];
	unsigned int i, modulusLen;
	
	modulusLen = (publicKey->bits + 7) / 8;
	if (inputLen + 11 > modulusLen)
		return (RSA_ERROR_LEN);
	
	pkcsBlock[0] = 0;
	/* block type 2 */
	pkcsBlock[1] = 2;
	
	for (i = 2; i < modulusLen - inputLen - 1; i++) {
		/* find nonzero random byte */
		do {
			crypto_rand_bytes(&byte, 1);
		} while (byte == 0);
		pkcsBlock[i] = byte;
	}
	/* separator */
	pkcsBlock[i++] = 0;
	
	memcpy(&pkcsBlock[i], input, inputLen);
	
	status = _rsa_public_block(publicKey, output, outputLen,
				   pkcsBlock, modulusLen);
	
	/* burn sensitive information */
	byte = 0;
	memset(pkcsBlock, 0, sizeof (pkcsBlock));
	
	return (status);
}

/* RSA public-key decryption, according to PKCS #1.
 */
int rsa_public_decrypt(rsa_public_t *publicKey,
		       uint8_t *output, size_t *outputLen,
		       uint8_t *input, size_t inputLen)
{
	int status;
	unsigned char pkcsBlock[MAX_RSA_MODULUS_LEN];
	unsigned int i, modulusLen, pkcsBlockLen;
	
	modulusLen = (publicKey->bits + 7) / 8;
	if (inputLen > modulusLen)
		return (RSA_ERROR_LEN);
	
	status = _rsa_public_block(publicKey, pkcsBlock, &pkcsBlockLen,
				   input, inputLen);
	if (status)
		return (status);
	
	if (pkcsBlockLen != modulusLen)
		return (RSA_ERROR_LEN);
	
	/* Require block type 1	*/
	if ((pkcsBlock[0] != 0) || (pkcsBlock[1] != 1))
		return (RSA_ERROR_DATA);
	
	for (i = 2; i < modulusLen-1; i++) {
		if (pkcsBlock[i] != 0xff)
			break;
	}
	
	/* separator */
	if (pkcsBlock[i++] != 0)
		return (RSA_ERROR_DATA);
	
	*outputLen = modulusLen - i;
	
	if (*outputLen + 11 > modulusLen)
		return (RSA_ERROR_DATA);
	
	memcpy(output, &pkcsBlock[i], *outputLen);
	
	/* burn potentially sensitive information */
	memset(pkcsBlock, 0, sizeof (pkcsBlock));
	
	return (0);
}

/* RSA private-key encryption, according to PKCS #1.
 */
int rsa_private_encrypt(rsa_private_t *privateKey,
			uint8_t *output, size_t *outputLen,
			uint8_t *input, size_t inputLen)
{
	int status;
	unsigned char pkcsBlock[MAX_RSA_MODULUS_LEN];
	unsigned int i, modulusLen;
	
	modulusLen = (privateKey->bits + 7) / 8;
	if (inputLen + 11 > modulusLen)
		return (RSA_ERROR_LEN);
	
	pkcsBlock[0] = 0;
	/* block type 1 */
	pkcsBlock[1] = 1;
	
	for (i = 2; i < modulusLen - inputLen - 1; i++)
		pkcsBlock[i] = 0xff;
	
	/* separator */
	pkcsBlock[i++] = 0;
	
	memcpy(&pkcsBlock[i], input, inputLen);
	
	status = _rsa_private_block(privateKey, output, outputLen,
				    pkcsBlock, modulusLen);
	
	/* burn potentially sensitive information */
	memset(pkcsBlock, 0, sizeof (pkcsBlock));
	
	return (status);
}

/* RSA private-key decryption, according to PKCS #1.
 */
int rsa_private_decrypt(rsa_private_t *privateKey,
			uint8_t *output, size_t *outputLen,
			uint8_t *input, size_t inputLen)
{
	int status;
	unsigned char pkcsBlock[MAX_RSA_MODULUS_LEN];
	unsigned int i, modulusLen, pkcsBlockLen;
	
	modulusLen = (privateKey->bits + 7) / 8;
	if (inputLen > modulusLen)
		return (RSA_ERROR_LEN);
	
	status = _rsa_private_block(privateKey, pkcsBlock, &pkcsBlockLen,
				    input, inputLen);
	if (status)
		return (status);
	
	if (pkcsBlockLen != modulusLen)
		return (RSA_ERROR_LEN);
	
	/* require block type 2 */
	if ((pkcsBlock[0] != 0) || (pkcsBlock[1] != 2))
		return (RSA_ERROR_DATA);
	
	for (i = 2; i < modulusLen-1; i++) {
		/* separator */
		if (pkcsBlock[i] == 0)
			break;
	}
	
	i++;
	if (i >= modulusLen)
		return (RSA_ERROR_DATA);
	
	*outputLen = modulusLen - i;
	
	if (*outputLen + 11 > modulusLen)
		return (RSA_ERROR_DATA);
	
	memcpy(output, &pkcsBlock[i], *outputLen);
	
	/* burn sensitive information */
	memset(pkcsBlock, 0, sizeof (pkcsBlock));
	
	return (0);
}

/* Raw RSA public-key operation. Output has same length as modulus.
 *
 * Assumes inputLen < length of modulus.
 * Requires input < modulus.
 */
static int _rsa_public_block(rsa_public_t *publicKey,
			     uint8_t *output, size_t *outputLen,
			     uint8_t *input, size_t inputLen)
{
	mpi_t c[MAX_MPI_DIGITS], e[MAX_MPI_DIGITS];
	mpi_t m[MAX_MPI_DIGITS], n[MAX_MPI_DIGITS];
	unsigned int eDigits, nDigits;
	
	mpi_decode(m, MAX_MPI_DIGITS, input, inputLen);
	mpi_decode(n, MAX_MPI_DIGITS, publicKey->n, MAX_RSA_MODULUS_LEN);
	mpi_decode(e, MAX_MPI_DIGITS, publicKey->e, MAX_RSA_MODULUS_LEN);
	nDigits = mpi_digits(n, MAX_MPI_DIGITS);
	eDigits = mpi_digits(e, MAX_MPI_DIGITS);
	
	if (mpi_cmp(m, n, nDigits) >= 0)
		return (RSA_ERROR_DATA);
	
	/* compute c = m^e mod n */
	mpi_mod_exp(c, m, e, eDigits, n, nDigits);
	
	*outputLen = (publicKey->bits + 7) / 8;
	mpi_encode(output, *outputLen, c, nDigits);
	
	/* burn sensitive information */
	memset(c, 0, sizeof (c));
	memset(m, 0, sizeof (m));
	return (0);
}

/* Raw RSA private-key operation. Output has same length as modulus.
 *
 * Assumes inputLen < length of modulus.
 * Requires input < modulus.
 */
static int _rsa_private_block(rsa_private_t *privateKey,
			      uint8_t *output, size_t *outputLen,
			      uint8_t *input, size_t inputLen)
{
	mpi_t c[MAX_MPI_DIGITS], cP[MAX_MPI_DIGITS], cQ[MAX_MPI_DIGITS];
	mpi_t dP[MAX_MPI_DIGITS], dQ[MAX_MPI_DIGITS], mP[MAX_MPI_DIGITS];
	mpi_t mQ[MAX_MPI_DIGITS], n[MAX_MPI_DIGITS], p[MAX_MPI_DIGITS];
	mpi_t q[MAX_MPI_DIGITS], qInv[MAX_MPI_DIGITS], t[MAX_MPI_DIGITS];
	unsigned int cDigits, nDigits, pDigits;
	
	mpi_decode(c, MAX_MPI_DIGITS, input, inputLen);
	mpi_decode(n, MAX_MPI_DIGITS, privateKey->n, MAX_RSA_MODULUS_LEN);
	mpi_decode(p, MAX_MPI_DIGITS, privateKey->r[0], MAX_RSA_PRIME_LEN);
	mpi_decode(q, MAX_MPI_DIGITS, privateKey->r[1], MAX_RSA_PRIME_LEN);
	mpi_decode(dP, MAX_MPI_DIGITS, privateKey->dR[0], MAX_RSA_PRIME_LEN);
	mpi_decode(dQ, MAX_MPI_DIGITS, privateKey->dR[1], MAX_RSA_PRIME_LEN);
	mpi_decode(qInv, MAX_MPI_DIGITS, privateKey->t, MAX_RSA_PRIME_LEN);
	cDigits = mpi_digits(c, MAX_MPI_DIGITS);
	nDigits = mpi_digits(n, MAX_MPI_DIGITS);
	pDigits = mpi_digits(p, MAX_MPI_DIGITS);
	
	if (mpi_cmp(c, n, nDigits) >= 0)
		return (RSA_ERROR_DATA);
	
	/* compute mP = cP^dP mod p  and  mQ = cQ^dQ mod q. (Assumes q has
	 * length at most pDigits, i.e., p > q.)
	 */
	mpi_mod(cP, c, cDigits, p, pDigits);
	mpi_mod(cQ, c, cDigits, q, pDigits);
	mpi_mod_exp(mP, cP, dP, pDigits, p, pDigits);
	mpi_assign_zero(mQ, nDigits);
	mpi_mod_exp(mQ, cQ, dQ, pDigits, q, pDigits);
	
	/* Chinese Remainder Theorem:
	m = ((((mP - mQ) mod p) * qInv) mod p) * q + mQ.
	*/
	if (mpi_cmp(mP, mQ, pDigits) >= 0)
		mpi_sub(t, mP, mQ, pDigits);
	else {
		mpi_sub(t, mQ, mP, pDigits);
		mpi_sub(t, p, t, pDigits);
	}
	mpi_mod_mult(t, t, qInv, p, pDigits);
	mpi_mult(t, t, q, pDigits);
	mpi_add(t, t, mQ, nDigits);
	
	*outputLen = (privateKey->bits + 7) / 8;
	mpi_encode(output, *outputLen, t, nDigits);
	
	/* burn sensitive information */
	memset(c, 0, sizeof (c));
	memset(cP, 0, sizeof (cP));
	memset(cQ, 0, sizeof (cQ));
	memset(dP, 0, sizeof (dP));
	memset(dQ, 0, sizeof (dQ));
	memset(mP, 0, sizeof (mP));
	memset(mQ, 0, sizeof (mQ));
	memset(p, 0, sizeof (p));
	memset(q, 0, sizeof (q));
	memset(qInv, 0, sizeof (qInv));
	memset(t, 0, sizeof (t));
	
	return (0);
}

#ifdef CONFIG_TEST

rsa_public_t rsa_test_public_key;
rsa_private_t rsa_test_private_key;

static void rsa_write_bigint(uint8_t *integer,
			     size_t integerLen)
{
	unsigned int i = 0;

	while (*integer == 0 && integerLen > 0) {
		integer++;
		integerLen--;
	}
	if (integerLen == 0) {
		/* Special case, just print a zero. */
		printf("    00\n");
		return;
	}
	for (; integerLen > 0; integerLen--, i++) {
		if ((i % 16) == 0)
			printf("\n    ");
		printf("%02x ", (unsigned int)(*integer++));
	}
	printf("\n");
}

static void rsa_test_write_keypair(void)
{
	printf("Public Key, %u bits:\n", rsa_test_public_key.bits);
	printf("  n (modulus): ");
	rsa_write_bigint(rsa_test_public_key.n,
			 sizeof (rsa_test_public_key.n));
	printf("  e (public exponent): ");
	rsa_write_bigint(rsa_test_public_key.e,
			 sizeof (rsa_test_public_key.e));
	
	printf("\nPrivate Key, %u bits:\n", rsa_test_private_key.bits);
	printf("  n (modulus): ");
	rsa_write_bigint(rsa_test_private_key.n,
			 sizeof (rsa_test_private_key.n));
	printf("  e (public exponent): ");
	rsa_write_bigint(rsa_test_private_key.e,
			 sizeof (rsa_test_private_key.e));
	printf("  d (private exponent): ");
	rsa_write_bigint(rsa_test_private_key.d,
			 sizeof (rsa_test_private_key.d));
	printf("  r[1] (prime 1): ");
	rsa_write_bigint(rsa_test_private_key.r[0],
			 sizeof (rsa_test_private_key.r[0]));
	printf("  r[2] (prime 2): ");
	rsa_write_bigint(rsa_test_private_key.r[1],
			 sizeof (rsa_test_private_key.r[1]));
	printf("  d[1] (prime exponent 1): ");
	rsa_write_bigint(rsa_test_private_key.dR[0],
			 sizeof (rsa_test_private_key.dR[0]));
	printf("  d[2] (prime exponent 2): ");
	rsa_write_bigint(rsa_test_private_key.dR[1],
			 sizeof (rsa_test_private_key.dR[1]));
	printf("  t (coefficient): ");
	rsa_write_bigint(rsa_test_private_key.t,
			 sizeof (rsa_test_private_key.t));
}

static void rsa_test_generate_keys(int keySize)
{
	rsa_param_t protoKey;
	int status;
	
	protoKey.bits = (unsigned int)keySize;
	protoKey.useFermat4 = 1;
	
	status = rsa_gen_pem_keys(&rsa_test_public_key,
				  &rsa_test_private_key,
				  &protoKey);
	assert(status == 0);
	rsa_test_write_keypair();
}

void crypto_rsa_test(void);

void crypto_rsa_test(void)
{
	rsa_test_generate_keys(1024);
}
#endif
