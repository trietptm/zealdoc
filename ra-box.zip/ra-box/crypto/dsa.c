#include <dsa.h>

static void (*dsa_progress_cb)(void *, int);
static void *dsa_progress_data;

void dsa_register_progress(void (*cb)(void *, int), void *cb_data)
{
	dsa_progress_cb = cb;
	dsa_progress_data = cb_data;
}

static void dsa_progress(int c)
{
	if (dsa_progress_cb)
		dsa_progress_cb(dsa_progress_data, c);
	else
		fputc(c, stderr);
}
