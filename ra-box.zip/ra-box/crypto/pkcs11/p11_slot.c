#include <pkcs11_rabox.h>
#include "p11_priv.h"


#include <pcsc.h>

DECLARE_LIST(p11_slots);

#define for_each_slot(e)		\
	list_for_each_entry(struct pkcs11_slot, e, &p11_slots, link)
#define for_each_slot_safe(e, n)		\
	list_for_each_entry_safe(struct pkcs11_slot, e, n, &p11_slots, link)

struct pkcs11_card {
	int reader;
	/* PCSC use slot as handle */
	struct pcsc_slot_t *card;
#if 0
	struct sc_pkcs11_framework_ops *framework;
	void *fw_data;
	sc_timestamp_t slot_state_expires;
#endif
	/* Number of slots owned by this card object */
	unsigned int num_slots;
	unsigned int max_slots;
	unsigned int first_slot;

#if 0
	/* List of supported mechanisms */
	struct sc_pkcs11_mechanism_type **mechanisms;
#endif
	unsigned int nmechanisms;
};

struct pkcs11_slot {
	int login_user;
	/* Slot specific information (information about reader) */
	CK_SLOT_INFO slot_info;
	/* Token specific information (information about card) */
	CK_TOKEN_INFO token_info;

	/* Reader to which card is allocated (same as card->reader
	 * if there's a card present) */
	int reader;

	/* The card associated with this slot */
	struct pkcs11_card *card;
	/* Card events SC_EVENT_CARD_{INSERTED,REMOVED} */
	int events;
	/* Framework specific data */
	void *fw_data;
#if 0
	/* Object pools */
	struct sc_pkcs11_pool object_pool;
#endif
	/* Number of sessions using this slot */
	unsigned int nsessions;
	void *pcsc_slot;
	list_t link;
};

typedef struct pkcs11_slot pkcs11_slot_t;

CK_RV C_GetSlotList(CK_BBOOL       tokenPresent,  /* only slots with token present */
		    CK_SLOT_ID_PTR pSlotList,     /* receives the array of slot IDs */
		    CK_ULONG_PTR   pulCount)      /* receives the number of slots */
{
	CK_SLOT_ID found[PCSC_MAX_SLOTS];
	CK_ULONG numMatches;
	CK_RV rv;
	CK_SLOT_ID id;

	if (pulCount == NULL_PTR) {
		rv = CKR_ARGUMENTS_BAD;
		goto out;
	}

	p11_log(P11_API_LOG, "Getting slot listing");

	id = PCSC_VALID_IDX;
	numMatches = 0;

	/* TODO: use p11's slot */
	do {
		if (tokenPresent)
			id = (CK_SLOT_ID)pcsc_next_present_unlock_slot((uint16_t)id);
		else
			id = (CK_SLOT_ID)pcsc_next_unlock_slot((uint16_t)id);
		if (id != PCSC_VALID_IDX)
			found[numMatches++] = id;
	} while (id == PCSC_VALID_IDX);

	if (pSlotList == NULL_PTR) {
		p11_log(P11_LOG_INFO, "was only a size inquiry (%d)", numMatches);
		*pulCount = numMatches;
		rv = CKR_OK;
		goto out;
	}

	if (*pulCount < numMatches) {
		p11_log(P11_LOG_INFO, "buffer was too small (needed %d)", numMatches);
		*pulCount = numMatches;
		rv = CKR_BUFFER_TOO_SMALL;
		goto out;
	}

	memcpy(pSlotList, found, numMatches * sizeof(CK_SLOT_ID));
	*pulCount = numMatches;
	rv = CKR_OK;

	p11_log(P11_API_LOG, "returned %d slots", numMatches);
out:
	return rv;
}

CK_RV C_GetSlotInfo(CK_SLOT_ID slotID, CK_SLOT_INFO_PTR pInfo)
{
	p11_log(P11_API_LOG, "Getting info about slot %d", slotID);
	return CKR_FUNCTION_NOT_SUPPORTED;
}

CK_RV C_GetTokenInfo(CK_SLOT_ID slotID, CK_TOKEN_INFO_PTR pInfo)
{
	p11_log(P11_API_LOG, "Getting info about token %d", slotID);
	return CKR_FUNCTION_NOT_SUPPORTED;
}

CK_RV C_WaitForSlotEvent(CK_FLAGS flags,	/* blocking/nonblocking flag */
			 CK_SLOT_ID_PTR pSlot,  /* location that receives the slot ID */
			 CK_VOID_PTR pReserved) /* reserved.  Should be NULL_PTR */
{
	p11_log(P11_API_LOG, "C_WaitForSlotEvent");
	return CKR_FUNCTION_NOT_SUPPORTED;
}

CK_RV C_GetMechanismList(CK_SLOT_ID slotID,
			 CK_MECHANISM_TYPE_PTR pMechanismList,
                         CK_ULONG_PTR pulCount)
{
	/* p11 Page 188 */
	return 8;
}

CK_RV C_GetMechanismInfo(CK_SLOT_ID slotID,
			 CK_MECHANISM_TYPE type,
			 CK_MECHANISM_INFO_PTR pInfo)
{
	return 9;
}

CK_RV C_InitToken(CK_SLOT_ID slotID,
		  CK_CHAR_PTR pPin,
		  CK_ULONG ulPinLen,
		  CK_CHAR_PTR pLabel)
{
	return 10;
}

CK_RV C_InitPIN(CK_SESSION_HANDLE hSession,
		CK_CHAR_PTR pPin,
		CK_ULONG ulPinLen)
{
	return 11;
}

CK_RV C_SetPIN(CK_SESSION_HANDLE hSession,
	       CK_CHAR_PTR pOldPin,
	       CK_ULONG ulOldLen,
	       CK_CHAR_PTR pNewPin,
	       CK_ULONG ulNewLen)
{
	return 11;
}

static void p11_slot_free(struct pkcs11_slot *slot);
static struct pkcs11_slot *__get_slot_by_lower(void *lower);
static struct pkcs11_slot *p11_slot_new(void);
static struct pkcs11_card *p11_card_new(void);
static void p11_card_free(struct pkcs11_card *card);
static void p11_slot_add(void *pcsc_slot);
static void p11_slot_del(void *pcsc_slot);
static void p11_icc_insert(void *pcsc_slot);
static void p11_icc_remove(void *pcsc_slot);

static struct pkcs11_slot *__get_slot_by_lower(void *lower)
{
	struct pkcs11_slot *slot;

	for_each_slot(slot) {
		if (slot->pcsc_slot == lower)
			return slot;
	}
	return NULL;
}

static struct pkcs11_slot *p11_slot_new(void)
{
	struct pkcs11_slot *slot = malloc(sizeof (struct pkcs11_slot));

	if (!slot)
		return NULL;
	memset(slot, 0, sizeof (struct pkcs11_slot));
	
	list_init(&slot->link);
	list_insert_before(&slot->link, &p11_slots);
	p11_log(P11_LOG_INFO, "SLOT: create slot");
	return slot;
}

static void p11_slot_free(struct pkcs11_slot *slot)
{
	list_delete(&slot->link);
	free(slot);
	p11_log(P11_LOG_INFO, "SLOT: delete slot");
}

static struct pkcs11_card *p11_card_new(void)
{
	struct pkcs11_card *card = malloc(sizeof (struct pkcs11_card));

	if (!card)
		return NULL;
	memset(card, 0, sizeof (struct pkcs11_card));
	
	p11_log(P11_LOG_INFO, "SLOT: create card");
	return card;
}

static void p11_card_free(struct pkcs11_card *card)
{
	free(card);
	p11_log(P11_LOG_INFO, "SLOT: delete card");
}

static void p11_slot_add(void *pcsc_slot)
{
	struct pkcs11_slot *slot = p11_slot_new();

	if (!slot) {
		p11_log(P11_LOG_ERR, "SLOT: out of memory");
		return;
	}
	
	slot->pcsc_slot = pcsc_slot;
}

static void p11_slot_del(void *pcsc_slot)
{
	struct pkcs11_slot *slot;

	slot = __get_slot_by_lower(pcsc_slot);
	if (slot)
		p11_slot_free(slot);
}

static void p11_icc_insert(void *pcsc_slot)
{
	struct pkcs11_slot *slot;

	slot = __get_slot_by_lower(pcsc_slot);
	if (slot) {
		struct pkcs11_card *card = p11_card_new();
		if (!card)
			return;
		BUG_ON(slot->card);
		slot->card = card;
	}
}

static void p11_icc_remove(void *pcsc_slot)
{
	struct pkcs11_slot *slot;

	slot = __get_slot_by_lower(pcsc_slot);
	if (slot && slot->card) {
		p11_card_free(slot->card);
		slot->card = NULL;
	}
}

static int p11_pcsc_event(notify_t *nb,
			  unsigned long event, void *data)
{
	switch(event) {
	case PCSC_ICC_REMOVE:
		p11_icc_remove(data);
		break;
	case PCSC_ICC_INSERT:
		p11_icc_insert(data);
		break;
	case PCSC_SLOT_ADD:
		p11_slot_add(data);
		break;
	case PCSC_SLOT_DEL:
		p11_slot_del(data);
		break;
	default:
		break;
	}
	return 0;
}

static notify_t p11_pcsc_notify = {
	NULL,
	p11_pcsc_event,
	9,
};

int __init pkcs11_slot_init(void)
{
	pcsc_register_notify(&p11_pcsc_notify);

	return 0;
}

void __exit pkcs11_slot_exit(void)
{
	pcsc_unregister_notify(&p11_pcsc_notify);
}

