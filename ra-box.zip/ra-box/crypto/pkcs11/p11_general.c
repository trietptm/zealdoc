#include <pkcs11_rabox.h>
#include "p11_priv.h"

CK_RV C_Initialize(CK_VOID_PTR pInitArgs)
{
	/* not support */
	if (pInitArgs != NULL_PTR)
		return CKR_ARGUMENTS_BAD;
	/* nothing to do */
	return CKR_OK;
}

CK_RV C_Finalize(CK_VOID_PTR pReserved)
{
	if (pReserved != NULL_PTR)
		return CKR_ARGUMENTS_BAD;
	/* nothing to do */
	return CKR_OK;
}

CK_RV C_GetInfo(CK_INFO_PTR pInfo)
{
	int rv;

	p11_log(P11_API_LOG, "Cryptoki info query");
	if (pInfo == NULL_PTR) {
		rv = CKR_ARGUMENTS_BAD;
		goto out;
	}

	memset(pInfo, 0, sizeof(CK_INFO));
	pInfo->cryptokiVersion.major = CRYPTOKI_VERSION_MAJOR;
	pInfo->cryptokiVersion.minor = CRYPTOKI_VERSION_MINOR;
	strncpy(pInfo->manufacturerID, P11_MAN_ID, sizeof(pInfo->manufacturerID));
	strncpy(pInfo->libraryDescription, P11_LIB_DESC, sizeof(pInfo->libraryDescription));
	pInfo->libraryVersion.major = 1;
	pInfo->libraryVersion.minor = 0;

out:
	return rv;
}	

CK_RV C_GetFunctionList(CK_FUNCTION_LIST_PTR_PTR ppFunctionList)
{
	if (ppFunctionList == NULL_PTR)
		return CKR_ARGUMENTS_BAD;

	*ppFunctionList = &pkcs11_function_list;
	return CKR_OK;
}

