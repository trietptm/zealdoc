#ifndef P11_PRIV_H
#define P11_PRIV_H

#include <sysdep.h>
#include <logger.h>
#include <module.h>
#include <list.h>
#include <panic.h>

#define P11_LOG_CRIT	LOG_EMERG
#define P11_LOG_FAIL	LOG_CRIT
#define P11_LOG_ERR	LOG_ERR
#define P11_LOG_WARN	LOG_WARNING
#define P11_LOG_INFO	LOG_INFO
#define P11_LOG_DEBUG	LOG_DEBUG

#define P11_API_LOG	P11_LOG_INFO
//#define LOG_CALL_CHAIN	PCSC_LOG_DEBUG
#define P11_SHOW	P11_LOG_INFO

void p11_log(int level, const char *format, ...);

/* p11_slot.c */
int __init pkcs11_slot_init(void);
void __exit pkcs11_slot_exit(void);

#endif	/* P11_PRIV_H */

