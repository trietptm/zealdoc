#include <pkcs11_rabox.h>
#include "p11_priv.h"

/* soliton p11 module implement function list */
CK_FUNCTION_LIST pkcs11_function_list = {
	{ 2, 20 },
	/* General purpose functions - p11_general.c */
	C_Initialize,
	C_Finalize,
	C_GetInfo,
	C_GetFunctionList,
	/* Slot and token management functions - p11_slot.c */
	C_GetSlotList,
	C_GetSlotInfo,
	C_GetTokenInfo,
	C_GetMechanismList,
	C_GetMechanismInfo,
	C_InitToken,
	C_InitPIN,
	C_SetPIN,
	/* Session management functions - p11_session.c */
	C_OpenSession,
	C_CloseSession,
	C_CloseAllSessions,
	C_GetSessionInfo,
	C_GetOperationState,
	C_SetOperationState,
	C_Login,
	C_Logout,
	/* Object management functions - p11_object.c */
	C_CreateObject,
	C_CopyObject,
	C_DestroyObject,
	C_GetObjectSize,
	C_GetAttributeValue,
	C_SetAttributeValue,
	C_FindObjectsInit,
	C_FindObjects,
	C_FindObjectsFinal,
	/* Encryption functions - p11_encrypt.c */
	C_EncryptInit,
	C_Encrypt,
	C_EncryptUpdate,
	C_EncryptFinal,
	/* Decryption functions - p11_decrypt.c */
	C_DecryptInit,
	C_Decrypt,
	C_DecryptUpdate,
	C_DecryptFinal,
	/* Message digesting functions */
	C_DigestInit,
	C_Digest,
	C_DigestUpdate,
	C_DigestKey,
	C_DigestFinal,
	/* Signing and MACing functions */
	C_SignInit,
	C_Sign,
	C_SignUpdate,
	C_SignFinal,
	C_SignRecoverInit,
	C_SignRecover,
	/* Functions for verifying signatures and MACs */
	C_VerifyInit,
	C_Verify,
	C_VerifyUpdate,
	C_VerifyFinal,
	C_VerifyRecoverInit,
	C_VerifyRecover,
	/* Dual-purpose cryptographic functions */
	C_DigestEncryptUpdate,
	C_DecryptDigestUpdate,
	C_SignEncryptUpdate,
	C_DecryptVerifyUpdate,
	/* Key management functions */
	C_GenerateKey,
	C_GenerateKeyPair,
	C_WrapKey,
	C_UnwrapKey,
	C_DeriveKey,
	/* Random number generation functions */
	C_SeedRandom,
	C_GenerateRandom,
	/* Parallel function management functions */
	C_GetFunctionStatus,
	C_CancelFunction,
	/* None?? */
	C_WaitForSlotEvent,
};

int p11_logger = 0;
log_source_t p11_log_source = {
	"pkcs11"
};

void p11_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(p11_logger, level, format, ap);
	va_end(ap);
}

static int __init p11_log_init(void)
{
	p11_logger = log_register_source(&p11_log_source);
	return !p11_logger;
}

static void __exit p11_log_exit(void)
{
	log_unregister_source(p11_logger);
}

modlinkage int __init pkcs11_init(void)
{

	p11_log_init();
	pkcs11_slot_init();
	return 0;
}

modlinkage void __exit pkcs11_exit(void)
{
	pkcs11_slot_exit();
	p11_log_exit();
}

subsys_initcall(pkcs11_init);
subsys_exitcall(pkcs11_exit);

