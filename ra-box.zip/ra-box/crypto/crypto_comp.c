/*
 * Cryptographic API.
 *
 * Compression operations.
 *
 * Copyright (c) 2002 James Morris <jmorris@intercode.com.au>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option) 
 * any later version.
 *
 */
#include "crypto_priv.h"

static int crypto_compress(crypto_tfm_t *tfm,
			   const uint8_t *src, unsigned int slen,
			   uint8_t *dst, unsigned int *dlen)
{
	return tfm->__crt_alg->cra_compress.coa_compress(tfm, src, slen, dst,
	                                                 dlen);
}

static int crypto_decompress(crypto_tfm_t *tfm,
                             const uint8_t *src, unsigned int slen,
                             uint8_t *dst, unsigned int *dlen)
{
	return tfm->__crt_alg->cra_compress.coa_decompress(tfm, src,
							   slen, dst,
	                                                   dlen);
}

int crypto_init_compress_ops(crypto_tfm_t *tfm)
{
	struct compress_tfm *ops = &tfm->crt_compress;

	ops->cot_compress = crypto_compress;
	ops->cot_decompress = crypto_decompress;
	
	return 0;
}

void crypto_exit_compress_ops(crypto_tfm_t *tfm)
{
}
