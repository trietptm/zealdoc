/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2003
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@hzcnc.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)mpi.c: multi-precision integer functions
 * $Id: mpi.c,v 1.1 2008-07-18 03:25:42 zhenglv Exp $
 */

#include <mpi.h>
#include <strutl.h>
#include <stdlib.h>
#include <memory.h>

static mpi_t mpi_add_digit_mult(mpi_t *, mpi_t *, mpi_t, mpi_t *, unsigned int);
static mpi_t mpi_sub_digit_mult(mpi_t *, mpi_t *, mpi_t, mpi_t *, unsigned int);

static unsigned int mpi_digit_bits(mpi_t);

/* Decodes character string b into a, where character string is ordered
 * from most to least significant.
 *
 * Lengths: a[digits], b[len].
 * Assumes b[i] = 0 for i < len - digits * MPI_DIGIT_BYTES. (Otherwise most
 * significant bytes are truncated.)
 */
void mpi_decode(mpi_t *a, unsigned int digits,
		uint8_t *b, size_t len)
{
	mpi_t t;
	int j;
	unsigned int i, u;
	
	for (i = 0, j = len - 1; i < digits && j >= 0; i++) {
		t = 0;
		for (u = 0; j >= 0 && u < MPI_DIGIT_BITS; j--, u += 8)
			t |= ((mpi_t)b[j]) << u;
		a[i] = t;
	}
	for (; i < digits; i++)
		a[i] = 0;
}

/* Encodes b into character string a, where character string is ordered
 * from most to least significant.
 *
 * Lengths: a[len], b[digits].
 * Assumes mpi_bits(b, digits) <= 8 * len. (Otherwise most significant
 * digits are truncated.)
 */
void mpi_encode(uint8_t *a, size_t len,
		mpi_t *b, unsigned int digits)
{
	mpi_t t;
	int j;
	unsigned int i, u;
	
	for (i = 0, j = len - 1; i < digits && j >= 0; i++) {
		t = b[i];
		for (u = 0; j >= 0 && u < MPI_DIGIT_BITS; j--, u += 8)
			a[j] = (unsigned char)(t >> u);
	}
	for (; j >= 0; j--)
		a[j] = 0;
}

/* Assigns a = b.
 *
 * Lengths: a[digits], b[digits].
 */
void mpi_assign(mpi_t *a, mpi_t *b, unsigned int digits)
{
	unsigned int i;
	
	for (i = 0; i < digits; i++)
		a[i] = b[i];
}

/* Assigns a = 0.
 *
 * Lengths: a[digits].
 */
void mpi_assign_zero(mpi_t *a, unsigned int digits)
{
	unsigned int i;
	
	for (i = 0; i < digits; i++)
		a[i] = 0;
}

/* Assigns a = 2^b.
 *
 * Lengths: a[digits].
 * Requires b < digits * MPI_DIGIT_BITS.
 */
void mpi_assign_2exp(mpi_t *a, unsigned int b, unsigned int digits)
{
	mpi_assign_zero(a, digits);
	
	if (b >= digits * MPI_DIGIT_BITS)
		return;
	
	a[b / MPI_DIGIT_BITS] = (mpi_t)1 << (b % MPI_DIGIT_BITS);
}

/* Computes a = b + c. Returns carry.
 *
 * Lengths: a[digits], b[digits], c[digits].
 */
mpi_t mpi_add(mpi_t *a, mpi_t *b, mpi_t *c, unsigned int digits)
{
	mpi_t ai, carry;
	unsigned int i;
	
	carry = 0;

	for (i = 0; i < digits; i++) {
		if ((ai = b[i] + carry) < carry)
			ai = c[i];
		else if ((ai += c[i]) < c[i])
			carry = 1;
		else
			carry = 0;
		a[i] = ai;
	}
	return (carry);
}

/* Computes a = b - c. Returns borrow.
 *
 * Lengths: a[digits], b[digits], c[digits].
 */
mpi_t mpi_sub(mpi_t *a, mpi_t *b, mpi_t *c, unsigned int digits)
{
	mpi_t ai, borrow;
	unsigned int i;
	
	borrow = 0;
	
	for (i = 0; i < digits; i++) {
		if ((ai = b[i] - borrow) > (MAX_MPI_DIGIT - borrow))
			ai = MAX_MPI_DIGIT - c[i];
		else if ((ai -= c[i]) > (MAX_MPI_DIGIT - c[i]))
			borrow = 1;
		else
			borrow = 0;
		a[i] = ai;
	}
	return (borrow);
}

/* Computes a = b * c.
 *
 * Lengths: a[2*digits], b[digits], c[digits].
 * Assumes digits < MAX_MPI_DIGITS.
 */
void mpi_mult(mpi_t *a, mpi_t *b, mpi_t *c, unsigned int digits)
{
	mpi_t t[2*MAX_MPI_DIGITS];
	unsigned int bDigits, cDigits, i;
	
	mpi_assign_zero(t, 2 * digits);
	
	bDigits = mpi_digits(b, digits);
	cDigits = mpi_digits(c, digits);
	
	for (i = 0; i < bDigits; i++)
		t[i+cDigits] += mpi_add_digit_mult(&t[i], &t[i], b[i], c, cDigits);
	
	mpi_assign(a, t, 2 * digits);
	
	/* burn potentially sensitive information */
	memset((unsigned char *)t, 0, sizeof (t));
}

/* Computes a = b * 2^c (i.e., shifts left c bits), returning carry.
 *
 * Lengths: a[digits], b[digits].
 * Requires c < MPI_DIGIT_BITS.
 */
mpi_t mpi_left_shift(mpi_t *a, mpi_t *b, unsigned int c, unsigned int digits)
{
	mpi_t bi, carry;
	unsigned int i, t;
	
	if (c >= MPI_DIGIT_BITS)
		return (0);
	
	t = MPI_DIGIT_BITS - c;
	
	carry = 0;
	
	for (i = 0; i < digits; i++) {
		bi = b[i];
		a[i] = (bi << c) | carry;
		carry = c ? (bi >> t) : 0;
	}
	return (carry);
}

/* Computes a = c div 2^c (i.e., shifts right c bits), returning carry.
 *
 * Lengths: a[digits], b[digits].
 * Requires: c < MPI_DIGIT_BITS.
 */
mpi_t mpi_right_shift(mpi_t *a, mpi_t *b, unsigned int c, unsigned int digits)
{
	mpi_t bi, carry;
	int i;
	unsigned int t;
	
	if (c >= MPI_DIGIT_BITS)
		return (0);
	
	t = MPI_DIGIT_BITS - c;
	
	carry = 0;
	
	for (i = digits - 1; i >= 0; i--) {
		bi = b[i];
		a[i] = (bi >> c) | carry;
		carry = c ? (bi << t) : 0;
	}
	return (carry);
}

/* Computes a = c div d and b = c mod d.
 *
 * Lengths: a[cDigits], b[dDigits], c[cDigits], d[dDigits].
 * Assumes d > 0, cDigits < 2 * MAX_MPI_DIGITS,
 *         dDigits < MAX_MPI_DIGITS.
 */
void mpi_div(mpi_t *a, mpi_t *b, mpi_t *c, unsigned int cDigits, mpi_t *d, unsigned int dDigits)
{
	mpi_t ai, cc[2*MAX_MPI_DIGITS+1], dd[MAX_MPI_DIGITS], t;
	int i;
	unsigned int ddDigits, shift;
	
	ddDigits = mpi_digits(d, dDigits);
	if (ddDigits == 0)
		return;
	
	/* normalize operands */
	shift = MPI_DIGIT_BITS - mpi_digit_bits(d[ddDigits-1]);
	mpi_assign_zero(cc, ddDigits);
	cc[cDigits] = mpi_left_shift(cc, c, shift, cDigits);
	mpi_left_shift(dd, d, shift, ddDigits);
	t = dd[ddDigits-1];
	
	mpi_assign_zero(a, cDigits);
	
	for (i = cDigits-ddDigits; i >= 0; i--) {
		/* underestimate quotient digit and subtract */
		if (t == MAX_MPI_DIGIT)
			ai = cc[i+ddDigits];
		else
			mpi_digit_div(&ai, &cc[i+ddDigits-1], t + 1);
		cc[i+ddDigits] -= mpi_sub_digit_mult(&cc[i], &cc[i], ai, dd, ddDigits);
		
		/* correct estimate */
		while (cc[i+ddDigits] || (mpi_cmp(&cc[i], dd, ddDigits) >= 0)) {
			ai++;
			cc[i+ddDigits] -= mpi_sub(&cc[i], &cc[i], dd, ddDigits);
		}
		
		a[i] = ai;
	}
	
	/* restore result. */
	mpi_assign_zero(b, dDigits);
	mpi_right_shift(b, cc, shift, ddDigits);
	
	/* burn potentially sensitive information */
	memset((unsigned char *)cc, 0, sizeof (cc));
	memset((unsigned char *)dd, 0, sizeof (dd));
}

/* Computes a = b mod c.
 *
 * Lengths: a[cDigits], b[bDigits], c[cDigits].
 * Assumes c > 0, bDigits < 2 * MAX_MPI_DIGITS, cDigits < MAX_MPI_DIGITS.
 */
void mpi_mod(mpi_t *a, mpi_t *b, unsigned int bDigits,
	     mpi_t *c, unsigned int cDigits)
{
	mpi_t t[2 * MAX_MPI_DIGITS];
	
	mpi_div(t, a, b, bDigits, c, cDigits);
	
	/* burn potentially sensitive information */
	memset((unsigned char *)t, 0, sizeof (t));
}

/* Computes a = b * c mod d.
 *
 * Lengths: a[digits], b[digits], c[digits], d[digits].
 * Assumes d > 0, digits < MAX_MPI_DIGITS.
 */
void mpi_mod_mult(mpi_t *a, mpi_t *b, mpi_t *c, mpi_t *d, unsigned int digits)
{
	mpi_t t[2*MAX_MPI_DIGITS];
	
	mpi_mult(t, b, c, digits);
	mpi_mod(a, t, 2 * digits, d, digits);
	
	/* burn potentially sensitive information */
	memset((unsigned char *)t, 0, sizeof (t));
}

/* Computes a = b^c mod d.
 *
 * Lengths: a[dDigits], b[dDigits], c[cDigits], d[dDigits].
 * Assumes d > 0, cDigits > 0, dDigits < MAX_MPI_DIGITS.
 */
void mpi_mod_exp(mpi_t *a, mpi_t *b, mpi_t *c, unsigned int cDigits, mpi_t *d, unsigned int dDigits)
{
	mpi_t bPower[3][MAX_MPI_DIGITS], ci, t[MAX_MPI_DIGITS];
	int i;
	unsigned int ciBits, j, s;
	
	/* store b, b^2 mod d, and b^3 mod d */
	mpi_assign(bPower[0], b, dDigits);
	mpi_mod_mult(bPower[1], bPower[0], b, d, dDigits);
	mpi_mod_mult(bPower[2], bPower[1], b, d, dDigits);
	
	mpi_assign_digit(t, 1, dDigits);
	
	cDigits = mpi_digits(c, cDigits);
	for (i = cDigits - 1; i >= 0; i--) {
		ci = c[i];
		ciBits = MPI_DIGIT_BITS;
		
		/* Scan past leading zero bits of most significant digit. */
		if (i == (int)(cDigits - 1)) {
			while (!DIGIT_2MSB(ci)) {
				ci <<= 2;
				ciBits -= 2;
			}
		}
		
		for (j = 0; j < ciBits; j += 2, ci <<= 2) {
			/* compute t = t^4 * b^s mod d, where s = two MSB's of ci */
			mpi_mod_mult(t, t, t, d, dDigits);
			mpi_mod_mult(t, t, t, d, dDigits);
			if ((s = DIGIT_2MSB(ci)) != 0)
				mpi_mod_mult(t, t, bPower[s-1], d, dDigits);
		}
	}
	
	mpi_assign(a, t, dDigits);
	
	/* burn potentially sensitive information */
	memset((unsigned char *)bPower, 0, sizeof (bPower));
	memset((unsigned char *)t, 0, sizeof (t));
}

/* Compute a = 1/b mod c, assuming inverse exists.
 *
 * Lengths: a[digits], b[digits], c[digits].
 * Assumes gcd(b, c) = 1, digits < MAX_MPI_DIGITS.
 */
void mpi_mod_inv(mpi_t *a, mpi_t *b, mpi_t *c, unsigned int digits)
{
	mpi_t q[MAX_MPI_DIGITS], t1[MAX_MPI_DIGITS], t3[MAX_MPI_DIGITS];
	mpi_t u1[MAX_MPI_DIGITS], u3[MAX_MPI_DIGITS], v1[MAX_MPI_DIGITS];
	mpi_t v3[MAX_MPI_DIGITS], w[2*MAX_MPI_DIGITS];
	int u1Sign;
	
	/*
	 * apply extended Euclidean algorithm, modified to avoid negative
	 * numbers.
	 */
	mpi_assign_digit(u1, 1, digits);
	mpi_assign_zero(v1, digits);
	mpi_assign(u3, b, digits);
	mpi_assign(v3, c, digits);
	u1Sign = 1;
	
	while (!mpi_zero(v3, digits)) {
		mpi_div(q, t3, u3, digits, v3, digits);
		mpi_mult(w, q, v1, digits);
		mpi_add(t1, u1, w, digits);
		mpi_assign(u1, v1, digits);
		mpi_assign(v1, t1, digits);
		mpi_assign(u3, v3, digits);
		mpi_assign(v3, t3, digits);
		u1Sign = -u1Sign;
	}
	
	/* negate result if sign is negative */
	if (u1Sign < 0)
		mpi_sub(a, c, u1, digits);
	else
		mpi_assign(a, u1, digits);
	
	/* burn potentially sensitive information */
	memset((unsigned char *)q, 0, sizeof (q));
	memset((unsigned char *)t1, 0, sizeof (t1));
	memset((unsigned char *)t3, 0, sizeof (t3));
	memset((unsigned char *)u1, 0, sizeof (u1));
	memset((unsigned char *)u3, 0, sizeof (u3));
	memset((unsigned char *)v1, 0, sizeof (v1));
	memset((unsigned char *)v3, 0, sizeof (v3));
	memset((unsigned char *)w, 0, sizeof (w));
}

/* Computes a = gcd(b, c).
 *
 * Lengths: a[digits], b[digits], c[digits].
 * Assumes b > c, digits < MAX_MPI_DIGITS.
 */
void mpi_gcd(mpi_t *a, mpi_t *b, mpi_t *c, unsigned int digits)
{
	mpi_t t[MAX_MPI_DIGITS], u[MAX_MPI_DIGITS], v[MAX_MPI_DIGITS];
	
	mpi_assign(u, b, digits);
	mpi_assign(v, c, digits);
	
	while (!mpi_zero(v, digits)) {
		mpi_mod(t, u, digits, v, digits);
		mpi_assign(u, v, digits);
		mpi_assign(v, t, digits);
	}
	
	mpi_assign(a, u, digits);
	
	/* burn potentially sensitive information */
	memset((unsigned char *)t, 0, sizeof (t));
	memset((unsigned char *)u, 0, sizeof (u));
	memset((unsigned char *)v, 0, sizeof (v));
}

/* Returns sign of a - b.
 *
 * Lengths: a[digits], b[digits].
 */
int mpi_cmp(mpi_t *a, mpi_t *b, unsigned int digits)
{
	int i;
	
	for (i = digits - 1; i >= 0; i--) {
		if (a[i] > b[i])
			return (1);
		if (a[i] < b[i])
			return (-1);
	}
	return (0);
}

/* Returns nonzero iff a is zero.
 *
 * Lengths: a[digits].
 */
int mpi_zero(mpi_t *a, unsigned int digits)
{
	unsigned int i;
	
	for (i = 0; i < digits; i++) {
		if (a[i])
			return (0);
	}
	return (1);
}

/* Returns the significant length of a in bits.
 *
 * Lengths: a[digits].
 */
unsigned int mpi_bits(mpi_t *a, unsigned int digits)
{
	if ((digits = mpi_digits(a, digits)) == 0)
		return (0);
	
	return ((digits - 1) * MPI_DIGIT_BITS + mpi_digit_bits(a[digits-1]));
}

/* Returns the significant length of a in digits.
 *
 * Lengths: a[digits].
 */
unsigned int mpi_digits(mpi_t *a, unsigned int digits)
{
	int i;
	
	for (i = digits - 1; i >= 0; i--) {
		if (a[i])
			break;
	}
	return (i + 1);
}

/* Computes a = b + c*d, where c is a digit. Returns carry.
 *
 * Lengths: a[digits], b[digits], d[digits].
 */
static mpi_t mpi_add_digit_mult(mpi_t *a, mpi_t *b, mpi_t c,
				mpi_t *d, unsigned int digits)
{
	mpi_t carry, t[2];
	unsigned int i;
	
	if (c == 0)
		return (0);
	
	carry = 0;
	for (i = 0; i < digits; i++) {
		mpi_digit_mult(t, c, d[i]);
		if ((a[i] = b[i] + carry) < carry)
			carry = 1;
		else
			carry = 0;
		if ((a[i] += t[0]) < t[0])
			carry++;
		carry += t[1];
	}
	return (carry);
}

/* Computes a = b - c*d, where c is a digit. Returns borrow.
 *
 * Lengths: a[digits], b[digits], d[digits].
 */
static mpi_t mpi_sub_digit_mult(mpi_t *a, mpi_t *b, mpi_t c,
				mpi_t *d, unsigned int digits)
{
	mpi_t borrow, t[2];
	unsigned int i;
	
	if (c == 0)
		return (0);
	
	borrow = 0;
	for (i = 0; i < digits; i++) {
		mpi_digit_mult(t, c, d[i]);
		if ((a[i] = b[i] - borrow) > (MAX_MPI_DIGIT - borrow))
			borrow = 1;
		else
			borrow = 0;
		if ((a[i] -= t[0]) > (MAX_MPI_DIGIT - t[0]))
			borrow++;
		borrow += t[1];
	}
	return (borrow);
}

/* Returns the significant length of a in bits, where a is a digit.
 */
static unsigned int mpi_digit_bits(mpi_t a)
{
	unsigned int i;
	
	for (i = 0; i < MPI_DIGIT_BITS; i++, a >>= 1) {
		if (a == 0)
			break;
	}
        return (i);
}

/* Computes a = b * c, where b and c are digits.
 *
 * Lengths: a[2].
 */
void mpi_digit_mult(mpi_t a[2], mpi_t b, mpi_t c)
{
	mpi_t t, u;
	hmpi_t bHigh, bLow, cHigh, cLow;
	
	bHigh = (hmpi_t)HIGH_HALF(b);
	bLow = (hmpi_t)LOW_HALF(b);
	cHigh = (hmpi_t)HIGH_HALF(c);
	cLow = (hmpi_t)LOW_HALF(c);
	
	a[0] = (mpi_t)bLow * (mpi_t)cLow;
	t = (mpi_t)bLow * (mpi_t)cHigh;
	u = (mpi_t)bHigh * (mpi_t)cLow;
	a[1] = (mpi_t)bHigh * (mpi_t)cHigh;
	
	if ((t += u) < u)
		a[1] += TO_HIGH_HALF(1);
	u = TO_HIGH_HALF(t);
	
	if ((a[0] += u) < u)
		a[1]++;
	a[1] += HIGH_HALF(t);
}

/* Sets a = b / c, where a and c are digits.
 *
 * Lengths: b[2].
 * Assumes b[1] < c and HIGH_HALF(c) > 0. For efficiency, c should be
 * normalized.
 */
void mpi_digit_div(mpi_t *a, mpi_t b[2], mpi_t c)
{
	mpi_t t[2], u, v;
	hmpi_t aHigh, aLow, cHigh, cLow;
	
	cHigh = (hmpi_t)HIGH_HALF(c);
	cLow = (hmpi_t)LOW_HALF(c);
	
	t[0] = b[0];
	t[1] = b[1];
	
	/* underestimate high half of quotient and subtract */
	if (cHigh == MAX_MPI_HALF_DIGIT)
		aHigh = (hmpi_t)HIGH_HALF(t[1]);
	else
		aHigh = (hmpi_t)(t[1] / (cHigh + 1));
	u = (mpi_t)aHigh * (mpi_t)cLow;
	v = (mpi_t)aHigh * (mpi_t)cHigh;
	if ((t[0] -= TO_HIGH_HALF(u)) > (MAX_MPI_DIGIT - TO_HIGH_HALF(u)))
		t[1]--;
	t[1] -= HIGH_HALF(u);
	t[1] -= v;
	
	/* correct estimate */
	while ((t[1] > cHigh) ||
		((t[1] == cHigh) && (t[0] >= TO_HIGH_HALF(cLow)))) {
		if ((t[0] -= TO_HIGH_HALF(cLow)) > MAX_MPI_DIGIT - TO_HIGH_HALF(cLow))
			t[1]--;
		t[1] -= cHigh;
		aHigh++;
	}
	
	/* underestimate low half of quotient and subtract */
	if (cHigh == MAX_MPI_HALF_DIGIT)
		aLow = (hmpi_t)LOW_HALF(t[1]);
	else
		aLow = (hmpi_t)((TO_HIGH_HALF(t[1]) + HIGH_HALF(t[0])) / (cHigh + 1));
	u = (mpi_t)aLow * (mpi_t)cLow;
	v = (mpi_t)aLow * (mpi_t)cHigh;
	if ((t[0] -= u) > (MAX_MPI_DIGIT - u))
		t[1]--;
	if ((t[0] -= TO_HIGH_HALF(v)) > (MAX_MPI_DIGIT - TO_HIGH_HALF (v)))
		t[1]--;
	t[1] -= HIGH_HALF (v);
	
	/* correct estimate */
	while ((t[1] > 0) || ((t[1] == 0) && t[0] >= c)) {
		if ((t[0] -= c) > (MAX_MPI_DIGIT - c))
			t[1]--;
		aLow++;
	}
	*a = TO_HIGH_HALF(aHigh) + aLow;
}
