#include "ccid_priv.h"
#include "ccid_usb.h"
#include <pcsc.h>
#include <pcsc_pinpad.h>

static ccid_desc_t *get_ccid_descriptor(ccid_reader_t *rdr)
{
	return (rdr) ? &rdr->ccid_desc : NULL;
}

int ccid_cancel(ccid_reader_t *handle)
{
	if (!handle)
		return CCID_ERROR_INVALID_SLOT;

	switch(handle->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		return ccid_usb_cancel(handle);
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
	return -1;
}

static void __ccid_get_slot_status_complete(struct ccid_trans_param *ccid_param)
{
	uint8_t *card_status = ccid_param->rbuf;

	if (ccid_param->ret == CCID_SUCCESS)
		*card_status = ccid_param->card_status;

	ccid_param->callback(ccid_param->user_data, ccid_param->ret);

	free(ccid_param);
}

int ccid_get_slot_status(ccid_reader_t *handle, uint8_t *card_status,
			 ccid_transfer_cb cb, void *user_data)
{
	struct ccid_trans_param *ccid_param;
	struct ccid_transfer *ccid_trans;
	int r;

	if (!handle) {
		ccid_log(CCID_LOG_WARN, "reader -1 is not exist");
		return CCID_ERROR_NO_DEVICE;
	}
	ccid_param = malloc(sizeof(struct ccid_trans_param));
	if (!ccid_param) return CCID_ERROR_NO_MEM;
	memset(ccid_param, 0, sizeof(struct ccid_trans_param));

	ccid_param->reader_idx = -1;
	ccid_param->rbuf = card_status;
	ccid_param->rbuf_len = 1;
	ccid_param->callback = cb;
	ccid_param->user_data = user_data;

	ccid_trans = ccid_alloc_transfer(PC_TO_RDR_GETSLOTSTATUS,
					 RDR_TO_PC_SLOTSTATUS);
	if (!ccid_trans) {
		free(ccid_param);
		return CCID_ERROR_NO_MEM;
	}
	ccid_trans->name = strdup("icc_status");
	ccid_trans->handle = handle;
	ccid_trans->callback = __ccid_get_slot_status_complete;
	ccid_trans->param = ccid_param;

	r = ccid_fill_cmd(ccid_trans);
	if (r != CCID_SUCCESS) {
		free(ccid_param);
		ccid_free_transfer(ccid_trans);
		return r;
	}

	r = ccid_submit(ccid_trans);
	if (r != CCID_SUCCESS) {
		free(ccid_param);
		ccid_free_transfer(ccid_trans);
	}

	return r;
}

static void __ccid_poweron_complete(struct ccid_trans_param *ccid_param)
{
	if (ccid_param->ret == CCID_SUCCESS)
		ccid_param->ret = ccid_param->rbuf_actual;

	ccid_param->callback(ccid_param->user_data, ccid_param->ret);

	free(ccid_param);
}

int ccid_power_on(ccid_reader_t *handle, uint8_t *atr_ret, size_t atr_len, 
		  ccid_transfer_cb callback, void *user_data)
{
	struct ccid_trans_param *ccid_param;
	struct ccid_transfer *ccid_trans;
	int r;

	if (!handle) {
		ccid_log(CCID_LOG_WARN, "reader %d is not exist", -1);
		return CCID_ERROR_NO_DEVICE;
	}
	ccid_param = malloc(sizeof(struct ccid_trans_param));
	if (!ccid_param) return CCID_ERROR_NO_MEM;
	memset(ccid_param, 0, sizeof(struct ccid_trans_param));
	
	ccid_param->reader_idx = -1;
	ccid_param->rbuf = atr_ret;
	ccid_param->rbuf_len = atr_len;
	ccid_param->callback = callback;
	ccid_param->user_data = user_data;

	ccid_trans = ccid_alloc_transfer(PC_TO_RDR_ICCPOWERON, 
					 RDR_TO_PC_DATABLOCK);
	if (!ccid_trans) {
		free(ccid_param);
		return CCID_ERROR_NO_MEM;
	}
	
	ccid_trans->name = strdup("power_on");
	ccid_trans->handle = handle;
	ccid_trans->callback = __ccid_poweron_complete;
	ccid_trans->param = ccid_param;

	r = ccid_fill_cmd(ccid_trans);
	if (r != CCID_SUCCESS) {
		free(ccid_param);
		ccid_free_transfer(ccid_trans);
		return r;
	}

	r = ccid_submit(ccid_trans);
	if (r != CCID_SUCCESS) {
		free(ccid_param);
		ccid_free_transfer(ccid_trans);
	}

	return r;
}

static void __ccid_poweroff_complete(struct ccid_trans_param *ccid_param)
{
	uint8_t *card_status = ccid_param->rbuf;

	if (ccid_param->ret == CCID_SUCCESS)
		*card_status = ccid_param->card_status;

	ccid_param->callback(ccid_param->user_data, ccid_param->ret);

	free(ccid_param);
}

int ccid_power_off(ccid_reader_t *handle, uint8_t *card_status,  
		   ccid_transfer_cb callback, void *user_data)
{
	struct ccid_trans_param *ccid_param;
	struct ccid_transfer *ccid_trans;
	int r;

	if (!handle) {
		ccid_log(CCID_LOG_WARN, "reader %d is not exist", -1);
		return CCID_ERROR_NO_DEVICE;
	}
	ccid_param = malloc(sizeof(struct ccid_trans_param));
	if (!ccid_param) return CCID_ERROR_NO_MEM;
	memset(ccid_param, 0, sizeof(struct ccid_trans_param));

	ccid_param->reader_idx = -1;
	ccid_param->rbuf = card_status;
	ccid_param->rbuf_len = 1;
	ccid_param->callback = callback;
	ccid_param->user_data = user_data;

	ccid_trans = ccid_alloc_transfer(PC_TO_RDR_ICCPOWEROFF, 
					 RDR_TO_PC_SLOTSTATUS);
	if (!ccid_trans) {
		free(ccid_param);
		return CCID_ERROR_NO_MEM;
	}
	
	ccid_trans->name = strdup("power_off");
	ccid_trans->handle = handle;
	ccid_trans->callback = __ccid_poweroff_complete;
	ccid_trans->param = ccid_param;

	r = ccid_fill_cmd(ccid_trans);
	if (r != CCID_SUCCESS) {
		free(ccid_param);
		ccid_free_transfer(ccid_trans);
		return r;
	}

	r = ccid_submit(ccid_trans);	
	if (r != CCID_SUCCESS) {
		free(ccid_param);
		ccid_free_transfer(ccid_trans);
	}

	return r;
}

static void __ccid_xfr_complete(struct ccid_trans_param *ccid_param)
{
	if (ccid_param->ret == CCID_SUCCESS)
		ccid_param->ret = ccid_param->rbuf_actual;
	
	ccid_param->callback(ccid_param->user_data, ccid_param->ret);

	free(ccid_param);
}

int ccid_xfrblock(ccid_reader_t *handle, int32_t protocol,
		  const uint8_t *sbuf, size_t sbuf_len, 
		  uint8_t *rbuf, size_t rbuf_len, 
		  ccid_transfer_cb callback, void *user_data)
{
	struct ccid_trans_param *ccid_param;
	struct ccid_transfer *ccid_trans;
	int r, reader_idx = -1;

	if (!handle) {
		ccid_log(CCID_LOG_WARN, "reader %d is not exist", reader_idx);
		return CCID_ERROR_NO_DEVICE;
	}

	ccid_param = malloc(sizeof(struct ccid_trans_param));
	if (!ccid_param) return CCID_ERROR_NO_MEM;
	memset(ccid_param, 0, sizeof(struct ccid_trans_param));

	ccid_param->reader_idx = reader_idx;
	ccid_param->sbuf = sbuf;
	ccid_param->sbuf_len = sbuf_len;
	ccid_param->rbuf = rbuf;
	ccid_param->rbuf_len = rbuf_len;
	ccid_param->callback = callback;
	ccid_param->user_data = user_data;


	ccid_trans = ccid_alloc_transfer(PC_TO_RDR_XFRBLOCK, 
					 RDR_TO_PC_DATABLOCK);
	if (!ccid_trans) {
		free(ccid_param);
		return CCID_ERROR_NO_MEM;
	}
	
	ccid_trans->name = strdup("xfrblock");
	ccid_trans->handle = handle;
	ccid_trans->protocol = protocol;
	ccid_trans->callback = __ccid_xfr_complete;
	ccid_trans->param = ccid_param;

	r = ccid_fill_cmd(ccid_trans);
	if (r != CCID_SUCCESS) {
		free(ccid_param);
		ccid_free_transfer(ccid_trans);
		return r;
	}

	r = ccid_submit(ccid_trans);	
	if (r != CCID_SUCCESS) {
		free(ccid_param);
		ccid_free_transfer(ccid_trans);
	}

	return r;
}

static void __ccid_secure_complete(struct ccid_trans_param *ccid_param)
{
	if (ccid_param->ret == CCID_SUCCESS)
		ccid_param->ret = ccid_param->rbuf_actual;
	
	ccid_param->callback(ccid_param->user_data, ccid_param->ret);

	free(ccid_param);
}

static int ccid_secure(ccid_reader_t *rdr, const uint8_t *sbuf, size_t sbuf_len, 
		       uint8_t *rbuf, size_t rbuf_len, 
		       ccid_transfer_cb callback, void *user_data)
{
	struct ccid_trans_param *ccid_param;
	struct ccid_transfer *ccid_trans;
	ccid_reader_t *handle = rdr;
	int r;
	
	if (!handle) {
		ccid_log(CCID_LOG_WARN, "reader -1 is not exist");
		return CCID_ERROR_NO_DEVICE;
	}

	ccid_param = malloc(sizeof(struct ccid_trans_param));
	if (!ccid_param)
		return CCID_ERROR_NO_MEM;
	memset(ccid_param, 0, sizeof(struct ccid_trans_param));

	/* FIXME: idx value */
	ccid_param->reader_idx = -1;
	ccid_param->sbuf = sbuf;
	ccid_param->sbuf_len = sbuf_len;
	ccid_param->rbuf = rbuf;
	ccid_param->rbuf_len = rbuf_len;
	ccid_param->callback = callback;
	ccid_param->user_data = user_data;

	ccid_trans = ccid_alloc_transfer(PC_TO_RDR_SECURE,
					 RDR_TO_PC_DATABLOCK);
	if (!ccid_trans) {
		free(ccid_param);
		return CCID_ERROR_NO_MEM;
	}
	
	ccid_trans->name = strdup("secure");
	ccid_trans->handle = handle;
	ccid_trans->callback = __ccid_secure_complete;
	ccid_trans->param = ccid_param;

	r = ccid_fill_cmd(ccid_trans);
	if (r != CCID_SUCCESS) {
		free(ccid_param);
		ccid_free_transfer(ccid_trans);
		return r;
	}

	r = ccid_submit(ccid_trans);
	if (r != CCID_SUCCESS) {
		free(ccid_param);
		ccid_free_transfer(ccid_trans);
	}
	
	return r;
}

static void __ccid_control_complete(struct ccid_trans_param *ccid_param)
{
	ccid_param->callback(ccid_param->user_data, ccid_param->ret);

	free(ccid_param);
}

int ccid_control(ccid_reader_t *handle, uint8_t request_class, uint8_t request, 
		 uint8_t *data, size_t data_len,
		 ccid_transfer_cb callback, void *user_data)
{
	struct ccid_trans_param *ccid_param;
	struct ccid_usb_control_param *control_param;
	int r, reader_idx = -1;

	if (!handle) {
		ccid_log(CCID_LOG_WARN, "reader %d is not exist", reader_idx);
		return CCID_ERROR_NO_DEVICE;
	}
	
	switch (handle->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		ccid_param = malloc(sizeof(struct ccid_trans_param));
		if (!ccid_param)
			return CCID_ERROR_NO_MEM;
		memset(ccid_param, 0, sizeof(struct ccid_trans_param));

		ccid_param->reader_idx = reader_idx;
		ccid_param->rbuf = data;
		ccid_param->rbuf_len = data_len;
		ccid_param->callback = callback;
		ccid_param->user_data = user_data;

		/* This will be freed in control_trans_callback */
		control_param = malloc(sizeof(struct ccid_usb_control_param));
		if (!control_param){
			free(ccid_param);
			return CCID_ERROR_NO_MEM;
		}

		r = ccid_usb_fill_control(request_class, request, data, 
					  data_len, control_param);
		if (r != CCID_SUCCESS) {
			free(control_param);
			return r;
		}
		control_param->callback = __ccid_control_complete;
		control_param->user_data = ccid_param;
		
		r = ccid_usb_control_transfer(handle->handle, 
					      control_param);
		if (r != CCID_SUCCESS) {
			free(ccid_param);
			free(control_param);
			return r;
		}
		break;
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
	
	return CCID_SUCCESS;
}

/* struct pcsc_pin_verify TO struct ccid_pin_verify */
static int pcsc2ccid_pin_verify(uint8_t *in, size_t in_len,
				uint8_t *out, size_t *out_len)
{
	uint32_t apdu_len;
	size_t a, b;

	/* 19 is the size of the PCSCv2 PIN verify structure
	 * The equivalent CCID structure is only 14-bytes long */
	if (in_len > 19 + CMD_BUF_SIZE)
		return PCSC_E_NOT_SUPPORTED;
	if (in_len < 19 + 4 /* 4 = APDU size */)
		return PCSC_E_NOT_SUPPORTED;

	apdu_len = dw2i(in, 15);
	if (apdu_len + 19 != in_len)
		return PCSC_E_NOT_SUPPORTED;

	if ((0x00 == in[7]) || (in[7] > 0x07))
		in[7] = 0x02;

	/* TODO: card_proto == PROTO_T1 && dwteature == CCID_CLASS_TPDU 
	 * update bTeoPrologue field */
	a = b = 0;
	out[a++] = CCID_PIN_VERIFY;
	for (; b < in_len; b++) {
		if (1 == b) /* bTimeOut2 */
			continue;
		if ((b >= 15)  && (b <= 18)) /* Ignore ulDataLength */
			continue;
		out[a] = in[b];
		a++;
	}
	*out_len = a;

	return PCSC_S_SUCCESS;
}

static int pcsc2ccid_pin_modify(uint8_t *in, size_t in_len,
				uint8_t *out, size_t *out_len)
{
	uint32_t apdu_len;
	size_t a, b;

	if (in_len > 24 + CMD_BUF_SIZE)
		return PCSC_E_NOT_SUPPORTED;
	if (in_len < 24 + 4)
		return PCSC_E_NOT_SUPPORTED;
	apdu_len = dw2i(in, 20);
	if (apdu_len + 24 != in_len)
		return PCSC_E_NOT_SUPPORTED;
	if (in[11] > 3)
		return PCSC_E_NOT_SUPPORTED;
	if ((0x00 == in[10]) || (in[10] > 0x07))
		in[10] = 0x02;
	
	/* TODO: card_proto == PROTO_T1 && dwteature == CCID_CLASS_TPDU 
	 * update bTeoPrologue field */
	a = b = 0;
	out[a++] = CCID_PIN_MODIFY;
	for (; b < in_len; b++) {
		if (1 == b) /* Ignore bTimeOut2*/
			continue;
		if ((15 == b) && (0 == in[11]))/* bMsgIndex2 */
			continue;
		if ((16 == b) && (in[11] < 3))/* bMsgIndex3 */
			continue;
		if ((b >= 20) && (b <= 23)) /* Ignore ulDataLength */
			continue;
		out[a] = in[b];
		a++;
	}
	*out_len = a;

	return PCSC_S_SUCCESS;
}

int ccid_ifd_control(ccid_reader_t *rdr, uint32_t ioctl, 
		     uint8_t *sbuf, size_t sbuf_len,
		     uint8_t *rbuf, size_t rbuf_len,
		     ccid_transfer_cb callback, void *user_data)
{
	const struct ccid_descriptor *ccid_desc;
	struct pcsc_feature_tlv *pcsc_tlv;
	int rbuf_actual = 0;
	int r;
	uint8_t ccid_verify[14 + CMD_BUF_SIZE], ccid_modify[19 + CMD_BUF_SIZE];
	size_t ccid_verify_len = sizeof(ccid_verify);
	size_t ccid_modify_len = sizeof(ccid_modify);
	
	switch (ioctl) {
	case CM_IOCTL_GET_FEATURE_REQUEST:
		if (rbuf_len < 2 * sizeof(struct pcsc_feature_tlv))
			return CCID_ERROR_INSUFFICIENT_BUFFER;

		ccid_desc = &rdr->ccid_desc;
		pcsc_tlv = (struct pcsc_feature_tlv *) rbuf;
		
		if (ccid_desc->bPINSupport & CCID_CLASS_PIN_VERIFY) {
			pcsc_tlv->tag = FEATURE_VERIFY_PIN_DIRECT;
			pcsc_tlv->len = 0x04;
			pcsc_tlv->value = htonl(IOCTL_FEATURE_VERIFY_PIN_DIRECT);
			pcsc_tlv++;

			rbuf_actual += sizeof(struct pcsc_feature_tlv);
		}

		if (ccid_desc->bPINSupport & CCID_CLASS_PIN_MODIFY) {
			pcsc_tlv->tag = FEATURE_MODIFY_PIN_DIRECT;
			pcsc_tlv->len = 0x04;
			pcsc_tlv->value= htonl(IOCTL_FEATURE_MODIFY_PIN_DIRECT);

			rbuf_actual += sizeof(struct pcsc_feature_tlv);
		}

		return rbuf_actual;
	/* TODO: you could process LCD like pinpad */
	case IOCTL_FEATURE_VERIFY_PIN_DIRECT:
		r = pcsc2ccid_pin_verify(sbuf, sbuf_len, ccid_verify, &ccid_verify_len);
		if (r != PCSC_S_SUCCESS)
			return r;

		return ccid_secure(rdr, ccid_verify, ccid_verify_len, 
				   rbuf, rbuf_len, callback, user_data);
	case IOCTL_FEATURE_MODIFY_PIN_DIRECT:
		r = pcsc2ccid_pin_modify(sbuf, sbuf_len, ccid_modify, &ccid_modify_len);
		if (r != PCSC_S_SUCCESS)
			return r;

		return ccid_secure(rdr, ccid_modify, ccid_modify_len, 
				   rbuf, rbuf_len, callback, user_data);
	case IOCTL_SMARTCARD_VENDOR_IFD_EXCHANGE:
		return CCID_ERROR_NOT_SUPPORTED;
	default:
		return CCID_ERROR_NOT_SUPPORTED;
	}
}

