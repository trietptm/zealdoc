#include "ccid_usb.h"

DECLARE_LIST(ccid_readers);
DECLARE_NOTIFY_CHAIN(ccid_chain);

#define for_each_reader(r)	\
	list_for_each_entry(ccid_reader_t, r, &ccid_readers, link)

ccid_reader_t *ccid_reader_get(ccid_reader_t *r)
{
	atomic_inc(&r->refcnt);
	return r;
}

void ccid_reader_put(ccid_reader_t *r)
{
	atomic_dec(&r->refcnt);
}

ccid_reader_t *ccid_reader_get_same_rdr(const char *name, int type, void* hd)
{
	ccid_reader_t *r;

	for_each_reader(r) {
		if (0 == strcasecmp(name, r->name) &&
		    type == r->dev_type &&
		    hd == r->handle)
			return ccid_reader_get(r);
	}
	return NULL;
}

static inline int ccid_unsupport_devtype(int type)
{
	return !(type == CCID_DEVICE_TYPE_USB);

}

int ccid_register_notify(notify_t *nb)
{
	ccid_reader_t *rdr;
	ccid_reader_t *last;
	int err;

	err = register_notify_chain(&ccid_chain, nb);
	if (err)
		goto unlock;

	for_each_reader(rdr) {
		err = nb->call(nb, CCID_RDR_REGISTER, rdr);
		err = notify_to_errno(err);
		if (err)
			goto rollback;
	}
unlock:
	return err;
rollback:
	last = rdr;
	for_each_reader(rdr) {
		if (rdr == last)
			break;
		nb->call(nb, CCID_RDR_UNREGISTER, rdr);
	}
	goto unlock;
}

void ccid_unregister_notify(notify_t *nb)
{
	unregister_notify_chain(&ccid_chain, nb);
}

int ccid_notify(unsigned long val, void *v)
{
	return call_notify_chain(&ccid_chain, val, v);
}

ccid_reader_t *ccid_reader_new(int dev_type, const char *reader_name,
			       void *hd)
{
	ccid_reader_t *rdr = malloc(sizeof (ccid_reader_t));

	if (!rdr) {
		ccid_log(CCID_LOG_ERR, "RDR: out of memory");
		return NULL;
	}

	memset(rdr, 0, sizeof (ccid_reader_t));

	list_init(&rdr->link);
	atomic_set(&rdr->refcnt, 1);

	rdr->bseq = 0;
	rdr->bslot = 0;
	rdr->intfc_proto = CCID_INTFC_PROTO_BULK;
	rdr->card_status = CCID_CARD_ABSENT;
	rdr->dev_type = dev_type;
	rdr->handle = hd;
	rdr->name = strdup(reader_name);

	list_insert_before(&rdr->link, &ccid_readers);
	ccid_log(CCID_LOG_INFO, "RDR: create ccid reader, type=%d",
		 dev_type);
	return rdr;
}

void ccid_reader_free(ccid_reader_t *r)
{
	if (r) {
		if (r->name) 
			free(r->name);
		list_delete(&r->link);
		free(r);
	}
}

/* do special type open stuff */
static int ccid_rdr_type_open(ccid_reader_t *rdr)
{
	switch(rdr->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		ccid_usb_rdr_open(rdr);
		break;
	default:
		break;
	}
	return -1;
}

static int ccid_rdr_type_close(ccid_reader_t *rdr)
{
	switch(rdr->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		ccid_usb_rdr_close(rdr);
		break;
	default:
		break;
	}

	return -1;
}

/* get reader up, ccid core may manage it */
ccid_reader_t *ccid_rdr_open(int dev_type, const char *reader_name,
			     void *handle/* usb_intfc_t now */)
{
	ccid_reader_t *reader;
	
	if (ccid_unsupport_devtype(dev_type))
		return NULL;

	reader = ccid_reader_get_same_rdr(reader_name, dev_type, handle);

	/* FIXME: can it? insert two USB CCID reader, how to do next? */
	if (reader) {
		/* ?right? */
		BUG();
		return reader;
	}
	reader = ccid_reader_new(dev_type, reader_name, handle);
	ccid_rdr_type_open(reader);

	ccid_notify(CCID_RDR_INSERT, reader);
	return reader;
}

void ccid_rdr_close(int type, const char *name,
		    void *hd/* usb_intfc_t now */)
{
	ccid_reader_t *rdr = ccid_reader_get_same_rdr(name, type, hd);

	if (!rdr)
		return;

	ccid_notify(CCID_RDR_REMOVE, rdr);

	if (atomic_dec_and_test(&rdr->refcnt)) {
		ccid_rdr_type_close(rdr);
		ccid_reader_free(rdr);
	}
}

uint16_t ccid_dev_idVendor(void *data, int dev_type)
{
	ccid_reader_t *rdr = (ccid_reader_t *)data;

	switch(rdr->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		return ccid_usb_dev_idVendor(rdr);
	default:
		break;
	}
	return -1;
}

uint16_t ccid_dev_idProduct(void *data, int dev_type)
{
	ccid_reader_t *rdr = (ccid_reader_t *)data;

	switch(rdr->dev_type) {
	case CCID_DEVICE_TYPE_USB:
		return ccid_usb_dev_idProduct(rdr);
	default:
		break;
	}
	return -1;
}

void ccid_close(int reader_idx)
{}
