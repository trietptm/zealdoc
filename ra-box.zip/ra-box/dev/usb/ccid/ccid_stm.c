#include "ccid_priv.h"

static void ccid_transfer_exit_delay(void *eloop, void *user_ctx);

static void ccid_stm_log(const stm_instance_t *fsmi,
			int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

#define CCID_TRANSFER_STATE_INIT	0
#define CCID_TRANSFER_STATE_SENDING	1
#define CCID_TRANSFER_STATE_RECEIVING	2
#define CCID_TRANSFER_STATE_RECEIVED	3
#define CCID_TRANSFER_STATE_EXIT	4

#define CCID_TRANSFER_STATE_COUNT	5

#define CCID_TRANSFER_STATE_NAMES {	\
	"INIT",				\
	"SENDING",			\
	"RECEIVING",			\
	"RECEIVED",			\
	"EXIT",				\
}

#define CCID_TRANSFER_EVENT_SUBMIT	0
#define CCID_TRANSFER_EVENT_STF		1
#define CCID_TRANSFER_EVENT_STS		2
#define CCID_TRANSFER_EVENT_RRS		3
#define CCID_TRANSFER_EVENT_RRF		4
#define CCID_TRANSFER_EVENT_TTE		5
#define CCID_TRANSFER_EVENT_TCP		6

#define CCID_TRANSFER_EVENT_COUNT	7

#define CCID_TRANSFER_EVENT_NAMES {	\
	"SUBMIT",			\
	"STF",				\
	"STS",				\
	"RRS",				\
	"RRF",				\
	"TTE",				\
	"TCP",				\
}


static void ccid_transfer_raise_event(void *data, int event)
{
	struct ccid_transfer *ccid_trans = (struct ccid_transfer *)data;

	eloop_schedule_event(NULL, ccid_trans->fsmi, event, data);
}

static void ccid_transfer_raise_submit(struct ccid_transfer *ccid_trans)
{
	ccid_transfer_raise_event(ccid_trans, CCID_TRANSFER_EVENT_SUBMIT);
}

static void ccid_transfer_raise_stf(struct ccid_transfer *ccid_trans)
{
	ccid_transfer_raise_event(ccid_trans, CCID_TRANSFER_EVENT_STF);
}

static void ccid_transfer_raise_sts(struct ccid_transfer *ccid_trans)
{
	ccid_transfer_raise_event(ccid_trans, CCID_TRANSFER_EVENT_STS);
}

/* Receive response fail*/
static void ccid_transfer_raise_rrf(struct ccid_transfer *ccid_trans)
{
	ccid_transfer_raise_event(ccid_trans, CCID_TRANSFER_EVENT_RRF);
}

/* Receive response success*/
static void ccid_transfer_raise_rrs(struct ccid_transfer *ccid_trans)
{
	ccid_transfer_raise_event(ccid_trans, CCID_TRANSFER_EVENT_RRS);
}

/* Transfer time extension*/
static void ccid_transfer_raise_tte(struct ccid_transfer *ccid_trans)
{
	ccid_transfer_raise_event(ccid_trans, CCID_TRANSFER_EVENT_TTE);
}

static void ccid_transfer_raise_tcp(struct ccid_transfer *ccid_trans)
{
	ccid_transfer_raise_event(ccid_trans, CCID_TRANSFER_EVENT_TCP);
}

/* Init ccid_trans context*/
static int ccid_transfer_action_itc(stm_instance_t *fsmi, void *data)
{
	return 1;
}

/* Exit transfer context*/
static int ccid_transfer_action_etc(stm_instance_t *fsmi, void *data)
{
	struct ccid_transfer *ccid_trans = (struct ccid_transfer *)data;
	
	ccid_trans->callback(ccid_trans->param);
	eloop_register_timeout(NULL, 0, 0, ccid_transfer_exit_delay, NULL, 
			       ccid_trans);
	
	return 1;
}

/* submit transfer*/
static int ccid_transfer_action_st(stm_instance_t *fsmi, void *data)
{
	struct ccid_transfer *ccid_trans = (struct ccid_transfer *)data;
	int r;
	
	r = ccid_send_transfer(ccid_trans);
	if (r != CCID_SUCCESS) {
		ccid_trans->param->ret = r;
		ccid_transfer_raise_stf(ccid_trans);
	}
	return 1;
}

/* read transfer response*/
static int ccid_transfer_action_rtr(stm_instance_t *fsmi, void *data)
{
	struct ccid_transfer *ccid_trans = (struct ccid_transfer *)data;
	int r;
	
	r = ccid_reap_transfer(ccid_trans);
	if (r != CCID_SUCCESS) {
		ccid_trans->param->ret = r;
		ccid_transfer_raise_rrf(ccid_trans);
	}

	return 1;
}

/* check transfer response*/
static int ccid_transfer_action_ctr(stm_instance_t *fsmi, void *data)
{
	struct ccid_transfer *ccid_trans = (struct ccid_transfer *)data;

	ccid_parse_reap(ccid_trans);
	switch (ccid_trans->param->ret) {
	case CCID_TIME_EXTENSION:
		ccid_transfer_raise_tte(ccid_trans);
		break;
	case CCID_SUCCESS:
	default:
		ccid_log(CCID_LOG_DEBUG, "ccid_action_ctr: %d", ccid_trans->param->ret);
		ccid_transfer_raise_tcp(ccid_trans);
		break;
	}
	return 1;
}

static int ccid_transfer_action_null(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static const stm_action_fn ccid_transfer_act_itc_st [] = {
	ccid_transfer_action_itc,
	ccid_transfer_action_st,
};

static const stm_action_fn ccid_transfer_act_etc [] = {
	ccid_transfer_action_etc,
};

static const stm_action_fn ccid_transfer_act_rtr [] = {
	ccid_transfer_action_rtr,
};

static const stm_action_fn ccid_transfer_act_ctr [] = {
	ccid_transfer_action_ctr,
};

static const stm_action_fn ccid_transfer_act_st [] = {
	ccid_transfer_action_st,
};

static const stm_action_fn ccid_transfer_act_null [] = {
	ccid_transfer_action_null,
};



#define STATE(state)	CCID_TRANSFER_STATE_##state
#define EVENT(event)	CCID_TRANSFER_EVENT_##event
#define ACTION(stem) ccid_transfer_act_##stem, \
		sizeof(ccid_transfer_act_##stem) / sizeof(stm_action_fn) 

static const stm_entry_t ccid_stm_transfer_entries[] = {
	/* state	event		action		new_state */
	{STATE(INIT),	EVENT(SUBMIT),	ACTION(itc_st),	STATE(SENDING),},

	{STATE(SENDING),EVENT(STS),	ACTION(rtr),	STATE(RECEIVING),},
	{STATE(SENDING),EVENT(STF),	ACTION(etc),	STATE(EXIT),},
	
	{STATE(RECEIVING),EVENT(RRS),	ACTION(ctr),	STATE(RECEIVED),},
	{STATE(RECEIVING),EVENT(RRF),	ACTION(etc),	STATE(EXIT),},

	{STATE(RECEIVED),EVENT(TTE),	ACTION(rtr),	STATE(RECEIVING),},
	{STATE(RECEIVED),EVENT(TCP),	ACTION(etc),	STATE(EXIT),},

	{0,		0,		ACTION(null),	0,},
};

static const char *ccid_transfer_state_names[] = CCID_TRANSFER_STATE_NAMES;
static const char *ccid_transfer_event_names[] = CCID_TRANSFER_EVENT_NAMES;

const stm_table_t ccid_stm_transfer_table = {
	"CCID-TRANSFER",
	ccid_stm_log,
	CCID_TRANSFER_STATE_COUNT,
	&ccid_transfer_state_names[0],
	CCID_TRANSFER_EVENT_COUNT,
	&ccid_transfer_event_names[0],
	ccid_stm_transfer_entries,	
};

#undef STATE
#undef EVENT
#undef ACTION

void ccid_stm_raise_sts(struct ccid_transfer *ccid_trans)
{
	ccid_transfer_raise_sts(ccid_trans);
}

void ccid_stm_raise_stf(struct ccid_transfer *ccid_trans)
{
	ccid_transfer_raise_stf(ccid_trans);
}

void ccid_stm_raise_rrs(struct ccid_transfer *ccid_trans)
{
	ccid_transfer_raise_rrs(ccid_trans);
}

void ccid_stm_raise_rrf(struct ccid_transfer *ccid_trans)
{
	ccid_transfer_raise_rrf(ccid_trans);
}

int ccid_submit(struct ccid_transfer *ccid_trans)
{
	ccid_trans->fsmi = stm_table_new(&ccid_stm_transfer_table, 
				       ccid_trans->name, 
				       CCID_TRANSFER_STATE_INIT);
	if (!ccid_trans->fsmi) {
		return CCID_ERROR_NO_MEM;
	}

	ccid_transfer_raise_submit(ccid_trans);

	return CCID_SUCCESS;
}

static void ccid_transfer_exit(struct ccid_transfer *ccid_trans)
{
	BUG_ON(ccid_trans == NULL);
	
	if (ccid_trans->fsmi) {
		eloop_cleanup_events(NULL, ccid_trans->fsmi);
		stm_table_free(ccid_trans->fsmi);
	}
	ccid_free_transfer(ccid_trans);
}

static void ccid_transfer_exit_delay(void *eloop, void *user_ctx) 
{
	ccid_transfer_exit((struct ccid_transfer *)user_ctx);
}
