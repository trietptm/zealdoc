#include "usb_priv.h"

#ifdef WIN32
extern struct sys_device_ops win_device_ops;
struct sys_device_ops *sys_ops = &win_device_ops;
#else
extern struct sys_device_ops linux_device_ops;
struct sys_device_ops *sys_ops = &linux_device_ops;
#endif

int usb_set_configuration(usb_intfc_t *intfc, uint8_t config_idx)
{
	int r;

	if (intfc->dev->active_config == config_idx)
		return USB_SUCCESS;	
	if (intfc->claimed) {
		usb_log(USB_LOG_ERR,
			"IO: cannot set configuration on the claimed interface");
		return USB_ERROR_IO;
	}

	r = sys_ops->sys_set_config(intfc, config_idx);
	if (r == USB_SUCCESS) {
		intfc->dev->active_config = config_idx;
		/* FIXME: can do it? */
		intfc->claimed = 1;
	//	intfc->altsetting = USB_INVALID_INTFC;
	}
	return r;
}

int usb_claim_interface(usb_intfc_t *intfc)
{
	int r;

	if(intfc->dev->active_config == USB_INVALID_CONFIG) {
		usb_log(USB_LOG_ERR,
				"IO: cannot claim interface with invalid configuration %d", 
				intfc->dev->active_config);
		return USB_ERROR_IO;
	}

	if (intfc->claimed) {
		usb_log(USB_LOG_DEBUG, "IO: interface has been claimed");
		return USB_SUCCESS;
	}

	r =  sys_ops->sys_claim_intfc(intfc);
	if (r == USB_SUCCESS) {
		intfc->claimed = 1;
	}
	
	return r;
}

int usb_release_interface(usb_intfc_t *intfc, uint8_t intfc_num)
{
	int r;

	if (intfc->claimed == 0)
		return USB_SUCCESS;
	r = sys_ops->sys_release_intfc(intfc);
	if (r == USB_SUCCESS)
		intfc->claimed = 0;

	return r;		
}

struct usb_transfer *usb_alloc_transfer(int iso_packets)
{
	int alloc_size;
	struct usb_transfer *transfer;

	alloc_size = sizeof(struct usb_transfer)
		+ (sizeof(struct usb_iso_packet_descriptor) * iso_packets);
	transfer = malloc(alloc_size);
	if (!transfer)
		return NULL;
	memset(transfer, 0, alloc_size);
	if (sys_ops->transfer_priv_size > 0) {
		transfer->os_priv = malloc(sys_ops->transfer_priv_size);
		if (!transfer->os_priv) {
			free(transfer);
			return NULL;
		}
		memset(transfer->os_priv, 0, sys_ops->transfer_priv_size);
	}
	transfer->num_iso_packets = iso_packets;

	return transfer;
}

void usb_free_transfer(struct usb_transfer *transfer)
{
	if (!transfer)
		return;
	if (transfer->name)
		free(transfer->name);
	if (transfer->buffer && 
		(transfer->flag & USB_TRANSFER_FREE_BUFFER))
		free(transfer->buffer);
	if (transfer->os_priv)
		free(transfer->os_priv);
	free(transfer);
}

static int usb_urb_transfer(uint8_t trans_type, const char *trans_name,
		     struct usb_trans_params *param, 
		     usb_bulk_trans_callback cb)
{
	struct usb_transfer *usb_trans;

	usb_trans = usb_alloc_transfer(0);
	if (!usb_trans)
		return USB_ERROR_NO_MEM;

	usb_trans->name = strdup(trans_name);
	usb_trans->flag = USB_TRANSFER_FREE_TRANSFER;
	usb_trans->type = trans_type;
	usb_trans->dev_handle = param->dev_handle;
	usb_trans->endpoint = param->ep;
	usb_trans->buffer = param->buf;
	usb_trans->length = param->buf_len;
	usb_trans->actual_length = 0;
	usb_trans->callback = cb;
	usb_trans->user_data = param;
	usb_trans->timeout.tv_sec = 1;
	usb_trans->timeout.tv_usec = USB_TRANSFER_TIMEOUT;

	return usbi_submit_transfer(usb_trans);
}

#define USB_TRANS_TYPE_BULK_NAME	"bulk"
#define USB_TRANS_TYPE_INT_NAME		"interrupt"
#define USB_TRANS_TYPE_CTRL_NAME	"control"
#define USB_TRANS_TYPE_ISO_NAME		"isochronous"

int usb_bulk_write(struct usb_trans_params *usb_param, 
		   usb_bulk_trans_callback cb)
{
	return usb_urb_transfer(USB_TRANSFER_TYPE_BULK, "bulk_write", 
				usb_param, cb);
}

int usb_bulk_read(struct usb_trans_params *param, usb_bulk_trans_callback cb)
{
	return usb_urb_transfer(USB_TRANSFER_TYPE_BULK, "bulk_read", 
				param, cb);
}

int usb_interrupt_write(struct usb_trans_params *param, usb_bulk_trans_callback cb)
{
	return usb_urb_transfer(USB_TRANSFER_TYPE_INTERRUPT, "interrupt_write", 
				param, cb);
}

int usb_interrupt_read(struct usb_trans_params *param, usb_bulk_trans_callback cb)
{
	return usb_urb_transfer(USB_TRANSFER_TYPE_BULK, "interrupt_read", 
				param, cb);
}

int usb_control_transfer(struct usb_trans_params *usb_param, 
			 usb_bulk_trans_callback cb)
{
	usb_param->ep = USB_ENDPOINT_CONTROL;
	return usb_urb_transfer(USB_TRANSFER_TYPE_CONTROL, "control trans", 
				usb_param, cb);
}

int usb_cancel(usb_intfc_t *usb_handle)
{
	struct usb_transfer *trans_pos, *trans_n;
	int r;

	list_for_each_entry_safe(usb_transfer_t, trans_pos, trans_n,
			&usb_handle->transfer_list, link) {
		trans_pos->status = USB_TRANSFER_CANCELLED;
		r = usbi_cancel_transfer(trans_pos);
		if (r != USB_SUCCESS)
			return r;
	}
	
	return USB_SUCCESS;
}

int usb_ioctl(usb_intfc_t *dev_handle, int intfc_no, 
	      int ioctl_code, void *data)
{
	return sys_ops->sys_ioctl(dev_handle, intfc_no, ioctl_code, data);
}

/*===========================================================================*/
/*				usb tools				     */
/*===========================================================================*/
#if 0
int usb_tool_list_handle(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	struct usb_device_handle *pos;
	int idx = 0;

	usb_log(USB_LOG_DEBUG, "\tIndex\t Refcnt\t FileName\t");
	list_for_each_entry(struct usb_device_handle, pos, 
			&usb_ctx->handle_list, link) {
		usb_log(USB_LOG_DEBUG, "\t%d\t %d\t %s", idx++, 
			atomic_read(&pos->refcnt), pos->dev->filename);
	}
	usb_log(USB_LOG_DEBUG, "\tTotoal %d", idx);
	
	return USB_SUCCESS;
}

int usb_tool_list_trans(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	struct usb_device_handle *handle_pos, *usb_handle = NULL;
	struct usb_transfer *trans_pos;
	int idx = 0;
	int reader_idx;

	reader_idx = atoi(argv[0]);

	list_for_each_entry(struct usb_device_handle, handle_pos, 
			&usb_ctx->handle_list, link) {
		if (idx == reader_idx) {
			usb_handle = handle_pos;
			break;
		}
		idx++;
	}
	if (!usb_handle) {
		usb_log(USB_LOG_DEBUG, "Idex %d reader not exist.", idx);
		return -1;
	}
	idx = 0;
	usb_log(USB_LOG_DEBUG, "Reader %d transfer list:", reader_idx);
	usb_log(USB_LOG_DEBUG, "\tIndex\t TransName\t");
	list_for_each_entry(struct usb_transfer, trans_pos, 
			&usb_handle->transfer_list, link) {
		usb_log(USB_LOG_DEBUG, "\t%d\t %s", idx, trans_pos->name);
		idx++;
	}
		
	usb_log(USB_LOG_DEBUG, "\tTotoal %d", idx);

	return USB_SUCCESS;
}

int usb_tool_cancel_trans(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int reader_idx, trans_idx;
	struct usb_device_handle *handle_pos, *usb_handle = NULL;
	struct usb_transfer *trans_pos, *usb_trans = NULL;
	int idx = 0;
	int r;

	reader_idx = atoi(argv[0]);
	trans_idx = atoi(argv[1]);

	list_for_each_entry(struct usb_device_handle, handle_pos, 
			&usb_ctx->handle_list, link) {
		if (idx == reader_idx) {
			usb_handle = handle_pos;
			break;
		}
		idx++;
	}
	if (!usb_handle) {
		usb_log(USB_LOG_DEBUG, "Idex %d reader not exist.", idx);
		return -1;
	}

	idx = 0;
	list_for_each_entry(struct usb_transfer, trans_pos, 
			&usb_handle->transfer_list, link) {
		if (idx == trans_idx) {
			usb_trans = trans_pos;
			break;
		}			
		idx++;
	}
	if (!usb_trans) {
		usb_log(USB_LOG_DEBUG, "transfer %d not exist.", idx);
		return -1;
	}

	r = usbi_cancel_transfer(usb_trans);
	if (r < 0) {
		usb_log(USB_LOG_ERR, "cancel transfer failed");
	}

	return r;
}

int usb_tool_close(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	struct usb_device_handle *pos, *usb_handle = NULL;
	int idx = 0;
	int r;

	idx = atoi(argv[0]);

	list_for_each_entry(struct usb_device_handle, pos, 
			&usb_ctx->handle_list, link) {
		if (idx == 0) {
			usb_handle = pos;
			break;
		}
		idx--;
	}
	if (!usb_handle) {
		usb_log(USB_LOG_DEBUG, "Idex %d reader not exist.", idx);
		return USB_ERROR_INVALID_PARAM;
	}
	r = usb_release_interface(usb_handle, usb_handle->dev->claimed_intfc);
	if (r != USB_SUCCESS) {
		usb_log(USB_LOG_DEBUG, "release failed.", idx);
		return r;
	}
	r = usb_close(usb_handle);

	return USB_SUCCESS;
}
#endif
int usb_get_endpoints(struct usb_device *usb_dev, usb_intfc_desc_t *altsetting)
{
	int e;

	/* class driver will check bInterfaceProtocol byself */
#if 0
	if (altsetting->bInterfaceProtocol != 0x00)
		return USB_SUCCESS;
#endif	
	for (e = 0; e < altsetting->bNumEndpoints; e++) {
		const struct usb_endpoint_descriptor *ep;
		
		ep = &altsetting->endpoint[e];

		if ((ep->bmAttributes & USB_TRANSFER_TYPE_MASK)
			== USB_TRANSFER_TYPE_BULK) {			
			if ((ep->bEndpointAddress & USB_ENDPOINT_DIR_MASK) 
				== USB_ENDPOINT_IN) {
				usb_dev->ep_i = ep->bEndpointAddress;
			} else if ((ep->bEndpointAddress & USB_ENDPOINT_DIR_MASK)
				== USB_ENDPOINT_OUT) {
				usb_dev->ep_o = ep->bEndpointAddress;
			}
		} else if ((ep->bmAttributes & USB_TRANSFER_TYPE_MASK)
			== USB_TRANSFER_TYPE_INTERRUPT) {
			usb_dev->ep_intr = ep->bEndpointAddress;
		}
	}
	return 0;
}

static uint8_t cmd_buf[1024];
static size_t cmd_len;
uint8_t active_config;

static void get_config_callback(struct usb_trans_params *usb_param)
{
	if (usb_param->ret == USB_SUCCESS) {
		active_config = usb_param->buf[8];

		usb_log(USB_LOG_ERR, 
			"current active config: %d", active_config);
	}else
		usb_log(USB_LOG_ERR, 
			"get_config_callback: failed: %d", usb_param->ret);
	
	free(usb_param);
}
#if 0
int usb_tool_get_config(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int r = USB_ERROR_NOT_SUPPORTED;
	struct usb_device_handle *pos, *usb_handle = NULL;
	struct usb_trans_params *usb_param;
	struct usb_control_setup *setup;

	r = atoi(argv[0]);
	list_for_each_entry(struct usb_device_handle, pos, 
			&usb_ctx->handle_list, link) {
		if (r == 0) {
			usb_handle = pos;
			break;
		}
		r--;
	}

	if (!usb_handle) 
		usb_log(USB_LOG_DEBUG, "Idex %d reader not exist.", r);
		
	memset(cmd_buf, 0, sizeof(cmd_buf));
	setup = (struct usb_control_setup *)cmd_buf;
	setup->bmRequestType = USB_ENDPOINT_IN;
	setup->bRequest = USB_REQUEST_GET_CONFIGURATION;
	setup->wValue = usb_cpu_to_le16(0x0000);
	setup->wIndex = usb_cpu_to_le16(0x0000);
	setup->wLength = usb_cpu_to_le16(0x0001);

	cmd_len = 9;
	
	usb_param = malloc(sizeof(struct usb_trans_params));
	if (!usb_param)
		return USB_ERROR_NO_MEM;
	usb_param->dev_handle = usb_handle;
	usb_param->ep = USB_ENDPOINT_CONTROL;
	usb_param->buf = cmd_buf;
	usb_param->buf_len = cmd_len;

	r = usb_control_transfer(usb_param, get_config_callback);
	if (r != USB_SUCCESS) {
		free(usb_param);
		usb_log(USB_LOG_ERR, "send usb_control_transfer failed: %d", r);
	}

	return r;	
}
#endif
static void select_read_callback(struct usb_trans_params *read_param)
{
	size_t actual_len;
	char out_debug[1024];
	size_t i;

	switch (read_param->ret) {
	case USB_SUCCESS:
		actual_len = read_param->rbuf_actual;
		memset(out_debug, 0, 1024);

		for (i = 0; i < actual_len; i++) {
			sprintf(out_debug + 3 * i, "%02X ", cmd_buf[i]);
		}
		usb_log(USB_LOG_DEBUG, "select 3F00 <--- %s", out_debug);
		break;
	default:
		usb_log(USB_LOG_ERR, 
			"select_read_callback: failed: %d", read_param->ret);
		break;
	}

	free(read_param);
}

static void select_write_callback(struct usb_trans_params *write_param)
{
	struct usb_trans_params *read_param;
	usb_intfc_t *usb_handle;
	int r;

	switch (write_param->ret) {
	case USB_SUCCESS:
		/* TODO: usb_bulk_read */
		read_param = malloc(sizeof(struct usb_trans_params));
		if (!read_param)
			return ;

		usb_handle = write_param->dev_handle;
		read_param->dev_handle = usb_handle;
		read_param->ep = usb_handle->dev->ep_i;
		read_param->buf = cmd_buf;
		read_param->buf_len = sizeof(cmd_buf);
		read_param->user_data = NULL;

		r = usb_bulk_read(read_param, select_read_callback);
		if (r != USB_SUCCESS) {
			free(read_param);
			usb_log(USB_LOG_ERR, "send usb_bulk_read failed: %d", r);
			goto out;
		}
		break;
	default:
		usb_log(USB_LOG_ERR, 
			"usb_bulk_write_callback: usb_bulk_write failed: %d", 
			write_param->ret);
		break;
	}
out:
	free(write_param);
}
#if 0
int usb_tool_select_trans(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int reader_idx;
	struct usb_trans_params *write_param;
	int r;
	struct usb_device_handle *handle_pos, *usb_handle = NULL;
	int idx = 0;
	static int seq = 1;

	reader_idx = atoi(argv[0]);

	list_for_each_entry(struct usb_device_handle, handle_pos, 
			&usb_ctx->handle_list, link) {
		if (idx == reader_idx) {
			usb_handle = handle_pos;
			break;
		}
		idx++;
	}
	if (!usb_handle) {
		usb_log(USB_LOG_DEBUG, "Idex %d reader not exist.", idx);
		return -1;
	}
	
	write_param = malloc(sizeof(struct usb_trans_params));
	if (!write_param)
		return USB_ERROR_NO_MEM;

	{ /*Select 3f00*/
		char out_debug[1024];
		size_t i;

		cmd_buf[0] = 0x6F; /* bMessageType*/
		cmd_buf[1] = 0x07; /* dwLength */
		cmd_buf[2] = 0x00;
		cmd_buf[3] = 0x00;
		cmd_buf[4] = 0x00;
		cmd_buf[5] = 0x00; /* bSlot */
		cmd_buf[6] = seq++; /* bSeq */
		cmd_buf[7] = 0x00; /* bBWI */
		cmd_buf[8] = 0x00; /* wLevelParameter */
		cmd_buf[9] = 0x00;
		cmd_buf[10] = 0x00; /* TPDU */
		cmd_buf[11] = 0xA4;
		cmd_buf[12] = 0x00;
		cmd_buf[13] = 0x00;
		cmd_buf[14] = 0x02;
		cmd_buf[15] = 0x3F;
		cmd_buf[16] = 0x00;
		
		cmd_len = 17;

		memset(out_debug, 0, 1024);
		for (i = 0; i < cmd_len; i++) {
			sprintf(out_debug + 3 * i, "%02X ", cmd_buf[i]);
		}
		usb_log(USB_LOG_DEBUG, "select 3F00 ---> %s", out_debug);

	}

	write_param->dev_handle = usb_handle;
	write_param->ep = usb_handle->dev->ep_o;
	write_param->buf = cmd_buf;
	write_param->buf_len = cmd_len;
	write_param->user_data = NULL;

	r = usb_bulk_write(write_param, select_write_callback);
	if (r != USB_SUCCESS) {
		free(write_param);
		usb_log(USB_LOG_ERR, "send usb_bulk_write failed: %d", r);
	}

	return r;
}
#endif /* cmd */
