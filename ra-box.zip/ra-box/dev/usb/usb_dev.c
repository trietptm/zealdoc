#include <usb.h>
#include <udev.h>
#include "usb_priv.h"

#define USB_GC_TIMEOUT	1
#define	USB_SERVICE_DESC	"Universal serial bus"

typedef void (*usb_action)(usb_device_t *dev, usb_intfc_t *intfc);

typedef struct _usb_name_t {
	char *name;
	list_t link;
} usb_name_t;

udev_rule_t *usb_add_rule;
udev_rule_t *usb_del_rule;

DECLARE_LIST(usb_devices);
DECLARE_LIST(usb_devices_gc);
DECLARE_LIST(usb_devices_handle);
DECLARE_LIST(usb_drivers);

DECLARE_LIST(usb_name_list);

DECLARE_NOTIFY_CHAIN(usb_device_chain);

#define for_each_usbname(n)		\
	list_for_each_entry(usb_name_t, n, &usb_name_list, link)

#define for_each_driver(c)		\
	list_for_each_entry(usb_driver_t, c, &usb_drivers, link)

#define for_each_device(t)		\
	list_for_each_entry(usb_device_t, t, &usb_devices, link)
#define for_each_device_safe(t, n)	\
	list_for_each_entry_safe(usb_device_t, t, n, &usb_devices, link)

#define for_each_device_gc(t)		\
	list_for_each_entry(usb_device_t, t, &usb_devices_gc, link)
#define for_each_device_gc_safe(t, n)	\
	list_for_each_entry_safe(usb_device_t, t, n, &usb_devices_gc, link)

#define for_each_trans(intfc, t)		\
	list_for_each_entry(usb_transfer_t, t, &intfc->transfer_list, link)
#define for_each_trans_safe(intfc, t, n)	\
	list_for_each_entry_safe(usb_transfer_t, t, n, &intfc->transfer_list, link)

static void usb_device_free(usb_device_t *dev);
static void usb_gc_timeout(void *eloop, void *data);
static int usb_device_down(usb_device_t *dev);
static void usb_device_close(usb_device_t *dev);
static usb_device_t *usb_device_open(const char *filename);

ui_schema_t usb_device_schema[] = {
	/* .usb */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE,
	  UI_TYPE_STRING, NULL, NULL,
	  ".usb", "usb", USB_SERVICE_DESC },

	/* .usb.device */
	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".usb.devices", "devices", "USB devices" },

	{ UI_TYPE_CLASS, UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, NULL, NULL,
	  ".usb.devices.interface", "interface", "USB interfaces" },

	{ UI_TYPE_NONE },
};

static usb_device_t *usb_ref_device(usb_device_t *dev)
{
	atomic_inc(&dev->refcnt);
	return dev;
}

static void usb_unref_device(usb_device_t *dev)
{
	if (dev)
		atomic_dec(&dev->refcnt);
}

static usb_device_t *usb_get_dev_by_intfc(usb_intfc_t *intfc)
{
	if (intfc->dev)
		return usb_ref_device(intfc->dev);
	return NULL;
}

static void usb_intfc_free_trans(usb_intfc_t *intfc)
{
	struct usb_transfer *trans_pos, *trans_n;

	for_each_trans_safe(intfc, trans_pos, trans_n) {
		trans_pos->status = USB_TRANSFER_ERROR;
		trans_pos->callback(trans_pos->user_data);			
		list_delete(&trans_pos->link);
		usb_free_transfer(trans_pos);
	}
}

static struct usb_config_descriptor *
usb_dev_active_config(usb_device_t *dev)
{
	if (dev && dev->active_config != USB_DEACTIVE_CONFIG)
		return &dev->config_desc[dev->active_config - 1];
	return NULL;
}

static int usb_device_notify(unsigned long val, void *v)
{
	return call_notify_chain(&usb_device_chain, val, v);
}

int usb_unregister_notify(notify_t *nb, int type)
{
	return unregister_notify_chain(&usb_device_chain, nb);
}

int usb_register_notify(notify_t *nb)
{
	int err;

	err = register_notify_chain(&usb_device_chain, nb);
	if (err)
		goto unlock;

#if 0
	for_each_device(dev) {
		nb->call(nb, USB_DEVICE_REGISTER, dev);
		if (dev->devfs_ready)
			nb->call(nb, USB_DEVICE_ADD, dev);
	}
#endif
unlock:
	return err;
}

/* if match return 1 otherwise 0 */
static int usb_match_one_id(usb_intfc_t *intfc, const usb_dev_id_t *id)
{
	struct usb_interface_descriptor *cur_altsetting;
	struct usb_device *dev;
	int res = 0;
	/* proc_connectinfo in devio.c may call us with id == NULL. */
	if (id == NULL)
		return 0;

	/* refcnt */
	dev = usb_get_dev_by_intfc(intfc);
	if (!dev)
		return 0;
	cur_altsetting = intfc->cur_altsetting;

	/* The interface class, subclass, and protocol should never be
	 * checked for a match if the device class is Vendor Specific,
	 * unless the match record specifies the Vendor ID. */
	res = 0;
	if (dev->dev_desc->bDeviceClass == USB_CLASS_VENDOR_SPEC &&
			!(id->match_flags & USB_DEVICE_ID_MATCH_VENDOR) &&
			(id->match_flags & (USB_DEVICE_ID_MATCH_INT_CLASS |
				USB_DEVICE_ID_MATCH_INT_SUBCLASS |
				USB_DEVICE_ID_MATCH_INT_PROTOCOL)))
				goto out;

	if ((id->match_flags & USB_DEVICE_ID_MATCH_INT_CLASS) &&
	    (id->bInterfaceClass != cur_altsetting->bInterfaceClass))
		goto out;

	if ((id->match_flags & USB_DEVICE_ID_MATCH_INT_SUBCLASS) &&
	    (id->bInterfaceSubClass != cur_altsetting->bInterfaceSubClass))
		goto out;

	if ((id->match_flags & USB_DEVICE_ID_MATCH_INT_PROTOCOL) &&
	    (id->bInterfaceProtocol != cur_altsetting->bInterfaceProtocol))
		goto out;
	res = 1;
out:
	if (dev) usb_unref_device(dev);
	return res;
}

static const usb_dev_id_t *usb_match_id(usb_intfc_t *intfc,
					const usb_dev_id_t *id)
{
	if (id == NULL)
		return NULL;

	/* It is important to check that id->driver_info is nonzero,
	   since an entry that is all zeroes except for a nonzero
	   id->driver_info is the way to create an entry that
	   indicates that the driver want to examine every
	   device and interface. */
	for (; id->idVendor || id->bDeviceClass || id->bInterfaceClass ||
	       id->driver_info; id++) {
		if (usb_match_one_id(intfc, id))
			return id;
	}

	return NULL;
}

static usb_driver_t *usb_driver_by_name(const char *name)
{
	usb_driver_t *c;

	for_each_driver(c) {
		if (strcasecmp(c->name, name) == 0)
			return c;
	}
	return NULL;
}

int usb_register_driver(usb_driver_t *drv)
{
	usb_driver_t *tmp;

	tmp = usb_driver_by_name(drv->name);
	if (!tmp) {
		log_kern(LOG_INFO, "USB: driver registered, driver=%s",
			 drv->name);
		list_init(&drv->link);
		list_insert_before(&drv->link, &usb_drivers);
	}
	return 0;
}

void usb_unregister_driver(usb_driver_t *drv)
{
	if (drv) {
		log_kern(LOG_INFO, "USB: driver unregistered, driver=%s",
				drv->name);
		list_delete_init(&drv->link);
	}
}

static usb_device_t *usb_device_by_name(const char *file_name)
{
	usb_device_t *dev;
	
	for_each_device(dev) {
		if (!strcasecmp(file_name, dev->filename))
			return dev;
	}
	return NULL;
}

static void usb_device_free(usb_device_t *dev)
{
	usb_device_notify(USB_DEVICE_UNREGISTER, dev);

	/* usbi_clear_configration: clear_intfc, setting, ep */
	if (sys_ops->sys_device_release)
		sys_ops->sys_device_release(dev);
	if (dev->filename)
		free(dev->filename);
	list_delete(&dev->link);

	free(dev);
}

static usb_device_t *usb_device_new(const char *file_name)
{
	usb_device_t *dev = malloc(sizeof (usb_device_t));
	int ret;

	if (!dev) {
		usb_log(USB_LOG_ERR,
			"DEV: create usb device, out of memory");
		return NULL;
	}

	memset(dev, 0, sizeof(*dev));
	dev->active_config = USB_DEACTIVE_CONFIG;
	dev->ep_o = -1;
	dev->ep_i = -1;
	dev->ep_intr = -1;
	list_init(&dev->link);

	dev->filename = strdup(file_name);
	BUG_ON(!dev->filename);
	atomic_set(&dev->refcnt, 1);
	
	ret = sys_ops->sys_device_init(dev);
	if (ret != USB_SUCCESS) {
		usb_log(USB_LOG_ERR, "DEV: sys ops init err");
		goto err;
	}

	list_insert_before(&dev->link, &usb_devices);
	usb_device_notify(USB_DEVICE_REGISTER, dev);

	return dev;
err:
	if (dev->filename) free(dev->filename);
	if (dev) free(dev);
	return NULL;
}

#define USB_MAXDRIVERNAME		255

struct usb_getdriver {
	unsigned int intfc_no;
	char drv_name[USB_MAXDRIVERNAME + 1];
};

static int intfc_has_kernel_drv(usb_intfc_t *intfc)
{
	struct usb_getdriver getdrv;

	int ret;

	/* FIXME: default value is 0? */
	getdrv.intfc_no = intfc->cur_altsetting ? intfc->cur_altsetting->bInterfaceNumber : 0;
	ret = ioctl(intfc->fd, USBDEVFS_GETDRIVER, (unsigned long)&getdrv);
	if (ret) {
		usb_log(USB_LOG_DEBUG, "IOCTL: could not get bound driver in kernel");
		return 0;
	} else {
		usb_log(USB_LOG_DEBUG, "IOCTL: bound driver in kernel, drv=%s", getdrv.drv_name);
		/* store drv name ? */
		intfc->drv_name = strdup(getdrv.drv_name);
		return 1;
	}
}

static void usb_intfc_init(usb_device_t *dev, usb_intfc_t *intfc)
{
	if (dev && intfc) {
		list_init(&intfc->transfer_list);
		intfc->dev = usb_ref_device(dev);
	}
}

static void usb_intfc_exit(usb_device_t *dev, usb_intfc_t *intfc)
{
	if (dev && intfc) {
		usb_intfc_free_trans(intfc);
		usb_unref_device(intfc->dev);
	}
}

/* bind driver to claim intfc */
static void usb_intfc_bind_driver(usb_device_t *dev, usb_intfc_t *intfc)
{
	if (dev && intfc) {
		usb_driver_t *drv;

		if (intfc->has_kernel_drv == 0 &&
		    intfc_has_kernel_drv(intfc)) {
			usb_log(USB_LOG_DEBUG, "INTFC: intfc has kernel drv=%s", intfc->drv_name);
			intfc->has_kernel_drv = 1;
			return;
		}

		usb_log(USB_LOG_DEBUG, "INTFC: intfc need userland drv");
		if (!intfc->bind_drv) {
			for_each_driver(drv) {
				/* TODO: how to make this unique match,
				 * if all driver use the same id how to do */
				if (usb_match_id(intfc, drv->id_table)) {
					usb_log(USB_LOG_INFO, "INTFC: get userland drv=%s", drv->name);
					intfc->bind_drv = 1;
					intfc->drv_name = strdup(drv->name);

#if 0
					ret = usb_claim_interface(intfc);
					usb_log(USB_LOG_INFO, "USB: claim intfc at start=%d", ret);
					ret = usb_release_interface(intfc, 0);
					usb_log(USB_LOG_INFO, "USB: release intfc at start=%d", ret);
#endif

					usb_open(intfc);
					/* call driver insert */
					if (drv->insert)
						drv->insert(intfc);
					/* open device for interface(userland) */
					break;
				}
			}
		}
	}
}

static void usb_intfc_unbind_driver(usb_device_t *dev, usb_intfc_t *intfc)
{
	if (dev && intfc) {
		usb_driver_t *drv;
		
		if (intfc->drv_name)
			free(intfc->drv_name);

		if (intfc->has_kernel_drv == 1) {
			intfc->has_kernel_drv = 0;
			return;
		}

		if (intfc->bind_drv) {
			for_each_driver(drv) {
				/* TODO: how to make this unique match,
				 * if all driver use the same id how to do */
				if (usb_match_id(intfc, drv->id_table)) {
					intfc->bind_drv = 0;
					/* call driver probe */
					usb_close(intfc);
					if (drv->remove)
						drv->remove(intfc);
					break;
				}
			}
		}
	}
}

usb_intfc_t *usb_get_intfc_by_altsetting(usb_device_t *dev, 
					 const struct usb_interface_descriptor *alts)
{
	int i, j, con_no, intfc_no;
	usb_config_t *config;
	usb_intfc_t *intfc;

	con_no = dev->dev_desc->bNumConfigurations;
	for (i = 0; i < con_no; i++) {
		config = &dev->config_desc[i];
		intfc_no = config->bNumInterfaces;

		for (j = 0; j < intfc_no; j++) {
			intfc = (usb_intfc_t *)&config->intfc[j];
			if (intfc->cur_altsetting == alts)
				return intfc;
		}
	}
	return NULL;
}

/**
 * iterate all interfaces on the dev and do the action for them.
 */
static void *usb_for_each_intfc_action(usb_device_t *dev, usb_action act)
{
	int i, j, con_no, intfc_no;
	usb_config_t *config;
	usb_intfc_t *intfc;

	if (!dev)
		return NULL;

	con_no = dev->dev_desc->bNumConfigurations;
	for (i = 0; i < con_no; i++) {
		config = &dev->config_desc[i];
		intfc_no = config->bNumInterfaces;
		for (j = 0; j < intfc_no; j++) {
			intfc = (usb_intfc_t *)&config->intfc[j];
			act(dev, intfc);
		}
	}
	return NULL;
}

/* if not exist then create device */
usb_device_t *usb_get_device(const char *file_name)
{
	usb_device_t *dev;

	dev = usb_device_by_name(file_name);
	if (dev)
		return usb_ref_device(dev);
	else {
		return usb_device_new(file_name);
	}
}

void usb_put_device(usb_device_t *usb_dev)
{
	usb_unref_device(usb_dev);
}

static void usb_gc_timeout(void *eloop, void *data)
{
	usb_device_t *dev, *n;

	for_each_device_gc_safe(dev, n) {
		if (atomic_read(&dev->refcnt) == 0) {
			usb_device_free(dev);
		}
	}
	if (!list_empty(&usb_devices_gc))
		eloop_register_timeout(NULL, USB_GC_TIMEOUT, 0,
				       usb_gc_timeout, NULL, NULL);
}

static int usb_device_down(usb_device_t *dev)
{
	if (!dev)
		return -1;

	usb_device_notify(USB_DEVICE_GOING_DOWN, dev);
	/* TODO: ioctl with kernel */

	return -1;
}



static usb_device_t *usb_device_open(const char *filename)
{
	/* create usb device and init desc */
	usb_device_t *dev = usb_get_device(filename);

	if (dev) {
		/* attach dev to interface and init trans list */
		usb_for_each_intfc_action(dev, usb_intfc_init);
		/* bind drv for each interface */
		usb_for_each_intfc_action(dev, usb_intfc_bind_driver);
	}
	return dev;
}

static void usb_device_close(usb_device_t *dev)
{
	if (dev && !dev->closing) {
		dev->closing = 1;
		usb_for_each_intfc_action(dev, usb_intfc_unbind_driver);
		/* detach dev from interface and free trans on intfc */
		usb_for_each_intfc_action(dev, usb_intfc_exit);
	
		usb_put_device(dev);

		list_delete_init(&dev->link);
		list_insert_before(&dev->link, &usb_devices_gc);
		eloop_register_timeout(NULL, USB_GC_TIMEOUT, 0,
				       usb_gc_timeout, NULL, NULL);
	}
}

/* FIXME: ccid do not call it directly. */
int usb_open(usb_intfc_t *intf)
{
	return sys_ops->sys_open(intf);
}

int usb_close(usb_intfc_t *intf)
{
	sys_ops->sys_close(intf);
	return USB_SUCCESS;
}


static int __convert_path2devname(udev_event_t *msg, char *path, char *devname)
{
	char *p;
	int busnum, devnum;

	p = strrchr(path, '/');
	if (strncmp(p + 1, "usbdev", 6))
		return -1;
	p += 7;
	sscanf(p, "%d.%d", &busnum, &devnum);

	memset(devname, 0, sizeof(devname));
	sprintf(devname, "bus/usb/%03i/%03i", busnum, devnum);
	return 0;
}

static usb_name_t *usb_name_get(const char *name)
{
	usb_name_t *n;
	for_each_usbname(n) {
		if (0 == strcasecmp(n->name, name))
			return n;
	}
	return NULL;
}

static int __is_usb_udev_node(const char *name)
{
	if (usb_name_get(name))
		return 1;
	return 0;
}

static void usb_add_dev_name(const char *name)
{
	usb_name_t *n;

	if (usb_name_get(name))
		return;

	n = malloc(sizeof (usb_name_t));

	if (!n) {
		usb_log(USB_LOG_ERR, "out of memory");
		return;
	}
	list_init(&n->link);
	n->name = strdup(name);
	list_insert_before(&n->link, &usb_name_list);
	usb_log(USB_LOG_INFO, "DEV: add name=%s", name);
}

static void usb_del_dev_name(const char *name)
{
	usb_name_t *n;
	
	n = usb_name_get(name);

	if (n == NULL)
		return;
	list_delete(&n->link);
	usb_log(USB_LOG_INFO, "DEV: del name=%s", name);
	if (n->name)
		free(n->name);
	free(n);
}

static int usb_device_add(udev_event_t *msg, udev_device_t *udev)
{
	/* K=%k;
	 * K=$${K#usbdev};
	 * printf bus/usb/%%03i/%%03i $${K%%%%.*} $${K#*.}
	 */
	char *devpath, devname[PATH_MAX];
	
	devpath = udev_event_getenv(msg, "DEVPATH");
	if (!devpath)
		BUG();

	if (0 != __convert_path2devname(msg, devpath, devname))
			return -1;

	udev_event_setenv(msg, "USB_DEVNAME", devname, 1);

	/* add dev filename into name list */
	usb_add_dev_name(devname);
	return 0;
}

static int usb_device_remove(udev_event_t *msg, udev_device_t *udev)
{
	usb_device_t *dev;
	char devname[PATH_MAX], *devpath = udev_event_getenv(msg, "DEVPATH");

	if (0 != __convert_path2devname(msg, devpath, devname))
			return -1;
	if (devname) {
		udev_event_setenv(msg, "USB_DEVNAME", devname, 1);
#if 1
		/* del dev filename into name list */
		usb_del_dev_name(devname);

		/* FIXME: why cannot get UDEV_DELETE event */
		dev = usb_device_by_name(devname);
		if (dev) {
			usb_log(USB_LOG_INFO, "DEV: remove device=%s", devname);
			usb_device_notify(USB_DEVICE_REMOVE, dev);
			usb_device_close(dev);	
		}
#endif
	}

	return 0;
}

static int usb_udev_event(notify_t *nb,
			  unsigned long event, void *data);

static int usb_udev_event(notify_t *nb,
			  unsigned long event, void *data)
{
	udev_node_t *node = (udev_node_t *)data;
	usb_device_t *dev;
	char *p, *res;


	p = strstr(node->filename, _PATH_DEV);
	res = node->filename;
	if (p)
		res = p + strlen(_PATH_DEV);

	if (__is_usb_udev_node(res)) {
		usb_log(USB_LOG_DEBUG, "usb_node=%s, res=%s", node->filename, res);
		switch (event) {
		case UDEV_CREATE:
			dev = usb_device_open(res);
			if (dev) {
				usb_device_notify(USB_DEVICE_ADD, dev);
				usb_log(USB_LOG_INFO, 
					"USB: add device=%s", dev->filename);
			}
			break;
		case UDEV_DELETE:
#if 0
			dev = usb_device_by_name(res);
			if (dev) {
				usb_del_dev_name(res);
				log_kern(LOG_INFO, "USB: remove device=%s", res);
				usb_device_notify(USB_DEVICE_REMOVE, dev);
				usb_device_close(dev);	
			}
#endif
			break;
		default:
			break;
		}
	}
	return 0;
}

static notify_t usb_udev_notify = {
	NULL,
	usb_udev_event,
	9,
};

static int usb_register_udev_notify(void)
{
	return udev_register_notify(&usb_udev_notify);
}

static void usb_unregister_udev_notify(void)
{
	udev_unregister_notify(&usb_udev_notify);
}

/* cli commands */
static int usb_cmd_devices(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	usb_device_t *dev;
	int i = 0;
	ui_table_t *table = ui_table_by_name(sess, "usb_devices");
	char buf[25] = "";

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "usb_devices");
	if (!table)
		return -1;

	ui_add_title(table, 0, "name");
	ui_add_title(table, 1, "active_config");
	ui_add_title(table, 2, "interface_count");	/* show act config's intfc number */
	ui_add_title(table, 3, "refcnt");

	for_each_device(dev) {
		ui_add_value(table, "name", i, dev->filename);
		snprintf(buf, sizeof(buf), "%d", dev->active_config);
		ui_add_value(table, "active_config", i, buf);
		snprintf(buf, sizeof(buf), "%d", 
				dev->config_desc[dev->active_config - 1].bNumInterfaces);
		ui_add_value(table, "interface_count", i, buf);
		snprintf(buf, sizeof(buf), "%d", atomic_read(&dev->refcnt));
		ui_add_value(table, "refcnt", i, buf);
		i++;
	}
	sess->result_table = table;
	return 0;
}

/* only show active config's interfaces on that dev */
static int usb_cmd_intfc(ui_session_t *sess, ui_entry_t *inst,
			   void *ctx, int argc, char **argv)
{
	usb_device_t *dev;
	ui_table_t *table = ui_table_by_name(sess, "usb_devices_intfc");
	char buf[25] = "";
	int i = 0, j = 0;

	if (table) {
		ui_table_delete(table);
	}
	table = ui_table_create(sess, "usb_devices_intfc");
	if (!table)
		return -1;

	ui_add_title(table, 0, "name");
	ui_add_title(table, 1, "intfc_no");
	ui_add_title(table, 2, "intfc_class");
	ui_add_title(table, 3, "driver_mode");
	ui_add_title(table, 4, "driver_name");
	
	for_each_device(dev) {
		usb_intfc_desc_t *intfc_desc;
		usb_intfc_t *intfc;
		usb_config_t *config = usb_dev_active_config(dev);

		if (!config)
			continue;

		for (j = 0; j < config->bNumInterfaces; j++) {
			intfc = (usb_intfc_t *)&config->intfc[j];
			intfc_desc = intfc->cur_altsetting;

			ui_add_value(table, "name", i, dev->filename);
			snprintf(buf, sizeof(buf), "%d", j);
			ui_add_value(table, "intfc_no", i, buf);
			snprintf(buf, sizeof(buf), "%d", intfc_desc->bInterfaceClass);
			ui_add_value(table, "intfc_class", i, buf);
			ui_add_value(table, "driver_mode", i, 
					intfc->has_kernel_drv ?  "kernel" : "userland");
			ui_add_value(table, "driver_name", i, 
					intfc->drv_name ?  intfc->drv_name : "not found");
			i++;
		}
	}

	sess->result_table = table;
	return 0;
}

ui_command_t usb_devices_command = {
	"dump",
	"Dump all usb devices",
	".usb.devices",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(usb_devices_command.link),
	usb_cmd_devices,
};

ui_command_t usb_intfc_command = {
	"dump",
	"Dump all interface on the usb devices",
	".usb.devices.interface",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(usb_intfc_command.link),
	usb_cmd_intfc,
};

int __init usb_dev_init(void)
{
	udev_register_program("usb_device_add", usb_device_add);
	udev_register_program("usb_device_remove", usb_device_remove);
	usb_add_rule = udev_register_rule("SUBSYSTEM==\"usb_device\", "
					   "PROGRAM=\"usb_device_add\", "
					   "ACTION==\"add\", "
					   "NAME=\"$env{USB_DEVNAME}\"");
	usb_del_rule = udev_register_rule("SUBSYSTEM==\"usb_device\", "
					  "PROGRAM=\"usb_device_remove\", "
					   "ACTION==\"remove\", "
					   "NAME=\"$env{USB_DEVNAME}\"");
	ui_register_schema(usb_device_schema);
	ui_register_command(&usb_devices_command);
	ui_register_command(&usb_intfc_command);

	usb_register_udev_notify();
	return 0;
}

void __exit usb_dev_exit(void)
{
	usb_unregister_udev_notify();

	ui_unregister_command(&usb_intfc_command);
	ui_unregister_schema(usb_device_schema);
	ui_unregister_command(&usb_devices_command);

	udev_unregister_program("usb_device_add");
	udev_unregister_program("usb_device_remove");
	udev_unregister_rule(usb_add_rule);
	udev_unregister_rule(usb_del_rule);
}
