#include "udev_priv.h"

udev_rule_t *usb_add_rule;

static int usb_device_rule(udev_event_t *msg, udev_device_t *dev)
{
	/* K=%k;
	 * K=$${K#usbdev};
	 * printf bus/usb/%%03i/%%03i $${K%%%%.*} $${K#*.}
	 */
	int busnum, devnum;
	char *p, devname[PATH_MAX];

	p = strrchr(msg->devpath, '/');
	if (strncmp(p + 1, "usbdev", 6))
		return -1;
	p += 7;
	sscanf(p, "%d.%d", &busnum, &devnum);
	
	memset(devname, 0, sizeof(devname));
	sprintf(devname, "bus/usb/%03i/%03i", busnum, devnum);

	udev_event_setenv(msg, "USB_DEVNAME", devname, 1);
	return 0;
}

modlinkage int udev_usb_init(void)
{
	udev_register_program("usb_device_rule", usb_device_rule);
	usb_add_rule = udev_register_rule("SUBSYSTEM==\"usb_device\", "
					   "PROGRAM=\"usb_device_rule\", "
					   "ACTION==\"add\", "
					   "NAME=\"$env{USB_DEVNAME}\"");
	return 0;
}

modlinkage void udev_usb_exit(void)
{
	udev_unregister_program("usb_device_rule");
	udev_unregister_rule(usb_add_rule);
}

module_init(udev_usb_init);
module_exit(udev_usb_exit);
