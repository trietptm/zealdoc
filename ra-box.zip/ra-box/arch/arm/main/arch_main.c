#include <sysdep.h>
#include <module.h>

modlinkage int arch_init(void)
{
	return 0;
}

modlinkage void arch_exit(void)
{
}

arch_initcall(arch_init);
arch_exitcall(arch_exit);

