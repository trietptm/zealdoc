/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2008
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@gmail.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)strutl.h: string utilities interface
 * $Id: strutl.h,v 1.33 2009-02-03 08:06:33 zhenglv Exp $
 */

#ifndef __STRUTL_H_INCLUDE__
#define __STRUTL_H_INCLUDE__

#include <sysdep.h>
#include <uiserv.h>

typedef struct _string_map_t {
	const char *name;
	int number;
	const char *desc;
} string_map_t;

const char *sock_errstr(void);

#define stremp(x)		(!x || x[0] == '\0')
#define streq(name2, name1)			\
	((stremp(name2) && stremp(name1)) ||	\
	(!stremp(name2) && !stremp(name1) && strcmp(name1, name2) == 0))

#define strlast(str)		str ? *(str + strlen(str)) : 0

#define STR_MAX_INADDR	16
uint32_t ip_addr(const char *ip_str);
uint32_t ip_resolv_addr(const char *host);
int ipv6_addr(const char *ip6_str, void *ip6addr);
char *ipv6_ntoa(char *buffer, size_t size, void *ip6addr);
uint8_t *ifid_aton(const char *ifid_str, uint8_t *ifid);
char *ifid_ntoa(char *buffer, size_t size, uint8_t *ifid);

uint8_t *eth_parse(const char *str);
const char *eth_build(const uint8_t *ptr);
int eth_empty(const uint8_t *mac);
int eth_compare(const uint8_t *mac1, const uint8_t *mac2);

const char *u8tostr(uint16_t num);
const char *u16tostr(uint16_t num);
uint8_t str2u8(const char *str);
uint16_t str2u16(const char *str);

char *time_string(int utc, time_t tm);
int hex2i(const char *hex);
uint8_t hexchar(char h);
unsigned int hweight32(unsigned int w);

void chomp(char *line);
size_t strlcpy(char *dst, const char *src, size_t size);
size_t strlcat(char *dst, const char *src, size_t size);
size_t strnlen(const char *s, size_t count);
char *strredup(char *old_str, const char *str);
int strisdigit(const char *str);
int strishex(const char *str);
char *strndup(const char *s1, size_t n);

int vslprintf(char *buf, int buflen, const char *fmt, va_list args);
int slprintf(char *buf, int buflen, const char *fmt, ...);

#ifdef WIN32
uint64_t strtoull(const char *, char **, unsigned int);
#endif
void strupper(char *string);

int replace_chars(char *str, const char *white);
int utf8_encoded_valid_unichar(const char *str);
void remove_trailing_chars(char *path, char c);
int string_is_true(const char *str);

int name2int(const string_map_t *table, const char *name, int def);
const char *int2name(const string_map_t *table, int number, const char *def);
const char *int2desc(const string_map_t *table, int number, const char *def);
void string_map_foreach(ui_choice_t *choice,
			ui_iterate_fn func, void *data);
const char *string_map_name(const void *iter);
const char *string_map_desc(const void *iter);

void do_percentm(char *obuf, const char *ibuf);

void daemonize(void);

#endif /* __STRUTL_H_INCLUDE__ */
