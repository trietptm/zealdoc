#ifndef __VTSS_BOARD_H_INCLUDE__
#define __VTSS_BOARD_H_INCLUDE__

#include <autoconf.h>

#define CONFIG_VTSS_AUTH 1
#define CONFIG_VTSS_ACL 1
#define CONFIG_VTSS_QOS 1
#define CONFIG_VTSS_CPU_FRAME 1
#define CONFIG_VTSS_PVLAN 1

/* ================================================================= *
 *  Features
 * ================================================================= */
#ifdef CONFIG_VTSS_GROCX
#define VTSS_PORTS			7
#define VTSS_ACES			64
/* CPU RX */
#define VTSS_CPU_RX_QUEUES		4
#define VTSS_CHIP_PORT_VAUI_START	24
/* QoS */
#define VTSS_PRIOS			4
#define VTSS_QUEUES			4
#define VTSS_CHIP_PGIDS			64
#define VTSS_ACS			((vtss_ac_no_t)16)
#define VTSS_PVLANS			(VTSS_PORTS)
#define VTSS_QCL_IDS			(VTSS_PORTS)
/* Maximum number entries in the MAC address table */
#define VTSS_MAC_ADDRS			8192

#define VTSS_CHIP_PORTS			VTSS_PORTS
#define VTSS_CHIP_PORT_CPU		VTSS_CHIP_PORTS
#define VTSS_CHIP_PORTMASK		((1<<VTSS_CHIP_PORTS)-1)

#define VTSS_FEATURE_SERIAL_LED 1             /* Serial LED */
#define VTSS_FEATURE_EXC_COL_CONT 1           /* Excessive collision continuation */
#define VTSS_FEATURE_PORT_CNT_PKT_CAST 1      /* Has separate counters for unicast/multicast */
#define VTSS_FEATURE_PORT_CNT_RMON_ADV 1      /* Advanced RMON counters */
#define VTSS_FEATURE_PORT_CNT_JUMBO 1         /* Jumbo frame (>1518) counters */
#define VTSS_FEATURE_PORT_CNT_QOS 1           /* QoS counters */
#define VTSS_FEATURE_PORT_CNT_BRIDGE 1        /* Bridge counters */
#define VTSS_FEATURE_QOS_WFQ_PORT 1           /* QoS: Weighted Fairness Queueing per port */
#define VTSS_FEATURE_QOS_ETYPE_PORT 1         /* QoS: Ethernet Type per port */
#define VTSS_FEATURE_QOS_IP_TOS_PORT 1        /* QoS: Use 3 MSBit from TOS field per port */
#define VTSS_FEATURE_QOS_L4_PORT 1            /* QoS: Layer 4 per port */
#define VTSS_FEATURE_QOS_DSCP_REMARK 1        /* QoS: DSCP remarking */
#define VTSS_FEATURE_QOS_TAG_REMARK 1         /* QoS: Tag priority remarking */
#define VTSS_FEATURE_QCL_PORT 1               /* QoS: QCLs per port */
#define VTSS_FEATURE_QOS_SHAPER_PORT 1        /* QoS: Shaper per port */
#define VTSS_FEATURE_QOS_POLICER_PORT 1       /* QoS: Policer per port */
#define VTSS_FEATURE_QOS_POLICER_CPU_SWITCH 1 /* QoS: CPU policers per switch */
#define VTSS_FEATURE_QOS_POLICER_UC_SWITCH 1  /* QoS: Unicast policer per switch */
#define VTSS_FEATURE_QOS_POLICER_MC_SWITCH 1  /* QoS: Multicast policer per switch */
#define VTSS_FEATURE_QOS_POLICER_BC_SWITCH 1  /* QoS: Broadcast policer per switch */
#define VTSS_FEATURE_ACL 1                    /* Access Control Lists */
#define VTSS_FEATURE_CPU_RX_LEARN 1           /* Learn flag */
#define VTSS_FEATURE_MAC_AGE_AUTO 1           /* Automatic MAC address ageing */
#define VTSS_FEATURE_VLAN_INGR_FILTER_PORT 1  /* VLAN: Ingr. filter per port */
#define VTSS_FEATURE_VLAN_TYPE_STAG 1         /* VLAN: S-Tag type */
#define VTSS_FEATURE_AGGR_MODE_ADV 1          /* Advanced aggregation mode */
#define VTSS_FEATURE_AGGR_MODE_RANDOM 1       /* Random aggregation mode */
#define VTSS_FEATURE_LEARN_PORT 1             /* Learning per port */
#define VTSS_FEATURE_ISOLATED_PORT 1          /* PVLAN port isolation */
#define VTSS_FEATURE_JUMBO_FRAME_PORT 1       /* Jumbo frames per port */
#endif

#endif /* __VTSS_BOARD_H_INCLUDE__ */
