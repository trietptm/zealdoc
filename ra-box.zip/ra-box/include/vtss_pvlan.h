#ifndef __VTSS_PVLAN_H_INCLUDE__
#define __VTSS_PVLAN_H_INCLUDE__

#define VTSS_PVLAN_NO_START    ((vtss_pvlan_no_t)1)
#define VTSS_PVLAN_NO_END      (VTSS_PVLAN_NO_START+VTSS_PVLANS)
#define VTSS_PVLAN_ARRAY_SIZE  VTSS_PVLAN_NO_END

#define VTSS_PVLAN_NO_DEFAULT  ((vtss_pvlan_no_t)1)

/* Private VLAN Number: 1..VTSS_PVLANS */
typedef uint vtss_pvlan_no_t;  /* VTSS_PVLAN_NO_START..(VTSS_PVLAN_NO_END-1) */

/* PVLAN entry */
typedef struct {
	BOOL member[VTSS_PORT_ARRAY_SIZE]; /* Member ports */
} vtss_pvlan_entry_t;

typedef struct {
	vtss_pvlan_entry_t       pvlan_table[VTSS_PVLAN_ARRAY_SIZE];
} vtss_pvlan_state_t;

/******************************************************************************
 * Description: Get Private VLAN membership.
 *
 * \param pvlan_no (input): Private VLAN group number.
 * \param member (output) : Private VLAN port member array.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_pvlan_port_members_get(const vtss_pvlan_no_t pvlan_no,
				BOOL member[VTSS_PORT_ARRAY_SIZE]);


/******************************************************************************
 * Description: Set Private VLAN membership.
 *
 * \param pvlan_no (input): Private VLAN group number.
 * \param member (input)  : Private VLAN port member array.
 *
 * \return : Return code.
 ******************************************************************************/
int vtss_pvlan_port_members_set(const vtss_pvlan_no_t pvlan_no,
				const BOOL member[VTSS_PORT_ARRAY_SIZE]);

extern vtss_pvlan_state_t vtss_pvlan_state;

#ifdef CONFIG_VTSS_PVLAN
int vtss_pvlan_reset(void);
int vtss_pvlan_start(void);
int vtss_pvlan_update_masks(vtss_port_no_t i_port_no,
			    vtss_port_no_t e_port_no,
			    BOOL member[VTSS_PORT_ARRAY_SIZE]);
#else
static inline int vtss_pvlan_reset(void) { return 0; }
static inline int vtss_pvlan_start(void) { return 0; }
static inline int vtss_pvlan_update_masks(vtss_port_no_t i_port_no,
					  vtss_port_no_t e_port_no,
					  BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	return 0;
}
#endif

#endif /* __VTSS_PVLAN_H_INCLUDE__ */
