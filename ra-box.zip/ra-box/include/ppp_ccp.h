#ifndef __PPP_CCP_H_INCLUDE__
#define __PPP_CCP_H_INCLUDE__

#include <ppp_nego.h>

/* RFC 1962 CCP
 * RFC 1979 PPP DEFLATE
 * RFC 2118 MPPC / RFC 3078 MPPE
 */
/*
	RFC 1962 CCP

  CCP Option      Compression type
  0               OUI
  1               Predictor type 1
  2               Predictor type 2
  3               Puddle Jumper
  4-15            unassigned
  16              Hewlett-Packard PPC
  17              Stac Electronics LZS
  18              Microsoft PPC
  19              Gandalf FZA
  20              V.42bis compression
  21              BSD LZW Compress
  255             Reserved
 */
#define PPP_CCP_TYPE_OUI	0
#define PPP_CCP_TYPE_PREDICTOR1	1
#define PPP_CCP_TYPE_PREDICTOR2 2
#define PPP_CCP_TYPE_MPPEC	18
#define PPP_CCP_TYPE_BSDCOMP	21
#define PPP_CCP_TYPE_DEFLATE	26	/* RFC 1979 */
#define PPP_CCP_TYPE_RESERVED	255

/* Option length */
#define CCP_CILEN_MPPE		6	/* length of config option */

/* FIXME: delete */
#define CI_BSD_COMPRESS		PPP_CCP_TYPE_BSDCOMP
#define CI_DEFLATE		PPP_CCP_TYPE_DEFLATE
#define CI_MPPE			PPP_CCP_TYPE_MPPEC

typedef struct _ccp_option_t	ccp_option_t;
typedef struct _ccp_extension_t ccp_extension_t;

struct _ccp_extension_t {
	uint8_t type;
	const char *name;
	const char *desc;

	int  (*init)(ppp_negoinst_t *inst);
	void (*exit)(ppp_negoinst_t *inst, ccp_option_t *opti);

	/* Since we only use one option, when CCP layer up, we call option up then. */
	int  (*opt_up)(ccp_option_t *opti);
	void (*opt_down)(ccp_option_t *opti);

	void (*opt_init)(ccp_option_t *opt);
	void (*opt_reset)(ccp_option_t *opti);
	int  (*opt_bcr)(ccp_option_t *opti, msgbuf_t *msg);
	int  (*opt_pcp)(ccp_option_t *opti, msgbuf_t *msg, uint8_t code);
	int  (*opt_rcr)(ccp_option_t *opti, msgbuf_t *req, msgbuf_t *nak, uint8_t *orc);
	void (*opt_rca)(ccp_option_t *opti, msgbuf_t *msg);
	void (*opt_rcn)(ccp_option_t *opti, msgbuf_t *msg);
	void (*opt_rcj)(ccp_option_t *opti, msgbuf_t *msg);
	
	bool (*opt_cnq)(ccp_option_t *opti);
	bool (*opt_cnp)(ccp_option_t *opti, msgbuf_t *req);
	bool (*opt_cnj)(ccp_option_t *opti, msgbuf_t *req);
	/* receive compress data */
	int (*opt_datainput)(ccp_option_t *opti, msgbuf_t *msg);
	list_t link;
};

struct _ccp_option_t {
	ccp_extension_t *ccp_extension;
	ppp_negoinst_t *ccp_instance;
	/* FIXME: disable the option */
	int naked;
	int seen_nak_before;
	list_t link;
};

int ccp_register_extension(ccp_extension_t *opt);
void ccp_unregister_extension(ccp_extension_t *opt);
void ccp_option_enable(ppp_negoinst_t *insti, ccp_option_t *opt);
void ccp_option_disable(ppp_negoinst_t *insti, ccp_option_t *opt);


#if 0 /* From PPPD */
/* Unfortunately there is a bug in zlib which means that using a
 * size of 8 (window size = 256) for Deflate compression will cause
 * buffer overruns and kernel crashes in the deflate module.
 * Until this is fixed we only accept sizes in the range 9 .. 15.
 * Thanks to James Carlson for pointing this out.
 *
 * If vpn server is MS machine, we can do deflate or bsd_compress with it?
 */
#define DEFLATE_MIN_WORKS	9
#define CCP_ANY_COMPRESS(opt)	((opt).neg_deflate || (opt).neg_bsd_compress \
				 || (opt).neg_predictor_1 || (opt).neg_predictor_2 \
				 || (opt).neg_mppe)
/* Values for auth_done only
 * since ccp need master key from the auth algo
 **/
#define CCP_CHAP_MD5_WITHPEER		0x40
#define CCP_CHAP_MD5_PEER		0x80
#define CCP_CHAP_MS_SHIFT		8	/* LSB position for MS auths */
#define CCP_CHAP_MS_WITHPEER		0x100
#define CCP_CHAP_MS_PEER		0x200
#define CCP_CHAP_MS2_WITHPEER		0x400
#define CCP_CHAP_MS2_PEER		0x800

#define CCP_RACK_PENDING	1	/* waiting for reset-ack */
#define CCP_RREQ_REPEAT		2	/* send another reset-req if no reset-ack */
#define CCP_RACKTIMEOUT		1	/* second */

/* code definition are in ppp-comp.h(in kernel) 
 * Note that there two individure code in ccp as below:
 *	#define CCP_RESETREQ	14
 *	#define CCP_RESETACK	15
 **/
/*
 * Max # bytes for a CCP option
 */
#define CCP_MAX_OPTION_LENGTH	32

/*
 * Parts of a CCP packet.
 */
#define CCP_CODE(dp)		((dp)[0])
#define CCP_ID(dp)		((dp)[1])
#define CCP_LENGTH(dp)		(((dp)[2] << 8) + (dp)[3])
#define CCP_HDRLEN		4

#define CCP_OPT_CODE(dp)	((dp)[0])
#define CCP_OPT_LENGTH(dp)	((dp)[1])
#define CCP_OPT_MINLEN		2

/* For allow option */
#define CCP_SCOMPRESS	0x01
#define CCP_GFLAGS	0x02
#define CCP_SFLAGS	0x03
#define CCP_GET_CTX	0x04
/*
 * Definitions for BSD-Compress.
 */
#define CI_BSD_COMPRESS		21	/* config. option for BSD-Compress */
#define CILEN_BSD_COMPRESS	3	/* length of config. option */

/* Macros for handling the 3rd byte of the BSD-Compress config option. */
#define BSD_NBITS(x)		((x) & 0x1F)	/* number of bits requested */
#define BSD_VERSION(x)		((x) >> 5)	/* version of option format */
#define BSD_CURRENT_VERSION	1		/* current version number */
#define BSD_MAKE_OPT(v, n)	(((v) << 5) | (n))

#define BSD_MIN_BITS		9	/* smallest code size supported */
#define BSD_MAX_BITS		15	/* largest code size supported */

/*
 * Definitions for Deflate.
 */
#define CI_DEFLATE		26	/* config option for Deflate */
#define CI_DEFLATE_DRAFT	24	/* value used in original draft RFC */
#define CILEN_DEFLATE		4	/* length of its config option */

#define DEFLATE_MIN_SIZE	8
#define DEFLATE_MAX_SIZE	15
#define DEFLATE_METHOD_VAL	8
#define DEFLATE_SIZE(x)		(((x) >> 4) + DEFLATE_MIN_SIZE)
#define DEFLATE_METHOD(x)	((x) & 0x0F)
#define DEFLATE_MAKE_OPT(w)	((((w) - DEFLATE_MIN_SIZE) << 4) \
				 + DEFLATE_METHOD_VAL)
#define DEFLATE_CHK_SEQUENCE	0

/*
 * Definitions for MPPE.
 */
#define CI_MPPE			18	/* config option for MPPE */
#define CILEN_MPPE		6	/* length of config option */

#define MPPE_PAD		4	/* MPPE growth per frame */
#define MPPE_MAX_KEY_LEN	16	/* largest key length (128-bit) */

/* option bits for ccp_options.mppe */
#define MPPE_OPT_40		0x01	/* 40 bit */
#define MPPE_OPT_128		0x02	/* 128 bit */
#define MPPE_OPT_STATEFUL	0x04	/* stateful mode */
/* unsupported opts */
#define MPPE_OPT_56		0x08	/* 56 bit */
#define MPPE_OPT_MPPC		0x10	/* MPPC compression */
#define MPPE_OPT_D		0x20	/* Unknown */
#define MPPE_OPT_UNKNOWN	0x40	/* Bits !defined in RFC 3078 were set */
/* Only support a encrypt bit since we set this as want options */
/* Note: in our used kernel, it has not support MPPC in ppp_mppe module */
#define MPPE_OPT_SUPPORTED	(MPPE_OPT_128)
#define MPPE_OPT_UNSUPPORTED 	(MPPE_OPT_56 | MPPE_OPT_40 | MPPE_OPT_MPPC)

/*
 * This is not nice ... the alternative is a bitfield struct though.
 * And unfortunately, we cannot share the same bits for the option
 * names above since C and H are the same bit.  We could do a u_int32
 * but then we have to do a htonl() all the time and/or we still need
 * to know which octet is which.
 */
#define MPPE_C_BIT		0x01	/* MPPC */
#define MPPE_D_BIT		0x10	/* Obsolete, usage unknown */
#define MPPE_L_BIT		0x20	/* 40-bit */
#define MPPE_S_BIT		0x40	/* 128-bit */
#define MPPE_M_BIT		0x80	/* 56-bit, not supported */
#define MPPE_H_BIT		0x01	/* Stateless (in a different byte) */

/* Values for auth_pending, auth_done */
#define PAP_WITHPEER	0x1
#define PAP_PEER	0x2
#define CHAP_WITHPEER	0x4
#define CHAP_PEER	0x8
#define EAP_WITHPEER	0x10
#define EAP_PEER	0x20

/* Values for auth_done only */
#define CHAP_MD5_WITHPEER	0x40
#define CHAP_MD5_PEER		0x80
#define CHAP_MS_SHIFT		8	/* LSB position for MS auths */
#define CHAP_MS_WITHPEER	0x100
#define CHAP_MS_PEER		0x200
#define CHAP_MS2_WITHPEER	0x400
#define CHAP_MS2_PEER		0x800

/* Does not include H bit; used for least significant octet only. */
#define MPPE_ALL_BITS (MPPE_D_BIT|MPPE_L_BIT|MPPE_S_BIT|MPPE_M_BIT|MPPE_H_BIT)

/* Build a CI from mppe opts (see RFC 3078) */
#define MPPE_OPTS_TO_CI(opts, ci)		\
    do {					\
	u_char *ptr = ci; /* u_char[4] */	\
						\
	/* H bit */				\
	if (opts & MPPE_OPT_STATEFUL)		\
	    *ptr++ = 0x0;			\
	else					\
	    *ptr++ = MPPE_H_BIT;		\
	*ptr++ = 0;				\
	*ptr++ = 0;				\
						\
	/* S,L bits */				\
	*ptr = 0;				\
	if (opts & MPPE_OPT_128)		\
	    *ptr |= MPPE_S_BIT;			\
	if (opts & MPPE_OPT_40)			\
	    *ptr |= MPPE_L_BIT;			\
	if (opts & MPPE_OPT_MPPC)		\
	    *ptr |= MPPE_C_BIT;			\
	/* M,D bits not supported */		\
    } while (/* CONSTCOND */ 0)

/* The reverse of the above */
#define MPPE_CI_TO_OPTS(ci, opts)		\
    do {					\
	u_char *ptr = ci; /* u_char[4] */	\
						\
	opts = 0;				\
						\
	/* H bit */				\
	if (!(ptr[0] & MPPE_H_BIT))		\
	    opts |= MPPE_OPT_STATEFUL;		\
						\
	/* S,L bits */				\
	if (ptr[3] & MPPE_S_BIT)		\
	    opts |= MPPE_OPT_128;		\
	if (ptr[3] & MPPE_L_BIT)		\
	    opts |= MPPE_OPT_40;		\
						\
	/* M,D,C bits */			\
	if (ptr[3] & MPPE_M_BIT)		\
	    opts |= MPPE_OPT_56;		\
	if (ptr[3] & MPPE_D_BIT)		\
	    opts |= MPPE_OPT_D;			\
	if (ptr[3] & MPPE_C_BIT)		\
	    opts |= MPPE_OPT_MPPC;		\
						\
	/* Other bits */			\
	if (ptr[0] & ~MPPE_H_BIT)		\
	    opts |= MPPE_OPT_UNKNOWN;		\
	if (ptr[1] || ptr[2])			\
	    opts |= MPPE_OPT_UNKNOWN;		\
	if (ptr[3] & ~MPPE_ALL_BITS)		\
	    opts |= MPPE_OPT_UNKNOWN;		\
    } while (/* CONSTCOND */ 0)

/*
 * Definitions for other, as yet unsupported, compression methods.
 */
#define CI_PREDICTOR_1		1	/* config option for Predictor-1 */
#define CILEN_PREDICTOR_1	2	/* length of its config option */
#define CI_PREDICTOR_2		2	/* config option for Predictor-2 */
#define CILEN_PREDICTOR_2	2	/* length of its config option */
#endif /* 0 */
#endif /* __PPP_CCP_H_INCLUDE__ */

