#ifndef __CHAP_H_INCLUDE__
#define __CHAP_H_INCLUDE__

#include <md5.h>

void chap_md5_response(uint8_t id, const uint8_t *chal, size_t chal_len,
		       uint8_t resp[MD5_DIGESTSIZE], const char *secret);

#endif /* __CHAP_H_INCLUDE__ */
