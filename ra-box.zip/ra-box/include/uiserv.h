#ifndef __UISERV_H_INCLUDE__
#define __UISERV_H_INCLUDE__

#ifdef __cplusplus
extern "C" {
#endif

#include <sysdep.h>
#include <module.h>
#include <vector.h>
#include <notify.h>
#include <list.h>

#define UI_DEF_CONF_FILE		"/etc/"CONFIG_PRODUCT_SHORT".conf"

typedef struct _ui_choice_t ui_choice_t;
typedef struct _ui_range_t ui_range_t;
/* schema node */
typedef struct _ui_node_t ui_node_t;
/* object entry */
typedef struct _ui_entry_t ui_entry_t;
typedef struct _ui_table_t ui_table_t;

typedef struct _ui_parser_t {
	const char *oid;
	void (*strconv)(const char *str, void *data);
	unsigned long offset;
} ui_parser_t;

#define UI_TYPE_NONE		0x00
/* used by schema node */
#define UI_TYPE_ATTRIBUTE	0x81
#define UI_TYPE_CLASS		0x82
/* used by object entry */
#define UI_TYPE_INSTANCE	0x83
#define UI_TYPE_VALUE		0x84

typedef struct _ui_schema_t {
	int type;

#define UI_FLAG_REQUIRED	0x01
#define UI_FLAG_SINGLE		0x02
#define UI_FLAG_NETORDER	0x04
#define UI_FLAG_EXTERNAL	0x08	/* no global command */
	unsigned long flags;

#define UI_TYPE_STRING			1
#define UI_TYPE_OCTETS			2
#define UI_TYPE_BOOLEAN			3
#define UI_TYPE_INT			4
#define UI_TYPE_UINT			5
#define UI_TYPE_UINT8			6
#define UI_TYPE_UINT16			7
#define UI_TYPE_UINT32			8
#define UI_TYPE_INT8			9
#define UI_TYPE_INT16			10
#define UI_TYPE_INT32			11
#define UI_TYPE_FLOAT			12
#define UI_TYPE_DOUBLE			13
#define UI_TYPE_ABINARY			14

#define UI_TYPE_CHOICE			16
#define UI_TYPE_RANGE			17

#define UI_TYPE_DATE			21
#define UI_TYPE_IFNAME			22
#define UI_TYPE_IPLABEL			23
#define UI_TYPE_IPADDR			24
#define UI_TYPE_IFID			25
#define UI_TYPE_IPV6ADDR		26
#define UI_TYPE_IPV6PREFIX		27

	int val_type;
	/* for range or choice */
	const char *type_name;
	const char *def_value;

	const char *oid;
	const char *name;
	const char *desc;
} ui_schema_t;

struct _ui_node_t {
	/* XXX: Required by schema registration
	 * Do not delete oid, when schema is not exist, node can appear
	 * there.  This allow schema registration being done in an out
	 * of order way.
	 */
	char *oid;
	notify_head_t oid_chain;
	ui_schema_t *schema;
#define UI_STATE_UNREGISTERED	0x00
#define UI_STATE_REGISTERED	0x01
	unsigned long state;
#define UI_USAGE_SCHEMA			0
#define UI_USAGE_CONF			1
#define UI_USAGE_USER			2
	int usage;
	ui_node_t *parent;
	list_t sibling;

	/* required only when node is an instance */
	list_t children;
};

struct _ui_entry_t {
	int type;
	int valid;
#define UI_VALID_CONF	0x01
#define UI_VALID_USER	0x02
#define UI_VALID_NONE	0x00
#define UI_VALID_ALL	(UI_VALID_CONF | UI_VALID_USER)
	ui_entry_t *parent;	/* parent node */
	char *conf_value;	/* value string */
	char *user_value;	/* value string */
	ui_node_t *node;
	list_t sibling;

	/* used only by instances */
	atomic_t refcnt;
	list_t children;
};

typedef struct _ui_session_t {
	ui_node_t *root_schema;
	ui_entry_t *root_object;

	/* ui tables */
	list_t tables;

	/* set by display commands */
	ui_table_t *result_table;
	const char *sort_column;

	list_t link;
} ui_session_t;

typedef int ui_validate_fn(ui_entry_t *parent, int type,
			   const char *in, const void *data);

/* deal with syntax */
typedef struct _ui_syntax_t {
	int type;
	ui_validate_fn *validate;
	list_t link;
} ui_syntax_t;

#define UI_ERROR_SUCCESS	0x00
#define UI_ERROR_NONVAL		0x01
#define UI_ERROR_MULVAL		0x02
#define UI_ERROR_VALTYPE	0x03
#define UI_ERROR_USAGE		0x04
#define UI_ERROR_USER		0x05
#define UI_ERROR_SYNTAX		0x06
#define UI_ERROR_MEMORY		0x07
#define UI_ERROR_PARAMETER	0x08
#define UI_ERROR_REQUIRED	0x09

/* choice iterater */
typedef int (*ui_iterate_fn)(ui_choice_t *choice, const void *iter, void *data);
const char *ui_get_node_name(void *);
const char *ui_get_node_desc(void *);

struct _ui_choice_t {
	const char *name;
	const void *priv;
	void (*foreach)(ui_choice_t *choice, ui_iterate_fn func, void *data);
	const char *(*get_name)(const void *iter);
	const char *(*get_desc)(const void *iter);
	list_t link;
};

#define UI_RANGE_VALUE_INFINITE		"*"

#define UI_RANGE_SIGN_UNKNOWN		0
#define UI_RANGE_SIGN_PLUS		1
#define UI_RANGE_SIGN_MINUS		2

typedef struct _ui_fromto_t {
	const char *from;
	const char *to;
} ui_fromto_t;

struct _ui_range_t {
	const char *name;
	int type;

	int allow_sign;
	int allow_float;
	int from_to_count;
	ui_fromto_t *from_to_pairs;
	list_t link;
};

typedef struct _ui_argument_t {
	const char *name;
	const char *desc;
	const char *type_name;
	int type;
} ui_argument_t;

typedef struct _ui_command_t {
	const char *name;
	const char *desc;
	const char *oid;
	int type;
#define UI_CMD_SINGLE_CLASS	0x0001
#define UI_CMD_MULTI_CLASS	0x0002
#define UI_CMD_CLASS		(UI_CMD_SINGLE_CLASS | UI_CMD_MULTI_CLASS)
#define UI_CMD_SINGLE_ATTR	0x0004
#define UI_CMD_MULTI_ATTR	0x0008
#define UI_CMD_ATTR		(UI_CMD_SINGLE_ATTR | UI_CMD_MULTI_ATTR)
#define UI_CMD_SCHEMA_NODE	(UI_CMD_CLASS | UI_CMD_ATTR)
#define UI_CMD_SINGLE_INST	0x0010
#define UI_CMD_MULTI_INST	0x0020
#define UI_CMD_INST		(UI_CMD_SINGLE_INST | UI_CMD_MULTI_INST)
#define UI_CMD_SINGLE_VALUE	0x0040
#define UI_CMD_MULTI_VALUE	0x0080
#define UI_CMD_VALUE		(UI_CMD_SINGLE_VALUE | UI_CMD_MULTI_VALUE)
#define UI_CMD_OBJECT_ENTRY	(UI_CMD_INST | UI_CMD_VALUE)

#define UI_CMD_MULTI_SCHENA	(UI_CMD_MULTI_CLASS | UI_CMD_MULTI_ATTR)
#define UI_CMD_MULTI_OBJECT	(UI_CMD_MULTI_INST | UI_CMD_MULTI_VALUE)
	ui_argument_t *args;
	int n_args;
	list_t link;
	/* ctx:
	 * UI_CMD_MULTI_OBJECT - ui_entry_t
	 * UI_CMD_MULTI_SCHENA - ui_node_t
	 */
	int (*execute_fn)(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
} ui_command_t;

struct _ui_table_t {
	char *name;		/* list file name */
	vector_t *title;	/* title */
	vector_t *table;	/* name / value table, index=0 means header */
	list_t list;
};

/* input service */
typedef struct _ui_service_t {
	const char *name;
	const char *desc;
	int (*start)(void);
	void (*stop)(void);
	void (*print_format)(ui_session_t *sess, const char *fmt, ...);
	void (*print_table)(ui_session_t *sess, ui_table_t *table);
} ui_service_t;

#ifdef CONFIG_DEBUG
#define OBJ_UI_TABLE_TITLE(table, i)
#define OBJ_UI_TABLE_VALUE(table, obj, i, gc)
#else
#define OBJ_UI_TABLE_TITLE(table, col)			\
	do {						\
		ui_add_title(table, col, "R");		\
		ui_add_title(table, col+1, "G");	\
	} while (0)

#define OBJ_UI_TABLE_VALUE(table, obj, row, gc)		\
	do {						\
		char buf[25] = "";			\
		snprintf(buf, sizeof(buf), "%d",	\
			 atomic_read(&obj->refcnt));	\
		ui_add_value(table, "R", row, buf);	\
		ui_add_value(table, "G", row, gc);	\
	} while (0)
#endif

/* ============================================================ *
 * input function
 * ============================================================ */
int ui_register_service(ui_service_t *input);
void ui_unregister_service(ui_service_t *input);
int ui_begin_session(ui_session_t *session);
void ui_end_session(ui_session_t *session);

/* ============================================================ *
 * choice function
 * ============================================================ */
int ui_register_choice(ui_choice_t *choice);
void ui_unregister_choice(ui_choice_t *choice);
ui_choice_t *ui_choice_by_name(const char *name);
void ui_foreach_choice(ui_choice_t *choice, ui_iterate_fn func, void *data);

/* ============================================================ *
 * range function
 * ============================================================ */
int ui_register_range(ui_range_t *range);
void ui_unregister_range(ui_range_t *range);
ui_range_t *ui_range_by_name(const char *name);
void ui_foreach_range(ui_range_t *range, ui_iterate_fn func, void *data);

/* ============================================================ *
 * command function
 * ============================================================ */
int ui_register_command(ui_command_t *command);
void ui_unregister_command(ui_command_t *command);
ui_command_t *ui_command_by_flag(const char *oid, const char *name, int flags);
ui_command_t *ui_command_by_name(const char *oid, const char *name);

/* ============================================================ *
 * schema function
 * ============================================================ */
ui_node_t *ui_register_node(ui_schema_t *schema);
void ui_unregister_node(ui_schema_t *schema);
ui_schema_t *ui_schema_by_oid(const char *oid);
int ui_register_schema(ui_schema_t *schema);
void ui_unregister_schema(ui_schema_t *schema);
void ui_dump_schema(void);
ui_node_t *ui_node_by_name(ui_node_t *node, const char *name);
ui_node_t *ui_attrib_iterate(const char *oid, ui_node_t *itor, 
			     unsigned char forward, int filter);
ui_node_t *ui_class_iterate(const char *oid, ui_node_t *itor,
			    unsigned char forward);
ui_node_t *ui_node_iterate(const char *oid, ui_node_t *iter,
			   unsigned char forward);
ui_command_t *ui_command_iterate_schema(ui_node_t *node,
					ui_command_t *iter);
ui_command_t *ui_command_iterate_object(ui_node_t *node,
					ui_command_t *iter);

const char *ui_node_type_name(int type);
int ui_node_entry_type(ui_node_t *node);

/* ============================================================ *
 * entry function
 * ============================================================ */
void ui_conf_dump(ui_entry_t *);
void ui_conf_dump_root(void);
void ui_set_conf_file(const char *file);

ui_entry_t *ui_entry_lookup_conf(ui_entry_t *inst, int type,
				 const char *name, const char *value);
ui_entry_t *ui_entry_create_user(ui_entry_t *inst, int type,
				 const char *name, const char *value);
#define ui_inst_lookup_conf(p, n, v)	ui_entry_lookup_conf(p, UI_TYPE_INSTANCE, n, v)
#define ui_inst_create_user(p, n, v)	ui_entry_create_user(p, UI_TYPE_INSTANCE, n, v)
#define ui_value_create_user(p, n, v)	ui_entry_create_user(p, UI_TYPE_VALUE, n, v)

int ui_load_single_values(ui_entry_t *, void *, ui_parser_t *);

void ui_inst_delete_conf(ui_entry_t *inst);
void ui_inst_delete_user(ui_entry_t *inst);
void ui_value_delete_user(ui_entry_t *value);

ui_entry_t *ui_entry_by_conf(ui_entry_t *inst, int type,
			     const char *name, const char *value);
ui_entry_t *ui_entry_by_user(ui_entry_t *inst, int type,
			     const char *name, const char *value);
ui_entry_t *ui_entry_get_by_conf(ui_entry_t *inst, int type,
				 const char *name, const char *value);
#define ui_inst_by_conf(i, n, v)	ui_entry_by_conf(i, UI_TYPE_INSTANCE, n, v)
#define ui_value_by_conf(i, n, v)	ui_entry_by_conf(i, UI_TYPE_VALUE, n, v)
#define ui_inst_by_user(i, n, v)	ui_entry_by_user(i, UI_TYPE_INSTANCE, n, v)
#define ui_value_by_user(i, n, v)	ui_entry_by_user(i, UI_TYPE_VALUE, n, v)
#define ui_inst_get_by_conf(i, n, v)	ui_entry_get_by_conf(i, UI_TYPE_INSTANCE, n, v)

ui_entry_t *ui_entry_iterate(ui_entry_t *parent, int type, int valid,
			     const char *name, ui_entry_t *iter);
ui_entry_t *ui_multiple_entry_iterate(ui_entry_t *ins, int type, int valid,
				      const char *name, ui_entry_t *iter);
#define ui_multiple_entry_iterate_user(p, t, n, i)	\
	ui_multiple_entry_iterate(p, t, UI_VALID_USER, n, i)
#define ui_inst_iterate(p, v, n, i)		\
	ui_entry_iterate(p, UI_TYPE_INSTANCE, v, n, i)
#define ui_value_iterate(p, v, n, i)		\
	ui_entry_iterate(p, UI_TYPE_VALUE, v, n, i)
#define ui_inst_iterate_conf(p, n, i)		\
	ui_inst_iterate(p, UI_VALID_CONF, n, i)
#define ui_inst_iterate_user(p, n, i)		\
	ui_inst_iterate(p, UI_VALID_USER, n, i)
#define ui_value_iterate_conf(p, n, i)		\
	ui_value_iterate(p, UI_VALID_CONF, n, i)
#define ui_value_iterate_user(p, n, i)		\
	ui_value_iterate(p, UI_VALID_USER, n, i)

#define ui_minst_iterate(p, v, n, i)		\
	ui_multiple_entry_iterate(p, UI_TYPE_INSTANCE, v, n, i)
#define ui_mvalue_iterate(p, v, n, i)		\
	ui_multiple_entry_iterate(p, UI_TYPE_VALUE, v, n, i)
#define ui_minst_iterate_conf(p, n, i)		\
	ui_minst_iterate(p, UI_VALID_CONF, n, i)
#define ui_minst_iterate_user(p, n, i)		\
	ui_minst_iterate(p, UI_VALID_USER, n, i)
#define ui_mvalue_iterate_conf(p, n, i)		\
	ui_mvalue_iterate(p, UI_VALID_CONF, n, i)
#define ui_mvalue_iterate_user(p, n, i)		\
	ui_mvalue_iterate(p, UI_VALID_USER, n, i)

const char *ui_get_entry_name(ui_entry_t *entry);
int ui_set_user_value(ui_entry_t *val, const char *value);
int ui_set_conf_value(ui_entry_t *val, const char *value);
const char *ui_get_user_value(ui_entry_t *val);
const char *ui_get_conf_value(ui_entry_t *val);
const char *ui_get_schema_value(ui_node_t *val);

static inline ui_entry_t *ui_inst_get(ui_entry_t *entry)
{
	if (entry->type == UI_TYPE_INSTANCE)
		atomic_inc(&entry->refcnt);
	return entry;
}
#define ui_inst_hold(i)		(void)ui_inst_get(i);

int ui_is_multiple_entry(ui_entry_t *);
int ui_is_multiple_node(ui_node_t *);

#define UI_ORDER_HIGHEST	4
#define UI_ORDER_HIGHER		3
#define UI_ORDER_LOWER		2
#define UI_ORDER_LOWEST		1

void ui_inst_choice_foreach(ui_choice_t *choice,
			    ui_iterate_fn func, void *data);
const char *ui_inst_choice_name(const void *iter);
const char *ui_inst_choice_desc(const void *iter);

int ui_get_entry_order_conf(ui_entry_t *entry);
int ui_get_entry_order_user(ui_entry_t *entry);
int ui_set_entry_lowest(ui_entry_t *);
int ui_set_entry_highest(ui_entry_t *);
int ui_set_entry_lower(ui_entry_t *);
int ui_set_entry_higher(ui_entry_t *);

/* ============================================================ *
 * syntax operation
 * ============================================================ */
int ui_validate_syntax(ui_entry_t *parent, int type, const char *in,
		       const void *data);
ui_syntax_t *ui_syntax_by_type(int type);
void ui_register_syntax(ui_syntax_t *syntax);
void ui_unregister_syntax(ui_syntax_t *syntax);

/* ============================================================ *
 * table operation
 * ============================================================ */
ui_table_t *ui_table_create(ui_session_t *sess, const char *name);
void ui_table_delete(ui_table_t *list);
ui_table_t *ui_table_by_name(ui_session_t *sess, const char *name);

typedef int (*ui_compare_fn)(const void *elem1, const void *elem2);

void ui_qsort_table(ui_table_t *list, const char *title,
		    ui_compare_fn compare);

int ui_table_rows(ui_table_t *list);
int ui_table_columns(ui_table_t *list);

const char *ui_value_by_title(ui_table_t *list, const char *title, int current);
const char *ui_value_by_index(ui_table_t *list, int index, int current);
/* get value by other value as reference */
const char *ui_value_by_refer(ui_session_t *sess,
			      const char *list, const char *locate_title,
			      const char *locate_value, const char *title);

int ui_column_by_title(ui_table_t *list, const char *title);
int ui_row_by_value(ui_table_t *list, const char *title, const char *value);

/* set value using its title / row index, will not extend list */
void ui_set_value(ui_table_t *list, const char *title,
		  int current, const char *value);
/* set value using its title / row index, will extend list */
void ui_add_value(ui_table_t *list, const char *title,
		  int index, const char *value);
void ui_set_title(ui_table_t *list, int index, const char *title);
void ui_add_title(ui_table_t *list, int index, const char *title);

/* set value using its title index / row index */
void ui_index_set_value(ui_table_t *list, int index,
			int current, const char *value);
/* set value by other value as reference */
void ui_refer_set_value(ui_session_t *sess,
			const char *list, const char *locate_title,
			const char *locate_value, const char *title,
			const char *value);

/* ============================================================ *
 * service operation
 * ============================================================ */
int ui_user_start(void);
void ui_user_stop(void);
int ui_conf_start(void);
void ui_conf_stop(void);

#ifdef __cplusplus
}
#endif

#endif
