#ifndef __MD4_H_INCLUDE__
#define __MD4_H_INCLUDE__

#include <sysdep.h>

/* MD4 context */
typedef struct _md4_t {
#define MD4_BLOCKSIZE	64	/* MD4 block size */
#define MD4_DIGESTSIZE	16	/* MD4 digest size */
	uint32_t buffer[4];	/* Holds 4-word result of MD computation */
	uint8_t count[8];	/* Number of bits processed so far */
	unsigned int done;	/* Nonzero means MD computation finished */
} md4_t;

void md4_init(md4_t *context);
void md4_update(md4_t *context, const uint8_t *data, size_t count);
void md4_final(md4_t *context, uint8_t *digest);
void md4_print(md4_t *context);

#endif /* __MD4_H_INCLUDE__ */
