#ifndef __NET_RTNL_H_INCLUDE__
#define __NET_RTNL_H_INCLUDE__

#include <sysdep.h>
#include <net_skb.h>
#include <linux/netlink.h>

#define RTNL_SERVICE_NAME	"rtnl"

typedef int (*rtnl_handle_t)(struct nlmsghdr *, void *);

int rtnl_register_handler(int protocol, int msgtype,
			  rtnl_handle_t doit);
int rtnl_unregister_handler(int protocol, int msgtype);
void rtnl_unregister_all_handlers(int protocol);
int rtnl_wild_dump(int family, int type);

#ifdef WIN32
typedef int (*rtnl_doit_t)(struct nlmsghdr *, void *);
typedef int (*rtnl_dumpit_t)(msgbuf_t *, netlink_callback_t *);

int rtnl_register_server(int protocol, int msgtype,
			 rtnl_doit_t doit,
			 rtnl_dumpit_t dumpit);
int rtnl_unregister_server(int protocol, int msgtype);
void rtnl_unregister_all_servers(int protocol);
#endif

#endif /* __NET_RTNL_H_INCLUDE__ */
