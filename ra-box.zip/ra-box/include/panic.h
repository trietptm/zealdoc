#ifndef __PANIC_H_INCLUDE__
#define __PANIC_H_INCLUDE__

void __panic(const char *file, int line);

#define panic()		__panic(__FILE__, __LINE__)
#define BUG_ON(expr)	do { if (expr) panic(); } while (0)
#define BUG()		panic()

#endif /* __PANIC_H_INCLUDE__ */

