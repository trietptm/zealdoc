#ifndef __HASH_H_INCLUDE__
#define __HASH_H_INCLUDE__

#ifndef DEFAULT_HASH_SIZE
# define DEFAULT_HASH_SIZE	9973
#endif

#ifndef KEY_HASH_SIZE
# define KEY_HASH_SIZE		1009
#endif

/* The purpose of the hashed_object_t struct is to not match anything else. */
typedef struct _hashed_object_t {
	int foo;
} hashed_object_t;

typedef int (*hash_iterate_cb)(const void *, unsigned, void *);
typedef int (*hash_compare_cb)(const void *, const void *, size_t);
typedef unsigned (*hash_generate_cb)(const void *, unsigned, unsigned);

typedef struct _hash_bucket_t {
	struct _hash_bucket_t *next;
	const unsigned char *name;
	unsigned len;
	hashed_object_t *value;
} hash_bucket_t;

typedef struct _hash_table_t {
	unsigned hash_count;
	hash_compare_cb cmp;
	hash_generate_cb do_hash;

	/* This must remain the last entry in this table. */
	hash_bucket_t *buckets[1];
} hash_table_t;

typedef struct _hash_t {
	struct _hash_t *next;
	const char *name;
	hash_table_t *hash;
} hash_t;

#define HASH_FUNCTIONS_DECL(name, bufarg, type, hashtype)		      \
void name##_hash_add(hashtype *, bufarg, unsigned, type *);		      \
void name##_hash_delete(hashtype *, bufarg, unsigned);			      \
int name##_hash_lookup(type **, hashtype *, bufarg, unsigned);		      \
const char * name##_hash_report(hashtype *);				      \
int name##_hash_foreach(hashtype *, hash_iterate_cb);			      \
int name##_hash_new(hashtype **, unsigned);				      \
void name##_hash_table_free(hashtype **);

#define HASH_FUNCTIONS(name, bufarg, type, hashtype, hasher)		      \
void name##_hash_add(hashtype *table,					      \
		     bufarg buf, unsigned len, type *ptr)		      \
{									      \
	hash_add((hash_table_t *)table, buf,				      \
		 len, (hashed_object_t *)ptr);				      \
}									      \
									      \
void name##_hash_delete(hashtype *table, bufarg buf, unsigned len)	      \
{									      \
	hash_delete((hash_table_t *)table, buf, len);			      \
}									      \
									      \
int name##_hash_lookup(type **ptr, hashtype *table,			      \
		       bufarg buf, unsigned len)			      \
{									      \
	return hash_lookup((hashed_object_t **)ptr,			      \
			   (hash_table_t *)table, buf, len);		      \
}									      \
									      \
const char * name##_hash_report(hashtype *table)			      \
{									      \
	return hash_report((hash_table_t *)table);			      \
}									      \
									      \
int name##_hash_foreach(hashtype *table, hash_iterate_cb func)		      \
{									      \
	return hash_foreach((hash_table_t *)table, func);		      \
}									      \
									      \
int name##_hash_new(hashtype **tp, unsigned c)				      \
{									      \
	return hash_new((hash_table_t **)tp, c, hasher);		      \
}									      \
									      \
void name##_hash_table_free(hashtype **table)				      \
{									      \
	hash_table_free((hash_table_t **)table);			      \
}

int hash_table_new(hash_table_t **, unsigned);
void hash_table_free(hash_table_t **);
hash_bucket_t *hash_bucket_new(void);
void hash_bucket_free(hash_bucket_t *);

/* hash_generate_cb functions */
unsigned do_string_hash(const void *, unsigned, unsigned);
unsigned do_number_hash(const void *, unsigned, unsigned);
unsigned do_ip4_hash(const void *, unsigned, unsigned);
unsigned do_id_hash(const void *, unsigned, unsigned);
unsigned do_case_hash(const void *, unsigned, unsigned);

const char *hash_report(hash_table_t *);
int hash_new(hash_table_t **, unsigned, hash_generate_cb);
void hash_add(hash_table_t *, const void *,
	      unsigned, hashed_object_t *);
void hash_delete(hash_table_t *, const void *, unsigned);
int hash_lookup(hashed_object_t **, hash_table_t *,
		const void *, unsigned);
int hash_foreach(hash_table_t *, hash_iterate_cb);

int casecmp(const void *s, const void *t, size_t len);

#endif /* __HASH_H_INCLUDE__ */
