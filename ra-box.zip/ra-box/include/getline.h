#ifndef __UI_LINE_H_INCLUDE__
#define __UI_LINE_H_INCLUDE__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

#define GETLINE_NO_LIMIT -1

int getline(char **_lineptr, size_t *_n, FILE *_stream);
int getline_safe(char **_lineptr, size_t *_n, FILE *_stream, int limit);
int getstr(char **_lineptr, size_t *_n, FILE *_stream,
	   char _terminator, int _offset, int limit);

#ifdef __cplusplus
}
#endif

#endif /* __UI_LINE_H_INCLUDE__ */
