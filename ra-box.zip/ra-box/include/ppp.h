#ifndef __PPP_H_INCLUDE__
#define __PPP_H_INCLUDE__

#include <sysdep.h>
#include <notify.h>
#include <dfastm.h>
#include <netsvc.h>
#include <uiserv.h>
#include <list.h>
#include <service.h>
#include <net/ppp_defs.h>

#ifndef PPP_EAP
#define PPP_EAP		0xc227
#endif

#define MAXNAMELEN	256	/* max length of hostname or name for auth */

#define PPP_SERVICE_NAME	"ppp"

typedef struct _ppp_phase_t ppp_phase_t;
typedef struct _ppp_profile_t ppp_profile_t;
typedef struct _ppp_channel_t ppp_channel_t;
typedef struct _ppp_unix_t ppp_unix_t;

#include <ppp_auth.h>

/* This struct contains pointers to a set of procedures for
 * doing operations on a "channel".  A channel provides a way
 * to send and receive PPP packets - the canonical example is
 * a serial port device in PPP line discipline.
 */
struct _ppp_channel_t {
	/* channel name */
	const char *name;
	const char *desc;

	/* make outgoing PPP message */
	msgbuf_t *(*make_message)(ppp_phase_t *ctx);
	/* send outgoing PPP message */
	int (*send_message)(ppp_phase_t *ctx, msgbuf_t *msg);

	/* make PPP interface up */
	int (*open_device)(ppp_phase_t *ctx);
	/* make PPP interface down, data is returned by open_device */
	void (*close_device)(ppp_phase_t *ctx);

	/* control (set/get) supported PPP options */
	int (*set_recv_option)(ppp_phase_t *ctx, uint16_t protocol,
			       uint8_t option, void *arg);
	int (*get_recv_option)(ppp_phase_t *ctx, uint16_t protocol,
			       uint8_t option, void *arg);
	int (*set_send_option)(ppp_phase_t *ctx, uint16_t protocol,
			       uint8_t option, void *arg);
	int (*get_send_option)(ppp_phase_t *ctx, uint16_t protocol,
			       uint8_t option, void *arg);

	/* NAC frontend */
	/* start NAC frontend */
	int (*start_server)(ppp_profile_t *prof, nac_t *nac);
	/* stop NAC frontend */
	void (*stop_server)(ppp_profile_t *prof, nac_t *nac);
	/* open NAC client */
	void *(*open_client)(ppp_phase_t *ctx, nac_client_t *nac,
			     nac_param_t param);
	/* close NAC client, data is returned by open_client */
	void (*close_client)(ppp_phase_t *ctx, nac_client_t *nac, void *data);

	void (*nac_advance)(ppp_phase_t *phase, void *data);
	void (*nac_retreat)(ppp_phase_t *phase, void *data);
	list_t link;
};

struct _ppp_profile_t {
	ui_entry_t *cs;
	const char *name;

	int restart_timer;	/* restart timer */
	int max_terminate;	/* Max-Terminate */
	int max_configure;	/* Max-Configure */
	int max_failure;	/* Max-Failure */
	/* looped-back link can be worked out by LCP Magic-Number */
	int max_loopback;
	int listen_time;
	int channel_timeout;	/* wait lower timer */
	int request_timeout;	/* wait request timer */

	/* XXX: Hack on Pool only Backend
	 * this is not a good idea, backend should support auth-types,
	 * but since we only have an IP pool as local backend, we put
	 * flag here to allow PPP performing authentication by itself
	 * Note that PPP must call ppp_peer_updated when !auth_spoofing
	 * where a NAC request will be generated
	 */
	int auth_spoofing;
	int auth_mutual;
	/* XXX: Force for Server or Mutual Authentication enabled Client
	 * when PPP server or mutual authentication enabled client's auth-type
	 * was rejected, link will fail if auth_force is enabled
	 */
	int auth_force;

	ppp_channel_t *channel;

	atomic_t refcnt;
	
	const char *auth_domain;
	const char *auth_user;
	const char *auth_secret;
	list_t link;
};

struct _ppp_unix_t {
	int chan_fd;
	int chan_id;

	const char *name;
	uint32_t xaccm[8];		/* extended transmit ACCM */

	/* channel allowed MTU for PPP messages */
	int chan_mtu;
	net_device_t *dev;
};

#if 0
	uint32_t address;
	uint32_t netmask;
	uint32_t dstaddr;
	nic_t *nic;
#endif

/* ============================================================ *
 * phase operations
 * ============================================================ */
ppp_phase_t *ppp_phase_get(ppp_phase_t *phase);
void ppp_phase_put(ppp_phase_t *phase);
int ppp_phase_unitid(ppp_phase_t *phase);
int ppp_phase_unitfd(ppp_phase_t *phase);
int ppp_phase_bind(ppp_phase_t *phase, net_device_t *dev);
void ppp_phase_unbind(ppp_phase_t *phase);

/* usage: channel APIs
 * channel may have its own state machine
 * call ppp_channel_up when channel is ready to carry PPP packets
 * call ppp_channel_down when channel cannot carry PPP packets any more
 * call ppp_set_peer_host when channel know remote name of the peer
 */
/* terminating by channel (don't send LCP terminate) */
void ppp_channel_down(ppp_phase_t *ctx);
/* opening by channel (means lower ready), called by channel */
void ppp_channel_up(ppp_phase_t *ctx);
void ppp_set_peer_host(ppp_phase_t *phase, const char *rname);

/* ============================================================ *
 * profile operations
 * ============================================================ */
static inline ppp_profile_t *ppp_profile_get(ppp_profile_t *profile)
{
	atomic_inc(&profile->refcnt);
	return profile;
}
static inline void ppp_profile_put(ppp_profile_t *profile)
{
	atomic_dec(&profile->refcnt);
}
void ppp_profile_free(ppp_profile_t *prof);

/* ============================================================ *
 * channel operations
 * ============================================================ */
int ppp_register_channel(ppp_channel_t *chan);
void ppp_unregister_channel(ppp_channel_t *chan);
ppp_channel_t *ppp_find_channel(const char *name);

int ppp_channel_set_recv(ppp_phase_t *ctx, uint16_t protocol,
			 uint8_t option, void *arg);
int ppp_channel_get_recv(ppp_phase_t *ctx, uint16_t protocol,
			 uint8_t option, void *arg);
int ppp_channel_set_send(ppp_phase_t *ctx, uint16_t protocol,
		         uint8_t option, void *arg);
int ppp_channel_get_send(ppp_phase_t *ctx, uint16_t protocol,
		         uint8_t option, void *arg);

msgbuf_t *ppp_channel_message(ppp_phase_t *ctx);
int ppp_channel_send(ppp_phase_t *ctx, msgbuf_t *msg, uint16_t proto);
int ppp_channel_recv(ppp_phase_t *ctx, msgbuf_t *msg);

/* ============================================================ *
 * generic channel operations
 * ============================================================ */
int ppp_generic_establish(ppp_unix_t *ctx, int fd);
int ppp_generic_disestablish(ppp_unix_t *ctx);
int ppp_generic_set_recv(ppp_unix_t *ctx, uint16_t protocol,
			 uint8_t option_type, void *arg);
int ppp_generic_get_recv(ppp_unix_t *ctx, uint16_t protocol,
			 uint8_t option_type, void *arg);
int ppp_generic_set_send(ppp_unix_t *ctx, uint16_t protocol,
			 uint8_t option_type, void *arg);
int ppp_generic_get_send(ppp_unix_t *ctx, uint16_t protocol,
			 uint8_t option_type, void *arg);
int ppp_phase_set_send(ppp_phase_t *phase, uint16_t protocol,
		       uint8_t option_type, void *arg);
int ppp_phase_set_recv(ppp_phase_t *phase, uint16_t protocol,
		       uint8_t option_type, void *arg);

#endif /* __PPP_H_INCLUDE__ */
