#ifndef __L2TP_H_INCLUDE__
#define __L2TP_H_INCLUDE__

#ifdef __cplusplus
extern "C" {
#endif

#include <sysdep.h>
#include <list.h>
#include <md5.h>
#include <netsvc.h>

typedef struct _l2tp_xprt_t l2tp_xprt_t;

typedef struct _l2tp_data_xprt_t l2tp_data_xprt_t;
typedef struct _l2tp_data_sess_t l2tp_data_sess_t;

typedef struct _l2tp_tunnel_t l2tp_tunnel_t;
typedef struct _l2tp_session_t l2tp_session_t;
typedef struct _l2tp_profile_t l2tp_profile_t;

#define L2TP_SERVICE_NAME	"l2tp"
#define L2TP_SERVICE_DESC	"Layer-2 tunneling protocol"

#define L2TP_PORT		1701

#define L2TP_VERSION		0x0002
#define L2F_VERSION		0x0001

#define L2TP_VECTOR_LEN		MD5_DIGESTSIZE
#define L2TP_STRING_LEN		120

#define L2TP_NOTIFY_TUNNEL_OPEN		0x01
#define L2TP_NOTIFY_TUNNEL_CLOSE	0x02
#define L2TP_NOTIFY_TUNNEL_UP		0x03
#define L2TP_NOTIFY_TUNNEL_GOING_DOWN	0x04
#define L2TP_NOTIFY_TUNNEL_DOWN		0x05
#define L2TP_NOTIFY_SESSION_OPEN	0x06
#define L2TP_NOTIFY_SESSION_CLOSE	0x07
#define L2TP_NOTIFY_SESSION_UP		0x08
#define L2TP_NOTIFY_SESSION_GOING_DOWN	0x09
#define L2TP_NOTIFY_SESSION_DOWN	0x10

/* ============================================================ *
 * result & error codes
 * ============================================================ */
#define L2TP_RESULT_RESV		0
#define L2TP_RESULT_CLOSE		1
#define L2TP_RESULT_ERROR		2

/* StopCCN result codes */
#define L2TP_RESULT_EEXIST		3
#define L2TP_RESULT_EAUTHZ		4
#define L2TP_RESULT_EPROTO		5
#define L2TP_RESULT_EDOWN		6
#define L2TP_RESULT_EFINSM		7
#define L2TP_RESULT_STOPCCN_COUNT	8

/* CDN result codes */
#define L2TP_RESULT_EADMIN	3
#define L2TP_RESULT_ETNORES	4
#define L2TP_RESULT_EPNORES	5
#define L2TP_RESULT_EINVAL	6
#define L2TP_RESULT_ECARRIER	7
#define L2TP_RESULT_EBUSY	8
#define L2TP_RESULT_ETONE	9
#define L2TP_RESULT_ETIMEOUT	10
#define L2TP_RESULT_EFRAME	11
#define L2TP_RESULT_CDN_COUNT	12

#define L2TP_ERROR_NOERR	0
#define L2TP_ERROR_EFAULT	2
#define L2TP_ERROR_ERANGE	3
#define L2TP_ERROR_ENOMEM	4
#define L2TP_ERROR_EINVAL	5
#define L2TP_ERROR_EVNDOR	6
#define L2TP_ERROR_EBUSY	7
#define L2TP_ERROR_EMAVP	8

/* overall configuration */
typedef struct _l2tp_config_t {
	int wait_timeout;
	uint16_t protocol_ver;			/* Protocol Version */
#define L2TP_PROTOCOL_VER	0x0100
	uint16_t firmware_rev;			/* Firmware Revision */
#define L2TP_FIRMWARE_REV	0x0100		/* major 1, minor 0 */

	uint32_t framing_cap;			/* Framing Capabilities */
#define L2TP_FRAMING_ASYNC		0x00000002
#define L2TP_FRAMING_SYNC		0x00000001

	uint32_t bearer_cap;			/* Bearer Capabilities */
#define L2TP_BEARER_ANALOG		0x00000002
#define L2TP_BEARER_DIGITAL		0x00000001

	uint16_t receive_ws;			/* Receive Windows Size */
#define L2TP_MIN_RECEIVE_WS		1
#define L2TP_MAX_RECEIVE_WS		16

	uint16_t max_retrans;
	uint16_t retrans_cap;
/* retransmission cap MUST be no less than 8 seconds */

	uint16_t hello_interval;
} l2tp_config_t;

/* control connection configuration */
struct _l2tp_profile_t {
	const char *name;

	int mode;

	int single_shot;

	/* if challenge required */
	char *secret;
	int reorder_timeout;
	int auth_mode;

	/* flags */
	int hide_avps;		/* hide AVPs */
	int seq_required;

	ui_entry_t *cs;

	uint32_t minimum_bps;	/* Minimum BPS */
	uint32_t maximum_bps;	/* Maximum BPS */

	/* used for outgoing call */
	uint32_t addr;
	uint16_t port;

	atomic_t refcnt;

	list_t link;
};

/* tunnel mode */
#define L2TP_MODE_LNS		0x01
#define L2TP_MODE_LAC		0x02

/* call type */
#define L2TP_OUTGOING		0x01
#define L2TP_INCOMING		0x02

/* tunnel transport routines */
/* ============================================================ *
 * data path operations
 * ============================================================ */
typedef struct _l2tp_data_t {
	const char *name;

	/* API to link PPPoX / PPPoL2TP kernel data path */
	l2tp_data_xprt_t *(*open_tunnel)(int sock, int mode,
					 uint32_t peer_addr,
					 uint16_t peer_port,
					 uint16_t this_tid);
	void (*close_tunnel)(l2tp_data_xprt_t *);
	int (*connect_tunnel)(l2tp_data_xprt_t *, uint16_t peer_port,
			      uint16_t peer_tid);
	l2tp_data_sess_t *(*session_open)(ppp_phase_t *phase,
					  uint16_t this_sid,
					  uint16_t peer_sid,
					  int seq_enabled,
					  int reorder_timeout,
					  l2tp_data_xprt_t *data_xprt);
	void (*session_close)(l2tp_data_sess_t *session_data);
	int (*session_send)(l2tp_data_sess_t *session_data, msgbuf_t *);

	int (*set_recv_option)(l2tp_session_t *, uint16_t protocol,
			       uint8_t option_type, void *arg);
	int (*get_recv_option)(l2tp_session_t *, uint16_t protocol,
			       uint8_t option_type, void *arg);
	int (*set_send_option)(l2tp_session_t *, uint16_t protocol,
			       uint8_t option_type, void *arg);
	int (*get_send_option)(l2tp_session_t *, uint16_t protocol,
			       uint8_t option_type, void *arg);
} l2tp_data_t;

struct _l2tp_session_t {
	char *name;

	atomic_t refcnt;
	list_t link;
	int closing : 1;

	int side;
	int mode;

	unsigned long flags;
	int reorder_timeout;

	stm_instance_t *fsmi;		/* state machine instance */

	uint32_t call_ser_no;		/* Call Serial Number */

	uint32_t peer_addr;
	uint16_t peer_port;
	uint32_t this_addr;
	uint16_t this_port;

#define L2TP_SESSION_ID_NONE	0
	uint16_t peer_sid;		/* peer's session identifier */
	uint16_t this_sid;		/* local's session identifier */

	uint16_t this_tid;
	uint16_t peer_tid;

	uint16_t mru;
	uint16_t mtu;

	int seq_enabled : 1;

	uint16_t Nr;
	uint16_t Ns;

	uint16_t result;
	uint16_t error;

	int32_t this_phys_channel;		/* Physical Channel ID */
	int32_t peer_phys_channel;		/* Physical Channel ID */

	char sub_address[L2TP_STRING_LEN];	/* Sub Address */
	char called_number[L2TP_STRING_LEN];	/* Called Number */
	char calling_number[L2TP_STRING_LEN];	/* Calling Number */

	uint32_t bearer_type;			/* Bearer Type */
	uint32_t framing_type;			/* Framing Type */

	uint32_t tx_speed;			/* Tx Connect Speed */
	uint32_t rx_speed;			/* Rx Connect Speed */
#define L2TP_DEF_CONNECT_SPEED		1000000

	char priv_group[L2TP_STRING_LEN];	/* Private Group ID */

	/*===== interface between L2TP and transports =====*/
	l2tp_xprt_t *xprt;
	l2tp_data_sess_t *data_path;
	/* which NIC we are sending and receiving through? */
	nic_t *nic;

	/*===== interface between L2TP and PPP =====*/
	/* XXX: Referrence of PPP Phase
	 * no nic_t is referrenced, because PPP proxy may not contain a
	 * valid nic_t
	 */
	ppp_phase_t *ppp_phase;
	/* ensure no DOWN event sending to PPP before UP event*/
	int this_layer_up;

	/*===== interface between L2TP and RADIUS =====*/
	nac_client_t *nac_client;
};

/* call param, used as nic_param_t for NETDEV_FRONT */
typedef struct _l2tp_call_t {
	uint32_t peer_addr;
	uint16_t peer_port;
	uint16_t peer_sid;
	uint16_t this_tid;
	int mode;
	int side;
} l2tp_call_t;

int l2tp_register_data_path(l2tp_data_t *data);
void l2tp_unregister_data_path(l2tp_data_t *data);
l2tp_data_t *l2tp_get_data_path(void);

/* APIs for PPPoL2TP */
#define L2TP_HEADER_CTRL_LEN		12
#define L2TP_HEADER_MAX_DATA_LEN	14
#define L2TP_HEADER_MIN_DATA_LEN	6

/* message types */
/* control connection management */
#define L2TP_MESSAGE_ZLB		0
#define L2TP_MESSAGE_SCCRQ		1
#define L2TP_MESSAGE_SCCRP		2
#define L2TP_MESSAGE_SCCCN		3
#define L2TP_MESSAGE_STOPCCN		4
#define L2TP_MESSAGE_HELLO		6

/* call management */
#define L2TP_MESSAGE_OCRQ		7
#define L2TP_MESSAGE_OCRP		8
#define L2TP_MESSAGE_OCCN		9
#define L2TP_MESSAGE_ICRQ		10
#define L2TP_MESSAGE_ICRP		11
#define L2TP_MESSAGE_ICCN		12
#define L2TP_MESSAGE_CDN		14

/* error reporting */
#define L2TP_MESSAGE_WEN		15

/* ppp session control */
#define L2TP_MESSAGE_SLI		16

#define L2TP_MESSAGE_DATA		0xffff

#define L2TP_MESSAGE_NUM_TYPES		17
#define L2TP_MESSAGE_ILLEGAL_TYPE	(uint16_t)(-1)

msgbuf_t *l2tp_make_message(int len, uint16_t type,
			    uint16_t tid, uint16_t sid);
l2tp_session_t *l2tp_session_up(l2tp_call_t *call,
				ppp_phase_t *ctx, nac_client_t *client);
void l2tp_session_down(l2tp_profile_t *prof, void *data);

void *l2tp_session_data(l2tp_session_t *session);
void *l2tp_session_open_data(l2tp_session_t *session);
void l2tp_session_close_data(l2tp_session_t *session);
int l2tp_session_send_data(l2tp_session_t *session, msgbuf_t *msg);

int l2tp_nac_start_server(l2tp_profile_t *prof, ppp_profile_t *pprof, nac_t *nac);
void l2tp_nac_stop_server(l2tp_profile_t *prof, nac_t *nac);
void l2tp_nac_open_client(l2tp_session_t *session);

/* ============================================================ *
 * tunnel operations
 * ============================================================ */
l2tp_tunnel_t *l2tp_tunnel_by_tid(uint16_t id);
l2tp_tunnel_t *l2tp_tunnel_by_xprt(l2tp_xprt_t *xprt);
l2tp_tunnel_t *l2tp_tunnel_by_peer(int mode, uint16_t id,
				   uint32_t peer_addr);
l2tp_tunnel_t *l2tp_tunnel_by_call(int side, uint16_t id,
				   uint32_t peer_addr);
int l2tp_tunnel_is_established(l2tp_tunnel_t *tunnel);
void l2tp_tunnel_lowerdown(l2tp_tunnel_t *tunnel);
int l2tp_tunnel_headsize(void);

/* outgoing tunnel creation */
int l2tp_tunnel_start(l2tp_profile_t *c, nic_t *dev);
int l2tp_tunnel_stop(l2tp_profile_t *c, nic_t *dev);
int l2tp_tunnel_unregister(l2tp_profile_t *c, nic_t *dev);
uint16_t l2tp_tunnel_outgoing(l2tp_profile_t *prof);
/* incoming tunnel creation */
uint16_t l2tp_tunnel_incoming(l2tp_profile_t *prof,
			      nic_t *dev, uint16_t p_tid,
			      uint32_t peer_addr,
			      uint16_t peer_port,
			      uint32_t this_addr);
int l2tp_tunnel_established(uint16_t tid);

#define L2TP_TUNNEL_REGISTER	0x01
#define L2TP_TUNNEL_UNREGISTER	0x02
#define L2TP_TUNNEL_ESTABLISH	0x03

int l2tp_register_notify(notify_t *nb);
int l2tp_unregister_notify(notify_t *nb);
int l2tp_tunnel_notify(unsigned long val, void *v);

/* ============================================================ *
 * session operations
 * ============================================================ */
void l2tp_session_raise(l2tp_session_t *session, int event);
int l2tp_session_recv(l2tp_session_t *session, msgbuf_t *msg);
l2tp_session_t *l2tp_session_by_sid(uint16_t sid);
l2tp_session_t *l2tp_session_by_peer(uint16_t sid,
				     uint32_t addr, uint16_t port);
void l2tp_session_notify(int event,
			 uint16_t peer_tid, uint16_t peer_port,
			 l2tp_xprt_t *xprt);

uint16_t l2tp_session_incoming(l2tp_tunnel_t *tunnel, ppp_phase_t *ctx,
			       uint16_t session_id);
uint16_t l2tp_session_outgoing(l2tp_tunnel_t *tunnel, ppp_phase_t *ctx,
			       nac_client_t *client);
void l2tp_session_advance(l2tp_session_t *session);

int l2tp_session_established(uint16_t sid);
int l2tp_session_is_established(l2tp_session_t *session);

/* ============================================================ *
 * profile operations
 * ============================================================ */
void l2tp_profile_free(l2tp_profile_t *prof);
l2tp_profile_t *l2tp_profile_get_by_name(const char *name);

int l2tp_name2authmode(const char *name);
int l2tp_name2mode(const char *name);
const char *l2tp_side2name(int side);
const char *l2tp_mode2name(int mode);

#ifdef __cplusplus
}
#endif

#endif
