#ifndef __VTSS_AUTH_H_INCLUDE__
#define __VTSS_AUTH_H_INCLUDE__

/* ================================================================= *
 * security
 * ================================================================= */

/* - Port Based Network Access Control, 802.1X --------------------- */

/* Authentication state */
#define VTSS_AUTH_STATE_NONE	0
#define VTSS_AUTH_STATE_EGRESS	1
#define VTSS_AUTH_STATE_BOTH	2

int vtss_port_auth_state_set(const vtss_port_no_t port_no,
			     const int auth_state);

#ifdef CONFIG_VTSS_AUTH
int vtss_port_auth_state_get(const vtss_port_no_t port_no);
int vtss_auth_start(void);
#else
static inline int vtss_port_auth_state_get(const vtss_port_no_t port_no)
{
	return VTSS_AUTH_STATE_NONE;
}
static inline int vtss_auth_start(void) { return 0; }
#endif

#endif /* __VTSS_AUTH_H_INCLUDE__ */
