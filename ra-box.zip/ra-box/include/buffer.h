#ifndef __BUFFER_H__
#define __BUFFER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>

typedef struct buffer {
	unsigned char *		base;
	unsigned int		head, tail, size;
	unsigned int		overrun;
} buffer_t;

extern void		buf_init(buffer_t *, void *, size_t);
extern void		buf_set(buffer_t *, void *, size_t);
extern void		buf_clear(buffer_t *);
extern int		buf_get(buffer_t *, void *, size_t);
extern int		buf_gets(buffer_t *, char *, size_t);
extern int		buf_put(buffer_t *, const void *, size_t);
extern int		buf_putc(buffer_t *, int);
extern int		buf_puts(buffer_t *, const char *);
extern int		buf_push(buffer_t *, const void *, size_t);
extern unsigned int	buf_avail(buffer_t *);
extern unsigned int	buf_tailroom(buffer_t *);
extern unsigned int	buf_size(buffer_t *);
extern void *		buf_head(buffer_t *);
extern void *		buf_tail(buffer_t *);
extern int		buf_read(buffer_t *, int);
extern void		buf_compact(buffer_t *);
extern int		buf_overrun(buffer_t *);

#ifdef __cplusplus
}
#endif

#endif /*__BUFFER_H__*/

