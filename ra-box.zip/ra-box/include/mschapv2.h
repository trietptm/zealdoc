#ifndef __MSCHAPV2_H_INCLUDE__
#define __MSCHAPV2_H_INCLUDE__

#include <sysdep.h>

#include <md4.h>
#include <sha1.h>
#include <mschap.h>

#define MSCHAPV2_CHALLENGE_LEN	16	/* Challenge length for MS-CHAPv2 */
#define MSCHAPV2_RESPONSE_LEN	49	/* Response length for MS-CHAPv2 */
#define MSCHAPV2_AUTH_RESP_LEN	40	/* MS-CHAPv2 authenticator response, */

/*
 * Offsets within the response field for MS-CHAPv2
 */
#define MSCHAPV2_RESP_PEERCHAL_OFF	0
#define MSCHAPV2_RESP_PEERCHAL_LEN	16
#define MSCHAPV2_RESP_RESERVED_LEN	8
#define MSCHAPV2_RESP_NTPASS_OFF	24
#define MSCHAPV2_RESP_NTPASS_LEN	24
#define MSCHAPV2_RESP_FLAGS_OFF		48

void GenerateNTResponse(IN const uint8_t AuthenticatorChallenge[16],
			IN const uint8_t PeerChallenge[MSCHAPV2_RESP_PEERCHAL_LEN],
			IN const char *UserName,
			IN const char *Password,
			OUT uint8_t Response[24]);
void ChallengeHash(IN const uint8_t PeerChallenge[MSCHAPV2_RESP_PEERCHAL_LEN],
		   IN const uint8_t AuthenticatorChallenge[16],
		   IN const char *UserName, OUT uint8_t Challenge[8]);
void GenerateAuthenticatorResponse(IN const char *Password,
				   IN const uint8_t NTResponse[24],
				   IN const uint8_t PeerChallenge[MSCHAPV2_RESP_PEERCHAL_LEN],
				   IN const uint8_t AuthenticatorChallenge[16],
				   IN const char *UserName,
				   OUT uint8_t AuthenticatorResponse[MSCHAPV2_AUTH_RESP_LEN]);
bool CheckAuthenticatorResponse(IN const char *Password,
				IN const uint8_t NtResponse[24],
				IN const uint8_t PeerChallenge[16],
				IN const uint8_t AuthenticatorChallenge[16],
				IN const char *UserName,
				IN const uint8_t *ReceivedResponse);

const char *mschapv2_parse_success(const uint8_t *msg, size_t len,
				   uint8_t auth_resp[MSCHAPV2_AUTH_RESP_LEN],
				   bool *valid);

#endif /* __MSCHAPV2_H_INCLUDE__ */
