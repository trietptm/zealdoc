#ifndef __PPP_AUTH_H_INCLUDE__
#define __PPP_AUTH_H_INCLUDE__

#include <ppp_prot.h>
#include <ppp_lcp.h>

#define LCP_CI_AUTH			3	/* Authentication-Type */
#define LCP_CILEN_AUTH			(PPP_CILEN_VOID + 2)

#define PPP_AUTH_NOSIDE		0x00
#define PPP_AUTH_INITIATE	0x01
#define PPP_AUTH_RESPOND	0x02

typedef struct _ppp_authmech_t ppp_authmech_t;
typedef struct _ppp_authinst_t ppp_authinst_t;

struct _ppp_authmech_t {
	const char *(*get_name)(ppp_authinst_t *inst, int side);
	void (*opt_reset)(ppp_authinst_t *inst);
	int (*opt_bcr)(ppp_authinst_t *inst, msgbuf_t *msg);
	int (*opt_pcp)(ppp_authinst_t *inst, msgbuf_t *msg, uint8_t code);
	/* for NAK hint */
	int (*opt_bcn)(ppp_authinst_t *inst, msgbuf_t *msg);

	/* incoming event handlers */
	int (*opt_rcr)(ppp_authinst_t *inst,
		       msgbuf_t *req, msgbuf_t *nak, uint8_t *orc);
	void (*opt_rca)(ppp_authinst_t *inst, msgbuf_t *msg);
	int (*opt_rcn)(ppp_authinst_t *inst, msgbuf_t *msg);

	bool (*opt_cnq)(ppp_authinst_t *inst);
	bool (*opt_cnp)(ppp_authinst_t *inst, msgbuf_t *req);
	bool (*opt_cnj)(ppp_authinst_t *inst, msgbuf_t *req);

	/* get_key */
	/* set_key */
};

#define PPP_AUTH_NONE		0
#define PPP_AUTH_FAILURE	0
#define PPP_AUTH_SUCCESS	1

/* ============================================================ *
 * authinst operations
 * ============================================================ */
void ppp_auth_enable(ppp_phase_t *ctx, ppp_authinst_t *inst, int def_prio);
void ppp_auth_disable(ppp_phase_t *ctx, ppp_authinst_t *inst);

void ppp_auth_start(ppp_phase_t *phase);
void ppp_auth_stop(ppp_phase_t *phase);

const char *ppp_auth_name(ppp_phase_t *phase, int side);

int ppp_auth_succeeded(ppp_phase_t *phase);
void ppp_auth_success(ppp_phase_t *phase, int side);
void ppp_auth_failure(ppp_phase_t *phase, int side);
int ppp_auth_required(ppp_phase_t *phase);
#ifdef HAVE_NAC
int ppp_auth_spoofing(ppp_phase_t *phase);
#endif
void ppp_auth_generic_exit(ppp_phase_t *ctx, ppp_protinst_t *insti);

/* ============================================================ *
 * auth-type handler
 * ============================================================ */
#include <secret.h>
#include <ppp_pap.h>
#include <ppp_chap.h>

#endif /* __PPP_AUTH_H_INCLUDE__ */
