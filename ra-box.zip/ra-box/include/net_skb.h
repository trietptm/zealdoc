/*
 * ZETALOG's Personal COPYRIGHT
 *
 * Copyright (c) 2008
 *    ZETALOG - "Lv ZHENG".  All rights reserved.
 *    Author: Lv "Zetalog" Zheng
 *    Internet: zetalog@hzcnc.com
 *
 * This COPYRIGHT used to protect Personal Intelligence Rights.
 * Redistribution and use in source and binary forms with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the Lv "Zetalog" ZHENG.
 * 3. Neither the name of this software nor the names of its developers may
 *    be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 4. Permission of redistribution and/or reuse of souce code partially only
 *    granted to the developer(s) in the companies ZETALOG worked.
 * 5. Any modification of this software should be published to ZETALOG unless
 *    the above copyright notice is no longer declaimed.
 *
 * THIS SOFTWARE IS PROVIDED BY THE ZETALOG AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE ZETALOG OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)msgbuf.h: stackable message buffer interfaces
 * $Id: net_skb.h,v 1.3 2009-02-12 03:47:41 zhenglv Exp $
 */

#ifndef __NET_SKB_H_INCLUDE__
#define __NET_SKB_H_INCLUDE__

#include <sysdep.h>
#include <list.h>
#include <panic.h>

typedef struct _msgbuf_info_t {
	/* store protocol stack data */
	void *msg_info;
	void (*msg_free)(void *);
	list_t link;
} msgbuf_info_t;

typedef struct _msgbuf_t {
	uint8_t *buf;
	int buf_len;
	uint8_t *head;	/* the first byte of real data */
	uint8_t *tail;	/* where new data will be added */

	/* stackable message info */
	msgbuf_info_t *info;
	list_t info_list;
	list_t link;
} msgbuf_t;

#define encode_net8(buf, byte)	*(buf++) = byte
#define decode_net8(buf)	*(buf++)

#define encode_net16(buf, word)					\
	do {							\
		buf[0] = (uint8_t)(((word) & 0xff00) >> 8);	\
		buf[1] = (uint8_t)(((word) & 0x00ff) >> 0);	\
		buf += 2;					\
	} while (0)

static inline uint16_t decode_net16(const char *buf)
{
	uint16_t word;
	word = (buf[0] << 8) | buf[1];
	buf += 2;
	return word;
}

#define encode_net32(buf, word)						\
	do {								\
		buf[0] = (uint8_t)(((word) & 0xff000000) >> 24);	\
		buf[1] = (uint8_t)(((word) & 0x00ff0000) >> 16);	\
		buf[2] = (uint8_t)(((word) & 0x0000ff00) >> 8);		\
		buf[3] = (uint8_t)(((word) & 0x000000ff) >> 0);		\
		buf += 4;						\
	} while (0)

static inline uint32_t decode_net32(char *buf)
{
	uint32_t dword;
	dword = (buf[0]  << 24) | (buf[1] << 16) |
		(buf[2]  << 8)  | buf[3];
	buf += 4;
	return dword;
}

#define put_net8(msg, byte)	*((msg)->tail++) = byte
#define get_net8(msg)		*((msg)->head++)

#define put_net16(msg, word)						\
	do {								\
		msg->tail[0] = (uint8_t)(((word) & 0xff00) >> 8);	\
		msg->tail[1] = (uint8_t)(((word) & 0x00ff) >> 0);	\
		msg->tail += 2;						\
	} while (0)

static inline uint16_t get_net16(msgbuf_t *msg)
{
	uint16_t word;
	word = ((msg)->head[0] << 8) | (msg)->head[1];
	msg->head += 2;
	return word;
}

#define put_net32(msg, word)						\
	do {								\
		msg->tail[0] = (uint8_t)(((word) & 0xff000000) >> 24);	\
		msg->tail[1] = (uint8_t)(((word) & 0x00ff0000) >> 16);	\
		msg->tail[2] = (uint8_t)(((word) & 0x0000ff00) >> 8);	\
		msg->tail[3] = (uint8_t)(((word) & 0x000000ff) >> 0);	\
		msg->tail += 4;						\
	} while (0)

static inline uint32_t get_net32(msgbuf_t *msg)
{
	uint32_t dword;
	dword = ((msg)->head[0]  << 24) | ((msg)->head[1] << 16) |
		((msg)->head[2]  << 8)  | (msg)->head[3];
	msg->head += 4;
	return dword;
}

void msgbuf_reset_buf(msgbuf_t * msg, void * buffer, int len);
void msgbuf_set_buf(msgbuf_t *msg, void *buffer, int len);
int msgbuf_cmp_buf(msgbuf_t *msg1, msgbuf_t *msg2);
msgbuf_t *msgbuf_new(void);
void msgbuf_free(msgbuf_t *msg);
msgbuf_t *msgbuf_make(int len, int headroom);

int msgbuf_set_msg(msgbuf_t *msg, uint8_t *data, int len);

/* stackable message info */
void msgbuf_add_info(msgbuf_t *msg, void *info, void (*msg_free)(void *));
void msgbuf_pop_info(msgbuf_t *msg);
void msgbuf_push_info(msgbuf_t *msg);
void *msgbuf_get_info(const msgbuf_t *msg);

void msgbuf_init(msgbuf_t * msg, void * buf, int len, int headroom);

msgbuf_t *msgbuf_clone_new(msgbuf_t *old);
void msgbuf_clone_free(msgbuf_t *msg);
void msgbuf_clone_replace(msgbuf_t *old, msgbuf_t *picked);

#define msgbuf_set_head(msg, phead)	((msg)->head = (uint8_t *)(phead))
#define msgbuf_set_tail(msg, ptail)	((msg)->tail = (uint8_t *)(ptail))
#define msgbuf_get_head(msg)		((msg)->head)
#define msgbuf_get_tail(msg)		((msg)->tail)

#define msgbuf_move_head(msg, off)	((msg)->head += off)
#define msgbuf_move_tail(msg, off)	((msg)->tail += off)
#define msgbuf_reserve(msg, len)	\
	(msgbuf_move_head(msg, len), msgbuf_move_tail(msg, len))

#define msgbuf_buffer(msg)		((msg)->buf)
#define msgbuf_buffer_len(msg)		((msg)->buf_len)

#define msgbuf_length(msg)		((msg)->tail - (msg)->head)
/* space after tail */
#define msgbuf_avail(msg)		((msg)->buf + (msg)->buf_len - (msg)->tail)
/* space before head */
#define msgbuf_reserved(msg)		((msg)->head - (msg)->buf)

/* check that head & tail are reasonable.
 * buf <= head <= tail <= buf+buf_len
 * returns TRUE for good, FALSE for bad.
 *
 * This assures that head and tail both point within the buffer and
 * that the contained data length is >= 0 and < buf_len.
 * Actually, its ok for the tail be just beyond the end of the buffer.
 * Since tail points to where we're writing next, this indicates the
 * full buffer condition.
 */
#define msgbuf_check(msg)			\
	(((msg)->buf  <= (msg)->head) &&	\
	 ((msg)->head <= (msg)->tail) &&	\
         ((msg)->tail <= (msg)->buf+(msg)->buf_len))

void msgbuf_queue_free(list_t *list);
msgbuf_t *msgbuf_queue_peek(list_t *head);
void msgbuf_queue_unlink(msgbuf_t *msg);
int msgbuf_queue_empty(list_t *head);
msgbuf_t *msgbuf_queue_pop(list_t *head);
void msgbuf_queue_push(list_t *head, msgbuf_t *msg);

static inline void put_net(msgbuf_t *msg, const uint8_t *data, int len)
{
	int i = 0;
	assert(len >= 0 && len <= msgbuf_avail(msg));
	while (i < len && data) {
		put_net8(msg, data[i]);
		i++;
	}
}

static inline void get_net(msgbuf_t *msg, uint8_t *data, int len)
{
	if (len > 0 && len < msgbuf_length(msg)) {
		memcpy(data, msgbuf_get_head(msg), len);
		msgbuf_move_head(msg, len);
	}
}

/* ============================================================ *
 * sk_buff operations
 * ============================================================ */
static inline unsigned char *skb_put(msgbuf_t *skb, unsigned int len)
{
	unsigned char *tmp = msgbuf_get_tail(skb);
	skb->tail += len;
	if (skb->tail > (skb->buf + skb->buf_len))
		panic();
	return tmp;
}

static inline void __skb_trim(msgbuf_t *skb, unsigned int len)
{
	msgbuf_set_tail(skb, msgbuf_get_head(skb) + len);
}

/**
 *	skb_trim - remove end from a buffer
 *	@skb: buffer to alter
 *	@len: new length
 *
 *	Cut the length of a buffer down by removing data from the tail. If
 *	the buffer is already under the length specified it is not modified.
 *	The skb must be linear.
 */
static inline void skb_trim(msgbuf_t *skb, int len)
{
	if (msgbuf_length(skb) > len)
		__skb_trim(skb, len);
}

#endif /* __NET_SKB_H_INCLUDE__ */
