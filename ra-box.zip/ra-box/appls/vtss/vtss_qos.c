#include "vtss_priv.h"
#include <vtss_qos.h>

#ifdef CONFIG_VTSS_QOS

vtss_qos_state_t vtss_qos_state;

/* ================================================================= *
 * port QoS (Categorizer/Policer/Shaper)
 * ================================================================= */
static int chip_prio(const vtss_prio_t prio)
{
#if (VTSS_PRIOS==2)
	switch (vtss_qos_state.prios) {
        case 1: return 1;
        case 2: return (prio-VTSS_PRIO_START);
	}
#endif /* (VTSS_PRIOS==2) */
#if (VTSS_PRIOS==4)
	switch (vtss_qos_state.prios) {
        case 1: return 3;
        case 2: return (prio==1 ? 1 : 3);
        case 4: return (prio-VTSS_PRIO_START);
	}
#endif /* (VTSS_PRIOS==4) */
#if (VTSS_PRIOS==8)
	switch (vtss_qos_state.prios) {
        case 1: return 7;
        case 2: return (prio==1 ? 5 : 7);
        case 4: return (prio==1 ? 1 : prio==2 ? 3 : prio==3 ? 5 : 7);
        case 8: return (prio-VTSS_PRIO_START);
	}
#endif /* (VTSS_PRIOS==8) */
	return 0; /* Never comes here, but avoid the compiler warning. */
}

#ifdef CONFIG_VTSS_GROCX
#define RATE_FACTOR 1176471 /* 8000000/6.8 */
#define RATE_MAX    4595    /* 0xFFF*RATE_FACTOR/0xFFFFF */
#else
#define RATE_FACTOR 1666667 /* 8000000/4.8 */
#define RATE_MAX    6510    /* 0xFFF*RATE_FACTOR/0xFFFFF */
#endif

/* Setup policers and shapers for all ports */
static int sparx_policer_shaper_setup(void)
{
	uint i, j, weight, w[VTSS_QUEUES];
	vtss_port_no_t port_no;
	ulong max_rate = 0, policer_rate, shaper_rate;
	vtss_port_qos_setup_t *qos;
	
	for (i = 0; i < 2; i++) {
		for (port_no = VTSS_PORT_NO_START;
		     port_no < VTSS_PORT_NO_END; port_no++) {
			if (vtss_mac_state.port_map.vtss_port_unused[port_no])
				continue;
			
			qos = &vtss_qos_state.qos[port_no];
			policer_rate = qos->policer_port;
			if (policer_rate == VTSS_BITRATE_FEATURE_DISABLED)
				policer_rate = 0;
			
			shaper_rate = qos->shaper_port;
			if (shaper_rate == VTSS_BITRATE_FEATURE_DISABLED)
				shaper_rate = 0;
			
			if (i == 0) {
				/* First round: calculate maximum rate */
				if (policer_rate > max_rate)
					max_rate = policer_rate;
				
				if (shaper_rate > max_rate)
					max_rate = shaper_rate;
			} else {
				/* Second round: Setup policer and shaper */
				for (j = 0; j < VTSS_QUEUES; j++) {
					weight = qos->weight[j + VTSS_QUEUE_START];
					w[j] = (qos->wfq_enable ? 
						(weight == VTSS_WEIGHT_1 ? 3 :
					weight == VTSS_WEIGHT_2 ? 2 :
					weight == VTSS_WEIGHT_4 ? 1 :
					weight == VTSS_WEIGHT_8 ? 0 : 4) : 0);
					if (w[j] > 3) {
						vtss_log(VTSS_LOG_ERR,
							 "SPARX: illegal weight, weight=%d",
							 weight);
						w[j] = 0;
					}
				}
				HT_WR(PORT, port_no, SHAPER_CFG,
				      (20<<24) | /* GAP_VALUE */
				      (w[0]<<22) | (w[1]<<20) | (w[2]<<18) | (w[3]<<16) | 
				      ((qos->wfq_enable ? 1 : 0)<<15) |
				      (1<<12) |  /* EGRESS_BURST: 4 kB */
				      (shaper_rate*0xFFF/max_rate)<<0); /* EGRESS_RATE */
				HT_WR(PORT, port_no, POLICER_CFG,
				      (1<<15) | /* POLICE_FWD */
				      (0<<14) | /* POLICE_FC */
				      (1<<12) | /* INGRESS_BURST: 4 kB */
				      (policer_rate*0xFFF/max_rate)<<0); /* INGRESS RATE */
			}
		}
		if (i == 0) {
			/* Calculate maximum rate */
			if (max_rate > 1000000 || max_rate == 0) /* Maximum 1G */
				max_rate = 1000000;
			/* Setup rate unit */
			if (max_rate < RATE_MAX)
				max_rate = RATE_MAX; 
			HT_WR(SYSTEM, 0, RATEUNIT,
			      5*(((0xFFF/5)*RATE_FACTOR)/max_rate));
		}
	}
	return 0;
}

/* - Quality of Service -------------------------------------------- */
int vtss_qos_prios_set(const vtss_prio_t prios)
{
	int        ex = 0;
	BOOL           warning = 0;
	vtss_port_no_t port_no;
	
	if (prios < VTSS_PRIO_START ||
		prios>=VTSS_PRIO_END || prios==3 || (prios>=5 && prios<=7)) {
		vtss_log(VTSS_LOG_ERR, "SWITCH: illegal prios, prios=%d", prios);
		return VTSS_UNSPECIFIED_ERROR;
	}
	
	if (prios != vtss_qos_state.prios) {
		vtss_qos_state.prios = prios;
		
		for (port_no = VTSS_PORT_NO_START;
		     port_no < VTSS_PORT_NO_END; port_no++) {
			if (!vtss_mac_state.port_map.vtss_port_unused[port_no]) {
				if ((ex = vtss_ll_port_qos_setup_set(port_no, &vtss_qos_state.qos[port_no])) < VTSS_WARNING)
					return ex;
				if (ex < 0) warning = 1;
				
				if ((ex = vtss_ll_port_queue_setup(port_no)) < VTSS_WARNING)
					return ex;
				if (ex < 0) warning = 1;
				
				if ((ex = vtss_ll_port_queue_enable(port_no, 1)) < VTSS_WARNING)
					return ex;
				if (ex < 0) warning = 1;
			}
		}
		VTSS_RC(vtss_ll_qos_setup_set(&vtss_qos_state.qos_setup));
	}
	if (warning)
		ex = VTSS_WARNING;
	
	return ex;
}

int vtss_port_qos_get(const vtss_port_no_t port_no,
                          vtss_port_qos_setup_t * const qos)
{
	/* Check that the port number is valid */
	if (!VTSS_PORT_IS_PORT(port_no)) {
		vtss_log(VTSS_LOG_ERR, "SWITCH: illegal port, port=%d", port_no);
		return VTSS_INVALID_PARAMETER;
	}
	
	*qos = vtss_qos_state.qos[port_no];
	return 0;
}

int vtss_port_qos_set(const vtss_port_no_t port_no,
                          const vtss_port_qos_setup_t * const qos)
{
	/* Check that the port number is valid */
	if (!VTSS_PORT_IS_PORT(port_no)) {
		vtss_log(VTSS_LOG_ERR, "SWITCH: illegal port, port=%d", port_no);
		return VTSS_INVALID_PARAMETER;
	}
	
	vtss_qos_state.qos[port_no] = *qos;
#ifdef VTSS_FEATURE_QOS_WFQ_PORT
	/* Use WFQ water marks on all ports if any port has WFQ enabled */
	{
		vtss_port_no_t port;
		BOOL           wfq_old;
		
		wfq_old = vtss_qos_state.wfq;
		vtss_qos_state.wfq = 0;
		for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
			if (!vtss_mac_state.port_map.vtss_port_unused[port] && vtss_qos_state.qos[port].wfq_enable)
				vtss_qos_state.wfq = 1;
		}
		if (vtss_qos_state.wfq != wfq_old) {
			for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
				if (!vtss_mac_state.port_map.vtss_port_unused[port]) {
					VTSS_RC(vtss_ll_port_queue_setup(port));
				}
			}
		}
	}
#endif
	return vtss_ll_port_qos_setup_set(port_no, qos);
}

/* Get QoS setup for switch */
int vtss_qos_setup_get(vtss_qos_setup_t * const qos)
{
	*qos = vtss_qos_state.qos_setup;
	return 0;
}

/* Set QoS setup for switch */
int vtss_qos_setup_set(const vtss_qos_setup_t * const qos)
{
	vtss_qos_state.qos_setup = *qos;
	return vtss_ll_qos_setup_set(qos);
}

/* - QoS Control Lists --------------------------------------------- */
#ifdef VTSS_FEATURE_QCL_PORT
int vtss_qce_add(const vtss_qcl_id_t         qcl_id,
                     const vtss_qce_id_t         qce_id,
                     const vtss_qce_t    * const qce)
{
	return vtss_ll_qce_add(qcl_id, qce_id, qce);
}

int vtss_qce_del(const vtss_qcl_id_t  qcl_id,
                     const vtss_qce_id_t  qce_id)
{
	return vtss_ll_qce_del(qcl_id, qce_id);
}
#endif

#define QCL_PORT_MAX 12 /* Number of QCLs per port */
#define QCE_TYPE_FREE      (0<<24)
#define QCE_TYPE_ETYPE     (1<<24)
#define QCE_TYPE_VID       (2<<24)
#define QCE_TYPE_UDP_TCP   (3<<24)
#define QCE_TYPE_DSCP      (4<<24)
#define QCE_TYPE_TOS       (5<<24)
#define QCE_TYPE_TAG       (6<<24)

static BOOL ht_qcl_full(const vtss_qcl_id_t qcl_id)
{
	int i;
	vtss_qcl_entry_t *entry;
	
	for (i = 0, entry = vtss_qos_state.qcl[qcl_id].qcl_list_used;
	entry != NULL; i++, entry = entry->next) {
		
		switch (entry->qce.type) {
		case VTSS_QCE_TYPE_ETYPE:
		case VTSS_QCE_TYPE_VLAN:
		case VTSS_QCE_TYPE_TOS:
		case VTSS_QCE_TYPE_TAG:
			/* These entries take up a single QCL entry */
			break;
		case VTSS_QCE_TYPE_UDP_TCP:
			if (entry->qce.frame.udp_tcp.low != entry->qce.frame.udp_tcp.high) {
				/* Range, at least two entries required */
				if (i & 1) /* Odd address, three entries requried */
					i++;
				i++;
			}
			break;
		case VTSS_QCE_TYPE_DSCP:
			if (entry->next != NULL && entry->next->qce.type == VTSS_QCE_TYPE_DSCP) {
				/* If next entry is DSCP, merge */
				entry = entry->next;
			}
			break;
		default: 
			vtss_log(VTSS_LOG_ERR,
				 "SPARX: unknown QCE type, qce=%d",
				 entry->qce.type); 
			return 0;
		}
	}
	return (i > QCL_PORT_MAX);
}

static int ht_qcl_port_setup_set(const vtss_port_no_t port_no, const vtss_qcl_id_t qcl_id)
{
	uint i, j;
	ulong value;
	vtss_qcl_entry_t *entry;
	
	/* Clear range table */
	HT_WR(PORT, port_no, CAT_QCL_RANGE_CFG, 0);
	
	for (i = 0, entry = vtss_qos_state.qcl[qcl_id].qcl_list_used;
	     i < QCL_PORT_MAX && entry != NULL; i++, entry = entry->next) {
		switch (entry->qce.type) {
		case VTSS_QCE_TYPE_ETYPE:
			value = (QCE_TYPE_ETYPE | 
				(chip_prio(entry->qce.frame.etype.prio)<<16) | 
				(entry->qce.frame.etype.val<<0)); 
			vtss_log(VTSS_LOG_DEBUG,
				 "SPARX: adding ETYPE QCE[%d]: value=0x%08lx",
				 i, value); 
			HT_WR(PORT, port_no, CAT_QCE0 + i, value);
			break;
		case VTSS_QCE_TYPE_VLAN:
			value = (QCE_TYPE_VID | 
				(chip_prio(entry->qce.frame.vlan.prio)<<16) | 
				(entry->qce.frame.vlan.vid<<0));
			vtss_log(VTSS_LOG_DEBUG,
				 "SPARX: adding VLAN QCE[%d]: value=0x%08lx",
				 i, value); 
			HT_WR(PORT, port_no, CAT_QCE0 + i, value);
			break;
		case VTSS_QCE_TYPE_UDP_TCP:
			if (entry->qce.frame.udp_tcp.low != entry->qce.frame.udp_tcp.high) {
				if (i & 1) {
					vtss_log(VTSS_LOG_DEBUG,
						 "SPARX: adding free QCE[%d] for UDP/TCP range",
						 i);
					HT_WR(PORT, port_no, CAT_QCE0 + i, QCE_TYPE_FREE);
					i++;
					if (i >= QCL_PORT_MAX)
						break;
				}
				vtss_log(VTSS_LOG_DEBUG,
					 "SPARX: setting bit #%d of QCL range cfg",
					 i/2);
				HT_WRF(PORT, port_no, CAT_QCL_RANGE_CFG, i/2, 0x1, 1);
			}
			value = (QCE_TYPE_UDP_TCP | 
				(chip_prio(entry->qce.frame.udp_tcp.prio)<<16) | 
				(entry->qce.frame.udp_tcp.low<<0)); 
			vtss_log(VTSS_LOG_DEBUG,
				 "SPARX: adding UDP/TCP QCE[%d], value=0x%08lx",
				 i, value);
			HT_WR(PORT, port_no, CAT_QCE0 + i, value);
			if (entry->qce.frame.udp_tcp.low != entry->qce.frame.udp_tcp.high) {
				i++;
				if (i >= QCL_PORT_MAX)
					break;
				value = (QCE_TYPE_UDP_TCP | 
					(chip_prio(entry->qce.frame.udp_tcp.prio)<<16) | 
					(entry->qce.frame.udp_tcp.high<<0)); 
				vtss_log(VTSS_LOG_DEBUG,
					 "SPARX: adding UDP/TCP QCE[%d], value=0x%08lx",
					 i, value);
				HT_WR(PORT, port_no, CAT_QCE0 + i, value);
			}
			break;
		case VTSS_QCE_TYPE_DSCP:
			value = (QCE_TYPE_DSCP | 
				(entry->qce.frame.dscp.dscp_val <<  2) | 
				(chip_prio(entry->qce.frame.dscp.prio) << 0));  /* DSCP0 */ 
			if (entry->next != NULL && entry->next->qce.type == VTSS_QCE_TYPE_DSCP) {
				/* If next entry is DSCP, merge */
				entry = entry->next;
			}
			value |= ((entry->qce.frame.dscp.dscp_val << 10) | 
				(chip_prio(entry->qce.frame.dscp.prio) << 8)); /* DSCP1 */ 
			vtss_log(VTSS_LOG_DEBUG,
				 "SPARX: adding DSCP QCE[%d], value=0x%08lx",
				 i, value);
			HT_WR(PORT, port_no, CAT_QCE0 + i, value);
			break;
		case VTSS_QCE_TYPE_TOS:
			value = QCE_TYPE_TOS;
			for (j = 0; j < 8; j++) {
				value |= (chip_prio(entry->qce.frame.tos_prio[j])<<(j*2));
			}
			vtss_log(VTSS_LOG_DEBUG,
				 "SPARX: adding TOS QCE[%d], value=0x%08lx",
				 i, value);
			HT_WR(PORT, port_no, CAT_QCE0 + i, value);
			break;
		case VTSS_QCE_TYPE_TAG:
			value = QCE_TYPE_TAG;
			for (j = 0; j < 8; j++) {
				value |= (chip_prio(entry->qce.frame.tag_prio[j])<<(j*2));
			}
			vtss_log(VTSS_LOG_DEBUG,
				 "SPARX: adding TAG QCE[%d], value=0x%08lx",
				 i, value);
			HT_WR(PORT, port_no, CAT_QCE0 + i, value);
			break;
		default: 
			vtss_log(VTSS_LOG_ERR,
				 "SPARX: unknown QCE type, qce=%d",
				 entry->qce.type); 
			return VTSS_UNSPECIFIED_ERROR;
		}
	}
	
	/* clear unused entries */
	while (i < QCL_PORT_MAX) {
		HT_WR(PORT, port_no, CAT_QCE0 + i, QCE_TYPE_FREE);
		i++;
	}
	return 0;
}

/* Set port QoS setup */
int vtss_ll_port_qos_setup_set(vtss_port_no_t port_no,
				   const vtss_port_qos_setup_t *qos)
{
	uint i = 0, j, k, max, prio_count[VTSS_PRIO_ARRAY_SIZE];
	vtss_prio_t prio;
	ulong tos = QCE_TYPE_TOS, dscp = 0, tag = QCE_TYPE_TAG;
	
	if (qos->qcl_id != VTSS_QCL_ID_NONE) {
		/* setup QCL */
		ht_qcl_port_setup_set(port_no, qos->qcl_id);
		
		/* skip old-style setup below by setting i to QCL_PORT_MAX */
		i = QCL_PORT_MAX;
	} else {
		/* Disable range checkers */
		HT_WR(PORT, port_no, CAT_QCL_RANGE_CFG, 0);
	}
	
	/* UDP/TCP port numbers */
	if (qos->udp_tcp_enable) {
		for (j = 0; j < 10; j++) {
			if (i < QCL_PORT_MAX && qos->udp_tcp_val[j] != 0) {
				HT_WR(PORT, port_no, CAT_QCE0 + i,
					QCE_TYPE_UDP_TCP | 
					(chip_prio(qos->udp_tcp_prio[j])<<16) | 
					(qos->udp_tcp_val[j]<<0));
				i++;
			}
		}
	}
	
	/* DSCP */
	if (qos->dscp_enable) {
		for (j = 0; j < 8; j++) {
			/* Find most frequent DSCP priority for each ToS value */
			memset(prio_count, 0, sizeof(prio_count));
			for (k = 0; k < 8; k++)
				prio_count[qos->dscp_prio[j*8+k]]++;
			max = VTSS_PRIO_START;
			for (k = VTSS_PRIO_START; k < VTSS_PRIO_END; k++)
				if (prio_count[k] > prio_count[max])
					max = k;
				
				/* Update ToS register value */
				tos |= (chip_prio(max)<<(j*2));
				
				/* Add entries for DSCP priorities different from the most frequent one */
				for (k = 0; k < 8; k++) {
					prio = qos->dscp_prio[j*8+k];
					if (prio != max) {
						if (dscp == 0) {
							dscp = QCE_TYPE_DSCP | ((j*8+k)<<10) | (chip_prio(prio)<<8);
						} else {
							dscp |= (((j*8+k)<<2) | (chip_prio(prio)<<0));
							if (i < (QCL_PORT_MAX - 1)) {
								HT_WR(PORT, port_no, CAT_QCE0 + i, dscp);
								i++;
							}
							dscp = 0;
						}
					}
				}
		} 
		
		/* If odd number of DSCP exceptions, write one more */
		if (dscp != 0 && i < (QCL_PORT_MAX - 1)) {
			HT_WR(PORT, port_no, CAT_QCE0 + i, dscp | ((dscp>>8) & 0xFF));
			i++;
		}
		
		/* Add ToS entry with most frequent priorities */
		if (i < QCL_PORT_MAX) {
			HT_WR(PORT, port_no, CAT_QCE0 + i, tos);
			i++;
		}
	} else if (qos->tos_enable && i < QCL_PORT_MAX) {
		for (j = 0; j < 8; j++) {
			tos |= (chip_prio(qos->dscp_prio[j*8])<<(j*2));
		}
		HT_WR(PORT, port_no, CAT_QCE0 + i, tos);
		i++;
	}
	
	/* Tag priority */
	if (qos->tag_enable && i < QCL_PORT_MAX) {
		for (j = 0; j < 8; j++) {
			tag |= (chip_prio(qos->tag_prio[j])<<(j*2));
		}
		HT_WR(PORT, port_no, CAT_QCE0 + i, tag);
		i++;
	}
	
	/* Ethernet Type */
	if (qos->etype_enable && i < QCL_PORT_MAX) {
		HT_WR(PORT, port_no, CAT_QCE0 + i, 
			QCE_TYPE_ETYPE | (chip_prio(qos->etype_prio)<<16) | (qos->etype_val<<0));
		i++;
	}
	
	/* Skip remaining QCEs */
	while (i < QCL_PORT_MAX) {
		HT_WR(PORT, port_no, CAT_QCE0 + i, QCE_TYPE_FREE);
		i++;
	}
	
	/* Default ingress VLAN tag priority */
	HT_WRF(PORT, port_no, CAT_PORT_VLAN, 12, 0x7, qos->usr_prio);
	
	/* Default priority */
	HT_WR(PORT, port_no, CAT_QCL_DEFAULT_CFG, chip_prio(qos->default_prio));
	
#ifdef VTSS_FEATURE_QOS_DSCP_REMARK
	/* DSCP remarking */
	dscp = qos->dscp_mode;
	if (port_no < 16) {
		HT_WRF(ANALYZER, 0, DSCPMODELOW, port_no*2, 0x3, dscp);
	} else {
		HT_WRF(ANALYZER, 0, DSCPMODEHIGH, (port_no - 16)*2, 0x3, dscp);
	}
	
	HT_WRF(PORT, port_no, TXUPDCFG, 18, 0x1, qos->dscp_remark ? 1 : 0);
	
	dscp = 0;
	for (prio = VTSS_PRIO_START; prio < VTSS_PRIO_END; prio++)
		dscp |= (qos->dscp_map[prio]<<((prio - VTSS_PRIO_START)*8));
	HT_WR(PORT, port_no, CAT_PR_DSCP_VAL_0_3, dscp);
#endif
	
#ifdef VTSS_FEATURE_QOS_TAG_REMARK
	/* Tag remarking */
	HT_WRF(PORT, port_no, TXUPDCFG, 17, 0x1, qos->tag_remark ? 1 : 0);
	
	tag = 0;
	for (prio = VTSS_PRIO_START; prio < VTSS_PRIO_END; prio++)
		tag |= (qos->tag_map[prio]<<((prio - VTSS_PRIO_START)*4));
	HT_WR(PORT, port_no, CAT_GEN_PRIO_REMAP, tag);
#endif
	
	/* Policers and shapers */
	VTSS_RC(sparx_policer_shaper_setup());
	
	/* Setup queues as water marks depend on policer setup */
	VTSS_RC(vtss_ll_port_queue_setup(port_no));
	return 0;
}

#ifdef VTSS_FEATURE_QCL_PORT
static int ht_qcl_commit(const vtss_qcl_id_t qcl_id)
{
	vtss_port_no_t port_no;
	int qcl_rc = 0;
	
	if (ht_qcl_full(qcl_id)) {
		vtss_log(VTSS_LOG_WARN,
			 "SPARX: QCL will be truncated when applied, qcl=%d",
			 qcl_id);
		qcl_rc = VTSS_WARNING;
	}
	
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		if (vtss_qos_state.qos[port_no].qcl_id == qcl_id) {
			/* Reapply QoS settings */
			VTSS_RC(vtss_ll_port_qos_setup_set(port_no, &vtss_qos_state.qos[port_no]));
		}
	}
	return qcl_rc;
}

/* Add QCE */
int vtss_ll_qce_add(vtss_qcl_id_t qcl_id,
                        vtss_qce_id_t qce_id,
                        const vtss_qce_t *qce)
{
	vtss_qcl_t *qcl;
	vtss_qcl_entry_t *cur, *prev = NULL;
	vtss_qcl_entry_t *new = NULL, *new_prev = NULL, *ins = NULL, *ins_prev = NULL;
	
	/* QCE ID 0 is reserved for insertion at end. Also check for same id */
	if (qce->id == VTSS_QCE_ID_LAST || qce->id == qce_id) {
		vtss_log(VTSS_LOG_ERR,
			 "SPARX: illegal qce id, qce=%lu", qce->id);        
		return VTSS_INVALID_PARAMETER;
	}
	
	/* Check that the QCL ID is valid */
	if (qcl_id < VTSS_QCL_ID_START || qcl_id >= VTSS_QCL_ID_END) {
		vtss_log(VTSS_LOG_ERR,
			 "SPARX: illegal qcl id, qcl=%lu", qcl_id);        
		return VTSS_INVALID_PARAMETER;
	}
	
	/* Search for existing entry and place to add */
	qcl = &vtss_qos_state.qcl[qcl_id];
	for (cur = qcl->qcl_list_used; cur != NULL; prev = cur, cur = cur->next) {
		if (cur->qce.id == qce->id) {
			/* Entry already exists */
			new_prev = prev;
			new = cur;
		}
		
		if (cur->qce.id == qce_id) {
			/* Found insertion point */
			ins_prev = prev;
			ins = cur;
		}
	}
	
	if (qce_id == VTSS_QCE_ID_LAST)
		ins_prev = prev;
	
	/* Check if the place to insert was found */
	if (ins == NULL && qce_id != VTSS_QCE_ID_LAST) {
		vtss_log(VTSS_LOG_ERR,
			 "SPARX: could not find qce, qce=%ld", qce_id);        
		return VTSS_ENTRY_NOT_FOUND;
	}
	
	if (new == NULL) {
		/* Take new entry from free list */
		if ((new = qcl->qcl_list_free) == NULL) {
			vtss_log(VTSS_LOG_ERR, "SPARX: QCL is full");
			return VTSS_UNSPECIFIED_ERROR;
		}
		qcl->qcl_list_free = new->next;
	} else {
		/* Take existing entry out of list */
		if (ins_prev == new)
			ins_prev = new_prev;
		if (new_prev == NULL)
			qcl->qcl_list_used = new->next;
		else
			new_prev->next = new->next;
	}
	
	/* Insert new entry in list */
	if (ins_prev == NULL) {
		new->next = qcl->qcl_list_used;
		qcl->qcl_list_used = new;
	} else {
		new->next = ins_prev->next;
		ins_prev->next = new;
	}
	new->qce = *qce;
	
	return ht_qcl_commit(qcl_id);
}

/* Delete QCE */
int vtss_ll_qce_del(vtss_qcl_id_t  qcl_id,
                        vtss_qce_id_t  qce_id)
{
	vtss_qcl_t *qcl;
	vtss_qcl_entry_t *cur, *prev;
	
	/* Check that the QCL ID is valid */
	if (qcl_id < VTSS_QCL_ID_START || qcl_id >= VTSS_QCL_ID_END) {
		vtss_log(VTSS_LOG_ERR, "SPARX: illegal QCL ID, qcl=%d", qcl_id);
		return VTSS_INVALID_PARAMETER;
	}
	
	qcl = &vtss_qos_state.qcl[qcl_id];
	
	for (cur = qcl->qcl_list_used, prev = NULL; cur != NULL;
	     prev = cur, cur = cur->next) {
		if (cur->qce.id == qce_id) {
			vtss_log(VTSS_LOG_DEBUG,
				 "SPARX: found existing ID, qce=%lu",
				 qce_id);
			if (prev == NULL)
				qcl->qcl_list_used = cur->next;
			else
				prev->next = cur->next;
			cur->next = qcl->qcl_list_free;
			qcl->qcl_list_free = cur;
			break;
		}
	}
	return (cur == NULL ? VTSS_ENTRY_NOT_FOUND : ht_qcl_commit(qcl_id));
}
#endif

BOOL vtss_qos_get_wfq(void)
{
#ifdef VTSS_FEATURE_QOS_WFQ_PORT
	return vtss_qos_state.wfq;
#endif
	return 0;
}

vtss_bitrate_t vtss_qos_policer_port(vtss_port_no_t port_no)
{
	return vtss_qos_state.qos[port_no].policer_port;
}

int vtss_qos_reset(void)
{
#ifdef VTSS_FEATURE_QOS_TAG_REMARK
        vtss_qce_t  qce;
        qce.id = 1;
        qce.type = VTSS_QCE_TYPE_TAG;
        qce.frame.tag_prio[0]= 1;
        qce.frame.tag_prio[1]= 1;
        qce.frame.tag_prio[2]= 2;
        qce.frame.tag_prio[3]= 2;
        qce.frame.tag_prio[4]= 3;
        qce.frame.tag_prio[5]= 3;
        qce.frame.tag_prio[6]= 4;
        qce.frame.tag_prio[7]= 4;
        vtss_qce_add(6,0,&qce);
#endif
	return 0;
}

int vtss_qos_start(void)
{
	vtss_port_no_t port_no;
	int i;

	/* Initialize QoS, all queues used */
	vtss_qos_state.prios = VTSS_PRIOS;
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		vtss_port_qos_setup_t *qos;
		
		qos = &vtss_qos_state.qos[port_no];
#ifdef VTSS_FEATURE_QCL_PORT
		qos->qcl_id = VTSS_QCL_ID_NONE;
#endif
#if defined(VTSS_FEATURE_QOS_L4_PORT)
		qos->udp_tcp_enable = 0;
#endif
		qos->dscp_enable = 0;
		qos->tag_enable = 0;
#ifdef VTSS_FEATURE_QOS_ETYPE_PORT
		qos->etype_enable = 0;
#endif
#ifdef VTSS_FEATURE_QOS_L4_PORT
		for (i = 0; i < 10; i++) {
			qos->udp_tcp_val[i] = 0;
		}
#endif
		for (i = 0; i < 64; i++) {
			qos->dscp_prio[i] = VTSS_PRIO_START;
		}
		for (i = 0; i < 8; i++) {
			/* Use IEEE user priority mapping adjusted for number of priorities */
			qos->tag_prio[i] = (
				((i == 0 ? 2 : i == 1 ? 0 : i == 2 ? 1 : i)*VTSS_PRIOS/8) + VTSS_PRIO_START);
		}
#ifdef VTSS_FEATURE_QOS_ETYPE_PORT
		qos->etype_val = 0xFFFF;
		qos->etype_prio = VTSS_PRIO_START;
#endif
		qos->default_prio = VTSS_PRIO_START;
		qos->usr_prio = 0 /*VTSS_TAGPRIO_DEFAULT*/;
#ifdef VTSS_FEATURE_QOS_POLICER_PORT
		qos->policer_port = VTSS_BITRATE_FEATURE_DISABLED;
#endif
#ifdef VTSS_FEATURE_QOS_POLICER_CIR_PIR_QUEUE
		for (i = VTSS_QUEUE_START; i < VTSS_QUEUE_END; i++) {
			qos->policer_cir_queue[i] = VTSS_BITRATE_FEATURE_DISABLED;
			qos->policer_pir_queue[i] = VTSS_BITRATE_FEATURE_DISABLED;
		}
#endif
#ifdef VTSS_FEATURE_QOS_SHAPER_PORT
		qos->shaper_port = VTSS_BITRATE_FEATURE_DISABLED;
#endif
	}
	
#ifdef VTSS_FEATURE_QOS_POLICER_CPU_SWITCH
	vtss_qos_state.qos_setup.policer_mac = VTSS_PACKET_RATE_DISABLED;
	vtss_qos_state.qos_setup.policer_cat = VTSS_PACKET_RATE_DISABLED;
	vtss_qos_state.qos_setup.policer_learn = VTSS_PACKET_RATE_DISABLED;
#endif
	
#ifdef VTSS_FEATURE_QOS_POLICER_UC_SWITCH
	vtss_qos_state.qos_setup.policer_uc = VTSS_PACKET_RATE_DISABLED;
#endif
	
#ifdef VTSS_FEATURE_QOS_POLICER_MC_SWITCH
	vtss_qos_state.qos_setup.policer_mc = VTSS_PACKET_RATE_DISABLED;
#endif
	
#ifdef VTSS_FEATURE_QOS_POLICER_BC_SWITCH
	vtss_qos_state.qos_setup.policer_bc = VTSS_PACKET_RATE_DISABLED;
#endif

#ifdef VTSS_FEATURE_QCL_PORT
	{
		vtss_qcl_id_t    qcl_id;
		vtss_qcl_t       *qcl;
		vtss_qcl_entry_t *qcl_entry;
		
		/* Initialize QCL free/used lists */
		for (qcl_id = VTSS_QCL_ID_START; qcl_id < VTSS_QCL_ID_END; qcl_id++) {
			qcl = &vtss_qos_state.qcl[qcl_id];
			for (i = 0; i < VTSS_QCL_LIST_SIZE; i++) {
				qcl_entry = &qcl->qcl_list[i];
				/* Insert in free list */
				qcl_entry->next = qcl->qcl_list_free;
				qcl->qcl_list_free = qcl_entry;
			}
		}
	}
#endif
	return 0;
}
#endif
