#include "vtss_priv.h"
#include <vtss_pvlan.h>

#ifdef CONFIG_VTSS_PVLAN

vtss_pvlan_state_t vtss_pvlan_state;

int vtss_pvlan_reset(void)
{
	return vtss_pgid_table_write(VTSS_PGID_BC);
}

int vtss_pvlan_port_members_get(const vtss_pvlan_no_t pvlan_no,
                                    BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	/* Check PVLAN number */
	if (pvlan_no < VTSS_PVLAN_NO_START || pvlan_no >= VTSS_PVLAN_NO_END) {
		vtss_log(VTSS_LOG_ERR,
			 "SWITCH: illegal pvlan, pvlan=%d", pvlan_no);
		return VTSS_INVALID_PARAMETER;
	}
	
	/* Return internal state information */
	memcpy(member, vtss_pvlan_state.pvlan_table[pvlan_no].member, sizeof(vtss_pvlan_state.pvlan_table[pvlan_no].member));
	return 0;
}

int vtss_pvlan_port_members_set(const vtss_pvlan_no_t pvlan_no, 
                                     const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	/* Check PVLAN number */
	if (pvlan_no < VTSS_PVLAN_NO_START || pvlan_no >= VTSS_PVLAN_NO_END) {
		vtss_log(VTSS_LOG_ERR,
			 "SWITCH: illegal pvlan, pvlan=%d", pvlan_no);
		return VTSS_INVALID_PARAMETER;
	}
	
	memcpy(vtss_pvlan_state.pvlan_table[pvlan_no].member, member, VTSS_PORT_ARRAY_SIZE*sizeof(BOOL));
	return vtss_update_masks(1, 0, 0);
}

int vtss_pvlan_start(void)
{
	vtss_port_no_t port_no;

	/* Initialize PVLAN table */
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		vtss_pvlan_state.pvlan_table[VTSS_PVLAN_NO_DEFAULT].member[port_no] = 1;
	}
	return 0;
}

int vtss_pvlan_update_masks(vtss_port_no_t i_port_no,
			    vtss_port_no_t e_port_no,
			    BOOL member[VTSS_PORT_ARRAY_SIZE])
{
	vtss_pvlan_no_t  pvlan_no;

	for (pvlan_no = VTSS_PVLAN_NO_START; pvlan_no < VTSS_PVLAN_NO_END; pvlan_no++) {
		if (vtss_pvlan_state.pvlan_table[pvlan_no].member[i_port_no]) {
			/* The ingress port is a member of this PVLAN */
			for (e_port_no = VTSS_PORT_NO_START; e_port_no < VTSS_PORT_NO_END; e_port_no++) {
				if (vtss_pvlan_state.pvlan_table[pvlan_no].member[e_port_no]) {
					/* This port is also a member of the PVLAN */
					member[e_port_no] = MAKEBOOL01(1);
				}
			}
		}
	}
	return 0;
}
#endif
