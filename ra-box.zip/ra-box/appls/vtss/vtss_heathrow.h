#ifndef __VTSS_HEATHROW_H_INCLUDE__
#define __VTSS_HEATHROW_H_INCLUDE__

/* Waiting time (nanoseconds) after reset command */
#define VTSS_T_RESET      125000

/* TX clock selection */
#define HT_TX_CLOCK_OFF		0
#define HT_TX_CLOCK_GIGA	1
#define HT_TX_CLOCK_100M	2
#define HT_TX_CLOCK_10M		3
#define HT_TX_CLOCK_MISC	4

/* SparX-G16/G24 revision B tail drop in MISCFIFO bit 2 */
#define MISCFIFO_TAILDROP (0<<2)

/* Frame ageing timer */
#define HT_TIMECMP_DEFAULT 0x3ffffff

/* ================================================================= *
 * helper functions
 * ================================================================= */
#define HT_IS_NOT_MII_PORT(port_no)     (1)

/* ================================================================= *
 * register access
 * ================================================================= */
#define HT_RD(blk, sub, reg, value) \
{ \
	int rc; \
	if ((rc = ht_rd_wr(B_##blk, sub, R_##blk##_##reg, value, 0)) < 0) \
		return rc; \
}

#define HT_WR(blk, sub, reg, value) \
{ \
	int rc; \
	ulong   val = value; \
	if ((rc = ht_rd_wr(B_##blk, sub, R_##blk##_##reg, &val, 1)) < 0) \
		return rc; \
}

#define HT_WRM(blk, sub, reg, value, mask) \
{ \
	int rc; \
	if ((rc = ht_wrm(B_##blk, sub, R_##blk##_##reg, value, mask)) < 0) \
		return rc; \
}

#define HT_RDF(blk, sub, reg, offset, mask, value) \
{ \
	int rc; \
	if ((rc = ht_rdf(B_##blk, sub, R_##blk##_##reg, offset, mask, value)) < 0) \
		return rc; \
}

#define HT_WRF(blk, sub, reg, offset, mask, value) \
{ \
	int rc; \
	if ((rc = ht_wrf(B_##blk, sub, R_##blk##_##reg, offset, mask, value)) < 0) \
		return rc; \
}

/* Write ACE data and mask */
#define HT_ACE_WR(reg, data, mask) \
{ \
	int rc; \
	ulong val = data; \
	ulong msk = ~(mask); \
	if ((rc = ht_rd_wr(B_ACL, S_ACL, R_ACL_##reg + ACE_DATA_OFFS, &val, 1)) < 0) \
		return rc; \
	if ((rc = ht_rd_wr(B_ACL, S_ACL, R_ACL_##reg + ACE_MASK_OFFS, &msk, 1)) < 0) \
		return rc; \
}

int ht_rd_wr(uint blk, uint sub, uint reg, ulong *value, int do_write);
int ht_rd(uint blk, uint sub, uint reg, ulong *value);
int ht_wr(uint blk, uint sub, uint reg, ulong value);
int ht_wrm(uint blk, uint sub, uint reg, ulong value, ulong mask);
int ht_rdf(uint blk, uint sub, uint reg, uint offset, ulong mask, ulong *value);
int ht_wrf(uint blk, uint sub, uint reg, uint offset, ulong mask, ulong value);
int ht_phy_readwrite(int do_write, uint miim_controller,
		     uint phy_addr, uint phy_reg, ushort *value);

int ht_vlan_table_idle(void);
int ht_vlan_table_clear(void);
int ht_mac_table_idle(void);
int ht_arbiter_empty_allports(int *empty);

/* CPU interface reset */
#ifdef CONFIG_VTSS_CPU_FRAME
int ht_cpu_frame_reset(void);
#else
static inline int ht_cpu_frame_reset(void) { return 0; }
#endif

#ifdef CONFIG_VTSS_ACL
int ht_acl_reset_port(uint port_on_chip);
#else
static inline int ht_acl_reset_port(uint port_on_chip) { return 0; };
#endif

/* Calculate packet rate register field */
ulong calc_packet_rate(vtss_packet_rate_t rate, ulong *unit);

/* Convert from vtss_pgid_no to destination index on chip */
uint ht_pgid2chip(const vtss_pgid_no_t pgid_no);
/* Convert from destination index on chip to vtss_pgid_no */
vtss_pgid_no_t ht_chip2pgid(const uint chip_pgid);
/* Convert from vtss_port_no list to chip port bitfield, */
ulong vtss_port_array2mask(const BOOL member[VTSS_PORT_ARRAY_SIZE]);

#endif
