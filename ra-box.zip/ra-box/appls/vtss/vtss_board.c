#include "vtss_priv.h"
#include "vtss_grocx.h"

static BOOL vtss_mac_age_started = FALSE;

static void __vtss_port_setup(vtss_port_no_t port_no, BOOL conf);

/* ================================================================= *
 *  Board specific functions
 * ================================================================= */
/* Board port map */
static vtss_mapped_port_t vtss_port_map[VTSS_PORT_ARRAY_SIZE] = { 
	{ 0, VTSS_MIIM_CONTROLLER_0, 0 },     /* 0: Internal PHY */
	{ 0, VTSS_MIIM_CONTROLLER_0, 1 },     /* 1: Internal PHY */
	{ 0, VTSS_MIIM_CONTROLLER_0, 2 },     /* 2: Internal PHY */
	{ 0, VTSS_MIIM_CONTROLLER_0, 3 },     /* 3: Internal PHY */
	{ 0, VTSS_MIIM_CONTROLLER_NONE, -1 }, /* 4: Internal GMII */
#ifdef CONFIG_VTSS_BOARD_GROCX_REF
	{ 0, VTSS_MIIM_CONTROLLER_1, 0 },     /* 5: (R)GMII (WAN) */
#if (VTSS_PORTS == 7)
	{ 0, VTSS_MIIM_CONTROLLER_NONE, -1 }, /* 6: Internal GMII or external RGMII (WiFi) */
#endif /* VTSS_PORTS == 7 */
#endif
};

#ifdef CONFIG_VTSS_ROUTER
/* Determine if port is first router port */
static BOOL vtss_router_port_0(vtss_port_no_t port_no)
{
#ifdef CONFIG_VTSS_GROCX
	return port_no == 4;
#endif
}

/* Determine if port is second router port */
static BOOL vtss_router_port_1(vtss_port_no_t port_no)
{
#ifdef CONFIG_VTSS_GROCX
	return (port_no == 6 && 
		vtss_port_map[port_no].miim_controller == VTSS_MIIM_CONTROLLER_NONE);
#endif
}

/* determine if port is router port */
static BOOL vtss_router_port(vtss_port_no_t port_no)
{
	return (vtss_router_port_0(port_no) || vtss_router_port_1(port_no));
}
#endif

/* Determine port MAC interface */
static int board_port_mac_interface(vtss_port_no_t port_no)
{
	int if_type;
	
	/* Determine interface type */
#ifdef CONFIG_VTSS_GROCX
	if_type = VTSS_PORT_INTERFACE_INTERNAL;
	if (port_no == 5)
		if_type = (VTSS_ROUTER_PORT_5_IF ? VTSS_PORT_INTERFACE_GMII : 
			   VTSS_PORT_INTERFACE_RGMII);
	if (port_no == 6 && !vtss_router_port_1(port_no))
		if_type = VTSS_PORT_INTERFACE_RGMII;
#endif
	
	return if_type;
}

/* Setup port based on configuration and auto negotiation result */
static void __vtss_port_setup(vtss_port_no_t port_no, BOOL conf)
{
	vtss_port_status_t *ps;
	vtss_port_conf_t *pc;
	vtss_port_setup_t setup;
	vtss_phy_setup_t phy;
	
	pc = &vtss_mac_state.port_conf[port_no];
	memset(&setup, 0, sizeof(setup));
	setup.interface_mode.interface_type = board_port_mac_interface(port_no);
	setup.powerdown = (pc->enable ? 0 : 1);
	setup.flowcontrol.smac.addr[5] = port_no;
	setup.maxframelength = pc->max_length;
	setup.frame_gaps.hdx_gap_1 = VTSS_FRAME_GAP_DEFAULT;
	setup.frame_gaps.hdx_gap_2 = VTSS_FRAME_GAP_DEFAULT;
	setup.frame_gaps.fdx_gap = VTSS_FRAME_GAP_DEFAULT;
	
	if (conf) {
		/* Configure port */
		if (vtss_port_map[port_no].miim_controller != VTSS_MIIM_CONTROLLER_NONE) {
			/* Setup PHY */
			phy.mode = (pc->enable ? 
				    (pc->autoneg || pc->speed == VTSS_SPEED_1G ? 
				     VTSS_PHY_MODE_ANEG : VTSS_PHY_MODE_FORCED) : 
				     VTSS_PHY_MODE_POWER_DOWN);
			phy.aneg.speed_10m_hdx = 1;
			phy.aneg.speed_10m_fdx = 1;
			phy.aneg.speed_100m_hdx = 1;
			phy.aneg.speed_100m_fdx = 1;
			phy.aneg.speed_1g_fdx = 1;
			phy.aneg.symmetric_pause = pc->flow_control;
			phy.aneg.asymmetric_pause = pc->flow_control;
			phy.forced.speed = pc->speed;
			phy.forced.fdx = pc->fdx;
			vtss_phy_setup(port_no, &phy);
		}
		/* Use configured values */
		setup.interface_mode.speed = pc->speed;
		setup.fdx = pc->fdx;
		setup.flowcontrol.obey = pc->flow_control;
		setup.flowcontrol.generate = pc->flow_control;
	} else {
		/* Setup port based on auto negotiation status */
		ps = &vtss_mac_state.port_status[port_no];
		setup.interface_mode.speed = ps->speed;
		setup.fdx = ps->fdx;
		setup.flowcontrol.obey = ps->aneg.obey_pause;
		setup.flowcontrol.generate = ps->aneg.generate_pause;
	}
	
#if defined(CONFIG_VTSS_GROCX)
	if (port_no == 5) {
		vtss_grocx_port_conf_t grocx_port_setup;
		
		grocx_port_setup.enable = 1;
		grocx_port_setup.speed = setup.interface_mode.speed;
		grocx_port_setup.fdx = setup.fdx;
		grocx_port_setup.flow_control = setup.flowcontrol.obey;
		
		vtss_grocx_port_setup(port_no, &grocx_port_setup);
		return;
	}
#endif
	vtss_port_setup(port_no, &setup);
}

#ifndef VTSS_FEATURE_MAC_AGE_AUTO
static void vtss_mac_age_timeout(void *eloop_data, void *user_data)
{
	if (vtss_main_config.mac_aging) {
		if (vtss_mac_age_started) {
			/* manually do MAC table aging */
			vtss_mac_table_age();
			eloop_register_timeout(NULL, VTSS_MAC_AGE_DEFAULT/2,
					       0, vtss_mac_age_timeout, NULL, NULL);
		}
	}
}
#endif

static int vtss_port_reset(void)
{
	vtss_port_no_t port_no;
	vtss_phy_reset_setup_t phy_reset;
	vtss_port_conf_t *pc;

	/* reset all ports */
	for (port_no = VTSS_PORT_NO_START;
	     port_no < VTSS_PORT_NO_END; port_no++) {
		vtss_mac_state.port_status[port_no].link = 0;
		
		/* default port configuration */
		pc = &vtss_mac_state.port_conf[port_no];
		pc->enable = 1;
		pc->autoneg = 0;
		pc->speed = VTSS_SPEED_1G;
		pc->fdx = 1;
		pc->flow_control = 0;
		pc->max_length = VTSS_MAXFRAMELENGTH_STANDARD;
		vtss_mac_state.port_poll[port_no] = 1;

		if (port_no >= 0 && port_no <= 4) {
			net_register_port(port_no + 1, port_no, "vtss");
		}
		
		if (vtss_port_map[port_no].miim_controller == VTSS_MIIM_CONTROLLER_NONE) {
			/* no PHY */
			/* setup for 1G, full duplex,
			 * flow control disabled
			 */
			vtss_port_stp_state_set(port_no, VTSS_STP_STATE_ENABLED);
			vtss_mac_state.port_poll[port_no] = 0;
			net_unregister_port(port_no);
		} else {
			/* reset PHY */
			pc->autoneg = 1;
			pc->flow_control = 1;
			phy_reset.mac_if = board_port_mac_interface(port_no);
			phy_reset.rgmii.rx_clk_skew_ps = 1800;
			phy_reset.rgmii.tx_clk_skew_ps = 1800;
			phy_reset.media_if = VTSS_PHY_MEDIA_INTERFACE_COPPER;
			vtss_phy_reset_port(port_no, &phy_reset);
		}

#ifdef CONFIG_VTSS_GROCX
		/* set WAN port phy 8601 RGMII skew value to 2.0ns */
		/* vtss_phy_page_ext(1); */
		vtss_phy_write(1, 31, 0x1);
		vtss_phy_writemasked(1, 28, 0xf000, 0xf000);    
		vtss_phy_write(1, 31, 0x0);
		/* vtss_phy_page_std(1); */       
#endif
#ifdef CONFIG_VTSS_ROUTER
		if (vtss_router_port(port_no)) {
			/* setup for 1G, full duplex, always up */
#ifdef CONFIG_VTSS_ROUTER_PORT_FLOW_CONTROL
			pc->flow_control = 1;
#endif
			vtss_port_stp_state_set(port_no, VTSS_STP_STATE_ENABLED);
			vtss_mac_state.port_poll[port_no] = 0;
			net_unregister_port(port_no);

			/* disable ACL on router port */
			vtss_acl_reset_port(port_no);
		}
#endif
		__vtss_port_setup(port_no, 1);
	}

	return 0;
}

void vtss_mac_age_start(void)
{
	if (vtss_main_config.mac_aging) {
#ifdef VTSS_FEATURE_MAC_AGE_AUTO
		/* automatic aging used */
		vtss_mac_table_age_time_set(vtss_main_config.mac_aging);
		vtss_mac_age_started = 0;
#else
		/* manual aging used */
		eloop_register_timeout(NULL, 0, 0, vtss_mac_age_timeout, NULL, NULL);
		vtss_mac_age_started = 1;
#endif
	}
}

void vtss_mac_age_stop(void)
{
	if (!vtss_main_config.mac_aging) {
#ifdef VTSS_FEATURE_MAC_AGE_AUTO
		/* automatic aging used */
		vtss_mac_table_age_time_set(0);
#else
		/* manual aging used */
		eloop_cancel_timeout(NULL, vtss_mac_age_timeout, NULL, NULL);
#endif
		vtss_mac_age_started = 0;
	}
}

static void cpu_frame_rx(void);
int vtss_test_cpu_start(void);
int vtss_set_rx_map(void);
int vtss_add_test_mac_entry(void);
void test_cpu_rx(void);


static void vtss_port_update(void *eloop_data, void *user_data)
{
	vtss_port_status_t status;
	vtss_port_status_t *ps;
	BOOL link_old;
	vtss_port_no_t port_no = (vtss_port_no_t)user_data;

	if (!vtss_mac_state.port_poll[port_no])
		goto next;

	/* get current status */
	vtss_port_status_get(port_no, &status);
	ps = &vtss_mac_state.port_status[port_no];
	link_old = ps->link;
	ps->link = status.link;
	ps->speed = status.speed;
	ps->fdx = status.fdx;
	ps->aneg.obey_pause = status.aneg.obey_pause;
	ps->aneg.generate_pause = status.aneg.generate_pause;
	
	/* detect link down and disable port */
	if ((!status.link || status.link_down) && link_old) {
		vtss_log(VTSS_LOG_INFO,
			 "SWITCH: link down detected, port=%d", port_no);

		net_port_link(port_no, NET_LINK_DOWN);

		vtss_port_stp_state_set(port_no, VTSS_STP_STATE_DISABLED);
		vtss_mac_table_forget_port(port_no);

		vtss_led_update_port(port_no, &status, 0);
	}
	
	/* detect link up and enable port */
	if (status.link && !link_old) { 
		vtss_log(VTSS_LOG_INFO,
			 "SWITCH: link up detected, port=%d", port_no);

		net_port_link(port_no, NET_LINK_UP);

		vtss_port_stp_state_set(port_no, VTSS_STP_STATE_ENABLED);
		if (vtss_mac_state.port_conf[port_no].autoneg)
			__vtss_port_setup(port_no, 0);
		vtss_led_update_port(port_no, &status, 0);
	}
	
	/* detect traffic when link is up */
	if (status.link) {    
		vtss_led_update_port(port_no, &status, 1);
	}

	cpu_frame_rx();
next:
	port_no++;
	if (port_no >= VTSS_PORT_NO_END)
		port_no = VTSS_PORT_NO_START;

	/* 200ms */
	eloop_register_timeout(NULL, 0, 200 * 1000, vtss_port_update, NULL, (void *)port_no);
}

static int vtss_port_start(void)
{
	vtss_port_no_t port_no;

	vtss_led_start();

	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		eloop_register_timeout(NULL, 0, 0, vtss_port_update, NULL, (void *)port_no);
	}
	return 0;
}

int vtss_appl_start(void)
{
	memset(&vtss_mac_state, 0, sizeof(vtss_mac_state_t));
	
	if (vtss_poag_start() ||
	    vtss_vlan_start() ||
	    vtss_ll_start() ||
	    vtss_phy_start() ||
	    /* optional functions */
	    vtss_auth_start() ||
	    vtss_mirror_start() ||
	    vtss_pvlan_start() ||
	    vtss_qos_start() ||
	    vtss_acl_start()) {
		return -1;
	}
    
	if (vtss_vlan_reset() ||
	    vtss_pvlan_reset() ||
	    vtss_cpu_start()) {
		return -1;
	}
	
	/* setup port map for board */
	vtss_port_map_set(vtss_port_map);

	if (vtss_port_reset() ||
	    vtss_qos_reset()) {
		return -1;
	}

	/* start MAC aging daemon */
	vtss_mac_age_start();
	/* start per-port status daemon */
	vtss_port_start();
	return 0;
}

void vtss_appl_stop(void)
{
	vtss_ll_stop();
}
/* Rx frames to CPU */
static void cpu_frame_rx(void) 
{
#if 0
    vtss_system_frame_header_t header;
    uchar                      frame[VTSS_MAXFRAMELENGTH_STANDARD];
    vtss_cpu_rx_queue_t        queue_no;

    for (queue_no=VTSS_CPU_RX_QUEUE_START; queue_no<VTSS_CPU_RX_QUEUE_END; queue_no++) {
        /* Check if frame is ready in Rx queue */
        if (vtss_cpu_rx_frameready(queue_no) <= 0)
            continue;
	printf(">>>>cpu_rx_frameready<<<<\n");
        /* Get frame */
        if (vtss_cpu_rx_frame(queue_no, &header, frame, 
                              VTSS_MAXFRAMELENGTH_STANDARD) != 0)
            continue;
        
	printf("\nIFH:\n");
	printf("frame length=%d, source_port_no=%d, tagged=%d, learn=%d at queue=%d.\n", 
			header.length, header.source_port_no, 
			header.arrived_tagged, header.learn, queue_no);

        /* Process frame */
        {
            int  i;
            char buf[100], *p;

            for (i = 0, p = &buf[0]; i < header.length; i++) {
                if ((i % 16) == 0) {
                    p = &buf[0];
                    p += sprintf(p, "%04x: ", i);
                }
                p += sprintf(p,"%02x%c", frame[i], ((i+9)%16)==0 ? '-' : ' ');
                if (((i+1) % 16) == 0 || (i+1) == header.length) {
                    printf(("%s", buf));
                }
            }
        }
    }
#endif
}

int vtss_test_cpu_start(void)
{
	vtss_cpu_rx_registration_t reg;
	/* Initialize CPU frame registration, enable BPDUs */
	memset(&reg, 0, sizeof(reg));

	reg.bpdu_cpu_only = 1;
	reg.mcast_igmp_cpu_only = 1;

	vtss_cpu_rx_registration_set(&reg);
	return 0;
}

int vtss_set_rx_map(void)
{
	vtss_cpu_rx_queue_map_t map;

	memset(&map, 0, sizeof (vtss_cpu_rx_queue_map_t));

	map.bpdu_queue = 1;      /* BPDUs */
	map.garp_queue = 1;      /* GARP frames */
	map.learn_queue = 1;     /* Learn frames */
	map.igmp_queue = 1;      /* IGMP/MLD frames */
	map.ipmc_ctrl_queue = 1; /* IP multicast control frames */
	map.mac_vid_queue = 1;   /* MAC address table */

	return vtss_cpu_rx_queue_map_set(&map);
}

int vtss_add_test_mac_entry(void)
{
	vtss_vid_mac_t *vid_mac;
	vtss_mac_table_entry_t entry;
	/* PC: 192.168.100.100 */
	unsigned char mac[6] = {0x00, 0xe0, 0x4c, 0x17, 0x05, 0x4f};
	vid_mac = &entry.vid_mac;

	vid_mac->vid = 1;
	memcpy(&vid_mac->mac, mac, 6);
	entry.copy_to_cpu = 1;
	entry.locked = 1;

	if (vtss_ll_mac_table_learn(&entry, 2) == 0)
		return vtss_ll_mac_table_learn(&entry, 0);
	return -1;
}
void test_cpu_rx(void)
{
#if 0
	vtss_test_cpu_start();
	vtss_set_rx_map();
	vtss_add_test_mac_entry();
#endif
}
