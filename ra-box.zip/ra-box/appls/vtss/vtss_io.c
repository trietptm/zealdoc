/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_io.c,v 1.19 2009-03-02 01:34:28 zhenglv Exp $
 $Revision: 1.19 $

*/

#include "vtss_priv.h"

int vtss_io_fd = -1;

/* Reset I/O Layer, must be called before any other function */
void vtss_io_start(void)
{
	if (vtss_io_fd < 0) {
		int fd;
		/* Open driver */
		if ((fd = open(_PATH_VITGENIO, 0)) < 0) {
			vtss_log(VTSS_LOG_ERR, "BOARD: open(/dev/vitgenio) failure");
			return;
		}
		vtss_io_fd = fd;
	}
}

void vtss_io_stop(void)
{
	if (vtss_io_fd >= 0) {
		close(vtss_io_fd);
		vtss_io_fd = -1;
	}
}

static int vtss_io_pi_rd_fast(uint block, uint subblock,
			      const uint reg, ulong *value)
{
	int rc = 0;
	struct vitgenio_32bit_readwrite pibuf;
	
	memset(&pibuf, 0, sizeof (struct vitgenio_32bit_readwrite));
	pibuf.offset = (block << 12) | (subblock << 8) | (reg << 0);
	if (ioctl(vtss_io_fd, VITGENIO_32BIT_READ, (unsigned long)&pibuf) < 0) {
		vtss_log(VTSS_LOG_ERR, "IO: ioctl(VITGENIO_32BIT_READ) failed");
		*value = 0;
		rc = VTSS_IO_READ_ERROR;
	} else {
		*value = pibuf.value;
	}
	return rc;
}

int vtss_io_pi_rd(uint block, uint subblock, const uint reg, ulong * const value)
{
	int rc;
	
	if (block == B_CAPTURE || block == B_SYSTEM) {
		rc = vtss_io_pi_rd_fast(block, subblock, reg, value);
	} else {
		int i;
		ulong val;
		
		if ((rc = vtss_io_pi_rd_fast(block, subblock, reg, &val)) < 0)
			return rc;
		for (i = 0; ; i++) {
			if ((rc = vtss_io_pi_rd_fast(B_SYSTEM, 0, R_SYSTEM_CPUCTRL, &val)) < 0)
				break;
			if (val & (1 << 4)) {
				rc = vtss_io_pi_rd_fast(B_SYSTEM, 0, R_SYSTEM_SLOWDATA, value);
				break;
			}
			if (i == 25) {
				vtss_log(VTSS_LOG_ERR,
					 "IO: DONE failed after %d retries, block=0x%02x, subblock=0x%02x, reg=0x%02x",
					 i, block, subblock, reg);
				rc = VTSS_IO_READ_ERROR;
				break;
			}
		}
	}
	return rc;
}

int vtss_io_pi_wr(uint block, uint subblock, const uint reg, const ulong value)
{
	int rc = 0;
	struct vitgenio_32bit_readwrite pibuf;
	
	pibuf.offset = (block << 12) | (subblock << 8) | (reg << 0);
	pibuf.value = value;
	if (ioctl(vtss_io_fd, VITGENIO_32BIT_WRITE, (unsigned long)&pibuf) < 0) {
		vtss_log(VTSS_LOG_ERR, "IO: ioctl(VITGENIO_32BIT_WRITE) failed");
		rc = VTSS_IO_WRITE_ERROR;
	}
	return rc;
}
