#include "vtss_priv.h"

/* - MAC Table ----------------------------------------------------- */
int vtss_mac_table_flush(void)
{
	return vtss_ll_mac_table_flush(0, 0, 0, 0);
}

int vtss_mac_table_learn(const vtss_mac_table_entry_t * const entry)
{
	int        rc;
	vtss_pgid_no_t pgid_no;
	vtss_port_no_t port_no;
	BOOL           member[VTSS_PORT_ARRAY_SIZE];
	vtss_vid_mac_t vid_mac;
	
	vid_mac = entry->vid_mac;
	
	/* Unlearn entry if it already exists */
	rc = vtss_mac_table_forget_vid_mac(&vid_mac);
	if (rc<0 && rc!=VTSS_ENTRY_NOT_FOUND)
		return rc;
	
	/* Allocate PGID */
	if (
		VTSS_MAC_IPV4_MC(entry->vid_mac.mac.addr)) {
		/* IPv4 multicast address, use pseudo PGID */
		pgid_no = VTSS_PGID_NONE;
	} else {
		if (
			VTSS_MAC_IPV6_MC(entry->vid_mac.mac.addr)) {
			/* IPv6 multicast address, use pseudo PGID */
			pgid_no = VTSS_PGID_NONE;
		} else {
			for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
				member[port_no] = MAKEBOOL01(entry->destination[port_no]);
			if (vtss_pgid_alloc(&pgid_no, 0, member)<0) {
				vtss_log(VTSS_LOG_ERR,
					 "SWITCH: pgid allocation failed");
				return VTSS_UNSPECIFIED_ERROR;
			}
		}
	}
	
	vtss_mac_state.mac_status_appl.learned = 1;
	
	if (pgid_no == VTSS_PGID_NONE) {
		/* IPv4/IPv6 multicast address */
		for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
			vtss_mac_state.pgid_table[pgid_no].member[port_no] = MAKEBOOL01(entry->destination[port_no]);
		for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
			vtss_mac_state.pgid_table[pgid_no].member[port_no] = vtss_pgid_member(pgid_no, port_no);
	}
	
	return vtss_ll_mac_table_learn(entry, pgid_no);
}

#ifdef VTSS_FEATURE_MAC_AGE_AUTO
int vtss_mac_table_age_time_set(const vtss_mac_age_time_t age_time)
{
	return vtss_ll_mac_table_age_time_set(age_time);
}
#endif

int vtss_mac_table_age(void)
{
	return vtss_ll_mac_table_age(0, 0, 0, 0);
}

int vtss_mac_table_age_vlan(const vtss_vid_t vid)
{
	return vtss_ll_mac_table_age(0, 0, 1, vid);
}

int vtss_mac_table_forget_vid_mac(const vtss_vid_mac_t * const vid_mac)
{
	vtss_mac_table_entry_t entry;
	vtss_pgid_no_t         pgid_no;
	
	entry.vid_mac = *vid_mac;
	VTSS_RC(vtss_ll_mac_table_lookup(&entry, &pgid_no));
	
	if (entry.locked && pgid_no != VTSS_PGID_NONE)
		vtss_pgid_free(pgid_no);
	
	vtss_mac_state.mac_status_appl.aged = 1;
	
	return vtss_ll_mac_table_unlearn(vid_mac);
}

int vtss_mac_table_forget_port(const vtss_port_no_t port_no)
{
	return vtss_ll_mac_table_flush(1, port_no, 0, 0);
}

int vtss_mac_table_forget_vlan(const vtss_vid_t vid)
{
	return vtss_ll_mac_table_flush(0, 0, 1, vid);
}

int vtss_mac_table_forget_port_in_vlan(const vtss_port_no_t port_no,
                                           const vtss_vid_t vid)
{
	return vtss_ll_mac_table_flush(1, port_no, 1, vid);
}

/* Set the destination list for a MAC address entry given a PGID */
static void vtss_mac_entry_destination_set(vtss_mac_table_entry_t * const entry, 
                                           vtss_pgid_no_t pgid_no) 
{
	vtss_poag_no_t poag_no;
	
	for (poag_no = VTSS_POAG_NO_START;
	     poag_no < VTSS_POAG_NO_END; poag_no++) {
		if (VTSS_POAG_IS_PORT(poag_no)) {
			entry->destination[poag_no] =
				vtss_pgid_member(pgid_no, poag_no);
		} else {
			entry->destination[poag_no] = 0;
		}
	}
}

int vtss_mac_table_read(const uint idx,
                            vtss_mac_table_entry_t * const entry)
{
	vtss_pgid_no_t pgid_no;
	
	if (idx < VTSS_MAC_ADDR_START || idx > VTSS_MAC_ADDRS) {
		vtss_log(VTSS_LOG_ERR,
			 "SWITCH: illegal idx, idx=%d", idx);
		return VTSS_INVALID_PARAMETER;
	}
	
	VTSS_RC(vtss_ll_mac_table_read(idx, entry, &pgid_no));
	
	/* Update entry->destination list based on pgid_no. */
	vtss_mac_entry_destination_set(entry, pgid_no);
	return 0;
}

int vtss_mac_table_lookup(const vtss_vid_mac_t * const vid_mac,
                              vtss_mac_table_entry_t * const entry)
{
	vtss_pgid_no_t pgid_no;
	
	entry->vid_mac = *vid_mac;
	VTSS_RC(vtss_ll_mac_table_lookup(entry, &pgid_no));
	
	vtss_mac_entry_destination_set(entry, pgid_no);
	return 0;
}

int vtss_mac_table_status_read(void) 
{
	vtss_mac_table_status_t st;
	
	/* Read and clear sticky bits */
	VTSS_RC(vtss_ll_mac_table_status_get(&st));
	
	/* Save API state */
	if (st.learned) {
		vtss_mac_state.mac_status_appl.learned = 1;
	}
	if (st.replaced) {
		vtss_mac_state.mac_status_appl.replaced = 1;
	}
	if (st.moved) {
		vtss_mac_state.mac_status_appl.moved = 1;
	}
	if (st.aged) {
		vtss_mac_state.mac_status_appl.aged = 1;
	}
	return 0;
}

int vtss_mac_table_status_get(vtss_mac_table_status_t * const status) 
{
	VTSS_RC(vtss_mac_table_status_read());
	
	/* Use API event state */
	if (vtss_mac_state.mac_status_appl.learned) {
		vtss_mac_state.mac_status_appl.learned = 0;
		status->learned = 1;
	}
	if (vtss_mac_state.mac_status_appl.replaced) {
		vtss_mac_state.mac_status_appl.replaced = 0;
		status->replaced = 1;
	}
	if (vtss_mac_state.mac_status_appl.moved) {
		vtss_mac_state.mac_status_appl.moved = 0;
		status->moved = 1;
	}
	if (vtss_mac_state.mac_status_appl.aged) {
		vtss_mac_state.mac_status_appl.aged = 0;
		status->aged = 1;
	}
	return 0;
}

int vtss_mac_table_get_next(const vtss_vid_mac_t * const   vid_mac,
			    vtss_mac_table_entry_t * const entry)
{
	int rc = VTSS_ENTRY_NOT_FOUND;
	vtss_pgid_no_t         pgid_no;
	vtss_mac_table_entry_t mac_entry;

	/* Do get next operation in chip */
	if (vtss_ll_mac_table_get_next(vid_mac, &mac_entry, &pgid_no) == 0) {
		vtss_mac_entry_destination_set(&mac_entry, pgid_no);
		*entry = mac_entry;
		rc = 0;
	}
	
	return rc;
}
