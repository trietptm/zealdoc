#include "vtss_priv.h"
#include <vtss_auth.h>

#ifdef CONFIG_VTSS_AUTH

int vtss_auth_state[VTSS_PORT_ARRAY_SIZE];

int vtss_port_auth_state_get(const vtss_port_no_t port_no)
{
	return vtss_auth_state[port_no];
}

int vtss_port_auth_state_set(const vtss_port_no_t port_no,
			     const int auth_state)
{
	BOOL dest_update = 0;
	
	/* Check that the port number is valid */
	if (!(VTSS_PORT_IS_PORT(port_no))) {
		vtss_log(VTSS_LOG_ERR,
			 "SWITCH: illegal port, port=%d", port_no);
		return VTSS_INVALID_PARAMETER;
	}
	
	/* Check that the Authentication state is valid */
	switch (auth_state) {
	case VTSS_AUTH_STATE_NONE:
	case VTSS_AUTH_STATE_EGRESS:
	case VTSS_AUTH_STATE_BOTH:
		break;
	default:
		vtss_log(VTSS_LOG_ERR,
			 "SWITCH: illegal auth state, state=%d", auth_state);
		return VTSS_INVALID_PARAMETER;
		break;
	}
	
	vtss_auth_state[port_no] = auth_state; 
	return vtss_update_masks(1, dest_update, 1);
}

int vtss_auth_start(void)
{
	vtss_port_no_t port_no;

	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		vtss_auth_state[port_no] = VTSS_AUTH_STATE_BOTH;
	}
	return 0;
}
#endif
