#include "vtss_priv.h"

int vtss_poag_start(void)
{
	vtss_port_no_t chip_port;
	vtss_port_no_t port_no;

	/* Initialize port map table */
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		chip_port = port_no-VTSS_PORT_NO_START;
		//vtss_mac_state.port_map.chip_port[port_no] = chip_port;
		//vtss_mac_state.port_map.vtss_port[chip_port] = port_no;
	}
	
	/* Initialize aggregations */
	for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
		vtss_mac_state.port_poag_no[port_no] = port_no;
	}
	return 0;
}
