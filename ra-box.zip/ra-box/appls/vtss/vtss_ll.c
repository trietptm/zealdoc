#include "vtss_priv.h"
#include "vtss_heathrow.h"

/* Read from the phy register */
int vtss_ll_phy_read(uint miim_controller, uint phy_addr,
		     uint phy_reg, ushort *value)
{
	return ht_phy_readwrite(0, miim_controller, phy_addr, phy_reg, value);
}

/* Write to the phy register */
int vtss_ll_phy_write(uint miim_controller, uint phy_addr,
		      uint phy_reg, ushort value)
{
	return ht_phy_readwrite(1, miim_controller, phy_addr, phy_reg, &value);
}

/* PI/SI register read */
int vtss_ll_register_read(ulong reg, ulong *value)
{
	return ht_rd((reg>>12) & 0x7, (reg>>8) & 0xF, reg & 0xFF, value);
}

/* PI/SI register write */
int vtss_ll_register_write(ulong reg, ulong value)
{
	return ht_wr((reg>>12) & 0x7, (reg>>8) & 0xF, reg & 0xFF, value);
}

/* Read port counters */
int vtss_ll_port_counters_get(uint port_no, vtss_chip_counters_t * counters)
{
	ulong value;
	
	/* Counter base address */
#define COUNTER_BASE 0x1800
	
	/* Read Rx counters in 32-bit mode */
	HT_WR(PORT, port_no, C_CNTADDR, (1<<31) | (COUNTER_BASE<<0));
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_octets);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_packets);
	HT_RD(PORT, port_no, C_CNTDATA, &value); /* c_rxbcmc */
	HT_RD(PORT, port_no, C_CNTDATA, &value); /* c_rxbadpkt */
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_broadcasts);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_multicasts);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_64);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_65_127);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_128_255);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_256_511);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_512_1023);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_1024_1526);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_1527_max);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_pauses);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_drops);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_local_drops);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_classified_drops);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_crc_align_errors);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_shorts);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_longs);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_fragments);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_jabbers);
	HT_RD(PORT, port_no, C_CNTDATA, &value); /* c_rxctrl */
	HT_RD(PORT, port_no, C_CNTDATA, &value); /* c_rxgoodpkt */
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_class[0]);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_class[1]);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_class[2]);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_class[3]);
	HT_RD(PORT, port_no, C_CNTDATA, &value); /* c_rxtotdrop */
	HT_RD(PORT, port_no, C_CNTDATA, &counters->rx_unicast);
	
	/* Read Tx counters in 32-bit mode */
	HT_WR(PORT, port_no, C_CNTADDR, (1<<31) | ((COUNTER_BASE+0x40)<<0));
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_octets);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_packets);
	HT_RD(PORT, port_no, C_CNTDATA, &value); /* c_txbcmc */
	HT_RD(PORT, port_no, C_CNTDATA, &value); /* c_txbadpkt */
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_broadcasts);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_multicasts);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_64);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_65_127);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_128_255);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_256_511);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_512_1023);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_1024_1526);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_1527_max);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_pauses);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_fifo_drops);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_drops);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_collisions);
	HT_RD(PORT, port_no, C_CNTDATA, &value); /* c_txcfidrop */
	HT_RD(PORT, port_no, C_CNTDATA, &value); /* c_txgoodpkt */
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_class[0]);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_class[1]);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_class[2]);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_class[3]);
	HT_RD(PORT, port_no, C_CNTDATA, &value); /* c_txtotdrop */
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_unicast);
	HT_RD(PORT, port_no, C_CNTDATA, &counters->tx_aging);
	return 0;
}
