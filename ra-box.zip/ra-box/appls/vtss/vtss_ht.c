#include "vtss_priv.h"

/* Read target register using current CPU interface */
int ht_rd_wr(uint blk, uint sub, uint reg, ulong *value, int do_write)
{
	int rc;
	int error;
	
	switch (blk) {
	case B_PORT:
		/* By default, it is an error if the sub block is not included in chip port mask */
		error = ((sub > VTSS_CHIP_PORTS) ||
			(VTSS_CHIP_PORTMASK & (1<<sub)) == 0);
		if (sub == VTSS_CHIP_PORT_CPU)
			error = 0;
		if (error)
			break;
		if (sub >= 16) {
			blk = B_PORT_HI;
			sub -= 16;
		}
		break;
	case B_MIIM: /* B_MEMINIT/B_ACL/B_VAUI */
		error = (sub > S_ACL);
		break;
	case B_CAPTURE:
		error = 0;
		break;
	case B_ANALYZER:
	case B_ARBITER:
	case B_SYSTEM:
		error = (sub != 0);
		break;
	case B_PORT_HI: /* vtss_ll_register_read/write may access this directly */
		error = 0;
		break;
	default:
		error = 1;
		break;
	}
	
	if (error) {
		vtss_log(VTSS_LOG_ERR,
			 "SPARX: illegal access, blk=0x%02x, sub=0x%02x, reg=0x%02x",
			 blk, sub, reg);
		return VTSS_INVALID_PARAMETER;
	}
	
	if (do_write)
		rc = vtss_io_pi_wr(blk, sub, reg, *value);
	else
		rc = vtss_io_pi_rd(blk, sub, reg, value);
	return rc;
}

/* Read target register using current CPU interface */
int ht_rd(uint blk, uint sub, uint reg, ulong *value)
{
	return ht_rd_wr(blk, sub, reg, value, 0);
}

/* Write target register using current CPU interface */
int ht_wr(uint blk, uint sub, uint reg, ulong value)
{
	return ht_rd_wr(blk, sub, reg, &value, 1);
}

/* Read-modify-write target register using current CPU interface */
int ht_wrm(uint blk, uint sub, uint reg, ulong value, ulong mask)
{
	int rc;
	ulong val;
	
	if ((rc = ht_rd_wr(blk, sub, reg, &val, 0))>=0) {
		val = ((val & ~mask) | (value & mask));
		rc = ht_rd_wr(blk, sub, reg, &val, 1);
	}
	return rc;
}

/* Read target register field using current CPU interface */
int ht_rdf(uint blk, uint sub, uint reg, uint offset, ulong mask, ulong *value)
{
	int rc;
	
	rc = ht_rd_wr(blk, sub, reg, value, 0);
	*value = ((*value >> offset) & mask);
	return rc;
}

/* Read-modify-write target register field using current CPU interface */
int ht_wrf(uint blk, uint sub, uint reg, uint offset, ulong mask, ulong value)
{
	return ht_wrm(blk, sub, reg, value<<offset, mask<<offset);
}

/* ================================================================= *
 * MII management
 * ================================================================= */
/* returns (ushort) result or (long) <0 */
int ht_phy_readwrite(int do_write, uint miim_controller,
		     uint phy_addr, uint phy_reg, ushort *value)
{
	ulong data;
	
	/* Enqueue MIIM operation to be executed */
	HT_WR(MIIM, miim_controller, MIIMCMD,
	      ((do_write ? 0 : 1) << 26) | (phy_addr << 21) | (phy_reg << 16) | *value);
	
	/* Wait for MIIM operation to finish */
	while (1) {
		HT_RD(MIIM, miim_controller, MIIMSTAT, &data);
		if (!(data & 0xF)) /* Include undocumented "pending" bit */
			break;
	}
	if (!do_write) {
		HT_RD(MIIM, miim_controller, MIIMDATA, &data);
		if (data & (1<<16))
			return VTSS_PHY_READ_ERROR;
		*value = (ushort)(data & 0xFFFF);
	}
	return 0;
}

int ht_vlan_table_idle(void)
{
	ulong cmd;
	
	while (1) {
		HT_RDF(ANALYZER, 0, VLANACES, 0, 0x3, &cmd);
		if (cmd == VLAN_CMD_IDLE)
			break;
	}
	return 0;
}

/* Clear VLAN table (by default all ports are members of all VLANs) */
int ht_vlan_table_clear(void)
{
	vtss_vid_t vid;
	
	for (vid = VTSS_VID_NULL; vid < VTSS_VIDS; vid++) {
		HT_WR(ANALYZER, 0, VLANTINDX, vid<<0);
		HT_WR(ANALYZER, 0, VLANACES, VLAN_CMD_WRITE<<0);
		VTSS_RC(ht_vlan_table_idle());
	}
	return 0;
}

int ht_mac_table_idle(void)
{
	ulong cmd;
	
	while (1) {
		HT_RDF(ANALYZER, 0, MACACCES, 0, 0x7, &cmd);
		if (cmd == MAC_CMD_IDLE)
			break;
	}
	return 0;
}

int ht_arbiter_empty_allports(int *empty)
{
	ulong value;
	
	HT_RD(ARBITER, 0, ARBEMPTY, &value);
	*empty = ((value) == ((1<<VTSS_PORTS)-1)<<1);
	return 0; 
}
