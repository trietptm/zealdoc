#ifndef __STAR_PRIV_H_INCLUDE__
#define __STAR_PRIV_H_INCLUDE__

#include <star.h>
#include <logger.h>
#include <getline.h>
#include <strutl.h>
#include <fsserv.h>
#include <service.h>
#include <netsvc.h>
#include <netphy.h>
#include <module.h>

#include <linux/sockios.h>
#include <linux/star_switch_api.h>

#define STAR_WAN_DEVICE		"wan"
#define STAR_LAN_DEVICE		"lan"

#define STAR_SERVICE_DESC	"Starsemi appliance"

#endif /* __STAR_PRIV_H_INCLUDE__ */
