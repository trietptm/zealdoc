/*
 * Copyright (c) 1990, 1993, 1994, 1995, 1996
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that: (1) source code distributions
 * retain the above copyright notice and this paragraph in its entirety, (2)
 * distributions including binary code include the above copyright notice and
 * this paragraph in its entirety in the documentation or other materials
 * provided with the distribution, and (3) all advertising materials mentioning
 * features or use of this software display the following acknowledgement:
 * ``This product includes software developed by the University of California,
 * Lawrence Berkeley Laboratory and its contributors.'' Neither the name of
 * the University nor the names of its contributors may be used to endorse
 * or promote products derived from this software without specific prior
 * written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

#include "pcap-int.h"

static inline int xdtoi(int);
static inline int skip_space(FILE *);
static inline int skip_line(FILE *);

/* Hex digit to integer. */
static inline int xdtoi(int c)
{
	if (isdigit(c))
		return c - '0';
	else if (islower(c))
		return c - 'a' + 10;
	else
		return c - 'A' + 10;
}

static inline int skip_space(FILE *f)
{
	int c;

	do {
		c = getc(f);
	} while (isspace(c) && c != '\n');

	return c;
}

static inline int skip_line(FILE *f)
{
	int c;

	do
		c = getc(f);
	while (c != '\n' && c != EOF);

	return c;
}

#ifdef WIN32
typedef struct _PACKET_OID_DATA PACKET_OID_DATA, *PPACKET_OID_DATA;
#define OID_802_3_CURRENT_ADDRESS		   		0x01010102

int pcap_getether(pcap_if_t *dev, uint8_t *ether)
{
	PPACKET_OID_DATA pOidData;
	LPADAPTER lpAdapter=NULL;
	CHAR *pStr;

	pStr = malloc(sizeof(PACKET_OID_DATA)+128);
	ZeroMemory(pStr, sizeof(PACKET_OID_DATA)+128);
	pOidData = (PPACKET_OID_DATA) pStr;
	pOidData->Oid = OID_802_3_CURRENT_ADDRESS;
	pOidData->Length = 6;

	lpAdapter = PacketOpenAdapter(dev->name);
	if (!lpAdapter)
		return -1;
	if (!PacketRequest(lpAdapter, FALSE, pOidData))
		return -1;

	memcpy(ether, pOidData->Data, 6);
	return 0;
}
#endif
