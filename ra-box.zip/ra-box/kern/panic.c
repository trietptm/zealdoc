#include <panic.h>
#include <logger.h>

void __panic(const char *file, int line)
{
	printf("\n\nsystem panic:\n"
	       "file: %s\n"
	       "line: %d\n\n",
	       file, line);
	while (1) sleep(1);
}

