#include <secret.h>
#include <strutl.h>
#include <smartcard/pkcs15.h>
#include <smartcard/errors.h>
#ifdef WIN32
#include <conio.h>
#endif
#include "secret_priv.h"

/* TLV format in the card
	+---+---+---+---+---+---+--------+---+---+-----+----+---+-------+---+---+--------+-----------
	|'S'| L1|id | L2|'D'| L | Domain |'U'| L |User |'F' | L | Format|'P'| L |Password| ... ...
	+---+---+---+---+---+---+--------+---+---+-----+----+---+-------+---+---+--------+-----------
		|	|<----------------------------L2-------------------------------->|
		|<----------------------------------L1(one entry)----------------------->|<---other entries---
 */
#define SC_PKCS15_DATA_SECRET_TAG	'S'

#define SECRET_DOMAIN_TAG	'D'
#define SECRET_USER_TAG		'U'
#define SECRET_FORMAT_TAG	'F'
#define SECRET_PWD_TAG		'P'

#define SCARD_READER_ID		0
#define SCARD_SLOT_ID		0
#define SC_PKCS15_SECRET_APPOID	"1.1.1"

struct secret_scard_trans {
	sc_context_t *ctx;
	sc_card_t *card ;
	struct sc_pkcs15_card *p15card;

	int reader_idx;
	int slot_idx;
};

struct sc_secret_entry {
	uint8_t id;
	uint8_t len;	/*Do not contain id and len*/

	const char *domain;
	const char *user;
	const char *format;
	char secret[MAX_SECRET_LEN];
};

static char *getpass(const char *prompt)
{
	static char buf[128];
	size_t i;

	fputs(prompt, stderr);
	fflush(stderr);

	for (i = 0; i < sizeof(buf) - 1; i++) {
		buf[i] = _getch();
		if (buf[i] == '\r')
			break;
	}
	buf[i] = 0;
	fputs("\n", stderr);

	return buf;
}

static uint8_t * get_pin(const char *prompt, sc_pkcs15_object_t *pin_obj)
{
	sc_pkcs15_pin_info_t *pinfo = (sc_pkcs15_pin_info_t *) pin_obj->data;
	char buf[80];
	char *pincode;
	
	sprintf(buf, "%s [%s]: ", prompt, pin_obj->label);
	while (1) {
		pincode = getpass(buf);
		if (strlen(pincode) == 0)
			return NULL;
		if (strlen(pincode) < pinfo->min_length) {
			printf("PIN code too short, try again.\n");
			continue;
		}
		if (strlen(pincode) > pinfo->max_length) {
			printf("PIN code too long, try again.\n");
			continue;
		}
		return (uint8_t *) strdup(pincode);
	}
}

static int authenticate(struct secret_scard_trans *scard_trans,
			sc_pkcs15_object_t *obj)
{
	sc_pkcs15_pin_info_t	*pin_info;
	sc_pkcs15_object_t	*pin_obj;
	uint8_t			*pin;
	int			r;

	if (obj->auth_id.len == 0)
		return 0;
	r = sc_pkcs15_find_pin_by_auth_id(scard_trans->p15card, 
					  &obj->auth_id, &pin_obj);
	if (r)
		return r;

	pin_info = (sc_pkcs15_pin_info_t *) pin_obj->data;
	pin = get_pin("Please enter PIN", pin_obj);

	return sc_pkcs15_verify_pin(scard_trans->p15card, pin_info,
			pin, pin? strlen((char *) pin) : 0);
}

static int connect_card(struct secret_scard_trans *scard_trans)
{
	int reader_count;
	struct sc_card *cp;
	struct sc_reader *reader;
	int r;

	reader_count = sc_ctx_get_reader_count(scard_trans->ctx);
	if ( reader_count == 0) {
		log_kern(LOG_ERR, "There is no smart card reader.");
		return -1;
	}
	if (scard_trans->reader_idx >= reader_count) {
		log_kern(LOG_ERR, "Illegal reader id.");
		return -1;		
	}
	reader = sc_ctx_get_reader(scard_trans->ctx, scard_trans->reader_idx);
	if (sc_detect_card_presence(reader, scard_trans->slot_idx) <= 0) {
		log_kern(LOG_ERR, "Card not present.\n");
		return -1;
	}
	if ((r = sc_connect_card(reader, scard_trans->slot_idx, &cp)) < 0) {
		log_kern(LOG_ERR, "Card not present.\n");
		return r;
	}
	if ((r = sc_lock(cp)) < 0) {
		log_kern(LOG_ERR, "Failed to lock card.\n");
		sc_disconnect_card(cp, 0);
		return -1;
	}	
	scard_trans->card = cp;

	return 0;
}

static void secret_scard_stop_trans(void *trans)
{
	struct secret_scard_trans *scard_trans = (struct secret_scard_trans *)trans;

	if (!scard_trans) return;
	if (scard_trans->p15card)
		sc_pkcs15_unbind(scard_trans->p15card);
	if (scard_trans->card) {
		sc_unlock(scard_trans->card);
		sc_disconnect_card(scard_trans->card, scard_trans->slot_idx);
	}
	if (scard_trans->ctx)
		sc_release_context(scard_trans->ctx);
}

static void *secret_scard_start_trans(void)
{
	int r;
	sc_context_param_t ctx_param;
	struct secret_scard_trans *scard_trans = NULL;

	scard_trans = malloc(sizeof(*scard_trans));
	if (!scard_trans)
		return NULL;
	memset(scard_trans, 0, sizeof(*scard_trans));
	scard_trans->reader_idx = SCARD_READER_ID;
	scard_trans->slot_idx = SCARD_SLOT_ID;

	memset(&ctx_param, 0, sizeof(ctx_param));
	ctx_param.ver      = 0;
	ctx_param.app_name = "Secret";
	r = sc_context_create(&scard_trans->ctx, &ctx_param);
	if (r < 0) goto err;

	r = connect_card(scard_trans);
	if (r != 0) goto err;
	
	r = sc_pkcs15_bind(scard_trans->card, &scard_trans->p15card);
	if (r) goto err;

	return scard_trans;
err:

	if (scard_trans) {
		secret_scard_stop_trans(scard_trans);
		free(scard_trans);
		scard_trans = NULL;
	}

	return NULL;
}

static int decode_secret_entry(const uint8_t *entry, size_t len, 
			       struct sc_secret_entry *record)
{
	uint8_t T, L;
	const uint8_t *V, *p = entry;
	secret_t sec;

	memset(record, 0, sizeof(*record));

	record->id = *p++;
	record->len = *p++;

	if ((unsigned int)(record->len + 2) < len)
		return -1;
	memset(&sec, 0, sizeof(sec));
	while ((size_t)(p - entry) < record->len) {
		T = *p++;
		L = *p++;
		V = p;
		switch (T) {
		case SECRET_DOMAIN_TAG:
			record->domain = V;
			break;
		case SECRET_USER_TAG:
			record->user = V;
			break;
		case SECRET_FORMAT_TAG:
			record->format = V;
			break;
		case SECRET_PWD_TAG:
			strcpy(record->secret, V);
			break;
		default:
			return -1;
		}
		p += L;
	}

	return 0;
}

static int encode_secret_entry(struct sc_secret_entry *record,
			       uint8_t *entry, size_t *len)
{
	uint8_t *p = entry;
	size_t L;

	*p++ = record->id;
	*p++ = record->len;

	*p++ = SECRET_DOMAIN_TAG;
	L = strlen (record->domain) ;
	*p++ = (uint8_t) L + 1;
	memcpy(p, record->domain, L);
	p += L;
	*p++ = '\0';
	
	*p++ = SECRET_USER_TAG;
	L = strlen (record->user);
	*p++ = (uint8_t)L + 1;
	memcpy(p, record->user, L);
	p += L;
	*p++ = '\0';

	*p++ = SECRET_FORMAT_TAG;
	L = strlen (record->format);
	*p++ = (uint8_t) L + 1;
	memcpy(p, record->format, L);
	p += L;
	*p++ = '\0';

	*p++ = SECRET_PWD_TAG;
	L = strlen (record->secret);
	*p++ = (uint8_t) L + 1;
	memcpy(p, record->secret, L);
	p += L;
	*p++ = '\0';
	
	/*Reset the entry(id)'s length*/
	entry[1] = (uint8_t)(p - entry - 2);

	*len = p - entry;

	return 0;
}

static int search_secret(const uint8_t *data, size_t data_len, 
			  struct sc_secret_entry *record)
{
	int r;
	const uint8_t *p = data;
	size_t plen = data_len;
	struct sc_secret_entry rcd;

	if (*p++ != SC_PKCS15_DATA_SECRET_TAG)
		return -1;
	*p++;
	plen -= 2;

	while(plen > 0) {
		memset(&rcd, 0, sizeof(rcd));
		r= decode_secret_entry(p, plen, &rcd);
		if (r != 0)
			return r;
		if (!strcmp(record->domain, rcd.domain) 
			&& !strcmp(record->user, rcd.user)
			&& !strcmp(record->format, rcd.format)) {
			strcpy(record->secret, rcd.secret);
			return 0;
		}
		p += rcd.len + 2;
		plen -= rcd.len + 2;
	}
	
	return -1;
}

static int load_secret(struct secret_scard_trans *scard_trans,
		       const char *appoid, uint8_t **data, size_t *data_len)
{
	int r, i, count, oid_len = 0;
	struct sc_pkcs15_object *objs[32];
	struct sc_object_id      oid;

	r = sc_pkcs15_get_objects(scard_trans->p15card, 
				  SC_PKCS15_TYPE_DATA_OBJECT, objs, 32);
	if (r < 0) {
		log_kern(LOG_ERR, "Data object enumeration failed");
		return r;
	}
	count = r;

	r = sc_format_oid(&oid, appoid);
	if (r == SC_SUCCESS) {
		while (oid.value[oid_len] >= 0) oid_len++;
	}
	if (oid_len == 0) 
		return -1;

	for (i = 0; i < count; i++) {
		struct sc_pkcs15_data_info *cinfo = (struct sc_pkcs15_data_info *) objs[i]->data;
		struct sc_pkcs15_data *data_object;
		
		if (memcmp(oid.value, cinfo->app_oid.value, sizeof(int) * oid_len))
			continue;
		r = authenticate(scard_trans, objs[i]);
		if (r < 0) {
			log_kern(LOG_ERR, "Authentication error");
			return r;
		}
		r = sc_pkcs15_read_data_object(scard_trans->p15card,
					       cinfo, &data_object);
		if (r) {
			if (r == SC_ERROR_FILE_NOT_FOUND) 
				continue;
			else
				return r;
		}
		*data = malloc(data_object->data_len);
		if (*data == NULL)
			return -1;
		memcpy(*data, data_object->data, data_object->data_len);
		*data_len = data_object->data_len;
		sc_pkcs15_free_data_object(data_object);
		return 0;
	}
	
	log_kern(LOG_DEBUG, "There is not secret in the card");
	return -1;
}


static int update_secret(struct secret_scard_trans *scard_trans,
			 struct sc_file *filp,
			 const uint8_t *data, size_t data_len)
{
	return 0;	

}
/*
static int secret_scard_save_passwd(const char *lname, const char *rname,
			   const char *format,
			   uint8_t *secret, int len)
{
	int r;
	sc_context_param_t ctx_param;
	int slot_id = SCARD_SLOT_ID, reader_id = SCARD_READER_ID;
	secret_t user_sec;

	memset(&ctx_param, 0, sizeof(ctx_param));
	ctx_param.ver      = 0;
	ctx_param.app_name = "Load Secret";
	r = sc_context_create(&ctx, &ctx_param);
	if (r < 0) goto end;

	r = connect_card(ctx, &card, reader_id, slot_id);
	if (r != 0) return r;

	r = sc_pkcs15_bind(card, &p15card);
	if (r) goto end;
	
	user_sec.local = lname;
	user_sec.remote = rname;
	user_sec.format = format;
	user_sec.password = secret;
	r = update_secret(SC_PKCS15_SECRET_APPOID, &user_sec);
end:
	if (p15card)
		sc_pkcs15_unbind(p15card);
	if (card) {
		sc_unlock(card);
		sc_disconnect_card(card, slot_id);
	}
	if (ctx)
		sc_release_context(ctx);

	return r;
}
*/
static int secret_scard_start_search(void *trans, 
				       const char *domain, const char *user,
				       const char *format, char *secret)
{
	struct secret_scard_trans *scard_trans = (struct secret_scard_trans *)trans;
	struct sc_secret_entry record;
	int r;
	uint8_t *buf = NULL;
	size_t buf_len;

	if (!scard_trans) {
		secret_source_failure(scard_trans);
		return -1;
	}
	
	memset(&record, 0, sizeof(record));
	record.domain = domain;
	record.user = user;
	record.format = format;
	r = load_secret(trans, SC_PKCS15_SECRET_APPOID, &buf, &buf_len);
	if (r != 0)
		goto out;
	r = search_secret(buf, buf_len, &record);
out:
	if (r != 0)
		secret_source_failure(scard_trans);
	else
		secret_source_success(scard_trans);
	if (buf)
		free(buf);
	buf = NULL;

	return r;
}

static int delete_record(uint8_t *data, size_t *data_len, 
			 const struct sc_secret_entry *record)
{
	int r;
	uint8_t *p = data;
	size_t plen = *data_len;
	struct sc_secret_entry rcd;

	if (*p++ != SC_PKCS15_DATA_SECRET_TAG)
		return -1;
	*p++;
	plen -= 2;

	while(plen > 0) {
		memset(&rcd, 0, sizeof(rcd));
		r= decode_secret_entry(p, plen, &rcd);
		if (r != 0)
			return r;
		if (!strcmp(record->domain, rcd.domain) 
			&& !strcmp(record->user, rcd.user)
			&& !strcmp(record->format, rcd.format)) {
			p = memmove(p, p + rcd.len + 2, plen - rcd.len - 2);
			if (p == NULL)
				return -1;
			else {
				*data_len -= rcd.len - 2;
				return 0;
			}
		}
		p += rcd.len + 2;
		plen -= rcd.len + 2;
	}
	
	return -1;	
}


static int secret_scard_start_delete(void *trans,
			      const char *domain, const char *user,
			      const char *format)
{
	struct secret_scard_trans *scard_trans = (struct secret_scard_trans *)trans;
	int r;
	uint8_t *buf = NULL;
	size_t buf_len;
	struct sc_secret_entry record;

	if (!scard_trans) {
		secret_source_failure(scard_trans);
		return -1;
	}

	r = load_secret(scard_trans, SC_PKCS15_SECRET_APPOID, &buf, &buf_len);
	if (r != 0)
		goto out;

	memset(&record, 0, sizeof(record));
	record.domain = domain;
	record.user = user;
	record.format = format;
	/*TODO: delete record and update to scard*/
	r = delete_record(buf, &buf_len, &record);
	if (r != 0)
		goto out;
	
out:
	if (r != 0)
		secret_source_failure(scard_trans);
	else
		secret_source_success(scard_trans);
	if (buf)
		free(buf);
	buf = NULL;

	return r;	
}

secret_source_t secret_scard = {
	SECRET_SOURCE_CARD,
	secret_scard_start_trans,
	secret_scard_stop_trans,
	secret_scard_start_search,
	secret_scard_start_delete,
	NULL, /*secret_scard_start_update,*/
};

modlinkage int __init secret_scard_init(void)
{
	return secret_register_source(&secret_scard);
}

modlinkage void __exit secret_scard_exit(void)
{
	secret_unregister_source(&secret_scard);
}

module_init(secret_scard_init);
module_exit(secret_scard_exit);
