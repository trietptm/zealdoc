#include <unistd.h>
#include <stdio.h>
#include <linux/types.h>
#include <string.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <signal.h>
#include <linux/socket.h>
#include <linux/in.h>

#include "../hbridge.h"

struct msg_to_kernel
{
	struct nlmsghdr hdr;
	struct hbr_trans_entry e;
};

struct u_packet_info
{
	struct nlmsghdr hdr;
	char *str;
};

static int skfd;

int main(void)
{

	struct hbr_trans_entry user;
	struct sockaddr_in *cli;
	struct sockaddr_in *per;
	struct sockaddr *hw_addr;

	struct sockaddr_nl local;
	struct sockaddr_nl kpeer;
	int kpeerlen;
	struct msg_to_kernel message;
	struct u_packet_info info;
	int sendlen = 0;
	int rcvlen = 0;
	struct in_addr addr;
	struct hbr_trans_entry *entry = &message.e;
	unsigned char my_mac[] = "\x00\x16\x36\xc0\x74\x66";
	unsigned char mac[] = "\x00\x16\xec\x4f\x4f\x7d";
	int i;

	skfd = socket(PF_NETLINK, SOCK_RAW, NETLINK_HBRIDGE);
	if(skfd < 0) {
		printf("can not create a netlink socket\n");
		return 0;
	}

	memset(&local, 0, sizeof(local));
	local.nl_family = AF_NETLINK;
	local.nl_pid = getpid();
	local.nl_groups = 0;
	if(bind(skfd, (struct sockaddr*)&local, sizeof(local)) != 0) {
		printf("bind() error\n");
		return -1;
	}

	printf("socket & bind success\n");

	//signal(SIGINT, sig_int);

	memset(&kpeer, 0, sizeof(kpeer));
	kpeer.nl_family = AF_NETLINK;
	kpeer.nl_pid = 0;
	kpeer.nl_groups = 0;

	memset(&message, 0, sizeof(message));
	message.hdr.nlmsg_len = sizeof(message);
	message.hdr.nlmsg_flags = NLM_F_ECHO | NLM_F_REQUEST;
	message.hdr.nlmsg_type = HBRM_DELHBR;
	message.hdr.nlmsg_pid = local.nl_pid;

	cli 	= (struct sockaddr_in *)&entry->client_ip;
	per 	= (struct sockaddr_in *)&entry->peer_ip;
	memcpy(entry->cli_hw_addr.sa_data, my_mac, 6);
	entry->cli_hw_addr.sa_family = 1;
	cli->sin_addr.s_addr = ntohl(0xc0a864a2);
	per->sin_addr.s_addr = ntohl(0xc0a864a1);
	memcpy(entry->ppp_dev, "ppp0", 4);
	memcpy(entry->hbr_dev, "eth0", 4);

	/* 1 */
	sendto(skfd, &message, message.hdr.nlmsg_len, 0,
			(struct sockaddr*)&kpeer, sizeof(kpeer));

	close(skfd);
	return 0;
}
