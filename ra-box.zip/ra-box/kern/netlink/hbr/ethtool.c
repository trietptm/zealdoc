#include <string.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <net/if.h>

typedef unsigned int __u32;
typedef unsigned char __u8;
typedef unsigned short __u16;
typedef unsigned long long __u64;
#include <linux/ethtool.h>

#ifndef SIOCETHTOOL
#define SIOCETHTOOL     0x8946
#endif

static int do_test(int fd, struct ifreq *ifr);

static int dump_test(struct ethtool_drvinfo *info, struct ethtool_test *test,
		      struct ethtool_gstrings *strings);
static enum {
	MODE_HELP = -1,
	MODE_GSET=0,
	MODE_SSET,
	MODE_GDRV,
	MODE_GREGS,
	MODE_NWAY_RST,
	MODE_GEEPROM,
	MODE_SEEPROM,
	MODE_TEST,
	MODE_PHYS_ID,
	MODE_GPAUSE,
	MODE_SPAUSE,
	MODE_GCOALESCE,
	MODE_SCOALESCE,
	MODE_GRING,
	MODE_SRING,
	MODE_GOFFLOAD,
	MODE_SOFFLOAD,
	MODE_GSTATS,
} mode = MODE_GSET;



static char *devname = NULL;
static int dump_test(struct ethtool_drvinfo *info, struct ethtool_test *test,
		      struct ethtool_gstrings *strings)
{
	int i, rc;

	rc = test->flags & ETH_TEST_FL_FAILED;
	fprintf(stdout, "The test result is %s\n", rc ? "FAIL" : "PASS");

	if (info->testinfo_len)
		fprintf(stdout, "The test extra info:\n");

#if 0
	for (i = 0; i < info->testinfo_len; i++) {
		fprintf(stdout, "data %d\n",
			(unsigned int) test->data[i]);
	}
#endif
	if (info->testinfo_len != 1)
		return -1;
	if (test->data[0] == 0)
		fprintf(stdout, "eth0 down now\n");
	else
		fprintf(stdout, "eth0 up now\n");
	return rc;
}

/* 8139too driver not support ETHTOOL_TEST.
 * add self_test_count and self_test cb in 8139too */
static int do_test(int fd, struct ifreq *ifr)
{
	int err;
	struct ethtool_drvinfo drvinfo;
	struct ethtool_test *test;

	drvinfo.cmd = ETHTOOL_GDRVINFO;
	ifr->ifr_data = (caddr_t)&drvinfo;
	err = ioctl(fd, SIOCETHTOOL, ifr);
	if (err < 0) {
		perror("Cannot get driver information");
		return 72;
	}

	test = calloc(1, sizeof(*test) + drvinfo.testinfo_len * sizeof(unsigned long long));
	if (!test) {
		perror("Cannot allocate memory for test info");
		return 73;
	}
	memset (test->data, 0, drvinfo.testinfo_len * sizeof(unsigned long long));
	test->cmd = ETHTOOL_TEST;
	test->len = drvinfo.testinfo_len;
	test->flags = ETH_TEST_FL_OFFLINE;
	ifr->ifr_data = (caddr_t)test;
	err = ioctl(fd, SIOCETHTOOL, ifr);
	if (err < 0) {
		perror("Cannot test");
		free (test);
		return 74;
	}

	err = dump_test(&drvinfo, test, NULL);
	free(test);

	return err;
}

int main()
{
	struct ifreq ifr;
	int fd;

	memset(&ifr, 0, sizeof (ifr));
	strcpy(ifr.ifr_name, "eth0");
	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0) {
		printf("socket err\n");
		return -1;
	}
	do_test(fd, &ifr);
	return 0;
}
