#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <netdb.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <linux/if_ether.h>
#include <linux/if_arp.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
int
addattr_l (struct nlmsghdr *n, int maxlen, int type, void *data, int alen)
{
	int len;
	struct rtattr *rta;

	len = RTA_LENGTH(alen);

	if (NLMSG_ALIGN(n->nlmsg_len) + len > maxlen)
		return -1;

	rta = (struct rtattr*) (((char*)n) + NLMSG_ALIGN (n->nlmsg_len));
	rta->rta_type = type;
	rta->rta_len = len;
	memcpy (RTA_DATA(rta), data, alen);
	n->nlmsg_len = NLMSG_ALIGN (n->nlmsg_len) + len;

	return 0;
}

int skfd = -1;
struct sockaddr_nl local;
struct sockaddr_nl kpeer;

int respond_to_kernel(int ifindex, __u32 addr, char *lla, int llalen)
{
	int res;
	struct {
		struct nlmsghdr 	n;
		struct ndmsg 		ndm;
		char   			buf[256];
	} req;

	memset(&req.n, 0, sizeof(req.n));
	memset(&req.ndm, 0, sizeof(req.ndm));

	req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct ndmsg));
	req.n.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE;
	req.n.nlmsg_type = RTM_NEWNEIGH;
	req.ndm.ndm_family = AF_INET;
	req.ndm.ndm_state = NUD_PERMANENT | NUD_REACHABLE;
//	req.ndm.ndm_flags = NTF_PROXY;
	req.ndm.ndm_ifindex = ifindex;
	req.ndm.ndm_type = RTN_UNICAST;

	addattr_l(&req.n, sizeof(req), NDA_DST, &addr, 4);
	addattr_l(&req.n, sizeof(req), NDA_LLADDR, lla, llalen);
	res = sendto(skfd, (char*)&req, req.n.nlmsg_len, 0, (struct sockaddr *)&kpeer, sizeof (kpeer));
	return res;
}

int main()
{

	unsigned char my_mac[] = "\x00\x16\x36\xc0\x74\x66";
	unsigned char eth0_mac[] = "\x00\xe0\x4c\x17\x05\x4f";
	int res;
	skfd = socket(PF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	if(skfd < 0) {
		printf("can not create a netlink socket\n");
		return 0;
	}

	memset(&local, 0, sizeof(local));
	local.nl_family = AF_NETLINK;
	local.nl_pid = getpid();
	local.nl_groups = 0;
	if(bind(skfd, (struct sockaddr*)&local, sizeof(local)) != 0) {
		printf("bind() error\n");
		return -1;
	}

	printf("socket & bind success\n");

	memset(&kpeer, 0, sizeof(kpeer));
	kpeer.nl_family = AF_NETLINK;
	kpeer.nl_pid = 0;
	kpeer.nl_groups = 0;
	res = respond_to_kernel(4, ntohl(0xc0a864a1), eth0_mac, 6);
	if (res > 0)
		printf("send succ\n");
	else
		printf("send fail\n");
	return -1;
}
