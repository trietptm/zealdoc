#include <sysdep.h>
#include <module.h>
#include <logger.h>

#ifdef CONFIG_MODULE
extern initcall_t __initcall_start[], __initcall_end[];
static void __init do_initcalls(void)
{
	initcall_t *call;

	for (call = __initcall_start; call < __initcall_end; call++) {
		int result;

		result = (*call)();

		if (result && result != -ENODEV) {
			log_kern(LOG_WARNING,
				 "INIT: call initcall failure, call=0x%08x, err=%d",
				 *call, result);
		} else {
			log_kern(LOG_INFO,
				 "INIT: call initcall success, call=0x%08x",
				 *call);
		}
	}
}
#else
static void __init do_initcalls(void) {}
#endif

int __init early_begin(void)
{
	log_early_init();
	eloop_init();
	return 0;
}

void __init early_end(void)
{
	log_early_exit();
}

int __init system_init(void)
{
	do_initcalls();
	service_init();
	secret_init();
	return 0;
}

void __exit system_exit(void)
{
	secret_exit();
	service_exit();
	eloop_exit();
	log_exit();
}
