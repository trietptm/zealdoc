#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

struct pkcs15_app_entry {
	const uint8_t *aid;
	size_t aid_len;
	const char *desc;
};

static const struct pkcs15_app_entry apps[] = {
	{ (const u8 *) "\xA0\x00\x00\x00\x63PKCS-15", 12, "PKCS #15" },
	{ (const u8 *) "\xA0\x00\x00\x01\x77PKCS-15", 12, "Belgian eID" },
};

static const struct pkcs15_asn1_entry c_asn1_dirrecord[] = {
	{ "aid",   PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_APP | 15, 0, NULL, NULL },
	{ "label", PKCS15_ASN1_UTF8STRING,   PKCS15_ASN1_APP | 16, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "path",  PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_APP | 17, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "ddo",   PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_APP | 19 | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};
static const struct pkcs15_asn1_entry c_asn1_dir[] = {
	{ "dirRecord", PKCS15_ASN1_STRUCT, PKCS15_ASN1_APP | 1 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_app_entry * find_app_entry(const uint8_t * aid, 
						      size_t aid_len)
{
	size_t i;

	for (i = 0; i < sizeof(apps)/sizeof(apps[0]); i++) {
		if (apps[i].aid_len == aid_len &&
		    memcmp(apps[i].aid, aid, aid_len) == 0)
			return &apps[i];
	}
	return NULL;
}

static const struct scard_app_info * pkcs15_find_app_by_aid(struct scard_handle *card_handle,
						     const uint8_t *aid, 
						     size_t aid_len)
{
	int i;

	for (i = 0; i < card_handle->app_count; i++) {
		if (card_handle->app[i]->aid_len == aid_len &&
		    memcmp(card_handle->app[i]->aid, aid, aid_len) == 0)
			return card_handle->app[i];
	}
	return NULL;
}

const struct scard_app_info * pkcs15_find_app(struct scard_handle *card_handle)
{
	const struct scard_app_info *app = NULL;
	unsigned int i;

	i = sizeof(apps)/sizeof(apps[0]);
	while (!app && i--)
		app = pkcs15_find_app_by_aid(card_handle, apps[i].aid, 
					     apps[i].aid_len);

	return app;
}


int parse_dir_record(struct scard_handle *card_handle, 
		     uint8_t **rbuf, size_t *rbuf_len, int rec_nr)
{
	struct pkcs15_asn1_entry asn1_dirrecord[5], asn1_dir[2];
	struct scard_app_info *app = NULL;
	const struct pkcs15_app_entry *ae;
	uint8_t aid[128], label[128], path[128];
	uint8_t ddo[128];
	size_t aid_len = sizeof(aid), label_len = sizeof(label),
		path_len = sizeof(path), ddo_len = sizeof(ddo);
	int r;

	pkcs15_copy_asn1_entry(c_asn1_dirrecord, asn1_dirrecord);
	pkcs15_copy_asn1_entry(c_asn1_dir, asn1_dir);
	pkcs15_format_asn1_entry(asn1_dir + 0, asn1_dirrecord, NULL, 0);
	pkcs15_format_asn1_entry(asn1_dirrecord + 0, aid, &aid_len, 0);
	pkcs15_format_asn1_entry(asn1_dirrecord + 1, label, &label_len, 0);
	pkcs15_format_asn1_entry(asn1_dirrecord + 2, path, &path_len, 0);
	pkcs15_format_asn1_entry(asn1_dirrecord + 3, ddo, &ddo_len, 0);

	r = pkcs15_asn1_decode(asn1_dir, *rbuf, *rbuf_len, 
			     (const uint8_t **)rbuf, rbuf_len);
	if (r == PKCS15_ERR_ASN1_END_OF_CONTENTS)
		return r;
	if (r) return r;
	if (aid_len > SCARD_AID_MAX)
		return PKCS15_ERR_INVALID_ASN1_OBJ;
	app = (struct scard_app_info *)malloc(sizeof(struct scard_app_info));
	if (!app) 
		return PKCS15_ERR_NO_MEM;
	memcpy(app->aid, aid, aid_len);
	app->aid_len = aid_len;
	if (asn1_dirrecord[1].flags & PKCS15_ASN1_PRESENT)
		app->label = strdup((char *)label);
	else 
		app->label = NULL;
	if (asn1_dirrecord[2].flags & PKCS15_ASN1_PRESENT) {
		if (path_len > SCARD_PATH_MAX) {
			free(app);
			return PKCS15_ERR_INVALID_ASN1_OBJ;
		}
		memcpy(app->path.value, path, path_len);
		app->path.len = path_len;
		app->path.type = SCARD_PATH_TYPE_PATH;
	} else if (aid_len < sizeof(app->path.value)) {
		memcpy(app->path.value, aid, aid_len);
		app->path.len = aid_len;
		app->path.type = SCARD_PATH_TYPE_DF_NAME;
	} else {
		app->path.len = 0;
	}
	if (asn1_dirrecord[3].flags & PKCS15_ASN1_PRESENT) {
		app->ddo = (uint8_t *)malloc(ddo_len);
		if (app->ddo == NULL) {
			free(app);
			return PKCS15_ERR_NO_MEM;
		}
		memcpy(app->ddo, ddo, ddo_len);
		app->ddo_len = ddo_len;
	} else {
		app->ddo = NULL;
		app->ddo_len = 0;
	}
	ae = find_app_entry(aid, aid_len);
	if (ae != NULL)
		app->desc = ae->desc;
	else
		app->desc = NULL;
	app->rec_nr = rec_nr;
	card_handle->app[card_handle->app_count] = app;
	card_handle->app_count++;

	return PKCS15_SUCCESS;
}

static const struct pkcs15_asn1_entry c_asn1_ddo[] = {
	{ "oid",	   PKCS15_ASN1_OBJECT, PKCS15_ASN1_TAG_OBJECT, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "odfPath",	   PKCS15_ASN1_PATH, PKCS15_ASN1_CONS | PKCS15_ASN1_TAG_SEQUENCE, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "tokenInfoPath", PKCS15_ASN1_PATH, PKCS15_ASN1_CONS | PKCS15_ASN1_CTX | 0, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "unusedPath",    PKCS15_ASN1_PATH, PKCS15_ASN1_CONS | PKCS15_ASN1_CTX | 1, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

int parse_ddo(struct pkcs15_handle *p15_handle, const uint8_t * buf, 
	      size_t buflen)
{
	struct pkcs15_asn1_entry asn1_ddo[5];
	struct scard_path odf_path, ti_path, us_path;
	int r;

	pkcs15_copy_asn1_entry(c_asn1_ddo, asn1_ddo);
	pkcs15_format_asn1_entry(asn1_ddo + 1, &odf_path, NULL, 0);
	pkcs15_format_asn1_entry(asn1_ddo + 2, &ti_path, NULL, 0);
	pkcs15_format_asn1_entry(asn1_ddo + 3, &us_path, NULL, 0);

	r = pkcs15_asn1_decode(asn1_ddo, buf, buflen, NULL, NULL);
	if (r)
		return r;

	if (asn1_ddo[1].flags & PKCS15_ASN1_PRESENT) {
		p15_handle->odf = scard_file_new();
		if (p15_handle->odf == NULL)
			goto mem_err;
		p15_handle->odf->path = odf_path;
	}
	if (asn1_ddo[2].flags & PKCS15_ASN1_PRESENT) {
		p15_handle->tif = scard_file_new();
		if (p15_handle->tif == NULL)
			goto mem_err;
		p15_handle->tif->path = ti_path;
	}
	if (asn1_ddo[3].flags & PKCS15_ASN1_PRESENT) {
		p15_handle->unused = scard_file_new();
		if (p15_handle->unused == NULL)
			goto mem_err;
		p15_handle->unused->path = us_path;
	}
	return 0;

mem_err:
	if (p15_handle->odf != NULL) {
		scard_file_free(p15_handle->odf);
		p15_handle->odf = NULL;
	}
	if (p15_handle->tif != NULL) {
		scard_file_free(p15_handle->tif);
		p15_handle->tif = NULL;
	}
	if (p15_handle->unused != NULL) {
		scard_file_free(p15_handle->unused);
		p15_handle->unused = NULL;
	}
	return PKCS15_ERR_NO_MEM;
}

static const struct pkcs15_asn1_entry c_asn1_odf[] = {
	{ "privateKeys",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 0 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "publicKeys",		 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 1 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "trustedPublicKeys",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 2 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "secretKeys",	 	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 3 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "certificates",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 4 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "trustedCertificates", PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 5 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "usefulCertificates",  PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 6 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "dataObjects",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 7 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ "authObjects",	 PKCS15_ASN1_STRUCT, PKCS15_ASN1_CTX | 8 | PKCS15_ASN1_CONS, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const unsigned int odf_indexes[] = {
	PKCS15_PRKDF,
	PKCS15_PUKDF,
	PKCS15_PUKDF_TRUSTED,
	PKCS15_SKDF,
	PKCS15_CDF,
	PKCS15_CDF_TRUSTED,
	PKCS15_CDF_USEFUL,
	PKCS15_DODF,
	PKCS15_AODF,
};

int parse_odf(const uint8_t * buf, size_t buflen, 
	      struct pkcs15_handle *p15_handle)
{
	const uint8_t *p = buf;
	size_t left = buflen;
	int r, i, type;
	struct scard_path path;
	struct pkcs15_asn1_entry asn1_obj_or_path[] = {
		{ "path", PKCS15_ASN1_PATH, PKCS15_ASN1_CONS | PKCS15_ASN1_SEQUENCE, 0, &path, NULL },
		{ NULL, 0, 0, 0, NULL, NULL }
	};
	struct pkcs15_asn1_entry asn1_odf[10];
	
	pkcs15_copy_asn1_entry(c_asn1_odf, asn1_odf);
	for (i = 0; asn1_odf[i].name != NULL; i++)
		pkcs15_format_asn1_entry(asn1_odf + i, asn1_obj_or_path, NULL, 0);
	while (left > 0) {
		r = pkcs15_asn1_decode_choice(asn1_odf, p, left, &p, &left);
		if (r == PKCS15_ERR_ASN1_END_OF_CONTENTS)
			break;
		if (r < 0)
			return r;
		type = r;
		r = scard_make_absolute_path(&p15_handle->app_root->path, &path);
		if (r < 0)
			return r;
		r = pkcs15_add_df(p15_handle, odf_indexes[type], &path, NULL);
		if (r)
			return r;
	}
	return 0;
}

static const struct pkcs15_asn1_entry c_asn1_twlabel[] = {
	{ "twlabel", PKCS15_ASN1_UTF8STRING, PKCS15_ASN1_TAG_UTF8STRING, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_toki[] = {
	{ "version",        PKCS15_ASN1_INTEGER,      PKCS15_ASN1_TAG_INTEGER, 0, NULL, NULL },
	{ "serialNumber",   PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_OCTET_STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "manufacturerID", PKCS15_ASN1_UTF8STRING,   PKCS15_ASN1_TAG_UTF8STRING, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "label",	    PKCS15_ASN1_UTF8STRING,   PKCS15_ASN1_CTX | 0, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	/* XXX the Taiwanese ID card erroneously uses explicit tagging */
	{ "label-tw",       PKCS15_ASN1_STRUCT,       PKCS15_ASN1_CTX | 0 | PKCS15_ASN1_CONS, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "tokenflags",	    PKCS15_ASN1_BIT_FIELD,    PKCS15_ASN1_TAG_BIT_STRING, 0, NULL, NULL },
	{ "seInfo",	    PKCS15_ASN1_SE_INFO,	  PKCS15_ASN1_CONS | PKCS15_ASN1_TAG_SEQUENCE, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "recordInfo",	    PKCS15_ASN1_STRUCT,       PKCS15_ASN1_CONS | PKCS15_ASN1_CTX | 1, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "supportedAlgorithms", PKCS15_ASN1_STRUCT,  PKCS15_ASN1_CONS | PKCS15_ASN1_CTX | 2, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "issuerId",       PKCS15_ASN1_UTF8STRING,   PKCS15_ASN1_CTX | 3, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "holderId",       PKCS15_ASN1_UTF8STRING,   PKCS15_ASN1_CTX | 4, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "lastUpdate",     PKCS15_ASN1_GENERALIZEDTIME, PKCS15_ASN1_CTX | 5, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "preferredLanguage", PKCS15_ASN1_PRINTABLESTRING, PKCS15_ASN1_TAG_PRINTABLESTRING, PKCS15_ASN1_OPTIONAL, NULL, NULL }, 
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_tokeninfo[] = {
	{ "TokenInfo", PKCS15_ASN1_STRUCT, PKCS15_ASN1_CONS | PKCS15_ASN1_TAG_SEQUENCE, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

int pkcs15_parse_tokeninfo(struct pkcs15_tokeninfo *ti,
			   const uint8_t *buf, size_t blen)
{
	int r;
	uint8_t serial[128];
	size_t i;
	size_t serial_len = sizeof(serial);
	uint8_t mnfid[PKCS15_LABEL_MAX];
	size_t mnfid_len  = sizeof(mnfid);
	uint8_t label[PKCS15_LABEL_MAX];
	size_t label_len = sizeof(label);
	uint8_t last_update[32];
	size_t lupdate_len = sizeof(last_update) - 1;
	size_t flags_len   = sizeof(ti->flags);
	struct pkcs15_asn1_entry asn1_toki[14], asn1_tokeninfo[3], asn1_twlabel[3];
	uint8_t preferred_language[3];
	size_t lang_length = sizeof(preferred_language);

	memset(last_update, 0, sizeof(last_update));
	pkcs15_copy_asn1_entry(c_asn1_twlabel, asn1_twlabel);
	pkcs15_copy_asn1_entry(c_asn1_toki, asn1_toki);
	pkcs15_copy_asn1_entry(c_asn1_tokeninfo, asn1_tokeninfo);
	pkcs15_format_asn1_entry(asn1_twlabel, label, &label_len, 0);
	pkcs15_format_asn1_entry(asn1_toki + 0, &ti->version, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 1, serial, &serial_len, 0);
	pkcs15_format_asn1_entry(asn1_toki + 2, mnfid, &mnfid_len, 0);
	pkcs15_format_asn1_entry(asn1_toki + 3, label, &label_len, 0);
	pkcs15_format_asn1_entry(asn1_toki + 4, asn1_twlabel, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 5, &ti->flags, &flags_len, 0);
	pkcs15_format_asn1_entry(asn1_toki + 6, &ti->sec_info, &ti->sec_info_num, 0);
	pkcs15_format_asn1_entry(asn1_toki + 7, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 8, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 9, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 10, NULL, NULL, 0);
	pkcs15_format_asn1_entry(asn1_toki + 11, last_update, &lupdate_len, 0);
	pkcs15_format_asn1_entry(asn1_toki + 12, preferred_language, &lang_length, 0);
	pkcs15_format_asn1_entry(asn1_tokeninfo, asn1_toki, NULL, 0);
	
	r = pkcs15_asn1_decode(asn1_tokeninfo, buf, blen, NULL, NULL);
	if (r)
		return r;
	
	ti->version += 1;
	ti->serial_num = (char *) malloc(serial_len * 2 + 1);
	if (ti->serial_num == NULL)
		return PKCS15_ERR_NO_MEM;
	ti->serial_num[0] = 0;
	for (i = 0; i < serial_len; i++) {
		char byte[3];

		sprintf(byte, "%02X", serial[i]);
		strcat(ti->serial_num, byte);
	}
	if (ti->manufacturer_id == NULL) {
		if (asn1_toki[2].flags & PKCS15_ASN1_PRESENT)
			ti->manufacturer_id = strdup((char *) mnfid);
		else
			ti->manufacturer_id = strdup("(unknown)");
		if (ti->manufacturer_id == NULL)
			return PKCS15_ERR_NO_MEM;
	}
	if (ti->label == NULL) {
		if (asn1_toki[3].flags & PKCS15_ASN1_PRESENT ||
		    asn1_toki[4].flags & PKCS15_ASN1_PRESENT)
			ti->label = strdup((char *) label);
		else
			ti->label = strdup("(unknown)");
		if (ti->label == NULL)
			return PKCS15_ERR_NO_MEM;
	}
	if (asn1_toki[11].flags & PKCS15_ASN1_PRESENT) {
		ti->last_update = strdup((char *)last_update);
		if (ti->last_update == NULL)
			return PKCS15_ERR_NO_MEM;
	}
	if (asn1_toki[12].flags & PKCS15_ASN1_PRESENT) {
		preferred_language[2] = 0;
		ti->prefered_lang = strdup((char *)preferred_language);
		if (ti->prefered_lang == NULL)
			return PKCS15_ERR_NO_MEM;
	}
	return PKCS15_SUCCESS;
}



int pkcs15_add_df(struct pkcs15_handle *p15_handle,
		  unsigned int type, const struct scard_path *path,
		  const struct scard_file *filp)
{
	struct pkcs15_df *newdf;

	newdf = (struct pkcs15_df *) calloc(1, sizeof(struct pkcs15_df));
	if (newdf == NULL)
		return PKCS15_ERR_NO_MEM;
	newdf->path = *path;
	newdf->type = type;
	if (filp != NULL) {
		scard_file_dup(&newdf->filp, filp);
		if (newdf->filp == NULL) {
			free(newdf);
			return PKCS15_ERR_NO_MEM;
		}
			
	}

	list_insert_before(&newdf->link, &p15_handle->df_list);
	
	return 0;
}

void pkcs15_remove_df(struct pkcs15_handle *p15_handle,
		      struct pkcs15_df *obj)
{
	list_delete(&obj->link);

	if (obj->filp)
		scard_file_free(obj->filp);
	free(obj);
}