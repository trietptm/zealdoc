#include "pkcs15_priv.h"
#include "pkcs15_asn1.h"

/*
 * AlgorithmIdentifier handling
 */
static struct pkcs15_asn1_entry	c_asn1_des_iv[] = {
	{ "iv",	PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_OCTET_STRING, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static const struct pkcs15_asn1_entry c_asn1_pbkdf2_params[] = {
	{ "salt",	PKCS15_ASN1_OCTET_STRING, PKCS15_ASN1_TAG_OCTET_STRING, 0, NULL, NULL },
	{ "count",	PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, 0, NULL, NULL },
	{ "keyLength",	PKCS15_ASN1_INTEGER, PKCS15_ASN1_TAG_INTEGER, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ "prf",	PKCS15_ASN1_ALGORITHM_ID, PKCS15_ASN1_TAG_SEQUENCE, PKCS15_ASN1_OPTIONAL, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};


static int asn1_decode_des_params(void **paramp, const uint8_t *buf,
				  size_t buflen, int depth)
{
	struct pkcs15_asn1_entry asn1_des_iv[2];
	uint8_t	iv[8];
	int	ivlen = 8, r;

	pkcs15_copy_asn1_entry(c_asn1_des_iv, asn1_des_iv);
	pkcs15_format_asn1_entry(asn1_des_iv + 0, iv, &ivlen, 0);
	r = asn1_decode(asn1_des_iv, buf, buflen, NULL, NULL, 0, depth + 1);
	if (r < 0)
		return r;
	if (ivlen != 8)
		return PKCS15_ERR_INVALID_ASN1_OBJ;
	*paramp = malloc(8);
	if (!*paramp)
		return PKCS15_ERR_NO_MEM;
	memcpy(*paramp, iv, 8);
	return 0;
}


static int asn1_decode_pbkdf2_params(void **paramp, const uint8_t *buf, 
				     size_t buflen, int depth)
{
	struct scard_pbkdf2_params info;
	struct pkcs15_asn1_entry asn1_pbkdf2_params[5];
	int r;

	pkcs15_copy_asn1_entry(c_asn1_pbkdf2_params, asn1_pbkdf2_params);
	pkcs15_format_asn1_entry(asn1_pbkdf2_params + 0,
			info.salt, &info.salt_len, 0);
	pkcs15_format_asn1_entry(asn1_pbkdf2_params + 1,
			&info.iterations, NULL, 0);
	pkcs15_format_asn1_entry(asn1_pbkdf2_params + 2,
			&info.key_length, NULL, 0);
	pkcs15_format_asn1_entry(asn1_pbkdf2_params + 3,
			&info.hash_alg, NULL, 0);

	memset(&info, 0, sizeof(info));
	info.salt_len = sizeof(info.salt);
	info.hash_alg.algorithm = SCARD_ALGORITHM_SHA1;

	r = asn1_decode(asn1_pbkdf2_params, buf, buflen, 
			NULL, NULL, 0, depth + 1);
	if (r < 0)
		return r;

	*paramp = malloc(sizeof(info));
	if (!*paramp)
		return PKCS15_ERR_NO_MEM;
	memcpy(*paramp, &info, sizeof(info));
	return 0;
}

static int asn1_encode_pbkdf2_params(void *params, uint8_t **buf, 
				     size_t *buflen, int depth)
{
	struct scard_pbkdf2_params *info;
	struct pkcs15_asn1_entry asn1_pbkdf2_params[5];

	info = (struct scard_pbkdf2_params *) params;

	pkcs15_copy_asn1_entry(c_asn1_pbkdf2_params, asn1_pbkdf2_params);
	pkcs15_format_asn1_entry(asn1_pbkdf2_params + 0,
			info->salt, &info->salt_len, 1);
	pkcs15_format_asn1_entry(asn1_pbkdf2_params + 1,
			&info->iterations, NULL, 1);
	if (info->key_length > 0)
		pkcs15_format_asn1_entry(asn1_pbkdf2_params + 2,
				&info->key_length, NULL, 1);
	if (info->hash_alg.algorithm != SCARD_ALGORITHM_SHA1)
		pkcs15_format_asn1_entry(asn1_pbkdf2_params + 3,
				&info->hash_alg, NULL, 0);

	return asn1_encode(asn1_pbkdf2_params, buf, buflen, depth + 1);
}

static int asn1_encode_des_params(void *params, uint8_t **buf, 
				  size_t *buflen, int depth)
{
	struct pkcs15_asn1_entry asn1_des_iv[2];
	int ivlen = 8;

	pkcs15_copy_asn1_entry(c_asn1_des_iv, asn1_des_iv);
	pkcs15_format_asn1_entry(asn1_des_iv + 0, params, &ivlen, 1);
	return asn1_encode(asn1_des_iv, buf, buflen, depth + 1);
}


static const struct pkcs15_asn1_entry c_asn1_pbes2_params[] = {
	{ "keyDerivationAlg", PKCS15_ASN1_ALGORITHM_ID, PKCS15_ASN1_TAG_SEQUENCE, 0, NULL, NULL },
	{ "keyEcnryptionAlg", PKCS15_ASN1_ALGORITHM_ID, PKCS15_ASN1_TAG_SEQUENCE, 0, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL }
};

static int asn1_decode_pbes2_params(void **paramp, const u8 *buf, 
				    size_t buflen, int depth)
{
	struct pkcs15_asn1_entry asn1_pbes2_params[3];
	struct scard_pbes2_params info;
	int r;

	pkcs15_copy_asn1_entry(c_asn1_pbes2_params, asn1_pbes2_params);
	pkcs15_format_asn1_entry(asn1_pbes2_params + 0,
				&info.derivation_alg, NULL, 0);
	pkcs15_format_asn1_entry(asn1_pbes2_params + 1,
				&info.key_encr_alg, NULL, 0);
	memset(&info, 0, sizeof(info));

	r = asn1_decode(asn1_pbes2_params, buf, buflen, 
			NULL, NULL, 0, depth + 1);
	if (r < 0)
		return r;
	*paramp = malloc(sizeof(info));
	if (!*paramp)
		return PKCS15_ERR_NO_MEM;
	memcpy(*paramp, &info, sizeof(info));
	return 0;
}

static int asn1_encode_pbes2_params(void *params, uint8_t **buf, 
				    size_t *buflen, int depth)
{
	struct pkcs15_asn1_entry asn1_pbes2_params[3];
	struct scard_pbes2_params *info;

	info = (struct scard_pbes2_params *) params;
	pkcs15_copy_asn1_entry(c_asn1_pbes2_params, asn1_pbes2_params);
	pkcs15_format_asn1_entry(asn1_pbes2_params + 0,
				&info->derivation_alg, NULL, 0);
	pkcs15_format_asn1_entry(asn1_pbes2_params + 1,
				&info->key_encr_alg, NULL, 0);
	return asn1_encode(asn1_pbes2_params, buf, buflen, depth + 1);
}

void pkcs15_asn1_clear_algorithm_id(struct scard_algorithm_id *id)
{
	struct asn1_pkcs15_algorithm_info *aip;

	if ((aip = pkcs15_asn1_get_algorithm_info(id)) && aip->free)
		aip->free(id);
}

static void asn1_free_pbes2_params(void *ptr)
{
	struct scard_pbes2_params *params = (struct scard_pbes2_params *) ptr;

	pkcs15_asn1_clear_algorithm_id(&params->derivation_alg);
	pkcs15_asn1_clear_algorithm_id(&params->key_encr_alg);
	free(params);
}


static struct asn1_pkcs15_algorithm_info algorithm_table[] = {
	/* hmacWithSHA1 */
	{ SCARD_ALGORITHM_SHA1, {{ 1, 2, 840, 113549, 2, 7 }}, NULL, NULL, NULL },
	{ SCARD_ALGORITHM_SHA1, {{ 1, 3, 6, 1, 5, 5, 8, 1, 2 }}, NULL, NULL, NULL },
	/* SHA1 */
	{ SCARD_ALGORITHM_SHA1, {{ 1, 3, 14, 3, 2, 26, }}, NULL, NULL, NULL },
	{ SCARD_ALGORITHM_MD5, {{ 1, 2, 840, 113549, 2, 5, }}, NULL, NULL, NULL },
	{ SCARD_ALGORITHM_DSA, {{ 1, 2, 840, 10040, 4, 3 }}, NULL, NULL, NULL },
	{ SCARD_ALGORITHM_RSA, {{ 1, 2, 840, 113549, 1, 1, 1 }}, NULL, NULL, NULL },
#ifdef SCARD_ALGORITHM_DH
	{ SCARD_ALGORITHM_DH, {{ 1, 2, 840, 10046, 2, 1 }}, NULL, NULL, NULL },
#endif
	/* from CMS */
#ifdef SCARD_ALGORITHM_RC2_WRAP
	{ SCARD_ALGORITHM_RC2_WRAP,  {{ 1, 2, 840, 113549, 1, 9, 16, 3, 7 }}, NULL, NULL, NULL },
#endif
#ifdef SCARD_ALGORITHM_RC2
	/* CBC mode */
	{ SCARD_ALGORITHM_RC2, {{ 1, 2, 840, 113549, 3, 2 }},
				asn1_decode_rc2_params,
				asn1_encode_rc2_params },
#endif
	/* CBC mode */
	{ SCARD_ALGORITHM_DES, {{ 1, 3, 14, 3, 2, 7 }},
				asn1_decode_des_params,
				asn1_encode_des_params,
				free },
#ifdef	SCARD_ALGORITHM_3DES_WRAP /* from CMS */
	{ SCARD_ALGORITHM_3DES_WRAP, {{ 1, 2, 840, 113549, 1, 9, 16, 3, 6 }}, NULL, NULL, NULL },
#endif
	/* EDE CBC mode */
	{ SCARD_ALGORITHM_3DES, {{ 1, 2, 840, 113549, 3, 7 }},
				asn1_decode_des_params,
				asn1_encode_des_params,
				free },
	/* We do not support PBES1 because the encryption is weak */
	{ SCARD_ALGORITHM_PBKDF2, {{ 1, 2, 840, 113549, 1, 5, 12 }},
				asn1_decode_pbkdf2_params,
				asn1_encode_pbkdf2_params,
				free },
	{ SCARD_ALGORITHM_PBES2, {{ 1, 2, 840, 113549, 1, 5, 13 }},
				asn1_decode_pbes2_params,
				asn1_encode_pbes2_params,
				asn1_free_pbes2_params },
	{ -1, {{ -1 }}, NULL, NULL, NULL },
};

struct asn1_pkcs15_algorithm_info *
	pkcs15_asn1_get_algorithm_info(const struct scard_algorithm_id *id)
{
	struct asn1_pkcs15_algorithm_info *aip;

	aip = algorithm_table;
	if ((int) id->algorithm < 0) {
		while (aip->id >= 0) {
			const int	*oid1, *oid2;
			int		m;
			
			oid1 = aip->oid.value;
	                oid2 = id->obj_id.value;
			for (m = 0; m < SCARD_OBJECT_ID_OCTETS_MAX; m++) {
				if (oid1[m] == oid2[m])
					continue;
				if (oid1[m] > 0 || oid2[m] > 0)
					break;
				/* We have a match */
				return aip;
			}
			aip++;
		}
	} else {
		while (aip->id >= 0) {
			if (aip->id == (int)id->algorithm)
				return aip;
			aip++;
		}
	}
	return NULL;
}
