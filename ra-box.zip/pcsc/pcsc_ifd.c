#include "pcsc_priv.h"
#ifdef CONFIG_USB
#include <usb.h>
#endif

struct pcsc_reader_context *reader_ctx[PCSC_MAX_READERS];

int __init pcsc_reader_context_init(void)
{
	int i;

	for (i = 0; i < PCSC_MAX_READERS; i++) {
		reader_ctx[i] = NULL;
	}

	return 0;
}

void __exit pcsc_reader_context_exit(void)
{
	int i;

	for (i = 0; i < PCSC_MAX_READERS; i++) {
		if (reader_ctx[i] != NULL) {
			/*TODO:*/
		}
	}

	return;
}


struct pcsc_reader_context *pcsc_reader_ctx_by_filename(const char *filename)
{
	int i;
	struct pcsc_reader_context *rd_ctx;

	for (i = 0; i < PCSC_MAX_READERS; i++) {
		rd_ctx = reader_ctx[i];
		if (rd_ctx
			&& !strcmp(rd_ctx->handle.reader.file_name, filename)) 
			return rd_ctx;
	}
	return NULL;
}

struct pcsc_reader_context *pcsc_alloc_reader_ctx(void)
{
	int reader_idx;
	struct pcsc_reader *reader;

	for(reader_idx = 0; reader_idx < PCSC_MAX_READERS; reader_idx++) {
		if (reader_ctx[reader_idx] == NULL)
			break;
	}
	if (reader_idx == PCSC_MAX_READERS)
		return NULL;
	reader_ctx[reader_idx] = malloc(sizeof(struct pcsc_reader_context));
	if (reader_ctx[reader_idx] == NULL)
		return NULL;		

	memset(reader_ctx[reader_idx], 0, sizeof(struct pcsc_reader_context));
	reader = &reader_ctx[reader_idx]->handle.reader;

	reader->reader_type = PCSC_READER_TYPE_USB;
	reader->reader_status = PCSC_READER_STATUS_PRESENT;
	reader->icc_seq = 0;

	return reader_ctx[reader_idx];
}

int pcsc_release_reader_ctx(struct pcsc_reader_context *rd_ctx)
{
	int i;

	for (i = 0; i < PCSC_MAX_READERS; i++) {
		if (reader_ctx[i] && (reader_ctx[i] == rd_ctx)) {
			if (rd_ctx->handle.reader.slot)
				free(rd_ctx->handle.reader.slot);
			if (rd_ctx->handle.reader.file_name)
				free(rd_ctx->handle.reader.file_name);
			if (rd_ctx->handle.reader.name)
				free(rd_ctx->handle.reader.name);
			if(rd_ctx->name) free(rd_ctx->name);
			free(rd_ctx);
			reader_ctx[i] = NULL;
			return PCSC_S_SUCCESS;
		}
	}

	return PCSC_E_INVALID_PARAMETER;
}


list_head(pcsc_driver_list);

/*match device by type/id(vid, pid, etc.)*/
int pcsc_device_id_match(const struct pcsc_devid *match, 
				const struct pcsc_devid *id)
{
	if ((id->type != match->type)
		|| id->num < match->num
		|| memcmp(id->val, match->val, match->num *sizeof(id->val[0])))
		return 0;
	return 1;
}

struct pcsc_ifd_driver *pcsc_driver_by_name(const char *name)
{
	list_t *pos, *n;
	struct pcsc_ifd_driver *driver;
	
	list_iterate_forward(pos, n, &pcsc_driver_list) {
		driver = list_entry(pos, struct pcsc_ifd_driver, link);
		if (strcmp(driver->name, name) == 0)
			return driver;
	}

	return NULL;
}

const struct pcsc_ifd_driver *pcsc_driver_by_devid(const struct pcsc_devid *devid)
{
	list_t *pos, *n;
	struct pcsc_ifd_driver *driver;
	struct pcsc_devid  *tmpid;

	list_iterate_forward(pos, n, &pcsc_driver_list) {
		list_t *id_pos, *id_next;

		driver = list_entry(pos, struct pcsc_ifd_driver, link);
		list_iterate_forward(id_pos, id_next, &driver->dev_id_list) {
			tmpid = list_entry(id_pos, struct pcsc_devid, link);
			if (pcsc_device_id_match(tmpid, devid))
				return driver;
		}
	}

	return NULL;		
}

int pcsc_driver_register(const char *name, struct pcsc_ifd_driver_ops *ops)
{
	struct pcsc_ifd_driver *driver;

	driver = pcsc_driver_by_name(name);
	if (driver != NULL) {
		pcsc_log(PCSC_LOG_WARN, 
			"Driver '%s' has been registered", name);
		return PCSC_F_INTERNAL_ERROR;
	}

	driver = (struct pcsc_ifd_driver *)calloc(1, sizeof(*driver));
	if (!driver) {
		return PCSC_E_NO_MEMORY;
	}

	driver->name = strdup(name);
	driver->ops = ops;

	list_init(&driver->dev_id_list);
	list_init(&driver->link);

	list_insert_after(&driver->link, &pcsc_driver_list);

	return PCSC_S_SUCCESS;
}

void pcsc_driver_unregister(const char *name)
{
	struct pcsc_ifd_driver *driver;
	
	driver = pcsc_driver_by_name(name);
	if (driver == NULL) return;

	list_delete(&driver->link);
	free(driver->name);
	free(driver);
	driver = NULL;
}

/**
 * Add a device ID to a driver.
 * Current only support USB
 */
int pcsc_driver_add_id(const char *driver_name, struct pcsc_devid *devid)
{
	struct pcsc_ifd_driver *driver;

	driver = pcsc_driver_by_name(driver_name);
	if (driver == NULL) {
		pcsc_log(PCSC_LOG_WARN, "There is not driver '%s'", 
			 driver_name);
		return PCSC_F_INTERNAL_ERROR;
	}
	
	list_insert_after(&devid->link, &driver->dev_id_list);

	return 0;
}


static void pcsc_stm_exit_delay(void *eloop, void *user_ctx);

static void pcsc_stm_log(const stm_instance_t *fsmi,
			int level, const char *fmt, ...)
{
	int lvl;
	va_list ap;
	
	if (level == STM_LOG_ERR)
		lvl = LOG_ERR;
	else
		lvl = LOG_DEBUG;
	va_start(ap, fmt);
	loggingv(log_logger, lvl, fmt, ap);
	va_end(ap);
}

#define PCSC_STATE_INIT		0
#define PCSC_STATE_OPEN		1	/* Reader Opening */
#define PCSC_STATE_CSTATUSING	2	/* ICC statusing */
#define PCSC_STATE_CSTATUSED	3	/* ICC statused */
#define PCSC_STATE_PRESENT	4	/* ICC present */
#define PCSC_STATE_ABSENT	5	/* ICC absent */
#define PCSC_STATE_POWERUP	6	/* ICC powerup(actived) */
#define PCSC_STATE_DEACTIVE	7	/* ICC deactive */
#define PCSC_STATE_POWERDOWN	8	/* ICC powerdown(deactived) */
#define PCSC_STATE_EXIT		9	

#define PCSC_STATE_COUNT	10

#define PCSC_STATE_NAMES {	\
	"INIT",			\
	"OPEN",			\
	"CSTATUSING",		\
	"CSTATUSED",		\
	"PRESENT",		\
	"ABSENT",		\
	"POWERUP",		\
	"DEACTIVE",		\
	"POWERDOWN",		\
	"EXIT",			\
}

#define PCSC_EVENT_RIS		0	/* Reader InSerted*/
#define PCSC_EVENT_ORS		1	/* Open Reader Success */
#define PCSC_EVENT_ORF		2	/* Open Reader Failed */
#define PCSC_EVENT_CSS		3	/* icC Status Success */
#define PCSC_EVENT_CSF		4	/* icC Status Failed */
#define PCSC_EVENT_TO		5	/* Time Out*/
#define PCSC_EVENT_ICCP		6	/* ICC Present */
#define PCSC_EVENT_ICCNP	7	/* ICC Not Present */
#define PCSC_EVENT_CAS		8	/* Card Active Success */
#define PCSC_EVENT_CAF		9	/* Card Active Failed */
#define PCSC_EVENT_ICCA		10	/* ICC active */
#define PCSC_EVENT_ICCD		11	/* Card deactive */
#define PCSC_EVENT_ICCR		12	/* ICC removed */
#define PCSC_EVENT_CIS		13	/* Card InSerted */	
#define PCSC_EVENT_RRM		14	/* Reader ReMoved */
#define PCSC_EVENT_CDS		15	/* Card Deactive Success */
#define PCSC_EVENT_CDF		16	/* Card Deactive Failed */

#define PCSC_EVENT_COUNT	17

#define PCSC_EVENT_NAMES {	\
	"RIS",			\
	"ORS",			\
	"ORF",			\
	"CSS",			\
	"CSF",			\
	"TO",			\
	"ICCP",			\
	"ICCNP",		\
	"CAS",			\
	"CAF",			\
	"ICCA",			\
	"ICCD",			\
	"ICCR",			\
	"CIS",			\
	"RRM",			\
	"CDS",			\
	"CDF",			\
}

static void pcsc_raise_event(struct pcsc_reader_context *rd_ctx, int event)
{
	eloop_schedule_event(NULL, rd_ctx->fsmi, event, rd_ctx);
}

/* Reader InSerted */
static void pcsc_raise_ris(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_RIS);
}

/* Open Reader Success */
static void pcsc_raise_ors(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ORS);
}

/* Open Reader Failed */
static void pcsc_raise_orf(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ORF);
}

/* icC Status Success */
static void pcsc_raise_css(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CSS);
}

/* icC Status Failed */
static void pcsc_raise_csf(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CSF);
}

/* Time Out */
static void pcsc_raise_to(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_TO);
}

/* ICC Present */
static void pcsc_raise_iccp(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCP);
}

/* ICC Not Present */
static void pcsc_raise_iccnp(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCNP);
}

/* Card Active Success */
static void pcsc_raise_cas(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CAS);
}

/* Card Active Failed */
static void pcsc_raise_caf(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CAF);
}

/* ICC active */
static void pcsc_raise_icca(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCA);
}

/* ICC Deactive*/
static void pcsc_raise_iccd(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCD);
}

/* ICC removed*/
static void pcsc_raise_iccr(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_ICCR);
}

/* Card InSerted */
static void pcsc_raise_cis(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CIS);
}

/* Reader ReMoved */
static void pcsc_raise_rrm(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_RRM);
}

/* Card Deactive Success */
static void pcsc_raise_cds(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CDS);
}

/* Card Deactive Fail */
static void pcsc_raise_cdf(struct pcsc_reader_context *rd_ctx)
{
	pcsc_raise_event(rd_ctx, PCSC_EVENT_CDF);
}

static int pcsc_action_open(stm_instance_t *fsmi, void *data)
{
	struct pcsc_reader_context *rd_ctx;
	struct pcsc_reader *reader;
	pcsc_driver_handle_desc_t hd;
	int r;

	rd_ctx = (struct pcsc_reader_context *)data;
	reader = &rd_ctx->handle.reader;
	
	r = reader->driver->ops->open(reader->reader_type, reader->file_name, &hd);
	if (r != PCSC_S_SUCCESS) {
		pcsc_raise_orf(rd_ctx);
		return 1;
	}
	rd_ctx->handle.hd = hd;
	atomic_set(&rd_ctx->handle.refcnt, 0);

	/* Here we only support one slot. 
	 * TODO: support multi-slots reader */
	reader->slot = malloc(sizeof(struct pcsc_slot));
	if (reader->slot == NULL) {
		reader->driver->ops->close(hd);
		pcsc_raise_orf(rd_ctx);
		return 1;
	}
	memset(reader->slot, 0, sizeof(struct pcsc_slot));
	reader->slot[0].card_status = PCSC_CARD_STATUS_UNKNOWN;
	reader->nslots = 1;
	rd_ctx->handle.slot_idx = 0;

	/* Check if support PinPad/Display */
	reader->driver->ops->get_feature(hd, reader);

	pcsc_raise_ors(rd_ctx);

	return 1;
}

static int pcsc_action_close(stm_instance_t *fsmi, void *data)
{
	struct pcsc_reader_context *rd_ctx;
	
	rd_ctx = (struct pcsc_reader_context *)data;
	rd_ctx->handle.reader.driver->ops->close(rd_ctx->handle.hd);
	
	return 1;
}


static int pcsc_action_erc(stm_instance_t *fsmi, void *data)
{	
	eloop_register_timeout(NULL, 0, 0, pcsc_stm_exit_delay, NULL, data);

	return 1;
}

/* This "warm up" sequence is sometimes needed when pcscd is
 * restarted with the reader already connected. We get some
 * "usb_bulk_read: Resource temporarily unavailable" on the 
 * first few tries. It is an empirical hack*/
#define ICC_STATUS_RETRY_MAX	3
static int icc_status_retry = ICC_STATUS_RETRY_MAX;

static void icc_status_complete(struct pcsc_reader_context *rd_ctx)
{
	uint32_t icc_status;

	if (rd_ctx->ret != PCSC_S_SUCCESS) {
		if ((--icc_status_retry) > 0) {
			pcsc_raise_to(rd_ctx);
		} else {
			pcsc_raise_csf(rd_ctx);
			icc_status_retry = ICC_STATUS_RETRY_MAX;
		}
	} else {
		icc_status = rd_ctx->handle.reader.slot[rd_ctx->handle.slot_idx].card_status;
		if (icc_status & PCSC_CARD_PRESENT_MASK) {
			pcsc_raise_iccp(rd_ctx);
			rd_ctx->handle.reader.icc_seq++;
		} else {
			pcsc_raise_iccnp(rd_ctx);
		}
		icc_status_retry = ICC_STATUS_RETRY_MAX;
	}
}

static int pcsc_action_icc_status(stm_instance_t *fsmi, void *data)
{
	struct pcsc_reader_context *rd_ctx = (struct pcsc_reader_context *)data;
	const struct pcsc_ifd_driver *driver = rd_ctx->handle.reader.driver;
	int r;
	
	rd_ctx->callback = icc_status_complete;
	r = driver->ops->icc_status(rd_ctx);
	if (r == PCSC_S_SUCCESS)
		pcsc_raise_css(rd_ctx);
	else
		pcsc_raise_csf(rd_ctx);
	
	return 1;
}

static void power_on_complete(struct pcsc_reader_context *rd_ctx)
{
	struct pcsc_slot *slot;
	struct pcsc_atr_info atr_info;
	uint8_t atr[PCSC_MAX_ATR * 3];
	size_t i;

	if (rd_ctx->ret < 0) {
		if (rd_ctx->ret == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_caf(rd_ctx);
	} else {
		slot = &rd_ctx->handle.reader.slot[rd_ctx->handle.slot_idx];
		slot->atr_len = rd_ctx->ret;
		if (pcsc_parse_atr(slot->atr, slot->atr_len, &atr_info) 
			== PCSC_S_SUCCESS) {
			slot->proto = atr_info.default_proto;
			slot->proto_supported = atr_info.supported_protos;

			for (i = 0; i < slot->atr_len; i++) {
				if (i == slot->atr_len - 1)
					sprintf(atr + i * 3, "%02X", slot->atr[i]);
				else 
					sprintf(atr + i * 3, "%02X:", slot->atr[i]);
			}
			pcsc_log(PCSC_LOG_DEBUG, "ATR: %s", atr);
			if (slot->proto_supported & PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_DEBUG, "Support protocol: T0");
			if (slot->proto_supported & PCSC_PROTOCOL_T1)
				pcsc_log(PCSC_LOG_DEBUG, "Support protocol: T1");

			if (slot->proto == PCSC_PROTOCOL_T0)
				pcsc_log(PCSC_LOG_DEBUG, "Default protocol: T0");
		} else {
			slot->proto = PCSC_PROTOCOL_UNKNOWN;
			slot->proto_supported = PCSC_PROTOCOL_UNKNOWN;
		}	
		slot->card_status = PCSC_CARD_PRESENT_POWERUP;
		pcsc_raise_cas(rd_ctx);
	}
}

/* Active ICC*/
static int pcsc_action_aicc(stm_instance_t *fsmi, void *data)
{
	struct pcsc_reader_context *rd_ctx = (struct pcsc_reader_context *)data;
	const struct pcsc_ifd_driver *driver = rd_ctx->handle.reader.driver;
	int r;

	rd_ctx->callback = power_on_complete;
	r = driver->ops->power_on(rd_ctx);
	if (r == PCSC_S_SUCCESS)
		pcsc_raise_cas(rd_ctx);
	else {
		if (r == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_caf(rd_ctx);
	}	
	return 1;
}

static void power_off_complete(struct pcsc_reader_context *rd_ctx)
{
	if (rd_ctx->ret != PCSC_S_SUCCESS) {
		if (rd_ctx->ret == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_cdf(rd_ctx);
	} else {
		pcsc_raise_cds(rd_ctx);
	}
}

/* Deactive ICC*/
static int pcsc_action_dicc(stm_instance_t *fsmi, void *data)
{
	struct pcsc_reader_context *rd_ctx = (struct pcsc_reader_context *)data;
	const struct pcsc_ifd_driver *driver = rd_ctx->handle.reader.driver;
	int r;

	rd_ctx->callback = power_off_complete;
	r = driver->ops->power_off(rd_ctx);
	if (r != PCSC_S_SUCCESS) {
		if (r == PCSC_E_NO_SMARTCARD)
			pcsc_raise_iccnp(rd_ctx);
		else
			pcsc_raise_cdf(rd_ctx);
	}	
	return 1;
}

/* Card Not Present*/
static int pcsc_action_cnp(stm_instance_t *fsmi, void *data)
{
	struct pcsc_reader_context *rd_ctx = (struct pcsc_reader_context *)data;
	int conn_num;

	rd_ctx->handle.reader.slot[rd_ctx->handle.slot_idx].card_status = PCSC_CARD_ABSENT;
	
	conn_num = atomic_read(&rd_ctx->handle.refcnt);
	while (conn_num--) {
		pcsc_disconnect(&rd_ctx->handle);
	}

	return 1;
}

/* Clear handle*/
static int pcsc_action_chd(stm_instance_t *fsmi, void *data)
{
	struct pcsc_reader_context *rd_ctx = (struct pcsc_reader_context *)data;
	
	rd_ctx->handle.reader.driver->ops->cancel(rd_ctx->handle.hd);
	return 1;
}

static int pcsc_action_null(stm_instance_t *fsmi, void *data)
{
	return 1;
}

static const stm_action_fn pcsc_act_open [] = {
	pcsc_action_open,
};

static const stm_action_fn pcsc_act_erc [] = {
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_close_erc [] = {
	pcsc_action_close,
	pcsc_action_erc,
};

static const stm_action_fn pcsc_act_icc_status [] = {
	pcsc_action_icc_status,
};

static const stm_action_fn pcsc_act_aicc [] = {
	pcsc_action_aicc,
};

static const stm_action_fn pcsc_act_cnp [] = {
	pcsc_action_cnp,
};

static const stm_action_fn pcsc_act_chd_cnp [] = {
	pcsc_action_chd,
	pcsc_action_cnp,
};

static const stm_action_fn pcsc_act_chd_dicc [] = {
	pcsc_action_chd,
	pcsc_action_dicc,
};


static const stm_action_fn pcsc_act_null [] = {
	pcsc_action_null,
};


#define STATE(state)	PCSC_STATE_##state
#define EVENT(event)	PCSC_EVENT_##event
#define ACTION(stem)	pcsc_act_##stem, \
		sizeof(pcsc_act_##stem) / sizeof(stm_action_fn) 

static const stm_entry_t pcsc_stm_entries[] = {
	/* state	event		action			new_state */
	{STATE(INIT),	EVENT(RIS),	ACTION(open),		STATE(OPEN),},

	{STATE(OPEN),	EVENT(ORS),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(OPEN),	EVENT(ORF),	ACTION(erc),		STATE(EXIT),},

	{STATE(CSTATUSING),EVENT(CSS),	ACTION(null),		STATE(CSTATUSED),},
	{STATE(CSTATUSING),EVENT(CSF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(CSTATUSING),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(CSTATUSED),EVENT(CSF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(CSTATUSED),EVENT(TO),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(CSTATUSED),EVENT(ICCP),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(CSTATUSED),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(CSTATUSED),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},
	
	{STATE(PRESENT),EVENT(CAS),	ACTION(null),		STATE(POWERUP),},
	{STATE(PRESENT),EVENT(CAF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(PRESENT),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(PRESENT),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(PRESENT),EVENT(RRM),	ACTION(erc),		STATE(EXIT),},

	{STATE(ABSENT),	EVENT(CIS),	ACTION(icc_status),	STATE(CSTATUSING),},
	{STATE(ABSENT),	EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(POWERUP),EVENT(ICCA),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(POWERUP),EVENT(ICCD),	ACTION(chd_dicc),	STATE(DEACTIVE),},
	{STATE(POWERUP),EVENT(ICCR),	ACTION(chd_cnp),	STATE(ABSENT),},
	{STATE(POWERUP),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(DEACTIVE),EVENT(CDS),	ACTION(null),		STATE(POWERDOWN),},
	{STATE(DEACTIVE),EVENT(CDF),	ACTION(close_erc),	STATE(EXIT),},
	{STATE(DEACTIVE),EVENT(ICCNP),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(DEACTIVE),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(DEACTIVE),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{STATE(POWERDOWN),EVENT(ICCA),	ACTION(aicc),		STATE(PRESENT),},
	{STATE(POWERDOWN),EVENT(ICCR),	ACTION(cnp),		STATE(ABSENT),},
	{STATE(POWERDOWN),EVENT(RRM),	ACTION(close_erc),	STATE(EXIT),},

	{0,		0,		ACTION(null),		0,},
};

static const char *pcsc_state_names[] = PCSC_STATE_NAMES;
static const char *pcsc_event_names[] = PCSC_EVENT_NAMES;

const stm_table_t pcsc_stm_table = {
	"pcsc",
	pcsc_stm_log,
	PCSC_STATE_COUNT,
	&pcsc_state_names[0],
	PCSC_EVENT_COUNT,
	&pcsc_event_names[0],
	pcsc_stm_entries,	
};

#undef STATE
#undef EVENT
#undef ACTION

int pcsc_reader_up(const char *filename)
{
	uint16_t vendor_id, product_id;
	const struct pcsc_ifd_driver *driver;
	struct pcsc_devid devid;
	struct pcsc_reader_context *rd_ctx;
	char vpid[10];
#ifdef CONFIG_USB
	struct usb_device *usb_dev;
#endif
	if (pcsc_reader_ctx_by_filename(filename))
		return PCSC_E_READER_BUSY;

#ifdef CONFIG_USB
	usb_dev = usb_get_device(filename);
	if (!usb_dev)
		return PCSC_E_UNKNOWN_READER;
	vendor_id = usb_dev->dev_desc->idVendor;
	product_id = usb_dev->dev_desc->idProduct;
	usb_put_device(usb_dev);
	
	devid.type = PCSC_READER_TYPE_USB;
	devid.num = 2;
	devid.val[0] = vendor_id;
	devid.val[1] = product_id;

	driver = pcsc_driver_by_devid(&devid);
	if (driver == NULL)
		driver = pcsc_driver_by_name("CCID");
	if (driver == NULL)
		return PCSC_E_UNKNOWN_READER;
#else
	return PCSC_E_NOT_SUPPORTED;
#endif
	sprintf(vpid, "%04X/%04X", vendor_id, product_id);

	rd_ctx = pcsc_alloc_reader_ctx();
	if (rd_ctx == NULL)
		return PCSC_E_NO_MEMORY;

	rd_ctx->name = strdup(vpid);
	rd_ctx->handle.reader.file_name = strdup(filename);
	rd_ctx->handle.reader.driver = driver;
	
	rd_ctx->fsmi = stm_table_new(&pcsc_stm_table, rd_ctx->name, PCSC_STATE_INIT);
	if (!rd_ctx->fsmi) {
		pcsc_release_reader_ctx(rd_ctx);
		return PCSC_E_NO_MEMORY;
	}
	
	pcsc_raise_ris(rd_ctx);

	return PCSC_S_SUCCESS;
}

int pcsc_reader_down(const char *filename)
{
	int i;

	for(i = 0; i < PCSC_MAX_READERS;i ++) {
		if (reader_ctx[i]) {
			pcsc_raise_rrm(reader_ctx[i]);			
		}
	}
	return PCSC_S_SUCCESS;
}

int pcsc_icc_poweron(int reader_idx)
{
	if (reader_idx > PCSC_MAX_READERS)
		return PCSC_E_INVALID_PARAMETER;
	if (reader_ctx[reader_idx] == NULL)
		return PCSC_E_INVALID_HANDLE;
	pcsc_raise_icca(reader_ctx[reader_idx]);

	return PCSC_S_SUCCESS;
}

int pcsc_icc_poweroff(int reader_idx)
{
	if (reader_idx > PCSC_MAX_READERS)
		return PCSC_E_INVALID_PARAMETER;
	if (reader_ctx[reader_idx] == NULL)
		return PCSC_E_INVALID_HANDLE;
	pcsc_raise_iccd(reader_ctx[reader_idx]);

	return PCSC_S_SUCCESS;
}

int pcsc_icc_insert(int reader_idx)
{
	if (reader_idx > PCSC_MAX_READERS)
		return PCSC_E_INVALID_PARAMETER;
	if (reader_ctx[reader_idx] == NULL)
		return PCSC_E_INVALID_HANDLE;
	pcsc_raise_cis(reader_ctx[reader_idx]);

	return PCSC_S_SUCCESS;
}

int pcsc_icc_remove(int reader_idx)
{
	if (reader_idx > PCSC_MAX_READERS)
		return PCSC_E_INVALID_PARAMETER;
	if (reader_ctx[reader_idx] == NULL)
		return PCSC_E_INVALID_HANDLE;
	pcsc_raise_iccr(reader_ctx[reader_idx]);

	return PCSC_S_SUCCESS;
}


static void pcsc_stm_exit(struct pcsc_reader_context *rd_ctx)
{

	if (rd_ctx->fsmi) {
		eloop_cleanup_events(NULL, rd_ctx->fsmi);
		stm_table_free(rd_ctx->fsmi);
	}
	pcsc_release_reader_ctx(rd_ctx);
}

static void pcsc_stm_exit_delay(void *eloop, void *user_ctx) 
{
	pcsc_stm_exit((struct pcsc_reader_context *)user_ctx);
}


int pcsc_card_status(int reader_idx, int slot_idx, 
		     uint32_t *icc_status)
{
	struct pcsc_reader *reader;

	if (reader_idx >= PCSC_MAX_READERS) {
		pcsc_log(PCSC_LOG_WARN, "There is not reader %d", reader_idx);
		return PCSC_E_INVALID_PARAMETER;
	}
	if (!reader_ctx[reader_idx])
		return PCSC_E_INVALID_HANDLE;
	reader = &reader_ctx[reader_idx]->handle.reader;

	if (slot_idx >= reader->nslots)
		return PCSC_E_INVALID_PARAMETER;
	*icc_status = reader->slot[slot_idx].card_status;
	
	return PCSC_S_SUCCESS;
}

struct pcsc_ifd_handle *pcsc_connect(int reader_idx, int slot_idx)
{
	uint32_t icc_status;

	if (reader_idx >= PCSC_MAX_READERS)
		return NULL;
	if ( reader_ctx[reader_idx] == NULL)
		return NULL;
	if (atomic_read(&reader_ctx[reader_idx]->handle.refcnt) > 0)
		return NULL;
	if (slot_idx >= reader_ctx[reader_idx]->handle.reader.nslots)
		return NULL;
	icc_status = reader_ctx[reader_idx]->handle.reader.slot[slot_idx].card_status;
	if (!(icc_status & PCSC_CARD_PRESENT_MASK))
		return NULL;

	atomic_inc(&reader_ctx[reader_idx]->handle.refcnt);
	reader_ctx[reader_idx]->handle.icc_seq = 
			reader_ctx[reader_idx]->handle.reader.icc_seq;

	return &reader_ctx[reader_idx]->handle;
}

int pcsc_check_handle_valid(struct pcsc_ifd_handle *handle)
{
	if (!handle) return 0;

	return (handle->icc_seq == handle->reader.icc_seq);
}

int pcsc_disconnect(struct pcsc_ifd_handle *handle)
{
	int i;

	for (i = 0; i < PCSC_MAX_READERS; i++) {
		if (reader_ctx[i] && &reader_ctx[i]->handle == handle) {
			atomic_dec(&reader_ctx[i]->handle.refcnt);
			return PCSC_S_SUCCESS;
		}
	}

	return PCSC_E_INVALID_HANDLE;
}

int pcsc_transmit(struct pcsc_transmit_param *param)
{
	const struct pcsc_ifd_driver *driver = param->handle->reader.driver;

	return driver->ops->xfr_block(param->handle->hd, param);
}

int pcsc_ifd_control(struct pcsc_transmit_param *param)
{
	const struct pcsc_ifd_driver *driver = param->handle->reader.driver;

	return driver->ops->ifd_ctl(param->handle->hd, param);		
}

/*
int pcsc_pin_verify(struct pcsc_transmit_param *param)
{
	const struct pcsc_ifd_driver *driver = param->handle->reader.driver;

	return driver->ops->pin_verify(param->handle->hd, param);
}

int pcsc_pin_modify(struct pcsc_transmit_param *param)
{
	const struct pcsc_ifd_driver *driver = param->handle->reader.driver;

	return driver->ops->pin_modify(param->handle->hd, param);
}
*/