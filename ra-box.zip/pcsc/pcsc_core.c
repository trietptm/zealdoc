#include "pcsc_priv.h"
#include <udev.h>

int pcsc_logger = 0;
log_source_t pcsc_log_source = {
	"pcsc"
};

void pcsc_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(pcsc_logger, level, format, ap);
	va_end(ap);
}

static int __init pcsc_log_init(void)
{
	pcsc_logger = log_register_source(&pcsc_log_source);
	return !pcsc_logger;
}

static void __exit pcsc_log_exit(void)
{
	log_unregister_source(pcsc_logger);
}

static void __init pcsc_driver_init(void)
{
	/*Register Driver(s)*/
	pcsc_driver_register_ccid();

	/*Register VID/PID(s) with the drivers*/
	ccid_register_devids();
}

static void __exit pcsc_driver_exit(void)
{
	ccid_unregister_devids();
	pcsc_driver_unregister_ccid();
}

modlinkage int __init pcsc_init(void)
{
	pcsc_log_init();
	pcsc_driver_init();
	pcsc_reader_context_init();
	pcsc_cmd_init();

	return 0;
}

modlinkage void __exit pcsc_exit(void)
{
	pcsc_cmd_exit();
	pcsc_reader_context_exit();
	pcsc_driver_exit();
	pcsc_log_exit();
}

subsys_initcall(pcsc_init);
subsys_exitcall(pcsc_exit);
