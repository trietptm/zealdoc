#include "pcsc_priv.h"
#include <ccid.h>

static int pcsc2ccid_reader_type(int pcsc_reader_type)
{
	switch (pcsc_reader_type) {
	case PCSC_READER_TYPE_USB:
		return CCID_DEVICE_TYPE_USB;
	default:
		return -1;
	}
}

static int pcsc2ccid_protocol(int pcsc_proto)
{
	switch(pcsc_proto) {
	case PCSC_PROTOCOL_T0:
		return CCID_PROTOCOL_T0;
	case PCSC_PROTOCOL_T1:
		return CCID_PROTOCOL_T1;
	default:
		return -1;
	}
}

static int ccid2pcsc_errno(int ccid_errno)
{
	switch(ccid_errno) {
	case CCID_SUCCESS:
		return PCSC_S_SUCCESS;

	case CCID_ERROR_NO_MEM:
		return PCSC_E_NO_MEMORY;
	case CCID_ERROR_CANCELLED:
		return PCSC_E_CANCELLED;
	case CCID_ERROR_NOT_SUPPORTED:
	case CCID_ERROR_INCOMPATIBLE_DEV:
		return PCSC_E_NOT_SUPPORTED;
	case CCID_ERROR_INVALID_ARG:
		return PCSC_E_INVALID_PARAMETER;
	case CCID_ERROR_TIMEOUT:
	case CCID_ERROR_USER_TIMEOUT:
		return PCSC_E_TIMEOUT;
	case CCID_ERROR_USER_ABORT:
		return PCSC_E_CANCELLED;
	case CCID_ERROR_INVALID_SLOT:
		return PCSC_E_INVALID_SLOT;	

	case CCID_ERROR_STALL:
		return PCSC_E_READER_UNAVAILABLE;
	case CCID_ERROR_NO_DEVICE:
		return PCSC_E_NO_READER;
	case CCID_ERROR_BUSY:
		return PCSC_E_READER_BUSY;	
	
	case CCID_ERROR_NO_CARD:
		return PCSC_E_NO_SMARTCARD;
	case CCID_ERROR_NO_ATR:
		return PCSC_E_INVALID_ATR;
	
	case CCID_ERROR_COMMUNICATION:
	case CCID_ERROR_COMM_ERR:
	case CCID_ERROR_OVERFLOW:
	case CCID_ERROR_GENERIC:
	default:
		return PCSC_F_INTERNAL_ERROR;
	}
}

static int pcsc_ccid_open(int pcsc_dev_type, const char *file_name, 
			  pcsc_driver_handle_desc_t *hd)
{
	int ccid_dev_type = pcsc2ccid_reader_type(pcsc_dev_type);
	int r;
	
	if (ccid_dev_type == -1)
		return PCSC_E_UNKNOWN_READER;

	r = ccid_open(ccid_dev_type, file_name, hd);
	if (r != CCID_SUCCESS) {
		if (r == CCID_ERROR_NO_DEVICE)
			return PCSC_E_UNKNOWN_READER;
		else
			return PCSC_F_INTERNAL_ERROR;
	}
	
	return PCSC_S_SUCCESS;
}

static int pcsc_ccid_close(pcsc_driver_handle_desc_t hd)
{
	ccid_close(hd);
	return PCSC_S_SUCCESS;
}

static int pcsc_ccid_get_feature(pcsc_driver_handle_desc_t hd, 
				 struct pcsc_reader *reader)
{
	uint8_t feature_tlv[11 * 6];
	int i, num, len;
	struct pcsc_feature_tlv *tlv;

	memset(feature_tlv, 0, sizeof(feature_tlv));
	len = ccid_ifd_control(hd, CM_IOCTL_GET_FEATURE_REQUEST, 
			 NULL, 0, feature_tlv, sizeof(feature_tlv), NULL, NULL);
	if (len < 0)
		return len;
	if (!(len % sizeof(struct pcsc_feature_tlv)))
		return PCSC_F_INTERNAL_ERROR;
	num = len / sizeof(struct pcsc_feature_tlv);

	tlv = (struct pcsc_feature_tlv *)feature_tlv;
	for (i = 0; i < num; i++) {		
		switch (tlv[i].tag) {
		case FEATURE_VERIFY_PIN_START:
			reader->path10.verify_ioctl_start = ntohl(tlv[i].value);
			break;
		case FEATURE_VERIFY_PIN_FINISH:
			reader->path10.verify_ioctl_finish = ntohl(tlv[i].value);
			break;
		case FEATURE_MODIFY_PIN_START:
			reader->path10.modify_ioctl_start = ntohl(tlv[i].value);
			break;
		case FEATURE_MODIFY_PIN_FINISH:
			reader->path10.modify_ioctl_finish = ntohl(tlv[i].value);
			break;
		case FEATURE_VERIFY_PIN_DIRECT:
			reader->path10.verify_ioctl = ntohl(tlv[i].value);
			break;
		case FEATURE_MODIFY_PIN_DIRECT:
			reader->path10.modify_ioctl = ntohl(tlv[i].value);
			break;
		default:
			break;
		}
	}
	if (reader->path10.verify_ioctl ||
		(reader->path10.verify_ioctl_start && reader->path10.verify_ioctl_finish)) {
		reader->keypad = 1;
		reader->path10.pinpad_support |= CCID_CLASS_PIN_VERIFY;
	}
	if (reader->path10.modify_ioctl ||
		(reader->path10.modify_ioctl_start && reader->path10.modify_ioctl_finish)) {
		reader->keypad = 1;
		reader->path10.pinpad_support |= CCID_CLASS_PIN_MODIFY;
	}


	/* FIXME: how to know whether a reader support LCD ? */
	/*
	if (ccid_desc->wLcdLayout != 0) {
		reader->display = 1;
		reader->col_num = (ccid_desc->wLcdLayout >> 8) & 0xFF;
		reader->row_num = ccid_desc->wLcdLayout & 0xFF;
	}
	*/

	return PCSC_S_SUCCESS;
}

static int pcsc_ccid_cancel(pcsc_driver_handle_desc_t hd)
{
	int r;
	r = ccid_cancel(hd);
	
	return ccid2pcsc_errno(r);
}

static void __ccid_icc_status_cb (void *user_data, int ret)
{
	struct pcsc_reader_context *rd_ctx = 
			(struct pcsc_reader_context *)user_data;
	struct pcsc_slot *slot;
	uint8_t card_status;
	
	slot = &rd_ctx->handle.reader.slot[rd_ctx->handle.slot_idx];
	if (ret < 0)
		rd_ctx->ret = ccid2pcsc_errno(ret);
	else {
		card_status = (uint8_t)slot->card_status;
		if (card_status == CCID_CARD_PRESENT_ACTIVE)
			slot->card_status = PCSC_CARD_PRESENT_POWERUP;
		else if (card_status == CCID_CARD_PRESENT_DEACTIVE)
			slot->card_status = PCSC_CARD_PRESENT_POWERDOWN;
		else
			slot->card_status = PCSC_CARD_ABSENT;
		rd_ctx->ret = PCSC_S_SUCCESS;
		
	}
	rd_ctx->callback(rd_ctx);
}

static int pcsc_ccid_icc_status(struct pcsc_reader_context *rd_ctx) 
{
	struct pcsc_slot *slot;
	int r;

	slot = &rd_ctx->handle.reader.slot[rd_ctx->handle.slot_idx];
	r = ccid_get_slot_status(rd_ctx->handle.hd, (uint8_t *) &slot->card_status, 
				 __ccid_icc_status_cb, rd_ctx);
	if (r != CCID_SUCCESS) 
		return ccid2pcsc_errno(r);

	return PCSC_S_SUCCESS;
}

static void __ccid_power_on_cb (void *user_data, int ret)
{
	struct pcsc_reader_context *rd_ctx = 
			(struct pcsc_reader_context *)user_data;

	if (ret < 0)
		rd_ctx->ret = ccid2pcsc_errno(ret);
	else
		rd_ctx->ret = ret;

	rd_ctx->callback(rd_ctx);
}

static int pcsc_ccid_power_on(struct pcsc_reader_context *rd_ctx) 
{
	int r;
	struct pcsc_slot *slot;

	slot = &rd_ctx->handle.reader.slot[rd_ctx->handle.slot_idx];
	r = ccid_power_on(rd_ctx->handle.hd, slot->atr, sizeof(slot->atr), 
			  __ccid_power_on_cb, rd_ctx);
	if (r != CCID_SUCCESS)
		return ccid2pcsc_errno(r);
	
	return PCSC_S_SUCCESS;
}

static void __ccid_power_off_cb(void *user_data, int ret)
{
	struct pcsc_reader_context *rd_ctx = 
			(struct pcsc_reader_context *)user_data;
	struct pcsc_slot *slot;
	uint8_t card_status;
	
	slot = &rd_ctx->handle.reader.slot[rd_ctx->handle.slot_idx];
	if (ret < 0)
		rd_ctx->ret = ccid2pcsc_errno(ret);
	else {
		card_status = (uint8_t)slot->card_status;
		if (card_status == CCID_CARD_PRESENT_ACTIVE)
			slot->card_status = PCSC_CARD_PRESENT_POWERUP;
		else if (card_status == CCID_CARD_PRESENT_DEACTIVE)
			slot->card_status = PCSC_CARD_PRESENT_POWERDOWN;
		else
			slot->card_status = PCSC_CARD_ABSENT;	
		rd_ctx->ret = PCSC_S_SUCCESS;
	}

	rd_ctx->callback(rd_ctx);
}

static int pcsc_ccid_power_off(struct pcsc_reader_context *rd_ctx) 
{
	int r;
	struct pcsc_slot *slot;

	slot = &rd_ctx->handle.reader.slot[rd_ctx->handle.slot_idx];
	r = ccid_power_off(rd_ctx->handle.hd, (uint8_t *)&slot->card_status,
			   __ccid_power_off_cb, rd_ctx);
	if (r != CCID_SUCCESS)
		return ccid2pcsc_errno(r);
	
	return PCSC_S_SUCCESS;
}

static void __ccid_xfr_block_cb(void *user_data, int ret)
{
	struct pcsc_transmit_param *pcsc_param;
	
	pcsc_param = (struct pcsc_transmit_param *)user_data;
	if (ret < 0) {
		pcsc_param->ret = ccid2pcsc_errno(ret);
	} else {
		pcsc_param->ret = PCSC_S_SUCCESS;
		pcsc_param->rbuf_actual = ret;
	}
	
	pcsc_param->callback(pcsc_param);
}

static int pcsc_ccid_xfr_block(pcsc_driver_handle_desc_t hd, 
			       struct pcsc_transmit_param *pcsc_param)
{
	struct pcsc_ifd_handle *handle = pcsc_param->handle;
	int ccid_proto;
	int r;
	
	ccid_proto = pcsc2ccid_protocol(handle->reader.slot[handle->slot_idx].proto);
	if (ccid_proto == -1)
		return PCSC_E_INVALID_PARAMETER;

	r = ccid_xfrblock(hd, ccid_proto, pcsc_param->sbuf, pcsc_param->sbuf_len,
			  pcsc_param->rbuf, pcsc_param->rbuf_len, 
			  __ccid_xfr_block_cb, pcsc_param);
	if (r != CCID_SUCCESS)
		return ccid2pcsc_errno(r);
	
	return PCSC_S_SUCCESS;
}


static void __ccid_ifd_control_cb(void *user_data, int ret)
{
	struct pcsc_transmit_param *pcsc_param = 
				(struct pcsc_transmit_param *)user_data;
	if (ret < 0) {
		pcsc_param->ret = ccid2pcsc_errno(ret);
	} else {
		pcsc_param->ret = PCSC_S_SUCCESS;
		pcsc_param->rbuf_actual = ret;
	}

	pcsc_param->callback(pcsc_param);	
}

static int pcsc_ccid_ifd_control(pcsc_driver_handle_desc_t hd, 
				 struct pcsc_transmit_param *pcsc_param)
{
	int r;

	r = ccid_ifd_control(hd, pcsc_param->ioctl, 
			     pcsc_param->sbuf, pcsc_param->sbuf_len, 
			     pcsc_param->rbuf, pcsc_param->rbuf_len, 
			     __ccid_ifd_control_cb, pcsc_param);
	
	return ccid2pcsc_errno(r);
}

static struct pcsc_ifd_driver_ops ccid_ops = {
	"CCID",
	pcsc_ccid_open, 		   
	pcsc_ccid_close,
	pcsc_ccid_get_feature,

	pcsc_ccid_cancel,
	pcsc_ccid_icc_status,
	pcsc_ccid_power_on,
	pcsc_ccid_power_off,
	pcsc_ccid_xfr_block,
	pcsc_ccid_ifd_control,
};

int pcsc_driver_register_ccid(void)
{
	return pcsc_driver_register(ccid_ops.name, &ccid_ops);
}

void pcsc_driver_unregister_ccid(void)
{
	pcsc_driver_unregister(ccid_ops.name);
}

void ccid_register_devids(void)
{
	struct pcsc_devid *devid;
	struct pcsc_ifd_driver *ccid;

	ccid = pcsc_driver_by_name(ccid_ops.name);
	if (!ccid) {
		pcsc_log(PCSC_LOG_WARN, "Driver %d has not been registered.", 
			 ccid_ops.name);
		return;
	}

	devid = malloc(sizeof(*devid));
	if (!devid)
		return;
	devid->type = PCSC_READER_TYPE_USB;
	devid->num = 2;
	devid->val[0] = 0x076B;
	devid->val[1] = 0x5321;

	pcsc_driver_add_id(ccid_ops.name, devid);
}

void ccid_unregister_devids(void)
{
	struct pcsc_ifd_driver *ccid;
	struct pcsc_devid *pos, *n;

	ccid = pcsc_driver_by_name(ccid_ops.name);
	if (!ccid) {
		pcsc_log(PCSC_LOG_WARN, "Driver %d has not been registered.", 
			 ccid_ops.name);
		return;
	}
	
	list_for_each_entry_safe(struct pcsc_devid, pos, n, &ccid->dev_id_list,
		link) {
		list_delete(&pos->link);
		free(pos);
	}
}
