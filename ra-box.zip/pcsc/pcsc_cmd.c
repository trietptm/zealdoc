#include "pcsc_priv.h"

#include <scard.h>
#include <strutl.h>
#if 1
#include <ccid.h>
#endif

static int pcsc_tool_list(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
static int pcsc_tool_remove(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
static int pcsc_tool_inserted(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
static int pcsc_tool_poweron(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
static int pcsc_tool_poweroff(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
static int pcsc_tool_icc_insert(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
static int pcsc_tool_icc_remove(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);

static int pcsc_cmd_select_file(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);

#define PCSC_TOOLS_DESP	"pcsc"

ui_argument_t pcsc_select_args = {
	"file ID",
	"file ID",
	NULL,
	UI_TYPE_STRING,
};

ui_argument_t pcsc_reader_idx_args = {
	"reader index",
	"reader index",
	NULL,
	UI_TYPE_STRING,
};

ui_argument_t pcsc_reader_name_args = {
	"reader",
	"reader name",
	NULL,
	UI_TYPE_STRING,
};

ui_command_t pcsc_inserted_cmd = {
	"insert",
	"reader inserted",
	".pcsc",
	UI_CMD_SINGLE_INST,
	&pcsc_reader_name_args,
	1,
	LIST_HEAD_INIT(pcsc_inserted_cmd.link),
	pcsc_tool_inserted,
};

ui_command_t pcsc_remove_cmd = {
	"remove",
	"reader inserted",
	".pcsc",
	UI_CMD_SINGLE_INST,
	&pcsc_reader_name_args,
	1,
	LIST_HEAD_INIT(pcsc_remove_cmd.link),
	pcsc_tool_remove,
};

ui_command_t pcsc_poweron_cmd = {
	"poweron",
	"power on",
	".pcsc",
	UI_CMD_SINGLE_INST,
	&pcsc_reader_idx_args,
	1,
	LIST_HEAD_INIT(pcsc_poweron_cmd.link),
	pcsc_tool_poweron,
};

ui_command_t pcsc_poweroff_cmd = {
	"poweroff",
	"power off",
	".pcsc",
	UI_CMD_SINGLE_INST,
	&pcsc_reader_idx_args,
	1,
	LIST_HEAD_INIT(pcsc_poweroff_cmd.link),
	pcsc_tool_poweroff,
};

ui_command_t pcsc_icc_insert_cmd = {
	"icc_insert",
	"icc insert",
	".pcsc",
	UI_CMD_SINGLE_INST,
	&pcsc_reader_idx_args,
	1,
	LIST_HEAD_INIT(pcsc_icc_insert_cmd.link),
	pcsc_tool_icc_insert,
};

ui_command_t pcsc_icc_remove_cmd = {
	"icc_remove",
	"icc remove",
	".pcsc",
	UI_CMD_SINGLE_INST,
	&pcsc_reader_idx_args,
	1,
	LIST_HEAD_INIT(pcsc_icc_remove_cmd.link),
	pcsc_tool_icc_remove,
};

ui_command_t pcsc_list_command = {
	"list",
	"list reader",
	".pcsc",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(pcsc_list_command.link),
	pcsc_tool_list,
};

ui_command_t pcsc_select_command = {
	"select",
	"select file",
	".pcsc",
	UI_CMD_SINGLE_INST,
	&pcsc_select_args,
	1,
	LIST_HEAD_INIT(pcsc_select_command.link),
	pcsc_cmd_select_file,
};



ui_schema_t pcsc_schema[] = {
	{ UI_TYPE_CLASS, 
	  UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, 
	  NULL, 
	  NULL,
	  ".pcsc", 
	  "pcsc", 
	  PCSC_TOOLS_DESP },
	
	{ UI_TYPE_NONE },
};

int __init pcsc_cmd_init(void)
{
	ui_register_schema(pcsc_schema);
	ui_register_command(&pcsc_inserted_cmd);
	ui_register_command(&pcsc_remove_cmd);
	ui_register_command(&pcsc_poweron_cmd);
	ui_register_command(&pcsc_poweroff_cmd);
	ui_register_command(&pcsc_icc_insert_cmd);
	ui_register_command(&pcsc_icc_remove_cmd);
	ui_register_command(&pcsc_list_command);
	ui_register_command(&pcsc_select_command);
	
	return 0;
}
	
void __exit pcsc_cmd_exit(void)
{
	ui_unregister_command(&pcsc_inserted_cmd);
	ui_unregister_command(&pcsc_remove_cmd);
	ui_unregister_command(&pcsc_poweron_cmd);
	ui_unregister_command(&pcsc_poweroff_cmd);
	ui_unregister_command(&pcsc_icc_insert_cmd);
	ui_unregister_command(&pcsc_icc_remove_cmd);
	ui_unregister_command(&pcsc_list_command);
	ui_unregister_command(&pcsc_select_command);
	ui_unregister_schema(pcsc_schema);
}

static uint8_t hex2byte(const char *hex)
{
	int total = 0, h, i;
	for (i = 0; i < 2; i++) {
		h = hexchar(hex[i]);
		total *= 16;
		total += h;
	}
	return total;
}

static uint8_t *tpdu = NULL;
static uint8_t  select_rbuf[1024];

static void select_callback(struct pcsc_transmit_param *param)
{
	size_t rbuf_actual;
	size_t i;
	char buffer[1024 * 3];

	if (param->ret != PCSC_S_SUCCESS) {
		pcsc_log(PCSC_LOG_ERR, "select file failed: %d", param->ret);
	} else {
		rbuf_actual = param->rbuf_actual;
		for (i = 0; i < rbuf_actual; i++) {
			sprintf(buffer + 3 * i, "%02X ", *(param->rbuf++));
		}
		pcsc_log(PCSC_LOG_DEBUG, "select file success: %s", buffer);
	}

	free(tpdu);
	free(param);
	pcsc_disconnect(param->handle);
}

static int pcsc_cmd_select_file(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	struct pcsc_transmit_param *pcsc_param;
	struct pcsc_ifd_handle *handle;
	struct scard_apdu apdu;
	char *file_id;
	uint8_t path[2];
	size_t tpdu_len;
	int reader_idx = 0, slot_idx = 0;
	uint32_t icc_status;
	int r;

	handle = pcsc_connect(reader_idx, slot_idx);
	if (handle == NULL) {
		pcsc_log(PCSC_LOG_DEBUG, "can not connect to %d", reader_idx);
		return -1;
	}

	r = pcsc_card_status(reader_idx, slot_idx, &icc_status);
	if (r != PCSC_S_SUCCESS) {
		pcsc_log(PCSC_LOG_ERR, "Error: pcsc_card_status");
		pcsc_disconnect(handle);
		return r;
	}
	if (icc_status != PCSC_CARD_PRESENT_POWERUP) {
		pcsc_log(PCSC_LOG_ERR, "Card not present or not powerup");
		pcsc_disconnect(handle);
		return PCSC_E_UNKNOWN_CARD;
	}
	file_id = argv[0];
	if (strlen(file_id) != 4) {
		pcsc_disconnect(handle);
		pcsc_log(PCSC_LOG_ERR, "there is no reader %d/%d", 
			 reader_idx, slot_idx);
		return -1;
	}

	path[0] = hex2byte(file_id);
	path[1] = hex2byte(file_id + 2);

	memset(&apdu, 0, sizeof(struct scard_apdu));
	apdu.cse = SCARD_APDU_CASE_4_SHORT;
	apdu.cla = 0x00;
	apdu.ins = 0xA4;
	apdu.p1 = 0x00;/* Select MF, DF or EF (data field=identifier or empty) */
	apdu.p2 = 0x00;
	apdu.lc = 0x02;
	apdu.data = path;
	apdu.datalen = 2;
	apdu.le = 256;
	apdu.resp = select_rbuf;
	apdu.resplen = sizeof(select_rbuf);

	tpdu_len = scard_apdu_get_length(&apdu, handle->reader.slot[0].proto);

	tpdu = malloc(tpdu_len);
	if (!tpdu) {
		pcsc_disconnect(handle);
		return SCARD_ERR_NO_MEM;
	}

	r = scard_apdu2tpdu(&apdu, handle->reader.slot[0].proto, tpdu, tpdu_len);
	if (r != SCARD_SUCCESS) {
		free(tpdu);
		pcsc_disconnect(handle);
		return r;
	}
	
	{
		uint8_t tpdu_str[256 * 3];
		size_t i;

		memset(tpdu_str, 0, sizeof(tpdu_str));
		for (i = 0; i < tpdu_len; i++) {
			sprintf(tpdu_str + i * 3, "%02X ", tpdu[i]);
		}
		pcsc_log(PCSC_LOG_DEBUG, "--> %s", tpdu_str);
	}	
	
	pcsc_param = malloc(sizeof(struct pcsc_transmit_param));
	if (!pcsc_param) {
		free(tpdu);
		pcsc_disconnect(handle);
		return PCSC_E_NO_MEMORY;
	}
	pcsc_param->handle = handle;
	pcsc_param->sbuf = tpdu;
	pcsc_param->sbuf_len = tpdu_len;
	pcsc_param->rbuf = select_rbuf;
	pcsc_param->rbuf_len = sizeof(select_rbuf);
	pcsc_param->callback = select_callback;

	r = pcsc_transmit(pcsc_param);
	if (r != PCSC_S_SUCCESS) {
		free(tpdu);
		pcsc_disconnect(handle);
		pcsc_log(PCSC_LOG_ERR, "pcsc_transmit %d", r);
	}
	return r;
}

static int pcsc_tool_inserted(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	const char *file_name;

	file_name = argv[0];

	return pcsc_reader_up(file_name);
	
}

static int pcsc_tool_remove(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	const char *file_name;

	file_name = argv[0];

	return pcsc_reader_down(file_name);
}

static int pcsc_tool_list(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int i;
	int count = 0;

	pcsc_log(PCSC_LOG_DEBUG, "\tIndex\t Refcnt\t Name");
	for (i = 0; i < PCSC_MAX_READERS; i++) {
		if (reader_ctx[i]) {
			pcsc_log(PCSC_LOG_DEBUG, "\t%d\t %d\t %s", i, 
				atomic_read(&reader_ctx[i]->handle.refcnt), 
				reader_ctx[i]->handle.reader.file_name);
			count++;
		}
	}
	pcsc_log(PCSC_LOG_DEBUG, "\tTotoal: %d", count);

	return PCSC_S_SUCCESS;
}

static int pcsc_tool_poweron(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int reader_idx;

	reader_idx = atoi(argv[0]);
	return pcsc_icc_poweron(reader_idx);
}

static int pcsc_tool_poweroff(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int reader_idx;

	reader_idx = atoi(argv[0]);
	return pcsc_icc_poweroff(reader_idx);
}

static int pcsc_tool_icc_insert(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int reader_idx;

	reader_idx = atoi(argv[0]);
	return pcsc_icc_insert(reader_idx);
}

static int pcsc_tool_icc_remove(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int reader_idx;

	reader_idx = atoi(argv[0]);
	return pcsc_icc_remove(reader_idx);
}
