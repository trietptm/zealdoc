#ifndef __PCSC_H__
#define __PCSC_H__
#include <sysdep.h>
#include <pcsc_pinpad.h>

/* ifd exchange (ESCAPE command) */
#define IOCTL_SMARTCARD_VENDOR_IFD_EXCHANGE	SCARD_CTL_CODE(1)

typedef int pcsc_driver_handle_desc_t; /* actually is the reader_idx in the driver*/

#define PCSC_MAX_READERS	16
#define PCSC_MAX_DEVID_PARTS	5
#define PCSC_MAX_ATR		33

typedef void (*pcsc_reader_ctx_callback)(struct pcsc_reader_context *rd_ctx);

struct pcsc_devid {
	int type;
	unsigned int num;
	unsigned int val[PCSC_MAX_DEVID_PARTS];

	list_t link;
};

struct pcsc_ifd_driver_ops {
	const char *name;
	int (*open)(int pcsc_dev_type, const char *file_name, 
		    pcsc_driver_handle_desc_t *hd);
	int (*close)(pcsc_driver_handle_desc_t hd);
	int (*get_feature)(pcsc_driver_handle_desc_t hd, 
			   struct pcsc_reader *reader);
	int (*cancel)(pcsc_driver_handle_desc_t hd);

	int (*icc_status)(struct pcsc_reader_context *rd_ctx);
	int (*power_on)(struct pcsc_reader_context *rd_ctx);
	int (*power_off)(struct pcsc_reader_context *rd_ctx);
	int (*xfr_block)(pcsc_driver_handle_desc_t hd,
			 struct pcsc_transmit_param *pcsc_param);
	int (*ifd_ctl)(pcsc_driver_handle_desc_t hd, 
			struct pcsc_transmit_param *pcsc_param);
};

struct pcsc_ifd_driver {
	char *name;
	struct pcsc_ifd_driver_ops *ops;
	
	list_t dev_id_list;
	list_t link;
};

enum pcsc_reader_type {
	PCSC_READER_TYPE_USB = 1,
};

enum pcsc_reader_status {
	PCSC_READER_STATUS_FAILED	= 0x0000,
	PCSC_READER_STATUS_ABSENT	= 0x0001,
	PCSC_READER_STATUS_PRESENT	= 0x0010,
};

enum pcsc_card_status {
	PCSC_CARD_STATUS_UNKNOWN	= 0xFFFF,	/*Unknown state */
	PCSC_CARD_PRESENT_MASK		= 0x00F0,
	PCSC_CARD_POWER_MASK		= 0x000F,

	PCSC_CARD_PRESENT_POWERUP	= 0x0011,
	PCSC_CARD_PRESENT_POWERDOWN	= 0x0010,
	PCSC_CARD_ABSENT		= 0x0000,

	PCSC_CARD_STATUS_NEGOTIABLE	= 0x0200,	/*Ready for PTS*/
	PCSC_CARD_STATUS_SPECIFIC	= 0x0400,	/*PTS has been set*/
};

enum pcsc_protocol {
	PCSC_PROTOCOL_UNKNOWN	= 0x00000000,
	PCSC_PROTOCOL_T0	= 0x00000001,
	PCSC_PROTOCOL_T1	= 0x00000002,
	PCSC_PROTOCOL_T15	= 0x00000008,
};

struct pcsc_slot {
	uint8_t atr[PCSC_MAX_ATR];
	size_t atr_len;
	int proto;
	int proto_supported;

	uint32_t card_status;
};

struct pcsc_reader {
	int reader_type;
	char *file_name;
	char *name;

	const struct pcsc_ifd_driver *driver;
	uint32_t reader_status;

	struct pcsc_slot *slot;
	int nslots;
	
	/* The times of the card has been inserted */
	uint32_t icc_seq;

	/* When you open the reader, you should determine(FIXME: How to ?) 
	 * wheter the reader support keypad/display. */
	uint8_t keypad;

	uint8_t display;
	uint8_t row_num;
	uint8_t col_num;

	struct pcsc_path10_data path10;
};

struct pcsc_ifd_handle {
	struct pcsc_reader reader;
	int slot_idx;
	pcsc_driver_handle_desc_t hd;
	/* If the icc_seq is not equal to reader->icc_status, 
	 * the handle has been expired(card has been removed, 
	 * and inserted later. */
	uint32_t icc_seq;
	atomic_t refcnt;
};

struct pcsc_reader_context {
	char *name;
	stm_instance_t *fsmi;

	struct pcsc_ifd_handle handle;
	pcsc_reader_ctx_callback callback;

	int ret;
};

enum pcsc_error {
	PCSC_S_SUCCESS			= 0,
	PCSC_E_NO_MEMORY		= -1,
	PCSC_E_INVALID_HANDLE		= -2,
	PCSC_E_INVALID_PARAMETER	= -3,
	PCSC_E_INSUFFICIENT_BUFFER	= -4,
	PCSC_E_CANCELLED		= -5,
	PCSC_E_TIMEOUT			= -6, /*  The user-specified timeout value has expired. */
	PCSC_E_SHARING_VIOLATION	= -7,
	PCSC_E_NOT_SUPPORTED		= -8,
	PCSC_E_NOT_READY		= -9,
	PCSC_E_INVALID_SLOT		= -10,
	
	PCSC_E_NO_SMARTCARD		= -20,
	PCSC_E_UNKNOWN_CARD		= -21,
	PCSC_E_PROTO_MISMATCH		= -22,
	PCSC_E_INVALID_ATR		= -23,
	
	PCSC_E_UNRESPONSIVE_CARD	= -30,
	PCSC_E_UNPOWERED_CARD		= -31,
	PCSC_E_RESET_CARD		= -32,
	PCSC_E_REMOVED_CARD		= -33,
	PCSC_E_INSERTED_CARD		= -34,

	PCSC_E_NO_READER		= -40,
	PCSC_E_UNKNOWN_READER		= -41,
	PCSC_E_READER_UNAVAILABLE	= -42, /*  The specified reader is not currently available for use. */
	PCSC_E_READER_BUSY		= -43, 
	
	PCSC_F_INTERNAL_ERROR		= -99,
};

typedef void (*pcsc_transmit_complete)(struct pcsc_transmit_param *pcsc_param);

struct pcsc_transmit_param {
	struct pcsc_ifd_handle *handle ;

	uint32_t ioctl;

	int ret;
	uint8_t *sbuf;
	size_t sbuf_len;
	uint8_t *rbuf;
	size_t rbuf_len;
	size_t rbuf_actual;
	uint32_t card_status;

	pcsc_transmit_complete callback;
	void *user_data;
};

struct pcsc_ifd_handle *pcsc_connect(int reader_idx, int slot_idx);
int pcsc_disconnect(struct pcsc_ifd_handle *handle);
int pcsc_check_handle_valid(struct pcsc_ifd_handle *handle);

int pcsc_card_status(int reader_idx, int slot_idx, 
		     uint32_t *icc_status);
int pcsc_transmit(struct pcsc_transmit_param *param);

int pcsc_ifd_control(struct pcsc_transmit_param *param);


/* TEST */
int __init pcsc_cmd_init(void);
void __exit pcsc_cmd_exit(void);

#endif /*__PCSC_H__*/
