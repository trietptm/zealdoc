#ifndef __RTC_PRIV_H_INCLUDE__
#define __RTC_PRIV_H_INCLUDE__

#include <rtc.h>
#include <service.h>
#include <module.h>
#include <udev.h>
#include <list.h>
#include <logger.h>

/* ============================================================ *
 * logging operation
 * ============================================================ */
#define RTC_LOG_CRIT		LOG_EMERG
#define RTC_LOG_FAIL		LOG_CRIT
#define RTC_LOG_ERR		LOG_ERR
#define RTC_LOG_WARN		LOG_WARNING
#define RTC_LOG_INFO		LOG_INFO
#define RTC_LOG_DEBUG		LOG_DEBUG

void rtc_log(int level, const char *format, ...);

#endif /* __RTC_PRIV_H_INCLUDE__ */
