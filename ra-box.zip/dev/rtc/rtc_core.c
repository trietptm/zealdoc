#include "rtc_priv.h"

#define RTC_SERVICE_DESC	"Real time clock devices"
#define _PATH_RTC		"/dev/rtc"

static int rtc_start(void);
static void rtc_stop(void);
static void rtc_open(void);
static void rtc_close(void);
static int rtc_udev_event(notify_t *nb,
			  unsigned long event, void *data);

int rtc_logger = 0;
log_source_t rtc_log_source = {
	"rtc",
};

service_t rtc_service = {
	RTC_SERVICE_NAME,
	RTC_SERVICE_DESC,
	SERVICE_UP_ALWAYS,
	SERVICE_FLAG_SYSTEM,
	LIST_HEAD_INIT(rtc_service.depends),
	rtc_start,
	rtc_stop,
};

handle_t rtc_handle = NULL;

static notify_t rtc_udev_notify = {
	NULL,
	rtc_udev_event,
	9,
};

void rtc_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(rtc_logger, level, format, ap);
	va_end(ap);
}

static int rtc_udev_event(notify_t *nb,
			  unsigned long event, void *data)
{
	udev_node_t *node = (udev_node_t *)data;
	if (strcmp(node->filename, _PATH_RTC) != 0)
		return 0;
	switch (event) {
	case UDEV_CREATE:
		rtc_open();
		break;
	case UDEV_DELETE:
		rtc_close();
		break;
	}
	return 0;
}

static int rtc_start(void)
{
	return 0;
}

static void rtc_stop(void)
{
}

static void rtc_open(void)
{
}

static void rtc_close(void)
{
}

modlinkage int __init rtc_init(void)
{
	rtc_logger = log_register_source(&rtc_log_source);
	if (!rtc_logger)
		return -1;
	service_register_depend(RTC_SERVICE_NAME, UDEV_SERVICE_NAME);
	rtc_handle = register_service(&rtc_service);
	udev_register_notify(&rtc_udev_notify);
	return rtc_handle ? 0 : -1;
}

modlinkage void __exit rtc_exit(void)
{
	udev_unregister_notify(&rtc_udev_notify);
	unregister_service(&rtc_service);
	log_unregister_source(rtc_logger);
}

core_initcall(rtc_init);
core_exitcall(rtc_exit);
