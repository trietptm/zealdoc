#ifndef __MTD_PRIV_H_INCLUDE__
#define __MTD_PRIV_H_INCLUDE__

#include <mtd.h>

#endif /* __MTD_PRIV_H_INCLUDE__ */
