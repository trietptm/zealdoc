#include "ccid_priv.h"
#include "ccid_usb.h"

#define CCID_SERVICE_DESC	"Chip/smart card interface devices"

int ccid_logger = 0;
log_source_t ccid_log_source = {
	"ccid"
};

void ccid_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(ccid_logger, level, format, ap);
	va_end(ap);
}

#define DEBUG_BUF_SIZE ((256+20)*3+10)

static int __init ccid_log_init(void)
{
	ccid_logger = log_register_source(&ccid_log_source);
	return !ccid_logger;
}

static void __exit ccid_log_exit(void)
{
	log_unregister_source(ccid_logger);
}

int ccid_parse_ccid_descriptor(const uint8_t *src, size_t len,
			       struct ccid_descriptor *ccid_desc)
{
	/* SEPC 5.1 */
	if (len != USB_CCID_DESCRIPTOR_LENGTH)
		return -1;

	ccid_desc->bLength = src[0];
	ccid_desc->bDescriptorType = src[1];
	ccid_desc->bcdCCID = (src[3] << 8) & src[2];
	ccid_desc->bMaxSlotIndex = src[4];
	ccid_desc->bVoltageSupport = src[5];
	ccid_desc->dwProtocols = 
		src[9] << 24 | src[8] << 16 | src[7] << 8 | src[6];
	ccid_desc->dwDefaultClock = 
		src[13] << 24 | src[12] << 16 | src[11] << 8 | src[10];
	ccid_desc->dwMaximumClock = 
		src[17] << 24 | src[16] << 16 | src[15] << 8 | src[14];
	ccid_desc->bNumClockSupported = src[18];
	ccid_desc->dwDataRate = 
		src[22] << 24 | src[21] << 16 | src[20] << 8 | src[19];
	ccid_desc->dwMaxDataRate = 
		src[26] << 24 | src[25] << 16 | src[24] << 8 | src[23];
	ccid_desc->bNumDataRatesSupported = src[27];
	ccid_desc->dwMaxIFSD = 
		src[31] << 24 | src[30] << 16 | src[29] << 8 | src[28];
	ccid_desc->dwSynchProtocols = 
		src[35] << 24 | src[34] << 16 | src[33] << 8 | src[32];
	ccid_desc->dwMechanical = 
		src[39] << 24 | src[38] << 16 | src[37] << 8 | src[36];
	ccid_desc->dwFeatures = 
		src[43] << 24 | src[42] << 16 | src[41] << 8 | src[40];
	ccid_desc->dwMaxCCIDMessageLength = 
		src[47] << 24 | src[46] << 16 | src[45] << 8 | src[44];
	ccid_desc->bClassGetResponse = src[48];
	ccid_desc->bClassEnvelope = src[49];
	ccid_desc->wLcdLayout = src[51] << 8 | src[50];
	ccid_desc->bPINSupport = src[52];
	ccid_desc->bMaxCCIDBusySlots = src[53];

	return 0;
}

ui_argument_t ccid_filename_args = {
	"filename",
	"reader name",
	NULL,
	UI_TYPE_STRING,

};

ui_argument_t ccid_reader_idx_args = {
	"reader_index",
	"reader index",
	NULL,
	UI_TYPE_STRING,

};

ui_schema_t ccid_schema[] = {
	{ UI_TYPE_CLASS, 
	  UI_FLAG_SINGLE | UI_FLAG_EXTERNAL,
	  UI_TYPE_STRING, 
	  NULL, 
	  NULL,
	  ".ccid", 
	  "ccid", 
	  CCID_SERVICE_DESC },
	
	{ UI_TYPE_NONE },
};

modlinkage int __init ccid_init(void)
{
	ccid_log_init();
	ccid_register_usb_driver();

	return 0;
}

modlinkage void __exit ccid_exit(void)
{
	ccid_unregister_usb_driver();
	ccid_log_exit();
}

subsys_initcall(ccid_init);
subsys_exitcall(ccid_exit);
