#include "ccid_priv.h"
#include "ccid_usb.h"

uint8_t atr[33];
size_t atr_len = 33;
uint8_t card_status = CCID_CARD_ABSENT;

int ccid_tool_list(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int i, count = 0;
	struct ccid_handle *handle;

	ccid_log(CCID_LOG_DEBUG, "\tIndex\t Type\t Refcnt\t FileName");
	for (i = 0; i < CCID_MAX_READERS; i++) {
		handle = ccid_handle_by_idx(i);
		if (handle) {
			switch(handle->dev_type) {
			case CCID_DEVICE_TYPE_USB:
				ccid_log(CCID_LOG_DEBUG, "\t%d\t USB\t %d\t %s", i, 
					atomic_read(&handle->refcnt),
					handle->handle.usb_handle->dev->filename);
				break;
			default:
				ccid_log(CCID_LOG_DEBUG, "\t%d\t Unknown", i);
				break;
			}
			count++;
		}
	}

	ccid_log(CCID_LOG_DEBUG, "\tTotal %d", count);
	return 0;
}

int ccid_tool_open(ui_session_t *sess, ui_entry_t *inst,
		   void *ctx, int argc, char **argv)
{
	const char *file_name;
	int reader_idx;
	int r;
	
	file_name = argv[0];

	r = ccid_open(CCID_DEVICE_TYPE_USB, file_name, &reader_idx);
	if (r != CCID_SUCCESS) {
		ccid_log(CCID_LOG_ERR, "open %s failed", file_name);
		return 0;
	} else {
		ccid_log(CCID_LOG_DEBUG, "open %s success, index :%d", 
			 file_name, reader_idx);
		return 0;	
	}
}

int ccid_tool_close(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int reader_idx = atoi(argv[0]);

	ccid_close(reader_idx);

	return 0;
}

static void __ccid_tool_icc_status_cb(void *user_data, int ret)
{
	if (ret == CCID_SUCCESS) {
		if (card_status == CCID_CARD_PRESENT_ACTIVE)
			ccid_log(CCID_LOG_DEBUG, "card present and active");	
		else if (card_status == CCID_CARD_PRESENT_DEACTIVE)
			ccid_log(CCID_LOG_DEBUG, "card present but deactive");	
		else 
			ccid_log(CCID_LOG_DEBUG, "card absent");	
	} else {
		ccid_log(CCID_LOG_ERR, "ccid transfer error: %d", ret);
	}
}

int ccid_tool_icc_status(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
#if 0
	int reader_idx = atoi(argv[0]);
	int r;

	r = ccid_get_slot_status(reader_idx, &card_status, __ccid_tool_icc_status_cb, NULL);
	if (r != CCID_SUCCESS) {
		ccid_log(CCID_LOG_ERR, "ccid_tool_icc_status submit failed: %d", r);
	}
	return CCID_SUCCESS;
#endif
	return -1;
}

static void __ccid_tool_poweron_cb(void *user_data, int ret)
{
	int i;
	uint8_t atr_str[33 * 3];


	if (ret < 0) {
		ccid_log(CCID_LOG_ERR, "ERR icc_poweon_complete : %d", ret);
		return;
	}

	if ( ret > 33)  {
		ccid_log(CCID_LOG_ERR, "invalid ATR length: %d", ret);
		return;
	}
	
	for (i = 0; i < ret; i++) {
		sprintf(atr_str + i * 3, "%02X:", atr[i]);
	}
	ccid_log(CCID_LOG_ERR, "ATR: %s", atr_str);
}

int ccid_tool_poweron(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int reader_idx = atoi(argv[0]);
	int r;

	r = ccid_power_on(reader_idx, atr, atr_len, __ccid_tool_poweron_cb, NULL);
	if (r != CCID_SUCCESS) {
		ccid_log(CCID_LOG_ERR, "ccid_tool_poweron submit failed: %d", r);
	}
	return CCID_SUCCESS;
}

static void __ccid_tool_poweroff_cb(void *user_data, int ret)
{
	if (ret == CCID_SUCCESS) {
		if (card_status == CCID_CARD_PRESENT_ACTIVE)
			ccid_log(CCID_LOG_DEBUG, "card present and active");	
		else if (card_status == CCID_CARD_PRESENT_DEACTIVE)
			ccid_log(CCID_LOG_DEBUG, "card present but deactive");	
		else 
			ccid_log(CCID_LOG_DEBUG, "card absent");	
	} else {
		ccid_log(CCID_LOG_ERR, "ccid transfer error: %d", ret);
	}
}

int ccid_tool_poweroff(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	int reader_idx = atoi(argv[0]);
	int r;

	r = ccid_power_off(reader_idx, &card_status, __ccid_tool_poweroff_cb, NULL);
	if (r != CCID_SUCCESS) {
		ccid_log(CCID_LOG_ERR, "ccid_tool_poweroff submit failed: %d", r);
	}
	return CCID_SUCCESS;
}

static uint8_t *tpdu;
static size_t tpdu_len;

static uint8_t select_rbuf[1024];

static void __ccid_tool_select_cb(void *user_data, int ret)
{
	int i;
	char buffer[1024 * 3];

	if (ret >= 0) {
		for (i = 0; i < ret; i++) {
			sprintf(buffer + 3 * i, "%02X ", select_rbuf[i]);
		}
		ccid_log(CCID_LOG_DEBUG, "select file success: %s", buffer);
	} else {
		ccid_log(CCID_LOG_ERR, "select file failed: %d", ret);
	}
	free(tpdu);
}

int ccid_tool_select(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{
	struct ccid_trans_param *ccid_param;
	int reader_idx;
	int r;
	
	reader_idx = atoi(argv[0]);

	ccid_param = malloc(sizeof(struct ccid_trans_param));
	if (!ccid_param) return CCID_ERROR_NO_MEM;

	/*Select 3f00*/
	tpdu = malloc(7 * sizeof(uint8_t));
	if (!tpdu) {
		free(ccid_param);
		return CCID_ERROR_NO_MEM;
	}
	tpdu[0] = 0x00; /* TPDU */
	tpdu[1] = 0xA4;
	tpdu[2] = 0x00;
	tpdu[3] = 0x00;
	tpdu[4] = 0x02;
	tpdu[5] = 0x3F;
	tpdu[6] = 0x00;
	
	tpdu_len = 7;

	ccid_param->reader_idx = reader_idx;
	ccid_param->sbuf = tpdu;
	ccid_param->sbuf_len = tpdu_len;
	ccid_param->rbuf = select_rbuf;
	ccid_param->rbuf_len = sizeof(select_rbuf);

	r = ccid_xfrblock(reader_idx, CCID_PROTOCOL_T0, tpdu, tpdu_len, 
			  select_rbuf, sizeof (select_rbuf),
			  __ccid_tool_select_cb, NULL);
	if (r != CCID_SUCCESS) {
		free(tpdu);
		free(ccid_param);
		return r;
	}
	return r;
}

static uint8_t active_config;

static void __ccid_tool_get_config_cb(void *user_data, int ret)
{
	if (ret == CCID_SUCCESS) {
		ccid_log(CCID_LOG_DEBUG, "active config: %d", active_config);
	} else {
		ccid_log(CCID_LOG_DEBUG, "get_config_complete failed");
	}
}

int ccid_tool_get_config(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv)
{	
	int r;
	int reader_idx;

	reader_idx = atoi(argv[0]);
	
	active_config = 0;
	r = ccid_control(reader_idx, USB_REQUEST_TYPE_STANDARD, 
			 USB_REQUEST_GET_CONFIGURATION, 
			 &active_config, 1,
			 __ccid_tool_get_config_cb, NULL);
	ccid_log(CCID_LOG_DEBUG, "ccid_control: %d", r);
	return r;
}