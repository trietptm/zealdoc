#include "usb_priv.h"

int usb_logger = 0;

log_source_t usb_log_source = {
	"usb"
};

void usb_log(int level, const char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	loggingv(usb_logger, level, format, ap);
	va_end(ap);
}

static int __init usb_log_init(void)
{
	usb_logger = log_register_source(&usb_log_source);

	return !usb_logger;
}

static void __exit usb_log_exit(void)
{
	log_unregister_source(usb_logger);
}


ui_argument_t usb_filename_args = {
	"filename",
	"reader name",
	NULL,
	UI_TYPE_STRING,
};

ui_argument_t usb_reader_args = {
	"reader",
	"reader index",
	NULL,
	UI_TYPE_STRING,
};
#if 0
ui_command_t usb_list_command = {
	"list",
	"list all usb",
	".usb",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(usb_list_command.link),
	usb_tool_list,
};

ui_command_t usb_list_opened_command = {
	"list_handle",
	"list opened usb",
	".usb",
	UI_CMD_SINGLE_INST,
	NULL,
	0,
	LIST_HEAD_INIT(usb_list_opened_command.link),
	usb_tool_list_handle,
};

ui_command_t usb_list_trans_command = {
	"list_trans",
	"list transfer",
	".usb",
	UI_CMD_SINGLE_INST,
	&usb_reader_args,
	1,
	LIST_HEAD_INIT(usb_list_opened_command.link),
	usb_tool_list_trans,
};



ui_command_t usb_close_command = {
	"close",
	"close smartcard reader",
	".usb",
	UI_CMD_SINGLE_INST,
	&usb_reader_args,
	1,
	LIST_HEAD_INIT(usb_close_command.link),
	usb_tool_close,
};
#endif
ui_argument_t usb_claim_intfc_args[] = {
	{ "reader",
	  "reader index",
	  NULL,
	  UI_TYPE_STRING,},
	{ "config",
	  "config index",
	  NULL, 
	  UI_TYPE_STRING,},
	{ "intfc",
	  "interface index",
	  NULL, 
	  UI_TYPE_STRING,},
};
#if 0
ui_command_t usb_claim_intfc_command = {
	"claim",
	"claim interface",
	".usb",
	UI_CMD_SINGLE_INST,
	usb_claim_intfc_args,
	3,
	LIST_HEAD_INIT(usb_claim_intfc_command.link),
	usb_tool_claim,
};

ui_command_t usb_get_config_command = {
	"get_config",
	"get config",
	".usb",
	UI_CMD_SINGLE_INST,
	&usb_reader_args,
	1,
	LIST_HEAD_INIT(usb_get_config_command.link),
	usb_tool_get_config,
};
#endif
ui_argument_t usb_trans_args[] = {
	{"reader",
	"USB smartcard reader",
	NULL,
	UI_TYPE_STRING,},
	{"transfer",
	"transfer index",
	NULL,
	UI_TYPE_STRING,},
};

#if 0
ui_command_t usb_cancel_trans_command = {
	"cancel",
	"cancel transfer",
	".usb",
	UI_CMD_SINGLE_INST,
	usb_trans_args,
	2,
	LIST_HEAD_INIT(usb_cancel_trans_command.link),
	usb_tool_cancel_trans,
};

ui_command_t usb_select_command = {
	"select",
	"select 3f00",
	".usb",
	UI_CMD_SINGLE_INST,
	&usb_reader_args,
	1,
	LIST_HEAD_INIT(usb_select_command.link),
	usb_tool_select_trans,
};
#endif	/* cmd */

static int __init usb_cmd_init(void)
{
#if 0
	ui_register_command(&usb_list_command);
	ui_register_command(&usb_open_command);
	ui_register_command(&usb_close_command);
	ui_register_command(&usb_claim_intfc_command);
	ui_register_command(&usb_list_opened_command);
	ui_register_command(&usb_get_config_command);
	ui_register_command(&usb_list_trans_command);
	ui_register_command(&usb_cancel_trans_command);
	ui_register_command(&usb_select_command);
#endif
	return 0;
}

static void __exit usb_cmd_exit(void)
{
#if 0
	ui_unregister_command(&usb_select_command);
	ui_unregister_command(&usb_cancel_trans_command);
	ui_unregister_command(&usb_list_trans_command);
	ui_unregister_command(&usb_get_config_command);
	ui_unregister_command(&usb_list_opened_command);
	ui_unregister_command(&usb_claim_intfc_command);
	ui_unregister_command(&usb_close_command);
	ui_unregister_command(&usb_open_command);
	ui_unregister_command(&usb_list_command);
#endif
}

static int __init usb_sys_ops_init(void)
{
	return sys_ops->init();
}

static void __exit usb_sys_ops_exit(void)
{
	/* none */
}

modlinkage int usb_init(void)
{
	usb_log_init();
	usb_sys_ops_init();
	usb_cmd_init();
	usb_dev_init();
	return 0;
}

modlinkage void usb_exit(void)
{
	usb_dev_exit();
	usb_cmd_exit();
	usb_sys_ops_exit();
	usb_log_exit();
}
subsys_initcall(usb_init);
subsys_exitcall(usb_exit);
