#ifndef __USB_PRIV_H__
#define __USB_PRIV_H__

#include <syslog.h>
#include <logger.h>
#include <module.h>
#include <uiserv.h>
#include <dirent.h>
#include <panic.h>
#include <eloop.h>
#include <usb.h>
#include <strutl.h>
#include <linux/usbdevice_fs.h>	/* ioctl */

#define USB_LOG_CRIT	LOG_EMERG
#define USB_LOG_FAIL	LOG_CRIT
#define USB_LOG_ERR	LOG_ERR
#define USB_LOG_WARN	LOG_WARNING
#define USB_LOG_INFO	LOG_INFO
#define USB_LOG_DEBUG	LOG_DEBUG

void usb_log(int level, const char *format, ...);

struct sys_device_ops {
	int (*init)(void);
	int (*sys_device_init)(usb_device_t *dev);
	void (*sys_device_release)(usb_device_t *dev);
	int (*sys_open)(usb_intfc_t *intfc);
	void (*sys_close)(usb_intfc_t *intfc);
	int (*sys_get_config)(usb_intfc_t *intfc, unsigned int *config_idx);
	int (*sys_set_config)(usb_intfc_t *intfc, unsigned int config_idx);
	int (*sys_claim_intfc)(usb_intfc_t *intfc);
	int (*sys_release_intfc)(usb_intfc_t *intfc);
	int (*sys_submit_transfer)(struct usb_transfer *transfer);
	int (*sys_asyn_reap)(usb_intfc_t *dev, struct usb_transfer **otranfer);
	int (*sys_cancel_transfer)(struct usb_transfer *transfer);

	int (*sys_ioctl)(usb_intfc_t *dev, int intfc_no, 
			 int ioctl_code, void *data);
	size_t device_priv_size;
	size_t transfer_priv_size;
};

struct usb_descriptor_header {
	uint8_t bLength;
	uint8_t bDescriptorType;
};

/* usb_transfer.flags values */
enum usb_transfer_flags {
	USB_TRANSFER_SHORT_NOT_OK	= (1<<0),
	USB_TRANSFER_FREE_BUFFER	= (1<<1),
	USB_TRANSFER_FREE_TRANSFER	= (1<<2),
};

/* Transfer status codes */
enum usb_transfer_status {
	USB_TRANSFER_COMPLETED = 0,
	USB_TRANSFER_REAPING = 1, 
	USB_TRANSFER_TIME_OUT,
	USB_TRANSFER_CANCELLED,
	USB_TRANSFER_STALL,
	USB_TRANSFER_NO_DEVICE,
	USB_TRANSFER_OVERFLOW,
	USB_TRANSFER_REAP_ERROR,
	USB_TRANSFER_ERROR,
};

struct usb_transfer {
	char *name;
	stm_instance_t *fsmi;
	list_t link;

	usb_intfc_t *dev_handle;
	
	uint8_t flag;
	uint8_t type;
	uint8_t endpoint;
#define USB_TRANSFER_TIMEOUT	1000 /* 1 ms */
	struct timeval timeout;
	uint32_t status;

	uint8_t *buffer;
	size_t length;
	size_t actual_length;
	
	usb_bulk_trans_callback callback;
	void *user_data;

	void *os_priv;

	int num_iso_packets;
	struct usb_iso_packet_descriptor iso_packet_desc[0];	
};

void __exit usb_dev_exit(void);
int __init usb_dev_init(void);

int usbi_parse_descriptor(unsigned char *source, const char *descriptor, 
			  void *dest, int host_endian);
int usbi_parse_configuration(struct usb_config_descriptor *config,
			     unsigned char *buffer, int host_endian);
void usbi_clear_configuration(struct usb_config_descriptor *config);

struct usb_transfer *usb_alloc_transfer(int iso_packets);
void usb_free_transfer(struct usb_transfer *transfer);

int usbi_submit_transfer(struct usb_transfer *transfer);
int usbi_cancel_transfer(struct usb_transfer *transfer);

void usbi_eloop_handle_cb(int fd, void *eloop_data, void *user_ctx);


int usb_tool_list(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int usb_tool_list_handle(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int usb_tool_list_trans(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int usb_tool_close(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int usb_tool_claim(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int usb_tool_get_config(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int usb_tool_cancel_trans(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);
int usb_tool_select_trans(ui_session_t *sess, ui_entry_t *inst,
			  void *ctx, int argc, char **argv);


int usb_sync_bulk_write(usb_intfc_t *dev, int ep, 
			char *bytes, int size, int timeout);
int usb_sync_bulk_read(usb_intfc_t *dev, int ep, 
		       char *bytes, int size, int timeout);

extern struct sys_device_ops *sys_ops;

#endif /*__USB_PRIV_H__*/
