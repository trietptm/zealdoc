#ifndef _CSP_UTILS_H

#define UNICODE
#define _CSP_UTILS_H

#ifdef __cplusplus
extern "C" {
#endif

#define DEBUG_FILE      "C:\\csp_sol.log" /**< Path to the debug log file.*/

#define DEBUG_LEVEL      0  /**< Debug level 0 to 5 */

/** \brief Close the debug log file.
 *
 * \return TRUE if the log file was closed. FALSE if not, (not opened of worse).
 */
BOOL closeDebug();

/** \brief Write debug to file
 *
 *  Lock the debug file, open it, write in it, close it, unlock it.
 *  
 *  \param  message C string containgin the message to write.
 *
 *  \return TRUE if ok.
 */
BOOL fdebug(const char *message);

/** \brief Debug macro
 *
 *
 */
#define DEBUG(LEVEL, MESSAGE)	\
    if(LEVEL <= DEBUG_LEVEL)	\
    {				\
        fdebug(MESSAGE);	\
    }

#ifdef __cplusplus
}
#endif

#endif /* _CSP_UTILS_H */

