#include <stdlib.h>
#include <stdio.h>
#include <windows.h>
#include "csp_utils.h"

static HANDLE debugFileHandle = INVALID_HANDLE_VALUE;

BOOL closeDebug()
{
	if(debugFileHandle == INVALID_HANDLE_VALUE)
	{
		return CloseHandle(debugFileHandle);
	}
	return FALSE;
}

BOOL fdebug(const char *message)
{
	DWORD   bytesWritten;
	DWORD   dwPos; /* Position in the file.*/
	
	/** - If the log file handle is invalid,*/
	if(debugFileHandle == INVALID_HANDLE_VALUE)
	{
		/** - Try to get a valid file handle.*/
		debugFileHandle = CreateFile(TEXT(DEBUG_FILE),     /* The debug file.*/
			GENERIC_WRITE,  /* Open for writing.*/
					FILE_SHARE_READ,/* Allow multiple
					readers.*/
					NULL,           /* No security.*/
					OPEN_ALWAYS,    /* If not exists, create.*/
					FILE_ATTRIBUTE_NORMAL, /* normal file.*/
					NULL);         /* No attribute template.*/
	}
	/** - If the log file handle is still invalid, error*/
	if(debugFileHandle == INVALID_HANDLE_VALUE)
	{
		return FALSE;
	}
	/** - Go to the end of the file.*/
	dwPos = SetFilePointer(debugFileHandle, 0, NULL, FILE_END);
	/** - Lock at the end of file, on length of message +1.*/
	if(!LockFile(debugFileHandle,dwPos,0, strlen(message),0))
	{
		return FALSE;
	}
	/** - Write the message to the file.*/
	if(!WriteFile(debugFileHandle, message, strlen(message), &bytesWritten, NULL))
	{
		UnlockFile(debugFileHandle, dwPos, 0, strlen(message),0);
		return FALSE;
	}
	/** - Unlock the file.*/
	return UnlockFile(debugFileHandle, dwPos, 0, strlen(message),0);
}

