#ifndef _TIME_H_
#define _TIME_H_

#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <getopt.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <time.h>
#include <dirent.h>
#include <sys/time.h>
#include <sys/types.h>		/* For pid_t. */
#include <sys/wait.h>
#include <sys/param.h>		/* For getpagesize, maybe.  */

/* time.c */
#define TV_MSEC tv_usec / 1000
#include <sys/resource.h>

/* Information on the resources used by a child process.  */
typedef struct {
	int waitstatus;
	struct rusage ru;
	struct timeval start, elapsed; /* Wallclock time of process.  */
} resource_t;

typedef int (*cmd_cb)(int p1, int p2);
int time_main (cmd_cb cmd, int p1, int p2);
/* --time.c-- */

#endif	/* _TIME_H_ */
