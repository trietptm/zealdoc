#include "main.h"
/*
 * Error code definitions
 */
#define ERR_SUC  0 /* no error */
#define ERR_CMD  1 /* command lines error */
#define ERR_PIP  2 /* pipe created error */
#define ERR_FRK  3 /* fork error */
#define ERR_WRI  4 /* write error */
#define ERR_RED  5 /* read error */
#define ERR_FOP  6 /* fopen error */
#define ERR_DIR  7 /* dir error */
#define ERR_TIO  8 /* timeout error */
#define ERR_SYN  9 /* sync error */
#define ERR_SIG  10 /* kill error */
#define ERR_CLK  11 /* clock error */

#define DEF_DURATION		3
#define DEF_TIME		10000
#define DEF_CACHE_SIZE		2000	/* kb */
#define LOOP_TYPE_DURATION	0x1
#define LOOP_TYPE_TIMES		0x2

unsigned long iter = 0;
clock_t cost = 0;
int g_duration = 0;
int g_time = 0;
int g_read_cpu = 0;
int g_size = 0;
long g_read_cpu_times = 0;

struct option LongOptions[] = {
    {"duration", 1, NULL, 'd'},
    {"help",     0, NULL, 'h'},
    {"time",     1, NULL, 't'},
    {0,          0, NULL, 0}
};

int usage () {
	fprintf (stdout, "name\n");
	fprintf (stdout, "context2 -- multi processes switching based on pipe\n");
	fprintf (stdout, "    usage\n");
	fprintf (stdout, "context2 [OPTION]\n");
	fprintf (stdout, "    options\n");
	fprintf (stdout, "    -d, --duration=DURATION   record duration\n");
	fprintf (stdout, "    -h, --help                usage\n");
	exit (ERR_SUC);
}

void report (int sig)
{
	g_read_cpu = 0;
}

/********************************************************
 * Timing routine
 *******************************************************/
int wake_me (int seconds, void (*func)(int signum))
{
	/* record the start time */
	//cost = time(NULL);
	/* set up the signal */
	signal (SIGALRM, func);
	/* set up the timeout clock */
	alarm (seconds);
}

static int vtss_cpu_read_test(void)
{
	long value;
	int i = 0;
	for (; i < g_time; i++)
		ht_cpurx_readbuffer(1, 0, &value);
	return 0;
}

int do_read_cpu_queue_loop(int type)
{
	long value;
	/* set up the timer */
	printf("prepare read from cpu extraction queue[1]:\n");

	if (type == LOOP_TYPE_DURATION) {
		g_read_cpu = 1;
		wake_me (g_duration, report);
		printf("duration=%d seconds and get times\n", g_duration);
		while (g_read_cpu) {
			ht_cpurx_readbuffer(1, 0, &value);	/* read ifh place */
			g_read_cpu_times++;
		}
		printf("times=%ld\n", g_read_cpu_times);

	} else if (type == LOOP_TYPE_TIMES) {
		printf("will read times=%ld\n", g_time);
		time_main(vtss_cpu_read_test);
	}
}

/* 32bit */
#define CACHE_SHIFT		5
#define CACHE_BYTES		(1 << CACHE_SHIFT)
#define BEACH_ALIGN(ptr)	(((unsigned long)(ptr) + CACHE_BYTES - 1)&~(CACHE_BYTES - 1))

static unsigned char *align_ptr = NULL;
static int g_cache_size;

static int do_l1_cache_cmd_write(void)
{
	long i = 0;
	for (i = 0; i < (g_cache_size - 32); i++) {
		align_ptr[i] = rand() % 0xff;
	}
}

static int do_l1_cache_cmd_read(void)
{
	long i = 0;
	unsigned char ch;
	for (i = 0; i < (g_cache_size - 32); i++) {
		ch = align_ptr[i];
	}
}

int do_l1_cache(long kb, int type)
{
	int i, read = type;
	unsigned char *cache;

	g_cache_size = (kb * 1024 * (sizeof (unsigned char)) + CACHE_BYTES);

	printf("buffer_size=%d(kb)\n", g_cache_size / 1024);

	cache = malloc(g_cache_size);

	align_ptr = BEACH_ALIGN(cache);
	
	if (!cache) {
		printf("out of memory.\n");
		return -1;
	}

	srand(time(NULL));
	if (read) {
		time_main(do_l1_cache_cmd_read);
	} else {
		time_main(do_l1_cache_cmd_write);
		time_main(do_l1_cache_cmd_write);
	}
	align_ptr = NULL;
	free(cache);
}

int do_init(void)
{
	if (!vtss_vit_init())
		return 0;
	return -1;
}

void do_exit(void)
{
	vtss_vit_exit();
}

int main(int argc, char *argv[])
{
	int i = 0;
	pid_t pid;
	int op_type = 0;

	while (1) {
		int option_index = 0;
		int c;

		c = getopt_long(argc, argv, "d:t:h",
				LongOptions, &option_index);

		if (c == EOF)
			break;

		switch(c) {
			case 'd':
				g_duration = atoi (optarg);
				break;
			case 't':
				g_time = atoi (optarg);
				break;
			case 's':
				g_size = atoi(optarg);
			case '?':
				fprintf (stdout, "invalid usgae\n");
			case 'h':
				usage ();
				break;
			default:
				fprintf (stdout, "Unknown usage %c.\n", c);
				exit (ERR_CMD);
		}
	}

	if (do_init()) {
		printf("do_init failure\n");
		return -1;
	}

	if (g_duration == 0)
		g_duration = DEF_DURATION;
	if (g_time == 0)
		g_time = DEF_TIME;
	
	//do_read_cpu_queue_loop(LOOP_TYPE_TIMES);
	if (g_size < DEF_CACHE_SIZE)
		do_l1_cache(g_size, op_type);
	else
		do_memroy(g_size, op_type);

	printf("loop end and exit now\n");

	do_exit();

	return 0;
}
