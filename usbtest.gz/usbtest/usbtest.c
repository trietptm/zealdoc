#include "priv.h"
#include "cunit.h"

/* smartcard reader handle */
USB_DEVICE_HANDLE *main_handle = NULL; 
#define MAGIC_SEQ(seq)	((((seq) + 6) * 2 / 3) % 0xff)

/* on a slot, how many command can receive, its kernel side function */
int max_send(void)
{
	do_PowerOn();
	do_PowerOn();
	do_PowerOn();

	return 1;
}

int __abort1(void)
{
	//do_PowerOn();
	do_Abort(CCID_ABORT_T_CTRL, 0x23);
//	sleep(5);
	//do_PowerOn();
	do_Reap();
	do_GetSlotStatus();
	do_Reap();
	do_Reap();
	do_Abort(CCID_ABORT_T_BULK, 0x23);
	do_Reap();
	do_Reap();

	return 1;
}

int __control_get_config(void)
{
	return ctrl_config_desc();
}

/* ccid abortable command:
 * IccPowerOn
 * XfrBlock
 * Escape
 * Secure
 * Mechanical
 * Abort
 * */
int __abort2(void)
{
	int seq = MAGIC_SEQ(4);

	/* 1. send a abort-able command */
//	do_PowerOn();
	do_XfrBlock();
	do_Reap();
	do_XfrBlock();
	do_Reap();
	do_XfrBlock();
	do_Reap();

	/* 2. abort last bulk-out command with a pair abort messages:
	 * a control-pipe abort request
	 * a bulk-out abort command 
	 * both of them use the same slot and seq. */
	do_Abort(CCID_ABORT_T_CTRL, seq);
	sleep(3);
	do_XfrBlock();
	do_XfrBlock();
	do_Reap();
	do_Reap();
	do_Abort(CCID_ABORT_T_BULK, seq);
	do_XfrBlock();
	do_Reap();
	do_XfrBlock();
	do_Reap();
	do_XfrBlock();

	/* 3. if succeed we will get a slotstatus response from bulk-in(which
	 * means abort operation is success)
	 * and before we get that abort response any other response will be
	 * dropped by ourself.
	 * CCID SPEC 5.3.1 the last paragraph */

	do_Reap();

	return 1;
}

int __setparam1()
{

	int ag;
	uint8_t param1[5], param2[5], param3[5];
#if 0
	/* maybe the reader may keep the lastest param for card. 
	 * after poweron, the param will reset to default value. */
	do_PowerOn_parse();
#endif

	do_GetParameters();
	while (!do_Reap())
		;
	ccid_get_param(param1);
	dbg_log(LOG_DEBUG, "param: bmFindexDindex=%02X, bWaitingIntegerT0=%02X",
				param1[0], param1[3]);
	ag = 1;
again:
	do_SetParameters();
	while (!do_Reap())
		;
	ccid_get_param(param2);
	dbg_log(LOG_DEBUG, "param: bmFindexDindex=%02X, bWaitingIntegerT0=%02X",
				param2[0], param2[3]);

	do_GetParameters();
	while (!do_Reap())
		;
	/* what's the default value? the value after PowerOn? or else? */
	/* ResetParam cannot get the `right' response? */
#if 0
	do_ResetParameters();
	while (!do_Reap())
		;
	do_GetParameters();
	while (!do_Reap())
		;
	ccid_get_param(param3);
	dbg_log(LOG_DEBUG, "param: bmFindexDindex=%02X, bWaitingIntegerT0=%02X",
				param3[0], param3[3]);
#endif
	if (ag--)
		goto again;

	return 1;
}

void CUNITCBK abort_case(void)
{
	CUNIT_ASSERT_RET_TRUE(__abort1);
	//CUNIT_ASSERT_RET_TRUE(__control_get_config);
	//CUNIT_ASSERT_RET_TRUE(__abort2);
}

void CUNITCBK do_all_cmd(void)
{
	ccid_do_all();
}

void CUNITCBK param_case(void)
{
	//CUNIT_ASSERT_RET_TRUE(__setparam1);
}

CUNIT_BEGIN_SUITE(init)
	CUNIT_INCLUDE_CASE(do_all_cmd)
	//CUNIT_INCLUDE_CASE(abort_case)
	//CUNIT_INCLUDE_CASE(param_case)
CUNIT_END_SUITE

int main(void)
{
	/* cannot enum interest class device or other errors */
	if (test_start() == 0) {
		dbg_log(LOG_ERROR, "usbtest die at bring up");
		return 0;
	}

	CUNIT_RUN_SUITE(init);
	test_stop();

	return 0;
}
