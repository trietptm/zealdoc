#include "priv.h"

int EP_IN = -1;
int EP_OUT = -1;

uint8_t DEF_INTFC = 0;
int g_log_open = 1;

#ifndef WIN32
#define dump_io_err(print)							\
	do {									\
		if (print) {							\
			dbg_log(LOG_ERROR, "I/O: err=%s/%d, line=%d", strerror(errno), errno, __LINE__);	\
		}								\
	} while (0)
#else
#define dump_io_err(x)	{}
#endif

static int parse_class_desc(const uint8_t *data, int len);

void log_open(void)
{
	g_log_open = 1;
}

void log_close(void)
{
	g_log_open = 0;
}


int warm_up(void)
{
	int succ = 0, i = 10, k = 5;

	log_close();
	/* read over older data */
	while (k--)
		do_Reap();

	while (i--) {
		/* true when fail */
		/* true when succ */
		do_GetSlotStatus();
		do_GetSlotStatus();

		if (do_Reap()) {
			succ = 1;
			break;
		}
	}
	log_open();

	if (succ)
		dbg_log(LOG_DEBUG, "warm_up success");
	else
		dbg_log(LOG_DEBUG, "warm_up failure");
	k = 10;

	while (k--)
		do_Reap();
	return succ;
}

#ifdef LIBUSB_01

/* bulk */
int __bulk_send(usb_dev_handle *handle, uint8_t *data, int len, int print)
{
	int ret, ag = 0;

	ret = usb_bulk_write(handle, EP_OUT, data, len, DEF_TO);

	if (ret < 0) {
		goto err;
	}
	if (print)
		print_bin2hex(data, len, 0);
err:
	return ret;	
}

int __bulk_recv(usb_dev_handle *handle, uint8_t *buff, int len, int print)
{
	int ret;

	ret = usb_bulk_read(handle, EP_IN, buff, len, DEF_TO);
	if (ret < 0) {
		dump_io_err(print);
		goto err;
	}
	else {
		if (print)
			print_bin2hex(buff, ret, 1);
	}
err:
	return ret;
}

int __ctrl_msg(usb_dev_handle *hd, uint8_t reqType, uint8_t req,
	       uint16_t value, uint16_t index, uint8_t *buff, uint16_t le)
{
	return 0;
}

static int find_interclass(struct usb_config_descriptor *config, int cla)
{
	int j, i;
	struct usb_interface *intfc;

	for (i = 0; i < config->bNumInterfaces; i++)
		intfc = &config->interface[i];
		for (j = 0; j < intfc->num_altsetting; j++) {
			if (intfc->altsetting[j].bInterfaceClass == cla) {
				if (parse_class_desc(intfc->altsetting[j].extra,
						 intfc->altsetting[j].extralen)) return 1;
			}
	}
	return 0;
}

static int is_needed(struct usb_device *dev)
{
	int i;
	for (i = 0; i < dev->descriptor.bNumConfigurations; i++) 
		if (find_interclass(&dev->config[i], INTEREST_CLASS))
			return 1;
	return 0;
}

/* init usb bus and get set g_dev handle */
int get_interest_dev(void) 
{
	struct usb_bus *bus; 
	struct usb_device *dev; 
	usb_dev_handle *udev; 

	for (bus = usb_busses; bus; bus = bus->next) { 
		for (dev = bus->devices; dev; dev = dev->next) { 
			udev = usb_open(dev);
			if (udev) {
				if (is_needed(dev)) {

#if 0
					if (usb_set_configuration(udev, 1) < 0) {
						printf("set_config err\r\n");
						usb_close(udev);
						break;
					}

					if (usb_set_altinterface(udev, 0) < 0) {
						printf("altset err\r\n");
						usb_close(udev);
						break;
					}

#endif
					if (usb_claim_interface(udev, DEF_INTFC) < 0) {
						printf("claim err\r\n");
						usb_close(udev);
						break;
					}
					main_handle = udev;
					break;
				}
				usb_close(udev);
			}
		}
	}
	/* found */
	if (main_handle)
		return 1;
	return 0;
}

void __init(void)
{
	usb_init(); 
	usb_find_busses(); 
	usb_find_devices(); 
	usb_set_debug(255);
}

void __exit(void)
{
	if (main_handle) {
		usb_release_interface(main_handle, 0);
		usb_close(main_handle);
		main_handle = NULL;
	}
}

#elif defined(LIBUSB_10)

libusb_context *g_ctx = NULL;
libusb_device **g_devs = NULL;

#define ENABLE_DEBUG_LOGGING
void __exit(void)
{
	if (main_handle) {
		libusb_release_interface(main_handle, DEF_INTFC);
		libusb_close(main_handle);
	}
	if (g_devs)
		libusb_free_device_list(g_devs, 0);
	if (g_ctx)
		libusb_exit(g_ctx);
}

void __init(void)
{
	if (libusb_init(&g_ctx)) {
		dump_io_err(1);
		return;
	}
	if (g_ctx)
		libusb_set_debug(g_ctx, 3);
}


int config_ep_addr(const struct libusb_interface_descriptor *alt)
{
	int i, num_ep = alt->bNumEndpoints;

	for (i = 0; i < num_ep; i++) {
		struct libusb_endpoint_descriptor *ep = (struct libusb_endpoint_descriptor *)
			alt->endpoint+i;

		if (LIBUSB_TRANSFER_TYPE_BULK == ep->bmAttributes) {
			if (ep->bEndpointAddress & 0x80)
				EP_IN = ep->bEndpointAddress;
			else
				EP_OUT = ep->bEndpointAddress;
		}
	}
	dbg_log(LOG_DEBUG, "EP_IN=%02X, EP_OUT=%02x", EP_IN, EP_OUT);
	return 1;
}

int get_interest_dev(void)
{
	struct libusb_device_descriptor desc;
	int i, cnt;

	cnt = libusb_get_device_list(g_ctx, &g_devs);
	if (cnt <= 0)
		return 0;

	for (i = 0; i < cnt; i++) {
		int config, j, k;

		libusb_get_device_descriptor(g_devs[i], &desc);
		config = desc.bNumConfigurations;

		for (j = 0; j < config; j++) {
			struct libusb_config_descriptor *c_desc = NULL;

			libusb_get_config_descriptor(g_devs[i], j, &c_desc);
			if (c_desc) {
				for (k = 0; k < c_desc->bNumInterfaces; k++) {
					int num_alt;
					int a;
					struct libusb_interface *intfc = 
						(struct libusb_interface *)c_desc->interface;

					intfc += k;
					num_alt = intfc->num_altsetting;
					for (a = 0; a < num_alt; a++) {
						if (intfc->altsetting->bInterfaceClass == 
						    INTEREST_CLASS) {
							if (libusb_open(g_devs[i], &main_handle)) {
								printf("open handle fail\r\n");
								libusb_free_config_descriptor(c_desc);
								return 0;
							}
							DEF_INTFC = k;
							if (!parse_class_desc(intfc->altsetting->extra, intfc->altsetting->extra_length))
									continue;
							if (libusb_claim_interface(main_handle, DEF_INTFC)) {
								libusb_close(main_handle);
								libusb_free_config_descriptor(c_desc);
								main_handle = NULL;
								dbg_log(LOG_ERROR, "claim fail");
								return 0;
							}
							config_ep_addr(intfc->altsetting);
							libusb_free_config_descriptor(c_desc);
							return 1;
						}
					}

					
				}
				libusb_free_config_descriptor(c_desc);
				c_desc = NULL;
			}
		}
	}
	return 0;
}

int __libusb_10_bulk_trans(int type, libusb_device_handle *handle,
			   uint8_t *data, int len, int print)
{
	int ret, transferred = 0;
	int ep = type ? EP_OUT : EP_IN;


	ret = libusb_bulk_transfer(handle, ep, data, len, &transferred, DEF_TO);

	if (transferred == 0) {
		dbg_log(LOG_ERROR, "bulk-%s error=%s", ep == EP_OUT ? "out" : "in",
				strerror(errno));
		/* need not go on */
		return ret;
	}

	if (ep == EP_OUT && transferred != len) {
		dbg_log(LOG_ERROR, "bulk trans less data, transferred=%d, except send=%d\r\n",
			transferred, len);
	}
	if (ret != 0) {
		dump_io_err(print);
		return 0;
	}
	if (print)
		print_bin2hex(data, ep == EP_IN ? transferred : len, ep == EP_IN ? 1 : 0);
	
	if (ep == EP_IN) 
		ret = transferred;
	return ret;
}

int __bulk_recv(libusb_device_handle *handle, uint8_t *data, int len, int print)
{
	return __libusb_10_bulk_trans(0, handle, data, len, print);
}

int __bulk_send(libusb_device_handle *handle, uint8_t *data, int len, int print)
{
	return __libusb_10_bulk_trans(1, handle, data, len, print);
}

int __ctrl_msg(libusb_device_handle *hd, uint8_t reqType, 
	       uint8_t req, uint16_t value, uint16_t index,
	       uint8_t *buff, uint16_t le)
{
	int ret;

	ret = libusb_control_transfer(hd, reqType, req, value, index, buff, le, DEF_TO);
	
	if (ret != 0) {
		dbg_log(LOG_ERROR, "ctrl ret=%d\r\n", ret);
		dump_io_err(1);
	}
	return ret;
}

#endif

/* t = 1 is receive */
void print_bin2hex(uint8_t *tmp_bin, int len, int t)
{
	int i;
	char buff[3 * MAX_BUFFER_LEN];
	char buff2[MAX_BUFFER_LEN];

	if (0 == g_log_open)
		return;

	if (len > MAX_BUFFER_LEN) {
		dbg_log(LOG_ERROR, "default output len is too samll, len=%d", len);
		return;
	}
	memset(buff, 0x00, sizeof (buff));

	for (i = 0; i < len; ) {
		sprintf(buff + 3 * i, "%02X ", tmp_bin[i]);
		i++;
	}

	sprintf(buff2, "[%s]", ccid_msg_type(tmp_bin[0]));

	if (t == 1)
		dbg_log(LOG_DEBUG, "\t<<< %-20s %s", buff2, buff);
	else
		dbg_log(LOG_DEBUG, "\t>>> %-20s %s", buff2, buff);
}

int test_bulk_send(uint8_t *snd, int slen, int print)
{
	return __bulk_send(main_handle, snd, slen, print);
}

int test_bulk_recv(uint8_t *rcv, int rlen, int print)
{
	return __bulk_recv(main_handle, rcv, rlen, print);
}

int test_ctrl_msg(uint8_t reqType, uint8_t req, 
		  uint16_t value, uint16_t index, uint8_t *buff, uint16_t len)
{
	return __ctrl_msg(main_handle, reqType, req, value, index, buff, len);
}

int test_start(void)
{
	__init();
	if (get_interest_dev())
		return warm_up();
	return 0;
}

void test_stop(void)
{
	__exit();
}

void dbg_log(int level, const char *format, ...)
{
	va_list args;
	FILE *stream = stdout;
	const char *prefix;

	if (g_log_open == 0)
		return;

	switch (level) {
	case LOG_INFO:
		prefix = "info";
		break;
	case LOG_WARNING:
		stream = stderr;
		prefix = "warning";
		break;
	case LOG_ERROR:
		stream = stderr;
		prefix = "error";
		break;
	case LOG_DEBUG:
		stream = stderr;
		prefix = "debug";
		break;
	default:
		stream = stderr;
		prefix = "unknown";
		break;
	}

	fprintf(stream, "dbg: ");

	va_start (args, format);
	vfprintf(stream, format, args);
	va_end (args);

	fprintf(stream, "\r\n");
}

static int parse_class_desc(const uint8_t *data, int len)
{
	if (INTEREST_CLASS == 0x0b || INTEREST_CLASS == 0x0) {
		return ccid_parse_desc(data, len);
	}
	return 0;
}
