#include "priv.h"
#include "cunit.h"

static void ccid_build_PowerOn(int bSlot, int bSeq, uint8_t v);
static void ccid_build_GetSlotStatus(int bSlot, int bSeq);
static void ccid_build_PowerOff(int bSlot, int bSeq);
static void ccid_build_SetParameters(int bSlot, int bSeq, int proto, uint8_t *apdu, int len);
static void ccid_build_GetParameters(int bSlot, int bSeq);
static void ccid_build_Abort(int bSlot, int bSeq);

static void ccid_desc_output(void);
static int __print_atr(const char *atr, size_t atr_len);

#define CCID_DESCRIPTOR_LENGTH		54
#define ccid_header_length	10

int gSeq = 0;
uint8_t output[MAX_BUFFER_LEN];
uint8_t input[MAX_BUFFER_LEN];

struct ccid_descriptor {
	uint8_t bLength;
	uint8_t bDescriptorType;
	uint16_t bcdCCID;
	uint8_t bMaxSlotIndex;
	uint8_t bVoltageSupport;
	uint32_t dwProtocols;	/*cardprotocol: t0: 0000 0001 ,t1: 0000 0002*/
	uint32_t dwDefaultClock;
	uint32_t dwMaximumClock;
	uint8_t bNumClockSupported;
	uint32_t dwDataRate;
	uint32_t dwMaxDataRate;
	uint8_t bNumDataRatesSupported;
	uint32_t dwMaxIFSD;
	uint32_t dwSynchProtocols;
	uint32_t dwMechanical;
	uint32_t dwFeatures;
	uint32_t dwMaxCCIDMessageLength;
	uint8_t bClassGetResponse;
	uint8_t bClassEnvelope;
	uint16_t wLcdLayout;
	uint8_t bPINSupport;
	uint8_t bMaxCCIDBusySlots;

	/* copy from ccid-1.3.1 */
	unsigned int readTimeout;

} g_desc;

struct err_items Error_Items[] = {
/* 1 */	{IS_BITS_2, CS_BITS_1, 0x05,			"bSlot does not exist"},

/* 2 */	{IS_BITS_2, CS_BITS_1, CCID_ERR_ICC_MUTE,	"No ICC present"},

/* 3 */	{IS_BITS_1, CS_BITS_1, CCID_ERR_HW,		"Hardware error"},

/* 4 */	{IS_BITS_1, CS_BITS_1, 0x07,			"bPowerselect error(not supported)"},

/* 5 */	{IS_BITS_1, CS_BITS_1, CCID_ERR_XFR_PARITY,	"parity error on ATR"},

/* 6 */	{IS_BITS_1, CS_BITS_1, CCID_ERR_ICC_MUTE,	"ICC mute (Time out)"},

/* 7 */	{IS_BITS_1, CS_BITS_1, CCID_ERR_BAD_ATR_TS,	"Bad TS in ATR"},

/* 8 */	{IS_BITS_1, CS_BITS_1, CCID_ERR_BAD_ATR_TCK,	"Bad TCK in ATR"},

/* 9 */	{IS_BITS_1, CS_BITS_1, CCID_ERR_ICC_PROT_NOSUP, "Protocol not managed"},

/* a */	{IS_BITS_1, CS_BITS_1, CCID_ERR_ICC_CLASS_NOSUP,"ICC class not supported"},

/* b */	{IS_BITS_1, CS_BITS_1, CCID_ERR_CMD_ABORTED,	"Command aborted by control pipe"},

/* c */	{IS_BITS_0, CS_BITS_1, 0x00,			"Command Not Supported"},

/* d */	{IS_BITS_0, CS_BITS_1, CCID_ERR_SLOT_BUSY,	"CCID_ERR_SLOT_BUSY"},

/* e */	{IS_BITS_1, CS_BITS_1, CCID_ERR_SLOT_BUSY,	"CCID_ERR_SLOT_BUSY"},

/* f */	{IS_BITS_2, CS_BITS_1, CCID_ERR_SLOT_BUSY,	"CCID_ERR_SLOT_BUSY"},

/* 10 */{IS_BITS_1, CS_BITS_1, CCID_ERR_BUSY_AUTO_SEQ,	"Automatic sequence on-going"},

/* 11 */{IS_BITS_0, CS_BITS_1, 0x07,			"bPowerselect error(not supported)"},

/* 12 */{IS_BITS_0, CS_BITS_1, CCID_ERR_XFR_PARITY,	"parity error"},

/* 13 */{IS_BITS_0, CS_BITS_1, CCID_ERR_XFR_OVERRUN,	"CCID_ERR_XFR_OVERRUN"},

/* 14 */{IS_BITS_0, CS_BITS_1, CCID_ERR_ICC_MUTE,	"ICC mute (Time out)"},

/* 15 */{IS_BITS_0, CS_BITS_1, 0x08,			"Bad wLevelParameter"},

/* 16 */{IS_BITS_0, CS_BITS_1, 0x01,			"Bad dwLength"},

/* 17 */{IS_BITS_0, CS_BITS_1, CCID_ERR_CMD_ABORTED,	"Command aborted by control pipe"},

/* 18 */{IS_BITS_0, CS_BITS_1, 0x07,			"Protocol invalid or not supported"},

/* 19 */{IS_BITS_0, CS_BITS_1, 0x10,			"FI �C DI pair invalid or not supported"},

/* 1a */{IS_BITS_0, CS_BITS_1, 0x11,			"Invalid TCCKTS parameter"},

/* 1b */{IS_BITS_0, CS_BITS_1, 0x12,			"Guard time not supported"},

/* 1c */{IS_BITS_0, CS_BITS_1, 0x13,			"(T=0)WI invalid or not supported/(T=1)BWI or CWI invalid or not supported"},

/* 1d */{IS_BITS_0, CS_BITS_1, 0x14,			"Clock stop support requested invalid or not supported"},

/* 1e */{IS_BITS_0, CS_BITS_1, 0x15,			"IFSC size invalid or not supported"},

/* 1f */{IS_BITS_0, CS_BITS_1, 0x16,			"NAD value invalid or not supported"},


#define MAX_ERROR_ITEM		0x1F

	{0,	    0,	       0,			NULL},
};

struct ccid_resp_error {
	uint8_t cmd;
	/* end by -1 */
	int err_items[MAX_ERROR_ITEM];
};

struct ccid_resp_error Resp_Error_Items[] = {
	{
		PC_TO_RDR_ICCPOWERON, 
		{
			0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A,
			0x0B, 0x0C, 0x0D, 0x0E, 0x0F, -1,
		},
	},

	{
		PC_TO_RDR_ICCPOWEROFF,
		{
			0x01, 0x10, 0x0C, 0x0D, 0x0E, 0x0F, -1,
		},
	},

	{
		PC_TO_RDR_GETSLOTSTATUS,
		{
			0x01, 0x02, 0x03, 0x0C, 0x0D, 0x0E, 0x0F, -1,
		},
	},

	{
		PC_TO_RDR_XFRBLOCK,
		{
			0x01, 0x02, 0x10, 0x03, 0x0C, 0x0D, 0x0E, 0x0F, 0x11, 0x12,
			0x13, 0x14, 0x15, 0x16, 0x17, -1,
		},
	},

	{
		PC_TO_RDR_GETPARAMETERS,
		{
			0x01, 0x02, 0x10, 0x03, 0x0C, 0x0D, 0x0E, 0x0F, -1,
		},
	},

	{
		PC_TO_RDR_RESETPARAMETERS,
		{
			0x01, 0x02, 0x10, 0x03, 0x0C, 0x0D, 0x0E, 0x0F, -1,
		},
	},

	{
		PC_TO_RDR_SETPARAMETERS,
		{
			0x01, 0x02, 0x10, 0x03, 0x0C, 0x0D, 0x0E, 0x0F, 0x18, 0x19,
			0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, -1,
		},
	},

	{
		PC_TO_RDR_ESCAPE,
		{
			0x01, 0x0C, 0x0D, 0x0E, 0x0F, 0x0B, /* FXIME: Manufacturer */-1, 
		},
	},
	
	{
		PC_TO_RDR_ICCCLOCK,
		{
			0x01, 0x02, 0x10, 0x03, 0x0C, 0x0D, 0x0E, 0x0F, -1, 
		},
	},

	{
		PC_TO_RDR_T0APDU,
		{
			0x01, 0x02, 0x09, 0x03, 0x0B, 0x0C, -1, 
		},
	},

	{
		PC_TO_RDR_SECURE,
		{
			0x01, 0x02, 0x10, 0x03, 0x0C, 0x0D, 0x0E, 0x0F, 0x05, 0x06,
			0x0B, -1, 
		},
	},

	{
		PC_TO_RDR_MECHANICAL,
		{
			0x01, 0x02, 0x10, 0x03, 0x0C, 0x0D, 0x0E, 0x0F, -1, 
		},
	},

	{
		PC_TO_RDR_ABORT,
		{
			0x01, 0x0C, 0x0D, 0x0E, 0x0F, -1, 
		},
	},

	{
		PC_TO_RDR_SETDATARATEANDCLOCK,
		{
			0x01, 0x0C, -1, 
		},
	},

	{0, -1,},
};

uint8_t g_t_buff[MAX_BUFFER_LEN - 70];

struct cmd_list {
	int id;
	uint8_t cmd[MAX_BUFFER_LEN];
	int len;
};

struct cmd_list list[] = {
	{
		1,/* read file 50184401 muscle card */
		{
			0xB0, 0x56, 0x00, 0x00, 0x09,
	 	 	0x3F, 0x00, 0x2F, 0x00, 0x00,
	 	 	0x00, 0x00, 0x00, 0x80, 0x80
		},
		15,
	},
	{
		2,/* get_response and except 0xFF */
		{
			0xB0, 0xC0, 0x00, 0x00, 0xFF
		},

	},
	{
		3, /* muscel select */
		{
			0x00, 0xA4, 0x04, 0x00, 0x06,
			0xA0, 0x00, 0x00, 0x00, 0x01, 0x01,
		},
		11
	},
	{
		4, /* wd select */
		{
			0x00, 0xA4, 0x00, 0x00, 0x02,
			0x3F, 0x00, 0x00,
		},
		8
	},
	{
		5, /* wd read_binary */
		{
			0x00, 0xB0, 0x00, 0x00, 0x70,
		},
		5
	},
	{
		6, /* wd select */
		{
			0x00, 0xA4, 0x00, 0x00, 0x02,
			0x50, 0x18, 0x00,
		},
		8
	},
	{
		7, /* wd select */
		{
			0x00, 0xA4, 0x00, 0x00, 0x02,
			0x50, 0x32, 0x00,
		},
		8
	},

	{-1, NULL, 0},
};

static int __test_buffer_len(int idx)
{
	struct cmd_list *ll = list;
	int id;

	if (idx == -1)
		goto out;
	id = ll->id;
	for ( ;id != -1; ll++) {
		id = ll->id;
		if (id == idx)
			return ll->len;
	}

out:
	return sizeof (g_t_buff);
}

static uint8_t *__test_buffer(int idx)
{
	int id = list[0].id;
	struct cmd_list *ll = list;

	if (idx == -1)
		goto out;
	for (;id != -1; ll++) {
		id = ll->id;
		if (id == idx)
			return ll->cmd;
	}
out:
	return g_t_buff;
}

static void __gen_test_buffer(void)
{
	int len = __test_buffer_len(0);
	int i;

	memset(g_t_buff, 0, sizeof (g_t_buff));

	for (i = 0; i < len; i++) {
		g_t_buff[i] = random() % 0xff;
	}
}

#define MAX_BLOCK_LEN()	\
	g_desc.dwMaxCCIDMessageLength

/* smart card device class descriptor */
int ccid_parse_desc(const uint8_t *src, size_t len)
{
	struct ccid_descriptor *ccid_desc = &g_desc;
	/* SEPC 5.1 */
	if (len != CCID_DESCRIPTOR_LENGTH)
		return 0;

	ccid_desc->bLength = src[0];
	ccid_desc->bDescriptorType = src[1];
	ccid_desc->bcdCCID = (src[3] << 8) & src[2];
	ccid_desc->bMaxSlotIndex = src[4];
	ccid_desc->bVoltageSupport = src[5];
	ccid_desc->dwProtocols = 
		src[9] << 24 | src[8] << 16 | src[7] << 8 | src[6];
	ccid_desc->dwDefaultClock = 
		src[13] << 24 | src[12] << 16 | src[11] << 8 | src[10];
	ccid_desc->dwMaximumClock = 
		src[17] << 24 | src[16] << 16 | src[15] << 8 | src[14];
	ccid_desc->bNumClockSupported = src[18];
	ccid_desc->dwDataRate = 
		src[22] << 24 | src[21] << 16 | src[20] << 8 | src[19];
	ccid_desc->dwMaxDataRate = 
		src[26] << 24 | src[25] << 16 | src[24] << 8 | src[23];
	ccid_desc->bNumDataRatesSupported = src[27];
	ccid_desc->dwMaxIFSD = 
		src[31] << 24 | src[30] << 16 | src[29] << 8 | src[28];
	ccid_desc->dwSynchProtocols = 
		src[35] << 24 | src[34] << 16 | src[33] << 8 | src[32];
	ccid_desc->dwMechanical = 
		src[39] << 24 | src[38] << 16 | src[37] << 8 | src[36];
	ccid_desc->dwFeatures = 
		src[43] << 24 | src[42] << 16 | src[41] << 8 | src[40];
	ccid_desc->dwMaxCCIDMessageLength = 
		src[47] << 24 | src[46] << 16 | src[45] << 8 | src[44];
	ccid_desc->bClassGetResponse = src[48];
	ccid_desc->bClassEnvelope = src[49];
	ccid_desc->wLcdLayout = src[51] << 8 | src[50];
	ccid_desc->bPINSupport = src[52];
	ccid_desc->bMaxCCIDBusySlots = src[53];

	ccid_desc_output();

	return 1;
}

int ccid_msg_ispair(uint8_t cmd, uint8_t resp)
{
	switch (cmd) {
	case PC_TO_RDR_ICCPOWERON:
	case PC_TO_RDR_XFRBLOCK:
	case PC_TO_RDR_SECURE:
		return (resp == RDR_TO_PC_DATABLOCK);
	case PC_TO_RDR_ICCPOWEROFF:
	case PC_TO_RDR_GETSLOTSTATUS:
	case PC_TO_RDR_ICCCLOCK:
	case PC_TO_RDR_T0APDU:
	case PC_TO_RDR_MECHANICAL:
	case PC_TO_RDR_ABORT:
		return (resp == RDR_TO_PC_SLOTSTATUS);
	case PC_TO_RDR_SETPARAMETERS:
	case PC_TO_RDR_GETPARAMETERS:
	case PC_TO_RDR_RESETPARAMETERS:
		return (resp == RDR_TO_PC_PARAMETERS);
	case PC_TO_RDR_ESCAPE:
		return (resp == RDR_TO_PC_ESCAPE);
	case PC_TO_RDR_SETDATARATEANDCLOCK:
		return (resp == RDR_TO_PC_DATARATEANDCLOCKFREQUENCY);
	default:
		return 0;
	}
}

const char *ccid_msg_type(uint8_t type)
{
	switch (type) {
	case PC_TO_RDR_ICCPOWERON: return "P2R_PWRON";
	case PC_TO_RDR_ICCPOWEROFF: return "P2R_PWROFF";
	case PC_TO_RDR_SETPARAMETERS: return "P2R_SETPARAM";
	case PC_TO_RDR_GETPARAMETERS: return "P2R_GETPARAM";
	case PC_TO_RDR_RESETPARAMETERS: return "P2R_RESETPARAM";
	case PC_TO_RDR_ABORT: return "P2R_ABORT";
	case PC_TO_RDR_XFRBLOCK: return "P2R_XFRBLOCK";
	case PC_TO_RDR_GETSLOTSTATUS: return "P2R_GETSLOTSTATUS";
	case PC_TO_RDR_ESCAPE: return "P2R_ESCAPE";
	case PC_TO_RDR_SECURE: return "P2R_SECURE";
	case PC_TO_RDR_T0APDU: return "P2R_T0APDU";
	case PC_TO_RDR_ICCCLOCK: return "CLOCK";
	case PC_TO_RDR_MECHANICAL: return "MECHANICAL";
	case PC_TO_RDR_SETDATARATEANDCLOCK: return "SET_DATARATE_CLOCK";	
	case RDR_TO_PC_PARAMETERS: return "R2P_PARAM";	
	case RDR_TO_PC_ESCAPE: return "R2P_ESCAPE";
	case RDR_TO_PC_DATABLOCK: return "R2P_DATABLOCK";
	case RDR_TO_PC_SLOTSTATUS: return "R2P_SLOTSTATUS";
	case RDR_TO_PC_DATARATEANDCLOCKFREQUENCY: return "R2P_DATARATE_FREQ";
		break;
	default:
		return "unknown";
	}
}

static void i2dw(int value, unsigned char buffer[])
{
	buffer[0] = value & 0xFF;
	buffer[1] = (value >> 8) & 0xFF;
	buffer[2] = (value >> 16) & 0xFF;
	buffer[3] = (value >> 24) & 0xFF;
}

static uint32_t dw2i(uint8_t *dw)
{
	return (dw[0]) | (dw[1] << 8) | (dw[2] << 16) | (dw[3] << 24); 
}

static void ccid_build_common(int bSlot, int bSeq, int type)
{
	memset(output, 0, sizeof (output));
	output[0] = type;
	output[1] = 0x00;
	output[2] = 0x00;
	output[3] = 0x00;
	output[4] = 0x00;
	output[5] = bSlot;
	output[6] = bSeq;
	output[7] = 0x00;
	output[8] = 0x00;
	output[9] = 0x00;	
}

static void ccid_build_PowerOn(int bSlot, int bSeq, uint8_t v)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_ICCPOWERON);
	output[7] = v;
	return;
}

static void ccid_build_PowerOff(int bSlot, int bSeq)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_ICCPOWEROFF);
	return;
}

static void ccid_build_GetSlotStatus(int bSlot, int bSeq)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_GETSLOTSTATUS);
	return;
}

static void ccid_build_SetParameters(int bSlot, int bSeq, int proto, uint8_t *data, int len)
{
	if (len + 10 > MAX_BUFFER_LEN) {
		printf("err length\r\n");
		return;
	}

	ccid_build_common(bSlot, bSeq, PC_TO_RDR_SETPARAMETERS);
	output[7] = proto;

	if (len > 0) {
		i2dw(len, output + 1);
		/* apdu */
		memcpy(output + 10, data, len);
	}
}

static void ccid_build_xfrblock(int bSlot, int bSeq, const uint8_t *data, int len)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_XFRBLOCK);
	i2dw(len, output + 1);
	/* if reader is APDU level 
	 * output[7] and output[8] are both 0x00 */
	memcpy(output + 10, data, len);
}

static void ccid_build_GetParameters(int bSlot, int bSeq)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_GETPARAMETERS);
	return;
}

static void ccid_build_ResetParameters(int bSlot, int bSeq)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_RESETPARAMETERS);
	return;
}

static void ccid_build_Escape(int bSlot, int bSeq, uint8_t *data, int len)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_ESCAPE);
	i2dw(len, output + 1);
	/* reader is APDU level 
	 * so output[7] and output[8] are both 0x00 */
	memcpy(output + 10, data, len);

}
static void ccid_build_IccClock(int bSlot, int bSeq, uint8_t clk)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_ICCCLOCK);
	output[7] = clk;
}

static void ccid_build_T0APDU(int bSlot, int bSeq, uint8_t a, uint8_t b, uint8_t c)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_T0APDU);
	output[7] = a;
	output[8] = b;
	output[9] = c;
}

static void ccid_build_Secure(int bSlot, int bSeq, uint8_t bBWI, uint16_t wLevelParameter,
			      uint8_t *data, int len)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_SECURE);
	output[7] = bBWI;
	output[8] = wLevelParameter & 0x00FF;
	output[9] = (wLevelParameter & 0xFF00) >> 8;

	if (len > 0) {
		i2dw(len, output + 1);
		/* apdu */
		memcpy(output + 10, data, len);
	}
}

static void ccid_build_Mechanical(int bSlot, int bSeq, uint8_t fun)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_MECHANICAL);
	output[7] = fun;
}

static void ccid_build_SetDataRateAndClockFrequency(int bSlot, int bSeq, 
						    const uint8_t *data, int len)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_SETDATARATEANDCLOCK);
	i2dw(len, output + 1);
	/* reader is APDU level 
	 * so output[7] and output[8] are both 0x00 */
	memcpy(output + 10, data, len);
}



static void ccid_build_Abort(int bSlot, int bSeq)
{
	ccid_build_common(bSlot, bSeq, PC_TO_RDR_ABORT);
	return;
}

int do_PowerOn(void)
{
	int ret = 0;
	uint8_t v = 0x00;

	if (g_data.opened && g_data.len == 1) {
		v = *g_data.data;
	}
	ccid_build_PowerOn(DEF_SLOT, gSeq++, v);
	g_data.opened = 0;

	if ((ret = test_bulk_send(output, 10, 1)) == 0)
		return 1;	
	/* some fail */
	return 0;
}

void ccid_atr_output(void)
{
	uint8_t *p = input;	
	int atr_len;

	atr_len = dw2i(&input[1]);
	
	if (atr_len <= 0)
		return;

	p += ccid_header_length;
	__print_atr(p, atr_len);
}

int do_PowerOn_parse(void)
{
	int ret = 0;
	uint8_t v = 0x00;

	if (g_data.opened && g_data.len == 1) {
		v = *g_data.data;
	}
	ccid_build_PowerOn(DEF_SLOT, gSeq++, v);
	g_data.opened = 0;

	if ((ret = test_bulk_send(output, 10, 1)) == 0) {
		while (!do_Reap())
			;
		ccid_atr_output();
		return 1;
	}
	/* some fail */
	return 0;
}

int do_GetSlotStatus(void)
{
	int ret = 0;

	ccid_build_GetSlotStatus(DEF_SLOT, gSeq++);
	if ((ret = test_bulk_send(output, 10, 1)) == 0)
		return 1;
	return 0;
}

int do_GetParameters(void)
{
	int ret = 0;

	ccid_build_GetParameters(DEF_SLOT, gSeq++);
	if ((ret = test_bulk_send(output, 10, 1)) == 0)
		return 1;
	return 0;
}

uint8_t FD_table[] = {0x13, 0x22, 0x33, 0x44, 0x55, 
		      0x66, 0x77, 0x88, 0x99, 0x94,
		      0x93, 0x92, 0x91, 0x21, 0x48,
		      0x54, 0x83, 0x31};

int gidx = 0;

int do_SetParameters(void)
{
	int ret = 0;
	/* T=0 len 5, T=1 len 7 */
	uint8_t data[5];

	/* bmFindexDindex iso7816-3 table 7/8 */
	data[0] = FD_table[gidx++ % sizeof (FD_table)];

	/* bmTCCKST0: CCID ignore this */
	data[1] = 0x0;
	/* bGuardTimeT0 */
	data[2] = 0;
	/* bWaitingIntegerT0 */
	data[3] = 0x0b;
	/* bClockStop */
	data[4] = 0x00;

	ccid_build_SetParameters(DEF_SLOT, gSeq++, 0, data, 5);
	if ((ret = test_bulk_send(output, 10 + 5, 1)) == 0) {
		return 1;
	}
	return 0;
}

int do_ResetParameters(void)
{
	int ret = 0;
	ccid_build_ResetParameters(DEF_SLOT, gSeq++);
	if ((ret = test_bulk_send(output, 10, 1)) == 0)
		return 1;		
	return 0;
}

int do_Escape(void)
{
	int len = 0, ret = 0;
	uint8_t *data = NULL;

	if (g_data.opened) {
		data = g_data.data;
		len = g_data.len;
	}

	ccid_build_Escape(DEF_SLOT, gSeq++, data, len);

	/* XXX */
	g_data.opened = 0;
	
	if ((ret = test_bulk_send(output, 10 + len, 1)) == 0)
		return 1;		
	return 0;
}

int do_IccClock(void)
{
	int ret = 0;
	uint8_t clk_cmd = 0x0;

	if (g_data.opened && g_data.len == 1) {
		clk_cmd = *g_data.data;
	}

	ccid_build_IccClock(DEF_SLOT, gSeq++, clk_cmd);
	g_data.opened = 0;

	if ((ret = test_bulk_send(output, 10, 1)) == 0)
		return 1;	
	return 0;

}

int do_T0APDU(void)
{
	int ret = 0;
	uint8_t bmChanges = 0x0;
	uint8_t bClassGetResponse = 0x00;
	uint8_t bClassEnvelope = 0x00;


	if (g_data.opened && g_data.len == 3) {
		bmChanges = g_data.data[0];
		bClassGetResponse = g_data.data[1];
		bClassEnvelope = g_data.data[2];
	}

	ccid_build_T0APDU(DEF_SLOT, gSeq++, bmChanges, bClassGetResponse, bClassEnvelope);
	g_data.opened = 0;

	if ((ret = test_bulk_send(output, 10, 1)) == 0)
		return 1;	
	return 0;
}

int do_Secure(void)
{
	int ret = 0;
	/* FIXME: param */
	ccid_build_Secure(DEF_SLOT, gSeq++, 0, 0, NULL, 0);
	if ((ret = test_bulk_send(output, 10, 1)) == 0)
		return 1;		
	return 0;
}

int do_Mechanical(void)
{
	int ret = 0;
	uint8_t fun = 0x0;

	if (g_data.opened && g_data.len == 1) {
		fun = *g_data.data;
	}

	ccid_build_Mechanical(DEF_SLOT, gSeq++, fun);
	g_data.opened = 0;

	if ((ret = test_bulk_send(output, 10, 1)) == 0)
		return 1;	
	return 0;
}

int do_SetDataRateAndClockFrequency(void)
{
	int len = 0, ret = 0;
	uint8_t *data = NULL;

	if (g_data.opened) {
		data = g_data.data;
		len = g_data.len;
	}

	ccid_build_SetDataRateAndClockFrequency(DEF_SLOT, gSeq++, data, len);

	/* XXX */
	g_data.opened = 0;
	
	if ((ret = test_bulk_send(output, 10 + len, 1)) == 0)
		return 1;		
	return 0;
}

int do_PowerOff(void)
{
	int ret = 0;
	ccid_build_PowerOff(DEF_SLOT, gSeq++);
	if ((ret = test_bulk_send(output, 10, 1)) == 0)
		return 1;		
	return 0;
}

/* user may indicate the seq */
int do_Abort(int type, int seq)
{
	/* abort last sent */
	dbg_log(LOG_DEBUG, "\t......send abort %s......",
	       type == CCID_ABORT_T_CTRL ? "request" : "command");

	if (CCID_ABORT_T_CTRL == type) {
		uint16_t wValue;
		wValue = seq << 8;
		wValue |= DEF_SLOT;
		/* CCID SPEC, note this need not CCID Header */
		return test_ctrl_msg(CCID_REQ_TYPE_ABORT, CCID_REQ_ABORT,
				     wValue, DEF_INTFC, NULL, 0);
	} else {
		int ret;
		ccid_build_Abort(DEF_SLOT, seq);
		if ((ret = test_bulk_send(output, 10, 1)) == 0)
			return 1;
	}
	return 0;
}


int ctrl_config_desc(void)
{
	int ret, tmp = 0;
	ret = test_ctrl_msg(ENDPOINT_IN, _REQUEST_GET_CONFIGURATION , 0, 0, &tmp, 1);
	dbg_log(LOG_DEBUG, "get config ret=%d, tmp=%d", ret, tmp);
	return ret;
}

int ctrl_intferce_desc(void)
{
	int ret;
	uint8_t data[50];

	ret = test_ctrl_msg(ENDPOINT_IN, _REQUEST_GET_DESCRIPTOR, _DT_INTERFACE << 8 | DEF_INTFC,
			0, data, 50);

	dbg_log(LOG_DEBUG, "get interface desc ret=%d", ret);
	return ret;
}


static int idx = 0;
static int arr[] = {4, 6, 7, 5, 4, 4, 4, 4, 4, 4, -1};

int do_XfrBlock(void)
{
	int ret, len;
	const uint8_t *data;

	__gen_test_buffer();
	len = __test_buffer_len(arr[idx]);
	data = __test_buffer(arr[idx++]);

	if (len == 0)
		return 0;

	if (len > (int)MAX_BLOCK_LEN() || len > MAX_BUFFER_LEN) {
		dbg_log(LOG_DEBUG, "xfrblock too large data to send");
		return 0;
	}
	ccid_build_xfrblock(DEF_SLOT, gSeq++, data, len);
	if ((ret = test_bulk_send(output, len+10, 1)) == 0)
		return 1;		
	return 0;
}

/* receive from slot */
int do_Reap(void)
{
	int ret;

	if ((ret = test_bulk_recv(input, sizeof (input), 1)) > 0)
		return 1;
	return 0;
}

int ccid_resp_valid(uint8_t cmd)
{
	struct ccid_resp_error *resp_err;
	uint8_t status = input[CCID_OFFSET_STATUS];
	uint8_t errors = input[CCID_OFFSET_ERROR];
	int i, items;
	uint8_t is_bits = (status & CCID_ICC_STATUS_MASK);
	uint8_t cs_bits = (status & CCID_CMD_STATUS_MASK);

	if (status & 0x3C) {
		dbg_log(LOG_DEBUG, "error=used RFU field");
		return 0;
	}
	/* if no error */
	if (!(status & CCID_CMD_STATUS_FAILED))
		return 1;
	/* check error valid */
	for (i = 0; i < sizeof (Resp_Error_Items); i++) {
		int idx = 0;
		resp_err = &Resp_Error_Items[i];

		/* end */
		if (resp_err->cmd == 0)
			break;

		if (resp_err->cmd != cmd)
			continue;
		while (resp_err->err_items[idx] != -1) {
			items = resp_err->err_items[idx];
			
			if (is_bits == Error_Items[items].bmICCStatus &&
			    cs_bits == Error_Items[items].bmCommandStatus &&
			    errors  == Error_Items[items].bError) {
				dbg_log(LOG_DEBUG, "match error=%s", Error_Items[items].desc);
				return 1;
			}
			idx++;
		}
		break;
	}

	dbg_log(LOG_DEBUG, "no matched is=%02X, error=%02X",
		is_bits, input[CCID_OFFSET_ERROR]);
	return 0;
}

int ccid_resp_match(void)
{
	uint8_t cmd = output[0];
	uint8_t resp = input[0];

	/* match type and seq first */
	if (ccid_msg_ispair(cmd, resp)) {
		if (input[6] == output[6])
			return ccid_resp_valid(cmd);
		else {
			dbg_log(LOG_DEBUG, "error=mismatch seq");
		}
	} else {
		dbg_log(LOG_DEBUG, "error=mismatch response type");
	}
	return 0;
}

int ccid_get_param(uint8_t *param)
{
	uint8_t *p = input;	
	int param_len;

	param_len = dw2i(&input[1]);

	if (param_len <= 0)
		return 0;

	p += ccid_header_length;

	memcpy(param, p, param_len);
	return 1;
}


static void ccid_desc_output(void)
{
	struct ccid_descriptor *d = &g_desc;
	char *p, v_str[20];
	char p_str[20];

	memset(v_str, 0, 20);
	memset(p_str, 0, 20);

	p = v_str;

	if (d->bVoltageSupport & 0x01) {
		strcpy(p, "5.0v ");
		p += 5;
	}
	if (d->bVoltageSupport & 0x02) {
		strcpy(p, "3.0v ");
		p += 5;
	}
	if (d->bVoltageSupport & 0x04) {
		strcpy(p, "1.8v");
		p += 4;
	}
	*p = '\0';

	p = p_str;

	if (d->dwProtocols & 0x01) {
		strcpy(p, "T=0 ");
		p += 4;
	}
	if (d->dwProtocols & 0x02) {
		strcpy(p, "T=1");
		p += 3;
	}
	*p = '\0';
	dbg_log(LOG_DEBUG, "Found CCID reader:");
//	dbg_log(LOG_DEBUG, "idVendor: 04E6  idProduct: 5115  bcdDevice: 0518");	
	dbg_log(LOG_DEBUG, "ChipCard Interface Descriptor:");	
	dbg_log(LOG_DEBUG,    "bLength             %d", d->bLength);
	dbg_log(LOG_DEBUG,    "bDescriptorType     %d", d->bDescriptorType);
	dbg_log(LOG_DEBUG,    "bcdCCID             %04Xh", d->bcdCCID);
	dbg_log(LOG_DEBUG,    "bMaxSlotIndex       %d", d->bMaxSlotIndex);
	dbg_log(LOG_DEBUG,    "bVoltageSupport     %d (%s)", d->bVoltageSupport, v_str);
	dbg_log(LOG_DEBUG,    "dwProtocols         %u (%s)", d->dwProtocols, p_str);
	dbg_log(LOG_DEBUG,    "dwDefaultClock      %u", d->dwDefaultClock);
	dbg_log(LOG_DEBUG,    "dwMaxiumumClock     %u", d->dwMaximumClock);
	dbg_log(LOG_DEBUG,    "bNumClockSupported  %d", d->bNumClockSupported);
	dbg_log(LOG_DEBUG,    "dwDataRate          %u bps", d->dwDataRate);
	dbg_log(LOG_DEBUG,    "dwMaxDataRate       %u bps", d->dwMaxDataRate);
	dbg_log(LOG_DEBUG,    "bNumDataRatesSupp   %d", d->bNumDataRatesSupported);
	dbg_log(LOG_DEBUG,    "dwMaxIFSD           %u", d->dwMaxIFSD);
	dbg_log(LOG_DEBUG,    "dwSyncProtocols     %d", d->dwSynchProtocols);
	dbg_log(LOG_DEBUG,    "dwMechanical        %d", d->dwMechanical);
	dbg_log(LOG_DEBUG,    "dwFeatures          %-8X", d->dwFeatures);
	if (d->dwFeatures & 0x00000002)
		dbg_log(LOG_DEBUG,    "  Auto configuration based on ATR");
	if (d->dwFeatures & 0x00000004)
		dbg_log(LOG_DEBUG,    "  Automatic activation of ICC on inserting");
	if (d->dwFeatures & 0x00000008)
		dbg_log(LOG_DEBUG,    "  Automatic ICC voltage selection");
	if (d->dwFeatures & 0x00000010)
		dbg_log(LOG_DEBUG,    "  Automatic ICC clock frequency change");
	if (d->dwFeatures & 0x00000020)
		dbg_log(LOG_DEBUG,    "  Automatic baud rate change");
	if (d->dwFeatures & 0x00000040)
		dbg_log(LOG_DEBUG,    "  Automatic parameters negotiation");
	if (d->dwFeatures & 0x00000080)
		dbg_log(LOG_DEBUG,    "  Automatic PPS made by the CCID according to the active parameters");
	if (d->dwFeatures & 0x00000100)
		dbg_log(LOG_DEBUG,    "  CCID can set ICC in clock stop mode");
	if (d->dwFeatures & 0x00000200)
		dbg_log(LOG_DEBUG,    "  NAD value other than 00 accepted (T=1 protocol in use)");
	if (d->dwFeatures & 0x00000400)
		dbg_log(LOG_DEBUG,    "  Automatic IFSD exchange as first exchange (T=1 protocol in use)");
	if (d->dwFeatures & 0x00010000)
		dbg_log(LOG_DEBUG,    "  TPDU level");
	else if (d->dwFeatures & 0x00020000)
		dbg_log(LOG_DEBUG,    "  Short APDU level");
	else if (d->dwFeatures & 0x00040000)
		dbg_log(LOG_DEBUG,    "  Short and Extended APDU level");
	else
		dbg_log(LOG_DEBUG,    "  Character level");
#if 0
	if (d->dwFeatures & 0x00000040)
		dbg_log(LOG_DEBUG,    "  Host shall not try to change the FI, DI, and protocol currently selected.");
#endif
	dbg_log(LOG_DEBUG,    "dwMaxCCIDMsgLen      %d", d->dwMaxCCIDMessageLength);
//	dbg_log(LOG_DEBUG,    "bClassGetResponse    echo");
//	dbg_log(LOG_DEBUG,    "bClassEnvelope       echo");
	dbg_log(LOG_DEBUG,    "wlcdLayout           %d", d->wLcdLayout);
	dbg_log(LOG_DEBUG,    "bPINSupport          %d", d->bPINSupport);
	dbg_log(LOG_DEBUG,    "bMaxCCIDBusySlots    %d", d->bMaxCCIDBusySlots);
}

static int __print_atr(const char *atr, size_t atr_len)
{
	uint16_t p;
	uint8_t K, TCK;		/* MSN of T0/Check Sum */
	uint8_t Y1i, T;		/* MSN/LSN of TDi */
	int i = 1, history_len;	/* value of the index in TAi, TBi, etc. */
	uint8_t TS;

	p = K = TCK = Y1i = T = 0;

	if (atr_len < 2)
		return -1;

	if (atr[0] == 0x3F)
		TS = 0x01;
	else if (atr[0] == 0x3B)
		TS = 0x02;

	Y1i = atr[1] >> 4;
	K = atr[1] & 0x0F;

	p = 2;

	dbg_log(LOG_DEBUG, "parse ATR:");

	dbg_log(LOG_DEBUG, "T0=%02X", atr[1]);

	do {
		short TAi, TBi, TCi, TDi;

		TAi = (Y1i & 0x01) ? (uint8_t)atr[p++] : -1;
		TBi = (Y1i & 0x02) ? (uint8_t)atr[p++] : -1;
		TCi = (Y1i & 0x04) ? (uint8_t)atr[p++] : -1;
		TDi = (Y1i & 0x08) ? (uint8_t)atr[p++] : -1;
		
		dbg_log(LOG_DEBUG, "TA%d=%02X, TB%d=%02X, TC%d=%02X, TD%d=%02X",
				i, TAi == -1 ? 0 : TAi, i, TBi == -1 ? 0 : TBi,
				i, TCi == -1 ? 0 : TCi, i, TDi == -1 ? 0 : TDi);

		if (TDi >= 0) {
			Y1i = TDi >> 4;
			T = TDi & 0x0F;

			switch (T) {
			case 0: 
				dbg_log(LOG_DEBUG, "protocol T=0");
				break;
			case 1:
				dbg_log(LOG_DEBUG, "protocol T=1");
				break;
			default:
				return -1;
			}

			if ((i == 2) && (TAi >= 0)) {
				T = TAi & 0x0F;
			}
		} else {
			Y1i = 0;
		}

		i++;
	} while (Y1i != 0);
	
	history_len = K;
	dbg_log(LOG_DEBUG, "history len=%d", history_len);
	p += K;

	return 0;
}

